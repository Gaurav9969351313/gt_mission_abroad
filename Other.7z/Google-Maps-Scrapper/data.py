data = {
    'names': [], 'rates': [], 'addresses': [], 'plus_code': [], 'phones': [], 'websites': [],
    'reviews_count': [], 'glinks': [], 'links': [], 'latitudes': [], 'longitudes': [], 'type': []
}
