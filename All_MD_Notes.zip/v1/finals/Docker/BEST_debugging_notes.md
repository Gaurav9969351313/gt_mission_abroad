### 🐛 Top 6 JavaScript Debugging Tricks No One Knows
JavaScript, the ever-so-dynamic language of the web, has a dark side that often leaves developers scratching their heads. Debugging those tricky bugs can become its own challenging adventure. While most coders rely on traditional methods like `console.log` and breakpoints, it's time to discover some hidden gems for debugging hacks.

### **1. The Magic of** `console.table`

Visualize complex objects and arrays with `console.table`. This transforms your data into a well-structured tabular format within your console:
```javascript
const myData = [  
  { name: "Alice", age: 30 },  
  { name: "Bob", age: 25 }  
];  
console.table(myData);
```
![](https://miro.medium.com/v2/resize:fit:875/1*W-_gGTdgwYWVCYCZ4aYxpw.png)

### **2. Unravel Call Stacks with** `console.trace`

When you're lost in a maze of function calls, `console.trace` comes to the rescue. Get a clear picture of how your code arrived at a specific point, illuminating the path of execution.
```javascript
function foo() {  
  function bar() {  
    console.trace("Trace from function bar");   
  }  
  bar();  
}  
foo();
```
![](https://miro.medium.com/v2/resize:fit:600/1*CVmr7c7BLXB9PKwSIqg_LA.png)

### **3. Performance Profiling**

Optimize like a pro using the browser's built-in performance tools. Start profiling with `console.time('label')` and end it with `console.timeEnd('label')`. This will log the execution time of your code blocks, pinpointing bottlenecks.
```javascript
function sortNumbers(numbers) {  
  // Let's use bubble sort here for demonstration   
  // (but it's not the most efficient way to sort!)  
   
  for (let i = 0; i < numbers.length; i++) {  
    for (let j = 0; j < numbers.length - i - 1; j++) {  
      if (numbers[j] > numbers[j + 1]) {  
        let temp = numbers[j];  
        numbers[j] = numbers[j + 1];  
        numbers[j + 1] = temp;  
      }  
    }  
  }  
  return numbers;  
}  

// Generate a large array of random numbers  
const unsortedArray = [];  
for (let i = 0; i < 10000; i++) {  
  unsortedArray.push(Math.floor(Math.random() * 1000));  
}  
  
// Measure the sorting time  
console.time('Sorting Time');   
const sortedArray = sortNumbers(unsortedArray);    
console.timeEnd('Sorting Time');  
  
// Sorting Time: 66.73681640625 ms
```
### **4. Embrace Advanced Assertions**

Assert your assumptions with `console.assert`. It logs an error if the assertion is false, helping you fail early and catch potential errors:
```javascript
console.assert(myArray.length > 0, "myArray is empty!");
```
### **5. “Poor Man's” Time Travel Debugging**

While “true” time travel debugging might still be sci-fi, you can create snapshots of your application's state. Use `JSON.stringify()` to serialize objects and store them, allowing you to revisit and analyze past states for tricky bugs.
```javascript
const stateSnapshot = JSON.stringify(currentAppState);   
// Store stateSnapshot for later comparison
```
Sometimes, you just need a more visually pleasing view of a complex object or a large chunk of JSON data. Combine `JSON.stringify` with some formatting:
```javascript
const complexObject = { /* ... your data */ };  
console.log(JSON.stringify(complexObject, null, 2));
```
This will output your data as a nicely formatted JSON string with indentation, making it much easier to parse and understand.

### **6. Unveiling Object Properties with** `console.log({obj})`

While `console.log(obj)` is the go-to for logging objects, it can be frustrating for complex objects with nested structures. By wrapping the object in curly braces, you're essentially creating a new object literal with the original object as a single property. This instructs the console to use its improved formatting for objects, revealing the properties and their values in a more readable way:
```javascript
const person = { name: "Alice", age: 30 };  
console.log(person); // { name: "Alice", age: 30 }  
console.log({ person }); // { person: { name: "Alice", age: 30 } }
```
Remember, debugging is as much an art as it is a science. Embrace the process, and don't be afraid to experiment! The more you practice these methods and explore the hidden corners of your browser's developer tools, the more you'll level up your JavaScript mastery.


----
# IntelliJ IDEA debugging best practices 
**_Line breakpoint_**

Stops the application when it reaches the line of code where it was added. This kind of breakpoint can be added only to the executable line of code. If the line contains a lambda expression, you can select whether you want to set a regular line breakpoint, or the program should only be stopped only when the lambda is called.


**_Method breakpoint_**

Stops the application upon entering or exiting the specified method or one of its implementations, allows you to check entry/exit conditions of method. This type of breakpoint may significantly slow down the debugging process, so be careful with it and use it only when you need it.

**_Exception breakpoint_**

Stops the application when `Throwable.class` or its subclasses were thrown.

**_Field watchpoint_**

Stops the application when the specified field is read or written to. This allows you to react to interactions with specific instance variables. For example, take a look at how property is initialized or what method changed its value.

To create the breakpoint use Ctrl + F8 shortcut. Depends where you do this, the different breakpoints will be created (Line, Method, or Field).  
To see the list of all breakpoints use Ctrl + Shift + F8.


This feature could save you hours. Thank this option you don’t need to search your breakpoints and manually remove them if they stop you code execution when you don’t want it. Also, it allows you just to disable the breakpoint. The disabled breakpoint will not stop your code during debugging, but when you need it, you can easily activate them again, so you don’t need to remember all crucial places in the project and every time create and remove breakpoints.  
Also, in this window, you can configure all your breakpoints:

### Suspend

Defines whether to stop the application execution when the breakpoint is reached. Has two possible values All/Thread. If **_all_** is chosen, all threads are suspended when any of the threads reach the breakpoint, If a **_thread_**, only the thread which hits the breakpoint is suspended.

### Condition

This option allows you to specify a condition that is checked every time the breakpoint is reached. If the condition returns a **_true_** value, the specified action is performed. If not, the breakpoint is skipped.

As a condition, you can use:

-   Multiple statements, including declarations, loops, anonymous classes, and so on
-   `this` (only in the nonstatic context), e.g `!(this instanceof User)`
-   Check boolean values or expressions

### Logging Options

When a breakpoint is reached, the following can be logged to the console:

-   **“Breakpoint hit” message**: a log message us `Breakpoint reached at package.User.main(User.java:10)`
-   **Stack trace**: the stack trace for the current frame. This is useful if you want to check what methods were called before reaching the breakpoint.
-   **Evaluate and log**: the result of an arbitrary expression, for example, `"Creating..."` or `users.size()`.

### Remove once hit

Defines whether the breakpoint should be removed from the project after it has been reached once.

### Disable until hitting the following breakpoint

Disables the current breakpoint until the specified breakpoint has been reached.  
You can also choose if the breakpoint should be disabled after this has happened or not.

### Filters

JetBrains IDE allows you to configure the breakpoint operation by filtering out classes/instances/methods and only stop the application where it’s needed.

The following types of filters are available:

-   **Catch class filters**: stop the application when the exception will be caught in the specified classes.
-   **Instance filters**: limit the breakpoint operation to specified object instances.
-   **Class filters**: limit the breakpoint operation to specified classes.
-   **Caller filters**: limit the breakpoint operation depending on the caller of the current method. Select this option if you need to stop at a breakpoint only when the method is called from a specified method.

### Field access/modification

-   **Field access:** Select this option to make the watchpoint work when the field is being read.
-   **Field modification:** Select to make the watchpoint work when the field is being written to.

### Pass count

Defines if the breakpoint should work only after it has been reached a specified number of times. This is convenient for debugging loops or recursive methods.

### Caught/uncaught exception

-   **Caught exception:** Select to make the breakpoint work when the specified exception was caught.
-   **Uncaught exception:** Select to make the breakpoint work when the specified exception was not caught. This allows you to figure out the cause of unhandled exceptions.

## Breakpoint best practices

> Use breakpoints to log debugging, do not use System.out.println

Use logging breakpoints instead of adding `System.out.print` in your code. This provides a more flexible way for your application logging and prevents you from dirty code and accidentally code changes in the git commits.

> Use shortcuts to add breakpoints, it will save you plenty of time

Using shortcuts it’s a good perspective for more productive development. Don’t forget about them.

> Organize group breakpoints

You can create a group of breakpoints, for example, if you need to mark out breakpoints for a particular problem. In the **Breakpoints** dialog (Ctrl+Shift+F8), select a breakpoint you want to add into a group, and select **Move to a group**.

> Figure out the root cause of fatal errors

Exception breakpoints work with `Throwable.class`. You can add a condition that will help you to stop code execution only when `Error.class` was thrown, or you can narrow down to `MyCustomException.class`.

> Don’t use method breakpoints when it isn’t necessary

Method breakpoints may significantly slow down the execution of your code, which could steal plenty of your time.

> Do not remove breakpoints completely

If you don’t need a particular breakpoint at the moment, do not remove it completely, you can just disable it. It could save a lot of time in the future when you need to test the same code block, you don’t need to search it in the huge project, you can just activate the same breakpoint once again.

> Add a description to the breakpoint

It could help you to understand why do you need this breakpoint, in a large number of breakpoints.

# Stepping through the program

_Stepping_ it’s the step-by-step execution of the program.

When code executing stops on your breakpoint you can move through code with different types of steps. You can see the panel of steps above.

![](https://miro.medium.com/v2/resize:fit:365/1*-4DOyCFpGsbIOjK2UI5ZFQ.png)

Let’s look at each of the steps in more detail.

### Step over(F8)

Steps over the current line of code and take you to the next line. The implementation of the methods is skipped, and you move to the next line of the current method.

### Step into(F7)

Steps inside the method to show code inside it. This option is convenient when you are not sure that the method returns the correct value.

### Step out(Shift + F8)

Steps out of the current method and takes you to the caller method.

### Run to cursor(Alt + F9)

Continues the execution of an application to the current cursor position.

### Force step over(Shift+Alt+F8)

Steps over the current line of code and take you to the next line. If there are breakpoints in the called methods, they are ignored.

### Drop frame

It allows you to undo the last frame and restore the previous frame in the stack. This can be convenient, for example, if you have accidentally stepped too far, or want to enter a function where you skipped a critical code block.

### Resume program(Ctrl + F9)

Resumes executions of your application to the next breakpoint.

# Debug tool window

When you start a debugging process, the **Debug** tool window appears. This window is used for controlling the debugging session, displaying and analyzing the program data, and performing various debug actions.

![](https://miro.medium.com/v2/resize:fit:875/1*O-C8x45U3iGexMXFiXutKA.png)

In this window, you can take a look at the created objects, properties, exceptions, values, etc. It’s convenient when you want to make sure that all properties initialized properly, what parameters method received, or to take a look at the exception stack trace.

# Step through the program best practices

> Use **Step Into** even for methods from the external libraries

Sometimes external libraries can have bugs too. Debugging of the external library could help you find the wrong code and report it to the developers of this library. Or the problem could be in another thing. If, for example, a method from the external library returns an unexpected value, step into it, to figure out the reason for this behavior, it could be because wrong equals/hashcode/etc objects method, or maybe some classes of this library was overridden in your project.

> Use **Show Execution Point**

If you have lost where your code execution stopped use **Show Execution Point (Alt + F10)** to move to the reached breakpoint.

> Take a look at the stack of calls

Sometimes the reason for unexpected behavior could be somewhere where you don’t have any breakpoints. Take a look at the stack of calls, to see what methods were executed, it could help you to find the wrong one. Also, if you navigate to another method through the stack of calls, you are able to see what parameters this method previously received.

# Expression evaluating

Also, IntelliJ IDEA allows you to evaluate expressions on the breakpoint. It’s a very convenient way to take a look at how the method behaves with other values.

To evaluate expression use **Alt + F8** or **Evaluate** button.

# Evaluating best practices

> Evaluate everything

If you need to test your method with different values, don’t create objects manually and restart the application, you can evaluate the method with these values, it could save you a lot of time, and also, you will see all properties of the returned object.

> The evaluator can execute everything

IntelliJ IDEA allows you to evaluate not only your local method but also different external or `java.*` methods. Evaluator even could even execute methods that send a request to another service, so you can take a look at the detailed response.

> Be careful with Streams

If you read you your stream once in the evaluator, the stream is considered as read, so it might cause errors if your application tries to read it once again.

Debbunging sometimes is an annoying and protracted, but indispensable, process for every developer. And IntelliJ IDEA provides features and options that make it more comfortable, easy, and productive. We can like or not debugging, but this is a thing that takes most of the development.

And in the end the most crucial practice

> Forget about **Run** button, use only **Debug** if you are a developer 😀

----
# Tips for Using IntelliJ Efficiently — Debugging Like a Pro

## Break on condition

A right click on an already placed breakpoint would open a pop-up window with a few options.

![](https://miro.medium.com/v2/resize:fit:529/1*pV0Jt1JQFMlEXo7GC67yFg.png)

One of the things I use most commonly is the `**Condition**` section, where you can put an expression evaluating to boolean using the variables i_n the scope of the line_ and the debugger would only break if the condition is _true_.

## Suspending single thread only

By default, in the pop up you’ll see the `**All**` radio button selected. However, if you choose the `**Thread**` one, you can suspend only the thread executing the line of code where the breakpoint is.

This is usually useful when you have threads, which, if suspended, might throw exceptions and die, like threads consuming from Kafka or querying a database with a timeout. Having only one thread stop might help you keep the app running and healthy while you examine the bit of code that might be problematic.

## Print debug statements… on steroids

Remember how I said print statements are not great. Well, I meant those ones you put in the code. They are not ideal because you need to restart the app every time you need to edit or add prints and, what’s worse, you might accidentally commit those and either expose sensitive information or just cause a lot of spam in the logs.

So, the alternative is…..drum roll.. print using the options IntelliJ provides.

![](https://miro.medium.com/v2/resize:fit:819/1*4Yt6_vH_dUnRNYzW7P7WTg.png)

In the default pop up, by default the **Suspend** checkbox is selected. If you deselect it, the window will expand revealing a whole lot more options. One of those is **Evaluate and log** which means that every time the debugger would normally suspend (no matter if it’s a normal breakpoint, with a condition, suspending one or all threads) it will print whatever the statement in that textbox evaluates to instead. It can either be a string literal or anything using the variables in the scope.

![](https://miro.medium.com/v2/resize:fit:875/1*DcEkHNudjO5YhijxkOsjIA.png)

# Exception breakpoint

Sometimes, though, you cannot pinpoint the exact line causing the problem. For example in multithreaded applications exceptions are being swallowed and appear as side effects somewhere else or you are not sure where the exception is thrown from due to lack of proper logging or you just need to approach the problem more generally. In those cases, you can add a breakpoint exception.

If you hit Ctrl + Shift + F8 | Cmd + Shift +F8 you’ll see this window listing all currently added breakpoints.

![](https://miro.medium.com/v2/resize:fit:875/1*V9FBxQYfR7UQC3ZBcnM1vw.png)

Additionally, you can either add a breakpoint for `**Any Exception**` for the current project’s language or a specific exception class.

Keep in mind that sometimes frameworks like Spring might have internal exceptions on startup so it’s a bit annoying to start up your app with that kind of exception and get suspended in places you are not interested in.

Also, as you can see in the right panel, those breakpoints also follow the same rules and provide the same options as the line ones.

# Debugger Pane

Once the execution is suspended there are few things in the `**Debugger**` pane I want to point out.

## Variables

This is the tab most familiar to people — besides hovering over variables in scope, you can review their values at the time in the `variables` pane.

![](https://miro.medium.com/v2/resize:fit:875/1*uzUI_tsS8M4n6GnsqQh2TQ.png)

## Frames

Slightly less familiar tab is the `frames` one.

![](https://miro.medium.com/v2/resize:fit:875/1*RKLI0_Hwg13k4T0LS5a3JQ.png)

The interesting bit here is not only that you see the stacktrace (what was the app’s path to this line of code) but also that you can actually **travel back in time.** You can click on the individual frames and review the values of the variables in that scope at the time the code went through it. Which is incredibly useful when tracking down unexpected values.

## Threads

The last tab here is the `Threads` one. It provides a way to check where all the other threads are (if they are also suspended) at that moment.

![](https://miro.medium.com/v2/resize:fit:875/1*myo3_ggH1UANRlZXQSOjew.png)

# Profiling

Sometimes, unfortunately, a breakpoint is not enough and you need to use some more serious tools. Mostly those are tools used to detect memory leaks and high CPU usage. The Profiler in IntelliJ provides a lot of the functionalities that previously we needed external tools for.

You can open the `Profiler` pane through the View Menu|Tool Windows|Profiler or it might already be visible somewhere in the left|bottom|right corners. If there is a Java process running it will appear there.

![](https://miro.medium.com/v2/resize:fit:875/1*2MZMPS-QCkQCyRTAIrfD6w.png)

The interesting bits are hidden in the context menu.

## CPU and Memory Live Charts

This will show you a timeline graph of the memory and CPU usage of the app while it’s running.

![](https://miro.medium.com/v2/resize:fit:875/1*WLdycox4javkTPK_XBfJ4w.png)

It can be very useful if you want to gauge where the app is at in terms of resource usage or detect any abnormal spikes or drops in either of those.

## Capture Memory Snapshot

A memory snap is a step further or a complimentary step to the live charts. You can see the actual objects and primitives filling up that memory and this might help you identify where a leak is coming from.

![](https://miro.medium.com/v2/resize:fit:875/1*eorjkVg9yz2ZRHwvlC6hIA.png)

The other 2 options I’ve used way less to be honest but will mention quickly

## Attaching profiler

Attaching a profiler or running the app with a profiler will give you a lot of information like a list of all methods executed while the profiler was running, all events that occured (such as GC, memory alloc etc) and more.

![](https://miro.medium.com/v2/resize:fit:875/1*J540hmjJ8H2ErL0JU5OTXg.png)

## Get Thread Dump

This will print the stacktrace for all threads in the app at that time.

![](https://miro.medium.com/v2/resize:fit:875/1*EQZ6cxHGCyxsWvvvzGnZug.png)

----


### 1. Evaluate Expression

-   **Shortcut**: `Alt + F8` (Windows/Linux), `⌥ + F8` (Mac)
-   Evaluate expressions during debugging without modifying your code

**Example**: Suppose you have this code:
```java
int a = 10;  
int b = 20;  
int sum = a + b;  
System.out.println(sum);
```
While debugging, you can evaluate expressions like `a * b` or `sum / 2` directly to test logic.

### 2. Watches

-   Add variables or expressions to the “Watches” list to monitor their values.

**How to use**:

1.  Right-click on a variable in the debugger.
2.  Select “Add to Watches.”

This feature helps you track the state of critical variables during execution.

### 3. Conditional Breakpoints

-   Pause execution only when a specific condition is met.

**Example**: Add a breakpoint in a loop and set a condition like `i > 5` to stop when the iteration reaches 6.

**Steps**:

1.  Right-click on the breakpoint.
2.  Add a condition such as `i == 10.`

### 4. Smart Step Into

-   **Shortcut**: `Shift + F7`
-   Select a specific method to step into when multiple methods are called on a single line.

**Example**:
```java
calculate(add(a, b), multiply(c, d));
```
You can choose to step into `add` or `multiply`.

### 5. Inline Debugging

-   See variable values inline with your code while debugging.

This feature helps you avoid constantly switching to the variables pane.

### 6. Force Return

-   Change the return value of a method during debugging.

**Steps**:

1.  Right-click on the frame in the debugger.
2.  Choose “Force Return” and specify the return value.

### 7. Log Breakpoints

-   Instead of stopping execution, log variable values or custom messages to the console.

**Example**: Log a message like `"Loop iteration: " + i` in a loop without pausing the program.

### 8. Drop Frame

-   Rewind execution to a previous method in the call stack.

**Steps**:

1.  Right-click on a frame in the Debug tool window.
2.  Select “Drop Frame.”

**Example**: Imagine debugging a recursive function. If you find an issue in an earlier recursive call, you can drop the frame to revisit it and re-execute the logic.

### 9. Reset Frame

-   Reset the execution of the current frame to its start.

**Steps**:

1.  Right-click on a frame in the call stack.
2.  Select “Reset Frame.”

**Example**: If a method’s logic needs to be re-executed from the start after altering variables, use this feature to debug effectively without restarting the entire program.

### 10. Debugging Threads

-   Monitor all running threads in the “Threads” tab.

Pause, resume, or inspect threads to debug multithreaded applications.

### 11. Attach to Process

-   Attach the debugger to a running process.

**Steps**:

1.  Go to `Run > Attach to Process.`
2.  Select the desired process.

### 12. Modify Variables at Runtime

-   Change variable values during runtime to test different scenarios.

**Steps**:

1.  Select a variable in the variables pane.
2.  Edit its value.

### 13. Debugging Lambda Expressions

-   Step through lambda expressions and anonymous classes.

**Example**:
```java
list.stream().filter(x -> x > 10).forEach(System.out::println);
```
Use “Smart Step Into” to focus on the `filter` logic.

### 14. Async Stacktraces

-   View asynchronous stack traces for better debugging of async code.

**Example**: Debug `CompletableFuture` or coroutines with complete context.

### 15. Throw Exception
-   Simulate exceptions to test error-handling logic during debugging.
**Steps**:
1.  Right-click in the variables pane or use the “Evaluate Expression” window.
2.  Manually throw an exception using syntax like `throw new IllegalArgumentException("Test Exception")`.

**Example**: Test a method’s exception handling without altering the actual code.

### 16. Memory View Plugin

-   Monitor heap memory usage and object counts.

**Steps**:

1.  Install the “Memory View” plugin.
2.  Use it during debugging to inspect memory usage.

### 17. Run to Cursor

-   Skip stepping through code and run directly to a selected line.

**Shortcut**: `Alt + F9` (Windows/Linux), `⌥ + F9` (Mac)

**Steps**:

1.  Right-click on the desired line.
2.  Select “Run to Cursor.”

---
# Remote Debugging with IntelliJ IDEA 

### **Introduction**

Remote debugging gives developers the ability to diagnose unique bugs on a server or another process. It provides the means to track down those annoying runtime bugs and identify performance bottlenecks and resource sinks.

In this article, we’ll take a look at remote debugging using JetBrains IntelliJ IDEA.

### Configure the JVM
```shell
-Xdebug -Xrunjdwp:transport=dt_socket,server=y,suspend=n,address=7800
```
In addition to the Java Debug Wire Protocol (JDWP) configuration, which includes jdwp=transport=dt_socket, there are several other parameters: server, suspend, and address.

The server parameter is used to configure the JVM as the debugger’s target. The suspend parameter instructs the JVM to wait for a debugger client to connect before starting up. Finally, the address parameter specifies a wildcard host and a declared port.

So, let’s build the application.
```shell
mvn clean install
```
And now let’s start the application.
```shell
java -jar -Xdebug -Xrunjdwp:transport=dt_socket,server=y,suspend=n,address=7800 com.task.api-1.0.3.jar
```
### Run Configuration in IntelliJ IDEA

Next, in IntelliJ, we create a new Run Configuration for remote debugging:

![](https://miro.medium.com/v2/resize:fit:875/1*iXwZJt_4JI0GClPAsbcK_A.png)

Now that our application is running, let’s start the remote debugging session by clicking the _Debug_ button.

Then debugger console of the IDE will show the below message.

![](https://miro.medium.com/v2/resize:fit:875/1*_ufcFnKkJhMFb-dQR9dMnA.png)

###### Add breakpoints in the code

You can add breakpoints in the code using the IDE by clicking the left side near the code segment that you want to debug as shown below.

![](https://miro.medium.com/v2/resize:fit:405/1*Ga2KrKAKCgv1d8NR6QkDvw.png)

###### Hitting breakpoints

When running the application if a particular breakpoint is hit then a message as on the following image will be displayed in the debugger console.
---
# Debugging the Undebuggable: Advanced Spring Boot Debugging Techniques
chniques and tools.

**Why Advanced Debugging Techniques Matter:**

1.  **Complex Architectures**: Microservices and reactive systems complicate root-cause analysis.
2.  **Real-Time Debugging**: Live debugging is essential for production-like environments.
3.  **Threading Issues**: Debugging deadlocks and thread contention requires specialized tools.

### 1. Debugging Reactive Spring Applications

Reactive programming, with its asynchronous and non-blocking nature, can be difficult to debug using traditional techniques.

### A. Using Debug Mode in Project Reactor

Spring WebFlux and Project Reactor include a `Hooks.onOperatorDebug()` mode, which provides stack traces for reactive streams.

**Enable Debugging for Reactive Streams:**
```java
import reactor.core.publisher.Hooks;  
  
public class App {  
    public static void main(String[] args) {  
        Hooks.onOperatorDebug();  
        SpringApplication.run(App.class, args);  
    }  
}
```
**Limitations:**

-   Adds overhead and is not suitable for production environments.
-   Better for debugging in local or staging environments.

### B. Step-Through Debugging with IntelliJ IDEA

Reactive streams complicate stepping through code using a debugger. To debug, use breakpoints and inspect the execution flow inside operators like `map`, `flatMap`, or `filter`.

**Example Debugging Workflow:**

1.  Set a breakpoint inside the lambda of an operator.
2.  Enable **“Async Stacktraces”** in IntelliJ to better navigate non-blocking flows.

### 2. Distributed Tracing with OpenTelemetry

In distributed systems, where requests span multiple services, debugging is particularly challenging. OpenTelemetry provides a unified approach to trace requests across systems.

### A. Setting Up OpenTelemetry in Spring Boot

1.  **Add Dependencies:**  
    Add OpenTelemetry SDK and Spring Boot instrumentation libraries:
```xml
<dependency>  
    <groupId>io.opentelemetry</groupId>  
    <artifactId>opentelemetry-api</artifactId>  
    <version>1.22.0</version>  
</dependency>  
<dependency>  
    <groupId>io.opentelemetry.instrumentation</groupId>  
    <artifactId>opentelemetry-spring-boot-starter</artifactId>  
    <version>1.22.0</version>  
</dependency>
```
2. **Configure Tracing:**  
Add OpenTelemetry exporters in `application.yml` to send traces to a backend like Jaeger or Zipkin:
```yml
otel:  
  traces:  
    exporter: otlp  
    service-name: spring-boot-app  
  resource:  
    attributes:  
      service.name: spring-boot-app
```
3. **Visualizing Traces:**  
View traces in the OpenTelemetry backend to identify bottlenecks or failures across services.

**Key Benefits of Distributed Tracing:**

-   Trace request flow across microservices.
-   Diagnose latency or errors in specific services or operations.

### 3. Live Debugging with BTrace

**BTrace** is a powerful Java agent that allows developers to trace live applications without modifying the source code or restarting the application.

### A. Setting Up BTrace

1.  Add the BTrace agent to the JVM startup command:
```shell
java -javaagent:/path/to/btrace-agent.jar -jar spring-boot-app.jar
```
2. Write a BTrace script to trace specific methods or classes.

**Example BTrace Script:**
```java
import com.sun.btrace.annotations.*;  
import static com.sun.btrace.BTraceUtils.*;  
  
@BTrace  
public class TraceController {  
    @OnMethod(  
        clazz = "com.example.controller.MyController",  
        method = "processRequest",  
        location = @Location(Kind.ENTRY)  
    )  
    public static void onMethodEntry(@Self Object self, String arg) {  
        println("Entering method: processRequest");  
        println("Argument: " + arg);  
    }  
}
```
3. Attach the script to the running application using the BTrace CLI:
```shell
btrace <PID> traceController.java
```
**Use Cases for BTrace:**

-   Debugging live production systems without downtime.
-   Monitoring specific method executions or variable states.

### 4. Troubleshooting Thread Deadlocks

Deadlocks occur when two or more threads are waiting for each other to release resources, causing the application to hang.

### A. Detect Deadlocks Using Thread Dumps

1.  Generate a thread dump:
```shell
jstack <PID>
```
2. Look for threads in the `BLOCKED` state and identify circular dependencies.

### B. Analyze Deadlocks with VisualVM

1.  Attach VisualVM to the running Spring Boot application.
2.  Navigate to the **Threads** tab to inspect thread states and identify deadlocks.

### C. Prevent Deadlocks with Timeouts

Use timeouts for thread synchronization to avoid indefinite waiting.

**Example with ReentrantLock:**
```java
ReentrantLock lock = new ReentrantLock();  
if (lock.tryLock(1, TimeUnit.SECONDS)) {  
    try {  
        // Critical section  
    } finally {  
        lock.unlock();  
    }  
} else {  
    System.out.println("Failed to acquire lock, avoiding deadlock.");  
}
```
### Best Practices for Advanced Debugging

1.  **Log Enrichment:** Include contextual information such as correlation IDs and thread names in logs.
2.  **Profiling Tools:** Use tools like JProfiler or YourKit for detailed insights into CPU and memory usage.
3.  **Asynchronous Call Monitoring:** Monitor thread pools in asynchronous systems to prevent starvation or thread leakage.

Debugging complex Spring Boot applications requires more than traditional tools and techniques. By leveraging advanced approaches like reactive stream debugging, distributed tracing with OpenTelemetry, live debugging with BTrace, and deadlock analysis, developers can gain deeper insights into application behavior and resolve critical issues more effectively.

With these tools and strategies, you’ll be better equipped to debug even the most challenging Spring Boot applications, improving reliability, performance, and maintainability.

1.  Reactive applications require specialized debugging techniques like `Hooks.onOperatorDebug()`.
2.  Distributed tracing with OpenTelemetry provides end-to-end visibility across services.
3.  Tools like BTrace enable live debugging without stopping the application.
4.  Prevent thread deadlocks with careful synchronization and timeouts.
