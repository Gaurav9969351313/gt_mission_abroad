# A Step-by-Step Guide to Docker Image Optimisation

### The Real Impact of Bloated Images

Image size directly affects how your applications behave in production. The difference between a 1GB image and a 50MB one can impact everything from startup time to infrastructure costs.

-   **Faster Deployments:** Smaller images move through CI/CD pipelines faster. When you’re shipping dozens of services daily, shaving a few minutes per deploy adds up quickly.
-   **Reduced Costs:** Lean images consume less storage. Teams have seen up to 60% savings on container registry costs after trimming image bloat.
-   **Better Security Posture:** Fewer packages mean fewer attack vectors. In one case, over two-thirds of flagged vulnerabilities were tied to unnecessary dependencies.

Docker image size directly impacts application startup time, which affects autoscaling, recovery time, and user experience.

### Our Sample Application

Let’s work with a typical Express application that represents the kind of Node.js microservice you might deploy in production:

It has essential dependencies like `express` for routing, `moment` for time formatting, `mongoose` for MongoDB interactions, and a couple of middlewares like `cors` and `helmet` to handle cross-origin requests and improve security. In a real-world microservice, you might also have logging, metrics, or authentication middleware, but for simplicity, we'll stick to the basics here.

First, initialise a new Node.js project:
```shell
mkdir docker-shrink  
cd docker-shrink  
npm init -y

### Install the dependencies:

npm install express moment mongoose cors helmet  
npm install --save-dev nodemon jest supertest
```

Now, create an index.js file:
```javascript
const express = require("express");  
const moment = require("moment");  
const cors = require("cors");  
const helmet = require("helmet");  
  
// Initialize express  
const app = express();  
const PORT = process.env.PORT || 3000;  
  
// Middleware  
app.use(cors());  
app.use(helmet());  
app.use(express.json());  
  
// Routes  
app.get("/", (req, res) => {  
  res.json({  
    message: "Hello from a slim Docker container!",  
    timestamp: moment().format("MMMM Do YYYY, h:mm:ss a"),  
    uptime: process.uptime(),  
  });  
});  
  
app.get("/health", (req, res) => {  
  res.json({ status: "UP", memory: process.memoryUsage() });  
});  
  
// Error handling middleware  
app.use((err, req, res, next) => {  
  console.error(err.stack);  
  res.status(500).json({ error: "Something went wrong!" });  
});  
  
// Start server  
if (process.env.NODE_ENV !== "test") {  
  app.listen(PORT, () => {  
    console.log("Server running on port ${PORT}");  
  });  
}  
  
module.exports = app; // For testing
```
Now let’s start dockerizing this application.

### Phase 1: The Standard Baseline Approach

Like most developers, I started with something like this, a straightforward `Dockerfile` copied from a tutorial or Stack Overflow post, using `node:latest` as the base image without a second thought.
```Dockerfile
FROM node:latest  
WORKDIR /app  
COPY package*.json ./  
RUN npm install  
COPY . .  
  
EXPOSE 3000  
CMD ["node", "index.js"]
```
Building this image:
```shell
docker build -t node-app:phase1 .  
docker images | grep node-app
```
![](https://miro.medium.com/v2/resize:fit:875/1*Rq3FhQujtQ-hX2A-HvydsA.png)

At **1.22 GB**, this image is enormous. My application code might be just a few megabytes, but the image contained an entire Linux distribution, the Node.js runtime, and numerous dependencies I didn’t need.

**Testing our baseline image**

Let’s make sure our application works before proceeding with optimisations:
```shell
docker run -d -p 3000:3000 node-app:phase1  
curl http://localhost:3000
```
![](https://miro.medium.com/v2/resize:fit:875/1*fxP9PGGZs1e-mf2HanRliw.png)

Great! Our application is working correctly. Now let’s start optimising.

### Phase 2: Choosing the Right Base Image

My first optimisation was switching to a slimmer base image, which immediately brought several benefits:

-   It eliminated unnecessary packages and utilities that weren’t needed at runtime.
-   It reduced the attack surface of the container.
-   It significantly improved build and pull times during deployments.

Here’s the updated Dockerfile:
```Dockerfile
FROM node:slim  
WORKDIR /app  
COPY package*.json ./  
RUN npm install  
  
COPY . .  
  
EXPOSE 3000  
CMD ["node", "index.js"]
```
Let’s measure:
```shell
docker build -t node-app:phase2 . -f Dockerfile.phase2  
docker images | grep node-app
```
![](https://miro.medium.com/v2/resize:fit:875/1*D4d6Xlog8X342i_l5aVT2A.png)

The image is reduced 345 MB, that is 71% reduction in size with a one-word change! The base image choice is the single most impactful decision for container size.

**Testing our slim image**

Let’s make sure the application still works with our slimmer image:
```shell
docker run -d -p 3000:3000 node-app:phase2  
curl http://localhost:3000
```
![](https://miro.medium.com/v2/resize:fit:875/1*ANi8dgL7rJYb3V2YJXhxNw.png)

Perfect! Our app still works the same, but with a significantly smaller image.

### Phase 3: Using Alpine Base Images

Next, we went even further with Alpine, a minimalistic Linux distribution known for its ultra-small footprint and security. Using Alpine not only slashes image size but also reduces the attack surface drastically.
```Dockerfile
FROM node:alpine  
WORKDIR /app  
COPY package*.json ./  
RUN npm install  
  
COPY . .  
  
EXPOSE 3000  
CMD ["node", "index.js"]
```
Let’s build and check the image size:
```shell
docker build -t node-app:phase3 . -f Dockerfile.phase3  
docker images | grep node-app
```
Now we’re at **258MB,** an impressive **78%** reduction from our starting point of **1.22 GB**.

**Testing our Alpine-based image**

Let’s verify our Alpine-based image works correctly:
```shell
docker run -d -p 3000:3000 node-app:phase3  
curl http://localhost:3000
```
![](https://miro.medium.com/v2/resize:fit:875/1*j0bzf4cCRPWOCvmRdH3PIg.png)

Alpine is so effective because it’s lean by design. It uses musl libc instead of glibc, BusyBox instead of GNU Core Utilities, and offers a much smaller package repository. The entire distribution weighs in at just 5 MB.

But I learned a tough lesson on a client project. We migrated to Alpine, everything ran fine in dev and test, but production started seeing random crashes. After digging in, we discovered the issue: a native dependency was behaving differently with musl libc compared to glibc.

Since then, I’ve made it a best practice to thoroughly validate Alpine build, especially when dealing with applications that rely on compiled native modules.

### Phase 4: Multi-Stage Builds and .dockerignore File

One powerful technique I’ve come to rely on is multi-stage builds, a method that allows you to separate the build environment from the runtime environment, reducing image size while keeping all the benefits of development-time tools.

With multi-stage builds, you can compile, test, or bundle your application using a full-featured Node image, and then copy only the essential artifacts into a clean, minimal runtime image, often based on Alpine. This approach not only trims unnecessary files and dev dependencies but also ensures your final container is lean, secure, and production-ready.

You can think of `.dockerignore` as the `.gitignore` for Docker builds. It enforces discipline in what gets packaged into the container and is one of the easiest ways to make builds cleaner and more secure.

Before building, it’s critical to add a `.dockerignore` file to exclude files and folders that shouldn't be copied into the image:
```shell
node_modules  
npm-debug.log  
tests  
coverage  
Dockerfile  
.dockerignore  
.env  
*.md
```
Here’s the Dockerfile with Multi-Stage Build
```Dockerfile
### Build stage  
FROM node:alpine AS builder  
  
WORKDIR /app  
  
COPY package*.json ./  
RUN npm ci --only=production  
  
COPY . .  
  
### Runtime stage  
FROM node:alpine  
  
WORKDIR /app  
  
COPY --from=builder /app/node_modules ./node_modules  
COPY --from=builder /app/package.json ./  
COPY --from=builder /app/*.js ./  
  
EXPOSE 3000  
CMD ["node", "index.js"]
```
Let’s build and check the image size:
```shell
docker build -t node-app:phase4 . -f Do4kerfile.phase4  
docker images | grep node-app
```
![](https://miro.medium.com/v2/resize:fit:875/1*CpDHsg9wfmddavb0zXQdPg.png)

###### Testing our multi-stage build

Let’s verify the application still functions correctly:

![](https://miro.medium.com/v2/resize:fit:875/1*n56jx-GGxr8WybngG8JjOw.png)

Everything is still working as expected!

We’ve now reached **178** **MB**, almost an **85%** reduction from our original size! Multi-stage builds keep build tools and intermediate files out of the final image. This approach lets you use one container to build your application and a different, smaller container to run it.

This pattern works particularly well for TypeScript projects. On a healthcare project, the TypeScript compilation and testing steps generated over 300MB of artifacts that would have been included in a single-stage build. Multi-stage builds kept only the compiled JavaScript in the final image.

### Phase 5: Going Distroless

Google’s [Distroless](https://github.com/GoogleContainerTools/distroless) images take minimalism to another level by stripping out even the operating system package manager and shell. These images include only the necessary runtime dependencies required for your app to run.

Here’s what makes them remarkable:

-   **No package manager** (e.g., `apk`, `apt`) Attackers can't install malware post-compromise.
-   **No shell,** which reduced attack surface (no `/bin/sh`).
-   **Immutable and minimal,** usually even smaller than Alpine-based images.
-   **Perfect for production** environments where reproducibility, size, and security are priorities.

Here’s what a Dockerfile might look like using
```Dockerfile
FROM node:22-alpine AS builder  
WORKDIR /app  
COPY package*.json ./  
RUN npm install --only=production  
COPY . .  
### Step 2: Use distroless image  
FROM gcr.io/distroless/nodejs22  
WORKDIR /app  
COPY --from=builder /app /app  
CMD ["index.js"]
```
Let’s build and check the image size:
```shell
docker build -t node-app:phase5 . -f Dockerfile.phase5  
docker images | grep node-app
```
![](https://miro.medium.com/v2/resize:fit:875/1*LH0y8plOiNb5FkIa7tXwMg.png)

###### Testing our distroless image

Let’s see if our application still works with the distroless image:

![](https://miro.medium.com/v2/resize:fit:875/1*Hlor5tbJvHt1cO9v4i8xrg.png)

If we try to access the container’s shell, we’ll find that there isn’t one:
```shell
docker exec -it <CONTAINER_ID> sh
```
![](https://miro.medium.com/v2/resize:fit:875/1*1ZaJlZnTzzx81gY5F9ceZA.png)

This is a security feature of distroless images, they contain no shell or utilities that could be exploited.

Distroless images contain only your application and its runtime dependencies. No package managers, no shells, no anything else. This doesn’t just save space — it dramatically improves security.

After going distroless, we reached **143MB,** an **88.2% reduction** compared to the original 1.22GB image. This is an incredible achievement considering we didn’t compromise on functionality or security.

### Phase 6: Static Binaries

For the ultimate in size optimisation, we will compile our Node.js app into a standalone binary. By using tools like `pkg` or `nexe`We bundled our entire application, including the Node.js runtime, into a single executable file. This not only reduces attack surface and dependency complexity but also enables us to run the app from scratch or distroless base images like`scratch`, achieving minimal image sizes often under **20MB**. This approach eliminates the need for a Node.js runtime, resulting in significantly smaller images and faster cold starts.

Here’s the Dockerfile
```Dockerfile
FROM node:alpine AS builder  
WORKDIR /app  
COPY package*.json ./  
RUN npm ci --only=production  
RUN npm install -g pkg  
  
COPY . .  
RUN pkg --targets node16-alpine-x64 index.js -o app  
  
### Minimal runtime  
FROM alpine:latest  
WORKDIR /app  
COPY --from=builder /app/app .  
  
EXPOSE 3000  
CMD ["./app"]
```
Let’s build and check the image size:
```shell
docker build --platform=linux/amd64 -t node-app:phase6 . -f Dockerfile.phase6  
docker run --platform=linux/amd64 -d -p 3000:3000 node-app:phase6
```
![](https://miro.medium.com/v2/resize:fit:875/1*-cD_oBI287PjJbW6kKgrPg.png)

A significantly reduced **57MB** final image, just **4.7%** of our original size! This is a massive improvement, stripping away unnecessary layers, packages, and dependencies.

> I Passed `--platform=linux/amd64` to ensure the binary runs on x86_64 architecture, avoiding compatibility issues on my ARM-based Mac.

###### Testing our static binary Image

Let’s test if our compiled application works:
```shell
docker run --platform=linux/amd64 -d -p 3000:3000 node-app:phase6  
curl http://localhost:3000
```
![](https://miro.medium.com/v2/resize:fit:875/1*GohPANf5cFgxXdLWbHWEMQ.png)

> This approach isn’t for everyone. Static compilation works well for simpler applications but can become problematic with complex dependencies. I once had a compiled app work fine in development but fail in production due to dynamic module loading patterns.

After containerising our Node.js app using various techniques, from basic base images to scratch, distroless, and even static binaries, we reached an impressively slim **57MB** final image.

### **Using Slim (Previously known as Dockerslim)**

When looking to streamline the optimisation workflow, I came across [**Slim**](https://github.com/slimtoolkit/slim), a powerful open-source tool that automates container image minification. It inspects your image, identifies what’s used at runtime, and removes everything else.

This not only drastically reduces image size, often by **30x or more,** but also improves security by eliminating unnecessary packages and reducing the attack surface. Even more impressive, it achieves this **without needing you to rewrite your Dockerfile or restructure your application code**.

###### How It Works

Slim runs your container in a sandboxed environment, traces system calls, and builds a new optimised image that includes only the essential runtime components. It also generates reports, security insights, and artifacts like:

-   A **minified image** (`slim.<original-image-name>`)
-   A **Seccomp profile** to harden your container
-   A **report directory** with details on files, packages, and network usage

###### Let’s Install and Use It

We’ll install Slim locally and use it to optimise our **Phase 1** Docker image (our original unoptimized Node.js app).

On macOS, the easiest way to install it is via Homebrew:
```shell
brew install docker-slim  
slim --version
```
Now, we’ll run the optimisation command on our `node-app:phase1` image:
```shell
slim build node-app:phase1  
docker images | grep slim
```
Slim reduced our **1.22GB** image to just **123MB** with one command!

![](https://miro.medium.com/v2/resize:fit:875/1*tH5xlVCEekvMLDbrY4Thpg.png)

###### Testing the Slim image

Let’s verify our Slim optimised container works:
```shell
docker run -d -p 3000:3000 node-app.slim  
curl http://localhost:3000
```
![](https://miro.medium.com/v2/resize:fit:875/1*7iIZD3W36f9bjkBWhknqoQ.png)

While Slim delivers impressive results, I’ve learned to use it with care. On one project, it stripped out files used only in rare error-handling paths, leading to elusive production failures that only appeared under specific conditions.

Slim isn’t a magic bullet. It works best when you understand your application’s runtime behaviour and can guide the optimisation process accordingly.

### Why Not Just Start with Slim?

After seeing Slim’s impressive results, you might wonder why bother with manual optimisation at all. I asked myself the same question when presenting this approach to my team.

Automated tools are excellent for optimisation, but they can’t replace understanding the fundamentals. There are several compelling reasons to learn manual optimisation first:

-   **Troubleshooting**: When Slim removes a critical file, understanding Docker optimisation principles helps you quickly diagnose and fix the issue, something automated tools can’t always handle.
-   **Control and Predictability**: Manual optimisation offers precise control over the image’s contents, ensuring only the necessary components remain, leading to more predictable builds.
-   **Security Validation**: Security teams require full visibility into container contents. Manually optimised images make it easier to document and validate what’s inside, ensuring compliance with security policies.
-   **Transferable Knowledge**: The principles of container optimisation apply across languages and frameworks, making manual optimisation a versatile skill for any project.
-   **Customisation and Flexibility**: Manual optimisation lets you tailor the image to your specific needs, whether it’s adjusting build pipelines or meeting storage constraints.
-   **Understanding the Build Process**: Manual optimisation offers a deeper understanding of how Docker layers interact and how to structure your Dockerfile for maximum efficiency.

### Potential Issues with Optimisations

While optimisations brought significant improvements, they came with certain challenges that need to be addressed:

-   **Alpine Compatibility Issues:** Native dependencies sometimes behave differently on Alpine, causing potential compatibility problems. Certain libraries or tools might not work as expected, requiring additional workarounds or adjustments to ensure compatibility.
-   **Debugging Difficulties:** Distroless containers, while minimal and efficient, can be harder to troubleshoot. With fewer tools available for debugging in the container, identifying and resolving issues can become more complex and time-consuming.
-   **Build Complexity:** Managing multi-stage builds added complexity to the Dockerfile. For some team members, understanding the flow of multi-stage builds and managing the different phases became a challenge, especially when trying to make sure the right layers are included and excluded.
-   **Team Adoption:** Encouraging the entire team to adopt and follow optimisation best practices took time and education. Not everyone was initially familiar with these practices, and getting full buy-in required some effort in training and continuous learning.

The key lesson is that optimisation isn’t one-size-fits-all. The right balance between size, functionality, and security depends on your specific application.

### Additional Optimisation Techniques

Some other techniques that have worked well for me:

1.  **Layer Optimisation**

Docker images consist of layers, and each instruction in your Dockerfile creates a new layer. Combining related commands reduces the number of layers and can significantly reduce image size.

**Bad Approach:**
```shell
RUN apt-get update  
RUN apt-get install -y package1  
RUN apt-get install -y package2
```
**Right Approach:**
```shell
RUN apt-get update &&   
    apt-get install -y package1 package2 &&   
    rm -rf /var/lib/apt/lists/*  
```
**2. Leverage BuildKit Cache Mounts**

For Node.js applications, npm caching can significantly speed up builds:

### syntax=docker/dockerfile:1.4
```Dockerfile  
FROM node:alpine  
WORKDIR /app  
  
COPY package*.json ./  
RUN --mount=type=cache,target=/root/.npm   
    npm ci --only=production  
  
COPY . .  
  
EXPOSE 3000  
CMD ["node", "index.js"]
```
This technique keeps the npm cache out of the final image while speeding up builds.

**3. Consider Alternative Tools**

In addition to manual tuning and automation with Slim, here are some powerful tools that can help you inspect, analyse, and further optimise your container images:

-   [**dive**](https://github.com/wagoodman/dive): A CLI tool to visually explore Docker image layers. It helps you understand what’s contributing to your image size and identify unnecessary files or inefficient layer ordering that cause bloat.
-   [**Docker Scout**](https://docs.docker.com/scout/): Docker’s official image analysis and security tool. It gives you insights into vulnerabilities, outdated dependencies, and size optimisations directly from your Docker image metadata and SBOM (Software Bill of Materials).
-   [**Buildpacks**](https://buildpacks.io/): A CNCF project that allows you to build container images from source code without needing a Dockerfile. Buildpacks enforce best practices and produce minimal, production-ready images tailored for your app’s runtime.

These tools are excellent companions to help you go beyond basic Dockerfile optimisations and gain deep insight into what’s inside your containers.

### Final Thoughts

The journey from 1.22GB to 57MB represents more than just saving disk space, it reflects a philosophy of efficiency, security, and engineering excellence.

The benefits of implementing these techniques compound over time. Smaller containers mean:

-   Faster deployments
-   Lower infrastructure costs
-   Improved security posture
-   Better resource utilisation
-   Quicker horizontal scaling

Remember that optimisation is a spectrum, not a binary goal. Even if you can’t implement every technique, each step provides benefits. **Even going from 1GB to 200MB is a huge win.**

Start with the techniques that make sense for your project and gradually implement more advanced optimisations as you become comfortable with them. The journey to container efficiency is iterative, but the rewards are well worth the effort.