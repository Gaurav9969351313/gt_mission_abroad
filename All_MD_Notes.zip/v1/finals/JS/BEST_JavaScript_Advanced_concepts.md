
# Bare-Minimum requirement for cracking the frontend interview (Internship)
Bare minimum (HTML) :

1.  HTML Semantic Elements
2.  Bind input field with a label
3.  Learn about commonly used tags: audio, video, script, head, body anchor, heading, span

Bare minimum (CSS)

1.  Pseudo-classes
2.  Ways of including CSS in HTML (Inline, external, using style tag)
3.  Types of selector
4.  Types of display
5.  Types of position
6.  CSS box model
7.  Padding vs Margin
8.  Flex and Flex-Box
9.  CSS grid

Bare minimum (Javascript):

1.  Promises
2.  Callbacks
3.  Closures
4.  Currying Functions
5.  ES7 or ES6 features
6.  Hoisting
7.  Object Destructing

# Prototype and Protypal Inheritance 
**What is Inheritance ?**

Inheritance in Object Oriented Programming language is a mechanism in which base class acquires all the properties and behaviors of the parent class. It is an important part of OOPs (Object Oriented programming system). The idea behind inheritance in Java is that you can create new classes that are built upon existing classes. When you inherit from an existing class, you can reuse methods and fields of the parent class.

In very simple words the class that inherits another class can use functions and variables of the inherited class. Rather creating the same methods repeatedly we can use the concept of inheritance.

**What is Inheritance in JavaScript ?**

Before knowing what is Inheritance in JavaScript read my article on [how everything is Object in JavaScrip](https://mevasanth.medium.com/how-everything-is-object-in-javascript-a4164d7e6a2d)t. It gives a base for what is __proto__ how it is bound to various programming constraints like Array, object etc in JavaScript.

So After reading that article you must have understood how JavaScript adds __proto__ object to different programming constraints.

Just for demo purpose attaching the same image used in my previous article.

![](https://miro.medium.com/v2/resize:fit:875/0*C1xw5xjul8gZS_rA.png)

As you notice here, we have just created an array and it has access to all the methods of array like map, join, concat etc. All these methods are added by JavaScript engine to the Array variable.

**So every array in JavaScript will get the same set of methods and properties attached to it. Now a light should on in your mind, every array getting same method means, all of them inherit properties from the _Array.Prototype, all function inherit properties from Function.Prototype_. _This is inheritance in JavaScript._**

**Whenever user creates a function, array, Object etc, in JavaScript it will get access to all the prototype methods or it inherits those methods. This is known as inheritance in JavaScript.**

Let me illustrate a quick example to understand it better.
```javascript
let userOneObject = {  
    name: "User 1",  
    city: "Singapore",  
    getTitle : function(){  
        console.log(this.name + " is from " + this.city )  
    }  
}
userOneObject.getTitle() // Output will be "User 1 is from Singapore"
```
As mentioned above the output of the above snippet will be

> User 1 is from Singapore

Now let us create another object as shown below.
```javascript
let userOneObject = {  
    name: "User 1",  
    city: "Singapore",  
    getTitle : function(){  
        console.log(this.name + " is from " + this.city )  
    }  
}let userTwoObject = {  
    name : "User2"  
}userTwoObject.getTitle()// we will get reference error as userTwoObject is not aware of getTitle method
```
The output of above code will be, reference error, userTwoObject is not aware of getTitle method

**Now let us make an interesting stuff, which you should never do in your day to day programming,**
```javascript
let userOneObject = {  
    name: "User 1",  
    city: "Singapore",  
    getTitle : function(){  
        console.log(this.name + " is from " + this.city )  
    }  
}let userTwoObject = {  
    name : "User2"  
}userTwoObject.__proto__ = userOneObject;userTwoObject.getTitle() // Output will be User2 is from Singapore
```
Can you guess the output now ? it will be

> User2 is from Singapore

Observe it carefully. In the output this.name has value **User2** but the city value is **Singapore**. That means, since userOneObject's proto is assigned to userTwoObject, now userTwoObject has access all methods of the userOneObject.

**The hierarchy would be, first the JavaScript engine look for the reference in the object's declared methods(Ex:** getTitle inside the object**) if it doesn't find it there, then it will search it in it's __proto__ object. If it doesn't find even there then it will look if __proto__ has any __proto__ object if there is, then it searches there and this process continues until it __proto__ is undefined.**

Does it sound like inheritance now ?

This is the same way how inheritance works in Java/C# or any other object oriented programming language. So, though JavaScript uses prototype for the purpose of inheritance, the final implementation is relatable with other programming language.

**Can we implement OOP inheritance the same way as Java in JavaScript ?**

Answer is yes. Though many doesn't use class keyword in JavaScript you should know that after ES6 one can create class in JavaScript using the **class** keyword. Below is the example snippet of same
```javascript
class BaseClass {  
    displayBaseClassName(){  
        console.log("This is Base class")  
    }  
}  
class DerivedClass extends BaseClass {  
    displayDerivedClassName(){  
        console.log("This is Derived class")  
    }  
}let derivedClassObj = new DerivedClass();  
derivedClassObj.displayBaseClassName(; //Output will be "This is Base class"
```
Here we have created two classes BaseClass and DerivedClass. And Derived class is inheriting from the BaseClass keyword **extend** is used for the purpose. Same way how you would use inheritance in Java you can use it in JavaScript with very minimum changes in creating object and functions.

Do not get confuse with the above code with Prototype inheritance. If your asked what is inheritance in JavaScript ? then they will be expecting Prototypal inheritance answer and not the second one. Good luck !!

---
# How everything is Object in JavaScript ?

![](https://miro.medium.com/v2/resize:fit:875/1*nMsqNFLgKiUc6cX1T8u_zg.png)

Observe the Image carefully, we just created an array named arr and in the next line if we type arr followed by a “.” then we are listed with set of functions which can be used with the arrays like map, concat, length etc.

Wait a minute, how did all came ? every JavaScript developer with basic knowledge is using array and it's methods everyday, but we have just created Array and how all these functions are made accessible to it ?

Answer is **Prototype: All JavaScript programming constraints inherit properties and methods from a prototype.** (A detailed article on prototype and prototypal inheritance is written by me in this [link](https://mevasanth.medium.com/prototype-and-protypal-inheritance-in-javascript-bb766097ac05))

whenever we create array, function, class etc, JavaScript takes the Prototype methods of it and creates and object named **__proto__** attaches it with object.

So if you try to log **arr.__proto__** output will look like below.

![](https://miro.medium.com/v2/resize:fit:875/1*yKotdDeaKz1-ZqFdXlBUxg.png)

Array was able to access methods like push, length, find etc because of this. What do we get if we try to print **Array.Prototype** ?

![](https://miro.medium.com/v2/resize:fit:875/1*9KzyMYMXmnzW8xWuiADNXg.png)

The output would be same as above. That means, any array that you create in JavaScript will inherit values from **Array.prototype**.

This is fine, but where we got explanation for everything is Object in JavaScript ? Below is explanation for same.

If you observer carefully in above two screenshots the last parameter is __proto__. In first image we logged arr.__proto__ which has a __proto__ property within it. Let's try logging the value of it.

![](https://miro.medium.com/v2/resize:fit:875/1*_N7hF4u_ypVx4mjjSrt0xw.png)

Observe the constructor here, it is an object, that means Array's prototype was derived from the **Object's prototype**. What will be objects's prototype then ? that is **a.__proto__.__proto__.__proto__**

the answer would be null. This is why everything is object in JavaScript. All the programming constraints like function, class, Arrays are derived from the Object's Prototype.

Just to elucidate further consider below example with functions.

![](https://miro.medium.com/v2/resize:fit:875/1*QzDKkCCGrqWDlSUOMQwr0g.png)

Even functions are derived from Object prototype this applies to all programming constraints of the JavaScript. Hope this clears most basic question, why everything is object is JavaScript.


---
# Hoisting in JavaScript : Hot topic for Interview 

Unlike strongly typed languages like Java, C, C++ sometimes JavasScript doesn't behave the way we expect it to be. Consider below example

console.log(“colour is”, colour);var colour;

The usual expectation here would be **Reference error** as we are trying to access a variable before it is being defined. But the actual output is

colour is undefined

You would be wondering how is this possible ? before explaining that consider below code snippet with slight modification.

console.log(“colour is”, colour);let colour;

Because of above explanation one would expect output should be **colour is** **undefined,** here as well. But the output would be **reference error,** if we use the **const** instead of **let** we will get runtime error. Same variable, because of the declaring process, how the answer is getting altered ?

### **Hoisting**

**“Hoisting is JavaScript's default behavior of moving declarations to the top.”** One can relate it with flag hosting, where flag will be hoisted to the top of the pole.

**In simple words in JavaScript all the variables that are declared with let, var or const will hoisted or declared at the top of the block during the compilation.** Only for those variables created with **var** keyword the default value will be set to **undefined**. So after compilation above code looks like below.
```javascript
var color = undefined; // _this is just indicatory_  
console.log(“colour is”, colour);  
var colour;let colour; // **Since there is no default value we will get reference error (**_this line is just indicatory_**)**  
console.log(“colour is”, colour);  
let colour;**// Here we get run time error, because when you declare a variable with const it must have a default value. We cannot create a const variable without initial value.**  
console.log(“colour is”, colour);  
const colour;//**Even in this case we get run time error as we are trying to access const variable before it is defined.** console.log(“colour is”, colour);  
const colour = "red";
```

Note: **Important thing to observe** here is JavaScript compiler doesn't just hoist variables declared with **var** keyword, **it will hoist variables created with let and const also**. Just Because the variables are not initialised with default value we get **reference error in case of let** and **runtime error in case of const**.

A snippets for practice

```javascript
var rate = 10
function getRate() {  
    if (rate == undefined) {      
        var rate = 6;      
        return rate;   
    } else {      
        return 10;   
        }
}
console.log("Rate is", getRate());
```

**Most of you think output as _Rate is 10_; But answer would be Rate is 6.** Because in the **getRate** function inside if condition, there is a variable named **rate** declared with **var** keyword. During compilation the rate variable will be hoisted to the top of the **getRate()** method with default value as undefined. So during runtime the **rate == undefined will be set to true and** value returned will be 6.

### **How to avoid above scenarios ?**

If your in an interview and you cracked above puzzle, next question interviewer will ask you is, how to resolve this problem. Simplest way to solve is use **let** instead of **var** inside the function.

```javascript
var rate = 10
function getRate() {
    if (rate == undefined) {let rate = 6;return rate;} else {return 10;}
}
console.log("Rate is", getRate());
```

---
# Concept of Event Bubbling and Trickling/Capturing in JavaScript — Common interview question

Say you have a basic HTML page where 3 div's are nested and there is a click event associated with each div, (Refer example code below)

```javascript
<html><body>  
<div id="GrandParent" onClick="grandParentFunction()">      <h1>Grand Parent</h1>   
     <div id="Parent" onClick="parentFunction()">             <h1> Parent</h1>  
             <div id="child" onClick="childFunction()">              <h1> Child</h1>  
            </div>  
      </div>  
</div><script src="./index.js" />  
</body>  
<html>
```

```javascript
// index.js contents

document.getElementById("GrandParent").addEventListener('click', () => {console.log("Grand Parent clicked")})
document.getElementById("Parent").addEventListener('click', () => {console.log("Parent clicked")})
document.getElementById("Child").addEventListener('click', () => {console.log("child clicked")})
```

Before reading further guess what will the output when you click on the child div ?

Whenever you click on the child div, internally you're also clicking the Parent and GrandParent div (as they are nested). So when you click on the child div, click events of Parent and Child will also be triggered. So the output will be
```javascript
Child clicked  
Parent clicked  
Grand Parent clicked
```
Now in the same way guess what will be the output if Parent div is clicked ?

The output will be,

Parent clicked  
Grand Parent clicked

Observe this output carefully, “child clicked” statement is not logged when you click on the Parent div. The reason is straight forward, when we click on Parent div, your not clicking on the block where child is present.

Similarly the output when you click on GrandParent div will be

Grand Parent clicked

If you observe the pattern how events are propagated, I,E when you click on child div, first click event associated with child is triggered and later with the parent and finally the grand parent. **Can you relate it to water bubbles that come out of a glass when you blow air into it. This process is called as event bubbling. You can also understand it as bottom up approach.**

What if you wanted the events to propogate in other way ? I,E when you click child div, first grand parent event triggered and then parent and lastly child event. The reverse of the above process, it is called **event trickling or Capturing**. Before demonstrating how to achieve it, you must ask a question to yourself **why there is a possibility of event trickling and capturing ?**

Earlier bubbling was only way to propagate events, for certain functionalities developers wanted event trickling, so browsers rather restricting users to a particular approach they gave a freedom to use both. By default most browsers, events are propagated in event bubbling fashion. addEventListener function takes second argument where we can specify events to bubble or trickle.
```javascript
document.getElementById("GrandParent").addEventListener('click', () => {console.log("Grand Parent clicked")}, false)
document.getElementById("Parent").addEventListener('click', () => {console.log("Parent clicked")}, false)
document.getElementById("Child").addEventListener('click', () => {console.log("child clicked")}, false)
```

As you can see in the above code snippet, if you set the value to false, events will bubble from bottom to top, which is default behaviour which was saw at first. **So if you do not specify the second parameter then it is considered as false.**

**Event Trickling**

In Above example consider the same HTML and modify the JavaScript as shown below.

```javascript
document.getElementById("GrandParent").addEventListener('click', () => {console.log("Grand Parent clicked")}, true)
document.getElementById("Parent").addEventListener('click', () => {console.log("Parent clicked")}, true)
document.getElementById("Child").addEventListener('click', () => {console.log("child clicked")}, true)
```

By setting the second argument to addEventListener method as true we are asking JavaScript browser to trickle the event. In this case if you click on the child div the output will be as shown below.

```javascript
Grand Parent clicked  
Parent clicked  
Child clicked
```
And if you click on the Parent Div then the output will be,
```javascript
Grand Parent clicked   
Parent clicked
```
And lastly if you click on the grand parent div then output remains the same,

```javascript
Grand Parent clicked
```
If you have understood the concept well, now try answering below question, what will be the output if you click on the child div.
```javascript
document.getElementById("GrandParent").addEventListener('click', () => {console.log("Grand Parent clicked")}, false)
document.getElementById("Parent").addEventListener('click', () => {console.log("Parent clicked")}, true)
document.getElementById("Child").addEventListener('click', () => {console.log("child clicked")}, false)
```
I know it is little confusing the answer will be,

```javascript
Parent clicked  
Child clicked  
Grand Parent clicked
```
That means priority is given for trickling and once all the events with trickling are triggered then bubbling events will get started. Try to nest more div's and play with true and false argument to understand it better.

**Last question the interviewer will ask would be how to stop event propagation ?**

Click event has an argument called event, we can use that to stop propagating the event.

```javascript
document.getElementById("GrandParent").addEventListener('click', () => {console.log("Grand Parent clicked")}, false)
document.getElementById("Parent").addEventListener('click', () => {console.log("Parent clicked")}, false)
document.getElementById("Child").addEventListener('click', (e) => {e.stopPropagationconsole.log("child clicked")}, false)
```
Now if you click the child the output would be just,

```javascript
Child clicked
```
Event will not propagate further from that point. This can be added at any level, and from there, event will not be propagated.

---
### When and Why to Use : Debounce vs Throttle in JavaScript
When it comes to handling high-frequency events in JavaScript — like scrolling, resizing, keypresses, or mouse movements — developers often encounter performance bottlenecks. Functions attached to these events can fire hundreds of times within seconds, potentially causing the browser to lag or crash, especially if the associated logic is computationally expensive.

![](https://miro.medium.com/v2/resize:fit:875/1*ExADocAkylH3hFk2gRACTg.png)
Source : Internet( ChatGPT )

> [**If Not a Member READ FROM HERE**](/when-and-why-to-use-debounce-vs-throttle-in-javascript-d51a452b7b6e?sk=cf3009660451fa4792751d02e2cf934c)

To address this, two powerful techniques are commonly used: **debouncing** and **throttling**. While they seem similar at first glance, their purposes and implementations differ significantly. Understanding when and why to use each can lead to better-performing, more efficient web applications.

### What is Debouncing?

Debouncing is a technique used to group a series of sequential calls to a function into a single call that only executes after a specified delay. If the event continues to fire before the delay ends, the timer resets. In essence, a debounced function will only run **after** the event stops firing for the defined period.

### How It Works

Imagine you're typing in a search bar that auto-suggests results from a server. Every keystroke fires an input event, potentially triggering a network request. Debouncing ensures that the request only goes out after you've paused typing for a certain amount of time, say 300 milliseconds.

### Real-World Use Case
```javascript
function debounce(func, delay) {  
  let timer;  
  return function (...args) {  
    clearTimeout(timer);  
    timer = setTimeout(() => func.apply(this, args), delay);  
  };  
}  
const handleInput = debounce(() => {  
  console.log('Fetching suggestions...');  
}, 300);  
document.getElementById('search').addEventListener('input', handleInput);
```
Here, `handleInput` is called **only after** the user has stopped typing for 300ms. This reduces unnecessary calls to the server, improving both performance and user experience.

### What is Throttling?

Throttling, on the other hand, ensures that a function is called at most once in a specified time interval. It limits the execution rate of the function, allowing it to run every X milliseconds, regardless of how frequently the event occurs.

### How It Works

Consider a scenario where you're implementing infinite scroll. You want to load more content as the user scrolls down, but continuously firing the scroll event can quickly become a problem. Throttling can limit how often the load function is triggered — say, once every 500ms.

### Real-World Use Case
```javascript
function throttle(func, limit) {  
  let lastFunc;  
  let lastRan;  
  return function (...args) {  
    const context = this;  
    if (!lastRan) {  
      func.apply(context, args);  
      lastRan = Date.now();  
    } else {  
      clearTimeout(lastFunc);  
      lastFunc = setTimeout(function () {  
        if ((Date.now() - lastRan) >= limit) {  
          func.apply(context, args);  
          lastRan = Date.now();  
        }  
      }, limit - (Date.now() - lastRan));  
    }  
  };  
}  
const handleScroll = throttle(() => {  
  console.log('Fetching more content...');  
}, 500);  
window.addEventListener('scroll', handleScroll);
```
This way, the function runs **at most once every 500ms**, regardless of how frequently the scroll event is fired.

### **Key Differences**

![](https://miro.medium.com/v2/resize:fit:875/1*Qpv_b5KiPnPDQTiKbw42kQ.png)
Source : Internet

### When to Use Debounce

Use **debounce** when:

-   You want to **delay** execution until the event has stopped firing.
-   Frequent triggers are not helpful unless they stop, such as:
-   Auto-saving form data when the user stops typing.
-   Validating email addresses during registration.
-   Adjusting UI layout on window resize, but only after resizing ends.

> Debounce is excellent for reducing noise in user input scenarios, improving UX by avoiding flickers or redundant network calls.

### When to Use Throttle

Use **throttle** when:

-   You need to **control the rate** of function execution.
-   The function is **resource-intensive**, but needs to run frequently:
-   Lazy-loading content on scroll.
-   Tracking mouse movement to draw on canvas.
-   Capturing real-time analytics at a steady pace.

> Throttle ensures your app remains responsive without overwhelming the browser or server.

### Common Mistakes and Pitfalls

1.  **Using debounce when throttle is needed (and vice versa):**  
    For example, throttling a search input will delay user feedback unnecessarily. Similarly, debouncing scroll can cause functions to miss important intermediate states.
2.  **Too short or too long delay intervals:**  
    A debounce delay that's too long may result in laggy UIs; too short, and it defeats the purpose. The same goes for throttle — test different intervals for your specific use case.
3.  **Context (**`**this**`**) loss in custom implementations:**  
    Make sure the original function's context is preserved using `.apply()` or `.call()` inside your throttle or debounce function.

### Third-Party Libraries

While writing your own debounce or throttle functions is educational, in production code, you might want to use trusted utilities like:

-   **Lodash**:  
    `_.debounce(func, wait)` and `_.throttle(func, wait)` are widely used, battle-tested, and well-documented.
-   **Underscore.js**:  
    Similar to Lodash, it provides both methods with slightly different internal implementations.

These libraries take care of edge cases and offer additional options like `leading` and `trailing` executions for more fine-tuned control.

### Conclusion

Both debounce and throttle are indispensable tools in a JavaScript developer's toolkit. They help improve performance, prevent unnecessary resource usage, and enhance user experience when dealing with rapid-fire events.

-   Use **debounce** when you want to wait until the flurry of events ends.
-   Use **throttle** when you want to allow the event handler to run at regular intervals, no matter how often the event fires.
---
# 🔥 JavaScript Array Immutable Methods You Didn't Know 

JavaScript has long embraced the concept of functional programming, and the emphasis on immutability is growing stronger. Immutability, in a nutshell, refers to the practice of not changing the contents of an object (like an array) after it has been created. This offers numerous advantages:

-   **Predictability:** Immutable data reduces unexpected side effects and makes your code easier to reason about.
-   **Error Reduction:** Modifying data indirectly lessens the chances of introducing bugs or unintended state changes.
-   **Concurrent Code:** Immutability unlocks new potential for building thread-safe, concurrent applications.

Traditionally, to modify arrays in JavaScript without affecting the original, you often create copies using the spread operator (`…`), `slice()`, or other library functions. These approaches, while valid, might introduce performance considerations, especially for larger arrays. Recent JavaScript specifications (ECMAScript 2023) have introduced exciting new array methods designed to make working with arrays in an immutable way easier and more performant:

### `Array.prototype.with()`

The `with()` method lets you perform a non-destructive update on an array. It creates a new array where a specific element has been replaced with a new value. Let's examine some use cases:
```javascript
const numbers = [1, 2, 3, 4];  
  
// Change the value at index 1 to 10  
const updatedNumbers = numbers.with(1, 10);   
  
console.log(numbers);        // Output: [1, 2, 3, 4] (original remains unchanged)  
console.log(updatedNumbers); // Output: [1, 10, 3, 4]

### **Using** `with()` **in Objects**

You can effectively employ `with()` to update properties within objects stored in an array:

const people = [  
    { name: "Alice", age: 25 },  
    { name: "Bob", age: 30 }  
];  
  
// Update the age of the person at index 0  
const updatedPeople = people.with(0, { name: "Alice", age: 26 });  
  
console.log(people);         // Original remains unchanged  
console.log(updatedPeople);  // Alice's age is updated
```
### **The Other New Methods**

-   `Array.prototype.toReversed()`**:**

As the name suggests, this method creates a new reversed copy of the original array.
```javascript
const numbers = [1, 2, 3];  
const reversedNumbers = numbers.toReversed(); // [3, 2, 1]
```
-   `Array.prototype.toSorted()`**:**

Returns a new, sorted array. The default sorting is based on Unicode code points, and an optional compare function can be provided for customization.
```javascript
const words = ["banana", "apple", "cherry"];  
const sortedWords = words.toSorted(); // ["apple", "banana", "cherry"]
```
-   `Array.prototype.toSpliced()`**:**

A versatile method for modifying arrays – add items, remove them, or do both at once. Its unique feature is that it also returns an array containing the elements removed during the splice operation.
```javascript
const numbers = [1, 2, 3, 4];  
const [removed, updatedNumbers] = numbers.toSpliced(1, 2, "A", "B");   
// removed: [2, 3]  
// updatedNumbers: [1, "A", "B", 4]
```
### **Browser Support**

Since these methods are relatively recent, not all browsers might offer full support. It's wise to consult resources like Can I Use ([https://caniuse.com/](https://caniuse.com/)) for the latest compatibility details. Here's a general picture:

-   `with()`**:** Supported in most modern browsers (Chrome, Edge, Firefox, Safari)
-   `toReversed()`**,** `toSorted()`**,** `toSpliced()`**:** Similar support levels as `with()`.

### **Polyfills to the Rescue**

For scenarios where you need to extend support to older browsers, polyfills provide a way to “fill in” the missing functionality. The core-js library ([https://github.com/zloirock/core-js](https://github.com/zloirock/core-js)) is a well-known provider of polyfills for many standard JavaScript features, including the new array methods.

### **The Power of Immutability**

Adopting these new immutable array methods in JavaScript brings valuable benefits to your code, making it more predictable, easier to debug, and potentially enhancing performance, unlocking doors to efficient concurrent programming patterns.
