### 10 Lesser-Known Utility Functions for Senior Developers 

As a senior developer I have found it is hard to prepare for the live coding interviews and while searching on Google or ChatGPT not able to find the comprehensive list which covers every utility functions in JavaScript so Here I am creating the utility functions list which can help junior to senior developers.

### 1. Remove Duplicates from an Array

-   **Arrays**: These are some handy methods that we can use to remove duplicates from an array.

1.  **Using lodash**
```javascript
let array = [2, 1, 2, 5, 6, 7, 8, 9, 9, 10];  
let arrayuniq = _.uniq(array);//[2, 1, 5, 6, 7, 8, 9, 10]
```
2. **Using the filter**
```javascript
let array = [2, 1, 2, 5, 6, 7, 8, 9, 9, 10];  
let list = array.filter((x, i, a) => a.indexOf(x) == i);  
//[2, 1, 5, 6, 7, 8, 9, 10]
```
3. **Using Set**
```javascript
let array = [2, 1, 2, 5, 6, 7, 8, 9, 9, 10];  
let setuniq = [...new Set(array)];  
//[2, 1, 5, 6, 7, 8, 9, 10]
```

### 2. Remove Duplicates from Array of Objects

-   **Arrays of Objects:** These are some handy methods that we can use to remove duplicates from an array of objects.

1.  **Using lodash**
```javascript
let users = [{ id: 1, name: "ted" },{ id: 1, name: "bob" },{ id: 3, name: "sara" },{ id: 4, name: "test" },{ id: 4, name: "test" },{ id: 5, name: "abc" }];  
  
let uniqueUsersByID = _.uniqBy(users, "id");  
  
//[{"id":1,"name":"ted"},{"id":3,"name":"sara"},{"id":4,"name":"test"},{"id":5,"name":"abc"}]
```
_We can check unique data with multiple properties with this code._
```javascript
const uniquewithMultipleProperties = _.uniqWith(  
    users,  
    (a, b) => a.id === b.id || a.name === b.name  
);  
//[{"id":1,"name":"ted"},{"id":3,"name":"sara"},{"id":4,"name":"test"},{"id":5,"name":"abc"}]
```
2. **Using a filter**
```javascript
let filteruniquebyID = users.filter(  
    (v, i, a) => a.findIndex(t => t.id === v.id) === i  
);  
//[{"id":1,"name":"ted"},{"id":3,"name":"sara"},{"id":4,"name":"test"},{"id":5,"name":"abc"}]
```

_We can check unique data with multiple properties with this code._
```javascript
let filteruniquebyIDName = users.filter(  
    (v, i, a) => a.findIndex(t => t.id === v.id || t.name === v.name) === i  
);  
//[{"id":1,"name":"ted"},{"id":3,"name":"sara"},{"id":4,"name":"test"},{"id":5,"name":"abc"}]
```
3. **Using Set**
```javascript
var set1 = Array.from(users.reduce((m, t) => m.set(t.id, t), new Map()).values());  

//[{"id":1,"name":"bob"},{"id":3,"name":"sara"},{"id":4,"name":"test"},{"id":5,"name":"abc"}]
```
You can check out the StackBlitz here.

[https://stackblitz.com/edit/remove-duplicates-arrayofobjects](https://stackblitz.com/edit/remove-duplicates-arrayofobjects)

### 3. Find an item in Array

-   Below are some methods to find an item in the array

1.  **includes:** this method determines whether an array includes a certain value among its entries, returning `true` or `false` as appropriate.

console.log(array.includes(2)); // returns true

2. **every:** this method tests whether all elements in the array pass the test implemented by the provided function. It returns a Boolean value.
```javascript
let testevery1 = array.every(val=> val>3); //false
```
3. **some:** this method tests whether at least one element in the array passes the test implemented by the provided function. It returns a Boolean value.
```javascript
let testsome1 = array.some(val=> val>3); //true
```

4. **lodash includes:** checks if `value` is in `collection` .Returns `true` if `value` is found, else `false`.
```javascript
let lodashtest9 =_.includes(array, 1); // true

let lodashtest10 =_.includes(array, 3, 2); // false
```
5. **findIndex:** this method returns the **index** of the first element in the array **that satisfies the provided testing function**. Otherwise, it returns `-1`, indicating that no element passed the test.
```javascript
let  testindex = array.findIndex(val => val > 1);  
//0
```
6. **find:** this method returns the value of the first element in the provided array that satisfies the provided testing function. If no values satisfy the testing function, `[undefined](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined)` are returned.
```javascript
let testfind = array.find(el => (el > 2));  
//5
```
**7. filter:** this method **creates a new array** with all elements that pass the test implemented by the provided function.
```javascript
let testfilter1 = array.filter(val=> val>3);  
//[5, 6, 7, 8, 9, 9, 10]
```
8. **map:** this method **creates a new array** populated with the results of calling a provided function on every element in the calling array.
```javascript
let val = [];  
array.map(item => { if(item >= 3) val.push(item); });  
//[5, 6, 7, 8, 9, 9, 10]
```
You can check out the StackBlitz here.

[https://stackblitz.com/edit/find-item-array](https://stackblitz.com/edit/find-item-array)

### 4. Find an item in the Array of Objects

-   These are the methods that can be used to find an item in the array of objects.

1. **every:** this method tests whether all elements in the array pass the test implemented by the provided function. It returns a Boolean value.
```javascript
let testevery2 = users.every(val=> val.id>3);  
//false
```
2. **some:** this method tests whether at least one element in the array passes the test implemented by the provided function. It returns a Boolean value.
```javascript
let testsome2 = users.some(val=> val.id>3); //true
```
3. **lodash includes:** checks if `value` is in `collection` .Returns `true` if `value` is found, else `false`.
```javascript
let lodashtest11 =_.includes({ 'a': 1, 'b': 2 }, 1);  
//true  
let lodashtest12 =_.includes('abcd', 'bc');  
//true
```
4. **findIndex:** this method returns the **index** of the first element in the array **that satisfies the provided testing function**. Otherwise, it returns `-1`, indicating that no element passed the test.
```javascript
let  testindex2 = users.findIndex(val => val.id > 1);  
//3
```

5. **find:** this method returns the value of the first element in the provided array that satisfies the provided testing function. If no values satisfy the testing function, `[undefined](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined)` are returned.
```javascript
let testfind2 = users.find(el => (el.id > 2));  
//{"id":3,"name":"sara"}
```

**6. filter:** this method **creates a new array** with all elements that pass the test implemented by the provided function.
```javascript
let testfilter2 = users.filter(val=> val.id>3);
```

7. **map:** this method **creates a new array** populated with the results of calling a provided function on every element in the calling array.
```javascript
let val2 = [];  
users.map(item => { if(item.id >= 3) val2.push(item); });
```

You can check out the StackBlitz here.

[https://stackblitz.com/edit/find-item-array](https://stackblitz.com/edit/find-item-array)

### 5. Sort Array items

Arrays can be sort using the sort method.

The `**sort()**` method sorts the elements of an array [_in place_](https://en.wikipedia.org/wiki/In-place_algorithm) and returns the sorted array. The default sort order is ascending, built upon converting the elements into strings, then comparing their sequences of UTF-16 code unit values.
```javascript
const months = ['March', 'Jan', 'Feb', 'Dec'];  
months.sort();  
console.log(months);  
// expected output: Array ["Dec", "Feb", "Jan", "March"]  
  
const array1 = [1, 30, 4, 21, 100000];  
array1.sort();  
console.log(array1);  
// expected output: Array [1, 100000, 21, 30, 4]
```

### 6. Sort Array Of Objects with specific properties

-   These are the methods that can be used to sort an array of objects using specific properties from objects.

**1. Simple Sort:** this method sorts the elements of an array [_in place_](https://en.wikipedia.org/wiki/In-place_algorithm) and returns the sorted array.
```javascript
let data = [{  
        id: "3",  
        city: "toronto",  
        state: "TR",  
        zip: "75201",  
        price: "123451"  
    },  
    {  
        id: "1",  
        city: "anand",  
        state: "AN",  
        zip: "94210",  
        price: "345678"  
    },  
    {  
        id: "5",  
        city: "sudbury",  
        state: "SB",  
        zip: "00110",  
        price: "789045"  
    }  
];

let sorttest2 = data.sort((a, b) => (a.id < b.id ? -1 : Number(a.id > b.id)));console.log("sort test 2 ", sorttest2);

//output  
{  
    "id": "1",  
    "city": "anand",  
    "state": "AN",  
    "zip": "94210",  
    "price": "345678"  
}, {  
    "id": "3",  
    "city": "toronto",  
    "state": "TR",  
    "zip": "75201",  
    "price": "123451"  
}, {  
    "id": "5",  
    "city": "sudbury",  
    "state": "SB",  
    "zip": "00110",  
    "price": "789045"  
}]
```

**2. localCompare:** this method returns a number indicating whether a reference string comes before, or after, or is the same as the given string in sort order.
```javascript
let sorttest2 = data.sort((a, b) => (a.id < b.id ? -1 : Number(a.id > b.id)));

//output  
[{  
    "id": "1",  
    "city": "anand",  
    "state": "AN",  
    "zip": "94210",  
    "price": "345678"  
}, {  
    "id": "3",  
    "city": "toronto",  
    "state": "TR",  
    "zip": "75201",  
    "price": "123451"  
}, {  
    "id": "5",  
    "city": "sudbury",  
    "state": "SB",  
    "zip": "00110",  
    "price": "789045"  
}]
```
**3. Sort with multiple fields**

The `**parseInt()**` function parses a string argument and returns an integer of the specified [radix](https://en.wikipedia.org/wiki/Radix) (the base in mathematical numeral systems).
```javascript
let sorttest4 = data.sort(function(left, right) {  
    var city_order = left.city.localeCompare(right.city);  
    var price_order = parseInt(left.price) - parseInt(right.price);  
    return city_order || -price_order;  
});

//output  
[{  
    "id": "1",  
    "city": "anand",  
    "state": "AN",  
    "zip": "94210",  
    "price": "345678"  
}, {  
    "id": "5",  
    "city": "sudbury",  
    "state": "SB",  
    "zip": "00110",  
    "price": "789045"  
}, {  
    "id": "3",  
    "city": "toronto",  
    "state": "TR",  
    "zip": "75201",  
    "price": "123451"  
}]
```

**4. Lodash _sortBy:** Creates an array of elements, sorted in ascending order by the results of running each element in a collection thru each iterate.
```javascript
let sorttest6 = _.sortBy(data, ["id", "city"]);  
//output  
[{  
    "id": "1",  
    "city": "anand",  
    "state": "AN",  
    "zip": "94210",  
    "price": "345678"  
}, {  
    "id": "3",  
    "city": "toronto",  
    "state": "TR",  
    "zip": "75201",  
    "price": "123451"  
}, {  
    "id": "5",  
    "city": "sudbury",  
    "state": "SB",  
    "zip": "00110",  
    "price": "789045"  
}]
```

### 7. Sort Array of Dates

**1. Using Sort**
```javascript
let isDescending = false; //set to true for Descending  
let dates = ["1/7/2021", "1/6/2021", "8/18/2020", "8/6/2020"];  
let sorteddates = dates.sort((a, b) => isDescending ? new Date(b).getTime() - new Date(a).getTime() : new Date(a).getTime() - new Date(b).getTime());  
console.log(sorteddates);  
//["8/6/2020", "8/18/2020", "1/6/2021", "1/7/2021"]
```

**2. Using Lodash**
```javascript
let arr = [{  
        name: "test1",  
        date: "1/7/2021"  
    },  
    {  
        name: "test2",  
        date: "1/6/2021"  
    },  
    {  
        name: "test3",  
        date: "1/5/2020"  
    }  
];  
arr = _.sortBy(arr, function(dateObj) {  
    return new Date(dateObj.date);  
});  
console.log("sort date", arr);  
//[{"name":"test3","date":"1/5/2020"},{"name":"test2","date":"1/6/2021"},{"name":"test1","date":"1/7/2021"}]
```

**3. Using Lodash (sort by month and year)**
```javascript
let  yearAndMonth  =  [  
    { "year": 2016, "month": "FEBRUARY" },  
    { "year": 2015, "month": "MARCH" },  
    { "year": 2021, "month": "JANUARY" },  
    { "year": 2021, "month": "FEBRUARY" }  
]  
  
let value= _.sortBy(yearAndMonth, a => new Date(1 + a.month + a.year));  
console.log('Sorted Result: ', value);  
//[{"year":2015,"month":"MARCH"},{"year":2016,"month":"FEBRUARY"},{"year":2021,"month":"JANUARY"},{"year":2021,"month":"FEBRUARY"}]
```
You can check out the StackBlitz here.

[https://stackblitz.com/edit/sort-array](https://stackblitz.com/edit/sort-array)

### 8. Remove an item from an Array

**1. pop:** this method removes the **last** element from an array and returns that element. This method changes the length of the array.
```javascript
let arraypoptest = [2, 1, 2, 5, 6, 7, 8, 9, 9, 10];
let testpop = arraypoptest.pop();  
console.log("array pop", testpop,"-", arraypoptest);  
//10 - [2, 1, 2, 5, 6, 7, 8, 9, 9];
```
**2. shift:** this method removes the **first** element from an array and returns that removed element. This method changes the length of the array.
```javascript
let arrayshifttest = [2, 1, 2, 5, 6, 7, 8, 9, 9, 10];  
let testshift = arrayshifttest.shift();  
console.log("array shift", testshift,"-", arrayshifttest);  
//2 - [1, 2, 5, 6, 7, 8, 9, 9, 10]
```

**3. slice:** this method returns a shallow copy of a portion of an array into a new array object selected from `start` to `end` (`end` not included) where `start` and `end` represent the index of items in that array. The original array will not be modified.
```javascript
let arrayslicetest = [2, 1, 2, 5, 6, 7, 8, 9, 9, 10];  
let testslice = arrayslicetest.slice(0, 3);  
console.log("array slice", testslice, arrayslicetest);   
//not changed original array  
//[2, 1, 2] - [2, 1, 2, 5, 6, 7, 8, 9, 9, 10]
```

**4. splice:** this method changes the contents of an array by removing or replacing existing elements and/or adding new elements [in place](https://en.wikipedia.org/wiki/In-place_algorithm).
```javascript
let arraysplicetest = [2, 1, 2, 5, 6, 7, 8, 9, 9, 10];  
let testsplice = arrayslicetest.splice(0, 3);  
//[2, 1, 2]
```

**5. filter:** this method **creates a new array** with all elements that pass the test implemented by the provided function.

**arrays:**
```javascript
let testarr = [2, 1, 2, 5, 6, 7, 8, 9, 9, 10];  
let testarr2 = [2, 1, 2, 5, 6, 7, 8, 9, 9, 10];  
let filtered = testarr.filter(function(value, index, arr) {  
    return value > 5;  
});  
let filtered2 = testarr2.filter(item => item !== 2);  
console.log("filter example 1", filtered);  
//[6, 7, 8, 9, 9, 10]  
console.log("filter example 2", filtered2);  
//[1, 5, 6, 7, 8, 9, 9, 10]
```

-   **filter with multiple values removal:**
```javascript
let forDeletion = [2, 3, 5];  
let mularr = [1, 2, 3, 4, 5, 3];  
mularr = mularr.filter(item => !forDeletion.includes(item));  
console.log("multiple value deletion with filter", mularr);  
//[1, 4]
```

**6. delete operator:** The JavaScript `**delete**` removes a property from an object; if no more references to the same property are held, it is eventually released automatically.
```javascript
let ar = [2, 1, 2, 5, 6, 7, 8, 9, 9, 10];  
delete ar[4]; // delete element with index 4  
console.log(ar);  
//[2, 1, 2, 5, undefined, 7, 8, 9, 9, 10]
```

**7. lodash remove:** `_remove` removes all elements from `array` that `predicate` returns truthy for and returns an array of the removed elements.
```javascript
let arrlodashtest = [2, 1, 2, 5, 6, 7, 8, 9, 9, 10];  
let evens = _.remove(arrlodashtest, function(n) {  
    return n % 2 == 0;  
});  
console.log("lodash remove array", arrlodashtest);  
//[1, 5, 7, 9, 9]
```

### 9. Remove an item from the Array of Objects

**1. pop:** this method removes the **last** element from an array and returns that element. This method changes the length of the array.
```javascript
let users1 = [{  
    id: 1,  
    name: "ted"  
}, {  
    id: 2,  
    name: "mike"  
}, {  
    id: 3,  
    name: "bob"  
}, {  
    id: 4,  
    name: "sara"  
}];  
let testpop1 = users1.pop();  
  
console.log(  
    "array of objects pop",  
    JSON.stringify(testpop1),"-"  
    JSON.stringify(users1)  
);  
//{"id":4,"name":"sara"} - [{"id":1,"name":"ted"},{"id":2,"name":"mike"},{"id":3,"name":"bob"}]
```

**2. shift:** this method removes the **first** element from an array and returns that removed element. This method changes the length of the array.
```javascript
let users2 = [{ id: 1, name: "ted" },{ id: 2, name: "mike" },{ id: 3, name: "bob" },{ id: 4, name: "sara" }];  
  
let testshift1 = users2.shift();  
  
console.log("array of objects shift", JSON.stringify(testshift1),"-", JSON.stringify(users2));  
//{"id":1,"name":"ted"} - [{"id":2,"name":"mike"},{"id":3,"name":"bob"},{"id":4,"name":"sara"}]
```

**3. slice:** this method returns a shallow copy of a portion of an array into a new array object selected from `start` to `end` (`end` not included) where `start` and `end` represent the index of items in that array. The original array will not be modified.
```javascript
let users3 = [{ id: 1, name: "ted" },{ id: 2, name: "mike" },{ id: 3, name: "bob" },{ id: 4, name: "sara" }];  
  
let testslice1 = users3.slice(0, 3);  
  
console.log("array of objects slice", JSON.stringify(testslice1));  
//not changed original array  
//[{"id":1,"name":"ted"},{"id":2,"name":"mike"},{"id":3,"name":"bob"}]
```

**4. splice:** this method changes the contents of an array by removing or replacing existing elements and/or adding new elements [in place](https://en.wikipedia.org/wiki/In-place_algorithm).
```javascript
let users4 = [  
{ id: 1, name: "ted" },{ id: 2, name: "mike" },{ id: 3, name: "bob" },{ id: 4, name: "sara" }  
];  
let testspice1 = users3.splice(0, 3);  
  
console.log("array of objects splice", JSON.stringify(testsplice));  
//[{"id":1,"name":"ted"},{"id":2,"name":"mike"},{"id":3,"name":"bob"}]
```

**5. filter:** this method **creates a new array** with all elements that pass the test implemented by the provided function.
```javascript
let users7 = [{ id: 1, name: "ted" },{ id: 2, name: "mike" },{ id: 3, name: "bob" },{ id: 4, name: "sara" }];  
  
let filterObj = users7.filter(item => item.id !== 2);  
  
console.log("filter example array of objects", filterObj);  
  
//[{"id":1,"name":"ted"},{"id":3,"name":"bob"},{"id":4,"name":"sara"}]
```

**6. lodash remove:** `_remove` removes all elements from `array` that `predicate` returns truthy for and returns an array of the removed elements.
```javascript
let users8 = [  
{ id: 1, name: "ted" },{ id: 2, name: "mike" },{ id: 3, name: "bob" },{ id: 4, name: "sara" }];  
  
let evensObj = _.remove(users8, function(n) {  
    return n.id % 2 == 0;  
});  

console.log("lodash remove array of object", JSON.stringify(evensObj));  
  
//[{"id":2,"name":"mike"},{"id":4,"name":"sara"}]
```

### 10. Find Number of Characters From Given String in Array

**1. String match method**

The `**match()**` method retrieves the result of matching a _string_ against a [regular expression](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Regular_Expressions). (source: [MDN](https://developer.mozilla.org/en-US/docs/Web/JavaScript/))
```javascript
const test1 = ("atit patel".match(/a/g)||[]).length  
console.log(test1); //2
```

**2. String split method**

The `**split()**` method divides a `[String](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String)` into an ordered list of substrings, puts these substrings into an array, and returns the array.
```javascript
const test2 ="atit patel".split("a").length-1  
console.log(test2); //2
```

**3. indexOf method**

The `**indexOf()**` method returns the index within the calling `[String](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String)` object of the first occurrence of the specified value, starting the search at `fromIndex`. Returns `-1` if the value is not found.
```javascript
let  stringsearch = "a" ,str = "atit patel";  
  
for(var count=-1,index=-2; index != -1; count++,index=str.indexOf(stringsearch,index+1) );  
console.log(count); //2
```

**4. filter method**

The `**filter()**` method **creates a new array** with all elements that pass the test implemented by the provided function.
```javascript
const mainStr = 'atit patel';  
const test3 = [...mainStr].filter(l => l === 'a').length;  
console.log(test3); //2
```

**5. reduce method**

The `**reduce()**` method executes a **reducer** function (that you provide) on each element of the array, resulting in a single output value.
```javascript
const mainStr1 = 'atit patel';  
const test4 = [...mainStr1].reduce((a, c) => c === 'a' ? ++a : a, 0);  
console.log(test4); //2
```

# 10 Lesser-Known Utility Functions for Senior Developers

### 11. Find Number of Occurrences of each Character From Given String in Array

**1. We can add reduce method which we can return object after iterations**
```javascript
let s = 'atit patel';  
  
let test5 = [...s].reduce((a, e) => { a[e] = a[e] ? a[e] + 1 : 1; return a }, {});  
  
console.log(test5); //{a: 2,e: 1,i: 1,l: 1,p: 1,t: 3}
```
**2. It is the same as method 6 with having OR operator**
```javascript
let test6 = [...s].reduce((res, char) => (res[char] = (res[char] || 0) + 1, res), {})  
  
console.log(test6);//{a: 2,e: 1,i: 1,l: 1,p: 1,t: 3}
```
You can play with the StackBlitz here.

[https://stackblitz.com/edit/numberofoccurance-string](https://stackblitz.com/edit/numberofoccurance-string)

### 12. Rename Object Properties in Array of Objects

**1. Using Map:** this method **creates a new array** populated with the results of calling a provided function on every element in the calling array.
```javascript
let countries = [{ id: 1, name: "india" },{ id: 2, name: "canada" },{ id: 3, name: "america" }];  
  
const transformed = countries.map(({ id, name }) => ({  
label: id,value: name}));  
  
console.log("1", JSON.stringify(transformed));
// [{"label":1,"value":"india"},{"label":2,"value":"canada"},{"label":3,"value":"america"}]
```
**2. Using a map with arguments**
```javascript
const transformed2 = countries.map(({ id: label, name: value }) => ({label,value}));  
console.log("2", JSON.stringify(transformed2));  
  
[{"label":1,"value":"india"},{"label":2,"value":"canada"},{"label":3,"value":"america"}]
```
**3. Using lodash:** `_.mapKeys`method creates an object with the same values as `object` and keys generated by running each own enumerable string keyed property of `object` thru `iteratee`.
```javascript
const test1= _.mapKeys({ a: 1, b: 2 }, function(value, key) {  
return key + value;  
});  
  
console.log("3",test1);  
//{a1: 1, b2: 2}
```

What if we want to rename Object keys? Let's check out the solution for that.

**4. Using lodash for objects for values**
```javascript
var users = {  
'atit':    { 'user': 'atit',    'age': 40 },  
'mahesh': { 'user': 'mahesh', 'age': 15 }  
};  
  
const test2 = _.mapValues(users, function(o) { return o.age; });  
  
console.log("4",test2);  
//{atit: 40, mahesh: 15}  
  
//shorthand  
  
const test3 =_.mapValues(users, 'age');  
  
console.log("5",test3);  
//{atit: 40, mahesh: 15}
```

**5. Using Object destructuring:** The **destructuring assignment** syntax is a JavaScript expression that makes it possible to unpack values from arrays, or properties from objects, into distinct variables.
```javascript
const rename = (({id: a_b_c, ...rest}) => ({a_b_c, ...rest}))  
  
console.log(rename({id: 1, val: 2}))  
//{a_b_c: 1, val: 2}
```

### 13. How to merge two arrays and create a new array?

This can be achieved simply by using the spread operator.
```javascript
var arr1 = ['a', 'b', 'c']  
var arr2 = ['d', 'e']  
  
var merged = [...arr1, ...arr2]  
  
console.log(merged)
```

### 14. A sum of an array of numbers

1.  **reduce** can be used to iterate through the array, adding the current element value to the sum of the previous element values.
```javascript
console.log(  
  [1, 2, 3, 4].reduce((a, b) => a + b, 0)  
)  
console.log(  
  [].reduce((a, b) => a + b, 0)  
)//10
```

**2. Using Lodash**
```javascript
array = [1, 2, 3, 4];  
sum = _.sum(array); // sum == 10
```

> Let's check some of the complex scenarios which can be helpful in Coding Assessments

### 15. Compare two arrays of objects, remove duplicates, merge objects based on property

We do get a requirement to compare two different arrays of objects and want to merge both objects if they match specific property values. It can be achieved using the filter method.

The `**filter()**` method **creates a new array** with all elements that pass the test implemented by the provided function. (source: [MDN](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/filter))

_Let's create test data._
```javascript
let array1 = [{ id: "50", active: "a", value: 10 },{ id: "51", active: "a", value: 11 }];  
let array2 = [{ id: "53", active: "a", value: 10 },{ id: "51", active: "a", value: 11 },{ id: "52", active: "a", value: 13 }];
```

_Let's create functions._
```javascript
let res = array2.filter(val =>  
    array1.some(({  
        value  
    }) => (val.value as any) === (value as any))  
);  
  
console.log("1", JSON.stringify(res));  
//[{"id":"53","active":"a","value":10},{"id":"51","active":"a","value":11}]
```

### 16. Compare two arrays of objects, merge and update values (assuming array 3,4 shares same ID)

We do get requirements sometimes to merge the two different with new property values. We can create a new set of arrays of objects using the map and we can use the find method to match the specific property before updating the new value.

The `**map()**` method **creates a new array** populated with the results of calling a provided function on every element in the calling array.

The `find()` method returns the value of the first element in the provided array that satisfies the provided testing function. If no values satisfy the testing function, `[undefined](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/undefined)` are returned. (source: [MDN](https://developer.mozilla.org/en-US/docs/Web/JavaScript/))

_Let's create the test data._
```javascript
let array3 = [{ id: "50", active: "a", value: 12 },{ id: "51", active: "a", value: 15 }];  
  
let array4 = [{ id: "50", active: "a", value: 10 },{ id: "51", active: "a", value: 11 },{ id: "52", active: "a", value: 13 }];
```

_Let's create functions._
```javascript
let arr = [];  
array3.map(id =>  
    arr.push({  
        id: id.id,  
        newValue: array4.find(o => o.id === id.id).value + 2  
    })  
);  
console.log("2", JSON.stringify(arr));  
//[{"id":"50","newValue":12},{"id":"51","newValue":13}]
```

### 17. Compare arrays of objects and find unique objects

If we want to compare two arrays of objects and check which are the unique objects from them, we can use a filter to achieve these functions.

_Let's create test data._
```javascript
const array5 = [{ id: "50", active: "a", value: 12 },{ id: "51", active: "a", value: 15 }];  
  
const array6 = [{ id: "50", active: "a", value: 12 },{ id: "51", active: "a", value: 15 },{ id: "52", active: "a", value: 13 }];
```

_Let's create functions_
```javascript
const ids = array5.map(e => e.id);  
let filtered = array6.filter(e => ids.includes(e.id));  
console.log("3", JSON.stringify(filtered));  
//[{"id":"50","active":"a","value":12},{"id":"51","active":"a","value":15}]
```

### 18. Compare and update property based on matched values

When we want to compare two arrays of objects and update the specific property based on the matched values we can use these functions.

_Let's create test data_
```javascript
const array7 = [{ id: "50", active: "a", value: 12 },{ id: "51", active: "a", value: 15 }];  
const array8 = [{ id: "50", active: "a", value: 12 }];
```

_Let's create functions_
```javascript
const idSet = new Set(array8.map(o => o.id));  
const res1 = array7.map(o => ({ ...o, value: idSet.has(o.id) ? "0" : o.value }));  
  
console.log("4", JSON.stringify(res1));  
//[{"id":"50","active":"a","value":"0"},{"id":"51","active":"a","value":15}]
```

### 19. Compare two arrays objects and get the differences

When we want to compare two different arrays of objects and get are differences between them we can use these functions.

_Let's create test data_
```javascript
let a = [  
{ id: "50", active: "a", value: 10 },{ id: "51", active: "a", value: 11 }];

let b = [{ id: "50", active: "a", value: 10 },{ id: "51", active: "a", value: 11 },{ id: "52", active: "a", value: 13 }];
```

_Let's create functions_
```javascript
let valuesArray1 = a.reduce(function(a, c) {  
    a[c.value] = c.value;  
    return a;  
}, {});  
let valuesArray2 = b.reduce(function(a, c) {  
    a[c.value] = c.value;  
    return a;  
}, {});  
var result = a  
    .filter(function(c) {  
        return !valuesArray2[c.value];  
    })  
    .concat(  
        b.filter(function(c) {  
            return !valuesArray1[c.value];  
        })  
    );  
console.log("5", result);  
//[{"id":"52","active":"a","value":13}]

//shorthand

let ab = b.filter(o => !a.find(o2 => o.id === o2.id));  
console.log("6", ab);
```

### 20. Compare two arrays of objects merge and remove duplicates

If we get requirements to compare two arrays of objects and remove the duplicates from them and merge both the arrays we can use this method.

_Let's create test data_
```javascript
let arr1 = [{ id: "50", active: "a", value: 10 },{ id: "51", active: "a", value: 11 }];  
  
let arr2 = [{ id: "50", active: "a", value: 10 },{ id: "51", active: "a", value: 11 },{ id: "52", active: "a", value: 13 }];
```

_Let's create functions_
```javascript
const arr1IDs = new Set(arr1.map(({ id }) => id));  
const combined = [...arr1, ...arr2.filter(({ id }) => !arr1IDs.has(id))];  
  
console.log(JSON.stringify(combined));  
//[{"id":"50","active":"a","value":10},{"id":"51","active":"a","value":11},{"id":"52","active":"a","value":13}]
```

-   **Using lodash**

Lodash supports `_differenceBy` and `_differenceWith` methods to find the difference between two arrays.
```javascript
let lodashtest1 = [{ id: "50" }, { id: "51" }];  
let lodashtest2 = [{ id: "50" }, { id: "51" }, { id: "52" }];  
let lodashresult = _.differenceBy(lodashtest2, lodashtest1, "id");  
  
console.log("7", JSON.stringify(lodashresult));  
//[{"id":"52"}]  
  
let dif = _.differenceWith(lodashtest2, lodashtest1, _.isEqual);  
  
console.log("8",JSON.stringify(dif));  
//[{"id":"52"}]
```

### 21. Compare objects and find unique values

When we do work with nested objects sometimes it is difficult to figure out how we can iterate and compare both nested objects and get some unique objects among them. We can use `Object.keys` and `Object.values` methods for the iterations.

_Let's create test data_
```javascript
let obj1 = {val1: "test",stream: { prop1: false, prop2: true }};  
  
let obj2 = {val1: "test",stream: { prop1: true, prop2: true }};  
  
interface Data {  
  
stream: { [key: string]: boolean };  
  
}
```

_Let's create functions:_
```javascript
function objFilter(objA: Data, objB: Data): Data {  
  
let out: Data = { stream: {} };  
  
Object.keys(objA.stream).filter((value, idx) =>  
  
    Object.values(objA.stream)[idx] === Object.values(objB.stream)[idx]
    ? (out.stream[value] = Object.values(objA.stream)[idx])
    : false);  
    return out;  
} 
console.log(JSON.stringify(objFilter(obj1, obj2))); //prop2  
//{"stream":{"prop2":true}}
```
If you would like to play with the StackBlitz, you can find it here: [https://stackblitz.com/edit/compare-objects-javascript](https://stackblitz.com/edit/compare-objects-javascript)

### 22. How to Handle Multiple Service Calls Inside a Loop

**1. If we don't want to wait for all the service calls to finish**
```javascript
let data = [{ id: 0 }, { id: 1 }, { id: 2 }, { id: 3 }];

async function getDetails(values) {  
    for (const data of values) {  
        const result = await axios.get(  
            `serviceURL/${data.id}`  
        );  
        const newData = result.data;  
        this.updateDetails(newData);  
        console.log(this.response);  
    }  
}

function updateDetails(data) {  
    this.response.push(data);  
}  
  
getDetails(data); //call service to get data
```

**2. If we want to wait until all service calls done**

We can use `promise.all` to wait until all promises have been resolved.

The `**Promise.all()**` the method takes an iterable of promises as an input and returns a single `[Promise](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise)` that resolves to an array of the results of the input promises. (source: [MDN](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/async_function))
```javascript
let data = [{ id: 0 }, { id: 1 }, { id: 2 }, { id: 3 }];

async function getDetails(values) {  
    const dataPromises = values.map(entry => {  
        return axios.get(  
            `serviceURL/${entry.id}`  
        );  
    });  
  
const resultData = await Promise.all(dataPromises);  
  
  
resultData.forEach((res: any) => {  
        this.updateDetails(res.data);  
    });  
    console.log(this.response);  
}  
  
function updateDetails(data) {  
    this.response.push(data);  
}  
  
getDetails(data); //call service to get data
```
# Top Optimization Techniques in JavaScript you should know in 2021 
# 1. If Shorthand

Have you got bored by using a lot of If statements? Let's check some option which can help here
```javascript
//longhand
if (fruit === 'apple' || fruit === 'banana' || fruit === 'orange' || fruit ==='mango') {  
    //logic  
}
//shorthand
 if (['apple', 'banana', 'orange', 'mango'].includes(fruit)) {  
   //logic  
}
```

# 2. If… else Shorthand

This one can help when we have if-else statements. (make sure you have max 2–3 if.. else as it will make less code readable )
```javascript
// Longhand  
let mychoice: boolean;if (money > 100) {  
    mychoice= true;  
} else {  
    mychoice= false;  
}
// Shorthand  
let mychoice= (money > 10) ? true : false;//or we can use directly  
let mychoice= money > 10;console.log(mychoice);
```
nested conditions look like this
```javascript
let salary = 300,  
checking = (salary > 100) ? 'greater 100' : (x < 50) ? 'less 50' : 'between 50 and 100';
.log(checking); // "greater than 100"
```

# 3. Variable declarations

when we have the same type of variables we can avoid writing two times.
```javascript
//Longhand   
let data1;  
let data2= 1;
//Shorthand   
let data1, data2= 1;
```

# 4. Checking not null values

What if we want to check the variable is not null? We can now get rid of writing all conditions again.
```javascript
// Longhand  
if (data1 !== null || data1!== undefined || data1 !== '') {  
    let data2 = data1;  
}
// Shorthand  
let data2 = data1 || '';
```
# 5. Assigning default values
```javascript
let data1 = null, data2 = test1 || '';
    console.log("null check", data2); // output will be ""
```

# 6. Undefined Value checks
```javascript
let data1 = undefined, data2 = data1 || '';
console.log("undefined check", data2); // output will be ""
```

Normal Value checks
```javascript
let data1 = 'data',data2 = data1 || '';
console.log(data); // output: 'data'
```

(Note: we can also use `??` operator for topic 4,5 and 6)

# 7. Nullish Operator

This operator returns the right-hand side value if the left-hand side is null or undefined.
```javascript
const data= null ?? 'data';  
console.log(data);  
// expected output: "data"const data1 = 1 ?? 4;  
console.log(data1);  
// expected output: 1
```
# 8. Assigning values
```javascript
//Longhand   
let data1, data2, data3;  
data1 = 1;  
data2 = 2;  
data3 = 3;//
// Shorthand   
let [data1, data2, data3] = [1, 2, 3];
```
# 9. Assignment Operators

It is mostly used when we are dealing with the arithmetic operators, personally, I like longhand here as it is more readable.
```javascript
// Longhand  
data1 = data1 + 1;  
data2 = data2 - 1;  
data3 = data3 * 30;// Shorthand  
data1++;  
data2--;  
data3 *= 30;
```
# 10. Null checks

One of the most used operands but make sure your values fall true, nonempty strings, defined values, and not null values.
```javascript
// Longhand  
if (data1 === true) or if (data1 !== "") or if (data1 !== null)
// Shorthand //  
if (test1)
```
Note: If test1 has any value it will fall into the logic after the if loop, this operator mostly used for null or undefined checks.

# 11. AND(&&) Operator

If we want to avoid one if statement then this shorthand will be helpful
```javascript
//Longhand   
if (test1) {  
 callMethod();   
}
//Shorthand   
test1 && callMethod();
```
# 12. Return shorthand

This one will help to avoid a big chunk of code that specifically returns to call methods based on the return statements.
```javascript
// Longhand  
let value;function returnMe() {  
    if (!(value === undefined)) {  
        return value;  
    } else {  
        return callFunction('value');  
    }  
}var data = returnMe();  
console.log(data); //output value  
function callFunction(val) {  
    console.log(val);  
}  
// Shorthand  
function returnMe() {  
    return value || callFunction('value');  
}
```

# 13. Arrow Functions
```javascript
//Longhand   
function add(a, b) {   
   return a + b;   
}   
//Shorthand   
const add = (a, b) => a + b;
```

Let's check one more example
```javascript
function function(value) {  
  console.log('value', value);  
}
function= value => console.log('value', value);
```
# 14. Short Function Calls

We can use the ternary operator to achieve these functions.
```javascript
// Longhand  
function data1() {  
    console.log('data1');  
};function data2() {  
    console.log('data2');  
};  
var data3 = 1;  
if (data3 == 1) {  
    data1();  
} else {  
    data2();  
} //data1  
// Shorthand  
(data3 === 1 ? data1 : data2)(); //data1
```

# 15. Switch Statment Optimization

If you want to optimize your switch statements then this one can help.
```javascript
// Longhand  
switch (data) {  
    case 1:  
        data1();  
        break;  
    case 2:  
        data2();  
        break;  
    case 3:  
        data();  
        break;  
        // And so on...  
}  
// Shorthand  
var data = {  
    1: data1,  
    2: data2,  
    3: data  
};  
const val = 1  
data[val]();function data1() {  
    console.log("data1");  
}function data2() {  
    console.log("data2");  
}function data() {  
    console.log("data");  
}
```


# 16. Implicit Return

Arrow functions can help to return the value even without writing return statements. Cool right?
```javascript
//longhand
function calculate(diameter) {  
  return Math.PI * diameter  
}
//shorthand
calculate = diameter => (  
  Math.PI * diameter;  
)
```

# 17. Decimal base exponents
```javascript
// Longhand  
for (var i = 0; i < 100000; i++) { ... }
// Shorthand  
for (var i = 0; i < 1e5; i++) {
```

# 18. Default Parameter Values
```javascript
//Longhand  
function add(data1, data2) {  
    if (data1 === undefined) data1 = 1;  
    if (data2 === undefined) data2 = 2;  
    return data1 + data2;  
}  
//shorthand  
add = (data1 = 1, data2 = 2) => data1 + data2;console.log(add()); //output: 3
```
# 19. Spread Operator

It can be useful in another place to create the array reference and for the shallow copy too.
```javascript
//longhand
// joining arrays using concat  
const testdata= [1, 2, 3];  
const values = [4 ,5 , 6].concat(data);
//shorthand
// joining arrays  
const testdata = [1, 2, 3];  
const values = [4 ,5 , 6, ...testdata];  
console.log(test); // [ 4, 5, 6, 1, 2, 3]
```
For cloning also we can use a spread operator.
```javascript
//longhand 
// cloning arrays  
const data1 = [1, 2, 3];  
const data2 = data1.slice()
//shorthand
// cloning arrays  
const data1 = [1, 2, 3];  
const data2 = [...data1];
```
# 20. Template Literals

If you are looking for shorthand to append multiple values in the string then this shorthand is for you.
```javascript
//longhand
const literal = 'Hi ' + data1 + ' ' + data2 + '.';
//shorthand
const literal= `Hi ${data1} ${data2}`;
```
# 21. Multi-line Strings
```javascript
//longhand
const literal = 'abc abc abc abc abc abcnt'  
    + 'val test,test test test testnt';
// shorthand
const literal = `abc abc abc abc abc abc  
         val test,test test test test`
```
# 22. Object Property Assignment
```javascript
let data1 = 'abcd';   
let data2 = 'efgh';
//Longhand   
let data = {data1: data1, data2: data2}; 
//Shorthand   
let data = {data1, data2};
```
# 23. Number conversion
```javascript
//Longhand   
let test1 = parseInt('12');   
let test2 = parseFloat('2.33');

//Shorthand   
let test1 = +'12';   
let test2 = +'2.33';
```
# 24. Destructuring Assignment
```javascript
//longhand  
const data1 = this.data.data1;  
const data2 = this.data.data2;  
const data2 = this.data.data3;
//shorthand  
const { data1, data2, data3 } = this.data;
```
# 25. Array.find method

One of the method from array which find the first matched values from array..
```javascript
const data = [{  
        type: 'data1',  
        name: 'abc'  
    },  
    {  
        type: 'data2',  
        name: 'cde'  
    },  
    {  
        type: 'data1',  
        name: 'fgh'  
    },  
]
function datafinddata(name) {  
    for (let i = 0; i < data.length; ++i) {  
        if (data[i].type === 'data1' && data[i].name === name) {  
            return data[i];  
        }  
    }  
}

//Shorthand
filteredData = data.find(data => data.type === 'data1' && data.name === 'fgh');  
console.log(filteredData); // { type: 'data1', name: 'fgh' }
```

# 26. Bitwise IndexOf Shorthand

What if we can combine indexof method with shorthand? Bitwise indexof do the same job for us.
```javascript
//longhand  
if (data.indexOf(item) > -1) { // item found  
}  
if (data.indexOf(item) === -1) { // item not found  
}//shorthand  
if (~data.indexOf(item)) { // item found  
}  
if (!~data.indexOf(item)) { // item not found  
}
```
we can use includes function too.
```javascript
if (data.includes(item)) {   
// true if the item found  
}
```

# 27. Object.entries()

This feature helps to convert the object to an array of objects.
```javascript
const data = {  
    data1: 'abc',  
    data2: 'cde',  
    data3: 'efg'  
};  
const arr = Object.entries(data);  
console.log(arr);

[  
    ['data1', 'abc'],  
    ['data2', 'cde'],  
    ['data3', 'efg']  
]

```

# 28. Object.values() and Object.keys()

It can be helpful to iterate the Object values.
```javascript
const data = {  
    data1: 'abc',  
    data2: 'cde'  
};  
const arr = Object.values(data);  
console.log(arr);//[ 'abc', 'cde']  
```
Object.keys() can be helpful to iterate the keys from object
```javascript
const data = {  
    data1: 'abc',  
    data2: 'cde'  
};  
const arr = Object.keys(data);  
console.log(arr);//[ 'data1', 'data2']
```
# 29. Double Bitwise Shorthand

**(The double NOT bitwise operator approach only works for 32-bit integers)**
```javascript
// Longhand  
Math.floor(1.9) === 1 // true

// Shorthand  
~~1.9 === 1 // true
```
# 30. Repeat a string multiple times

This string method can be helpful to repeat the same string value again and again
```javascript
//longhand   
let data = '';  
for (let i = 0; i < 5; i++) {  
    data += 'data ';  
}  
console.log(str); // data data data data data 

//shorthand   
'data '.repeat(5);
```
# 31. Find max and min number in the array
```javascript
const data = [1, 4, 3];   
Math.max(…data); // 4  
Math.min(…data); // 1
```
# 32. Get character from string
```javascript
let str = 'test';  
//Longhand   
str.charAt(2); 
//Shorthand   
Note: this is only works if we know the index of matched characterstr[2]; // c
```
# 33. Power Shorthand
```javascript
//longhand\
Math.pow(2,2); // 4

//shorthand
2**2 // 4

---
### 🔥 Mastering TypeScript: 20 Best Practices for Improved Code Quality 
### Content

-   [**Intro**](###6eb3)
-   [**Best Practice 1: Strict Type Checking**](######82d7)
-   [**Best Practice 2: Type Inference**](###9610)
-   [**Best Practice 3: Linters**](###97cf)
-   [**Best Practice 4: Interfaces**](###0d22)
-   [**Best Practice 5: Type Aliases**](###5e5a)
-   [**Best Practice 6: Using Tuples**](###da1c)
-   [**Best Practice 7: Using any Type**](###e2c2)
-   [**Best Practice 8: Using the unknown Type**](###4f04)
-   [**Best Practice 9: “never”**](###7070)
-   [**Best Practice 10: Using the keyof operator**](###0df1)
-   [**Best Practice 11: Using Enums**](###6996)
-   [**Best Practice 12: Using Namespaces**](###2a51)
-   [**Best Practice 13: Using Utility Types**](###9a72)
-   [**Best Practice 14: “Readonly” and “ReadonlyArray”**](###01aa)
-   [**Best Practice 15: Type Guards**](###60b7)
-   [**Best Practice 16: Using Generics**](###4740)
-   [**Best Practice 17: Using the infer keyword**](###1a29)
-   [**Best Practice 18: Using Conditional Types**](###09a7)
-   [**Best Practice 19: Using Mapped Types**](###d76b)
-   [**Best Practice 20: Using Decorators**](###8c2a)
-   [**Conclusion**](###9131)
-   [**Learn More**](###b6ff)

### Intro

**TypeScript** is a widely used, open-source programming language that is perfect for modern development. With its advanced type system, TypeScript allows developers to write code that is more robust, maintainable, and scalable. But, to truly harness the power of TypeScript and build high-quality projects, it's essential to understand and follow best practices. In this article, we'll dive deep into the world of **TypeScript** and explore 20 best practices for mastering the language. These best practices cover a wide range of topics and provide concrete examples of how to apply them in real-world projects. Whether you're just starting out or you're an experienced TypeScript developer, this article will provide valuable insights and tips to help you write clean, efficient code.

So, grab a cup of coffee ☕️, and let's get started on our journey to mastering TypeScript!

### Best Practice 1: Strict Type Checking

We will start with the most basic ones. Imagine being able to catch potential errors before they even happen, sounds too good to be true? Well, that's exactly what **strict type checking** in TypeScript can do for you. This best practice is all about catching those sneaky bugs that can slip into your code and cause headaches down the line.

Strict type checking is all about making sure that the types of your variables match the types you expect them to be. This means that if you declare a variable to be of type `string`, TypeScript will make sure that the value assigned to that variable is indeed a string and not a number, for example. This helps you to catch errors early on and make sure your code is working as intended.

Enabling strict type checking is as simple as adding “strict”: true to your `tsconfig.json` file (has to be true by default). By doing this, TypeScript will enable a set of checks that will catch certain errors that would otherwise go unnoticed.

Here's an example of how strict type checking can save you from a common mistake:
```javascript
let userName: string = "John";  
userName = 123; // TypeScript will raise an error because "123" is not a string.
```
By following this best practice, you will be able to catch errors early on and make sure that your code is working as intended, saving you time and frustration in the long run.

### Best Practice 2: Type Inference

TypeScript is all about being explicit with your types, but that doesn't mean you have to spell everything out.

Type inference is the ability of the TypeScript compiler to automatically determine the type of a variable based on the value that is assigned to it. This means that you don't have to explicitly specify the type of a variable every time you declare it. Instead, the compiler will look at the value and infer the type for you.

For example, in the following code snippet, TypeScript will automatically infer that the type of `name` is a `string`:
```javascript
let name = "John";
```
Type inference is especially useful when you are working with complex types or when you are initializing a variable with a value that is returned from a function.

But remember, type inference is not a magic wand, sometimes it's better to be explicit with types, especially when working with complex types or when you want to make sure that a specific type is used.

### Best Practice 3: Linters

Linters are tools that can help you to write better code by enforcing a set of rules and guidelines. They can help you to catch potential errors and improve the overall quality of your code.

There are several linters available for TypeScript, such as [TSLint](https://palantir.github.io/tslint/) and [ESLint](https://eslint.org/), that can help you to enforce a consistent code style and catch potential errors. These linters can be configured to check for things like missing semicolons, unused variables, and other common issues.

### Best Practice 4: Interfaces

When it comes to writing clean and maintainable code, **interfaces** are your best friend. They are like a blueprint for your objects, outlining the structure and properties of the data you will be working with.

An interface in TypeScript defines a contract for the shape of an object. It specifies the properties and methods that an object of that type should have, and it can be used as a type for a variable. This means that when you assign an object to a variable with an interface type, TypeScript will check that the object has all the properties and methods specified in the interface.

Here's an example of how to define and use an interface in TypeScript:
```javascript
interface User {  
 name: string;  
 age: number;  
}  
let user: User = {name: "John", age: 25};
```
Interfaces also make it easier to refactor your code, by ensuring that all the places where a certain type is used are updated at once.

### Best Practice 5: Type Aliases

TypeScript allows you to create custom types using a feature called **type aliases**. The main difference between features `type alias` and `interface`is that `type alias` creates a new name for the type, whereas `interface` creates a new name for the shape of the object.

For example, you can use a **type alias** to create a custom type for a point in a two-dimensional space:
```javascript
type Point = { x: number, y: number };  
let point: Point = { x: 0, y: 0 };

Type aliases can also be used to create complex types, such as a **union type** or an **intersection type**.

type User = { name: string, age: number };  
type Admin = { name: string, age: number, privileges: string[] };  
type SuperUser = User & Admin;
```
### Best Practice 6: Using Tuples

Tuples are a way to represent a fixed-size array of elements with different types. They allow you to express a collection of values with a specific order and types.

For example, you can use a tuple to represent a point in a 2D space:
```javascript
let point: [number, number] = [1, 2];

You can also use a tuple to represent a collection of multiple types:

let user: [string, number, boolean] = ["Bob", 25, true];
```
One of the main advantages of using tuples is that they provide a way to express a specific type relationship between the elements in the collection.

In addition, you can use destructuring assignment to extract the elements of a tuple and assign them to variables:
```javascript
let point: [number, number] = [1, 2];  
let [x, y] = point;  
console.log(x, y);
```
### Best Practice 7: Using any Type

Sometimes, we may not have all the information about a variable's type, but still need to use it in our code. In such cases, we can utilize the `any` type. But, like any powerful tool, the use of `any` should be used with caution and purpose.

One best practice when using `any` is to limit its usage to specific cases where the type is truly unknown, such as when working with **third-party libraries** or **dynamically generated data**. Additionally, it's a good idea to add **type** **assertions** or **type guards** to ensure the variable is being used correctly. And when possible, try to narrow down the type of the variable as much as you can.

For example:
```javascript
function logData(data: any) {  
    console.log(data);  
}  
  
const user = { name: "John", age: 30 };  
const numbers = [1, 2, 3];  
  
logData(user); // { name: "John", age: 30 }  
logData(numbers); // [1, 2, 3]
```
Another best practice is to avoid using `any` in function return types and function arguments, as it can weaken the type safety of your code. Instead, you can use a type that is more specific or use a type that is more general like `unknown` or `object` that still provide some level of type safety.

### Best Practice 8: Using the `unknown` Type

The unknown type is a powerful and restrictive type that was introduced in TypeScript 3.0. It is a more restrictive type than `any` and it can help you to prevent unintended type errors.

Unlike `any`, when you use the unknown type, TypeScript will not allow you to perform any operation on a value unless you first check its type. This can help you to catch type errors at compile-time, instead of at runtime.

For example, you can use the unknown type to create a more type-safe function:
```javascript
function printValue(value: unknown) {  
 if (typeof value === "string") {  
   console.log(value);  
 } else {  
   console.log("Not a string");  
 }  
}

You can also use the unknown type to create more type-safe variables:

let value: unknown = "hello";  
let str: string = value; // Error: Type 'unknown' is not assignable to type 'string'.
```
### Best Practice 9: “never”

In TypeScript, `never` is a special type that represents values that will never occur. It's used to indicate that a function will not return normally, but will instead throw an error. This is a great way to indicate to other developers (and the compiler) that a function can't be used in certain ways, this can help to catch potential bugs.

For example, consider the following function that throws an error if the input is less than 0:
```javascript
function divide(numerator: number, denominator: number): number {  
 if (denominator === 0) {  
 throw new Error("Cannot divide by zero");  
 }  
 return numerator / denominator;  
}
```
Here, the function `divide` is declared to return a number, but if the denominator is zero, it will throw an error. To indicate that this function will not return normally in this case, you can use **never** as the return type:
```javascript
function divide(numerator: number, denominator: number): number | never {  
 if (denominator === 0) {  
   throw new Error("Cannot divide by zero");  
 }  
   return numerator / denominator;  
}
```

### Best Practice 10: Using the `keyof` operator

The `keyof` operator is a powerful feature of TypeScript that allows you to create a type that represents the keys of an object. It can be used to make it clear which properties are allowed for an object.

For example, you can use the `keyof` operator to create a more readable and maintainable type for an object:
```javascript
interface User {  
 name: string;  
 age: number;  
} 
  
type UserKeys = keyof User; // "name" | "age"

You can also use the `keyof` operator to create more type-safe functions that take an object and a key as arguments:

function getValue<T, K extends keyof T>(obj: T, key: K) {  
 return obj[key];  
}  
let user: User = { name: "John", age: 30 };  
console.log(getValue(user, "name")); // "John"  
console.log(getValue(user, "gender")); 
// Error: Argument of type '"gender"' is not assignable to parameter of type '"name" | "age"'.
```

### Best Practice 11: Using Enums

Enums, short for enumerations, are a way to define a set of named constants in TypeScript. They can be used to create a more readable and maintainable code, by giving a meaningful name to a set of related values.

For example, you can use an enum to define a set of possible status values for an order:
```javascript
enum OrderStatus {  
 Pending,  
 Processing,  
 Shipped,  
 Delivered,  
 Cancelled  
}  
  
let orderStatus: OrderStatus = OrderStatus.Pending;

Enums can also have a custom set of numeric values or strings.

enum OrderStatus {  
 Pending = 1,  
 Processing = 2,  
 Shipped = 3,  
 Delivered = 4,  
 Cancelled = 5  
}  
  
let orderStatus: OrderStatus = OrderStatus.Pending;
```
Always name an enum with the first capital letter and the name has to be in singular form, as a part of the naming convention.

### Best Practice 12: Using Namespaces

Namespaces are a way to organize your code and prevent naming collisions. They allow you to create a container for your code, where you can define variables, classes, functions, and interfaces.

For example, you can use a namespace to group all the code related to a specific feature:
```javascript
namespace OrderModule {  
 export class Order { /* … */ }  
 export function cancelOrder(order: Order) { /* … */ }  
 export function processOrder(order: Order) { /* … */ }  
}  
let order = new OrderModule.Order();  
OrderModule.cancelOrder(order);
```
You can also use namespaces to prevent naming collisions by providing a unique name for your code:
```javascript
namespace MyCompany.MyModule {  
 export class MyClass { /* … */ }  
}  
  
let myClass = new MyCompany.MyModule.MyClass();
```

It's important to note that namespaces are similar to modules, but they are used to organize the code and prevent naming collisions, while modules are used to load and execute the code.

### Best Practice 13: Using Utility Types

Utility types are a built-in feature of TypeScript that provide a set of predefined types to help you write better type-safe code. They allow you to perform common type operations and manipulate types in a more convenient way.

For example, you can use the `Pick` utility type to extract a subset of properties from an object type:
```javascript
type User = { name: string, age: number, email: string };  
type UserInfo = Pick<User, "name" | "email">;
```
You can also use the `Exclude` utility type to remove properties from an object type:
```javascript
type User = { name: string, age: number, email: string };  
type UserWithoutAge = Exclude<User, "age">;
```
You can use the `Partial` utility type to make all properties of a type optional:
```javascript
type User = { name: string, age: number, email: string };  
type PartialUser = Partial<User>;
```
### Best Practice 14: “Readonly” and “ReadonlyArray”

When working with data in TypeScript, you might want to make sure that certain values can't be changed. And that's where `Readonly` and `ReadonlyArray` come in.

The `Readonly` keyword is used to make properties of an object read-only, meaning they can't be modified after they are created. This can be useful when working with configuration or constant values, for example.
```javascript
interface Point {  
 x: number;  
 y: number;  
}  
let point: Readonly<Point> = {x: 0, y: 0};  
point.x = 1; // TypeScript will raise an error because "point.x" is read-only

The `ReadonlyArray` is similar to `Readonly` but for arrays. It makes an array read-only, and it can't be modified after it's created.

let numbers: ReadonlyArray<number> = [1, 2, 3];  
numbers.push(4); // TypeScript will raise an error because "numbers" is read-only
```
### Best Practice 15: Type Guards

When working with complex types in TypeScript, it can be challenging to keep track of the different possibilities of a variable. Type guards are a powerful tool that can help you to narrow down the type of a variable based on certain conditions.

Here's an example of how to use a type guard to check if a variable is a number:
```javascript
function isNumber(x: any): x is number {  
 return typeof x === "number";  
}  
let value = 3;  
if (isNumber(value)) {  
 value.toFixed(2); // TypeScript knows that "value" is a number because of the type guard  
}
```
Type guards can also be used with the “in” operator, the `typeof` operator and the `instanceof` operator.

### Best Practice 16: Using Generics

Generics are a powerful feature of TypeScript that allows you to write code that can work with any type, making it more reusable. Generics allow you to write a single function, `class` or `interface` that can work with multiple types, without having to write separate implementations for each type.

For example, you can use a generic function to create an array of any type:
```javascript
function createArray<T>(length: number, value: T): Array<T> {  
 let result = [];  
  
 for (let i = 0; i < length; i++) {  
   result[i] = value;  
 }  
  
 return result;  
}  
  
let names = createArray<string>(3, "Bob");  
let numbers = createArray<number>(3, 0);
```
You can also use generics to create a `class` that can work with any type of data:
```javascript
class GenericNumber<T> {  
 zeroValue: T;  
 add: (x: T, y: T) => T;  
}  
  
let myGenericNumber = new GenericNumber<number>();  
myGenericNumber.zeroValue = 0;  
myGenericNumber.add = function(x, y) { return x + y; };
```
### Best Practice 17: Using the `infer` keyword

The `infer` keyword is a powerful feature of TypeScript that allows you to extract the type of a variable in a type.

For example, you can use the `infer` keyword to create a more precise type for a function that returns an array of a specific type:
```javascript
type ArrayType<T> = T extends (infer U)[] ? U : never;  
type MyArray = ArrayType<string[]>; // MyArray is of type string
```
You can also use the `infer` keyword to create more precise types for a function that returns an object with a specific property:
```javascript
type ObjectType<T> = T extends { [key: string]: infer U } ? U : never;  
type MyObject = ObjectType<{ name: string, age: number }>; // MyObject is of type {name:string, age: number}
```
### Best Practice 18: Using Conditional Types

Conditional types let you to express more complex type relationships. They allow you to create new types based on the conditions of other types.

For example, you can use a conditional type to extract the return type of a function:
```javascript
type ReturnType<T> = T extends (…args: any[]) => infer R ? R : any;  
type R1 = ReturnType<() => string>; // string  
type R2 = ReturnType<() => void>; // void
```
You can also use conditional types to extract the properties of an object type that meet a certain condition:
```javascript
type PickProperties<T, U> = { [K in keyof T]: T[K] extends U ? K : never }[keyof T];  
type P1 = PickProperties<{ a: number, b: string, c: boolean }, string | number>; // "a" | "b"
```
### Best Practice 19: Using Mapped Types

Mapped types are a way to create new types based on existing types. They allow you to create new types by applying a set of operations to the properties of an existing type.

For example, you can use a mapped type to create a new type that represents the readonly version of an existing type:
```javascript
type Readonly<T> = { readonly [P in keyof T]: T[P] };  
let obj: { a: number, b: string } = { a: 1, b: "hello" };  
let readonlyObj: Readonly<typeof obj> = { a: 1, b: "hello" };
```
You can also use a mapped type to create a new type that represents the optional version of an existing type:
```javascript
type Optional<T> = { [P in keyof T]?: T[P] };  
let obj: { a: number, b: string } = { a: 1, b: "hello" };  
let optionalObj: Optional<typeof obj> = { a: 1 };
```
Mapped types can be used in different ways: to create new types, to add or remove properties from an existing type, or to change the type of the properties of an existing type.

### Best Practice 20: Using Decorators

Decorators are a way to add additional functionality to a class, method or property using a simple syntax. They are a way to enhance the behavior of a class without modifying its implementation.

For example, you can use a decorator to add logging to a method:
```javascript
function logMethod(target: any, propertyKey: string, descriptor: PropertyDescriptor) {  
 let originalMethod = descriptor.value;  
  
 descriptor.value = function(…args: any[]) {  
 console.log("Calling ${propertyKey} with args: ${JSON.stringify(args)}");  
 let result = originalMethod.apply(this, args);  
 console.log("Called ${propertyKey}, result: ${result}");  
 return result;  
 }  
}  
  
class Calculator {  
 @logMethod  
 add(x: number, y: number): number {  
 return x + y;  
 }  
}
```
You can also use decorators to add metadata to a class, method or property, which can be used at runtime.
```javascript
function setApiPath(path: string) {  
 return function (target: any) {  
 target.prototype.apiPath = path;  
 }  
}  
  
@setApiPath("/users")  
class UserService {  
 // …  
}  
console.log(new UserService().apiPath); // "/users"
```
### Conclusion

Whether you are a beginner or an experienced TypeScript developer, I hope that this article has provided valuable insights and tips to help you write clean, efficient code.

Remember, best practices are guidelines, not hard rules. Always use your own judgment and common sense when writing code. And keep in mind that, as TypeScript evolves and new features are introduced, the best practices may change, so stay up to date and be open to learning new things.

We hope that you have found this article helpful and that it has inspired you to become a better TypeScript developer. Happy coding! Don't forget to clap, comment, follow and subscribe, this will share TypeScript best practices with more people and improve your karma!



