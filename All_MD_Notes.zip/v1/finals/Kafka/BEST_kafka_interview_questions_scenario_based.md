# Kafka Deep Dive: Scenario-Based Problems 

### **Scenario 1:** Let’s say we have a topic with 4 partitions and 1 consumer group consisting of only 1 consumer. The consumer has subscribed to the TopicT1 and is assigned to consume from all the partitions.
This scenario can be depicted by the picture below:

![](https://miro.medium.com/v2/resize:fit:875/1*3jb6Zu_kZMV8PZccKKsgUw.png)

### **Scenario 2:** Now let’s consider we have 2 consumers in our consumer group. These 2 consumers would be assigned to read from different partitions — Consumer1 assigned to read from partitions 0, 2; and Consumer2 assigned to read from partitions 1, 3.

**Note**: Kafka assigns the partitions of a topic to the consumer in a consumer group, so that each partition is consumed by exactly one consumer in the consumer group.

Kafka guarantees that a message is only ever read by a single consumer in the consumer group.

Since the messages stored in individual partitions of the same topic are different, the two consumers would never read the same message, thereby avoiding the same messages being consumed multiple times at the consumer side.

This scenario can be depicted by the picture below:

![](https://miro.medium.com/v2/resize:fit:875/1*HWCRdF_2_aX1WLs0Da7Khw.png)

But, what if the number of consumers in a consumer group is more than the number of partitions?

**Check out Scenario 3**

### **Scenario 3:**Let’s say we have 5 consumers in the consumer group which is more than the number of partitions of the TopicT1, then every consumer would be assigned a single partition and the remaining consumer (Consumer5) would be left idle.

This scenario can be depicted by the picture below:

![](https://miro.medium.com/v2/resize:fit:875/1*g0kV3F5F5hDweUyl8llReA.png)

Okay, and what if you want multiple consumers to read from the same partition?

**Check out Scenario 4**

### **Scenario 4:** If you want to assign multiple consumers to read from the same partition, then you can add these consumers to different consumer groups, and have both of these consumer groups subscribed to the TopicT1.

Here, the messages from Partition0 of TopicT1 are read by Consumer1 of ConsumerGroup1 and Consumer1 of ConsumerGroup2.

This scenario can be depicted by the picture below:

![](https://miro.medium.com/v2/resize:fit:856/1*c-jiQcLjJoPBi2hd5npGuw.png)

### When should you add consumers to the same consumer group

### Vs

### When should you add the consumers to a different consumer group?

If your goal is to attain a higher throughput or increase the consumption rate for a particular topic, then adding multiple consumers in the same consumer group would be the way to go.

You can have at max consumers equal to the number of partitions of a topic in a consumer group, adding more consumers than the number of partitions would cause the extra consumers to remain idle, since Kafka maintains that no two partitions can be assigned to the consumer in a consumer group.

When the the number of consumers consuming from a topic is equal to the number of partitions in the topic, then each consumer would be reading messages from a single topic, and the message consumption would be happening in parallel, thereby increasing the consumption rate.

But if you have a use case where you want multiple consumers to consume the same messages of a topic, then having multiple consumer groups subscribed to the topic, and adding consumers as per your requirements to these consumer groups would be something you can make use of.

### Leader and Follower

In a Kafka cluster, each partition has one leader and multiple followers. The leader handles all read and write requests for the partition, while followers replicate the data from the leader. If the leader fails, one of the followers is elected as the new leader to ensure continuous data availability.

This leader-follower mechanism enhances Kafka’s fault tolerance and reliability, ensuring that data streams remain consistent and available.

### Leader:

The leader is the broker responsible for handling all read and write requests for a specific partition. Each partition has one leader at any given time. The leader manages the in-sync replicas list for its partition.

### Follower:

Followers are brokers that replicate the leader’s data for a partition. They don’t handle client requests directly for that partition. Followers stay in sync with the leader by fetching messages. If a leader fails, one of the in-sync followers is elected as the new leader.

### ISR-In Sync Replica

ISR refers to the replicas of a partition that are “in sync” with the leader. An ISR is a follower that is synchronized with the leader.

![](https://miro.medium.com/v2/resize:fit:875/1*ATrAh5tBs3POkpoveyLQ6w.png)


### 1️⃣ Your Kafka producer is sending duplicate messages due to network retries. How would you ensure exactly-once message processing?

Kafka provides **idempotent producers** and **transactions** to guarantee exactly-once processing:

✅ **Use an Idempotent Producer** (Prevents duplicates at the producer level):
```java
Properties props = new Properties();  
props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");  
props.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, "true");  // Ensures exactly-once  
props.put(ProducerConfig.ACKS_CONFIG, "all");  // Ensures all replicas have received data  
props.put(ProducerConfig.RETRIES_CONFIG, Integer.MAX_VALUE);  // Retry indefinitely  
KafkaProducer<String, String> producer = new KafkaProducer<>(props);
```
✅ **Use Kafka Transactions** (Ensures atomicity across partitions):
```java
props.put(ProducerConfig.TRANSACTIONAL_ID_CONFIG, "order-txn-1");    
KafkaProducer<String, String> producer = new KafkaProducer<>(props);  
producer.initTransactions();  
try {  
    producer.beginTransaction();  
    producer.send(new ProducerRecord<>("orders", "order123", "processed"));  
    producer.commitTransaction();  // Ensures atomicity  
} catch (Exception e) {  
    producer.abortTransaction();  // Rollback on failure  
}
```
### 2️⃣ Your consumer group is experiencing **high lag**. What steps would you take to troubleshoot and fix this?

Below are the steps →

###### 1️⃣ Check Lag Metrics:
```shell
kafka-consumer-groups.sh --bootstrap-server localhost:9092 --group my-consumer-group --describe
```
###### 2️⃣ Optimize Consumer Processing:

✅ **Increase Parallel Consumers**

-   If partitions > consumers, add more consumers to the group to **distribute load**.

✅ **Use Asynchronous Processing with CompletableFuture:**
```java
ExecutorService executor = Executors.newFixedThreadPool(10);  
ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(100));  
for (ConsumerRecord<String, String> record : records) {  
    CompletableFuture.runAsync(() -> processMessage(record), executor);  
}
```

✅ **Use Batch Processing Instead of Single Message Processing**
```java
List<ConsumerRecord<String, String>> batch = new ArrayList<>();  
for (ConsumerRecord<String, String> record : records) {  
    batch.add(record);  
    if (batch.size() == 100) { // Process batch of 100 messages  
        processBatch(batch);  
        batch.clear();  
    }  
}
```

### 3️⃣ A Kafka broker crashes. What happens to the messages, and how do you recover?

Lets see the steps →

###### 🔹 **Step 1: Identify Affected Partitions**
```shell
kafka-topics.sh --describe --bootstrap-server localhost:9092 --topic my-topic
```
Check if the crashed broker was a **leader** for partitions.

###### 🔹 **Step 2: Ensure Automatic Leader Election**

-   Kafka elects a new leader from the **in-sync replicas (ISR)**.
-   If no ISR exists, the topic becomes **unavailable until a replica catches up**.

###### 🔹 **Step 3: Restart the Broker & Ensure it Rejoins ISR**
```shell
systemctl restart kafka
```
If broker is **too far behind**, increase `replica.lag.time.max.ms` to allow it to catch up.

### 4️⃣ Your Kafka producer sends large messages (e.g., 10MB), and consumers experience failures. How do you handle this?

###### 🔹 **Solution 1: Increase the Maximum Message Size**  
In `server.properties`:
```shell
message.max.bytes=10485760  ### 10MB  
replica.fetch.max.bytes=10485760
```
In producer:
```java
props.put(ProducerConfig.MAX_REQUEST_SIZE_CONFIG, 10485760);
```
###### 🔹 **Solution 2: Use Compression (Reduces Message Size by 50–70%)**
```java
props.put(ProducerConfig.COMPRESSION_TYPE_CONFIG, "snappy");
```
###### 🔹 **Solution 3: Store Large Payloads in External Storage**

-   Save **only a reference** (e.g., S3 URL, database key) in Kafka instead of the full payload.

### 5️⃣ Your Kafka consumer group frequently experiences rebalances, causing delays. How do you optimize it?

###### 🔹 **Solution 1: Increase** `**session.timeout.ms**` **to Reduce Unnecessary Rebalances**
```java
props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, "45000"); // Default: 10s  
props.put(ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, "15000");
```
###### 🔹 **Solution 2: Use Static Membership to Avoid Unnecessary Rebalances**
```java
props.put(ConsumerConfig.GROUP_INSTANCE_ID_CONFIG, "consumer-1");
```
This ensures that **restarting a consumer does not trigger rebalancing**.

### 6️⃣ Producers experience **high end-to-end latency** while sending messages. How do you optimize Kafka for low latency?

###### 🔹 **Step 1: Reduce Acknowledgment Wait Time**
```java
props.put(ProducerConfig.ACKS_CONFIG, "1");  // Default is "all" (safe but slower)  
props.put(ProducerConfig.LINGER_MS_CONFIG, "5");  // Default is 0 (reduce batching delay)  
props.put(ProducerConfig.BATCH_SIZE_CONFIG, "65536"); // Increase batch size
```
###### 🔹 **Step 2: Use** `**send()**` **Asynchronously to Avoid Blocking**
```java
producer.send(new ProducerRecord<>("fast-topic", "key", "message"),  
    (metadata, exception) -> {  
        if (exception != null) {  
            exception.printStackTrace();  
        } else {  
            System.out.println("Message sent to " + metadata.partition());  
        }  
    });
```

### 7️⃣ You need to retain only the **latest update** for each key in a Kafka topic. How do you do it?

###### 🔹 **Step 1: Enable Log Compaction in Topic Settings**
```shell
kafka-configs.sh --bootstrap-server localhost:9092 --alter --entity-type topics --entity-name user-updates --add-config cleanup.policy=compact
```
###### 🔹 **Step 2: Ensure Messages Have a Key**
```java
ProducerRecord<String, String> record = new ProducerRecord<>("user-updates", "user123", "profile updated");  
producer.send(record);
```
Kafka **removes older records with the same key** while keeping at least one version.

### 8️⃣ Your Kafka brokers are **running out of disk space**. How do you free up storage?

###### 🔹 **Solution 1: Reduce Retention Time**
```shell
kafka-configs.sh --bootstrap-server localhost:9092 --alter --entity-type topics --entity-name logs --add-config retention.ms=86400000  ### 1 Day
```
###### 🔹 **Solution 2: Delete Old Topics Manually**
```shell
kafka-topics.sh --delete --bootstrap-server localhost:9092 --topic old-topic
```
###### 🔹 **Solution 3: Use Tiered Storage (Store Older Data in S3, GCS)**

-   **Kafka Tiered Storage** (Available in Confluent and open-source Kafka).

# Kafka Interview Question for experienced Java developer

### Q.  Why Kafka is used in tech industry why it so popular?

Apache Kafka is popular in the tech industry for several key reasons:

1.  High Throughput and Low Latency: Kafka can handle large volumes of messages quickly, making it suitable for real-time data processing.
2.  Scalability: Kafka’s distributed architecture allows it to scale horizontally, accommodating growing data needs by adding more nodes.
3.  Fault Tolerance and Reliability: Kafka ensures data durability and reliability through replication and partitioning, maintaining operations even if some nodes fail.
4.  Stream Processing: Kafka Streams enables building complex real-time data processing applications.
5.  Data Integration: Kafka acts as a central hub, integrating data from various sources and distributing it to multiple systems.
6.  Open-Source and Community Support: Kafka benefits from a large, active community that continuously improves and expands its capabilities.
7.  Versatile Use Cases: Kafka is used for log aggregation, real-time analytics, event sourcing, messaging, and metrics collection.
8.  Compatibility with Big Data Ecosystems: Kafka integrates well with technologies like Hadoop, Spark, and Elasticsearch, facilitating comprehensive data pipelines.
9.  Streamlined Data Processing: Kafka enables asynchronous processing, enhancing system performance and reliability.

Tech giants like LinkedIn, Netflix, Uber, and Airbnb use Kafka for its robust, scalable, and efficient real-time data handling capabilities, demonstrating its effectiveness in production environments.

> **Actual Kafka interview questions**

As an experienced developer, I’ve noticed a strong demand for Kafka knowledge in interviews. To help others prepare, I’ll be posting Q&A sessions on Kafka. Feel free to leave a comment below with any Kafka questions you’ve encountered, and I’ll do my best to answer them!

### Q.  What are the main components of Kafka (Producers, Consumers, Brokers, Topics, Zookeeper)?

**Producers:** These are applications or services that publish data streams to Kafka. They write messages to specific categories or feeds called Topics (explained below). Producers don’t directly interact with consumers; they simply publish data into Kafka.

**Consumers:** These are applications or services that subscribe to Topics and read the data streams published by producers.Consumers can belong to Consumer Groups (explained below) to coordinate how messages are processed.

**Topics:** Think of Topics as named categories or feeds for data streams. Producers publish data to specific Topics, and Consumers subscribe to those Topics to receive the data.

**Brokers:** These are servers that form the Kafka cluster. A single Kafka cluster can have one or more brokers working together. Brokers are responsible for storing messages published by producers and serving them to consumers. They handle message replication, partition management (explained below), and overall Kafka cluster coordination.

**Zookeeper:** An external service, Zookeeper, manages the Kafka cluster’s state. It keeps track of topics, brokers, and consumer groups, ensuring everything runs smoothly within the cluster. While crucial for coordination, Zookeeper itself doesn’t store actual data messages.

These components work together to form a robust and scalable platform for handling real-time data pipelines.

### Q.  How does Kafka ensure durability and fault tolerance? (replication)

Kafka guarantees data durability and fault tolerance primarily through a technique called **replication**. Here’s how it works:

-   **Topics and Partitions:** A Kafka topic is a category for a stream of data. Internally, each topic is further divided into smaller, ordered segments called partitions. This partitioning allows for parallel processing and scalability.
-   **Replication Factor:** Each partition is replicated across multiple brokers in the Kafka cluster. The number of replicas for a partition is determined by a configuration parameter called the **replication factor**. A higher replication factor ensures greater fault tolerance.
-   **Leader and Followers:** Among the replicas for a partition, one broker is designated as the **leader**. The leader is responsible for receiving writes from producers and replicating those writes to the other replicas, called **followers**.
-   **Data Persistence:** All brokers persist data (messages) on disk. This ensures that even if a broker fails, the data isn’t lost. The followers keep their copies of the partition data synchronized with the leader.
-   **Leader Failure and Recovery:** If a leader broker fails, Kafka automatically triggers a leader election process.One of the in-sync followers becomes the new leader, and the data replication continues. Consumers can continue reading data from the new leader with minimal interruption.

**Producer Acknowledgements:** Additionally, Kafka offers producer acknowledgement settings that influence durability guarantees:

-   **acks=all:** This setting ensures maximum durability. The producer waits for an acknowledgement from all replicas before considering the write successful.
-   **acks=1 (default):** The producer waits for an acknowledgement from the leader replica only. This offers a balance between durability and performance.

With replication and acknowledgement strategies, Kafka ensures data isn’t lost due to broker failures. Even if a broker goes down, its data remains available on the replicas, enabling the system to recover and continue operations.

**There are other factors that contribute to Kafka’s fault tolerance, but replication is the core mechanism.**

### Q.  Explain the difference between Leader and Follower replicas in Kafka?

In a Kafka cluster, where data is organized into topics and further divided into partitions for scalability, Leader and Follower replicas play crucial roles in ensuring data availability and fault tolerance. Here’s a breakdown of their key differences:

**Leader Replica:**

-   **Responsibilities:**
-   Accepts writes (new messages) from producers for its assigned partition.
-   Replicates the received messages to all Follower replicas for the same partition.
-   Determines the committed offset, which signifies the point up to which messages are safely stored and can be consumed.
-   Serves read requests from consumers (although typically consumers primarily interact with the in-sync replica set, explained below).
-   **Selection:** The leader is elected from among the replicas for a partition. This election happens automatically during broker startup, leader failure, or if the leader falls behind significantly.

**Follower Replica:**

-   **Responsibilities:**
-   Passively consumes messages replicated from the Leader.
-   Applies the received messages to its own log, keeping its copy of the partition data synchronized with the Leader.
-   Acknowledges the Leader upon successful replication.
-   **Importance:** Followers provide redundancy and ensure data availability in case the Leader fails. When a leader election occurs, a Follower can become the new Leader to maintain partition functionality.

### Q.  What are Consumer Groups and how do they work?

Consumer Groups are a fundamental concept in Kafka that enable parallel processing of data streams and ensure each message is delivered to exactly one consumer within the group. Here’s how they work:

**Grouping Consumers:**

-   Consumers can be grouped together using a unique identifier called the **group.id**. Consumers belonging to the same group are identified as a Consumer Group.
-   A consumer instance specifies its group affiliation during configuration.

**Load Balancing and Parallel Processing:**

-   When a Consumer Group subscribes to a topic, the partitions of that topic are automatically divided among the consumers in the group. This distribution happens intelligently, aiming for an even balance based on the number of consumers and partitions.
-   Each consumer within the group is then responsible for processing messages from its assigned partitions. This parallel processing allows Consumer Groups to handle high volumes of data efficiently.

**Consumer Exclusivity:**

-   A key aspect of Consumer Groups is that **each message is delivered to only one consumer within the group**.This prevents duplicate processing and ensures data consistency. Kafka achieves this by maintaining a state for each Consumer Group, tracking the current partition assignments.

**Consumer Rebalancing:**

-   The distribution of partitions across consumers can change dynamically. This happens in scenarios like:
-   A consumer joins or leaves the group.
-   A broker failure necessitates partition reassignment.
-   Kafka triggers a process called **consumer rebalancing** in these situations. Rebalancing involves reshuffling the partition assignments among the remaining consumers to maintain balanced processing.

**Benefits of Consumer Groups:**

-   **Parallel Processing:** Enables efficient handling of high-volume data streams.
-   **Scalability:** Allows you to easily scale consumer processing by adding or removing consumers from the group.
-   **Fault Tolerance:** If a consumer fails, its partitions are reassigned to other consumers in the group, ensuring data continues to be processed.
-   **Exactly-Once Delivery (with configuration):** When configured correctly, Consumer Groups can guarantee that each message is delivered to exactly one consumer within the group only once.

**Consumer Group Use Cases:**

Consumer Groups are valuable in various scenarios where you need to parallelize data processing across multiple consumers, such as:

-   Log aggregation: Multiple consumers can process log data from a central topic in parallel.
-   Stream processing: Consumer Groups can be used to distribute data streams for real-time analytics tasks.
-   Microservices communication: Consumer Groups facilitate communication between microservices by allowing them to subscribe to relevant topics and process messages concurrently.

### Q.  What are offsets in Kafka and how are they committed?

In Kafka, offsets act as pointers that keep track of the progress of a consumer group or individual consumer within a topic partition. They are essentially integers assigned sequentially to each message within a partition, starting from zero. Here’s a deeper dive into offsets and how they’re committed:

**Understanding Offsets:**

-   **Per-Partition Tracking:** Offsets are specific to a particular consumer group or consumer and a specific partition within a topic. This allows each consumer to track its own progress independently for each partition it reads from.
-   **Resuming Consumption:** Offsets play a crucial role in resuming consumption after interruptions. When a consumer restarts or joins a group, it uses the committed offset to determine where to begin reading messages from the assigned partition. This ensures consumers don’t re-process messages they’ve already handled.

**Committing Offsets:**

-   **Consumer Responsibility:** Consumers are responsible for committing their offsets periodically. This informs Kafka about the last message the consumer has successfully processed. There are different strategies for committing offsets, each with its own delivery semantics (guarantees about how messages are delivered):
-   **At-least-once:** This is the default setting. The consumer commits the offset after processing a message. However, if the consumer crashes before committing the offset, the message might be redelivered upon restart, leading to potential duplicate processing.
-   **At-most-once:** The consumer commits the offset as soon as the message is received. If processing fails, the message won’t be retried, potentially leading to data loss.
-   **Exactly-once (Transactional):** This is the most complex but ensures each message is delivered and processed exactly once. It requires using Kafka transactions and the Kafka Streams API for processing.
-   **Offset Commit Process:** Consumers typically commit offsets to a special internal topic named “__consumer_offsets” maintained by Kafka. This topic stores the committed offsets for all consumer groups and partitions.

**Importance of Committing Offsets:**

-   **Progress Tracking:** Committed offsets enable consumers to resume processing from the correct point after failures or restarts.
-   **Preventing Duplicates (with at-least-once):** Regular commits with the at-least-once strategy help avoid re-processing messages already handled by the consumer.

**Choosing an Offset Commit Strategy:**

The choice of offset commit strategy depends on your application’s requirements. If data loss is absolutely unacceptable, exactly-once delivery is necessary (though more complex to implement). If some message duplication is tolerable, the at-least-once strategy is a simpler approach.

### Q.  How does Kafka achieve high throughput and low latency?

Kafka achieves high throughput and low latency through a combination of design choices and techniques. Here are some key factors:

**Scalability and Parallelism:**

-   **Distributed Architecture:** Kafka’s distributed architecture allows it to handle large volumes of data by spreading the load across multiple brokers in a cluster. This enables horizontal scaling by adding more machines as needed.
-   **Partitioning:** Topics in Kafka are divided into smaller units called partitions. Producers can publish messages to these partitions in parallel, improving overall throughput. Consumers can also parallelize their processing by consuming messages from assigned partitions concurrently.

**Efficient Data Storage and Access:**

-   **Append-only Logs:** Data is stored in append-only logs on each broker. This simplifies writes and avoids the overhead of random disk access. Since new data is written at the end of the log, it can be accessed efficiently.
-   **Batching:** Producers can batch multiple messages together before sending them to the broker. This reduces network round-trips and improves the efficiency of data transfer.
-   **Zero-Copy Processing:** Whenever possible, Kafka leverages zero-copy techniques to avoid unnecessary data copying between buffers. This minimizes CPU overhead and improves processing speed.
-   **Leveraging OS Features:** Kafka utilizes the Linux page cache to store frequently accessed data in memory,reducing disk I/O and enabling faster message retrieval for consumers.

**Decoupled Communication:**

-   **Producers and Consumers:** Producers and consumers operate independently. Producers publish messages to topics without needing to know which consumers are subscribed. This decoupling reduces overall latency as producers don’t wait for consumer acknowledgement.

**Asynchronous Communication:**

-   Communication between producers, brokers, and consumers is asynchronous. This means producers don’t block while waiting for the broker to confirm receipt, and consumers don’t block waiting for new messages. This improves overall responsiveness.

**Consumer-centric Optimizations:**

-   **Prefetching:** Consumers can prefetch a configurable number of messages into their local buffers. This reduces the latency of subsequent message fetches as data is readily available in memory.
-   **Efficient Consumer Group Management:** Consumer groups leverage rebalancing algorithms to distribute partitions efficiently among consumers. This ensures balanced load and reduces overall processing time.

### Q.  **What are some real-world use cases for Kafka?** (log aggregation, microservices communication)

Here are some real-world use cases for Apache Kafka, highlighting its versatility in handling real-time data pipelines:

**Log Aggregation and Monitoring:**

-   Kafka excels at collecting logs from various distributed applications, services, and microservices. These logs are published as streams to specific topics in Kafka.
-   Centralized log aggregation allows for real-time analysis, troubleshooting, and performance monitoring of applications. Tools like ELK Stack (Elasticsearch, Logstash, Kibana) can be integrated with Kafka to consume and visualize log data for deeper insights.

**Microservices Communication:**

-   Kafka acts as a central nervous system for microservices architectures. Microservices can publish events or data updates to relevant topics in Kafka.
-   Other microservices can subscribe to these topics and react to the published events, enabling asynchronous and loosely coupled communication between services. This promotes scalability and flexibility in microservice deployments.

**Stream Processing and Analytics:**

-   Kafka’s ability to handle high-volume data streams makes it ideal for real-time analytics applications.
-   Stream processing frameworks like Apache Flink or Apache Spark Streaming can be integrated with Kafka to consume data streams from topics and perform real-time computations, filtering, or transformations.
-   This enables applications to react to real-time data insights for fraud detection, anomaly analysis, or recommendation engines.

**IoT Data Ingestion and Processing:**

-   In the realm of Internet of Things (IoT), Kafka can efficiently handle the high volume and velocity of data generated by sensors and devices.
-   Sensor data can be published as messages to Kafka topics, enabling real-time processing, aggregation, and analysis of this data.
-   This can be used for predictive maintenance, remote monitoring, or real-time visualization of IoT sensor data.

**Event Sourcing:**

-   Kafka can be used as a central event store for microservices and applications. Events representing state changes or actions are published as messages to Kafka topics.
-   This event log can be used to reconstruct the application state at any point in time or for implementing eventual consistency patterns in distributed systems.

**Real-time Fraud Detection:**

-   Kafka’s high throughput and low latency make it suitable for building real-time fraud detection systems.
-   Transaction data can be streamed to Kafka topics, and stream processing applications can analyze this data in real-time to identify suspicious patterns or potential fraudulent activities.

These are just a few examples, and Kafka’s use cases continue to evolve as businesses leverage its capabilities for real-time data pipelines and applications.

### Q.  **How would you handle a situation where a Kafka consumer lags behind?** (consumer rebalancing, adjusting configs)

Here are some steps you can take to address a situation where a Kafka consumer lags behind the producer and starts falling behind in processing messages:

**Identify the Cause:**

-   **Monitor Consumer Lag:** First, utilize Kafka consumer monitoring tools or the built-in consumer group lag information to pinpoint which consumer group and partitions are experiencing lag.
-   **Analyze Consumer Performance:** Investigate the problematic consumer’s performance metrics like CPU,memory usage, and processing time to identify potential bottlenecks within the consumer application itself.

**Consumer-side Solutions:**

-   **Optimize Consumer Code:** Review the consumer code and identify areas for improvement. This could involve:
-   Optimizing message processing logic to reduce per-message processing time.
-   Batching message processing to handle multiple messages at once.
-   **Increase Consumer Parallelism:** If the consumer application can handle it, consider increasing the number of consumer instances within the consumer group. This distributes the load and helps catch up with the backlog.
-   **Adjust Consumer Fetch Size:** The consumer fetch size controls the amount of data retrieved from the broker in each request. Increasing the fetch size (within reasonable limits) can improve throughput and potentially reduce lag.

**Kafka Configuration Adjustments:**

-   **Consumer Rebalance:** If the lag is related to uneven partition distribution within the consumer group, consider triggering a consumer rebalance manually using Kafka consumer group management tools. This can redistribute partitions among consumers and potentially alleviate lag on overloaded consumers.
-   **Auto-Offset Reset:** In extreme cases, you might need to reset the consumer offsets for the lagging partitions.However, this approach should be used cautiously as it can lead to message duplication (with at-least-once semantics) or data loss (with at-most-once semantics).

### Q.  How to not consume duplicates messages in Kafka from one consumer?

Achieving exactly-once semantics, where a message is delivered and processed by one consumer only once, requires a bit more effort in Kafka compared to at-least-once or at-most-once delivery. Here are two main approaches to avoid duplicate processing by a single consumer in Kafka:

1.  **Transactional Consumers with Kafka Streams API:**

-   This is the recommended approach for achieving exactly-once processing guarantees. Kafka Streams is a high-level API built on top of Kafka Consumer that simplifies stream processing tasks.
-   It leverages Kafka transactions to ensure that message writes from the producer and the consumer’s offset commits are treated as an atomic unit. If either the write or the commit fails, the entire transaction is rolled back, preventing partial processing and potential duplicates.

Here’s a breakdown of the process:

-   The consumer initiates a Kafka transaction before consuming messages.
-   The consumer processes the messages and performs any necessary actions.
-   If processing is successful, the consumer commits the offsets within the transaction.
-   Kafka ensures that either all operations in the transaction succeed (including the message write and offset commit) or all fail, preventing duplicates.
-   Important points to remember:
-   This approach requires using the Kafka Streams API for consuming messages.
-   Exactly-once semantics also require transactional capabilities on the producer side.

**2. Idempotence with Manual Offset Management:**

-   This approach involves implementing idempotence within your consumer application and managing offsets manually. Idempotence ensures that an operation can be repeated multiple times without unintended side effects.

Here’s the general idea:

-   The consumer assigns a unique identifier (idempotency key) to each message it receives.
-   Before processing a message, the consumer checks if it has already processed a message with the same idempotency key. This can be done by storing processed keys in a database or distributed cache.
-   If the message is new (unique key), the consumer processes it and stores the key for future reference.
-   If the message is a duplicate (key already exists), the consumer discards it without further processing.
-   The consumer commits offsets after successful processing.

Key points to consider:

-   Implementing idempotency logic adds complexity to your consumer application.
-   You need to choose a suitable mechanism for storing and managing idempotency keys.
-   Manually committing offsets requires careful handling to avoid data loss or duplicates.

**Choosing the Right Approach:**

-   **Transactional Consumers (Kafka Streams API) is generally the recommended approach** for its simplicity and guaranteed exactly-once delivery.
-   **Idempotence with manual offset management** can be an alternative, but it requires more development effort and introduces potential complexities in managing idempotency keys and offsets.

### Q.  How to ensure that you do not listen to same message on different consumers?

By default, Kafka consumers within a consumer group **will not** listen to the same message. Kafka achieves this through a concept called consumer groups and offset management. Here’s how it works:

**Consumer Groups:**

-   Consumers can be grouped together using a unique identifier called the “group.id”. All consumers belonging to the same group form a Consumer Group.
-   Each consumer instance specifies its group affiliation during configuration.

**Partition and Offset Tracking:**

-   Topics in Kafka are divided into smaller units called partitions.
-   Each consumer group maintains a record of the **offsets** for each partition it subscribes to. An offset is a unique identifier for a message within a partition, essentially a counter starting from zero.
-   When a consumer group subscribes to a topic, Kafka performs a **consumer rebalancing** to distribute the partitions among the consumers in the group. This ensures even load balancing.

**Exclusive Listening:**

-   Each partition within a topic is assigned to only one consumer **within the group** at a time. This prevents duplicate processing within the group.
-   As consumers process messages, they commit their offsets periodically. This informs Kafka about the last message the consumer has successfully processed for each partition.

**Benefits:**

-   **Prevents Duplicates:** By assigning partitions exclusively and tracking offsets, Kafka ensures that each message is delivered to only one consumer within the group, preventing duplicate processing.
-   **Scalability:** You can easily scale consumer processing by adding or removing consumers from the group. Kafka automatically rebalances partitions to maintain balanced load.

**Example:**

Imagine a Consumer Group with 2 consumers (Consumer A and Consumer B) subscribed to a topic with 3 partitions.Kafka might distribute the partitions as follows:

-   Consumer A: Listens to Partitions 0 and 1
-   Consumer B: Listens to Partition 2

This way, each message is delivered to only one consumer within the group.

**Important Note:**

While Kafka prevents duplicate processing within a consumer group, it’s possible for a message to be delivered to multiple consumer groups if they are both subscribed to the same topic. If you need to ensure a message is only processed once ever, regardless of consumer group, you’ll need to implement additional logic within your consumers using techniques like message idempotence (covered in previous question).

### Q.  How to recover from a failure at consumer end while consuming?

Recovering from a failure at the consumer end in Kafka involves a few key strategies to ensure data isn’t lost and message processing resumes smoothly. Here’s a breakdown of the approaches you can take:

**1. Utilize Kafka’s Offset Commits and Consumer Rebalancing:**

-   **Offset Commits:** Kafka relies on consumer-side offset commits to track progress. Consumers periodically commit their offsets, indicating the last message they’ve successfully processed for each partition they’re subscribed to.
-   **Consumer Rebalancing:** When a consumer fails or a new consumer joins the group, Kafka triggers a **consumer rebalancing**. This process redistributes the partitions among the remaining consumers in the group.

**Recovery Process:**

-   Upon restart, the failed consumer retrieves its committed offsets for the partitions it was previously responsible for.
-   Kafka reassigns those partitions back to the consumer during rebalancing (if it rejoins the same consumer group).
-   The consumer resumes processing messages from the committed offsets, ensuring no data loss occurs due to the failure.

**2. Implement Error Handling and Retries in Your Consumer:**

-   **Error Handling:** It’s crucial to have robust error handling mechanisms in your consumer application to catch exceptions or processing failures during message consumption.
-   **Retry Logic:** When an error occurs, the consumer should implement retry logic to attempt processing the message again. This can involve retrying with a backoff strategy to avoid overwhelming the broker in case of transient errors.
-   **Dead-letter Queues (Optional):** For critical messages or persistent errors, consider implementing a dead-letter queue (DLQ). Failed messages can be sent to the DLQ for manual intervention or later processing attempts.

**3. Leverage Kafka Consumer Offsets Management Tools:**

-   Kafka provides tools and APIs for managing consumer offsets manually. This can be useful in specific scenarios:
-   **Resetting Offsets:** In extreme cases, you might need to manually reset the offsets for a consumer group or specific partitions. However, use this cautiously as it can lead to message duplication (with at-least-once semantics) or data loss (with at-most-once semantics).
-   **Pausing/Resuming Consumers:** You can use tools to pause a consumer or consumer group temporarily for maintenance or debugging purposes. This allows you to control message delivery and offset management.

**4. Choose the Right Offset Commit Strategy:**

-   The default offset commit strategy in Kafka is **at-least-once**. This ensures messages are delivered at least once,but there’s a possibility of duplicates if the consumer fails before committing the offset.
-   For stricter delivery guarantees, consider **exactly-once semantics** using Kafka transactions with the Kafka Streams API. This approach ensures each message is delivered and processed exactly once, but it requires more complex configuration and development effort.

### Q.  How to configure the Kafka in spring boot app?

1.  Add Kafka Dependencies:

Include the necessary Kafka dependencies in your pom.xml (for Maven) or build.gradle (for Gradle) file. Spring Boot provides a convenient `spring-kafka` starter that includes core Kafka dependencies:

<dependency>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-starter-kafka</artifactId>  
</dependency>

2. Configure Kafka Properties:

Spring Boot provides a convenient way to configure Kafka properties using application properties files (like application.yml or application.properties). Here are some essential properties:

-   `spring.kafka.bootstrap-servers`: This property specifies the comma-separated list of Kafka broker addresses.
-   `spring.kafka.consumer.group-id`: This property defines the consumer group ID for your application. Consumers subscribed to the same topic with the same group ID will form a consumer group and efficiently process messages in parallel.
-   `spring.kafka.producer.key-serializer`: This property specifies the serializer used for serializing message keys produced by your application. By default, a `StringSerializer` is used. You can choose other serializers based on your message key data type (e.g., `JsonSerializer` for JSON keys).
-   `spring.kafka.producer.value-serializer`: This property defines the serializer used for serializing message values produced by your application. Similar to key serializer, choose the appropriate serializer based on your message value data type.
-   (Optional) `spring.kafka.consumer.auto-offset-reset`: This property controls what happens to the consumer offsets when the consumer group rebalances or restarts after a failure. The default is `earliest` which means the consumer will start reading from the beginning of the partitions. You can set it to `latest` to start reading from the latest messages.

**3. Create Kafka Producers and Consumers:**

-   Spring Boot provides abstractions for Kafka producers and consumers. You can inject them using `@Autowired` and use them to interact with Kafka topics:

@SpringBootApplication  
public class MyKafkaApp {  
  
    @Autowired  
    private KafkaTemplate<String, String> kafkaTemplate;  
  
    public void sendMessage(String topic, String message) {  
        kafkaTemplate.send(topic, message);  
    }  
  
    @KafkaListener(topics = "myTopic")  
    public void receiveMessage(String message) {  
        // Process the received message  
    }  
  
    // ... (other application logic)  
}

### Q.  What are some common mistakes developers make when working with Kafka?

**Mistakes in Configuration and Usage:**

-   **Not Understanding Consumer Groups:** Failing to grasp the concept of consumer groups and how they distribute workload among consumers can lead to inefficient processing or duplicate messages.
-   **Incorrect Offset Commit Strategy:** Choosing an unsuitable offset commit strategy (at-least-once, at-most-once, or exactly-once) can result in data loss or message duplication depending on your needs.
-   **Improper Serializer Selection:** Not selecting the appropriate serializer/deserializer for message keys and values based on their data types can lead to serialization errors or unexpected behavior.
-   **Unnecessary Manual Offset Management:** Manually managing offsets can be error-prone and complex. Utilize Kafka’s automatic offset management whenever possible.

**Performance and Scalability Issues:**

-   **Overlooking Partitioning:** Not effectively utilizing topic partitioning can bottleneck performance as all consumers in a group would read from a single partition.
-   **Insufficient Consumer Parallelism:** Having too few consumers in a group can lead to processing delays,especially for high-volume data streams.
-   **Inefficient Consumer Code:** Poorly optimized consumer code can slow down message processing and hinder overall throughput.
-   **Not Monitoring Consumer Lag:** Failing to monitor consumer lag can leave you blind to potential bottlenecks or uneven workload distribution.

**Development and Error Handling:**

-   **Ignoring Exactly-Once Semantics:** If your application requires strict data consistency, neglecting exactly-once delivery guarantees (using Kafka Streams and transactions) can lead to data inconsistencies.
-   **Insufficient Error Handling:** Not implementing robust error handling mechanisms in producers and consumers can leave your application vulnerable to exceptions and data loss during failures.
-   **Lack of Testing:** Omitting proper testing of your Kafka application, especially in failure scenarios, can expose weaknesses in your error handling and recovery processes.

**What are some alternatives to Kafka and how do they compare?** (RabbitMQ, Apache Pulsar)

While Kafka is a dominant player in the world of message streaming, there are other options to consider depending on your specific needs. Here’s a comparison of Kafka with two popular alternatives: RabbitMQ and Apache Pulsar:

**RabbitMQ:**

-   **Focus:** RabbitMQ is a lightweight, mature message broker known for its ease of use and flexibility. It excels in message routing and message exchange patterns like pub/sub, RPC (remote procedure calls), and fanout for flexible communication between applications.

**Strengths:**

-   **Simplicity:** Easy to set up, manage, and use, making it suitable for less complex messaging needs.
-   **Lightweight:** Ideal for resource-constrained environments due to its smaller footprint compared to Kafka.
-   **Flexibility:** Supports various message exchange patterns for diverse communication scenarios.
-   **Mature and Stable:** Backed by a large community and extensive battle testing.

**Weaknesses:**

-   **Scalability:** Not as horizontally scalable as Kafka when it comes to handling extremely high message volumes.
-   **Throughput:** May struggle with very high-throughput data streams due to its architecture.
-   **Limited Stream Processing:** Lacks built-in stream processing capabilities compared to Kafka Streams or Pulsar Functions.
-   **Use Cases:**
-   Task Queues: RabbitMQ is well-suited for managing task queues and triggering background jobs in applications.
-   Microservice Communication: It can be used for lightweight communication and data exchange between microservices.
-   Integrations: RabbitMQ is a good choice for implementing integrations between different applications and systems.

**Apache Pulsar:**

-   **Focus:** Pulsar is a relatively newer open-source message streaming platform designed for high performance,scalability, and low latency. It offers features similar to Kafka but with a focus on multi-tenancy and geo-replication.

**Strengths:**

-   **High Performance:** Built for high throughput and low latency, making it suitable for demanding real-time data pipelines.
-   **Scalability:** Highly scalable horizontally to handle massive data volumes.
-   **Multi-tenancy:** Supports secure sharing of a single Pulsar cluster among multiple tenants or organizations.
-   **Geo-replication:** Enables data replication across geographically distributed regions for disaster recovery and global deployments.
-   **Stream Processing:** Offers built-in stream processing capabilities similar to Kafka Streams, allowing data transformation and analysis within the platform.

**Weaknesses:**

-   **Maturity:** Compared to Kafka’s established ecosystem, Pulsar is a relatively younger project, and its ecosystem of tools and integrations might be less mature.
-   **Complexity:** Setting up and managing Pulsar can be slightly more complex than Kafka due to its advanced features.

**Use Cases:**

-   Real-time Analytics: Due to its high throughput and low latency, Pulsar is a good choice for building real-time analytics pipelines.
-   IoT Data Streaming: Pulsar can efficiently handle the high-volume and velocity of data generated by IoT devices.
-   Cloud-native Deployments: Its multi-tenancy and geo-replication features make Pulsar well-suited for cloud-native deployments.

**Choosing the Right Tool:**

The best choice between Kafka, RabbitMQ, and Pulsar depends on your specific requirements. Here’s a quick guideline:

-   **For simple message routing and lightweight communication:** RabbitMQ
-   **For high-throughput, low-latency streaming with scalability:** Kafka or Pulsar
-   **For multi-tenancy, geo-replication, and cloud-native deployments:** Pulsar
-   **For existing Kafka ecosystem and mature tooling:** Kafka

### Kafka Is Overkill: The Dark Side of Event-Driven Microservices 
In the world of microservices, Kafka has become the golden hammer — wielded by every architect chasing scalability and “modern” design. Event-driven architecture is hailed as the future: asynchronous, decoupled, resilient. But here’s the uncomfortable truth no one wants to say out loud:

> **_Kafka is often overkill. And event-driven microservices? Frequently more pain than progress._**

While flashy diagrams and conference talks paint a utopian picture of real-time event streams and loosely coupled services, real-world teams are left drowning in operational complexity, opaque debugging nightmares, and unmanageable message contracts.

This article isn’t here to dismiss Kafka entirely — it’s a powerful tool when used for the right problems. But it’s time we challenge the hype, question the defaults, and ask:  
**Do most microservice architectures _really_ need Kafka and event-driven design? Or are we building complexity we don’t need — just to feel modern?**

Let’s dive deep into why event-driven microservices are often overrated, where Kafka falls short, and what simpler, more practical alternatives developers are embracing in 2025.

![](https://miro.medium.com/v2/resize:fit:453/1*VJnzM8qVmIPGcBpHyOTvyg.gif)

### The Promise of Event-Driven Microservices🧩

At first glance, event-driven microservices seem like a dream:

-   Services are loosely coupled
-   Systems become more scalable
-   Events flow asynchronously across the system
-   Easy to plug in new features by consuming existing events

Kafka fits this narrative perfectly — a distributed event streaming platform that promises durability, high throughput, and horizontal scalability. And when it works, it _really_ works.

But as with all architectural patterns, the devil is in the details.

### The Hidden Complexity of Event-Driven Systems🧠

While decoupling sounds great in theory, it often introduces **invisible coupling** — dependencies on event contracts, formats, topics, and message semantics.

Here’s where things get messy:

-   **Versioning Hell**: Changing the shape of an event becomes a breaking change. You can’t just refactor like you do with REST APIs protected by versioned routes.
-   **Debugging Is a Nightmare**: Tracing a single business flow across multiple event consumers is like playing detective with a half-burned trail.
-   **Testing Becomes Harder**: You can’t simply hit an endpoint and check the response. You have to simulate events, mock brokers, and guess what’s broken.
-   **Operational Overhead**: Kafka clusters are not trivial to operate. You’ll need Zookeeper (or KRaft), manage partitions, monitor offsets, and deal with brokers crashing.

What was meant to simplify scalability ends up complicating development and operations — especially for small to mid-sized teams.

### You Probably Don’t Need Kafka🚫

Let’s be honest: most applications aren’t pushing millions of messages per second.

**Do you really need distributed log-based pub/sub for your CRUD-based billing service or user notification microservice?**

In many cases, a simple synchronous REST call or lightweight queue (like RabbitMQ or even SQS) will do the job without introducing the full complexity of a distributed streaming platform.

Kafka shines when:

-   You need **real-time analytics** across a firehose of data
-   You’re dealing with **IoT-scale telemetry**
-   You need to **replay event history** for rebuilding projections or state
-   You want to decouple a **high-throughput producer** from many consumers

But if your application doesn’t have these requirements, **Kafka might be overkill**.

### Simpler Alternatives to Kafka in Microservices🛠️

Let’s look at practical tools that often meet most microservice communication needs:

### 1. REST APIs (with OpenAPI/Swagger)

For well-defined interactions, REST is easier to test, trace, and version. Tools like Spring Boot, Express.js, or FastAPI make this seamless.

### 2. Message Queues (RabbitMQ, Amazon SQS, Google Pub/Sub)

If you still want async communication, queues are simpler and more suitable for task offloading, background jobs, or decoupling services without needing to replay event logs.

### 3. gRPC or GraphQL Federation

For tighter integration with type safety and schema control, gRPC or GraphQL offer strong contracts and better developer ergonomics.

### 4. Change Data Capture (CDC) with Debezium or Outbox Pattern

Instead of pushing events everywhere, capture changes from the database and selectively stream them to consumers. This offers a more passive event-driven model.

### Event-Driven ≠ Event-Sourced🔍

A quick sidebar to clarify: **Event-Driven Architecture (EDA)** is not the same as **Event Sourcing**.

-   **EDA** means services react to events instead of direct requests
-   **Event Sourcing** stores the entire state change history as a sequence of events

Mixing the two often leads to unnecessary complexity, especially when developers adopt full event sourcing without a solid use case.

Unless you’re building a financial ledger or system with strong audit requirements, event sourcing might just be a premature optimization.

### What Real-World Teams Are Actually Doing🤝

Many engineering teams — especially in mid-size organizations — are opting for a **hybrid approach**:

-   Core domain interactions over REST/gRPC
-   Asynchronous processing via queues for slow or background tasks
-   Kafka or Pulsar reserved for specific high-scale, analytical use cases

The reality is: most business logic doesn’t require streaming architectures. Teams that adopt Kafka “just because” often find themselves rewriting services, re-architecting flows, or paying for unnecessary infrastructure.

### Rethinking the “Event-Driven by Default” Mindset💡

Here’s the uncomfortable truth: **event-driven design has a cost**.

And just because it sounds modern doesn’t mean it’s the best fit for your project.

Ask yourself:

-   Do we need to scale horizontally across hundreds of microservices right now?
-   Can we debug and monitor our event flows effectively?
-   Will our team benefit from eventual consistency — or just be confused by it?
-   Are we trading simplicity for theoretical decoupling?

There’s nothing wrong with using Kafka — when you **need** it.  
But building an entire system around Kafka when a simple HTTP call or job queue will do? That’s architectural over-engineering.

### Final Thoughts: Choose Boring, Proven Tools First🧭

Kafka isn’t evil. Event-driven design isn’t wrong.  
But they’re **not defaults** — they’re **tools for specific problems**.

Start with what’s simple, observable, and maintainable. Don’t let conference talks or Twitter hype dictate your architecture. If and when your system needs Kafka-scale streaming, you’ll know — and you’ll be better prepared to adopt it with intention.

Until then, **build microservices** **without Kafka** — and sleep better at night.
---
### Kafka with Spring Boot: Deep Dive with Interview Questions
### Definition

Apache Kafka is a distributed event streaming platform used for building real-time data pipelines and event-driven applications.

It provides high throughput, fault tolerance, and scalability, making it a popular choice for microservices communication and event sourcing.

### Core Concepts

-   **Topics** → Kafka organizes messages into topics, which act as message categories.
-   **Partitions** → Each topic is divided into multiple partitions to enable parallel processing.
-   **Producers** → Send messages to Kafka topics.
-   **Consumers** → Read messages from topics, typically within consumer groups for parallel processing.
-   **Brokers** → Kafka servers that store and serve messages.
-   **Zookeeper** → Manages metadata and leader election for partitions (deprecated in KRaft mode).
-   **Kafka EOS v2** → EOS v2 was introduced in Kafka 2.5, enabling Exactly-Once Processing without Zookeeper in KRaft mode (introduced in Kafka 2.8.x). KRaft mode eliminates the need for Zookeeper by utilizing an internal quorum for metadata management.

### Advantages

1. **High Throughput** → Handles millions of messages per second with low latency.  
2. **Fault Tolerance** → Replicates data across brokers to ensure durability.  
3. **Real-time Processing** → Ideal for event-driven architectures.  
4. **Decouples Microservices** → Enables asynchronous communication between services.  
5. **Scalability** → Can be scaled horizontally by adding brokers and partitions.

### Disadvantages

1. **Higher Complexity** → More challenging to manage compared to traditional message queues.  
2. **Limited Ordering Guarantees** → Ordering is maintained **only within partitions**, not across partitions.  
3. **Zookeeper Dependency (before EOS v2)** → Adds an extra operational burden (solved in KRaft mode).

### Use Cases

1.  **Log aggregation & monitoring** (e.g., collecting logs from multiple services).
2.  **Event-driven microservices** (e.g., order processing in e-commerce platforms).
3.  **Real-time analytics & fraud detection** (e.g., banking systems).
4.  **Multi-Region Kafka Clusters** → **MirrorMaker 2** is used for **cross-region replication & disaster recovery**.

### Comparison with REST

![](https://miro.medium.com/v2/resize:fit:831/0*0RZfvsJFtJamchFw.png)

**REST is like a phone call (wait for a response), while Kafka is like a WhatsApp group (messages are sent asynchronously).**

### Security Considerations

Kafka supports multiple security mechanisms to protect data:  
1. **OAuth 2.0** → Kafka supports OAuth authentication using **OAuth Bearer tokens**. Example:
```java
sasl.mechanism=OAUTHBEARER  
security.protocol=SASL_SSL  
sasl.jaas.config=org.apache.kafka.common.security.oauthbearer.OAuthBearerLoginModule required;
```
**2. Authentication** → SASL (Simple Authentication and Security Layer) for verifying identities.  
3. **Authorization** → ACLs (Access Control Lists) to restrict access to topics.  
4. **Encryption** → SSL/TLS encryption for securing data in transit.  
5. **RBAC (Role-Based Access Control)** → **Apache Kafka does not natively support RBAC**. However, **Confluent Kafka** and **third-party tools** provide RBAC implementations for fine-grained access control.  
6. **Log Segmentation & Data Retention** → Configures message deletion or compaction policies..

### Observability & Monitoring

1. **OpenTelemetry** → The latest **distributed tracing standard** (replacing Zipkin & Jaeger).  
2. **Dead Letter Queues (DLQ)** → Stores failed messages for later processing.  
3. **Consumer Retries & Circuit Breakers** → Uses **Spring Kafka Error Handling** & **Resilience4j**.  
4. **Monitoring** → Uses **Prometheus & Grafana** for real-time metrics.

5. **Kafka Lag Monitoring** → **Burrow** (Netflix’s Kafka Consumer Lag monitoring tool) provides real-time consumer lag monitoring.

### Error Handling in Spring Kafka

Kafka provides mechanisms for **handling failures** using Dead Letter Queues (DLQ) and retries.
```java
@KafkaListener(topics = "my-topic", groupId = "my-group", errorHandler = "customErrorHandler")  
public void listen(String message) {  
    throw new RuntimeException("Error processing message!");  
}  
  
@Bean  
public KafkaListenerErrorHandler customErrorHandler() {  
    return (m, e) -> {  
        System.out.println("Error handling message: " + m.getPayload());  
        return null; // Custom retry or DLQ logic  
    };  
}
```
This allows messages to be retried or redirected to a Dead Letter Queue.

### Performance Benchmarks

1.  **Handles millions of messages per second** with optimized partitioning.
2.  **Scalability** → Performance improves by increasing partitions and consumers.
3.  **Latency** → Typically **in single-digit milliseconds**, depending on cluster configuration.
4.  **Backpressure Handling** → Kafka’s **pull-based model** prevents consumers from being overwhelmed.

### Deployment and Scaling

Kafka is cloud-native and integrates well with Kubernetes:  
1. **Kafka on Kubernetes** → Uses Strimzi Operator & Headless Services for better scaling.

**2. Scaling Kafka Brokers** → Increase the number of brokers dynamically.

3. **Replication Factor** → Ensures high availability by replicating partitions.

4. **Monitoring & Metrics** → Uses Prometheus, Grafana, and Confluent Control Center for observability.

5. **Kafka Connect** → Allows scaling connectors for integrating external systems, such as databases or file systems.

6. **Kafka Tiered Storage** (available in Confluent) → Helps manage long-term retention of messages without scaling storage vertically.

### Implementation in Spring Boot

###### 1. Add Dependencies
```java
<dependency>  
    <groupId>org.springframework.kafka</groupId>  
    <artifactId>spring-kafka</artifactId>  
</dependency>
```
###### 2. Reactive Kafka Producer (Using Project Reactor)
```java
@Service  
public class KafkaProducerService {  
    private final ReactiveKafkaProducerTemplate<String, String> reactiveKafkaTemplate;  
  
    public KafkaProducerService(ReactiveKafkaProducerTemplate<String, String> reactiveKafkaTemplate) {  
        this.reactiveKafkaTemplate = reactiveKafkaTemplate;  
    }  
    public Mono<SenderResult<Void>> sendMessageAsync(String topic, String message) {  
        return reactiveKafkaTemplate.send(topic, message);  
    }  
}
```

Note: Reactive Kafka support was introduced with Spring Kafka 2.6.x

###### 3. Kafka Consumer (Manual Offset Commit for At-Least-Once)
```java
@Service  
public class KafkaBatchConsumerService {  
    @KafkaListener(topics = "my-topic", groupId = "my-group")  
    public void listen(@Payload List<String> messages, Acknowledgment acknowledgment) {  
        messages.forEach(System.out::println);  
        acknowledgment.acknowledge(); // Manual Offset Commit  
    }  
}
```

Manual offset commits are important for ensuring “at-least-once” processing in scenarios where duplicate messages need to be handled.

###### 4. Confluent Schema Registry (Avro/Protobuf for Strongly Typed Messages)
```java
@Bean  
public KafkaAvroSerializer kafkaAvroSerializer() {  
    return new KafkaAvroSerializer();  
}
```

###### 5. Kafka Streams Example
```java
@Configuration  
@EnableKafkaStreams  
public class KafkaStreamsConfig {  
    @Bean  
    public KStream<String, String> kStream(StreamsBuilder builder) {  
        KStream<String, String> stream = builder.stream("input-topic");  
        stream.mapValues(value -> value.toUpperCase()).to("output-topic");  
        return stream;  
    }  
}
```
###### 6. Kafka Transactional Producer (Exactly-Once Processing with EOS v2)
```java
@Bean  
public KafkaTemplate<String, String> transactionalKafkaTemplate() {  
    KafkaTemplate<String, String> kafkaTemplate = new KafkaTemplate<>(producerFactory());  
    kafkaTemplate.setTransactionIdPrefix("txn-");  
    return kafkaTemplate;  
}
```

###### 7. Idempotent Producer Settings (Preventing Duplicate Messages)
```java
@Bean  
public ProducerFactory<String, String> producerFactory() {  
    Map<String, Object> configProps = new HashMap<>();  
    configProps.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true);  
    return new DefaultKafkaProducerFactory<>(configProps);  
}
```
### Troubleshooting & Debugging

1. **Consumer Lag** → Monitor with Kafka tools like kafka-consumer-groups.sh.  
2. **Partition Reassignment** → Use kafka-reassign-partitions.sh to rebalance partitions.  
3. **Message Loss** → Ensure proper `acks` settings and exactly-once semantics.  
4. **Slow Consumers** → Optimize with multi-threaded consumers and batch processing.  
5. **Debugging Kafka Streams** → Use tools like `KStream.debug()` to trace transformations and identify bottlenecks.

### Interview Questions

###### 1. How does Kafka ensure message ordering within a partition? What happens when multiple consumers consume messages from the same partition, and how does Kafka manage the message order in this case?

In Kafka, **message ordering** is guaranteed **within a partition**, but **not across partitions**. Here’s how Kafka ensures ordering and handles message consumption when multiple consumers are involved:

###### Message Ordering in a Partition:

-   Kafka guarantees that messages are **consumed in the same order they were produced** within a single partition. The order is preserved because Kafka uses an **append-only log** structure for each partition, where messages are stored sequentially.
-   Each message within a partition is assigned an **offset**, which acts as a unique identifier for the message in that partition. Consumers track these offsets to know which message they should consume next.

###### Multiple Consumers in a Consumer Group:

When you have multiple consumers in a **consumer group**, Kafka splits the partitions across the consumers, ensuring that each partition is consumed by **only one consumer at a time**. However, message ordering within the partition is still preserved:

-   If there are **multiple partitions**, each partition can be assigned to a different consumer. So, multiple consumers might be consuming messages from different partitions simultaneously.
-   If there’s **only one partition**, only **one consumer** from the group will consume messages from that partition, ensuring strict ordering.

###### Multiple Consumers Consume from the Same Partition:

-   **One Consumer per Partition:** Within a consumer group, **only one consumer** can consume messages from a given partition at any point in time. This ensures that message order is maintained, as no two consumers will read the same partition concurrently.
-   **Rebalancing and Ordering:** If a consumer crashes or leaves the group, Kafka triggers **rebalancing**, and another consumer is assigned to the partition that the failed consumer was consuming from. During this rebalancing, Kafka ensures that the consumer takes over at the correct offset, maintaining the order.

###### Managing Message Order:

Kafka handles the ordering by enforcing that each partition can only be read by one consumer at a time (within a consumer group). This prevents any out-of-order consumption in a single partition.

However, if there are multiple partitions, Kafka does not guarantee order **across partitions**, only **within each partition**.

###### Code Example:

**Producer Code (Sending Messages to Kafka):**
```java
Producer<String, String> producer = new KafkaProducer<>(props);  
producer.send(new ProducerRecord<>("my-topic", "key1", "message1"));  
producer.send(new ProducerRecord<>("my-topic", "key2", "message2"));
```
**Consumer Code (Consuming Messages from Kafka):**
```java
Properties properties = new Properties();  
properties.put("bootstrap.servers", "localhost:9092");  
properties.put("group.id", "my-consumer-group");  
properties.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");  
properties.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");  
  
KafkaConsumer<String, String> consumer = new KafkaConsumer<>(properties);  
consumer.subscribe(Arrays.asList("my-topic"));  
while (true) {  
    ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(100));  
    for (ConsumerRecord<String, String> record : records) {  
        System.out.println("Consumed message with key " + record.key() + " and value " + record.value() + " at offset " + record.offset());  
    }  
}
```
In this consumer code, **each consumer** will receive messages in order, based on the offset for the partition they are consuming from.

###### 2. What happens if a producer sends a message to a Kafka topic, and no consumers are available or subscribed? Does Kafka queue the message, or does it discard it?

In Kafka, if a producer sends a message to a topic and no consumers are available or subscribed, **Kafka stores the message in the topic’s partition as part of its log storage mechanism**.

Unlike traditional Message-Oriented Middleware (MOM) systems such as RabbitMQ or ActiveMQ, **Kafka does not delete messages after they are read**. Instead, it retains messages based on a **configured retention policy (**`**retention.ms**`**)**, allowing multiple consumers to read them at different times.

###### Message Storage and Consumer Behavior:

-   Kafka topics are divided into **partitions**, and each partition **acts as an append-only log** where messages are sequentially stored.
-   **Messages in Kafka topics are not removed when consumed.** Instead, Kafka maintains an **offset** for each consumer, tracking how far they have read.
-   This differs from **traditional queues**, where a message is **removed from the queue as soon as a consumer reads it**.
-   If no consumers are subscribed or available, messages **remain in the partition until either:**

a) A consumer reads them, or

b) The **retention period expires**, at which point Kafka automatically deletes them to free up space.

###### Retention Policy:

Kafka retains messages based on **time-based (**`**retention.ms**`**)** or **size-based (**`**log.retention.bytes**`**)** policies:

-   By default, messages are stored for **7 days**, but this can be adjusted using the `retention.ms` property.
-   If no consumers read the messages within this period, Kafka automatically removes them.

###### Producer Behavior:

-   **Producers are independent of consumers.** They write messages to Kafka **whether or not consumers are online**.
-   Kafka guarantees **message durability** based on:

**a) Replication factor** (to prevent data loss).

**b) Acknowledgment settings (**`**acks**`**)** to ensure message reliability.

-   Messages remain available for multiple consumers **within the retention period**, supporting event replay and fault tolerance.

###### Example:

To set a **1-day retention period (86400000 ms) for a topic:**
```shell
kafka-topics.sh --alter --topic my-topic --config retention.ms=86400000
```
This ensures messages in `**my-topic**` will be stored for **one day**, after which they will be deleted **if they haven’t been consumed**.

###### 3. How do idempotent producers help achieve exactly-once semantics in Kafka, and why is this important in distributed systems?

Idempotent producers in Kafka help achieve exactly-once semantics (EOS) by ensuring that a message is only written once to a Kafka topic, even if the producer retries sending the same message due to network issues, timeouts, or failures. This is crucial in distributed systems where message duplication or loss can lead to inconsistent or incorrect data.

###### Idempotent Producers:

-   Kafka’s **idempotent producer** ensures that a message is sent only once to a partition, regardless of retries.
-   When enabled, Kafka uses the combination of a **producer’s sequence number** and **broker-side deduplication** to identify and discard duplicate messages. This prevents the same message from being written multiple times to the same partition, even if the producer tries to send it multiple times.

###### Exactly-Once Semantics (EOS):

-   Exactly-once semantics ensures that messages are neither lost nor duplicated, and they are processed exactly once by consumers.
-   This is important because in distributed systems, network failures, crashes, or retries can lead to scenarios where a message might be sent multiple times, causing inconsistencies in data processing.

###### Importance in Distributed Systems:

-   **Fault Tolerance**: Network issues, system crashes, or retries can lead to message duplication. EOS ensures that consumers process each message exactly once, even if failures occur.
-   **Data Consistency**: In use cases like financial transactions, payment processing, or inventory management, ensuring that each message is processed exactly once is crucial to maintaining data consistency.
-   **Eliminates Duplication**: Without idempotent producers, consumers could process the same message more than once, leading to duplicated actions (e.g., processing an order twice).

###### Enabling Idempotence and Achieving EOS in Kafka:

To achieve exactly-once semantics, idempotent producers are enabled in Kafka, and consumers must also be configured to handle idempotent delivery.
```java
@Configuration  
public class KafkaProducerConfig {  
  
@Bean  
    public ProducerFactory<String, String> producerFactory() {  
        Map<String, Object> producerProps = new HashMap<>();  
        producerProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");  
        producerProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);  
        producerProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);  
          
        // Enabling idempotence  
        producerProps.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, "true");  
          
        // Configure retries and acks for strong delivery guarantees  
        producerProps.put(ProducerConfig.ACKS_CONFIG, "all");  
        producerProps.put(ProducerConfig.RETRIES_CONFIG, Integer.MAX_VALUE);  
        producerProps.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, 1);  
        return new DefaultKafkaProducerFactory<>(producerProps);  
    }  
    @Bean  
    public KafkaTemplate<String, String> kafkaTemplate() {  
        return new KafkaTemplate<>(producerFactory());  
    }  
}
```
###### Configurations:

-   **ENABLE_IDEMPOTENCE_CONFIG**: Setting this to `true` ensures the producer handles message retries and ensures exactly-once delivery.
-   **ACKS_CONFIG**: Setting this to `"all"` guarantees that the producer waits for acknowledgment from all replicas, ensuring durability.
-   **RETRIES_CONFIG**: Setting it to `Integer.MAX_VALUE` ensures the producer will retry indefinitely on transient errors.
-   **MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION**: Setting this to `1` ensures that Kafka will send only one request at a time per connection, avoiding out-of-order messages.

###### Ensuring EOS for Consumers:

To fully achieve exactly-once semantics, consumers must also be configured to commit offsets atomically along with processing messages.
```java
@Configuration  
@EnableKafka  
public class KafkaConsumerConfig {  
  
@Bean  
    public ConcurrentMessageListenerContainer<String, String> messageListenerContainer(            ConsumerFactory<String, String> consumerFactory) {  
        ContainerProperties containerProps = new ContainerProperties("my-topic");  
        containerProps.setMessageListener(new MessageListener<String, String>() {  
            @Override  
            public void onMessage(ConsumerRecord<String, String> record) {  
                // Handle the message here  
                System.out.println("Received: " + record.value());  
            }  
        });  
          
        // Enable auto commit of offsets to support exactly-once semantics  
        containerProps.setAckMode(AckMode.MANUAL_IMMEDIATE);  
        return new ConcurrentMessageListenerContainer<>(consumerFactory, containerProps);  
    }  
    @Bean  
    public ConsumerFactory<String, String> consumerFactory() {  
        Map<String, Object> consumerProps = new HashMap<>();  
        consumerProps.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");  
        consumerProps.put(ConsumerConfig.GROUP_ID_CONFIG, "my-consumer-group");  
        consumerProps.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);  
        consumerProps.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);  
        // Enable exactly-once semantics for consumers  
        consumerProps.put(ConsumerConfig.ISOLATION_LEVEL_CONFIG, "read_committed");  
        return new DefaultKafkaConsumerFactory<>(consumerProps);  
    }  
}
```
###### 4. How does Kafka handle load balancing when multiple consumers are in the same group, and what happens when a new consumer joins or an existing consumer fails?

When multiple consumers belong to the same Kafka consumer group, Kafka automatically assigns partitions from the topic to consumers within that group.

Each partition is consumed by exactly one consumer in the group at any time.

###### 1. Load Balancing:

-   Kafka assigns partitions to consumers in a way that ensures each partition is consumed by only one consumer at a time.
-   If you add more consumers, Kafka triggers a **rebalance** and redistributes the partitions among the consumers to balance the load.

###### 2. New Consumer Joining:

-   When a new consumer joins the group, Kafka reassigns partitions to ensure all consumers share the load evenly. This process is called **rebalancing**. For example,

If a topic has 4 partitions and 2 consumers, partitions will be distributed as follows:

-   Consumer 1: Partitions 0, 1
-   Consumer 2: Partitions 2, 3

If a 3rd consumer joins:

-   Consumer 1: Partition 0
-   Consumer 2: Partition 1
-   Consumer 3: Partitions 2, 3

###### 3. Consumer Failure:

-   If a consumer fails, Kafka triggers another rebalance, and partitions handled by the failed consumer are reassigned to the remaining consumers.
-   This ensures that there’s no interruption in processing, though there might be a slight delay during the rebalance.

###### Code Example:
```java
@Configuration  
@EnableKafka  
public class KafkaConsumerConfig {  
  
@Bean  
    public ConcurrentMessageListenerContainer<String, String> messageListenerContainer(            ConsumerFactory<String, String> consumerFactory) {  
        ContainerProperties containerProps = new ContainerProperties("my-topic");  
        containerProps.setMessageListener(new MessageListener<String, String>() {  
            @Override  
            public void onMessage(ConsumerRecord<String, String> record) {  
                // Handle the message here  
                System.out.println("Received: " + record.value());  
            }  
        });  
        ConcurrentMessageListenerContainer<String, String> container =  
                new ConcurrentMessageListenerContainer<>(consumerFactory, containerProps);  
        container.setConcurrency(3);  // Set the concurrency to handle multiple consumers  
        return container;  
    }  
    @Bean  
    public ConsumerFactory<String, String> consumerFactory() {  
        Map<String, Object> consumerProps = new HashMap<>();  
        consumerProps.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");  
        consumerProps.put(ConsumerConfig.GROUP_ID_CONFIG, "my-consumer-group");  
        consumerProps.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);  
        consumerProps.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);  
        return new DefaultKafkaConsumerFactory<>(consumerProps);  
    }  
}
```
###### 5. How would you optimize Kafka for high-throughput scenarios, and which producer configurations (e.g., batch size, linger.ms) would you tune?

In high-throughput scenarios, optimizing Kafka involves tuning both the **producer** and **consumer** settings to maximize efficiency and throughput.

###### Producer Configurations:

1.  **Batch Size (**`**batch.size**`**)**:

-   The `batch.size` configuration controls the maximum size of a batch of messages the producer will send in one request. Larger batches reduce the number of requests to the Kafka brokers, which can significantly improve throughput.
-   **Tuning**: Increase this value (e.g., 16MB or more) depending on the payload size, network latency, and available memory.

producerProps.put(ProducerConfig.BATCH_SIZE_CONFIG, 16384);  // 16KB batch size

**2. Linger Time (**`**linger.ms**`**)**:

-   The `linger.ms` setting controls how long the producer will wait before sending a batch of messages. By increasing this value, the producer waits a bit longer to accumulate more messages into a batch, thereby improving throughput at the cost of slight latency.
-   **Tuning**: Set this to a higher value (e.g., 5–10 ms) to allow more time for batches to fill.

producerProps.put(ProducerConfig.LINGER_MS_CONFIG, 10);  // 10ms linger time

**3. Compression Type (**`**compression.type**`**)**:

-   Enabling compression reduces the amount of data sent over the network, which improves throughput and reduces storage consumption. `snappy`, `gzip`, and `lz4` are popular compression algorithms.
-   **Tuning**: Use `snappy` for a good trade-off between compression and speed.

producerProps.put(ProducerConfig.COMPRESSION_TYPE_CONFIG, "snappy");

**4. Acks (**`**acks**`**)**:

-   Set to `all` to ensure the producer waits for acknowledgment from all in-sync replicas, ensuring durability and reliability. In high-throughput, however, this setting may slow down the producer slightly, so it might be worth adjusting depending on your consistency and durability needs.
-   **Tuning**: `acks=all` guarantees durability, but `acks=1` could be used for faster performance with lower consistency.

producerProps.put(ProducerConfig.ACKS_CONFIG, "all");

**5. Max In-Flight Requests (**`**max.in.flight.requests.per.connection**`**)**:

-   This setting controls the number of requests sent before waiting for a response from the broker. Higher values allow more concurrent requests, thus increasing throughput.
-   **Tuning**: A value of 5–10 is generally recommended.
```java
producerProps.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, 5);
```
###### Example Code with Optimizations:
```java
@Bean  
public KafkaTemplate<String, String> kafkaTemplate() {  
    Map<String, Object> producerProps = new HashMap<>();  
    producerProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");  
    producerProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);  
    producerProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);  
    producerProps.put(ProducerConfig.BATCH_SIZE_CONFIG, 16384); // 16KB  
    producerProps.put(ProducerConfig.LINGER_MS_CONFIG, 10);     // 10ms  
    producerProps.put(ProducerConfig.COMPRESSION_TYPE_CONFIG, "snappy");  
    producerProps.put(ProducerConfig.ACKS_CONFIG, "all");  
    producerProps.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, 5);  
  
    ProducerFactory<String, String> producerFactory = new DefaultKafkaProducerFactory<>(producerProps);  
    return new KafkaTemplate<>(producerFactory);  
}
```
###### Consumer Configuration:

To complement the producer optimizations, consumers also need to be tuned for high-throughput:

-   `**fetch.min.bytes**`: The minimum amount of data that the consumer should fetch in one request. Setting this to a higher value can help reduce the number of requests, improving throughput.
-   `**fetch.max.wait.ms**`: Configures the maximum time the consumer will wait for data before sending the fetch request. It can be tuned to improve throughput in high-latency scenarios.

###### Kafka Cluster Configurations:

1.  **Replication Factor**:

-   Ensure a higher replication factor (e.g., 3) to ensure fault tolerance while ensuring throughput remains high.

**2. Partition Count**:

-   Having more partitions allows Kafka to spread the load across multiple brokers, enabling better parallelism for high-throughput.

**3. Broker Settings**:

-   `**log.segment.bytes**`: Tuning the segment size helps Kafka handle disk I/O more efficiently.
-   `**num.io.threads**` **and** `**num.network.threads**`: Increase these to optimize resource utilization under heavy load.

###### 6. How does Kafka handle backpressure in high-load scenarios, and how does it affect consumer lag and throughput?

Backpressure is a condition that occurs when a system (in this case, the Kafka consumer) is overwhelmed by too much data and cannot process it fast enough. This leads to delays, queuing, or dropped messages.

In Kafka, backpressure is typically caused by consumers being slower than producers, leading to a growing backlog of unprocessed messages in the broker.

Kafka can handle backpressure by **pausing** message fetching from topics if the consumer is falling behind.

Consumers in Kafka can manually control the offsets they acknowledge, ensuring they only process messages at a pace they can handle. If consumers are overwhelmed, they can **slow down the fetching** process, preventing excessive consumption.

**Consumer Code (Manual Offset Commit):**
```java
@Service  
public class KafkaBatchConsumerService {  
    @KafkaListener(topics = "my-topic", groupId = "my-group")  
    public void listen(@Payload List<String> messages, Acknowledgment acknowledgment) {  
        // Process the messages here  
        messages.forEach(System.out::println);  
  
        // Acknowledge after processing  
        acknowledgment.acknowledge();  
    }  
}
```
In the example above, **manual offset commit** ensures that messages are only acknowledged after they’ve been processed.

If the consumer crashes before acknowledging, Kafka will retry those messages, maintaining **at-least-once delivery**.

**Backpressure Monitoring with Consumer Lag:**

Kafka’s **consumer lag** can be monitored to detect backpressure. For example, you can use **Burrow** or **Kafka’s built-in consumer lag tool** to track lag and decide if scaling or optimizations are needed.
```shell
kafka-consumer-groups.sh --bootstrap-server <kafka-broker> --describe --group my-group
```
If lag is high, you may need to scale consumers horizontally to handle the increased load.

**Scaling Consumers:**

You can add more consumers in a group to balance the load across partitions, which helps to reduce lag.
```java
@KafkaListener(topics = "my-topic", groupId = "my-group")  
public void listen(String message) {  
    // Process the message  
    System.out.println(message);  
}
```

By adding more consumers, Kafka will distribute the partitions among them, improving throughput and reducing lag.

**Throughput Management:**

To avoid throttling in high-load scenarios, producers can be configured to handle retries and acknowledgments, helping smooth over temporary backpressure.

**Producer Code (Retries and Acknowledgments):**
```java
@Bean  
public KafkaTemplate<String, String> kafkaTemplate() {  
    Map<String, Object> producerProps = new HashMap<>();  
    producerProps.put(ProducerConfig.RETRIES_CONFIG, 3);  
    producerProps.put(ProducerConfig.ACKS_CONFIG, "all"); // Ensure all brokers acknowledge  
      
    ProducerFactory<String, String> producerFactory = new DefaultKafkaProducerFactory<>(producerProps);  
    return new KafkaTemplate<>(producerFactory);  
}
```
This config ensures that the producer will **retry sending messages** in case of failure and waits for acknowledgment from all brokers to ensure message durability.

###### 7. How do you configure Kafka producers and consumers in Spring Boot to ensure guaranteed message delivery (e.g., using ACKs, retries, and transactions)?

To ensure **guaranteed message delivery** in Kafka using Spring Boot, you can configure **producers** and **consumers** to use **acks**, **retries**, and **transactions** for **durable and reliable messaging**.

###### 1. Kafka Producer Configuration for Guaranteed Delivery

In Kafka, producers can ensure message delivery guarantees using the following mechanisms:

-   **Acknowledgments (ACKs)**: The number of acknowledgments the producer requires from Kafka brokers before considering a request as successful.
-   **Retries**: Retry logic in case of message delivery failure.
-   **Transactions**: Ensure atomicity and message delivery guarantees across multiple Kafka topics or partitions.

###### Producer Configuration for Guaranteed Delivery

Here’s how you can configure the Kafka producer in **Spring Boot** for guaranteed message delivery.

**application.properties**:
```java
spring.kafka.producer.bootstrap-servers=localhost:9092  
spring.kafka.producer.key-serializer=org.apache.kafka.common.serialization.StringSerializer  
spring.kafka.producer.value-serializer=org.apache.kafka.common.serialization.StringSerializer  
  
### Set acks to "all" for the highest level of guarantee (Wait for all replicas to acknowledge)  
spring.kafka.producer.acks=all  
### Set retries to ensure messages are re-sent in case of failures  
spring.kafka.producer.retries=3  
### Configure a max retry timeout  
spring.kafka.producer.retry-backoff-ms=1000  
### Enable transactions  
spring.kafka.producer.transaction-id-prefix=txn-
```
-   `**acks=all**`: Ensures the message is acknowledged by all brokers before being considered successfully sent.
-   `**retries=3**`: Retries sending the message up to 3 times in case of failure.
-   `**retry-backoff-ms=1000**`: Waits for 1 second between retries.
-   `**transaction-id-prefix=txn-**`: Specifies a transaction prefix, enabling the producer to send messages in a transaction. This ensures atomicity across multiple Kafka topic partitions.

###### Producer Code Example (Using Transactions):
```java
@Service  
public class KafkaProducerService {  
  
@Autowired  
    private KafkaTemplate<String, String> kafkaTemplate;  
    @Transactional  
    public void sendMessage(String topic, String message) {  
        try {  
            kafkaTemplate.send(topic, message);  
        } catch (Exception e) {  
            // Handle error (e.g., log it, retry, etc.)  
            System.err.println("Failed to send message: " + e.getMessage());  
        }  
    }  
}
```
`**@Transactional**` ensures that messages are sent atomically as part of a single transaction, meaning if a failure occurs, no partial messages will be sent.

###### 2. Kafka Consumer Configuration for Guaranteed Delivery

To guarantee reliable message processing and delivery to consumers, you can use manual **offset commits**, **retries**, and **dead-letter queues (DLQs)** in case of processing failures.

###### Consumer Configuration for Guaranteed Delivery

**application.properties**:
```java
spring.kafka.consumer.bootstrap-servers=localhost:9092  
spring.kafka.consumer.group-id=my-group  
spring.kafka.consumer.key-deserializer=org.apache.kafka.common.serialization.StringDeserializer  
spring.kafka.consumer.value-deserializer=org.apache.kafka.common.serialization.StringDeserializer  
  
### Enable manual offset commit  
spring.kafka.consumer.enable-auto-commit=false  
### Set consumer retries  
spring.kafka.consumer.max-poll-records=10  
spring.kafka.consumer.retries=3  
spring.kafka.consumer.retry-backoff-ms=1000
```
-   `**enable-auto-commit=false**`: Disables automatic offset commits. This ensures we can commit offsets manually after successfully processing the message.
-   `**retries=3**`: Retries processing messages if an error occurs.
-   `**retry-backoff-ms=1000**`: Waits for 1 second between retries.

###### Consumer Code Example (Manual Offset Commit):
```java
@Service  
public class KafkaConsumerService {  
  
@KafkaListener(topics = "my-topic", groupId = "my-group")  
    public void processMessage(ConsumerRecord<String, String> record, Acknowledgment acknowledgment) {  
        try {  
            // Simulate message processing  
            System.out.println("Processing message: " + record.value());  
            // After processing, manually commit the offset  
            acknowledgment.acknowledge();  
        } catch (Exception e) {  
            // Handle error (e.g., retry, log, send to DLQ)  
            System.err.println("Failed to process message: " + e.getMessage());  
        }  
    }  
}
```
###### Handling Errors (DLQ):

To handle errors, you can configure a **Dead Letter Queue (DLQ)** where failed messages are sent after a certain number of retries.
```java
### DLQ Configuration  
spring.kafka.consumer.dead-letter-publisher.enabled=true  
spring.kafka.consumer.dead-letter-topic=my-dlq-topic  
spring.kafka.consumer.dead-letter-publisher.retries=5  
spring.kafka.consumer.dead-letter-publisher.retry-backoff-ms=2000
```

###### 8. What happens if a Kafka consumer crashes after consuming a message but before processing it? How do you ensure at-least-once processing, and how can you configure Spring Kafka to handle manual offset commits?

If a Kafka consumer crashes after consuming a message but before processing it, it can lead to re-processing of the same message when the consumer restarts.

This happens because Kafka only commits the offset after a message has been processed, ensuring **at-least-once delivery**. The downside is that if the consumer crashes before committing the offset, the message will be re-consumed when the consumer recovers, which could lead to **duplicate processing**.

###### At-Least-Once Processing in Kafka

Kafka ensures **at-least-once** semantics by allowing consumers to manually commit offsets. This ensures that messages are only marked as successfully processed after the business logic has been applied, preventing message loss but potentially causing duplicates.

###### Handling This with Spring Kafka

To ensure **at-least-once processing** in **Spring Kafka**, you can configure **manual offset commits**. This allows you to commit the offset only after successful processing, preventing Kafka from marking a message as consumed until you’ve fully processed it.

###### Steps to Implement:

1.  **Disable auto-commit** to manage the offsets manually.
2.  **Commit the offset after successful processing** in the listener method.
3.  Use the `Acknowledgment` interface to manually commit offsets.

###### Example:
```java
@EnableKafka  
@SpringBootApplication  
public class KafkaConsumerApplication {  
  
public static void main(String[] args) {  
        SpringApplication.run(KafkaConsumerApplication.class, args);  
    }  
    // Consumer method with manual offset commit  
    @KafkaListener(topics = "my-topic", groupId = "consumer-group")  
    public void processMessage(ConsumerRecord<String, String> record, Acknowledgment acknowledgment) {  
        try {  
            // Business logic: Process the message  
            System.out.println("Processing message: " + record.value());  
            // After processing, manually commit the offset  
            acknowledgment.acknowledge();  // Commit the offset explicitly  
        } catch (Exception e) {  
            // Handle failure (could be retry, DLQ, etc.)  
            System.err.println("Error processing message: " + e.getMessage());  
        }  
    }  
    // Kafka Listener Container Configuration  
    @Bean  
    public ConcurrentMessageListenerContainerFactory<String, String> kafkaListenerContainerFactory() {  
        ConcurrentMessageListenerContainerFactory<String, String> factory = new ConcurrentMessageListenerContainerFactory<>();  
        // Optional: Custom retry or error handling logic  
        factory.setMessageListener(new RetryMessageListener());  
        return factory;  
    }  
}
```

###### Breakdown:

1.  `**@KafkaListener**`: This annotation marks the method to listen to messages from the Kafka topic.
2.  `**Acknowledgment**`: This object allows us to explicitly acknowledge (commit) the offset after the message has been processed successfully.
3.  **Manual Offset Commit**: By calling `acknowledgment.acknowledge()`, the consumer commits the offset only after processing the message, ensuring at-least-once delivery.
4.  **Error Handling**: In case of an exception during message processing, you could implement retry logic, send messages to a **Dead Letter Queue (DLQ)**, or log the error, depending on your use case.

###### Why This Works for At-Least-Once Delivery:

-   If the consumer crashes after receiving a message but before calling `acknowledge()`, the consumer will re-consume the message upon recovery because the offset wasn't committed.
-   This guarantees that every message is processed at least once, though it may lead to duplicate processing, which can be managed using **idempotent processing**.

###### 9. Write a Kafka Streams application that reads messages from one Kafka topic, transforms them by converting all text to uppercase, and writes the transformed messages to another topic.
```java
StreamsBuilder builder = new StreamsBuilder();  
KStream<String, String> input = builder.stream("input-topic");  
input.mapValues(value -> value.toUpperCase())  
     .to("output-topic", Produced.with(Serdes.String(), Serdes.String()));  
  
KafkaStreams streams = new KafkaStreams(builder.build(), streamsConfig);  
streams.start();
```

###### 10. Write a Kafka consumer that processes messages from a topic. If the message processing fails, the message should be sent to a dead-letter queue for further inspection.
```java
@KafkaListener(topics = "input-topic", groupId = "consumer-group")  
public void processMessage(String message) {  
    try {  
        // Simulate processing  
        System.out.println("Processing message: " + message);  
        if (message.contains("error")) {  
            throw new RuntimeException("Simulated error");  
        }  
    } catch (Exception e) {  
        // Send to DLQ if processing fails  
        sendToDLQ(message);  
    }  
}  
  
public void sendToDLQ(String message) {  
    kafkaTemplate.send("dead-letter-topic", message);  
}
```

### Stop Using @KafkaListener Like This: The Spring Boot Anti-Pattern Nobody Talks About🔥
`@KafkaListener` is one of the most convenient features in Spring Boot. With just a single annotation, you can start consuming Kafka messages like magic. And that’s exactly the problem.

Most developers stop at the bare minimum: annotate a method, point it to a topic, and assume it “just works.” But under the hood, dangerous assumptions are being made — about error handling, retries, offset commits, message ordering, and concurrency.

> _In reality, most Spring Boot Kafka consumers are one production outage away from chaos — and it all starts with_ `_@KafkaListener_`_._

In this article, we’ll challenge the status quo and explore:

-   Why default configurations may hurt you in production
-   Subtle traps that can break message delivery guarantees
-   Threading, concurrency, and performance bottlenecks
-   Best practices to make your consumers rock solid

### The Common (and Dangerous) Assumptions🎯

Most tutorials and documentation examples look like this:
```java
@KafkaListener(topics = "orders", groupId = "order-service")  
public void listen(String message) {  
    System.out.println("Received message: " + message);  
}
```
Clean, simple, and elegant, right?

Yes — but also dangerously naive.

### The Problem?

This kind of implementation ignores:

-   **Error handling and retries**
-   **Threading behavior**
-   **Back-pressure handling**
-   **Manual vs. automatic offset commits**
-   **Message ordering guarantees**

That’s fine for dev environments or demo apps — but for production systems? It’s a recipe for disaster. Let’s break it all down.

### The Offset Commit Trap💣

By default, Spring Kafka commits offsets **automatically** after a successful listener method execution. That seems helpful — until it isn’t.

Let’s say you write to a database inside your listener:
```java
@KafkaListener(topics = "user-updates", groupId = "user-service")  
public void processUserUpdate(String message) {  
    User user = parseMessage(message);  
    userRepository.save(user); // might fail!  
}
```
If the `save` operation throws an exception **after** the message has been committed, that message is lost. Forever. ☠️

### The Fix: Manual Acknowledgment🔐

You can take control using manual acknowledgment:
```java
@KafkaListener(topics = "user-updates", groupId = "user-service")  
public void processUserUpdate(ConsumerRecord<String, String> record, Acknowledgment ack) {  
    try {  
        User user = parseMessage(record.value());  
        userRepository.save(user);  
        ack.acknowledge(); // commit offset only after success  
    } catch (Exception e) {  
        // log and handle the error  
    }  
}
```

This gives you **at-least-once** semantics while avoiding silent message loss.

### Retries: Not What You Think🔄

Spring Kafka automatically retries failed messages **in the same listener thread**, unless you explicitly configure a retry mechanism.

This means:

-   Your listener will **block** during retries
-   You risk **consumer lag** if a message fails repeatedly
-   There’s **no dead-letter queue (DLQ)** unless configured manually

### Best Practice: Use Error Handlers✅

Use a `SeekToCurrentErrorHandler` or `DeadLetterPublishingRecoverer` for fine-grained control:
```java
@Bean  
public DefaultErrorHandler errorHandler(KafkaTemplate<Object, Object> template) {  
    return new DefaultErrorHandler(  
        new DeadLetterPublishingRecoverer(template),  
        new FixedBackOff(1000L, 3) // 3 retries with 1s delay  
    );  
}
```

Then wire it in your container factory:
```java
@Bean  
public ConcurrentKafkaListenerContainerFactory<String, String> kafkaListenerContainerFactory(  
        ConsumerFactory<String, String> consumerFactory,  
        DefaultErrorHandler errorHandler) {  
    ConcurrentKafkaListenerContainerFactory<String, String> factory =  
        new ConcurrentKafkaListenerContainerFactory<>();  
    factory.setConsumerFactory(consumerFactory);  
    factory.setCommonErrorHandler(errorHandler);  
    return factory;  
}
```

This makes retries predictable and production-safe.

### Concurrency: The Hidden Bottleneck⚙️

You might think `@KafkaListener` just works magically with concurrency. But it doesn't unless you explicitly configure it.
```java
factory.setConcurrency(3);
```
This means **three consumer threads** (each consuming from different partitions). But:

-   You can’t consume faster than your partition count
-   Concurrency above partition count is useless
-   Stateful services (like DB transactions) must be thread-safe

💡 Pro tip: Monitor partition lag using Kafka monitoring tools and adjust concurrency accordingly.

### Message Ordering: You Might Be Breaking It🧩

Kafka guarantees **order within a partition**, not globally. But many Spring Kafka setups break ordering due to:

-   Excessive concurrency
-   Retry policies with random reprocessing
-   Manual seek or rebalancing logic

If ordering is critical (e.g., financial transactions), you must:

-   Limit concurrency to 1 for that topic
-   Use partition keying properly when producing
-   Avoid skipping failed messages arbitrarily

### Custom Deserialization: A Must for Safety🧠

Don’t just rely on default deserializers. When messages change (say you add a new field), consumers might crash with `JsonParseException`.

Instead, use robust deserialization:
```java
@Bean  
public ConsumerFactory<String, MyEvent> consumerFactory() {  
    JsonDeserializer<MyEvent> deserializer = new JsonDeserializer<>(MyEvent.class);  
    deserializer.setRemoveTypeHeaders(false);  
    deserializer.addTrustedPackages("*");  
    deserializer.setUseTypeMapperForKey(true);  
  
    return new DefaultKafkaConsumerFactory<>(props, new StringDeserializer(), deserializer);  
}
```
This guards against subtle serialization issues that crash listeners.

### Rebalancing Chaos🕸️

When a Kafka consumer group changes (a pod restarts, new instance added), Kafka **triggers a rebalance**.

This means:

-   Consumer threads pause
-   Messages may be reprocessed
-   You could commit offsets prematurely

### The Solution: Graceful Shutdown🧘‍♂️

Hook into Spring’s lifecycle to close the container gracefully:
```java
@PreDestroy  
public void onShutdown() {  
    listenerContainer.stop(); // avoid rebalance chaos  
}
```

Also, set `max.poll.interval.ms` and `session.timeout.ms` wisely to balance stability and responsiveness.

### Observability: Don’t Fly Blind🔍

You can’t fix what you can’t see. And Spring Kafka doesn’t log everything by default.

Ensure you:

-   Enable consumer lag metrics via Micrometer or Prometheus
-   Monitor failed messages and retries
-   Track offset commits and rebalances

Kafka is not “fire and forget” — it’s “observe and respond continuously.”

### So… Are We Doing It All Wrong?🧭

If your Kafka consumer setup:

-   Uses `@KafkaListener` without error handling
-   Commits offsets automatically
-   Ignores retries and back-pressure
-   Has no observability

Then… yeah, you’re probably doing it all wrong. 😅

But you’re not alone — and the fix isn’t hard. With a few tweaks, you can move from “it works on my machine” to rock-solid, production-ready consumers.

### Takeaways✅

Let’s wrap with some battle-tested best practices:

-   **Always handle errors explicitly**: Don’t trust the default behavior.
-   **Use manual acknowledgment** when side-effects (like DB writes) matter.
-   **Configure a proper retry + DLQ** strategy.
-   **Tune concurrency** based on partition count and system capacity.
-   **Preserve message ordering** where needed — don’t rely on luck.
-   **Set timeouts and shutdowns smartly** to avoid rebalancing hell.
-   **Make your deserializers fail-safe** and forward-compatible.
-   **Observe everything** — logs, metrics, offsets, retries.

Spring Boot and Kafka are powerful allies, but only if we respect their complexity.

---
