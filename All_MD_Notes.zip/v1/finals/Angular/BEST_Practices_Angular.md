# Angular Best Practices Every Developer Needs to Know

#### 1. Avoiding logic in Angular templates

Avoiding logic in Angular templates helps maintain cleaner, more maintainable code. Here's why and how you should do it:

**Why Avoid Logic in Templates?**

1.  **Performance Optimization** — Function calls in templates are executed repeatedly during change detection, which can impact performance.
2.  **Better Testability** — Moving logic to the component makes it easier to write unit tests.
3.  **Improved Maintainability** — Keeping business logic separate from the template reduces the risk of breaking functionality when modifying the UI.
4.  **Enhanced Readability** — Templates remain clean and focused on presentation rather than logic.

**How to Extract Logic from Templates**

Instead of doing this:
```html
<div *ngIf="isUserLoggedIn()">{{ getUserName() }}</div>
```

Move the logic to the component:
```javascript
export class ExampleComponent {  
  isLoggedIn = false;  
  userName = '';  
  
  constructor(private authService: AuthService) {  
    this.isLoggedIn = this.authService.isAuthenticated();  
    this.userName = this.authService.getUserName();  
  }  
}
```

Then use it in the template:
```html
<div *ngIf="isLoggedIn">{{ userName }}</div>
```
This ensures the function isn't re-evaluated unnecessarily and improves performance.

#### 2. Using Aliases for Cleaner Imports

In a deep folder structure, import paths can become long and messy.

Using **aliases** can help keep your import paths clean and manageable in such projects with deep folder structures.

**Example of bad imports:**
```javascript
import { MyComponent } from '../../../components/MyComponent';
```
This import path is **long**, **hard to understand**, and **can easily break** when files are moved around.

Instead, **aliases** allow you to define a short path to access files and components, **improving clarity** and **reducing the chances of errors**.

In Angular projects, **aliases** are set up in the **tsconfig.json** file.

Here's an example:

In the **tsconfig.json** file, we will use the **paths property** to define **aliases**.
```json
"compilerOptions": {  
  "baseUrl": "./",  
  "paths": {  
    "@app/*": ["src/app/*"],  
    "@services/*": ["src/app/services/*"],  
    "@components/*": ["src/app/components/*"]  
  }  
}
```
Once you've set up your **aliases**, you can use them in your **imports**.

For example:
```javascript
import { MyComponent } from '@components/MyComponent';
```
Instead of writing a long import path like:
```javascript
import { MyComponent } from '../../../components/MyComponent';
```
**How Aliases Improve Your Workflow:**

-   **Improved Readability**: Aliases make it clear where your files are located. For instance, @components or @services give a clear context of what's being imported, making your codebase easier to navigate.
-   **Refactoring Made Easy**: You can move files, folders, or entire sections of your application without worrying about breaking import paths throughout your project.
-   **Consistency**: With aliases, your import paths are consistent across the entire project, reducing the chance of errors.

#### 3. Avoid Nested Subscriptions in RxJS

When handling multiple streams of data (like user input, API requests, or events), a common mistake is **subscribing inside another subscription**.

This leads to the following main problems:

1.  **Multiple ongoing requests** → If a new request starts before the previous one finishes, multiple requests run at the same time.
2.  **Race conditions** → The responses don't always come back in order, so old data can overwrite new data.
3.  **Memory leaks** → Unnecessary active subscriptions can slow down the app and use extra memory.

Instead, we should use **switchMap**

**switchMap** makes sure that only **the latest request is completed** and **all previous requests are canceled**

**How This Looks in Code (Nested Subscriptions)**
```javascript
pickupLocation$.subscribe(location => {  
  findDriver$(location).subscribe(driver => {  
    console.log(`Driver assigned: ${driver}`);  
  });  
});
```
**Problem:**

-   If you update your location multiple times, multiple driver searches run at the same time.
-   The first request may return **after** the second, assigning the wrong driver.

#### Using switchMap (Cancels Old Requests)
```javascript
pickupLocation$.pipe(  
  switchMap(location => findDriver$(location)) // Cancels old requests  
).subscribe(driver => {  
  console.log(`Driver assigned: ${driver}`);  
});
```
**Fixed Problems:**

-   **Only one active search at a time** (old requests are canceled).
-   **Always get the correct driver for your latest request** (no outdated responses).

Using switchMap ensures only the latest request matters, preventing outdated responses, unnecessary operations

#### 4. Breaking large components into smaller, reusable components

As an Angular application grows, components tend to become large and difficult to maintain.

A single component that handles multiple responsibilities is harder to debug, test, and manage.

So, the idea is to **split the large component into smaller ones** that follows the **Single Responsibility Principle (SRP),** meaning each handle a specific task.

This way, you can test, debug, and reuse each smaller component more easily.

**Example: Transforming a Large Component**

Let's say we have a large Angular component that:

-   Displays a list of items.
-   Filters items based on a search input.

**Before Splitting: The Large Component**
```html
<!-- main.component.html -->  
<div>  
  <input [(ngModel)]="searchTerm" placeholder="Search..." />  
  <div *ngFor="let item of filterItems(items, searchTerm)">  
    <h3>{{ item.title }}</h3>  
    <p>{{ item.description }}</p>  
  </div>  
</div>
```
```javascript
// main.component.ts  
export class MainComponent {  
  items = [  
    { title: 'fist item', description: 'Description of Item 1' },  
    { title: 'second item', description: 'Description of Item 2' },  
    { title: 'third item', description: 'Description of Item 3' }  
  ];  
  searchTerm = '';  
  
  filterItems(items: any[], term: string) {  
    return items.filter((item) => item.title.includes(term));  
  }  
}
```
**After Splitting: Smaller Components**

To make the component more reusable, we break it down into:

1.  **Search Bar Component** — Handles search input.
2.  **Item List Component** — Displays a list of items.
3.  **Item Component** — Displays a single item.
4.  **Search Bar Component (search-bar.component.ts)**
```html
<!-- search-bar.component.html -->  
<input [(ngModel)]="searchTerm" (input)="search.emit(searchTerm)" placeholder="Search..." />
```
```javascript
// search-bar.component.ts  
import { Component, EventEmitter, Output } from '@angular/core';  
  
@Component({  
  selector: 'app-search-bar',  
  templateUrl: './search-bar.component.html',  
})  
export class SearchBarComponent {  
  @Output() search = new EventEmitter<string>();  
  searchTerm: string = '';  
}
```
**2. Item Component (item.component.ts)**
```html
<!-- item.component.html -->  
<h3>{{ item.title }}</h3>  
<p>{{ item.description }}</p>
```
```javascript
// item.component.ts  
import { Component, Input } from '@angular/core';  
  
@Component({  
  selector: 'app-item',  
  templateUrl: './item.component.html',  
})  
export class ItemComponent {  
  @Input() item: any;  
}
```
**3. Item List Component (item-list.component.ts)**
```html
<!-- item-list.component.html -->  
<div *ngFor="let item of items">  
  <app-item [item]="item"></app-item>  
</div>
```
```javascript
// item-list.component.ts  
import { Component, Input } from '@angular/core';  
  
@Component({  
  selector: 'app-item-list',  
  templateUrl: './item-list.component.html',  
})  
export class ItemListComponent {  
  @Input() items: any[] = [];  
}
```
**4. Updated Main Component (main.component.ts)**
```html
<!-- main.component.html -->  
<app-search-bar (search)="searchTerm = $event"></app-search-bar>  
<app-item-list [items]="filterItems(items, searchTerm)"></app-item-list>
```
```javascript
// main.component.ts  
import { Component } from '@angular/core';  
  
@Component({  
  selector: 'app-main',  
  templateUrl: './main.component.html',  
})  
export class MainComponent {  
  items = [  
    { title: 'Item 1', description: 'Description of Item 1' },  
    { title: 'Item 2', description: 'Description of Item 2' },  
    { title: 'Item 3', description: 'Description of Item 3' }  
  ];  
  searchTerm = '';  
  
  filterItems(items: any[], term: string) {  
    return items.filter((item) => item.title.includes(term));  
  }  
}
```
#### **Why Break Large Components?**

· **Easier to Debug & Maintain** — Smaller components mean fewer things can go wrong. If a bug appears, it's easier to **isolate** and fix.

· **Better Code Organization** — Each component handles one task, making the project easier to navigate.

· **Better Reusability** — Extracting common UI elements prevents duplicate code.

· **Improved Readability** — Smaller files are easier to navigate.

· **Faster Testing** — Unit testing becomes much simpler because each component has a single purpose.

#### 5. Documenting code

Documenting code with comments is an excellent practice, because it improves code maintainability, readability, and collaboration, making it easier for new developers (or even yourself in the future) to understand the logic.

**Example 1: Documenting a Method**
```javascript
/**  
 * This method converts a given age into a string.  
 * It takes a number as input and returns the string version of it.  
 *   
 * @param age The age value to be converted.  
 * @returns A string representation of the age value.  
 */  
function getAge(age: number): string {  
  return age.toString();  
}
```
**Example 2: Documenting a Variable**

For class variables, documenting them can also be helpful.
```javascript
class UserProfile {  
  /**  
   * The name of the user.  
   * This is typically initialized when the user registers.  
   * @example "John Doe"  
   */  
  userName: string;  
  
  /**  
   * The age of the user in years.  
   * This is an optional field and may not be available for every user.  
   * @example 28  
   */  
  userAge?: number;  
}
```

**Angular Example: Documenting a Service Method**

In Angular services, you can document methods as follows:
```javascript
@Injectable({  
  providedIn: 'root'  
})  
export class UserService {  
  /**  
   * Fetches user data from the backend API.  
   * It sends a GET request to retrieve the user's profile information.  
   *   
   * @param userId The ID of the user whose data is to be fetched.  
   * @returns An Observable of the user's data.  
   */  
  getUserData(userId: string): Observable<User> {  
    return this.http.get<User>(`/api/users/${userId}`);  
  }  
}
```
Using clear, consistent commenting practices like this will make your code much more understandable.

#### 6. Keep components lean by delegating complex logic to services.

In Angular, **components** and **templates** serve distinct roles in the app architecture.

The general rule is: **components handle the logic**, and **templates handle the view**. However, to avoid bloating your components with too much logic, it's best to delegate business logic to **services**.

**Example: Without a Service (Bad Practice)**

Here, the component is doing too much.
```javascript
import { Component } from '@angular/core';  
  
@Component({  
  selector: 'app-products',  
  template: `<div *ngFor="let product of products">{{ product.name }}</div>`,  
})  
export class ProductsComponent {  
  products = [  
    { id: 1, name: 'Jacket' },  
    { id: 2, name: 'Sneakers' },  
  ];  
  
  filterProducts(search: string) {  
    return this.products.filter(product => product.name.includes(search));  
  }  
}
```
The filtering logic should be handled by a service instead.

**Example: With a Service (Good Practice)**

Move the logic to a service and inject it into the component.

**Step 1: Create the Service**
```javascript
import { Injectable } from '@angular/core';  
  
@Injectable({  
  providedIn: 'root',  
})  
export class ProductService {  
  private products = [  
    { id: 1, name: 'Jacket' },  
    { id: 2, name: 'Sneakers' },  
  ];  
  
  getProducts() {  
    return this.products;  
  }  
  
  filterProducts(search: string) {  
    return this.products.filter(product => product.name.includes(search));  
  }  
}
```
**Step 2: Use the Service in the Component**
```javascript
import { Component } from '@angular/core';  
import { ProductService } from '../services/product.service';  
  
@Component({  
  selector: 'app-products',  
  template: `<div *ngFor="let product of filteredProducts">{{ product.name }}</div>`,  
})  
export class ProductsComponent {  
  filteredProducts = [];  
  
  constructor(private productService: ProductService) {  
    this.filteredProducts = this.productService.getProducts();  
  }  
  
  searchProducts(search: string) {  
    this.filteredProducts = this.productService.filterProducts(search);  
  }  
}
```

#### **Why Delegate Logic to Services?**
· **Separation of Concerns** — The component handles UI, and the service handles logic.
· **Reusability** — ProductService can be used in multiple components.
· **Testability** — We can test the service separately.
· **Maintainability** — Easier to modify or expand.


## 1. Use Standalone Components Wisely

With Angular 14 introducing standalone components, you can now create components without tying them to an `NgModule`. This simplifies small components or features meant for lazy-loaded routes. However, don't rush to make everything standalone. It's best used when you want clear separation and don't need tight integration with a feature module. Keep consistency in mind—mixing module-based and standalone approaches can lead to confusion if not documented well.

## 2. Keep Component Classes Lean

A common mistake is stuffing too much logic into a component. Angular promotes separation of concerns. Keep your component's job limited to handling view logic and delegating complex operations to services. For example, if your component is managing a lot of business rules or state, extract that into a service or facade. This makes your code more testable and maintainable.

## 3. Take Advantage of Reactive Forms

Angular offers both template-driven and reactive forms, but for complex forms, reactive forms offer more control, scalability, and testability. You can dynamically add controls, apply custom validations, and listen to form changes in a declarative way. It's especially useful in enterprise applications where forms are dynamic or deeply nested.
```javascript
this.form = this.fb.group({  
  name: ['', Validators.required],  
  email: ['', [Validators.required, Validators.email]]  
});
```
Using `FormBuilder` and reactive patterns not only improves clarity but also enhances debugging.

## 4. Use Lazy Loading for Feature Modules

Lazy loading is essential for performance in large Angular applications. It allows you to load feature modules only when they're needed, reducing the initial bundle size. Define lazy routes in your `AppRoutingModule`:
```javascript
{ path: 'dashboard', loadChildren: () => import('./dashboard/dashboard.module').then(m => m.DashboardModule) }
```
Combine this with preloading strategies to further enhance user experience.

## 5. Avoid Logic in Templates

Templating should be kept as clean as possible. Avoid putting logic-heavy expressions inside the HTML. For example, instead of:
```html
<div *ngIf="user && user.isActive && user.role === 'admin'">
```
Do this in your component:
```javascript
get isAdminActiveUser(): boolean {  
  return this.user && this.user.isActive && this.user.role === 'admin';  
}
```

Then use:
```html
<div *ngIf="isAdminActiveUser">
```
It improves readability and makes it easier to write unit tests.

## 6. Embrace the Angular CLI

The Angular CLI isn't just for project scaffolding. It offers a ton of helpful commands: linting, building, testing, serving with proxy configurations, and generating boilerplate code. You can use:
```shell
ng generate component user-profile  
ng build --configuration=production
```
Custom schematics can even help enforce company-specific code patterns. Mastering the CLI will save you hours over the life of a project.

## 7. Use `async` Pipe in Templates

Instead of manually subscribing and unsubscribing to observables, use the `async` pipe in your templates. This handles subscriptions for you and avoids memory leaks:
```html
<div *ngIf="user$ | async as user">  
  Welcome, {{ user.name }}  
</div>
```
This way, you let Angular handle lifecycle management, keeping your components cleaner and safer.

## 8. Organize Project Structure

As your app grows, organization becomes crucial. Group files by features, not by type. Instead of a flat structure like:

/components  
/services  
/models

Use a modular feature-based layout:

/users  
  - user.component.ts  
  - user.service.ts  
  - user.model.ts  
  - user-routing.module.ts

This aligns well with Angular's module system and makes the app easier to scale and understand.

## 9. Keep Up with Angular Updates

Angular has a regular update schedule, and each version brings improvements and deprecations. Use tools like Angular Update Guide to safely upgrade your projects. Staying up-to-date not only gives you access to new features (like `signals` in Angular 17) but also keeps your app secure and performant.

Don't skip minor version upgrades for too long — they're easier to tackle incrementally than in one big batch.

## 10. Don't Ignore Testing

Angular makes it easy to test components, services, and directives using Jasmine and Karma. But beyond unit tests, consider adding integration and e2e tests with tools like Cypress or Playwright. For unit tests:
```javascript
it('should return true when user is admin', () => {  
  const user = { role: 'admin' };  
  expect(service.isAdmin(user)).toBeTrue();  
});
```
Good tests reduce bugs, document intent, and boost confidence when refactoring. Invest in a testing strategy early — it pays off in the long run.

--- 
### Angular Application Security

Security is a top priority for Angular applications, as security breaches can result in data leaks, unauthorized access, and loss of user trust. Angular applications handle sensitive user data and perform critical functions, robust protection. Angular includes built-in security features to address common vulnerabilities like XSS and CSRF, equipping developers with tools to safeguard their applications and users effectively.

```html
<iframe src="https://cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fstackblitz.com%2Fedit%2Fstackblitz-starters-22fu8pz8%3Fembed%3D1%26file%3Dsrc%252Fapp.component.html&amp;display_name=StackBlitz&amp;url=https%3A%2F%2Fstackblitz.com%2Fedit%2Fstackblitz-starters-22fu8pz8%3Fembed%3D1%26file%3Dsrc%252Fapp.component.html&amp;image=https%3A%2F%2Fsocial-img.staticblitz.com%2Fprojects%2Fstackblitz-starters-22fu8pz8%2Fc6d63aa7326966ca8850bd91b93b0485&amp;type=text%2Fhtml&amp;schema=stackblitz" allowfullscreen="" frameborder="0" height="400" width="745" title="stackblitz-starters-22fu8pz8 - StackBlitz" class="eo n fi dz bg" scrolling="no"></iframe>
```

### **Key Security Practices for Angular App Security**

1.  **XSS (Cross-site scripting) attack**
2.  **Preventing HTTP — level Vulnerabilities**
3.  **Secure Communication with APIs**
4.  **Enable Strict CSP & Offline Template Compiler**
5.  **Secure Development Best Practices**

### XSS (Cross-site scripting) attacks

Cross-site scripting (XSS) is a cyber-attack where hackers/attackers inject malicious scripts into web pages that other users visit. These scripts can then steal sensitive information like login credentials or cookies, or even take control of the user's actions on the site. Attackers often exploit vulnerabilities in websites that allow them to insert harmful code, such as through input fields or URL parameters. XSS attacks can affect any user interacting with the compromised page, making it a significant threat to online security. To prevent XSS attacks, developers need to sanitize and validate all user inputs and carefully manage how data is displayed on web pages to ensure it cannot execute harmful scripts.

![](https://miro.medium.com/v2/resize:fit:875/1*pDRmlSgXmo-OalyGBx8Djw.png)

Use Angular's DomSanitizer to convert untrusted values into trusted values. Use attribute binding for sanitization to prevent XSS attacks. Validate untrusted values depending on the security context (HTML, style, attributes, resources).

Angular categorizes data into different security contexts: HTML for content that should be treated as HTML (like inner HTML), Style for CSS styles, URL for links, and Resource URL security context for scripts that need to be loaded and run.

Angular identifies unsafe content in the input and automatically removes potentially harmful elements like `<script>` tags while retaining safe elements like `<p>` tags before displaying them on the webpage. This helps prevent security risks such as XSS attacks by sanitizing inputs before rendering them.

These methods in Angular mark a value as trusted for specific types:

1.  **bypassSecurityTrustScript**: Marks a value as trusted for use as a script.
2.  **bypassSecurityTrustStyle**: Marks a value as trusted for use in styles.
3.  **bypassSecurityTrustUrl**: Marks a value as trusted for use in URLs.
4.  **bypassSecurityTrustResourceUrl**: Marks a URL as trusted for loading resources.

They bypass Agular's default security checks to allow these values to be used safely in the specified contexts, helping to prevent security vulnerabilities when handling dynamic content.

To protect against XSS attacks on the server side in Angular applications, use a templating language that automatically escapes values. This prevents attackers from injecting malicious code into HTML generated on the server.

### Cross site request forgery (CSRF) attack

Cross site request forgery (CSRF), also known as XSRF, Sea Surf or Session Riding, is an attack vector that tricks a web browser into executing an unwanted action in an application to which a user is logged in.

A successful CSRF attack can be devastating for both the business and user. It can result in damaged client relationships, unauthorized fund transfers, changed passwords and data theft — including stolen session cookies.

![](https://miro.medium.com/v2/resize:fit:875/1*DuFVH1Lx8NMNbWCC84maLQ.png)

CSRFs are typically conducted using malicious social engineering, such as an email or link that tricks the victim into sending a forged request to a server. As the unsuspecting user is authenticated by their application at the time of the attack, it's impossible to distinguish a legitimate request from a forged one.

![](https://miro.medium.com/v2/resize:fit:875/1*yn3-9ecigpcfMA0moO-pQw.png)

###### CSRF example

Before executing an assault, a perpetrator typically studies an application in order to make a forged request appear as legitimate as possible.

For example, a typical GET request for a $100 bank transfer might look like:

GET http://netbank.com/transfer.do?acct=PersonB&amount=$100 HTTP/1.1

A hacker can modify this script so it results in a $100 transfer to their own account. Now the malicious request might look like:

GET http://netbank.com/transfer.do?acct=AttackerA&amount=$100 HTTP/1.1

A bad actor can embed the request into an innocent looking hyperlink:
```html
<a href="http://netbank.com/transfer.do?acct=AttackerA&amount=$100">Read more!</a>
```
Next, he can distribute the hyperlink via email to a large number of bank customers. Those who click on the link while logged into their bank account will unintentionally initiate the $100 transfer.

Note that if the bank's website is only using POST requests, it's impossible to frame malicious requests using a <a> href tag. However, the attack could be delivered in a <form> tag with automatic execution of the embedded JavaScript.

This is how such a form may look like:
```html
<body onload="document.forms[0].submit()">  
   <form action="http://netbank.com/transfer.do" method="POST">  
     <input type="hidden" name="acct" value="AttackerA"/>  
     <input type="hidden" name="amount" value="$100"/>  
     <input type="submit" value="View my pictures!"/>  
   </form>  
 </body>
```
###### Methods of CSRF mitigation

A number of effective methods exist for both prevention and mitigation of CSRF attacks. From a user's perspective, prevention is a matter of safeguarding login credentials and denying unauthorized actors access to applications.

Best practices include:

-   Logging off web applications when not in use
-   Securing usernames and passwords
-   Not allowing browsers to remember passwords
-   Avoiding simultaneously browsing while logged into an application

For web applications, multiple solutions exist to block malicious traffic and prevent attacks. Among the most common mitigation methods is to generate unique random tokens for every session request or ID. These are subsequently checked and verified by the server. Session requests having either duplicate tokens or missing values are blocked. Alternatively, a request that doesn't match its session ID token is prevented from reaching an application.

Double submission of cookies is another well-known method to block CSRF. Similar to using unique tokens, random tokens are assigned to both a cookie and a request parameter. The server then verifies that the tokens match before granting access to the application.

While effective, tokens can be exposed at a number of points, including in browser history, HTTP log files, network appliances logging the first line of an HTTP request and referrer headers, if the protected site links to an external URL. These potential weak spots make tokens a less than full-proof solution.

### Secure Communication with APIs

Communication with APIs is essential for protecting sensitive data exchanged between clients and servers. Using HTTPS encrypts data during transmission, safeguarding against eavesdropping and tampering. Implementing CORS (Cross-Origin Resource Sharing) ensures that only trusted domains can access resources, preventing unauthorized requests from malicious sites.

Encrypting sensitive client-side data before sending it to servers adds layer of security, making intercepted data unreadable.

Avoiding storing sensitive information on clients and opting for secure storage mechanisms like HTTP-only cookies for tokens and credentials further enhances protection against potential threats.

These practices collectively ensure that API communications are robustly secured, maintaining data integrity and user privacy.

![](https://miro.medium.com/v2/resize:fit:875/1*zctUB9yuafmGpQrJCa_Hhw.png)

### Avoid Security Risk Angular API

It's crucial to avoid using Angular APIs labeled as “Security Risk” in the documentation, particularly ElementRef. ElementRef allows direct access to the DOM, which can expose your application to XSS (Cross-Site Scripting) attacks if not used carefully. Instead, rely on Angular's templating and data binding capabilities whenever possible, as they provide safer alternatives.

When direct DOM access is unavoidable, consider using Renderer2, which offers a secure API to interact with native elements without compromising security. By following these guidelines, you can minimize risks associated with vulnerable APIs and strengthen the overall security of both your users and Angular applications.

![](https://miro.medium.com/v2/resize:fit:875/1*L92QwpR_hfG4CLGCt951NA.png)

### Never use native DOM APIs to interact with HTML elements

Avoid direct DOM manipulation and use Angular template mechanisms, and Agular's own APIs to manipulate the DOM instead. As a general guideline, avoid the following:

-   `node.appendChild();`
-   using the `document` object methods to interact with the page
-   using jQuery APIs

There are native Angular APIs that allow the same type of direct DOM manipulation that we're advising against — for example, the **ElementRef API**. Angular ElementRef introduces security issues when used to gain access to a direct DOM node and perform manipulations at that point.

This and other interactions outside of the Angular set of APIs could potentially lead to security vulnerabilities.

### Avoid template engines on server-side templates

Angular security best practice ###5: Avoid 3rd party template engines to create or add templates data on Angular server-side rendered applications.

If you've been using Node.js to build web applications, you have probably used a template engine such as EJS, Pug, **Handlebars**, or one of their alternatives at some point in time. They are used to manage server-side rendered templates for the view layer and may include partials or layouts composites, and other sorts of features that help dynamically generate a view.

However, implementing these template engine mechanisms in a configuration of Angular's server-side rendered application could lead to potential injection of malicious code into a template. That happens because data injected is external to the scope of the Angular API and cannot be sanitized, posing the same risks as template string concatenation

### Scan your Angular project for components which introduce security vulnerabilities

When it comes to using third-party libraries, like Angular and its ecosystem of modules or components, you should keep the following in mind: security vulnerabilities affecting the core Angular library, and security vulnerabilities in the third-party Angular modules you are importing and using in your project.

**Using components with known vulnerabilities** is actually a documented **OWASP Top 10** web security risk that you should be aware of.In fact, the picture below shows a list of Angular modules with known security vulnerabilities, for example, those that would get flagged when you run an `npm install` or `npm audit`. Indeed, as you see in this picture taken from our **JavaScript Frameworks Security report**, some of these are winning millions of downloads a year yet have **no security fix** to this date:

![](https://miro.medium.com/v2/resize:fit:875/0*cMTfFdO5gF3M55dl)

### **Enable Strict CSP**

To enable Strict CSP(Content Security Policy) configure your web server to include a Content-Security-Policy HTTP header with directives for script and style sources, and enhanced security and performance.

To make an application compatible with strict CSP it is usually necessary to make some changes to HTML templates and client-side code, add the policy header, and test that everything works properly once the policy is deployed. This page walks you through the common steps.

###### **Add nonces to <script> elements**

With strict CSP, every `<script>` element must have a `nonce` attribute containing a random, unguessable token which matches the value specified in the policy. The first step is to add these attributes to all scripts:
```javascript
<script src="/path/to/script.js"></script>  
<script>foo()</script>
```
becomes (depending on the template system syntax):
```javascript
<script nonce="${nonce}" src="/path/to/script.js"></script>  
<script nonce="${nonce}">foo()</script>
```
If you use Closure Templates , the template system will [add nonce attributes automatically](https://developers.google.com/closure/templates/docs/security###content_security_policy) without requiring any changes to your templates if you pass the nonce value as [injected data](https://developers.google.com/closure/templates/docs/concepts###injecteddata).

In other template systems you will need to modify the templates which include `<script>` tags to add the `nonce` attribute and set its value.
```javascript
default-src 'self';   
script-src 'self';   
style-src 'self';                   
img-src 'self' data:;   
font-src 'self';   
connect-src 'self';
```
**Here's how the policy works:**

-   **Default-src**Script-src **'self':** All content has to be fetched from the same domain as that which hosted the HTML page.
-   **Script-src 'self' https:** An API service (_https://apis.example.com_) serves as the only source for JavaScript loaded on the website.
-   **img-src 'self' data:** One can retrieve images from their origin or represent them as data URIs.

We can set the CSP directives in the meta tag as well. To set the directives in an angular application. The CSP meta tag allows you to define a Content Security Policy in HTML <head> Section. Configuring CSP with meta tags is a good way to implement and test Content Security Policies directly within your HTML documents.
```html
<! --- index.html --->  
<!DOCTYPE html>  
<html lang="en">  
<head>  
    <meta charset="utf-8" />  
    <title>AngularCsp</title>  
    <base href="/" />  
    <meta name="viewport"  
          content="width=device-width,  
                   initial-scale=1" />  
    <link rel="icon" type="image/x-icon"  
          href="favicon.ico" />  
    <meta http-equiv="Content-Security-Policy"  
        content="default-src 'self'; script-src 'self'; style-src 'self';  
                 img-src 'self' data:; font-src 'self'; connect-src 'self';" />  
</head>  
<body>  
    <app-root></app-root>  
</body>  
</html>
```

###### How to Use a Nonce in Angular

If your Angular application has a CSP and you do not want to use `'unsafe-inline'` (and you shouldn't if you can help it), this is the _minimum_ policy you must have according to Angular (line breaks added for readability):
```javascript
default-src 'self';   
style-src 'self' 'nonce-randomNonceGoesHere';   
script-src 'self' 'nonce-randomNonceGoesHere';
```

Since Angular 16, You can set the nonce for Angular in one of two ways:

1.  Set the `ngCspNonce` attribute on the root application element as `<app ngCspNonce="randomNonceGoesHere"></app>`. Use this approach if you have access to server-side templating that can add the nonce both to the header and the `index.html` when constructing the response.
2.  Provide the nonce using the `CSP_NONCE` injection token. Use this approach if you have access to the nonce at runtime and you want to be able to cache the `index.html`.
```javascript
import {bootstrapApplication, CSP_NONCE} from '@angular/core';  
import {AppComponent} from './app/app.component';  
bootstrapApplication(AppComponent,   
  {  providers:   
    [{      
      provide: CSP_NONCE,  
      useValue: globalThis.myRandomNonceValue    
    }]  
});
```
### Offline Template Compiler

The offline template compiler in Angular compiles templates during the build process, rather than at runtime, which improves security and performance.

`tsconfig.json`: Set `angularCompilerOptions.fullTemplateTypeCheck` to `true` in your `tsconfig.json` file.
```json
{  
  "angularCompilerOptions": {  
    "fullTemplateTypeCheck": true  
  }  
}
```
**Benefits:**

-   **Enhanced Security:** Prevents template injection vulnerabilities.
-   **Improved Performance:** Templates are compiled ahead of time, reducing runtime overhead.

### Secure Development Best Practices

Following are the secure coding practices:

1. **Secure Authentication**:

Use strong hashing algorithms (like bcrypt) to securely store passwords. This ensures passwords are not easily compromised even if your database is breached

Enforce password policies such as minimum length, complexity requirements (including numbers and special characters), and periodic password changes.

![](https://miro.medium.com/v2/resize:fit:730/0*uTe-n4QZUGgj7xmn.png)

2. **Avoid Hazardous Angular API Endpoints**:

Avoid using Angular API endpoints that are overloaded, unavailable, or incorrect, as they can cause application failures or unpredictable behavior.

Ensure that API endpoints are well-documented, maintained, and adhere to RESTful principles for consistency and reliability in communication between Angular frontend and backend services.

3. **Stay Updated**:

Regularly update your Angular libraries to the latest versions. Updates often include security fixes that protect against known vulnerabilities. Check the Angular change log for security-related updates and best practices.

4. **Security Audits**:

Conduct Angular application security audits to identify and address potential vulnerabilities. This ensures that you follow security best practices and maintain robust protection against threats.

5. **Use Route Guards**:

Implement route guards to control access to specific routes based on user authentication and authorization. This helps ensure that only authorized users can access sensitive or restricted areas of your application.

6. **Keep Dependencies Updated**:

Use npm (Node Package Manager) to keep Angular and its dependencies up to date. Regular updates help to mitigate risks associated with known vulnerabilities in third-party libraries and packages.

### Do I even need a BEARER token, if i have a CSRF token?

The bearer token is your login token to an external api-service like a passport or member-card, so you are granted access to this external service. The token also tells the server who the person/machine accessing the resource is, so the server can decide if they have the correct permissions.

The CSRF token protects you from request forgery, meaning someone making a request to your server from an external server or tool. The only thing a CSRF token tells you is that the request came from someone using your site, it doesn't tell you who that person is or what permissions they have.

# Linting With Angular.

Every developer has its own style of coding. If you are working on a project where multiple developers are working, you may notice different variations of coding styles. Some like to use single quotes, some may use double quotes, some like to write long lines of codes and some may want to break code into new lines. Although all of them may be syntactically correct but at the end, your code will be having lots of different coding variations. **Too many developers spoil the code.**

### **What's the problem?**

The above-listed issues may not be a problem for you with a small team or a small project or if you don't care enough, but when code grows, consistency really matters. Keeping coding style consistent throughout your application helps you in matters like code reviews, easy for other developers to understand, easy to extent and lot more. The solution to this problem is Linting.

### **What is Linting**

Linting is the process of running a program that analyses your code for programmatic and stylistic errors. A Linting tool, or a linter, checks any potential errors in your code such as syntax errors, incorrectly spelled variable names, and many more. This can save time and help you write better code.

Linters will go through your code, and highlight

**· formatting and styling discrepancy**

**· non-adherence to coding standards and conventions**

**· possible logical errors in your code**

Running a linter on your code makes sure it follows best practices, is readable, and easy to maintain. Different programming languages have different tools for Linting. JavaScript also has a good variety of linting tools. Some of the popular JS linting tools are

· JSLint

· JSHint

· ESLint

### **Linting with Angular**

Angular CLI has provided built-in support for Typescript code linting. The default tool used by angular CLI is TSlint. The basic CLI command used for linting an angular project is

**· ng lint <_project_> [_options_]**

This command takes the name of the project, as specified in the `projects` section of the `angular.json` configuration file. When a project name is not supplied, it will execute for all projects (libraries).

The default linting tool is TSLint, and the default configuration is specified in the project's `tslint.json` file. You can change any rule in this file according to your requirements.

When you will run this command through CLI, TSLint will check all the issues which don't follow the lint rules defined in the tslint.json configuration file and show a list of all the issues in CLI output with an error description, file name and line of error. Following that output, you can fix all your lint issues, that's nice right?

Yes, that is nice but sometimes the errors list is very large and it is really time-consuming to follow all the instructions and fix the issues one by one. But there is a solution to this as well. Angular CLI has provided some options with this command which are really useful. For this particular case, you can use

**· ng lint --fix=true**

This command will fix all the fixable lint problems automatically using the rules written in the tslint.json configuration file. There are a lot more options available for this command. For more options check the following link.

[https://angular.io/cli/lint](https://angular.io/cli/lint)

### **Linting with VS Code**

VS Code has provided some really good extensions for linting as well. One of the best VS code lint extensions is TSLint, Prettier and husky. To install TSLint in VS code, open the extensions tab and type tslint. For the results list, click the install button and the extension will be installed on one click.

![](https://miro.medium.com/v2/resize:fit:875/1*qg8LPv2TZKnhx9Kf-xbSNA.png)

This extension will highlight the lint error as you type, which makes it very useful as you can fix or avoid your lint errors while you are coding. When there are some lint errors, this extension will underline the error indication of the issue. It also provided a suggestion to fix the issues or fix all fixable issues, which fixes all fixable issues automatically.

### **Custom Lint Rules**

Angular linting configuration comes with a very good set of linting rules. Still, there may be cases where you want to create some new rule according to your requirements. TSLint provides facility to extend its existing rules.

If you have a look at the rules list, you see how many rules exist, and they should cover already most use cases. But still, enforcing coding guidelines is hard if you don't use the tooling available, and manual checks just don't catch every case.

Follow these steps for setting up a custom TSLint rule:

1. Add a directory for your rules to your project, e.g. `tslint-rules`
2. Add a new file for the rule (e.g. `mycustomrule.ts`)
3. Compile rule: `tsc mycustomrule.ts`
4. Configure directory
5. Add rule to `tslint.json`: "my-custom-rule": true

TSLint provides a rich syntax for creating custom rules, but that's out of scope for this article. For details and guidelines, following the instructions provided by TSLint documentation.

# Angular 19 Logger Service.

The log level is set based on the environment. In production, we only log `info` and above to reduce noise and improve performance.

Here is the logger service where we have created our own logging functions like **_info(), log(), warn() & error()_** with arguments and _log level._

The log level is set based on the environment.

## logger.service.ts
```typescript
import { Injectable, inject } from '@angular/core';  
import { ENV_CONFIG } from '../environments/environment-config';  
import { UtilService } from './util.service';  
  
interface LoggingFunction {  
  (...args: any[]): void;  
}  
export interface Logger {  
  info: LoggingFunction;  
  log: LoggingFunction;  
  warn: LoggingFunction;  
  error: LoggingFunction;  
}  
  
@Injectable({ providedIn: 'root' })  
export class LoggerService implements Logger {  
  private readonly envConfig = inject(ENV_CONFIG);  
  constructor(private utilService: UtilService) {}  
  
  info(...args: any[]): void {  
    if (!this.envConfig.production) {  
      console.info.apply(null, args);  
    }  
  }  
  
  log(...args: any[]): void {  
    if (!this.envConfig.production) {  
      console.log.apply(null, args);  
    }  
  }  
  
  warn(...args: any[]): void {  
    if (!this.envConfig.production) {  
      console.warn.apply(null, args);  
    }  
  }  
  
  error(...args: any[]): void {  
    if (!this.envConfig.production) {  
      console.log('Error =>>>>');  
      console.error.apply(null, args);  
      this.utilService.downloadCSV(args);  
    }  
  }  
}
```
with log.error() function, one txt file will be downloaded automatically using the following :
```typescript
this.utilService.downloadCSV(args);
```
## util.service.ts
```typescript
import { Injectable, SecurityContext } from '@angular/core';  
import { DomSanitizer } from '@angular/platform-browser';  
  
@Injectable({ providedIn: 'root' })  
export class UtilService {  
  constructor(private sanitizer: DomSanitizer) {}  
  downloadCSV(arr: any) {  
    /*  
      type: 'application/octet-stream'  
      type: 'text/csv'  
      type: 'text/plain'  
      type: 'text/html'  
      type: 'image/jpeg'  
      type: 'image/png'  
      type: ''  
      type: ''  
    */  
    console.log('===================', arr[0].message);  
    const formattedData = {  
      message: arr[0].message,  
      status: arr[0].status,  
      url: arr[0].url,  
    };  
    const blob = new Blob([JSON.stringify(formattedData)], {  
      type: 'text/html',  
    });  
    const url = this.sanitizer.sanitize(  
      SecurityContext.RESOURCE_URL,  
      this.sanitizer.bypassSecurityTrustResourceUrl(  
        window.URL.createObjectURL(blob)  
      )  
    );  
    console.log('url =>', url);  
    if (url) {  
      window.open(url);  
    }  
  }  
}
```
## api.service.ts
```typescript
import { HttpClient } from '@angular/common/http';  
import { Injectable } from '@angular/core';  
import { Observable } from 'rxjs';  
import { User } from './user/user-model';  
  
@Injectable({ providedIn: 'root' })  
export class ApiService {  
  constructor(private http: HttpClient) {}  
  getUsers(): Observable<User[]> {  
    const usersAPI = 'https://jsonplaceholder.typicode.com/todos';  
    return this.http.get<any>(`${usersAPI}`);  
  }  
}
```
## user.component.ts
```typescript
import { Component, ChangeDetectionStrategy, signal } from '@angular/core';  
import { CommonModule } from '@angular/common';  
import { LoggerService } from '../logger.service';  
import { User } from './user-model';  
import { ApiService } from '../api.service';  
@Component({  
  selector: 'app-user',  
  standalone: true,  
  imports: [CommonModule],  
  templateUrl: './user.component.html',  
  styleUrls: ['./user.component.scss'],  
  providers: [LoggerService, ApiService],  
  changeDetection: ChangeDetectionStrategy.OnPush,  
})  
export class UserComponent {  
  usersList = signal<User[]>([]);  
  constructor(    private loggerService: LoggerService,  
    private apiService: ApiService  ) {  
    this.apiService.getUsers().subscribe({  
      next: (users: User[]) => {  
        this.usersList.set(users);  
        this.loggerService.info('Display Users');  
      },  
      error: (err) => this.loggerService.error(err),  
    });  
  }  
}
```

the console.log(), console.debug(), and console.info() methods are identical. The only difference is the way the output is visible in the browser console. The console.warn() method helps us to display a warning message in the console.