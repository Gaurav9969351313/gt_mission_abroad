
# Tree Shaking in JS

> _“Improved application performance by 30% through code refactoring, data reorganization, removing code duplication, and simplifying conditional expressions.”_

It sounds impressive on a resume, but the real question is — can they actually explain it like an expert in an interview?

If an interviewer asks: **“Which approach did you use to achieve this?”**

One of the best ways to explain this is by discussing **Tree Shaking** in JavaScript. Let's explain what is actually Tree Shaking.

> Tree shaking is a term commonly used within a JavaScript context to describe the removal of dead code. It relies on the [import](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/import) and [export](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/export) statements to detect if code modules are exported and imported for use between JavaScript files.It's commonly used in modern bundlers like **Webpack, Rollup, and ESBuild** to optimize performance.

> In modern JavaScript applications, we use module bundlers (e.g., [webpack](https://webpack.js.org/) or [Rollup](https://github.com/rollup/rollup)) to automatically remove dead code when bundling multiple JavaScript files into single files. This is important for preparing code that is production ready, for example with clean structures and minimal file size.

## Answer that Question Like an Expert

> _“I optimized the application's performance by_ **_implementing Tree Shaking,_** _which helps eliminate unused code from the final JavaScript bundle._ **_This was particularly effective in reducing the bundle size and improving load times_**_. I analyzed the dependency tree using tools like_ **_Webpack_** _and ensured that only necessary modules were included in the production build. Additionally, I refactored the code by removing redundant functions, simplifying complex conditionals, and restructuring data processing to reduce unnecessary computations. These optimizations collectively improved the application's performance by 30%.”_

Let's make a simple example of using Tree Shaking with Webpack.

## Step 1: Basic Project Setup

1.  **Create a project folder and initialize npm**

First let's create a directory, initialize npm, [install webpack locally](https://webpack.js.org/guides/installation/#local-installation), and install the `[webpack-cli](https://github.com/webpack/webpack-cli)` (the tool used to run webpack on the command line)
```shell
mkdir tree-shaking-example && cd tree-shaking-example  
npm init -y
```
2. Install Webpack and Babel
```shell
npm install --save-dev webpack webpack-cli babel-loader @babel/core @babel/preset-env
```
The `[import](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/import)` and `[export](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/export)` statements have been standardized in [ES2015](https://babeljs.io/docs/en/learn/). They are supported in most of the browsers at this moment, however there are some browsers that don't recognize the new syntax. But don't worry, webpack does support them out of the box.

Behind the scenes, webpack actually “transpiles” the code so that older browsers can also run it. If you inspect `dist/main.js`, you might be able to see how webpack does this, it's quite ingenious! Besides `import` and `export`, webpack supports various other module syntaxes as well, see [Module API](https://webpack.js.org/api/module-methods) for more information.

Note that webpack will not alter any code other than `import` and `export` statements. If you are using other [**ES6 features**](http://es6-features.org/)**,** make sure to [use a transpiler](https://webpack.js.org/loaders/#transpiling) such as [**Babel**](https://babeljs.io/) via webpack's [loader system](https://webpack.js.org/concepts/loaders/).

## **Step 2: Create Sample JavaScript Files**

`math.js` (Utility File with Unused Code)
```javascript
export function add(a, b) {  
  return a + b;  
}  
  
export function multiply(a, b) {  
  return a * b;  
}  
  
// This function is never used in the project  
export function subtract(a, b) {  
  return a - b;  
}
```
`index.js` (Main File That Only Uses 'add' Function)
```javascript
import { add } from "./math.js";  
  
console.log("Result:", add(5, 10));
```
## Step 3: Configure Webpack for Tree Shaking

Create a `webpack.config.js` File
```javascript
const path = require("path");  
  
module.exports = {  
  mode: "production", // Enables tree shaking  
  entry: "./index.js",  
  output: {  
    filename: "bundle.js",  
    path: path.resolve(__dirname, "dist"),  
  },  
  optimization: {  
    usedExports: true, // Enables Tree Shaking  
  },  
  module: {  
    rules: [  
      {  
        test: /.js$/,  
        exclude: /node_modules/,  
        use: {  
          loader: "babel-loader",  
          options: {  
            presets: ["@babel/preset-env"],  
          },  
        },  
      },  
    ],  
  },  
};
```
## Step 4: Build and Observe Tree Shaking in Action

Run Webpack to bundle the project
```shell
npx webpack
```
> What Happens after running the webpack ?
> 
> Since `subtract()` is **never used**, Webpack **removes it** from the final `bundle.js`.
> 
> Only the `add()` function is included, reducing bundle size and improving performance.

## How Tree Shaking Works?

**> ES6 Module Analysis**: Webpack scans your import/export statements.

**> Dead Code Elimination**: It removes functions that are not used in the final bundle.

**> Minification**: Additional optimization happens in **production mode**, shrinking the code further.
---


# Angular Performance Optimization Techniques
Angular is, by default, a powerful and high performing front-end framework. Yet, unexpected challenges are bound to happen when you're building mission-critical web applications, apps that are content-heavy, and complex on the architectural side.

Apps will start to become slow as they grow if you are not aware of how to develop performant Angular apps and this will directly affect the end-users' experience. A decline in traffic or no traffic, decrease in engagement, high bounce rate are some of the factors that could give you a quick idea if your application is struggling with performance.

### **How to solve this problem?**

These problems can certainly be rectified using Angular optimization techniques. You need to analyze your application and figure out the areas which are performing slow. Also, you need to ensure that your app is adhering to the principles of clean coding architecture. There are many ways you can optimize your Angular application but there are some very important techniques that can improve your application with a great impact.

### Optimization Techniques

### 1: OnPush change detection strategy

Change detection is one of the most common features in Angular frameworks. This is the ability to detect when the user's data have changed or altered then, update the DOM to reflect the changes.

**Default Change Detection:** Angular detects the changes in the application, within the tree of components. It starts by checking the root component, then its children, then its grand-children, until all components are checked. Then all the necessary DOM updates are applied in one batch.

But this is not a very good idea to check _every_ component on _every_ change. And that's often not really necessary. Whenever a change occurs, Angular starts checking all components again, starting from the root component and descending in each child component.

In the case of **Reference type** i.e. objects, whenever some change occurs, Angular will check each property of the object to see if there was some change and update the DOM accordingly. This can be a **performance affecting action**. Suppose we have large objects used in a component and its child components, Angular will check each and every property of all the objects used within the parent and all its child components whenever a change occurs.

**OnPush Change Detection**: With the OnPush change detection strategy, we can tell Angular not to check each component, every time the change detection runs.

With OnPush strategy, Angular will check the reference of the objects i.e. reference types and if the reference is the same, no deep comparison is performed.

For example, if a component is populating a large object and passing it along to the child components. Now if the child component is using the OnPush strategy, the change detection will check if the reference of the object passed to the chid component is changed, if yes only then it will compare the object properties.

This technique can save a lot of time and improves performance for the objects where we don't need to check for changes every time some change occurs.

This also introduces the concept of immutability. With OnPush strategy, we don't mutate the objects directly. Instead we create a new object (which will of course have a new reference) in order for OnPush strategy to trigger change detection.
```javascript
@Component({  
     selector: 'child-component',  
     changeDetection: ChangeDetectionStrategy.OnPush,  
     template: `...`  
})
```

### 2: Detach Change Detection/NgZone

Every component in an Angular project tree has a change detector which creates a change detection tree. Whenever some change occurs, these change detectors tell Angular about the change which further updates the DOM accordingly.

We can inject the change detector instance into the components to either detach the component from the change detection tree or attach it to the change detection tree. So, when Angular runs change detection on the component tree, the component with its sub-tree will be skipped.

This is done by the use of the **ChangeDetectorRef** class. Using this change detection reference instance we can **detach** the change detection from any component where it is not necessary to check for changes with each change detection cycle. We can attach the change detection back anytime we want using the ChangeDetectorRef instance.

Behind the scene, Angular uses the **browser APIs** to make the change detection work. This is done by the **Angular zone**. This zone is created by Zone.js which listens on async events and tells them to Angular. We can also optimize the performance by running our code outside the **Angular zone**.
```javascript
class TestComponent {  
    constructor(private changeDetectorRef: ChangeDetectorRef) {  
        changeDetectorRef.detach()  
     }  
     clickHandler() {  
         chnageDetectorRef.detectChnages()  
     }  
 }
```
### 3: Using Pure Pipes

In Angular Pipes are used to format data. Using a pipe is also more performant. There are two types of pipes, pure and impure. By default, a pipe is “**pure**”.

In JavaScript, a function is called “pure” if it has no side effect, and whose result only depends on its input. A pure pipe is pretty much the same: the result of its transform method only depends on arguments. Knowing that Angular applies a nice optimization: the ” transform” method is only called if the reference of the value it transforms is changed or if one of the other arguments changes. It means that whereas a method of a component is called on every change detection, a pure pipe will only be executed when needed, and only once in a template if it is used with the same input value and arguments.

### 4: AOT Compilation

Angular framework uses Typescript by default. In order to run the application in the browser, we need to compile (Transpire) the Typescript code and convert it into JavaScript code so that browsers can understand it.

Angular provides two compilation modes

• just-in-time (JIT)

•Ahead of time (AOT)

JIT compiles your app at **runtime**, and ahead-of-time (AOT) compilation occurs at build time. By default, the development compilation uses the JIT compilation. With **JIT** compilation, the compiler is also part of the bundle, and code is compiled at runtime. This can increase the rendering time of the components.

**AOT** anticipates compilation at **build time**, produces only the compiled templates, and removes the Angular compiler from the deployment bundle, which reduces your app payload by around 1MB (roughly the size of the Angular compiler) and rendering time is increased significantly.

### 5: Lazy Loading

When an Angular application is compiled, behind the scene Angular uses Webpack to create bundles that are sent over to the client. With large enterprise applications, the size of the application increases significantly with time and hence the size of the bundles also increases.

Once the main bundle starts to increase the performance goes down exponentially because every kB extra on the main bundle is contributing to slower:

Download

Parsing

JS execution

This is a performance impacting issue and can be solved by **using Lazy Loading**. With lazy loading, we can split our application to feature modules and load them on-demand. The main benefit is that initially, we can only load what the user expects to see at the start screen. The rest of the modules are only loaded when the user navigates to their routes. This improves application load time with a great deal.
```javascript
export const routes = [  
     …homeRoutes,  
    {  
       path: “users”,  
       loadChildren: “./users/users.module#UserModule”,  
    }  
];
```
Care must be taken to avoid adding any sort of reference to the feature module anywhere in the main bundle. Otherwise, it will create a compile-time dependency, and the compiler will include the feature module in the main bundle instead of lazy-loading it. That's why we pass a string as the value of loadChildren, instead of a module reference.

### 6: Trackby

Angular user *ngFor structural directive to loop over data and manipulate the DOM by adding and removing DOM elements. However, if not used well, it may damage your app's performance.

Let's say we have a large object containing User data and we need to iterate over this object and display the data on UI. We will use the ***ngFor directive** to iterate over the object and display the data. Now we have a scenario where we are adding records in the object asynchronously. With each addition on the object Angular change detection runs and see if the object has some new value, it will **destroy the previous DOM** elements and recreates the DOM for each item again. If the size of the objects even reaches over hundreds and thousands, it will re-render the whole DOM again, just for one newly added item.

This is a huge impact on performance as **DOM rendering is an expensive** operation. What if our *ngFor directive checks the object and only render the newly added item?

This can be done using Trackby.

### 7: Web Workers

It is said **humans are very impatient** wait for an app to load or run some computations, we will leave a site if it takes ~3s to run/load. JavaScript is **single-threaded**, which when running in the browser context, is called the DOM thread. During the loading of a new script in the browser, a DOM thread is created where the JS engine loads, parses and executes the JS files in the page. If our application has to perform some heavy tasks at startup i.e. calculate and render some graphs, the load time of the application will increase, waiting for the thread to complete its task.

**_Web apps would run better if heavy computations could be performed in the background._**

The solution to this is Web Workers. The Web Worker will create a new thread called the **_Worker Thread_** that will run a JS script parallel to the DOM thread. The JS script run by the Worker thread would not have a reference to the DOM because it is running in a different environment where no DOM APIs exist.

Letting the Web Worker perform the heavy computation and loading the app using the main DOM thread can increase the load time of the application and user experience as well.

### 8: Preloading Modules

We have seen that with lazyloading, we load our featured modules on demand. There may be cases where we don't want to load a feature module initially but we know that it is a popular module and it will be required soon. Once we've pulled down the initial bundle and loaded our application, there's **no reason to wait** for a user to navigate to that popular feature before starting to load it. So its **better to start loading it in the background**. This is where preloading comes into play.

Preloading works with lazy loading. It's a way to tell Angular when to start loading your feature modules. Angular comes with two default preloading strategies:

•Preload everything (PreloadAllModules)

• Don't preload anything (NoPreloading)

You can use one of the two default preloading strategies mentioned above, or you can write your own custom preloading strategy.

You can specify which preloading strategy you want to use by passing an option into the routing configuration. Preloading can have a positive performance impact.

### 9: Resolve Guards

Let's say that we have to load another component from the currently loaded component which will display a list of users. In case if there is some error getting the users list from the server, we need to navigate back to the previous component with an error. Now if the server responds with an error, here are the performance impacting actions happening around.

•Currently loaded component is destroyed

•New component is loaded

•New component sending HTTP call which results in an error

•New component is destroyed

•Previous component is loaded again and displays the error

All this round trip is causing DOM rendering and destroying which is an expensive operation. This can be minimized using Resolve Guard.

We can send the required HTTP call within the **Resolve Guard**, which will load the next component only if the HTTP call returns success. In case of error, it will not load the next component and displays an error on an already loaded component. This can save a lot of DOM rendering and destroying time and increases performance.

### 10: Unsubscribe from Observables

Observables have the **subscribe** method which we call with a callback function to get the values emitted. Now, if we subscribe to a stream the stream will be left open and the callback will be called when values are emitted into it anywhere in the app until they are closed by calling the **unsubscribe** method.

If a subscription is not closed the function callback attached to it will be continuously called, this poses a **huge memory leak** and performance issue.

It is always a good practice to unsubscribe from observables using the OnDestroy **lifecycle hook** so when we leave the component, all the used observables are unsubscribed.

---
# Approaching Web App performance optimisation

Performance is a loaded term, that is often thought to be high fidelity stuff to be performed at the end of development, but understanding the factors and techniques that constitute good performance will help inculcate it as a habit in the development cycle. I hope this post will serve as a good introduction on how to approach web performance optimisation, by looking at a few basic techniques.

In a web application, performance might refer to  
— **Loading performance**: How quickly the page loads  
— **Rendering performance**: How quickly the page elements respond to user interactions

I always recommend this [Google web fundamentals](https://developers.google.com/web/fundamentals/performance/rail) guide as a good place to start with detailed explanations on the different metrics. But, once we understand what the different metrics and the optimisation techniques are, how do we actually go about the process? Which is what I'll attempt to guide you through here.

Performance is about the cycle of Optimise -> Measure -> Optimise. Here lies a sample application ([https://girlswhojs.herokuapp.com/](https://girlswhojs.herokuapp.com/)) with a huge hero banner image and a map loaded on another route. We're going to attempt to improve the perceived performance, which involves optimising the critical rendering path to prioritise the display of relevant content to the user, by adopting a few techniques, some of which are on the client and some on the server.

Some of the useful tools are:

-   WebPageTest
-   GTMetrix
-   Google PageSpeed
-   Pingdom
-   YSlow
-   Google DevTools

**How?**

We're going to be using the [webpagetest](http://www.webpagetest.org/) tool to understand our sample app's performance, as we proceed through each step. I've got a simple Heroku instance setup with Github deployment pipeline enabled, so that as I make the changes in each step, I deploy them to the instance and run Webpagetest on it. If you're unfamiliar with interpreting a waterfall chart, [this](https://blog.radware.com/applicationdelivery/wpo/2014/03/waterfalls-101-how-to-use-a-waterfall-chart-to-diagnose-performance-pains/) should serve as a good place to start.

**Step — 1: Compression (on server)**

Gzip compression reduces the size of the files from the server to the browser by about 70%. Since this is a Node application, all I had to do was to include the compression middleware and, voila! The below table shows the differences in loading times after this step was performed.

![](https://miro.medium.com/v2/resize:fit:875/1*0ZR6R3b-8HvQikYQargoIw.png)
Webpagetest results — The gains on such a small effort

![](https://miro.medium.com/v2/resize:fit:875/1*5UeFOCHoK-Iybt7XI2k5Mg.png)
This image shows, in the Size column, the original size(below) and the compressed size(above).

The new kid on the block for compression is Brotli, which promises [better compression ratios](https://blogs.akamai.com/2016/02/understanding-brotlis-potential.html).

**Step — 2: Asynchronous loading of resources (on client)**

Anything not required immediately for user action needs to be loaded asynchronously, so that main thread is free to process critical resources. In our case, we have a map displayed only after a user action(navigating to a different route), so google maps script could be downloaded asynchronously.
```html
<script src=”[https://maps.googleapis.com/maps/api/js?&key=x](https://maps.googleapis.com/maps/api/js?amp%3Bkey=AIzaSyC5kgVtsX9_WAWV-4Vzp77gs9mxs9hsE7o)yz" async></script>
```
![](https://miro.medium.com/v2/resize:fit:875/1*JJxpoBguys-ZTTgJ_TGwuA.png)

**Step — 3: Cache static resources (on server)**

Caching helps in improving repeat view loading times. This is done by setting the max-age header in the asset response, so that the subsequent requests to the assets are served from the browser cache for the same user.

![](https://miro.medium.com/v2/resize:fit:875/1*vzPYZ7v8zAQXh4oOUDCvGg.png)

**Step — 4: Preloading resources of priority (on client)**

This is currently fully supported only on Chrome, but doesn't impact the perf on other browsers, until they catch up. Here, I tried preloading the huge hero image, so that the visually complete time for the user is perceived to be shorter, but then from the result below, this seems to negatively impact the performance, so the measuring phase is very important to validate our theories on improving performance.

**Preload**: Fetch resources with high priority immediately, while the HTML is being parsed, as soon as the tag is encountered  
**Prefetch**: Fetch resources needed for further navigation with lower priority(subsequent routes), in the background  
**DNS-prefetch**: Perform DNS lookup to a URL in the background  
**Preconnect**: Setup connections to a URL before requests are triggered
```html
<link rel=”preload” as=”font” type=”font/woff” href=”/fonts/font.woff2">
```
![](https://miro.medium.com/v2/resize:fit:875/1*FJxi1xbDLtnuZe1FhQ-E5Q.png)

**Step — 5: HTTP/2 (on server)**

A key performance bottleneck in HTTP/1.1 was the latency and the limited number of simultaneous TCP connections per host (typically 6), while on HTTP/2, a single TCP connection can be reused for multiple asset requests. The resulting improvement should be pretty obvious from the below images.

![](https://miro.medium.com/v2/resize:fit:875/1*rxAFX60xZAQ8JSGlenOzBA.png)
Waterfall — Before HTTP/2 implementation

![](https://miro.medium.com/v2/resize:fit:875/1*7JQo23Go3XVktkcbVlXhzA.png)
Waterfall — After HTTP/2 implementation

Though browser support is still not 100%, HTTP/2 pushes us to rethink some of the good practices currently adopted, like bundling, domain sharding, image sprites and inline assets.

HTTP/2 should be enabled on the server, by installing the SSL certificates and most of the browsers currently support HTTP/2.

![](https://miro.medium.com/v2/resize:fit:875/1*nV1MAlQr7i2CYat7qzqGsw.png)

This table summarises the journey of optimisation we just took and the gains achieved.

[These slides](http://slides.com/anbarasiu/deck) contain in the speaker notes, the links to elaborate reports of all the Webpagetest runs above.

---
### Web Performance Optimisation Techniques

Websites are critically important for a business because they create a positive or negative impression of your products, goods, services…image of your brand. And as we know websites are visited even though the actual purchase can be made in store. Therefore, a website should be user-friendly, intuitive, and easy to navigate. Moreover, it should be optimized for various kinds of mobile devices and site traffic. But quite often in the process of putting up a website, we're so busy focusing on the big stuff like design, content, and digital marketing that we forget one of the most fundamental parts of keeping that business site operational and fast: website performance optimization. Actually, speed is a critical element of running a successful website and should always be a priority for website managers. Faster loading websites benefit from better user engagement, higher conversion rates, higher SEO rankings and much more.There is a lot of work behind it and today, we will go over key practices, tools, and tips for web performance optimization techniques!

### Web Performance Optimization overview

Web performance optimization is always something that should be a top priority, especially when there is so much online competition.  
But first of all, let's clarify what is web performance? It refers to the speed in which web pages are downloaded and displayed on the user's web browser. And web performance optimization is the field of knowledge about increasing web performance.

It is a very well know fact that faster website download speeds have been shown to increase visitor retention and loyalty, user satisfaction, especially for users with slow internet connections and those on mobile devices!

### 16 Web performance optimization techniques

1. HTTP requests reduction  
In general, the more HTTP requests your web page makes the slower it will load. A browser is limited to opening only a certain number of simultaneous connections to a single host. To prevent bottlenecks, the number of individual pages elements are reduced using resource consolidation whereby smaller files, such as images, are bundled together into one file. This reduces HTTP requests and the number of round trips required to load a webpage. Making fewer HTTP requests turns out to be the most important optimization technique, with the biggest impact. If your time is limited, and you can only complete one optimization task, pick this one.

2. File compression  
Web pages are constructed from code files such JavaScript and HTML. As web pages grow in complexity, so do their code files and subsequently their load times. File compression can reduce code files by as much as 80%, thereby improving site responsiveness.

3. Web caching optimization  
Web Caching Optimization reduces server load, bandwidth usage, and latency. CDNs use dedicated web caching software to store copies of documents passing through their system.  
Leveraging the browser cache is crucial. It is recommended to have a max-age of 7 days in such cases. This saves server time and makes things altogether faster.

4. Code minification  
Code minification distinguishes discrepancies between codes written by web developers and how network elements interpret code. Minification removes comments and extra spaces as well as crunch variable names in order to minimize code.

5. Lossy compression  
Lossy compression techniques, similar to those used with audio files, remove non-essential header information and lower original image quality on many high-resolution images. These changes, such as pixel complexity or color gradations, are transparent to the end-user and do not noticeably affect the perception of the image.

6. Replacement of vector graphics  
Replacement of vector graphics with resolution-independent raster graphics. Raster substitution is best suited for simple geometric images.

7. Image Optimization  
Don't upload the original photos on your website, they are too heavy. Use tools like TinyPNG, Kraken.io, JPEGmini, etc, which reduces the size of the image while quality remains more or less the same.

8. 301 Redirects  
Redirects are performance killers. Avoid them whenever possible. A redirect will generate additional round-trip times and therefore quickly doubles the time that is required to load the initial HTML document before the browser even starts to load other assets.

9. Adopt Cloud-based Website Monitoring  
There are significant advantages to offloading your website monitoring to a cloud-based host, for example, cost, scalability, efficiency, etc.

10. Prefetch and reconnect  
Domain name prefetching is a good solution to already resolve domain names before a user actually follow a link.

11. SSL certificate/ HTTPS  
Absolutely a must! Actually, Google penalizes those websites that don't have it.

12. Web Font Performance  
The disadvantages of web fonts, such as Google Fonts, are that they add extra HTTP requests to external resources. Web fonts are also rendered blocking. Try to  
prioritize based on browser support, choose only the styles you need, keep character sets down to a minimum, etc.

13. Hotlink protection  
Hotlink protection refers to restricting HTTP referrers in order to prevent others from embedding your assets on other websites. Hotlink protection will save you bandwidth by prohibiting other sites from displaying your images.

14. Infrastructure  
Having a fast web host is equally as important as any website performance optimization you could make, as it is the backbone of your site. Stay away from cheap shared hosting.

15. 404 Errors  
Any missing file generates a 404 HTTP error. Depending upon the platform you are running 404 errors can be quite taxing on your server.

16. Database Optimization  
And last but not least is database optimization. Whether it is cleaning out old unused tables or creating indexes for faster access there are always things that can be optimized.

### Key tools for web performance optimization

-   [PageSpeed](https://developers.google.com/speed/pagespeed/)  
    Google PageSpeed Insights grades both the desktop and mobile site speeds. This popular testing tool analyzes some of the most important website components; JavaScript, CSS, and Image performance.
-   [Pagelocity](http://pagelocity.com/)  
    On top of analyzing on-page SEO performance, Pagelocity also takes a look at social metrics and how those are affecting your social visibility, as well as general page speed performance and individual tips on how parts of your site can be optimized for better speeds.
-   [Varvy Pagespeed Optimization](https://varvy.com/pagespeed/)  
    Varvy Pagespeed Optimization offers reports which are broken into 5 different sections including a resource diagram, css delivery, javascript usage, page speed issues found, and services used. Varvy gives you key web performance optimization techniques to boost web speed and seo rankings.
-   [GTMetrix](https://gtmetrix.com/)  
    GTMetrix offers a variety of reporting options. GTmetrix goes into great detail as it checks both PageSpeed and YSlow metrics, assigning your site a grade from F to A.
-   [Seositecheckup](https://seositecheckup.com/seo-audit/apiumhub.com)  
    Seositecheckup helps you instantly analyze your SEO and web speed issues, understand your competitors' situation and gives you advices on which web performance optimization techniques to use to improve your website in a faster and better way.
-   [Semrush](https://www.semrush.com/dashboard/)  
    It is a paid option, but absolutely worth this money! They have different plans, but even with the most basic one you get enough information to boost your web performance. In our case, [Apiumhub's page](https://apiumhub.com/software-projects-barcelona/) started to see tremendous changes starting from the first month.

---
### Get better web performance with Lazy Loading of Images

As a web developer, web performance optimisation is a key task. At Tokopedia, we take this key task very seriously. Serving our web pages fast is a key aspect in reducing the bounce rate of our customers. Images and how we load those images on the web page is one of the factors that determine the speed of the page. _Lazy loading images_ is one such approach in loading the page fast.

> By lazy loading , we mean downloading the images asynchronously only when they become part of [viewport](https://viewportsizer.com/what-is-a-viewport/). This helps us in shortening the [critical rendering path](https://developer.mozilla.org/en-US/docs/Web/Performance/Critical_rendering_path), as only the images which are required for the initial view of the site are downloaded at first go. Rest of them are loaded upon user interaction like user scroll, or carousel click etc.

_Below is what it looks like_

![](https://miro.medium.com/v2/resize:fit:875/1*GIAcAqH0F7MR3I1OkMvLAQ.png)
By use of lazy loading, we only loaded the first fold images of the viewport in one of our module at Tokopedia, thereby keeping the total image payload near to just 248Kb

![](https://miro.medium.com/v2/resize:fit:875/1*FSmQo-oSmSGwCPm5IziHnQ.png)
When user further scrolls, the rest of the images are loaded, based upon their viewport entry

In this article, lets explore the various ways to do so.

### **I. The native “loading” attribute :**

This new attribute([still experimental as per Mozilla docs MDN](https://developer.mozilla.org/en-US/docs/Web/API/HTMLImageElement/loading)) simplifies the task for lazy loading images by only requiring to add loading attribute  
on an <img/> element. This eliminates the use of a third party javascript library used specifically for lazy loading.
```html
<img src=”exampleImage.jpg” alt=”example image” loading=”lazy” />
```
This attribute can be used also with iframe.
```html
 <iframe src=”exampleVideo.html” title=”example video” loading=”lazy” />
```
Along with “lazy”, there are two other values that can be passed to _loading_ attribute.  
**1.) auto** — default value. Will have no additional effect.  
**2.) eager** — demands immediate loading of images (for eg — can be used for images above the fold).

**Pro Tip ->** Always set width and height of images, to minimise layout shifts and get better web vital [CLS(Cumulative Layout Shift)](https://web.dev/cls/) score.
```html
<img src=”exampleImage.jpg” alt=”example image” width=”200px” height=”200px” loading=”lazy” />
```
**Key findings and web support -**  
Not all web browsers currently support loading attribute. you can see the browser matrix [here](https://caniuse.com/loading-lazy-attr).

![](https://miro.medium.com/v2/resize:fit:875/1*djW_ZgiJYdS3_FSFuIOgkQ.png)
Browser that supports lazy loading via attribute

So for lower versions and unsupported browsers, we require polyfills.  
Also, we can detect support for “loading” attribute by checking for `**loading in HTMLImageElement.prototype**` and subsequently use third party JS for non-supported environment (_I am using_ [_lazysizes.min.js_](https://github.com/aFarkas/lazysizes))  
Check out the related snippet here-

![](https://miro.medium.com/v2/resize:fit:875/1*2MHANJx_4btW5MYqKtv81w.png)

> While I was trying out, i found even latest chrome as of now lazy loads only those images which are located way down the page.  
> (Almost 2000px below the viewport). This does not make it very practically useful for all the use cases.  
> Therefore, lets check out the conventional way of lazy loading:

**Have a look at the working code** [**here**](https://codepen.io/Annesha/pen/oNLdxNr)**.**

### **II. Use of data-src instead of src:**

Browser starts to load images after they encounter the src tag while parsing the HTML. In order to achieve lazy loading, instead of writing src attribute, we can write data-src and later replace it with src attribute (using javascript) when the image tag is visible inside the viewport which will eventually trigger the browser to download the image.

How to detect viewport entry of images-

1.  **) By using event listeners -**  
    We can make use of event listeners like _scroll, resize, and orientation_. On fire of these events, we can check whether the images now fall inside the viewport or not. The math is done by calculating the current document scroll top, image's top offset, and window height. If the image becomes part of the viewport then, we attach the image URL to the src attribute from the data-src attribute. Here is the crux of the code required:
```html
<img class="lazy" data-src="https://ecs7-p.tokopedia.net/img/cache/800/VxWOnu/2020/10/2/7c5bcbce-65ee-46b1-8a48-4f05785e0229.jpg?width=500" />
```

![](https://miro.medium.com/v2/resize:fit:875/1*rkQtoR_g0TdJfQ-IQq3mHA.png)

> Note that this procedure is not an optimised one. Scroll event gets triggered  
> numerously and rapidly. It is recommended to make use of throttle while executing lazy load function for better web performance.

**Checkout the CodePen link** [**here**](https://codepen.io/Annesha/pen/mdELdRx).

**2.) Using intersection Observer -**  
This fantastic API does all the above math behind the scene and is rather more performant. As for the implementation, we add the observer to all the images which are going to be lazy-loaded. Whenever our element enters the viewport, Intersection Observer API makes use of **isIntersecting** property and attaches the URL to the src attribute from the data-src attribute. Following this, the lazy class is removed and downloading is triggered.
```html
<img class="lazy" data-src="https://ecs7-p.tokopedia.net/img/cache/800/VxWOnu/2020/10/2/7c5bcbce-65ee-46b1-8a48-4f05785e0229.jpg?width=500" />
```
![](https://miro.medium.com/v2/resize:fit:875/1*yykNgxgZCPaUaFlMq7qOVQ.png)

> Note that Intersection Observer too is not supported in all browser versions so we ought to use pollyfill as a fallback. Check out the web support [here](https://caniuse.com/?search=IntersectionObserver).

**Have a hands-on with the code** [**here**](https://codepen.io/Annesha/pen/ExyLxNK)**.**

### **Conclusion:**

After experimenting with all the 3 techniques, it can be safely concluded that Intersection Observer API is your safest bet if performance and browser compatibility is your concern.
---

# JavaScript Performance Optimisation

That is going to be the required path to process with JavaScript which is the tool used to create all the fantastic animations and interactions on different web pages. Developers used to carry the web they built, but currently, we can see that to achieve usability and flexibility in applications and web development for mobile devices, they are imposing performance improvement, thus enhanced user experience, and dialogue enhancement in users.

The performance of JavaScript is not just a user issue and we can discuss it on several occasions. The speed of these applications is typically dictated by the quality of coding and patterns so optimizing the performance is a byproduct of this.

JavaScript is the toughest part of the web to learn and to optimise in an effective way. There are a lot of tricks to try out. This real turn off that issues such as this one, and some others are never attempted to be removed. If you want to see how much JavaScript is obsessed with the web compared to using Ajax.

### 1. Use Efficient Data Structures and Algorithms

The correct initiations and the right algorithms will have big results in your time, especially in operations when you waved a big & root node or complex transactions. To illustrate, always use Maps and Sets instead of using only plain objects and arrays to gain better search and insert times. Technical characteristics, (time complexity) are considered when you select the appropriate data structure for the performance of the operations.
```javascript
// Using Map for faster lookups  
let map = new Map();  
map.set('key1', 'value1');  
map.set('key2', 'value2');  

// Accessing values in Map  
let value = map.get('key1');
```
### 2. Minimise DOM Manipulation

Frequent DOM updates or changes could result in performance issues and slow down the application. It's always better to perform batching on DOM updates. DOM updates are done with less number of actions therefore it becomes faster.
```javascript
// Inefficient DOM manipulation  
for (let i = 0; i < 1000; i++) {  
    document.getElementById('container').innerHTML += '<div>Item ' + i + '</div>';  
}  
  
// Efficient DOM manipulation using document fragment  
let fragment = document.createDocumentFragment();  
for (let i = 0; i < 1000; i++) {  
    let div = document.createElement('div');  
    div.textContent = 'Item ' + i;  
    fragment.appendChild(div);  
}  
document.getElementById('container').appendChild(fragment);
```
### 3. Optimise Loops and Avoid Excessive Function Calls

Loops and function calls could be a bit of a headache when they are running in JavaScript, specifically, if the mathematically hard calculations or the array operations which are computationally complex are involved. Meet loops obey strictly for loops wherever does not need nested loops and the iteration number could be reduced by the implementation of some of the different approaches. Map(), filter(), and reduce() are some of them.
```javascript
// Inefficient loop  
let sum = 0;  
for (let i = 0; i < array.length; i++) {  
    sum += array[i];  
}  
  
// Efficient loop using array reduce method  
let sum = array.reduce((acc, currentValue) => acc + currentValue, 0);
```
### 4. Minimise Object Property Access

While the prototypical inheritance of JavaScript resides, having to accessory the object properties are slower than to the local variables because of the JavaScript's prototype chain search. If you copy past over a multitude of property accesses, particularly within the performance-critical code path, you can expect an improvement.
```javascript
// Inefficient property access  
for (let i = 0; i < array.length; i++) {  
    let value = obj.property;  
    // Use 'value' here  
}  
  
// Efficient property access using local variable  
let property = obj.property;  
for (let i = 0; i < array.length; i++) {  
    let value = property;  
    // Use 'value' here  
}
```
### 5. Leverage Browser Developer Tools for Profiling

Powerful developer tools give you capabilities to find out the limitations that might hinder the performance of your JavaScript code, these can be in a way you measure time of affectations also. The most common way of spending the time of our code is really simple, although if you put the visualising of the analysis of the performance profiles. You will get the best way of showing what is wrong with the code that is running slow.

### Conclusion

Optimising JavaScript performance entails careful plan-making, coding, and mainly using browsers'-native tools as the preliminary step in debugging and evaluating. The techniques presented in this article when implemented can bring out enormous performance hikes to the JavaScript applications you are working on. It has to be said, that if you want to go further, you will be sure to offer a higher level of user experience, and experience the overall efficiency of the application will increase greatly. Do not only concentrate on the functionality of the application but also spend some time on JavaScript code optimization to ensure that your users enjoy faster, more responsive applications.