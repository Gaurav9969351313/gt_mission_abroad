# 🔥 Frontend Interview 

[**Web Knowledge**](### f45b)

-   [**1. Caching**](### 21a5)
-   [**2. HTTP/2**](### 4f67)
-   [**3. Security**](### 48af)

[**Web Performance**](### 59ff)

-   [**1. Critical Rendering Path**](### cfb1)
-   [**2. Reflow**](### 5178)
-   [**3. preload, preconnect, prefetch, prerender**](### b7ea)
-   [**4. Rendering Performance**](### 3a67)
-   [**5. Workers**](### 88cf)
-   [**6. Image Optimization**](### d8e2)

[**DOM**](### b93f)

-   [**1. Elements**](### 6776)
-   [**2. Manipulation**](### c97c)
-   [**3. Document Fragment**](### 96ac)
-   [**4. Event delegation and bubbling**](### 7e69)

[**HTML**](### a4e7)

-   [**1. Semantic Elements**](### fb9d)
-   [**2. Accessibility**](### dd22)
-   [**3. Responsive web**](### 115c)

[**Javascript**](### 071b)

-   **1.**`[**this**](### 84ab)`
-   [**2. Closure**](### 84b2)
-   [**3. Inheritance**](### 34f3)
-   [**4. Asynchronous Javascript**](### 0728)
-   [**5. Hoisting**](### 3cb1)
-   [**6. Currying**](### 59bc)
-   [**7. Higher-order functions**](### 6b87)

[**Design patterns**](### ebeb)

-   [**1. Mixin**](### 88ca)
-   [**2. Factory**](### c627)
-   [**3. Singleton**](### 862f)
-   [**4. Facade**](### 0b77)
-   [**5. MVC, MVVM**](### ca84)
-   [**6. Server vs Client-Side Rendering**](### 829f)

###  Intro

Of course, there is not enough space to fit all the frontend knowledge into one article. And this is not what this cheatsheet wants to achieve. This is just a shortcut of frontend topic, that each sr frontend engineer has to be familiar with. They are frequently raised in interviews and helped me to get an offer on Amazon and LinkedIn. Enjoy reading, and feel free to dive deeper by clicking on the topic link 🙌

###  Web Knowledge

**_1. Caching_**

-   [**_Cache-Control_**](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Cache-Control): instruction of request and response cache;
-   [**_Etag_**](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/ETag)_: <cache_id>_check if the resource was updated by comparing _<cache_id>_, if not — update the cached version;

**_2._** [**_HTTP/2_**](https://www.sitepoint.com/http2-the-pros-the-cons-and-what-you-need-to-know/)

_Pros:_

-   Multiple HTTP connection calls (HTTP/1 supports only 6);
-   A server can push an event to a client;
-   Compress headers;
-   More secure

_Cons:_

-   Server push can be abused;
-   Can be slower if LB (Load Balancer) supports HTTP/1 and server HTTP/2

**_3. Security_**

-   [_Transfer-Encoding_](https://www.geeksforgeeks.org/http-headers-transfer-encoding/) — defines how to encrypt body: _chunked_, _gzip;_
-   [_Access-Control-Allow-Origin_](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Access-Control-Allow-Origin) (Cross-Origin Resource Sharing — CORS) Defines a list of domains that can access the API of the origin domain;
-   [_JSONP_](https://www.w3schools.com/js/js_json_jsonp.asp### :~:text=JSONP%20stands%20for%20JSON%20with,instead%20of%20the%20XMLHttpRequest%20object.) — run script to access cross-domain data (old browser);
-   [_X-Frame-Options_](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/X-Frame-Options) — Prevent clickjacking from iframe;
-   [_Cross-Site Request Forgery_](https://owasp.org/www-community/attacks/csrf) **(**CSRF). _Attack_: user has a session (logged in), attacker creates link, user clicks on the link and performs the request, attacker steals user session. _Prevent:_ captcha, log out from visited site;
-   [_Content-Security-Policy_](https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP) — prevent from execution harmful code;
-   [_X-XSS-Protection_](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/X-XSS-Protection) — Enable XSS protection for old sites;
-   [_Feature-Policy_](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Feature-Policy) _—_ Disable not needed Browser features;
-   [_Referrer-Policy_](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Referrer-Policy) — when there is a link to another website from your site, by clicking it will send the URL of origin which can contain some sensitive data (user id, session);
-   Don't allow the user to input any HTML `innerHtml` ;
-   Use UI frameworks, keep node_modules updated, and limit of usage 3rd party services;

###  Web Performance

**_1._** [**_Critical Rendering Path_**](https://developer.mozilla.org/en-US/docs/Web/Performance/Critical_rendering_path) — steps browser makes to paint the page. The steps are:

-   _DOM_ — browser compiles the Document Object Model;
-   _CSSOM_ — browser compiles the CSS Object Model;
-   _Render Tree_ — browser combines DOM and CSSOM to render the tree;
-   _Layout_ — browser computes the size and position of each of the objects;
-   _Paint_ — browser converts the tree into the pixels in the screen;

Optimize **_CRP:_**

-   _Optimize the order of sources_ — load critical resources as soon as possible;
-   _Minimize the number of sources_ — reduce the number, load async;

**_2._** [**_Reflow_**](https://developers.google.com/speed/docs/insights/browser-reflow) _—_Browser recalculates the position and geometries of the elements after rerender.

Optimize **_Reflow:_**

-   reduce DOM depths;
-   avoid long CSS selectors, minimize rules;

**_3. preload, preconnect, prefetch, prerender_**

-   [_preload_](https://developer.mozilla.org/en-US/docs/Web/HTML/Link_types/preload) _—_ loads high prior sources that need to be loaded faster`<link rel="preload">` ;
-   [_preconnect_](https://developer.mozilla.org/en-US/docs/Web/HTML/Link_types/preconnect) _—_ If some resources are required to accelerate handshake, use`<link rel="preconnect">`to reduce latency;
-   [_prefetch_](https://developer.mozilla.org/en-US/docs/Glossary/Prefetch) — loads low prior resources and cache `<link rel="prefetch">`;
-   [_dns-prefetch_](https://developer.mozilla.org/en-US/docs/Web/Performance/dns-prefetch)—reduce latency of resolving domain names before resources get requested `<link rel="dns-prefetch">`;
-   [prerender](https://developer.mozilla.org/en-US/docs/Glossary/prerender) — similar to _prefetch_ + caches whole the page `<link rel="prerender">` ;

**_4. Rendering Performance_**

**JS:**

-   Move the heavy task to the [web worker](https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Using_web_workers);
-   Use `[requestAnimatinFrame](https://developer.mozilla.org/en-US/docs/Web/API/window/requestAnimationFrame)` instead of `setTimeout`to perform animation;

**Style:**

-   reduce the complexity of selectors;
-   Reduce the number of elements on which style calculation must be applied;

**Layout:** (how an element is positioned and sized)

-   Avoid layout changes;
-   Use `[flexbox](https://css-tricks.com/snippets/css/a-guide-to-flexbox/)`;
-   Use `[css-grid](/how-i-learned-css-grid-in-5-min-ec6439d8bf0)`;

**Paint:** (draw pixels: color, shadows; layout changes trigger repaint)

-   Use `[will-change](https://developer.mozilla.org/en-US/docs/Web/CSS/will-change)` to optimize layout repaint;

**_5. Workers_**

-   [_Service Worker_](https://developer.mozilla.org/en-US/docs/Web/API/ServiceWorker) _—_ interceptor to build an offline app;
-   [_Web Worker_](https://developer.mozilla.org/en-US/docs/Web/API/Worker) _—_ perform heavy tasks on background;

**_6. Image optimization_**

**Format**_:_

-   if animation — use `<video>`instead _gif_
-   if high details and resolution — _PNG_
-   if geometry shapes — _SVG_
-   if text logo — use font text
-   if photo — _JPEG_

**Compression**_:_

-   _SVG_ — use optimizer (like [SVGO](https://github.com/svg/svgo)), use gzip;
-   _WebP_ — use optimized image format for Web;
-   Remove metadata attributes from _SVG tag;_
-   Use [_Sprites_](https://www.w3schools.com/css/css_image_sprites.asp);

**Cache and Lazy Load**_:_

-   Use [_CDN_](https://aws.amazon.com/cloudfront/) for distributing static data;
-   _Lazy Load_ images and videos — Use `<img loading="lazy"/>` or libraries like [_lazysizes_](https://github.com/aFarkas/lazysizes);

###  DOM

**_1. Elements_**

-   **selector:** `getElementById`, `getElementByTagName`, `querySelector`, `querySelectorAll`;
-   **navigation:** `children` (elements): `childNodes` (nodes) , `firstElementChild`, `lastElementChild`, `parentElement`, `previousElementSibling`, `nextElementSibling`;
-   **attributes:** `classList`, `clientHeight`, `clientWidth`, `childElementCount`, `setAttribute(attrName, value)` `removeAttribute(attrName)` `removeAttribute(attrName)` ;

**_2. Manipulation_**

`createElement('div')`, `append`, `prepend`, `el.cloneNode(true)`, `remove()`, `insertBefore(newNode, beforeNode)`, `insertAfter(newNode, afterNode);`

**_3._** [**_Document Fragment_**](https://developer.mozilla.org/en-US/docs/Web/API/DocumentFragment) _—_ creates a virtual copy of a document, that can store multiple elements. By inserting _document fragment_ into DOM, it becomes empty, and cause only one [reflow](### 5178);

**_4._** [**_Event delegation and bubbling_**](https://programmingwithmosh.com/javascript/javascript-event-bubbling-and-event-delegation/)

-   When we emit an _Event,_ ex. `click`, the event is bubbling up to `<html>` element through the `parentElement` link:
```shell
-html (bubble click)  
   -body (bubble click)  
        -div (bubble click)  
            -p   
            -p (click)

-   _Delegation_ is used to improve performance. Let's say we have a structure:

-div.parent  
    -p.child   
    -p.child  
    -p.child
```
And we want to assign an `addEventListener` to `.child` , in this case, we have to attach an event to 3 elements. Instead, we can attach events only to `.parent` and resolve the logic.
```javascript
document.querySelector(".parent").addEventListener("click", function(event) {  
    if (event.target.classList.contains("child")) {  
      // you logic is here  
    };  
});
```
###  HTML

**_1. Semantic Elements_** — clearly describes its meaning with its name to developer and browser: `<article>`, `<aside>`, `<details>`, `<figcaption>`, `<figure>`, `<footer>`, `<header>`, `<main>`, `<mark>`, `<nav>`, `<section>`, `<summary>`, `<time>` ;

**_2. Accessibility_**

-   Use headers `<h1>,<h2>,<h3>…` ;
-   Use `<img alt=””`;
-   Use attribute`tabindex=”index_position”` to navigate the focus using `Tab` key;
-   Use `roles` like `<ul role=”list”><li role=”listitem”>`, `<dialog role=”dialog”`. Find the whole list [**here**](https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/Roles);
-   Use `accesskey=”key”` for creating keyboard shortcuts;
-   use attributes to describe the element:`aria-label=”label_text”`or `aria-labelledby=”text_id”`, `aria-describedby=”text_id”` and `<label id="text_id">label_text</label>` ;
-   Use color contrasts, textures;
-   Use text size;
-   Use captions in a video;

**_3. Responsive web_**

-   Add `<meta viewport name=”viewport” content=”width=device-width, initial-scale=1.0"` to give browser direction to scale;
-   Use `<img max-width=”100%”` and the image will not scale more than its size;
-   Use `<[picture](https://www.w3schools.com/tags/tag_picture.asp)> <source srcset=”” media=”” >` to specify images for different screen sizes;
-   Responsive [**font sizes**](https://css-tricks.com/confused-rem-em/): `em` and `rem` ;
-   Use [media queries](https://css-tricks.com/a-complete-guide-to-css-media-queries/);

###  Javascript


**_1._** `[**_this_**](https://javascript.info/object-methods)`

-   `this` is a reference to the object where a function is **called**;
-   default `this` context is `window`;
-   context which function will get from the place it called;
-   arrow function `->` takes context which function is **defined;**
-   `this` loses context when we call one function inside another function
```javascript
function Foo() {  
    console.log(this);   
}  
Foo(); // at this line the context is 'window'  
// output: 'window'var foo1 = new Foo(); // at this line the context binds to 'foo1'  
// output: 'Foo {}'
```
-   Explicitly assign the context of `this` : `foo1.apply(context, arrayOfArgs)`, `foo1.call(context, arg1, arg2, …)`, `var foo2 = foo1.bind(context, arg1, arg2, …)`— returns an instance of function with given context;

**_2._** [**_Closure_**](https://javascript.info/closure) **_—_** functions ability to remember and access scope even if was called from another scope (function return function/block scope in block scope)
```javascript
function a(arg1) { // arg1 scoped  
    var arg2 = 0; // arg2 scoped    return function b(){  
        ++arg2;  
        return arg1 + arg2;  
    }  
}var foo = a(2);  
foo(); // 3  
foo(); // 4  
var foo2 = a(4);  
foo(); // 5  
foo(); // 6
```
**_3._** [**_Inheritance_**](https://javascript.info/prototype-inheritance)

-   To inherit `obj1` from `obj2` , you can link an object to another object `var obj1 = Object.create(obj2);`
-   JS uses prototype inheritance. Each object has a `__proto__` link. If we access any property of an object, the JS engine first checks if the object has it, if not — checks the prototype, and goes through `__proto__` chain to find the property name, and then throws `undefined` if didn't find;

**_4._** [**_Asynchronous Javascript_**](/the-evolution-of-asynchronous-patterns-in-javascript-64efc8938b16)

-   **Event loop**: In JS there are 3 types of memory: `stack` used for functions call, `heap` for each of the objects, `queue` — setTimeout. JS engine executes the function `stack` first. If the `stack` is empty, it pops the event from `queue`. If the event `queue` has another function call, it pushes it to `stack` and executes it again until it is empty. This is called event loop;
-   JS uses `callback`, `promise`, async-await to implement asynchronous patterns. You can read more about **async JS** and **event loop** in this article:

[

### ###  🔥 The Evolution of Asynchronous Patterns in JavaScript
**_5._** [**_Hoisting_**](https://javascript.info/var)

-   `function` definition moves to the top of block scope during JS compilation, then goes `var` ;
-   `let` and `const` are hoisted too but in the temporary dead zone;
```javascript
// Code example              // After hoisting   
 console.log('hoisting');    | function foo(){  
 var a;                      |    return null;  
 function foo(){             | }  
    return null;             | var a;  
 }                           | console.log('hoisting');  
 a = 5;                      | a = 5;
```
**_6._** [**_Currying_**](https://javascript.info/currying-partials) _— nested functions:_
```javascript
function calcABC(a){  
    return function(b){  
        return function(c){  
            return a+b+c;  
        }  
    }  
}console.log(calcABC(1)(2)(3));  
// 6
```
**_7._** [**_Higher-order functions_**](https://www.freecodecamp.org/news/a-quick-intro-to-higher-order-functions-in-javascript-1a014f89c6b/)

-   `map`, `reduce`, `filter`, `find`
-   You can chain higher-order functions into `composition`
```javascript
[1,2,3,4,5].map((num) => ({age: num})).filter((el) => el.age < 4);  
// [{age: 1}, {age: 2}, {age: 3}]
```
###  Design patterns

**_1._** [**_Mixin_**](https://javascript.info/mixins) **_—_** extend the functionality of an object with the list of methods;
```javascript
// Option 1  
class Person{}let Mixin = {foo(){}};Object.assign(Person.prototype, Mixin);let person = new Person();person.foo();// Option 2let Mixin1 = {foo1(){}};let Mixin2  = {__proto__: Mixin1, foo2(){}};
```

**_2._** [**_Factory_**](https://www.javascripttutorial.net/javascript-factory-functions/) _— a_ class that can create one or many different objects (useful if you want to generate different mock data in Unit Tests);
```javascript
personFactory.one({name: 'John'}); -> Person{name: 'John', age: 5}  
personFactory.many(); -> [Person{name: 'Bill', age: 7}, Person{name: 'Anna', age: 3}]
```
**_3._** [**_Singleton_**](https://www.sitepoint.com/javascript-design-patterns-singleton/) — class which you can call the method directly, without creating an object;
```javascript
let mySingleton = (function() {    let instance = null;    function init(){  
        return {  
           //list all the methods           method(){}  
        }  
    }  
    if(instance == null){  
        instance = init();  
    }    return instance;  
})();mySingleton.method();
```
**_4._** [**_Facade_**](https://www.dofactory.com/javascript/design-patterns/facade) **_—_** abstract more complex logic and wrap it in class. For example, service that stays between component and API layer:

ui component - Facade service (complex state object) - API layer (Redux);

**_5. MVC, MVVM —_** [**Model View Controller**](https://en.wikipedia.org/wiki/Model%E2%80%93view%E2%80%93controller) and [**Model View ViewModel**](https://en.wikipedia.org/wiki/Model%E2%80%93view%E2%80%93viewmodel)**.**

_React is MVC_

-   state — `Model`;
-   JSX — `View`;
-   actions (violate — can be mixed with a view) — `Controller` ;

_Angular is MVVM_

-   component — `ModelView`
-   template — `View` (violate — not reusable)
-   properties — `Model`

**_6._** [**_Server vs Client-Side Rendering_**](https://www.freecodecamp.org/news/what-exactly-is-client-side-rendering-and-hows-it-different-from-server-side-rendering-bd5c786b340d/)

**SSR —** Use SSR if a site is stable, static, SEO focused, can pay for additional servers;

_pros_

-   Faster page load (viewable, but not interactable);
-   Better for search engines (faster indexing);
-   Better with sites that have a lot of static content (blogs);

_cons_

-   More server requests;
-   Slower render to interact;
-   Full page reloads;

**CSR —** Use CSR if site under development, dynamic;

_pros_

-   Faster render after initial load;
-   Best for web app;

_cons_

-   The initial load can require more time

---
# I failed a $190,000 FrontEnd Interview due to this try…catch question

I had a tech interview for a FrontEnd developer position with the annual salary of around $190,000, unfortunately I failed because I missed a `try…catch` question. Let me tell you what the question is, and maybe it can help you as well.

In JavaScript, the `try…catch` construct is often perceived as a safety net, a guardian against the perils of unexpected errors within code blocks. Many developers, including myself, have wielded it confidently in synchronous contexts. However, a seemingly innocuous question during an interview shattered my complacency, revealing a blind spot in my understanding: `try…catch` can only capture errors within synchronous code blocks.

###  The Challenge

The interview question that tripped me up was deceptively simple: are there any issues with the code snippets below?
```javascript
try {  
  setTimeout(() => {  
    throw new Error('err')  
  }, 200);  
} catch (err) {  
  console.log(err);  
}
```

and

```javascript
try {  
  Promise.resolve().then(() => {  
    throw new Error('err')  
  })  
} catch (err) {  
  console.log(err);  
}
```

Confounded, I faltered. How could these snippets be problematic? After all, isn't this a common pattern in coding? It was a stark reminder of the adage: familiarity breeds complacency.

###  The Revelation

Post-interview, armed with humility, I delved into the nuances of `try…catch`. The epiphany struck hard: `try…catch` is ill-equipped to handle asynchronous errors because it operates synchronously. In JavaScript, `setTimeout`, a quintessential asynchronous function, schedules its callback to the event queue, decoupling it from the `try…catch` block's execution.

###  The Solution

To confront this limitation, one must embrace a paradigm shift in error handling within asynchronous contexts. The correct approach involves integrating error handling directly into asynchronous operations using callbacks, Promises, or the modern `async/await` syntax.

Consider the corrected version of the first snippet:

```javascript
new Promise((resolve, reject) => {  setTimeout(() => {    try {      throw new Error('err');  
    } catch (err) {      reject(err);  
    }  
  }, 200);  
})  
  .then(() => {    // Handle successful execution  })  
  .catch((err) => {    console.log(err); // Error is caught here  });
```

And for the second snippet:

```javascript
// Method One: Using Promise chaining  
Promise.resolve()  
  .then(() => {  
    throw new Error('err');  
  })  
  .catch((err) => {  
    console.log(err); // Error is caught here  
  });  
  
// Method Two: Using async/await  
async function handleError() {  
  try {  
    await Promise.resolve().then(() => {  
      throw new Error('err');  
    });  
  } catch (err) {  
    console.log(err); // Error is caught here  
  }  
}  
  
handleError();
```

These revised implementations demonstrate a proactive approach to error management in asynchronous scenarios, leveraging the intrinsic capabilities of Promises and `async/await`.

My journey from interview failure to enlightenment underscored the importance of continuous learning and humility in the ever-evolving landscape of software development. Embracing the nuances of error handling in JavaScript not only enriches our understanding but also equips us to write more robust and resilient code.

So, fellow developers, let us not shy away from confronting our misconceptions. For it is in acknowledging our weaknesses that we pave the path to mastery.

If you found this article helpful, please encourage me by giving it a clap. Follow me for more interesting articles on web development.

--- 
#  🔍 Frontend Interview Questions You Actually Need to Prepare For 

If you're practicing frontend interviews in leading tech companies or MNCs, chances are you've already understood that it's not all about UI building anymore. Companies want you to show how well you understand JavaScript, systems thinking, and problem-solving capabilities that mirror real-world development.

Here's a handpicked list of **frontend interview questions** that you need to know — based on real interviews — and what you're actually supposed to know.

###  🧠 JavaScript Fundamentals

These are the bread and butter of any frontend interview. Be prepared to be asked not only what things are, but why they work the way they do.

-   **Closures**: Define closures by coding `createCounter()`. Interviewers love this because it tests understanding of scope.
-   **Memoization**: Code a `memoize()` function that stores expensive function calls. Perfect for optimization questions.
-   **Polyfills**: Recreate`Array.prototype.map`, `reduce`, and `Function.prototype.bind` from scratch. This demonstrates your in-depth knowledge of how JavaScript works under the hood.
-   **Async Handling**: Write `fetchWithRetry()` to handle flaky APIs elegantly. Bonus points if you add exponential backoff.
-   **Custom Promise.all**: Write a `promiseAll()` function to manage multiple asynchronous tasks — a great challenge for Promise handling.
-   **Debounce**: Write a `debounce()` function to optimize high-frequency events like `onInput` or `onScroll`.
-   **Event Loop Deep Dive**: Be ready to describe the output of async JavaScript puzzles involving `setTimeout`, `Promise`, and microtasks.

###  📚 Arrays: Think Beyond the Basics

These are not just DSA problems — they challenge your skill at writing efficient code under time constraints.

-   **Rotate by K**: Rotate an array left or right by _k_ positions — classic pointer manipulation.
-   **Max Subarray (Kadane's Algorithm)**: Find the maximum sum of a contiguous subarray — a frequent question in both product and service-based companies.
-   **Two-Pointer Pattern**: Solve pair-sum problems efficiently. A must-know technique.
-   **Sort 0s, 1s, 2s**: Use the Dutch National Flag algorithm to sort with O(1) space.
-   **Sliding Window**: Find the longest substring without repeating characters — this one shows up everywhere.
-   **Fixed Window Sum**: Get the maximum sum of a fixed-size subarray — excellent to demonstrate time complexity thought.

###  🔤 Strings: Demonstrate You Can Manipulate Text Effectively

String problems usually have covert edge cases. These challenge your accuracy and string-pulling ability.

-   **Anagram Check**: Check Weather two strings are anagrams using sorting or frequency maps.
-   **First Unique Character**: Get the first non-duplicate character — excellent use case for hash maps.
-   **Longest Palindromic Substring**: Apply expand-around-center or dynamic programming methods.
-   **Rearranged Palindrome**: Verify whether characters can be rearranged to create a palindrome — unexpectedly frequent in interviews.

###  🧩 Objects: Master Core JavaScript Structures

Modern JavaScript is object manipulation-intensive. Be prepared to show these:

-   **Deep Clone**: Recursively clone nested objects. Bonus points if you deal with edge cases such as circular references.
-   **Flatten Object**: Transform deeply nested objects into a flat map with dot notation for keys.
-   **Frequency Counters**: Apply object maps to count frequencies of elements — a versatile method for most problems.

###  💡 Real-World Scenarios: Beyond Just Algorithms

These demonstrate you can code something that's useful and scalable.

-   **Pagination Logic**: Take a page number and size as input and divide an array into paginated segments.
-   **Debounce in UI**: Apply debounce to a real UI element (such as a search input).
-   **Throttle API Calls**: Throttle rapid-fire API calls with a throttle function — a must-have for production-ready code.

###  🛠 Advanced Concepts & Systems Thinking

Senior or mid-level positions are within reach if these distinguish you from the pack.

-   **DOM Tree Serialization**: Serialize a DOM structure into JSON and deserialize from JSON back into a DOM structure — exemplifies recursion and knowledge of the DOM.
-   **Event Delegation**: Handle events on dynamic elements effectively with low memory overhead.
-   **LRU Cache**: Write Least Recently Used cache using a Map — commonly asked in system design interviews.
-   **Custom Promise Class**: Recreate a basic `Promise` class with `.then`, `.catch`, `.resolve` — tests deep knowledge of async flows.
-   **Dependency Graph Resolution**: Model how bundlers (such as Webpack) resolve dependencies in a directed graph.

###  🎯 Interview Tips That Actually Work

1.  **Walk through your thought process** before you write code — communication is more important than you realize.
2.  **Handle edge cases upfront** — it reflects maturity and experience.
3.  **Write clean, modular code** — even during interviews, readability trumps smart tricks.

---


# JavaScript Frontend Interview Questions

### 1. What data types exist in JavaScript?

1.  Number — Numbers
2.  String — Strings
3.  Boolean — Boolean type, true or false
4.  Object — JavaScript object
5.  null — a special value that represents “nothing”, “empty”, or “unknown value”.
6.  undefined — “value has not been assigned”. This type is assigned if a variable is declared but has no assigned value.
7.  Symbol — a unique and immutable data type that can be used as an identifier for object properties.
8.  BigInt — used for creating large numbers.

`const bigInt = 1234567890123456789012345678901234567890n;`

### 2. What is the difference between “==” and “===”?

The operator “==” checks for abstract equality, while “===” checks for strict equality.  
In other words, the “==” operator performs necessary type conversions before comparison, whereas “===” does not perform type conversion. Therefore, if two values are not of the same type, it will return false when using the “===” operator.

### 3. What are the ways to declare a variable?

There are 4 ways to declare a variable:
![](https://miro.medium.com/v2/resize:fit:875/1*9TTze8sbyx9IDhTD-w5sKA.png)

Declaring a variable using the `var` keyword is similar to older methods of declaring variables in JavaScript. Variables declared this way have **function scope** if declared within a function and **global scope** if declared outside of any function. However, they lack **block scope**, which can lead to unintended behaviors in code.

In contrast, `let` and `const` are preferable for declaring variables. Both have **block scope**, meaning a variable declared inside a block (e.g., within a function, loop, or conditional statement) will not be accessible outside of that block.

The `const` keyword is used to declare variables that are immutable, meaning the variable itself cannot be reassigned. However, if a `const` variable is an object or an array, you can still modify the properties of the object or the elements of the array.


### 4. What is the difference between null and undefined?

Both options represent an empty value. If we initialize a variable but don't assign a value to it, it will be assigned a special marker — undefined. Null is assigned manually.

Null is a special value that represents “nothing,” “empty,” or “unknown value.” If we need to clear the value of a variable, we set foo = null.

[Learn more](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/null)

### 5. Arrow functions and the differences from regular functions.

1.  Arrow functions cannot use the arguments object.
2.  They have a different syntax.
3.  Arrow functions do not have their own this context. When referencing this, an arrow function takes the context from the surrounding scope.
4.  Arrow functions cannot be used as constructor functions. In other words, they cannot be invoked with the new keyword.

[Learn more](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Functions/Arrow_functions)

### 6. What is a closure and why are they needed?

A closure is a feature in JavaScript where a function retains access to variables from its lexical scope even after the function has finished executing. Essentially, when an inner function is defined within an outer function, it forms a closure by 'closing over' the variables of the outer function. This allows the inner function to continue accessing and manipulating those variables even after the outer function has returned.

![](https://miro.medium.com/v2/resize:fit:875/1*GdpgSS8I30GOcn1etd72ow.png)

[Learn more](https://javascript.info/closure)

### 7. What are template literals?

Template literals are enclosed in backticks (``) and allow for multiline strings. They also allow for embedding expressions within them.

![](https://miro.medium.com/v2/resize:fit:875/1*f9Fm-jA1K91rY495SdUOWw.png)

[Learn more](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Template_literals)

### 8. What are Set and Map?

Map is a collection, a data structure that operates on the principle of key-value pairs, similar to Objects. However, the main difference between Map and Object is that Map allows the use of keys of any type.  
Set is a type of collection without keys, an array where each value can only appear once. Set stores unique values within itself.

[Learn more](https://javascript.info/map-set)

### 9. How to check for the presence of a property in an object?

The first way is to use the hasOwnProperty function, which is available for every object.  
The second way is to use the in operator. However, when using the in operator, caution must be exercised as it checks all prototypes in the chain.

![](https://miro.medium.com/v2/resize:fit:875/1*xYk7CWllFOOWh9EIYd806w.png)

[Learn more](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/hasOwnProperty)

### 10. How to access an object property?

The first way is static, using dot notation: obj.a.  
The second way is dynamic, using square brackets: obj['a'].

![](https://miro.medium.com/v2/resize:fit:875/1*gK6nW2HgAsNtCO2nwB8KXg.png)

[Learn more](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Working_with_Objects)

### 11. What are the main methods for working with arrays?

-   forEach — an iterative method for looping through the array, does not return anything. It offers a more elegant alternative to a regular for loop.
-   filter(callback, [args]) — a method for filtering an array using a provided function. It creates a new array that includes only the elements from the original array for which the callback(item, i, arr) function returns true.
-   map(callback, [args]) — a method for transforming an array. It creates a new array that consists of the results of calling the callback(item, i, arr) function for each element of the array.
-   reduce(callback, [initValue]) — a method for sequentially processing each element of the array while maintaining an intermediate result.

[Learn more](https://javascript.info/array-methods)

### 12. What are the ways to create an object?

Using a constructor function:

![](https://miro.medium.com/v2/resize:fit:875/1*vJFxy5bT2V3mjReTY2Ybfw.png)

Using object literal notation:

![](https://miro.medium.com/v2/resize:fit:875/1*5FrwaopNpFFfeCJ6s91U8Q.png)

Using a class:

![](https://miro.medium.com/v2/resize:fit:875/1*sEcAaWg9xZ9jDOFs72oApg.png)

Using the create function:

![](https://miro.medium.com/v2/resize:fit:875/1*O25N3YRqgJVIr-5oAKHJAg.png)

### 13. What is a Promise?

A Promise is an object designed to work with asynchronous code. It maintains its own state. Initially, a Promise is in the pending state, then it transitions to the fulfilled state if the asynchronous code is executed successfully, or to the rejected state if an error occurs. A Promise accepts two callback functions:

-   onFulfilled, which is triggered when the Promise is fulfilled.
-   onRejected, which is triggered when the Promise is rejected.

The usage pattern is as follows:

1.  The code that needs to perform something asynchronously creates a Promise and returns it.
2.  The external code, upon receiving the Promise, passes the onFulfilled and onRejected callback functions to it.
3.  Upon completion of the process, the asynchronous code transitions the Promise to the fulfilled or rejected state, automatically invoking the corresponding callback function.

[Learn more](https://javascript.info/promise-basics)

### 14. What is async/await and how to use it?

async/await is a special syntax for working with Promises.  
A function declared with the async syntax always returns a Promise.  
The keyword await makes the JavaScript interpreter wait until the Promise on the right side of await is fulfilled before continuing the execution. It will then return the result, and the code execution will proceed. await cannot be used in regular functions.

[Learn more](https://javascript.info/async-await)

### 15. How to check if an object is an array?

To check whether an object is an array or not, you can use the Array.isArray() method. It takes an object as input and returns true if the object is an array, and false if it is not an array.

![](https://miro.medium.com/v2/resize:fit:875/1*phJsNkOCgbpjDTz-k-0EIw.png)

### 16. What is the purpose of the spread operator?

The spread operator (…) is used to unpack arrays or objects.  
It allows you to expand elements that are iterable, such as arrays and strings.

-   It is used in functions where the expected number of arguments for a call is zero or more.
-   It is used in array literals or expressions.
-   It is used in object literals where the number of key-value pairs should be zero or more.

![](https://miro.medium.com/v2/resize:fit:875/1*vIrc5n9IWnwVkpHNAjvQEg.png)

[Learn more](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Spread_syntax)

### 17. How to avoid reference dependency when copying an object?

If the object does not contain nested objects, for example:

![](https://miro.medium.com/v2/resize:fit:875/1*86wKZ5rXznUp9pxNwYmxaw.png)

In this case, you can use **spread operator** or **Object.assign()** method:

![](https://miro.medium.com/v2/resize:fit:875/1*BEM_DGPwj1l9Fsbl2jcvdg.png)

If the object contains nested objects:

![](https://miro.medium.com/v2/resize:fit:875/1*_xpmX3Br6wKgbTmbLzSy1Q.png)

In this case, you need to perform a deep copy.  
A workaround, though **slower**, is:

![](https://miro.medium.com/v2/resize:fit:875/1*SxNfj0tVgSdVFNxASeyTyQ.png)

This method is suitable for objects without prototypes and functions.  
Alternatively, you can use the lodash library's **deepClone()** function.

### 18. How to change the context of a function?

1.  Using the **bind()** method, which returns a new function with the bound context.

![](https://miro.medium.com/v2/resize:fit:875/1*o25EEiSKJdc3CLdsZ5nsfw.png)

1.  Using **call()** and **apply()** methods. The main difference is that **call()** accepts a sequence of arguments, while **apply()** accepts an array of arguments as the second parameter.

![](https://miro.medium.com/v2/resize:fit:875/1*MKoPKuewo22CowebqT24sA.png)

### 19. What is a ternary operator / **conditional operator**.?

A ternary operator is a shorthand notation for an if-else statement. The operator is represented by a question mark and a colon. It is called ternary because it is the only operator that takes three arguments.

Condition ? Expression_1 : Expression_2

![](https://miro.medium.com/v2/resize:fit:875/1*KEW4z8aXg-IpEA_37ExWOA.png)

[Learn more](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Conditional_Operator)

### 20. What is destructuring?

Destructuring is a syntax that allows us to unpack arrays and objects into multiple variables.

![](https://miro.medium.com/v2/resize:fit:875/1*3PUUO1NQKZqdV2b3TwLGFw.png)

[Learn more](https://javascript.info/destructuring-assignment)

### 21. What is the DOM?

DOM stands for Document Object Model. It is a representation of an HTML document as a tree of tags.  
Example  
Each node in the DOM tree is an object.

![](https://miro.medium.com/v2/resize:fit:875/0*5G_at4gLGcrEuCl7.png)

The basic elements of an HTML document are tags.  
According to the Document Object Model (DOM), each HTML tag is an object. Nested tags are “children” of their parent element. The text inside a tag is also an object. All these objects are accessible using JavaScript, and we can use them to manipulate the page.

[Learn more](https://javascript.info/dom-nodes)

### 22. What is the Event Loop?

Event loop — a mechanism that manages the execution of code. It handles event processing and task execution in the correct order. The main idea of the event loop is that JavaScript runs in a single-threaded environment but can handle asynchronous operations. When an asynchronous operation, such as a server request, completes, it puts the corresponding event into the event queue. The event loop works in a loop, processing these events in the order they arrive. It takes an event from the queue and passes it for execution. If the event contains a callback or a handler, it is invoked, and the code associated with that event is executed. The event loop also handles other tasks, such as timers and microtasks (Promise). It manages the execution order of all these tasks to ensure consistency and prevent the blocking of the main thread of code execution.

In short, the event loop in JavaScript manages asynchronous operations by handling events in the queue and executing the corresponding code in the correct order. This allows JavaScript to be responsive and effectively utilize its resources when working with asynchronous operations.

![](https://miro.medium.com/v2/resize:fit:875/0*9ZbiKJ0EM31GDXNX.png)

I highly recommend watching the video at the link provided, as the topic is important and deserves a separate article.

[Learn more](https://www.youtube.com/watch?v=8aGhZQkoFbQ&t=15s&ab_channel=JSConf)

### 23. What is prototypal inheritance?

Every object in JavaScript has a property — a prototype. Methods and properties can be added to the prototype. Other objects can be created based on the prototype. The created object automatically inherits the methods and properties of its prototype. If a property is absent in the object, its search will be performed in the prototype.  
[Learn more](https://javascript.info/prototype-inheritance)

### 24. What is the Optional Chaining operator?

The Optional Chaining operator ?. stops the evaluation and returns undefined if the part after ?. is either undefined or null.

Let's consider a user object. Most users have an address user.address, with a street user.address.street, but some users have not provided an address. In such cases, the Optional Chaining operator can help us avoid an error when trying to access the user's street who hasn't specified one in their address.

![](https://miro.medium.com/v2/resize:fit:875/1*KBNGf-8UB9deTz7hqKZjRg.png)

[Learn more](https://javascript.info/optional-chaining)

### 25. What is Shadow DOM?

Shadow DOM is a set of web standards that allows for encapsulating the structure and styles of elements on a web page. It represents a special segment of the DOM that resides inside an element and is separate from the rest of the page. Shadow DOM is used to create components and widgets with isolated and stylized content that does not conflict with the overall structure of the page.  
[Learn more](https://javascript.info/shadow-dom)

### 26. What is recursion? How to use it?

Recursion is an approach to problem-solving where a function solves a problem by reusing itself within its own function body. In simple terms, it's when a function calls itself.

A recursive function consists of:

1.  Termination condition or base case
2.  Recursive step — a way to reduce the problem into simpler forms.

![](https://miro.medium.com/v2/resize:fit:875/1*VP1M4IsEI5ERGOUFSHCA7w.png)

The base case is a necessary condition; otherwise, it will lead to stack overflow due to an infinite loop of function calls.  
[Learn more](https://javascript.info/recursion)

### 27. What's the difference between Function Expression and Function Declaration?

Function Declaration is the traditional way of declaring a function.

![](https://miro.medium.com/v2/resize:fit:875/1*PWs2lax4hCxuhAoyakYlZw.png)

Function Expression:

![](https://miro.medium.com/v2/resize:fit:875/1*SpLynR8X3AwBh1tWQtPjMQ.png)

With Function Declaration, the function is created and assigned to a variable, just like any other value. Essentially, it doesn't matter how the function is defined, as it is a value stored in the variable “foo”. Function Declarations, however, are processed before the code block is executed, meaning that they are visible throughout the entire code block. On the other hand, Function Expressions are created only when the execution flow reaches them.

[Learn more](https://javascript.info/function-expressions)

### 28. What are constructor functions?

Constructor functions are regular functions that are used to create objects. However, there are two rules for using them:

1.  The name of the constructor function should start with a capital letter.
2.  The constructor function should be called using the new operator.

![](https://miro.medium.com/v2/resize:fit:875/1*dGrlUq53AgVlchTu2NLPYg.png)

When a constructor function is created using the new operator, the following happens:

1.  A new empty object is created and assigned to this.
2.  The code inside the constructor function is executed. Typically, this code will modify the this object and add new properties.
3.  The value of this is returned.

[Learn more](https://javascript.info/constructor-new)

### 29. How can you get a list of keys and a list of values from an object?

You can use Object.keys() to get a list of keys and Object.values() to get a list of values.

![](https://miro.medium.com/v2/resize:fit:875/1*2Zx9Hma7YzS7iCHxwxNxjQ.png)

[Learn more](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object)

### 30. Provide an example of new functionality in ES6.

The most common ones:

-   let and const. Introduction of new keywords let and const for declaring variables with block scope.
-   Arrow functions. The concept of arrow functions allows for more concise and clear function definitions.

![](https://miro.medium.com/v2/resize:fit:875/1*GWN0bHWpy7TVj-Vz0TKyOw.png)

-   Default parameters. You can define default values for function parameters.

![](https://miro.medium.com/v2/resize:fit:875/1*M7OITkxh2rIFKN1lPxU_zg.png)

-   Spread operator (…). The spread operator allows unpacking array or object elements for function arguments or creating new arrays/objects.

![](https://miro.medium.com/v2/resize:fit:875/1*fWFl41dfuo0HT1CoaBArNQ.png)

-   Destructuring. Destructuring allows extracting values from arrays or objects and assigning them to variables.

![](https://miro.medium.com/v2/resize:fit:875/1*OCaBufTUszETwxPTnnzJkg.png)

[Learn more](https://www.w3schools.com/js/js_es6.asp)

### 31. How to do class inheritance in ES6?

Class inheritance is done using the “extends” keyword followed by the name of the parent class.

![](https://miro.medium.com/v2/resize:fit:875/1*v--iovTJyQ_ZCNlOXweKyw.png)

[Learn more](https://javascript.info/class)  
[And even more](https://javascript.info/class-inheritance)

### 32. What are micro and macro tasks in JavaScript?

In JavaScript, microtasks and macrotasks refer to types of tasks that need to be executed in the event loop. Microtasks are tasks that need to be executed within the current event loop before the browser repaints the page. They are usually added to the execution queue using methods such as Promise.then(), process.nextTick() (in Node.js), or MutationObserver. Examples of microtasks include executing promise handlers and DOM mutations. On the other hand, macrotasks are tasks that need to be executed after the current event loop is finished and before changes are rendered on the screen. This includes tasks added to the event queue using setTimeout, setInterval, requestAnimationFrame, as well as handling input events and network requests. Macrotasks are executed after all microtasks in the current event loop have been processed. The difference between microtasks and macrotasks is important because it determines the order of execution and allows for managing the priority of different tasks in JavaScript. Microtasks have a higher priority and are executed before macrotasks, which allows for faster interface updates and prevents blocking the main JavaScript execution thread.  
[Learn more](https://javascript.info/event-loop)

### 33. What are generators?

Generators produce a sequence of values one by one as needed. Generators work well with objects and make it easy to create data streams.

To declare a generator, a special syntax is used — a generator function.

![](https://miro.medium.com/v2/resize:fit:875/1*L0QPMWViuIFnukKtbgbzaQ.png)

next() is the main method of a generator. When called, next() starts executing the code until the nearest yield statement. The value may be absent, in which case it is represented as undefined. When a yield is reached, the function execution is paused, and the corresponding value is returned to the outer code.

![](https://miro.medium.com/v2/resize:fit:875/1*wMMQ9U_-omuY7NJkOZ2UHA.png)

[Learn more](https://javascript.info/generators)

### 34. What are the methods of storing data in a browser?

There are several methods of storing data in a browser:

-   LocalStorage and SessionStorage — store key-value pairs in the browser. The data stored in them is retained after the page is refreshed. Both storage options can only use strings as keys and values, so objects need to be converted using JSON.stringify().
-   Cookie — small strings of data that are stored in the browser. Cookies are usually set by the web server using the Set-Cookie header. The browser will then automatically add them to almost every request to the same domain using the Cookie header. One cookie can hold up to 4kb of data. Depending on the browser, more than 20 cookies per site are allowed.
-   IndexedDB — a built-in database, more powerful than localStorage. It is a key-value store where multiple types of keys are available and values can be almost anything. IndexedDB supports transactions for reliability, supports key range queries and indexes, and allows storing more data than localStorage. IndexedDB is designed for offline applications and can be combined with Service Workers and other technologies.

[Learn more](https://javascript.info/localstorage)  
[Learn more](https://javascript.info/cookie)  
[Learn more](https://javascript.info/indexeddb)

### 35. What is the difference between sessionStorage and localStorage?

SessionStorage and localStorage allow storing objects in key-value format in the browser.  
The main differences are:

-   localStorage can store up to 10 MB of data, while sessionStorage can store up to 5 MB.
-   Data in localStorage is not deleted, while data in sessionStorage is deleted when the browser tab is closed.
-   Data from localStorage is accessible from any window, while data from sessionStorage is only accessible from the same browser window.

[Learn more](https://javascript.info/localstorage)

### 36. What are regular expressions?

Regular expressions are strings defined by special rules and patterns. They are a powerful tool that allows detecting and working with complex constructions within strings.

![](https://miro.medium.com/v2/resize:fit:875/1*leCnSAbkOwwx20immjxBQw.png)

[Learn more](https://javascript.info/regular-expressions)

### 37. What are WeakSet and WeakMap and how do they differ from Map and Set?

The first difference between WeakMap and Map is that the keys in WeakMap must be objects, not primitive values.  
The second difference is in the memory storage of the data structures. The JavaScript engine keeps values in memory as long as they are reachable, meaning they can be used.  
Usually, object properties, array elements, or other data structures are considered reachable and are kept in memory as long as the data structure exists, even if there are no other references to them.  
In the case of WeakMap and WeakSet, it works differently. Once an object becomes unreachable, it is removed from the data structure.

[Learn more](https://javascript.info/weakmap-weakset)

### 38. Why do two objects with the same fields return false when compared?

Objects are compared based on references to the memory area. For JavaScript, test1 and test2 objects are different, even though they have the same fields. Objects are only equal if they are the same object.

![](https://miro.medium.com/v2/resize:fit:875/1*VVZ2f7e5MxuVWNSGGenlZA.png)

### 39. Why can we call methods on primitive types?

JavaScript allows working with primitive data types — strings, numbers, etc. — as if they were objects. Primitive data types have methods.  
To make this functionality available, each primitive data type has its own wrapper object: String, Number, Boolean, and Symbol. Thanks to these wrapper objects, primitive data types have different sets of methods, such as toLowerCase() or toUpperCase().

[Learn more](https://javascript.info/primitives-methods)

### 40. How to check which class an object was created from?

You can check which class an object was created from using the **instanceof** operator, taking inheritance into account.

![](https://miro.medium.com/v2/resize:fit:875/1*CNzL4yA_DPPjdzKuHZsA9Q.png)

[Learn more](https://javascript.info/instanceof)

### 41. Write code that will log the time spent on the site in seconds every 10 seconds.

![](https://miro.medium.com/v2/resize:fit:875/1*fwXOGWtrSE5Lc9bArYY1MA.png)

[Learn more](https://javascript.info/settimeout-setinterval)

### 42. What is a pure function?

A pure function is a function that satisfies two conditions:

1.  Every time the function is called with the same set of arguments, it returns the same result.
2.  It has no side effects, meaning it does not modify variables outside the function.

![](https://miro.medium.com/v2/resize:fit:875/1*_1WdwSJCLWHWX5lZeylPiQ.png)

### 43. What is a higher-order function?

A higher-order function is a function that takes another function as an argument or returns a function as a result.

![](https://miro.medium.com/v2/resize:fit:875/1*tqycavQ5MVMFHLP3mlJ6Gg.png)

### 44. Why do we need Promises if we can work with asynchronous code using callbacks?

If we want to asynchronously fetch some data from a server using callback functions, it would result in the following:

![](https://miro.medium.com/v2/resize:fit:875/1*t8l4-7KccQf6aMuzU5RAvA.png)

This is called **callback hell**, as each callback is nested inside another, and each inner callback depends on the parent function.

Using Promises, we can rewrite the code above:

![](https://miro.medium.com/v2/resize:fit:875/1*2KDO49DFtlBiPgUizGXuXw.png)

With Promises, the execution sequence is clear, making the code more readable.  
[Learn more](https://javascript.info/promise-basics)

### 45. Write your own implementation of the bind method.

To implement it, we can use closure and the apply() method to bind the function to the context.

![](https://miro.medium.com/v2/resize:fit:875/1*sk5h_Hq3jSlBEgC73Uod3A.png)

### 46. Write a calculator function with methods plus, minus, multiply, divide, and get. The function must work through optional chaining.

![](https://miro.medium.com/v2/resize:fit:875/1*Ddrb6taodsonPYUZeE0Olw.png)

### 47. Write a randomSort function that takes an array of numbers and sorts the array in random order.

You can use the sort() method and Math.random() for this.

![](https://miro.medium.com/v2/resize:fit:875/1*-BfyMUIuhNfILfH-EVeQCA.png)

### 48. Write a deleteGreatestValue function that takes a two-dimensional array of numbers and removes the greatest number from each nested array.

We should iterate through every nested array, get the greatest value of each nested array and delete it.

![](https://miro.medium.com/v2/resize:fit:875/1*4dIuEC057vwud6-Emwzj4Q.png)

### 49. Write a sortPeople function that takes an array of strings names and an array of numbers heights, where names[i] == heights[i]. It should sort the names array based on the heights array.

![](https://miro.medium.com/v2/resize:fit:875/1*6TQdIPCikg5OUND8duhO5w.png)

### 50. Write a subsets function that takes an array of numbers nums and returns all possible variations of arrays from those numbers.

![](https://miro.medium.com/v2/resize:fit:875/1*ggmRMrqBiHvOFuzu4mi6tA.png)

### 51. How to reverse a linked list?

Lets create a function reverseLinkedList that takes a linked list as input and returns the reversed version of that list.

Approach:

1.  It initializes the result variable with null, which will hold the reversed list.
2.  It initializes the root variable with head, which points to the start of the list.
3.  It enters a while loop that continues until root becomes null, indicating the end of the list.
4.  Inside the loop, it checks if result already has elements. If it does, it creates a new list node with the current value root.val and a pointer to the next node result. It then updates result with this new node.
5.  If result doesn't have any elements yet, it creates a new list node with the current value root.val and null as the pointer to the next node. It then updates result with this new node.
6.  After updating result, it moves to the next element in the list by assigning root.next to root.
7.  Once the while loop finishes, it returns the reversed list stored in result.

In summary, the function reverses the linked list by iterating through each node from the head to the tail, creating a new list node for each value and updating the pointers accordingly.

![](https://miro.medium.com/v2/resize:fit:875/1*21n416p6nVZzqZmihUMqVw.png)

### 52. How to sort a linked list?

Lets create a function sortList that takes a linked list as input and returns the sorted version of that list.

Approach:

1.  Check if the given linked list is empty or not.
2.  Traverse the linked list and store the node values into an array.
3.  Sort the array using the built-in sort() method.
4.  Create a new linked list using the sorted array.
5.  Return the head of the created linked list.

![](https://miro.medium.com/v2/resize:fit:875/1*IxObe8BfVyP1Mhpvay6v9Q.png)

### 53. What's the difference between observables and promises?

Observables and Promises are both used for handling asynchronous operations in JavaScript. A key difference is that Observables can emit multiple values over time. They are suitable for handling streams of data, such as user interactions, events, or data from APIs that change over time. Promises on the other hand can only resolve once with a single value. They are suitable for handling single asynchronous operations that will either succeed or fail.

In summary, Promises are best suited for handling one-time asynchronous operations with a single result, while Observables are more powerful when dealing with ongoing streams of data, events, and complex data processing pipelines. The choice between them depends on the specific use case and the nature of the asynchronous operations you're dealing with.

[Learn More](https://codingbootcamps.io/resources/observables-vs-promises-whats-the-difference/)


---

# Is JavaScript Array.push() a Deep or Shallow Copy?

Let's discuss one interesting JavaScript topic today. Even beginners of JavaScript will be aware of array and adding and removing values from it. But most of us do not try to understand internal implementation of all array functions (Sometimes it is not possible also, to understand implementation of every function !!).

So today let us discuss about array.push method. If your are not aware, how array.push works then here is the official [link](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/push) for it.

![](https://miro.medium.com/v2/resize:fit:438/0*hi7yig8dFI0tChsz.png)
Source — Wikipedia

Let's start with easy example: Can you guess the output of below snippet?
```javascript
let arr = [];  
let x = 10;  
arr.push(x);  
x = 20;  
console.log(arr);   
console.log(x);
```
It's pretty straight forward `arr` will print 10 and `x` will be printed as 20.

Now lets slightly complicate it. Try to guess the code without executing it.
```javascript
var array = [];  
var y = {name: "test", type: "data", data: "2-27-2009"};  
array.push(y);  
y.name = "foo";  
console.log(array);
```
If your from Java, c# background you would guess the output will be:
```javascript
`[{name: “test”, type: “data”, data: “2–27–2009”}]`
```
But the actual output is:
```javascript
`[ { name: “foo”, type: “data”, data: “2–27–2009” } ]`
```
Now let's tweak it again, guess the output of this without executing,
```javascript
var array = [];  
var y = {name: "test", type: "data", data: "2-27-2009"};  
array.push(y);  
array[0].name = "foo";  
console.log(y);  
console.log(array);
```
So, the output is:

_// y  
{ name: 'foo', type: 'data', data: '2–27–2009' }__// array  
[{ name: 'foo', type: 'data', data: '2–27–2009' }]_

By now you might have understood when we push an object into an array, rather adding the contents of the object the reference is copied. So, if you change the object or the array where it is pushed, it will modify the same reference. So both array and object gets updated at the same time.

Now the next question: **Does array.push() does deep copy or shallow copy?**

For those of you, who do not know what is deep and shallow copy, here is the quick definition.

## Shallow copy

Shallow copy is a bit-wise copy of an object. A new object is created that has an exact copy of the values in the original object. If any of the fields of the object are references to other objects, just the reference addresses are copied i.e., only the memory address is copied. So, if you change any object both get's changed due to sharing of common reference.

## Deep copy

A deep copy copies all fields, and makes copies of dynamically allocated memory pointed to by the fields. A deep copy occurs when an object is copied along with the objects to which it refers. So, if you change any object only that object gets changed as both will have different reference.

So answering above question, It depends upon what you're pushing. Objects and arrays are pushed as a pointer to the original object. Built-in primitive types like numbers or booleans are pushed as a copy.

Now let's extend the above example further,
```javascript
var array = [];  
var y = {name: "test", type: "data", data: "2-27-2009"};  
array.push(y);  
y = {};   
y.name = 'bar';  
console.log(array);  
console.log(y);

Output is:

// array   
[ { name: 'test', type: 'data', data: '2–27–2009' } ]// y  
{ name: 'bar' }
```
Here array value didn't change after changing 'y.name' because, when we initialise

y = {}

`y` points to new reference, now previous reference which was copied to array is only pointed by array. So, by changing value of `y`, array value will not change.

**What are the best practices to deep copy a variable so that we will not face this problem?**

I will discuss that in my next article. Till then happy reading.

---
# The Problem with Returning Values from Async Await Functions 

###  **What are async and await?**

In simple words they are syntactic sugars for promise nesting. In case you're not aware of it, read my article that explains async and await [here](https://medium.com/geekculture/does-async-await-block-javascript-main-thread-c07db9c48c3e).

Assuming you have read above article and know what is async and await let's take up a simple example.
```javascript
async function foo() {  
   const result1 = await new Promise((resolve) => setTimeout(() =>   resolve('1')))  
   console.log(result1); //Output is 1  
}
```

Output of above functions is 1, pretty straight forward and self explanatory, Where await will block the main thread until the promise is resolved. Now let's check an interesting version of above code snippet.

###  **Can you guess the output of below snippet?**
```javascript
async function foo() {  
   const result1 = await new Promise((resolve) => setTimeout(() => resolve('1')))  
   return result1;  
}  
let output = foo();  
console.log('Output is' + JSON.stringify(output) );
```
For those of you who have guessed the output as 1, you're wrong. Copy the code and try running it on any online compilers, the output is {}.

###  **Why is it so?**

Because an async function always returns a promise and rather resolving the promise in above example we are trying to extract the value out of it.

###  **What's the solution?**
```javascript
async function foo() {  
   const result1 = await new Promise((resolve) => setTimeout(() =>    resolve('1')))  
   return result1;  
}  
let output = foo().then(data => {  
 console.log('Result is' + JSON.stringify(data))   
});
```
Since async function returns a promise in above code snippet we are resolving it with the help of **.then** method and extracting the value out of it.

###  **A better approach**

We use async and await because we want to avoid promise chain or .then expression, so rather using .then we can use async and await itself to resolve the promise, below snippet will represent that.
```javascript
async function foo() {  
   const result1 = await new Promise((resolve) => setTimeout(() => resolve('1')))  
   return result1;  
}async function test(){  
 let output = await foo();  
 console.log('Result is' + JSON.stringify(output)); // Output is 1   
}test()
```

---
#  7 Best Practices for MongoDB Query Optimization in Node.js down your app, increase server costs, and create bottlenecks.

###  1. Use Indexes Wisely for Faster Lookups

Indexes are the backbone of MongoDB performance. Without indexes, queries perform a **collection scan**, meaning MongoDB has to check every document — this is painfully slow for large datasets.

###  How to Create an Index

Use the `createIndex` method to speed up queries:
```javascript
const { MongoClient } = require("mongodb");  
  
async function createIndex() {  
  const client = new MongoClient("mongodb://localhost:27017");  
  await client.connect();  
  const db = client.db("ecommerce");  
  const products = db.collection("products");  
  
  // Create an index on the 'category' field  
  await products.createIndex({ category: 1 });  
  
  console.log("Index created!");  
  await client.close();  
}  
  
createIndex();
```
###  Best Practices for Indexing

-   **Always index fields used in** `**find()**`**,** `**sort()**`**, and** `**group()**` **queries.**
-   **Use compound indexes** when filtering by multiple fields. For example, if you frequently query by `category` and `price`, create an index on `{ category: 1, price: -1 }`.
-   **Avoid over-indexing.** While indexes speed up read queries, they also slow down write operations since every insert or update must update the index.

###  2. Optimize Query Patterns to Reduce Unnecessary Data Fetching

Fetching unnecessary data increases load time and resource consumption. Always **query for only the fields you need.**

###  Example of Selecting Specific Fields

Instead of fetching the entire document:
```javascript
const product = await products.findOne({ category: "electronics" });

Use **projection** to return only required fields:

const product = await products.findOne(  
  { category: "electronics" },  
  { projection: { name: 1, price: 1, _id: 0 } }  
);

// Result: { "name": "Laptop", "price": 1200 }
```
This approach **reduces data transfer**, leading to better performance.

###  3. Avoid Large `$in` Queries and Use `$or` for Better Performance

If you're filtering a collection with an `$in` query on a large dataset, MongoDB may struggle to optimize it. Instead, consider `$or` or **index-based filtering**.

###  Bad Query Using `$in`
```javascript
const users = await usersCollection.find({ country: { $in: ["US", "UK", "CA"] } }).toArray();
```
Instead, **optimize it with** `**$or**`:
```javascript
const users = await usersCollection.find({  
  $or: [{ country: "US" }, { country: "UK" }, { country: "CA" }],  
}).toArray();
```
MongoDB can better optimize individual indexed fields with `$or` queries compared to `$in`.

###  4. Use Pagination Instead of `skip()` for Large Datasets

When paginating, avoid using `.skip(n)`, as it forces MongoDB to iterate through `n` documents before returning results—this slows down performance.

###  The Better Approach: Pagination with `_id`

Instead of:
```javascript
const products = await productsCollection.find().skip(1000).limit(20).toArray();
```
Use **range-based pagination** with `_id`:
```javascript
const lastId = "660f1f2e5c2135c29d1c1234"; // Last `_id` from the previous page  
const products = await productsCollection  
  .find({ _id: { $gt: lastId } })  
  .limit(20)  
  .toArray();
```
This method is **faster and more efficient** because MongoDB can leverage indexes.

###  5. Use `lean()` Queries with Mongoose for Performance Boost

If you're using Mongoose, the `.lean()` method removes unnecessary document overhead, making queries faster.

**Without** `**.lean()**`**:**
```javascript
const users = await User.find({ isActive: true }); // Returns full Mongoose documents
```
With `.lean()`:
```javascript
const users = await User.find({ isActive: true }).lean(); // Returns plain JavaScript objects
```
This is **20–30% faster** for read-heavy operations.

###  6. Monitor Slow Queries Using `explain()`

MongoDB has a built-in way to analyze queries: `explain()`.

###  Example Usage
```javascript
const explainOutput = await productsCollection  
  .find({ category: "electronics" })  
  .explain("executionStats");  
  
console.log(JSON.stringify(explainOutput, null, 2));
```
Key metrics to watch:

-   `**nReturned**` – Number of documents returned.
-   `**totalDocsExamined**` – If this is high, your query needs an index.
-   `**executionTimeMillis**` – Total query execution time.

###  7. Enable Query Caching with Redis

For read-heavy applications, caching frequent queries **reduces database load** and **boosts performance**. Use Redis to cache query results.

###  Example: MongoDB with Redis
```javascript
const Redis = require("ioredis");  
const redis = new Redis();  
  
async function getProducts() {  
  const cacheKey = "products:electronics";  
  
  // Check Redis cache first  
  const cachedData = await redis.get(cacheKey);  
  if (cachedData) return JSON.parse(cachedData);  
  
  // Query MongoDB if not found in cache  
  const products = await productsCollection.find({ category: "electronics" }).toArray();  
  
  // Store result in Redis for 10 minutes  
  await redis.setex(cacheKey, 600, JSON.stringify(products));  
  
  return products;  
}
```
This **reduces database queries** and **speeds up responses** for frequently requested data.

###  Quick Recap of Best Practices:

→ **Use Indexes Wisely** — Avoid full collection scans.  
→ **Optimize Query Patterns** — Fetch only the necessary fields.  
→ **Use** `**$or**` **Instead of Large** `**$in**` **Queries** – More efficient filtering.  
→ **Paginate Efficiently** – Avoid `.skip()`, use `_id` for faster queries.  
→ **Use** `**.lean()**` **with Mongoose** – Get plain objects instead of full documents.  
→ **Monitor Slow Queries with** `**explain()**` – Identify bottlenecks.  

---