# NGRX in Angular (Interview). What is NgRx?

# What is NgRx?

### Flux design pattern

During the last decade, Facebook has popularized an approach in building single page Web Applications called the [Flux](https://facebook.github.io/flux/docs/in-depth-overview/). [Redux](https://redux.js.org/), a vastly popular state management library for React, is built using the Flux approach, and so is NgRx. They have similar (almost the same) concepts, and serve the same need. **NgRx can be called “Redux + RxJS”**. It combines the simplicity and centralization of Redux with the power of `Observables`.

### So what does Flux do?

Flux solves this problem with a series of easy to grasp concepts, which bundled together comprise a state management system. It sort of utilizes both previous approaches in a way that

-   Makes state easy to synchronize
-   Makes changes to the state easy to track
-   Allows to a actually debug state changes
-   Is declarative

NgRx does the same, but for Angular. If at this point you think “why do I event bother? My app works fine right now”, then let's now explore why exactly do we need solutions like NgRx.

# Why do we need NgRx?

NgRx, as mentioned, is built on concepts of Redux. It utilizes core ideas like `Stores` (the place where the application states are stored), `Actions` (events that notify the `Store` that some change to the state is to happen), `Reducers` (functions that determine how a certain `Action` affects the `State`), and also adds concepts like `Selectors` (functions that allow to pick a slice of the `State` as an `Observable`) and `Effects` (special functions that work on side effects like data loading and API calls). It also provides utility functions to make writing boilerplate code easier and even utility libraries like `@ngrx/entity` to work with large lists of data.

# NGRX Actions, Reducers

### What are Actions?

`Actions` are the most simple core concept of NgRx (and Redux in general). Action is a unique event that is used to trigger a change in the state. What does it mean? For example, we might have an action that says "Home page has been loaded". It might mean some changes in the state. For example, in our application, it might trigger an API call for lists of expenses and incomes, which will in turn trigger an event that puts that data in the `Store`, resulting in a change in the UI. Or we might have an action that says "Add a category", which will create a new category of income/expense in the `Store`, again resulting in a UI change. Again, essentially `Actions` are like commands to the `Store`, or methods that allow to update its contents.
```typescript
// state/actions.ts  

import { createAction, props } from "@ngrx/store";  
import { Category } from "./state";  
  
export const addCategory = createAction(  
  "[Category List] Add Category",  
  props<{ category: Category }>()  
);  
```
```typescript
// app.component.ts  
--------------------------------------------------------  
import { Component, OnInit } from "@angular/core";  
import { addCategory } from "./state/actions";  
  
@Component({/* ... */})  
export class AppComponent implements OnInit {  
  ngOnInit() {  
    console.log(addCategory({category:{ name: "Food" }}));  
  }  
}
```

### What are Reducers?

Reducers are _pure functions_ that receive two arguments, the current `State` of the application, an `Action` object, calculate the new state based on the `Action` that happened, and return that new `State`. Usually calculating involves determining which `Action` happened (sometimes via `switch-case` statements, but NgRx provides utilities that reduce boilerplate), copying the previous state into a new object while modifying the relevant properties of the `State`, and returning the new `State` object. Every time an `Action` is dispatched (we will learn more about dispatching in the next chapters, for now "dispatching" an `Action` means the `Action` has happened), NgRx will call the `Reducer` function, providing the old `State` and the `Action` object as arguments, get the returned new `State` and immediately notify all of our components about the change (how neat is that!). Essentially, `Reducers` are the central place where `State` changes happen.
```typescript
import { Action } from "@ngrx/store";  
  
import { AppState } from "./state";  
  
export function reducer(state: AppState, action: Action) {  
  switch (action.type) {  
    case "[Category List] Add Category":  
      return { ...state, categories: [...state.categories, action.payload] };  
    default:  
      return state;  
  }  
}
```

### What are Selectors?

In most simple terms, `Selectors` are `pure functions` that take the `State` of ur application, and return a piece of it so that it can be used in a component (you will see NgRx extensively uses `pure functions`). In more detail, in the future chapters, our `State` will evolve to contain lots of data in the main object, for example, we will have categories, expenses, incomes, probably data about the current user (authentication, full name, etc) and so on. Obviously in a single component we don't need the entire `State`, thus we write `Selectors` which will return pieces of that `State`, for example, a `Selector` that return only the array of categories to use in the corresponding component.

Those pieces are called “slices” of the `State` sometimes, but often the term `derived State` is used, to indicate it is some modified form of the original `State`. `Selectors` can also be used to return not just a slice, but some complex calculation of the `State`, for example, we can write a `Selector` that calculates the total income based on all the items in the `incomes` array, and based on that `Selector`, another one that calculates the average.

This chapter is called “Basic Selectors”, so in this one we are going to write only such `Selectors` that return just slices of the `State`; in the future chapters, we will write more complex `Selectors` and learn how to create new `Selectors` from existing ones, and also how to combine them into new ones.
```typescript
// src/app/state/selectors.ts  
import { AppState } from "./state";  
  
export const categories = (state: { categories: AppState }) =>  
  state.categories.categories;  
```  

```typescript
// category-list-container.component.ts    
import { Component } from "@angular/core";  
import { Store } from "@ngrx/store";  
  
import { categories } from "../../state/selectors";  
  
@Component({  
  selector: "app-category-list-presenter",  
  template: `  
    <app-category-list-presenter [categories]="categories$ | async">  
    </app-category-list-presenter>  
  `,  
})  
export class CategoryListContainer {  
  categories$ = this.store.select(categories);  
  
  constructor(private readonly store: Store) {}  
}
```

# NPM Packages

dependencies  
===================================================================  
```typescript
"@ngrx/effects": "^15.4.0",  
"@ngrx/entity": "^15.4.0",  
"@ngrx/store": "^15.4.0",  
"ngrx/store-devtools": "*",
```

# StoreModule.forRoot() vs StoreModule.forFeature() with EffectModule

**forRoot :::** The **forRoot** method is invoked in the AppModule and, generally, **once in the application** to initialize the Store and provide the initial reducers/actions/state configuration. If you use the EffectsModule, you'll invoke the forRoot method on this module too:
```typescript
@ngModule({   
  imports: [   
    StoreModule.forRoot({}),   
    EffectsModule.forRoot([])   
  ]   
})  
  
class AppModule {}
```
**forFeature :::** The **forFeature** method is invoked in any feature module that requires it's own part of the state management: as an example, an UserModule will define it's own portion of the state, describing the required actions, reducers and so on. If you use the EffectsModule, remember to invoke the forFeature method against it too. As you may have understood by yourself, _forFeature_ (as the more generic Angular's _forChild_ method) can be invoked multiple times for the same imported module in the application:
```typescript
// AppModule    
@ngModule({   
  imports: [   
    StoreModule.forRoot({}),   
    EffectsModule.forRoot([])   
  ]   
})  
```
```typescript
// UsersModule    
@ngModule({   
  imports: [   
    StoreModule.forFeature('usersFeature', UserReducers),  
    StoreModule.forFeature('logsFeature', LogsReducer),   
    EffectsModule.forFeature([UserEffects, LoginEffects, LogsEffects])  
  ]   
})
```

As you have noticed, instead of `forRoot` we used methods called `forFeature`, which indicate these are reducers and effects that are being added dynamically, after the user visits this particular module. The `StoreModule.forFeature` method's first argument is the name of the feature state, which is being used when writing feature specific selectors.

# EffectsModule

EffectsModule. forRoot is required to wire up application level providers and must be registered only once before EffectsModule. forFeature is used. You can provide forRoot with an empty array if you don't need to register any effects in the root.

`EffectsModule.forFeature()` is basically the same function as `EffectsModule.forRoot()` except the fact that the providers aren't loaded.

# forRoot vs forFeature

below every number represents a module

        0                                                                                                  
    1       2                                                                                              
  3   4   5   6

if I do `forRoot(databaseConfig)` on module `1` then `1, 3, 4` can use databaseConfig  
if I do `forFeature(databaseConfig)` on module `1` then only `1` can use the databaseConfig  
if I do `forRoot(databaseConfig)` on module `0` then all can use the databaseConfig
---

# Angular Function vs DI-Based Interceptors: Which Approach Fits Your Application? 

Angular provides a powerful way to handle HTTP requests and responses through interceptors, which can be implemented using either function-based or dependency injection (DI)-based approaches. In this blog, let's explore both options, examine their differences, and help you decide which one is best for your Angular application.

### What Are Angular Interceptors?

Angular interceptors are a type of middleware that allows you to modify or handle HTTP requests or responses. You can use them to add authentication headers, log responses, handle errors globally, or modify requests before they hit your backend server. Interceptors are registered in the Angular dependency injection (DI) system, making them reusable and configurable across your application.

### Function-Based Interceptors

Function-based interceptors are a lightweight approach where the core logic of interception is encapsulated within a function. This function typically takes in the `HttpRequest` and `HttpHandler` objects, performs necessary transformations or processing, and returns an updated or original request. This approach is often used for simpler use cases and has the following characteristics:

-   **Simplicity**: Function-based interceptors are concise and less verbose. You do not need to deal with creating classes or injecting dependencies, which can make this a great option for smaller, one-off use cases.
-   **Less Overhead**: Since function-based interceptors do not involve Angular DI, there is less overhead involved. This can result in slight performance gains, though the difference may not be noticeable in many real-world applications.
-   **Drawbacks**: Lack of flexibility is one major drawback here. Function-based interceptors do not benefit from dependency injection, which means you cannot easily inject services or reuse logic that might require access to shared services.

### Dependency Injection (DI)-Based Interceptors

DI-based interceptors use Angular's DI framework to provide services within your interceptor class. This is the more common approach used in Angular applications as it provides greater flexibility and allows the interceptor to leverage other services:

-   **Scalability**: DI-based interceptors are better suited for larger, more complex applications where reusability is important. Since they are registered as providers, DI-based interceptors are ideal when you need to apply cross-cutting logic, such as user authentication or logging, throughout your application.
-   **Service Injection**: Since DI-based interceptors are classes, they can inject services such as `AuthService`, `LoggingService`, or even custom utility classes. This capability makes it possible to add rich, dynamic behaviors to your HTTP pipeline.
-   **Drawbacks**: Compared to function-based interceptors, DI-based interceptors introduce more boilerplate code. You must create an interceptor class and register it as a provider within your module, which can be overkill for simpler scenarios.

### Which One to Choose?

-   **For Simple Use Cases**: If you have a small application or need to perform a specific transformation without needing shared services, a function-based interceptor is the simplest and most effective approach.
-   **For Complex Requirements**: For larger applications where interceptors need to share services, or for scenarios where logic is complex (e.g., adding an authentication token based on some logic), DI-based interceptors are the way to go.

Function-based interceptors are a good fit if you need something quick and don't want to add complexity. However, DI-based interceptors give you all the power of Angular's DI system, making them far more versatile and suitable for sophisticated applications.

### Example: Creating Function vs DI-Based Interceptor

1.  **Function-Based Interceptor**
```javascript
import { HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';  
import { Observable } from 'rxjs';  
  
export function simpleInterceptor(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {  
  const modifiedReq = req.clone({  
    setHeaders: { 'Custom-Header': 'MyHeaderValue' }  
  });  
  return next.handle(modifiedReq);  
}
```
**2. DI-Based Interceptor**
```javascript
import { Injectable } from '@angular/core';  
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';  
import { Observable } from 'rxjs';  
  
@Injectable()  
export class CustomInterceptor implements HttpInterceptor {  
  constructor(private authService: AuthService) {}  
  
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {  
    const token = this.authService.getToken();  
    const modifiedReq = req.clone({  
      setHeaders: { Authorization: `Bearer ${token}` }  
    });  
    return next.handle(modifiedReq);  
  }  
}
```
### Conclusion

Choosing between function-based and DI-based interceptors depends on your application's complexity and the level of flexibility you need. Function-based interceptors are simple, with less boilerplate, making them great for straightforward needs. DI-based interceptors are more robust and fit well when scaling your application with reusable, service-oriented logic.

By understanding the strengths and weaknesses of each approach, you can make an informed decision about which fits best for your Angular app's requirements.

---
# Exploring Angular's Newly Introduced HttpClient with fetch(): A Guide with Examples 

Angular continually evolves, offering developers improved tools and methodologies for building modern web applications. The recent integration of the `fetch()` API into Angular's `HttpClient` provides a cleaner, more streamlined approach for making HTTP requests. In this blog, we'll delve into this new feature, its benefits, and how to use it effectively with an example.

### What Is `fetch()` in Angular's `HttpClient`?

The `fetch()` API is a modern JavaScript function used for making HTTP requests. With its integration into Angular's `HttpClient`, developers can now leverage its simplicity and native capabilities while maintaining Angular's ecosystem advantages, such as dependency injection, interceptors, and testing utilities.

### Why Use `fetch()` with Angular's `HttpClient`?

1.  **Simplified API**: `fetch()` offers a cleaner, promise-based interface compared to traditional `XMLHttpRequest`.
2.  **Native Browser Support**: It's a modern web standard supported across all major browsers.
3.  **Seamless Integration**: Angular enhances `fetch()` by incorporating its interceptors, making it a powerful tool for managing headers, logging, or modifying requests/responses.

### Using `fetch()` with Angular's `HttpClient`

###### 1. Setting Up Angular Environment

Ensure you have Angular 15 or newer installed, as this version introduces the `fetch()` integration in `HttpClient`.

2. Updating `app.config.ts` to Use `fetch()`

The Angular framework requires that you explicitly enable the `fetch()` API in the application configuration. This ensures that `fetch()` is used as the default mechanism for HTTP requests.

### Steps to Enable `fetch()` in `app.config.ts`

### 1. Locate or Create `app.config.ts`

If you don't already have an `app.config.ts` file in your project, create it in the `src/app/` directory.

### 2. Enable Fetch API in Providers

Add the following code to configure Angular to use `fetch()`:
```javascript
import { ApplicationConfig, provideHttpClient, withFetch } from '@angular/core';  
  
export const appConfig: ApplicationConfig = {  
  providers: [  
    provideHttpClient(withFetch())  
  ]  
};
```
-   `provideHttpClient(withFetch())`: Configures the `HttpClient` to use `fetch()` for all HTTP requests.
-   `withFetch()`: Explicitly sets `fetch()` as the default mechanism for making HTTP requests.

### Updating `main.ts` to Use the Configuration

After setting up the `app.config.ts`, ensure that your `main.ts` file imports and uses this configuration.
```javascript
import { bootstrapApplication } from '@angular/platform-browser';  
import { AppComponent } from './app/app.component';  
import { appConfig } from './app/app.config';  
  
bootstrapApplication(AppComponent, appConfig)  
  .catch(err => console.error(err));
```
### Benefits of Using `fetch()` via `app.config.ts`

1.  **Simplified Setup**: By enabling `fetch()` globally, you don't need to configure it repeatedly in every service.
2.  **Interceptors Compatibility**: Integrating `fetch()` with Angular's `HttpClient` allows you to utilize interceptors seamlessly for logging, headers, or authentication.
3.  **Cleaner Code**: Keeps the application configuration consistent and clean.

**Service Implementation**

Create a service to handle HTTP operations using `fetch()`.
```javascript
import { Injectable } from '@angular/core';  
import { HttpClient } from '@angular/common/http';  
  
@Injectable({  
  providedIn: 'root',  
})  
export class DataService {  
  private apiUrl = 'https://jsonplaceholder.typicode.com/posts';  
  
  constructor(private http: HttpClient) {}  
  
  fetchData() {  
    return this.http.fetch(this.apiUrl, { method: 'GET' }).then(response => {  
      if (!response.ok) {  
        throw new Error('Network response was not ok');  
      }  
      return response.json();  
    });  
  }  
}
```
### 1. Generate Component

Generate a component to display fetched data.
```shell
ng generate component fetch-example
```
2. **Component Code**
```javascript
import { Component, OnInit } from '@angular/core';  
import { DataService } from './data.service';  
  
@Component({  
  selector: 'app-fetch-example',  
  template: `  
    <div>  
      <h1>Fetched Posts</h1>  
      <ul>  
        <li *ngFor="let post of posts">{{ post.title }}</li>  
      </ul>  
    </div>  
  `,  
})  
export class FetchExampleComponent implements OnInit {  
  posts: any[] = [];  
  
  constructor(private dataService: DataService) {}  
  
  ngOnInit() {  
    this.dataService  
      .fetchData()  
      .then(data => (this.posts = data))  
      .catch(error => console.error('Error fetching data:', error));  
  }  
}
```

### Conclusion

The integration of the `fetch()` API into Angular's `HttpClient` offers a powerful, streamlined way to manage HTTP requests while maintaining Angular's feature-rich ecosystem. Whether you're building a small application or a complex enterprise-grade system, this new feature simplifies HTTP operations while providing robust support for modern web standards.

---

# How to Use HttpClient in Angular. Mastering HTTP Requests in Angular

Angular's `HttpClient` is a powerful tool that makes it easy to perform HTTP requests. Whether you are fetching data from a backend server, sending POST requests, or handling errors, `HttpClient` provides a clean API to interact with RESTful services. In this blog, we will guide you on how to use `HttpClient` in your Angular applications to create seamless interactions with APIs.

### Setting Up HttpClient in Angular

To use `HttpClient`, you first need to import the necessary module into your Angular application. Here's how to get started:

1.  **Import** `**HttpClientModule**`
2.  To use `HttpClient`, add the `HttpClientModule` to your Angular application. You need to import it in your app module (`app.module.ts`):

```javascript
import { HttpClientModule } from '@angular/common/http';  
  
@NgModule({  
  declarations: [  
    // Your components here  
  ],  
  imports: [  
    BrowserModule,  
    HttpClientModule, // Add this line  
  ],  
  providers: [],  
  bootstrap: [AppComponent]  
})  
export class AppModule { }
```
By importing `HttpClientModule`, you make `HttpClient` available across your application.

**2. Injecting HttpClient**

Once `HttpClientModule` is imported, you can inject `HttpClient` into a service or component. Here is an example of how you can use it:
```javascript
import { HttpClient } from '@angular/common/http';  
import { Injectable } from '@angular/core';  
import { Observable } from 'rxjs';  
  
@Injectable({  
  providedIn: 'root'  
})  
export class DataService {  
  private apiUrl = 'https://api.example.com/data';  
  
  constructor(private http: HttpClient) { }  
  
  getData(): Observable<any> {  
    return this.http.get<any>(this.apiUrl);  
  }  
}
```
In the above example, `HttpClient` is injected into the `DataService` class, and a simple GET request is made to the API endpoint.

### Making GET, POST, PUT, and DELETE Requests

`HttpClient` allows you to make various types of requests to interact with your backend. Let's explore how you can use `HttpClient` to perform different HTTP methods:

1.  **GET Request**

A GET request is used to fetch data from the server:
```typescript
getData(): Observable<any> {  
  return this.http.get<any>('https://api.example.com/data');  
}
```

**2. POST Request**

A POST request is used to send data to the server, such as adding a new item:
```typescript
addData(data: any): Observable<any> {  
  return this.http.post<any>('https://api.example.com/data', data);  
}
```

### Handling Errors with HttpClient

HTTP requests might fail for various reasons, such as network issues or incorrect endpoints. To handle errors effectively, you can use RxJS operators like `catchError` to intercept and handle errors gracefully:
```typescript
import { catchError } from 'rxjs/operators';  
import { throwError } from 'rxjs';  
  
getData(): Observable<any> {  
  return this.http.get<any>(this.apiUrl).pipe(  
    catchError(error => {  
      console.error('Error occurred:', error);  
      return throwError(() => new Error('Something went wrong; please try again later.'));  
    })  
  );  
}
```
In this example, `catchError` is used to catch any error that occurs during the HTTP request and log it or return an alternative response.

### Using HttpParams for Query Parameters

Sometimes, you need to pass query parameters along with your HTTP requests. `HttpClient` provides a way to add query parameters using `HttpParams`:
```javascript
import { HttpParams } from '@angular/common/http';  
  
getFilteredData(filter: string): Observable<any> {  
  const params = new HttpParams().set('filter', filter);  
  return this.http.get<any>(this.apiUrl, { params });  
}
```

In this example, `HttpParams` is used to set the `filter` query parameter for the GET request.

### Conclusion

Angular's `HttpClient` is a robust tool that allows you to communicate effortlessly with your backend services. By understanding how to make GET, POST, PUT, and DELETE requests, handle errors, and use query parameters, you can make your Angular applications more dynamic and responsive.

Whether you're building a small app or a large-scale application, mastering `HttpClient` will make data handling and communication with APIs much easier, ensuring that your applications are always in sync with your backend services.

---
# Angular: Http: File Upload in Angular with Progress Tracking
## Understanding HTTP Client Event Stream

Angular's HTTP client allows developers to track the progress of file uploads by using the event stream functionality. Here's a breakdown of the key events:

1.  **Request Sent**: Signals that the file upload request has been dispatched.
2.  **Upload Progress**: Reports the percentage of data uploaded to the server.
3.  **Response Header Received**: Indicates the server's acknowledgment of the request.
4.  **Download Progress**: Tracks the server's response download progress.
5.  **Response Received**: Confirms that the response body is fully downloaded and available.

To utilize these events, developers must enable the `reportProgress` option in the HTTP request.

## Setting Up the Angular Application

To implement file upload, follow these steps:

### 1. Create a Standalone Component

Angular 19 introduced standalone components, which simplify modularization. Create a `FileLoaderComponent` as shown below:
```javascript
@Component({  
  standalone: true,  
  selector: 'app-file-loader',  
  templateUrl: './file-loader.component.html',  
})  
export class FileLoaderComponent {  
  selectedFile: File | null = null;  
  
  onFileSelected(event: Event): void {  
    const input = event.target as HTMLInputElement;  
    if (input.files?.length) {  
      this.selectedFile = input.files[0];  
    }  
  }  
}
```
### 2. Design the HTML Template

The HTML for the component includes an upload form:
```html
<form [formGroup]="formGroup" (ngSubmit)="onSubmit()">  
  <div>  
    <label for="file">Upload File:</label>  
    <input type="file" id="file" (change)="onFileSelected($event)" />  
  </div>  
  <button type="submit">Submit</button>  
</form>
```
### Tracking Progress

Progress tracking is achieved by observing events during the HTTP request lifecycle. Use the `observe` option set to `'events'` to access the event stream:
```javascript
this.httpClient.post('upload-url', formData, {  
  reportProgress: true,  
  observe: 'events'  
}).subscribe(event => {  
  if (event.type === HttpEventType.UploadProgress) {  
    const progress = Math.round((100 * event.loaded) / event.total!);  
    console.log(`Progress: ${progress}%`);  
  } else if (event.type === HttpEventType.Response) {  
    console.log('Upload Complete!', event.body);  
  }  
});
```

### Benefits of Angular Standalone Components

Standalone components reduce boilerplate code and make the application more modular. By default, components in Angular 19 are standalone unless explicitly configured otherwise.

### Challenges and Best Practices

1.  **Large Files**: Ensure efficient memory usage for larger files by handling progress updates selectively.
2.  **User Feedback**: Display a progress bar to keep users informed during uploads.
3.  **Error Handling**: Handle cases like network interruptions gracefully.

### Conclusion

Angular's HTTP client and standalone component features simplify the implementation of file uploads with real-time progress tracking. By leveraging these tools, developers can create user-friendly and efficient web applications.

---

### 21. What is the wild card route?

One of the common use wild card route redirects to this route if someone types something which is not the proper path.

To handle this error, and instead of notifying the user, we can use **WILDCARD** routes.

**Example**:

![](https://miro.medium.com/v2/resize:fit:604/1*fxCE1xQ5qrMyQ0g-0C4Fjw.png)

**_Let's check out practical code to understand this concept better._**

[https://stackblitz.com/edit/angular-feature-modules-final-and-wildcard-route-example](https://stackblitz.com/edit/angular-feature-modules-final-and-wildcard-route-example)

### 22. What is the difference between ngIf and hidden?

Isn't it both same? both have the same function of hiding the things.No, but if you check that ngIf won't load template if conditions get false while hidden will load the template and hide it.

**ngIf** will not load the HTML data written inside if the condition is not satisfied.

**hidden** will load the data and using **display: none** property doesn't show in the HTML

Which one is better?

If you are thinking about performance, ngIf is better as it will not load the HTML itself but if the condition is satisfied it will render DOM again.

### 23. What is a router outlet?

We do see this tag in the main app component HTML. But what is it? Let's understand this term.

this directive is available from the `@angular/router` package and used to mark where the component is inserted.

it is the main tag of the angular application as it will act as a shell of our application. whatever we add in the shell will be rendered in views, only the part marked by the router outlet will be changed.

For example: If you use the header in the application it will be steady and other things will change based on the components.

![](https://miro.medium.com/v2/resize:fit:363/1*oIBMmCnNHEhyBQqTDrYdGw.png)

### 24. What is the Router state?

In simple terms, the router state maintains the state of the routes and we can check all the states by subscribing to specific router events.

_For example:_

If we navigate from “/inbox/33/messages/44” to “/inbox/33/messages/45”, the data observable will emit a new set of data with the new message object, and the component will display Message 45.

**_Let's check out practical code to understand this concept better._**

[https://stackblitz.com/edit/angular-routerlink-state](https://stackblitz.com/edit/angular-routerlink-state)

### 25. What is an Active route?

**ActivatedRoute gives access to the URL, params, data, queryParams, and fragment observables.**

Given the following:

And navigating first to “/inbox/33/data/44” and then to “/inbox/33/data/45”, we will see:

url [{path: 'data', params: {}}, {path: '44', params: {}}]  
url [{path: 'data', params: {}}, {path: '45', params: {}}]

### 26. Explain different injections in angular.

One of the common interview questions asked in angular interview questions is how you are using injections in Angular application?

There are 5 different ways we angular provide dependency injections

1.  **use class**
2.  **use value**
3.  **use factory**
4.  **token factory**
5.  **component injections**

### What can you provide with Dependency Injection in Angular?

### 27. What is the best way to implement translations in angular?

In the Single Page Application, One of the main features is multi-language support on the fly. But Sometimes the interviewer asks have you implemented translations in your application?

The most common library used for this is ngx-translate which provides a translation by adding in the JSON.

**_Let's check out practical code to understand this concept better._**

[https://stackblitz.com/edit/ngx-translate-example](https://stackblitz.com/edit/ngx-translate-example)

### 28. Explain different routing params in Angular.

We do use routing parameters to maintain the data or sometimes pass data when navigating from one route to another route.

Angular does support the following routing parameters.

1.  Required Parameters
2.  Optional Parameters
3.  Query Parameters
4.  NavigationExtras

### 29. What is a virtual scroll in Angular?

Here Interviewer wants to check if you have updated knowledge of the latest angular features.

The main concept behind virtual scrolling is rendering only visible items.

For example, if there are thousands of alerts in an application, an efficient way would be to load only the elements that are visible and unload them when they are not by replacing them with new ones.

An initial implementation of virtual scrolling is now available in @angular/cdk. (v7.0.0-beta.0)

**_Let's check out practical code to understand this concept better._**

[https://stackblitz.com/edit/angular-virtual-scrolling](https://stackblitz.com/edit/angular-virtual-scrolling)

### 30. What is the difference between route param vs query param?

The main difference between query and route param is route param is mandatory to determine the route while query param is optional.

Let's understand some of the basics of Routing in Angular.

### Declaring Route Parameters

```typescript
export const routes: Routes = [{ path: '', redirectTo: 'data', pathMatch: 'full' },
{ path: 'data', component: DataList },
{ path: 'data/:id', component: DataDetails }];
```
`Example of URL: localhost:3000/data/5`

### Passing Query Parameters
```html
<a [routerLink]="['data']" [queryParams]="{ page: 99 }">Go to Page 99</a>
```
Alternatively, we can navigate programmatically using the `Router` service:
```typescript
goToPage(pageNum) {t
    his.router.navigate(['/data'], { queryParams: { page: pageNum } });
}
```

# Cache It Right: Top Frontend Interview Questions on HTTP Caching — Part 1 


## **Basic concepts of caching**

Caching is the process of storing frequently used data or resources in a temporary storage location, such as memory or disk, to accelerate their retrieval in the future. Caching in web applications can involve various types of data or resources, such as HTML pages, CSS stylesheets, JavaScript files, images, and API responses.

## **Benefits of caching in web applications**

By serving cached data instead of fetching or computing the same data repeatedly from the original source, caching can significantly reduce the response time and improve the overall performance of web applications. This results in:

-   **Improved Performance, faster page load times lead to a better user experience**
-   **Reduced Server Load, lower bandwidth usage, cost savings & enhanced scalability**

## Common http response status code for cached resources

1.  **200 OK**

With an empty cache, or without a cache, the requested resource is sent back with a status of `[200](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/200)` `OK`

**2. 200 OK (from memory cache)**

![](https://miro.medium.com/v2/resize:fit:718/1*XvsUKzTF1dRT-VwRafYgEw.png)

The requested resource has already been cached into memory and is still fresh, thus it is returned from memory. Usually when you close the browser and reopen the same page, you won't see this again.

**3. 200 OK (from disk cache)**

![](https://miro.medium.com/v2/resize:fit:875/1*BXCZSndiVWEaZe0Pnf464g.png)

The requested resource has already been cached into disk at some point and is still fresh, thus it is returned from disk. Usually when you close the browser and reopen the same page, you will see this again.

**4. 304 Not Modified**

> The HTTP `304 Not Modified` client redirection response code indicates that there is no need to retransmit the requested resources. It is an **implicit redirection to a cached resource**. This happens:
> 
> 1. When the request method is a [safe](https://developer.mozilla.org/en-US/docs/Glossary/Safe/HTTP) method, such as `[GET](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/GET)` or `[HEAD](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/HEAD)` **OR**
> 
> 2. When the request is [conditional](https://developer.mozilla.org/en-US/docs/Web/HTTP/Conditional_requests) and uses an `[If-None-Match](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/If-None-Match)` or an `[If-Modified-Since](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/If-Modified-Since)` header.

## Some commonly asked http headers for caching

1.  [**Expires**](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Expires)

The `Expires` HTTP header contains the date/time after which the response is considered expired.

Invalid expiration dates with value 0 represent a date in the past and mean that the resource is already expired.

> Note: If there is a `[Cache-Control](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Cache-Control)` header with the `max-age` or `s-maxage` directive in the response, the `Expires` header is ignored.

`[_Cache-Control_](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Cache-Control)` is a http1.1 header，`Expires` is a http1.0 header

**2. Cache Control Headers**

The `**Cache-Control**` general-header field is used to specify directives for caching mechanisms in both requests and responses. Caching directives are _unidirectional_. Below are the most commonly asked directives. The full list can be found [here](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Cache-Control).

-   **no-store**

`no-store` means that any caches of any kind (private or shared) should not store this response.

-   **no-cache**

`no-cache` doesn't mean “don't cache”, it means it must revalidate with the server before using the cached resource.

-   **max-age=<seconds>**

`max-age` Specifies the maximum amount of time a resource will be considered fresh. This directive is relative to the time of the request whereas `Expires`, specifies the expiration in GMT.

-   **must-revalidate**

`must-revalidate` doesn't mean "must revalidate", it means the local resource can be used if it's younger than the provided `max-age`, otherwise it must revalidate.

3. **Pragma**

The `**Pragma**` HTTP/1.0 general header is used for backwards compatibility with HTTP/1.0 caches where the `Cache-Control` HTTP/1.1 header is not yet present. It includes only one directive `no-cache`.

## Two pairs: Last-Modified/If-Modified-Since & Etag/If-None-Match

Last-Modified/If-Modified-Since and Etag/If-None-Match are two pairs. You will usually see one pair or the other.

1.  **Last-Modifed/If-Modified-Since**

[**Last-Modified**](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Last-Modified)

The `Last-Modified` response HTTP header contains a date and time when the origin server believes the resource was last modified. It is used as a validator to determine if the resource is the same as the previously stored one. Less accurate than an `[ETag](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/ETag)` header, it is a fallback mechanism. Conditional requests containing `[If-Modified-Since](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/If-Modified-Since)` or `[If-Unmodified-Since](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/If-Unmodified-Since)` headers make use of this field.

It is used like this:

Last-Modified: <day-name>, <day> <month> <year> <hour>:<minute>:<second> GMT

Last-Modified: Wed, 21 Oct 2015 07:28:00 GMT

[**If-Modified-Since**](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/If-Modified-Since)

The `If-Modified-Since` request HTTP header makes the request conditional: the server sends back the requested resource, with a `[200](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/200)` status, only if it has been last modified after the given date. If the resource has not been modified since, the response is a `[304](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/304)` without any body; the `[Last-Modified](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Last-Modified)` response header of a previous request contains the date of last modification. Unlike `[If-Unmodified-Since](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/If-Unmodified-Since)`, `If-Modified-Since` can only be used with a `[GET](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/GET)` or `[HEAD](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/HEAD)`.

It is used like this:

If-Modified-Since: <day-name>, <day> <month> <year> <hour>:<minute>:<second> GMT

If-Modified-Since: Wed, 21 Oct 2015 07:28:00 GMT

**2. Etag/If-None-Match**

[**Etag**](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/ETag)

The `ETag` (or entity tag) HTTP1.1 response header is an identifier for a specific version of a resource. It lets caches be more efficient and save bandwidth, as a web server does not need to resend a full response if the content was not changed. Additionally, etags help to prevent simultaneous updates of a resource from overwriting each other (["mid-air collisions"](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/ETag#avoiding_mid-air_collisions)).

If the resource at a given URL changes, a new `Etag` value _must_ be generated. A comparison of them can determine whether two representations of a resource are the same.

It is used like this:

ETag: W/"<etag_value>"  
ETag: "<etag_value>"

ETag: "33a64df551425fcc55e4d42a148795d9f25f89d4"

**If-None-Match**

The `If-None-Match` HTTP request header makes the request conditional. For `[GET](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/GET)` and `[HEAD](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/HEAD)` methods, the server will return the requested resource, with a `[200](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/200)` status, only if it doesn't have an `[ETag](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/ETag)` matching the given ones. For other methods, the request will be processed only if the eventually existing resource's `[ETag](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/ETag)` doesn't match any of the values listed.

When the condition fails for `[GET](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/GET)` and `[HEAD](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/HEAD)` methods, then the server must return HTTP status code 304 (Not Modified). For methods that apply server-side changes, the status code 412 (Precondition Failed) is used. Note that the server generating a 304 response MUST generate any of the following header fields that would have been sent in a 200 (OK) response to the same request: Cache-Control, Content-Location, Date, ETag, Expires, and Vary.

The comparison with the stored `[ETag](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/ETag)` uses the _weak comparison algorithm_, meaning two files are considered identical if the content is equivalent — they don't have to be identical byte by byte. For example, two pages that differ by their creation date in the footer would still be considered identical.

> NOTE: Last-Modifed/If-Modified-Since track down to seconds，Etag could be more accurate than seconds.

## When both ETag & Last-Modified, which one should be used?

According to [RFC2616](https://www.ietf.org/rfc/rfc2616.html#section-13.3.4), An HTTP 1.1 Client MUST use the ETag in any cache-conditional requests, and if both an ETag and Last Modified are present, it SHOULD use both. The ETag header is considered a strong validator (see section 13.3.3), unless explicitly declared weak by the server, whereas the Last Modified header is considered weak unless at least a minute difference exists between it and the Date header. Note, however that the Server is not required to send either (but it SHOULD, if it can).

Note that the Client does not check the headers to see if they have changed; it just blindly uses them in the next conditional request; it is up to the Server to evaluate whether to send the requested content or a 304 Not Modified response. If the Server only sends one, then the Client will use that one alone (although, only strong validators are useful for a Range request). Of course, it is also at the discretion of intermediate caches (unless they have been prevented from caching via Cache Control directives) and the Server as to how they will act upon the headers; the RFC states that they MUST NOT return a 304 Not Modified if the validators are inconsisent, but since the header values are generated by the server, it has quite a bit of leeway.

### Cache It Right: Top Frontend Interview Questions on HTTP Caching — Part 2

In today's article, we will showcase some **common cache settings** you need to be aware of for different resource types & scenarios.

### Default: Heuristic caching

Heuristic caching is a workaround that came before `Cache-Control` support became widely adopted, and basically all responses should explicitly specify a `Cache-Control` header.

Date: Wed, 23 Feb 2023 00:00:00 GMT  
Last-Modified: Wed, 23 Feb 2023 00:00:00 GMT

In this example, even if no `Cache-Control` is given, responses will get stored and reused if certain conditions are met. This is called heuristic caching([since HTTP is designed to cache as much as possible](https://developer.mozilla.org/en-US/docs/web/http/caching###heuristic_caching)).

> The client stores this response (despite the lack of `max-age`) and reuses it for a while.

### Use case: long-lived caching for versioned URLs

Cache-Control: max-age=31536000

**This setting is also good for immutable resources. (like your versioned JavaScript, CSS, Images).**

In modern web development, JavaScript and CSS resources are frequently updated as development progresses. Also, if the versions of JavaScript and CSS resources that a client uses are out of sync, the display will break.

Therefore, you can serve the JavaScript and CSS with URLs that include a changing part based on a version number or hash value.

When responding to requests for URLs that contain versioning information, if the content is never meant to change, add `Cache-Control: max-age=31536000` to your responses.

### version in filename  
bundle-v111.js  
### version in query param  
bundle.js?v=111  
### hash in filename  
bundle-md5hashvalue.js  
### hash in query  
bundle.js?v=md5hashvalue

Setting this value tells the browser that whenever it needs to load the same URL anytime over the next one year (31,536,000 seconds), it can immediately use the value in the HTTP Cache, without having to make a network request to your web server at all.

For example, at AWS, when you make changes to the frontend codebase, it usually involves deploying a new versioned JavaScript bundle. You can see the cache-control header in the below screenshot.

![](https://miro.medium.com/v2/resize:fit:675/1*-MJixW7ewQo76Y6tpq_E2w.png)
Cache-control setting for versioned JavaScript bundle

Build tools like webpack can [automate the process](https://webpack.js.org/guides/caching/###output-filenames) of assigning hash fingerprints to your asset URLs.

You can also add the `[immutable](https://developer.mozilla.org/docs/Web/HTTP/Headers/Cache-Control###Revalidation_and_reloading)` [property](https://developer.mozilla.org/docs/Web/HTTP/Headers/Cache-Control###Revalidation_and_reloading) to your `Cache-Control` header as a further optimization, though it [will be ignored](https://www.keycdn.com/blog/cache-control-immutable###browser-support) in some browsers.

### Use case: when you don't want to share resource with others

If the response contains personalized content, and you don't want the content to be unexpectedly visible to others, add the **private** directive to Cache-Control header.

Cache-Control: private

In this, case, using the `private` directive will cause the personalized response to only be stored with the specific client and not be leaked to any other user of the cache.

### Use case: when you want to provide up-to-date content every time

You may be tempted to use the `no-store` directive. The `no-store` directive prevents a response from being stored but does not delete any already-stored response for the same URL.

If there is an old response already stored for a particular URL, returning `no-store` will not prevent the old response from being reused.

However, a `no-cache` directive will force the client to send a validation request before reusing any stored response.

Cache-Control: no-cache, no-store

![](https://miro.medium.com/v2/resize:fit:684/1*BUeRnYRKHx640eN-KEKRnA.png)
Cache-control setting for AWS html page

In this pattern you can also add an `ETag` (a version ID of your choosing) or `Last-Modified` date header to the response. Next time the client fetches the resource, it echoes the value for the content it already has via `If-None-Match` and `If-Modified-Since` respectively, allowing the server to say "Just use what you've already got, it's up to date", or as it spells it, "HTTP 304".

### Use case: use service worker to serve offline content

This is a great read for how to set up service worker and their cache settings:

[Caching best practices & max-age gotchas — JakeArchibald.com](https://jakearchibald.com/2016/caching-best-practices/)

In short

```javascript
self.addEventListener('install', (event) => {  
  event.waitUntil(  
    caches  
      .open(`static-${version}`)  
      .then((cache) =>  
        cache.addAll([  
          '/root.html',  
          '/script-v123.js',  
          '/styles-v234.css',  
          '/img-v123.jpg',  
        ]),  
      ),  
  );  
});
```

For the root html page, its Cache-Controle header should be set to
```shell
Cache-Control: no-cache
```
so that each service worker update will trigger a request for the root page. but the rest of the resources:
```javascript
'/script-v123.js',  
'/styles-v234.css',  
'/img-v123.jpg',
```

will have this Cache-Control setting:
```shell
Cache-Control: max-age=31536000
```
They will only be downloaded if their URL has changed.

---

# Building a Simple Angular Application Using Signals

### Introduction

Signals are a powerful feature in Angular that improve state management, reactivity, and change detection. In this tutorial, we walk through the process of building a simple Angular application using signals, `computed`, `linked signals`, and the experimental `RX Resource`. The example application dynamically displays Star Wars vehicle data and calculates totals based on user input.

### Understanding Signals in Angular

### What are Signals?

Signals are a new state management tool in Angular that provide a reactive way to manage and respond to state changes. Unlike traditional approaches like observables, signals are simpler, easier to reason about, and reduce change detection overhead.

### Key Signal Features Used:

1.  **Signal:** A reactive value that triggers updates when it changes.
2.  **Computed Signal:** A signal whose value is derived from other signals and recalculated automatically when dependencies change.
3.  **Linked Signal:** A signal that resets its value based on changes in a source signal.

### Building the Application

### Step 1: Setting Up the Angular Project

To begin, create a new Angular project using the Angular CLI
```shell
ng new signals-in-action --standalone
```
Next, add `HTTPClientModule` for API requests and a service to handle data fetching.

### Step 2: Creating the Service with Signals

The `VehicleService` retrieves Star Wars vehicle data from the public SWAPI (Star Wars API). Signals are used to manage the app's reactive state.

###### Define the Service:

-   Inject the HTTP client to make API requests.
-   Use signals to manage key application state.
```javascript
export class VehicleService {  
  vehicles = signal<Vehicle[]>([]); // Holds fetched vehicle data  
  selectedVehicle = signal<Vehicle | undefined>(undefined);  
  quantity = signal<number>(1);  
  
totalCost = computed(() =>   
    (this.selectedVehicle()?.cost_in_credits || 0) * this.quantity()  
  );  
  color = computed(() =>  
    this.totalCost() > 50000 ? 'green' : 'blue'  
  );  
}
```
### Explanation:

-   `signal<Vehicle[]>`: Holds the list of vehicles fetched from the API.
-   `selectedVehicle`: Tracks the user's selected vehicle.
-   `computed`: Calculates the total cost based on selected vehicle and quantity.
-   Conditional styling (green/blue) is derived using `computed`.

### Step 3: Adding a Component with Signals

Create a `VehicleSelection` component:
```shell
ng generate component vehicle-selection --inline-template --skip-tests
```

Inject the `VehicleService` into the component to access the signals. Bind the signals to the template using Angular's reactive features.

### Template:
```html
<div>  
  <label>Select Vehicle:</label>  
  <select [ngModel]="vehicleService.selectedVehicle()"   
          (ngModelChange)="vehicleService.selectedVehicle.set($event)">  
    <option *ngFor="let v of vehicleService.vehicles()" [value]="v">  
      {{ v.name }}  
    </option>  
  </select>  
  
<label>Quantity:</label>  
  <input type="number" [ngModel]="vehicleService.quantity()"   
         (ngModelChange)="vehicleService.quantity.set($event)" />  
  <div>  
    <p>Price: {{ vehicleService.selectedVehicle()?.cost_in_credits }}</p>  
    <p [style.color]="vehicleService.color()">Total: {{ vehicleService.totalCost() }}</p>  
  </div>  
</div>
```
### Key Features in the Template:

1.  **Two-Way Binding:** Signals are bound to user inputs (`select` and `input`) for reactivity.
2.  **Computed Signals:** Automatically calculate and update total cost and text color.

### Enhancing State Management with RX Resource

Angular 19 introduces `RX Resource`, which simplifies fetching data and converting it into reactive signals.

### Using RX Resource:
```javascript
vehicleResource = rxResource(() =>   
  this.http.get<VehicleResponse>('https://swapi.dev/api/vehicles/')  
    .pipe(map(response => response.results))  
);  
vehicles = computed(() => this.vehicleResource.value() || []);
```

-   `RX Resource` fetches API data and converts it into a signal.
-   `computed` ensures the vehicle list is always reactive.

### Finalizing the Application

The completed app dynamically retrieves vehicle data, updates totals based on quantity, and conditionally changes styles when thresholds are met.

### Linked Signal for Resetting Quantity

To reset the quantity when a new vehicle is selected:
```javascript
quantity = linkedSignal({  
  source: this.selectedVehicle,  
  compute: (selected) => (selected ? 1 : 0)  
});
```

This ensures the quantity resets to `1` when the user picks a new vehicle.

### Benefits of Using Signals

1.  **Improved Change Detection:** Signals provide precise updates, reducing unnecessary recalculations.
2.  **Declarative Code:** Code is easier to read and maintain with clear data flow.
3.  **Better Performance:** Signals simplify state management and reduce overhead.

### Conclusion

Using Angular's signal features, we built a simple yet reactive application that dynamically manages state and calculates values. Signals, combined with computed and linked signals, provide a clean, efficient, and declarative way to handle reactivity.

By integrating RX Resource, we further enhanced the app's state management for real-time data fetching. Signals are a game-changer for building scalable and maintainable Angular applications.

---
# Understanding Vendor.js, Polyfill.js, Style.css, Main.js, and Runtime.js in an Angular Application. 

## Introduction :

When building an Angular application, developers often come across various JavaScript and CSS files that play a crucial role in the application's functionality and styling. In this blog post, we will explore the purpose and significance of several key files commonly found in an Angular project: vendor.js, polyfill.js, style.css, main.js, and runtime.js. Understanding these files will help developers gain insights into the inner workings of an Angular application and optimize their projects effectively.

## Vendor.js :

The vendor.js file is generated during the build process of an Angular application. It contains all the external libraries and dependencies that your application relies on. These can include frameworks like Angular itself, as well as third-party libraries like RxJS, Angular Material, or Bootstrap. The purpose of bundling these dependencies into a single file is to optimize the application's loading time by reducing the number of network requests needed to fetch multiple JavaScript files.

By bundling the vendor dependencies together, the Angular build process creates a separate chunk that can be cached by the browser, resulting in faster subsequent loads of your application.

## Polyfill.js :

Polyfills play a vital role in ensuring that your Angular application runs smoothly across different browsers and versions. They provide modern JavaScript features to older browsers that do not natively support them. The polyfill.js file includes a collection of JavaScript code that “polyfills” or replicates missing features in older browsers.

Angular applications leverage features from the ECMAScript standards, and not all browsers support the latest specifications. Polyfills bridge this gap by enabling the use of modern JavaScript syntax, APIs, and functionalities in older browsers. The polyfill.js file is automatically generated during the build process, and its contents are based on the browser support configuration specified in the Angular project.

## Main.js :

The main.js file is the entry point of your Angular application. It contains the bootstrap logic that initializes and launches your Angular application. When the browser loads the main.js file, it triggers the Angular framework to start, which in turn bootstraps the root module of your application.

The main.js file is generated during the Angular build process. It includes the necessary code to set up the application environment, load the required modules, and configure the application for rendering in the browser. It also handles other essential tasks such as registering service workers for progressive web apps (PWAs) and enabling production optimizations like AOT (Ahead-of-Time) compilation.

## Runtime.js :

The runtime.js file is another crucial component of an Angular application. It provides the runtime environment necessary for the execution of your application. The file contains the core Angular runtime code, which enables Angular-specific functionalities such as change detection, dependency injection, and routing.

---

### Angular Analyzing Bundles with Source Map Explorer

### What is Source Map Explorer?

Source Map Explorer is a tool that helps you visualize the contents of your JavaScript bundle by generating a map of your code. Think of it like an x-ray machine for your bundle — you get to see what's inside, which parts take up the most space, and what can potentially be optimized. If you've ever wondered why your web app's bundle is larger than a holiday fruitcake, this tool can help you pinpoint exactly what the problem is.

### Why Should You Care?

JavaScript bundles can easily grow out of control, resulting in slower page load times and a subpar user experience. Large bundles mean more data to download and more code for the browser to parse and execute — ultimately, it means longer wait times for your users. Keeping bundles light and clean makes your application faster, keeps your users happy, and can even improve your search engine rankings.

Source Map Explorer helps by breaking down your bundle, letting you see the size of each module or library, so you can decide whether that 100-kilobyte utility function or that fancy new library is worth the extra bloat.

### Setting Up Source Map Explorer

Getting started with Source Map Explorer is pretty simple. You'll need to install it in your project first. Run the following command:

```javascript
npm install -g source-map-explorer
```

If you prefer to add it as a dev dependency in your project, you can use:
```javascript
npm install --save-dev source-map-explorer
```
Once installed, it's time to dig into the juicy details of your JavaScript bundle.

### Running Source Map Explorer

To analyze your bundle, you need to pass in the JavaScript file along with its corresponding source map file to the Source Map Explorer. Typically, it would look something like this:
```javascript
npx source-map-explorer dist/main.js dist/main.js.map  
  
or   
  
npm source-map-explorer dist/main.js dist/main.js.map
```
This command will open up a visual representation of your bundle in your default browser, giving you a colorful breakdown of all the code inside.

### Making Sense of the Visualization

The output from Source Map Explorer is a tree map, which might look overwhelming at first. Here's how to make sense of it:

-   **Big Blocks Mean Big Modules**: The larger the block, the more space that particular module takes up in your bundle. For example, if you see a big blue block with the word “Lodash” on it, it means Lodash is taking up a large chunk of your bundle.
-   **Colors Represent Different Parts**: Each library or module is assigned a different color, making it easier to distinguish between them at a glance.
-   **Drill Down and Investigate**: You can often click on individual blocks to drill down deeper into the bundle, allowing you to see exactly what files or functions are eating up your precious kilobytes.

### Tips for Reducing Bundle Size

Once you know what's taking up the most space in your bundle, you can take steps to reduce it:

1.  **Remove Unused Dependencies**: If you find that a library is taking up a lot of space but isn't providing much value, consider removing it or finding a smaller alternative.
2.  **Tree Shaking**: Make sure your bundler (like Webpack or Vite) is configured to perform tree shaking, which removes unused code from your bundles.
3.  **Lazy Loading**: Only load what you need when you need it. For instance, instead of loading an entire library at the start, you can load specific parts on demand.
4.  **Code Splitting**: Break up your bundle into smaller chunks that can be loaded separately, ensuring that users only download what they need.

### Conclusion

Source Map Explorer is an invaluable tool for anyone looking to optimize their JavaScript bundles and improve the performance of their web applications. By giving you a detailed view of what's inside your code, it helps you make informed decisions on what to keep, what to remove, and what to optimize.

Next time your app feels sluggish, think of Source Map Explorer as your personal dietitian — helping you trim the unnecessary fat and get your app back in shape. Give it a try, and you'll see how easy it is to spot the bottlenecks in your JavaScript.

---

# Angular Dependency Providers. Dependency Injection (DI) 

**Dependency Injection** (**DI**) is a **design pattern** that creates the dependencies of a class and provides those objects to the class when required. Angular being a nice framework provides a built-in dependency injection mechanism that creates and provides runtime version of a dependency value using dependency injectors.

In order for dependency injectors to provide values, we must first configure the injector which tells the injectors that which values to provide. Injectors configuration is done using **providers**.

To configure the injector, we supply the value to the **providers** array of the module or component (depending upon the scope of the provided instance, but that's another topic).

The simplest way to configure an injector using providers is by supplying the class name itself. For example, to provide an instance of a dependency i.e. “MessageService”, we can write
```javascript
    providers: [MessageService]
```
## **What really happens**

Okay, now the fun part begins here. When we provide the value as a class name, what really happens behind the scene is that angular creates a **provider configuration object** using this provided value. The class-provider syntax is a shorthand expression that expands into a provider configuration object. For example, the above-provided value expands as
```javascript
  providers: [{ provide: MessageService, useClass: MessageService }]
```
The **provide** property of this **configuration object** holds the value known as **Token** which is used by the injector to locate the required dependency value.

The second property of this object holds the **actual dependency** value which is provided by the injector when its dependency is required. This property can be one of the following, depending upon different use cases discussed in this article.

· useClass
· useValue
· useExisting
· useFactory

Use of these configuration properties depend upon different use cases and are used with different type of tokens.

## **Provider Tokens**

The first property of the configuration object holds the provider token. There are **three different ways of defining tokens**.

· Type Token
· String Tokens
· InjectionToken (Opaque Token before Angular 4.x)

## **Type Token**

Type token means when we use a defined type i.e. class as token as we did in the above example. We usually provide a type as a token which is expanded in configuration object and tell the injector to provide that **type** dependency.
```javascript
 providers: [MessageService]
```
Now there may be cases when we want to use some different class instead of the same class used as a token. This is possible using **useClass** property. In the following example, the **useClass** property tells the injector to use DirectMessageService class when MessageService is required somewhere in the application using DI.
```javascript
   [{ provide: MessageService, useClass: DirectMessageService }]
```
Sometimes there are cases when you use a class different from token but that class is already used as a provider. For example, look at the following example
```javascript
Providers: [ ErrorMessageService, { provide: MessageService, useClass: ErrorMessageService}]
```
In this case, the injector will create two different instances of the ErrorMessageService class. Now to solve this problem we can use the **useExisting** configuration property, which will use the existing class instance instead of creating a new instance again.
```javascript
Providers: [ ErrorMessageService, { provide: MessageService, useExisting: ErrorMessageService}]
```
Sometimes it's required to provide a ready-made object rather than asking the injector to create it from a class. To inject an object, which you have already created, configure the injector with the `useValue` option
```javascript
const messageObj = {  
messageType: 'Direct',  
messageText: 'this is a direct message'  
};
Providers: [{ provide: MessageService, useValue: messageObj }]
```
**TypeScript interfaces are not valid tokens.** So if you want to use interface as a token and provide its implementation as provider it's not possible. One alternative is to use **String Token.**

## **String Token**

String token allows us to make objects available via DI without introducing an actual type. We can define a string and use it as a valid token.
```javascript
const FEATURE_ENABLED =true;
let featureMessageToken = 'messageFeatureEnabled';
...

providers: [  
    { provide: featureMessageToken, useValue: FEATURE_ENABLED}  
]
```

All we do is, instead of using a type, we use a simple string as a token. We can inject this dependency using the `@Inject()` decorator likes this:
```javascript
import { Inject } from '@angular/core';  
class MyComponent {constructor(@Inject(featureMessageToken) private featureEnabled) {...}}
```

This is pretty cool right.

If a token is repeated in the injector configuration, the last one wins, and the injector uses the last provider configuration which has the same token values. In the case of string tokens, there are chances when tokens can be the same i.e. some third module can be using the same string token. In this case, the last found will be picked. To solve this issue, we can use the **Injection Token**.

## **InjectionToken**

The third way of defining token is InjectionToken. It is the same as string token but it generates a unique value every time so there are no same token conflicts.
```javascript
import { ReflectiveInjector } from '@angular/core';class DirectMessageService {};  
class ErrorMessageService {};let Message Token = "DMService";  
let Message Token = "EMService";let injector = ReflectiveInjector.resolveAndCreate([  
{ provide: MessageToken, useClass: DirectMessageService },  
{ provide: MessageToken, useClass: ErrorMessageService },  
]);
```

## **Factory Providers**

Sometimes it is required to create dependency values dynamically, using some runtime values. For example, we want to create a DirectMessageService class object if the user has direct message settings enabled. In this case, we can use the **factory provider,** which will check the user settings while creating class instance.
```javascript
let messageFactory = (settings) => {  
    if(settings.DirectEnabled)  
      return new DirectMessage();  
};
```

And use this factory using the **useFactory** configuration property.
```javascript
{ provide: DirectMessageService, useFactory: messageFactory};
```

## **Multi Providers**

The provider configuration object has another interesting property multi. Using `multi: true` tells Angular that the provider is a multi-provider. With multi providers, we can basically provide **multiple dependencies for a single token.** This can be used using InjectionToken as defined above. If we ask for dependency for that token, what we get is a list of all registered and provided values.

Angular provides a number of built-in injection-token constants that you can use to customize the behavior of various systems. You can use these built-in tokens as hooks into the framework's bootstrapping and initialization process. A provider object can associate any of these injection tokens with one or more callback functions that take app-specific initialization actions.

· PLATFORM_INITIALIZER
· APP_BOOTSTRAP_LISTENER
· APP_INITIALIZER

This is pretty much all about Angular providers. Angular documentation also provides detailed information about all these configurations.

---

### Unlock the Power of Local Variables in Angular with @let

**@let: Harness the Power of Local Variables in Your Angular Templates**

Angular 19 introduces a new directive called `@let`, which is designed to simplify working with local variables within templates. This directive is aimed at providing developers with a cleaner, more expressive way to manage values derived from expressions in Angular templates, reducing redundancy and enhancing readability.

### What is `@let`?

The `@let` directive is a structural directive introduced in Angular 19 that allows developers to declare local variables directly in the template. This functionality is incredibly useful when you need to reuse the result of an expression without recalculating it multiple times, or when you want to manage multiple states more conveniently.

The `@let` directive helps avoid repeating the same expression across multiple bindings and enables easier tracking of values, making the template cleaner and more efficient.

### Syntax Overview

The syntax for `@let` is intuitive and concise. It allows developers to introduce variables in the template without additional boilerplate code.

Here's a basic example of how `@let` works:
```javascript
@let name = user.name;  
@let data = data$ | async;  
  
<p>Hello, {{ name }}!</p>  
<div>  
  @if (data) {  
    <p>Data loaded: {{ data }}</p>  
  } @else {  
    <p>Loading data...</p>  
  }  
</div>
```

In this example, `@let` creates local variables named `name` and `data`. The `name` variable holds the `user.name` value, while `data` uses the `async` pipe to handle an observable. You can then use these variables in subsequent bindings within the same template block. This saves you from having to repeatedly access `user.name` or use the `async` pipe each time you need it.

### Why Use `@let`?

There are several advantages of using `@let` in your Angular templates:

1.  **Avoid Redundancy**: If you have a value that's used multiple times, `@let` can prevent repeated calculations by defining the value once and reusing it.
2.  **Improved Readability**: Templates that involve complex bindings or calculations can quickly become unreadable. By assigning parts of these calculations to local variables with `@let`, you make your templates much easier to follow.
3.  **Cleaner Logic**: When combining `@let` with directives like `@if`, the overall structure becomes cleaner, as you can define your data logic right where it is needed.

Consider the following example with redundant code:
```html
<p>The total price is: {{ cart.items.length * cart.itemPrice }}</p>  
@if (cart.items.length * cart.itemPrice > 100) {  
  <button>Discount Available!</button>  
}
```
With `@let`, the same template becomes much more readable:
```javascript
@let totalPrice = cart.items.length * cart.itemPrice;  
  
<p>The total price is: {{ totalPrice }}</p>  
@if (totalPrice > 100) {  
  <button>Discount Available!</button>  
}
```

### Usage Scenarios

The `@let` directive can be particularly useful in scenarios where:

1.  **Repeated Expressions**: You have an expression that appears multiple times in your template, and you want to avoid recalculating it.
2.  **Complex State Management**: You need to handle multiple related states that are derived from data within the template. Instead of recalculating these states multiple times, you can use `@let` to manage them more efficiently.
3.  **Conditional Rendering with** `**@if**`: When you use `@let` in combination with `@if`, you can simplify how you handle conditional rendering, making the template easier to manage and debug.

### Comparison with Traditional Approaches

In the past, developers might have opted for using methods or properties in their components to handle repeated logic. While this approach is still valid, `@let` provides an elegant way to declare such logic directly within the template, reducing the need for repetitive bindings or extra component code.

For example, before `@let`, you might have seen this:
```html
<p>{{ getTotalPrice() }}</p>  
<button *ngIf="getTotalPrice() > 100">Discount Available!</button>
```
This approach, while functional, involves calling a method multiple times, which can be inefficient and harder to debug. With `@let`, the template logic becomes both more efficient and easier to read:
```html
@let totalPrice = getTotalPrice();  
  
<p>{{ totalPrice }}</p>  
@if (totalPrice > 100) {  
  <button>Discount Available!</button>  
}
```

### Conclusion

The `@let` directive is a powerful addition to Angular 19, providing developers with a simple way to manage local variables within templates. By reducing redundancy, enhancing readability, and allowing for cleaner conditional rendering, `@let` helps developers write more maintainable and efficient Angular code.

If you haven't tried `@let` yet, start by refactoring some of your templates that involve repeated logic. You'll quickly notice the improvements in readability and maintainability.

---
# Angular Components Communication
### Understanding Angular Components Communication

Angular components are the building blocks of an application, and they often need to share data or trigger actions with one another. Understanding how components communicate is crucial for creating a cohesive and responsive user interface.

### Why Is Components Communication Important?

Effective communication between Angular components is essential for several reasons:

1.  **Modularity**: Components encapsulate specific functionality, and communication allows them to work together cohesively while maintaining modularity.
2.  **Reusability**: Components can be reused in different parts of the application, and communication enables them to adapt and interact seamlessly.
3.  **Parent-Child Relationships**: In hierarchical component structures, parent and child components need to exchange data or trigger events.
4.  **Maintainability**: Well-established communication patterns contribute to code maintainability, making it easier to understand and update.

### When to Use Each Communication Strategy

Choosing the right communication strategy depends on the specific use case:

1.  **@Input and @Output**: Ideal for parent-child relationships, where the parent needs to pass data to the child, and the child needs to emit events to the parent.
```javascript
// Child Component  
import { Component, Input, Output, EventEmitter } from '@angular/core';  
  
@Component({  
  selector: 'app-child',  
  template: `<div (click)="emitEvent()">Child Component</div>`,  
})  
export class ChildComponent {  
  @Input() dataFromParent: string = '';  
  @Output() customEvent = new EventEmitter<string>();  
  
  emitEvent() {  
    this.customEvent.emit('Event from Child');  
  }  
}
```
```javascript
// Parent Component  
import { Component } from '@angular/core';  
  
@Component({  
  selector: 'app-parent',  
  template: `  
    <app-child [dataFromParent]="parentData" (customEvent)="handleEvent($event)"></app-child>  
  `,  
})  
export class ParentComponent {  
  parentData: string = 'Data from Parent';  
  
  handleEvent(eventData: string) {  
    console.log('Event received in Parent:', eventData);  
  }  
}
```
2. **Services for Shared Data**: Angular services can act as a centralized hub for sharing data between components. Components inject the same service to access shared data.
```javascript
// Shared Service  
import { Injectable } from '@angular/core';  
import { BehaviorSubject } from 'rxjs';  
  
@Injectable({  
  providedIn: 'root',  
})  
export class DataService {  
  private sharedDataSubject = new BehaviorSubject<string>('Initial Data');  
  sharedData$ = this.sharedDataSubject.asObservable();  
  
  updateSharedData(newData: string) {  
    this.sharedDataSubject.next(newData);  
  }  
}
```
```javascript
// Components using the Shared Service  
import { Component, OnInit } from '@angular/core';  
import { DataService } from './data.service';  
  
@Component({  
  selector: 'app-component-a',  
  template: `<div>{{ sharedData }}</div>`,  
})  
export class ComponentAComponent implements OnInit {  
  sharedData: string = '';  
  
  constructor(private dataService: DataService) {}  
  
  ngOnInit() {  
    this.dataService.sharedData$.subscribe((data) => {  
      this.sharedData = data;  
    });  
  }  
}
```
3. **ViewChild and ContentChild**: Useful when a parent component needs to directly interact with its child components.
```javascript
// Parent Component with ViewChild  
import { Component, ViewChild, AfterViewInit } from '@angular/core';  
import { ChildComponent } from './child.component';  
  
@Component({  
  selector: 'app-parent',  
  template: `  
    <app-child></app-child>  
    <button (click)="callChildMethod()">Call Child Method</button>  
  `,  
})  
export class ParentComponent implements AfterViewInit {  
  @ViewChild(ChildComponent) childComponent!: ChildComponent;  
  
  ngAfterViewInit() {  
    this.childComponent.childMethod();  
  }  
  
  callChildMethod() {  
    this.childComponent.childMethod();  
  }  
}
```
4. **Event Emitters**: Appropriate for scenarios where components need to communicate custom events, especially when the components are not closely related.
```javascript
// Event Emitter Service  
import { Injectable, EventEmitter } from '@angular/core';  
  
@Injectable({  
  providedIn: 'root',  
})  
export class EventService {  
  customEvent = new EventEmitter<string>();  
}
```
```javascript
// Components using the Event Emitter Service  
import { Component } from '@angular/core';  
import { EventService } from './event.service';  
  
@Component({  
  selector: 'app-component-b',  
  template: `  
    <button (click)="emitEvent()">Emit Event</button>  
  `,  
})  
export class ComponentBComponent {  
  constructor(private eventService: EventService) {}  
  
  emitEvent() {  
    this.eventService.customEvent.emit('Custom Event Data');  
  }  
}
```
### Conclusion

In the dynamic world of Angular development, mastering various communication strategies between components is crucial for building interactive and maintainable applications. These practical examples showcase the application of different techniques in real-world scenarios, providing a foundation for creating robust Angular applications.

By understanding when to use @Input and @Output, services, ViewChild and ContentChild, and event emitters, developers can navigate the intricacies of Angular components communication, fostering modular, reusable, and well-communicating components.

---
# Mastering Global Error Handling in Angular: 

**Introduction**  
In any complex application, errors and exceptions are inevitable. From network failures to unexpected data types, handling these issues gracefully can spell the difference between a smooth user experience and a cascade of disruptive crashes. Angular provides a built-in mechanism to handle errors globally through its `ErrorHandler` interface. By creating a global custom error handler, you gain a single entry point for dealing with all runtime errors, enabling you to log issues, display user-friendly messages, and integrate with external monitoring services—all without littering your codebase with ad-hoc try-catch statements.

In this blog, we'll explore the fundamentals of global error handling in Angular, learn how to implement a custom error handler as both a class and a function-based factory, and discover best practices to ensure your application is production-ready.

**Why Global Error Handling Matters**  
Without a centralized error-handling strategy, you risk scattering various approaches throughout your application: a console log here, a user alert there. This decentralization makes it difficult to maintain a consistent user experience and effectively track and fix errors. A global error handler allows you to:

1.  **Maintain Consistency:** Centralize how errors are handled across all components and services.
2.  **Improve Maintenance:** Streamline debugging and logging by ensuring all runtime errors are funneled through a single method.
3.  **Enhance Reliability:** Integrate with tools like Sentry, Datadog, or New Relic for real-time alerts and performance monitoring.
4.  **User-Friendly Messaging:** Gracefully communicate errors to the user with minimal disruption, improving UX and user trust.

**Implementing a Class-Based Custom Error Handler**  
Angular's `ErrorHandler` is a simple interface with a single method signature:
```javascript
handleError(error: any): void;
```
To implement a global error handler, you create a class that implements `ErrorHandler` and override this method:

**custom-error-handler.service.ts:(class approach)**
```javascript
import { ErrorHandler, Injectable, isDevMode } from '@angular/core';  
  
@Injectable({  
  providedIn: 'root'  
})  
export class CustomErrorHandler implements ErrorHandler {  
  handleError(error: any): void {  
    // In dev mode, log the error to the console for debugging.  
    if (isDevMode()) {  
      console.error('An unexpected error occurred:', error);  
    }  
    // In production mode, integrate with an external logging service.  
    // Example: loggingService.logError(error);  
    // Optionally, you could display a user-friendly message or navigate to an error page.  
  }  
}  
```
**custom-error-handler.service.ts:(method approach)**
```javascript
import { ErrorHandler, isDevMode } from '@angular/core';  
  
export function customErrorHandlerFactory(): ErrorHandler {  
  return {  
    handleError: (error: any): void => {  
      if (isDevMode()) {  
        console.error('An unexpected error occurred:', error);  
      }  
      // Integrate with external logging services in production  
      // loggingService.logError(error);  
    }  
  };  
}
```

**Registering the Handler in AppModule:**
```javascript
import { NgModule, ErrorHandler } from '@angular/core';  
import { BrowserModule } from '@angular/platform-browser';  
import { AppComponent } from './app.component';  
import { CustomErrorHandler } from './custom-error-handler.service';  
  
@NgModule({  
  declarations: [AppComponent],  
  imports: [BrowserModule],  
  providers: [  
    { provide: ErrorHandler, useClass: CustomErrorHandler }  
  ],  
  bootstrap: [AppComponent]  
})  
export class AppModule {}
```
```javascript
import { NgModule, ErrorHandler } from '@angular/core';  
import { BrowserModule } from '@angular/platform-browser';  
import { AppComponent } from './app.component';  
import { customErrorHandlerFactory } from './custom-error-handler-factory';  
  
@NgModule({  
  declarations: [AppComponent],  
  imports: [BrowserModule],  
  providers: [  
    { provide: ErrorHandler, useFactory: customErrorHandlerFactory }  
  ],  
  bootstrap: [AppComponent]  
})  
export class AppModule {}
```
After angular 14+
```javascript
import { bootstrapApplication } from '@angular/platform-browser';  
import { provideHttpClient } from '@angular/common/http';  
import { ErrorHandler } from '@angular/core';  
import { AppComponent } from './app.component';  
import { CustomErrorHandler } from './custom-error-handler.service';  
  
bootstrapApplication(AppComponent, {  
  providers: [  
    provideHttpClient(),  
    { provide: ErrorHandler, useClass: CustomErrorHandler }  
  ]  
}).catch(err => console.error(err));
```

With this configuration, any unhandled error thrown during the runtime of your Angular application will pass through your `CustomErrorHandler`. This includes template errors, component initialization issues, and errors from observable subscriptions that fail to catch exceptions downstream.

**Using a Function-Based Factory**  
If you prefer a more functional approach, Angular's dependency injection system allows you to provide an `ErrorHandler` as a factory function rather than a class. This can be useful if you want a more lightweight syntax or if you're integrating configuration dynamically.

**custom-error-handler-factory.ts:**
```javascript
import { ErrorHandler, isDevMode } from '@angular/core';  
  
export function customErrorHandlerFactory(): ErrorHandler {  
  return {  
    handleError: (error: any): void => {  
      if (isDevMode()) {  
        console.error('An unexpected error occurred:', error);  
      }  
      // Integrate with external logging services in production  
      // loggingService.logError(error);  
    }  
  };  
}
```

**Registering the Factory in AppModule:**
```javascript
import { NgModule, ErrorHandler } from '@angular/core';  
import { BrowserModule } from '@angular/platform-browser';  
import { AppComponent } from './app.component';  
import { customErrorHandlerFactory } from './custom-error-handler-factory';

@NgModule({  
  declarations: [AppComponent],  
  imports: [BrowserModule],  
  providers: [  
    { provide: ErrorHandler, useFactory: customErrorHandlerFactory }  
  ],  
  bootstrap: [AppComponent]  
})  
export class AppModule {}
```
This functional approach offers the same benefits as a class-based handler, simply organized in a different style.

**Best Practices for Global Error Handling**

1.  **Differentiate Between Environments:**  
    Use Angular's `isDevMode()` function to provide more verbose logging in development and silent logging in production.
2.  **Integrate with Logging/Monitoring Tools:**  
    Consider sending errors to services like Sentry, Rollbar, or LogRocket. This provides insights into the types and frequency of errors, and helps you prioritize fixes.
3.  **User-Friendly Error Notifications:**  
    Instead of leaving the user in the dark when errors occur, show a non-technical message explaining that something went wrong. A friendly modal or toast can guide the user on what to do next.
4.  **Graceful Degradation:**  
    For certain errors, consider fallback strategies. For example, if an API call fails, you might display cached data or allow the user to retry.
5.  **Avoid Over-Handling:**  
    While global error handling is powerful, don't rely exclusively on it. In specific scenarios (e.g., form validation), it's often better to handle errors locally and give immediate, contextual feedback to the user.

**Conclusion**  
Global error handling in Angular is a vital tool for building robust, stable, and maintainable applications. By implementing a custom `ErrorHandler`, you gain centralized control over how your application responds to runtime errors. Whether you choose a class-based or function-based approach, the key is to integrate logging, user-friendly messages, and external monitoring to ensure that when errors occur—because they eventually will—you're equipped to handle them gracefully and keep your users engaged.

Adopting these strategies early on will set you up for long-term success, making troubleshooting easier, maintaining code quality simpler, and ultimately delivering a better user experience.

---

### Mastering Angular's @for Directive 

In modern web development, dynamically displaying lists is a common requirement. Angular's `@for` directive offers a streamlined approach to iterating over collections within your templates, enhancing both readability and performance.

### Understanding the `@for` Directive

The `@for` directive in Angular allows developers to loop through collections and render content for each item. This directive can handle any JavaScript iterable, though it is optimized for arrays.

### Basic Syntax
```html
@for (item of items; track item.id) {  
  <!-- Template for each item -->  
}
```
In this structure:

-   `item` represents the current element in the iteration.
-   `items` is the collection being iterated over.
-   `track item.id` is a tracking expression that uniquely identifies each item, aiding Angular in optimizing DOM manipulations.

The tracking expression is crucial as it helps Angular maintain a relationship between your data and the DOM nodes on the page, allowing for minimal DOM operations when data changes.

### Contextual Variables

Within an `@for` block, Angular provides several implicit variables:

-   `$count`: Total number of items in the collection.
-   `$index`: Index of the current item.
-   `$first`: `true` if the current item is the first in the collection.
-   `$last`: `true` if the current item is the last.
-   `$even`: `true` if the current item's index is even.
-   `$odd`: `true` if the current item's index is odd.

These variables can be aliased using the `let` keyword for clarity, especially in nested loops:
```html
@for (item of items; track item.id; let idx = $index, isEven = $even) {  
  <p>Item ###{{ idx }}: {{ item.name }} - Even: {{ isEven }}</p>  
}
```
Aliasing is particularly useful when nesting `@for` blocks, as it prevents naming collisions and enhances code readability.

### Handling Empty Collections

Angular allows the inclusion of an `@empty` block immediately after the `@for` content to handle scenarios where the collection is empty:
```html
@for (item of items; track item.id) {  
  <li>{{ item.name }}</li>  
}  
@empty {  
  <li>No items available.</li>  
}
```

In this example, if `items` is empty, the content within the `@empty` block is rendered, providing a graceful fallback for empty states.

### Best Practices

-   **Unique Tracking**: Always use a unique identifier in the `track` expression to help Angular efficiently manage DOM elements, especially in dynamic collections.
-   **Static Collections**: For collections that remain static, using `$index` in the `track` expression is acceptable.
-   **Dynamic Collections**: For collections that experience additions, deletions, or reordering, opt for a unique property of each item as the tracking key to ensure optimal performance.

Proper tracking is essential for performance optimization, as it allows Angular to execute the minimum necessary DOM operations when the data changes.

### Conclusion

Angular's `@for` directive simplifies the process of rendering lists by providing a clean and efficient syntax. By leveraging contextual variables, handling empty states, and adhering to best practices for tracking, developers can create dynamic and responsive user interfaces with ease.

---
# Angular Tree Shaking: A Comprehensive Guide

Tree shaking is a **dead code elimination technique** to remove unused JavaScript code from the final bundle. In modern front-end frameworks like Angular, it is particularly crucial to improve performance by reducing bundle size.

Angular leverages tree shaking, static analysis, TypeScript, Ahead-of-Time (AOT) compilation, and Webpack optimizations to improve application performance, and ensure efficient dependency management. This guide will dive deep into these topics and illustrate how tree shaking works in Angular with practical examples.

## Understanding Tree-Shaking in Angular

Tree-shaking removes unused code from the final JavaScript bundle during the build process. Angular achieves this primarily through:

-   **Static Analysis:** Identifying unused imports and dependencies.
-   **Dead Code Elimination:** Removing functions, classes, or services that are not referenced.
-   **Optimized Compilation:** Generating smaller and more efficient JavaScript bundles.

Angular's shift to the Ivy compiler has further improved tree-shaking by making service injection more dynamic and eliminating unnecessary module imports.

## Examples of Tree-Shaking in Angular

1.  **Removing Unused Services with** ** providedIn: 'root' **

In older Angular versions, services were manually provided in the providers' array within NgModule, making them always available in the final bundle. However, with providedIn: 'root', Angular tree-shakes services that are never used.

**Without Tree-Shaking (Legacy Approach)**
```javascript
import { NgModule } from '@angular/core';  
import { SomeService } from './some.service';  
  
@NgModule({  
 providers: [SomeService]  
})  
export class AppModule {}
```
-   **Issue:** Even if SomeService is never used, it remains included in the final bundle.

**With Tree-Shaking (Optimized Approach)**
```javascript
import { Injectable } from '@angular/core';  
  
@Injectable({ providedIn: 'root' })  
export class SomeService {  
 constructor() {  
   console.log('SomeService Loaded');  
 }  
}
```
-   **Tree-Shaking Benefit:** If SomeService is never referenced, Angular removes it from the bundle.

**2. Tree-Shaking Unused Functions in Modules**

If you have a module that exports multiple functions but only a few are used, tree-shaking removes the unused ones.

**Module with Multiple Functions**
```javascript
export function usedFunction() {  
 console.log('This function is used');  
}  
export function unusedFunction() {  
 console.log('This function is never used');  
}
```
**Usage in a Component**
```javascript
import { usedFunction } from './utils';  
usedFunction();
```
-   **Tree-Shaking Benefit:** unusedFunction() is never referenced, so Webpack removes it from the final build.

**3. Tree-Shaking Unused Components in Angular**

When using lazy loading and feature modules, Angular eliminates unused components.

**Feature Module (UnusedComponent is not referenced anywhere)**
```javascript
import { NgModule } from '@angular/core';  
import { CommonModule } from '@angular/common';  
import { UsedComponent } from './used.component';  
import { UnusedComponent } from './unused.component';  
  
@NgModule({  
 declarations: [UsedComponent, UnusedComponent],  
 exports: [UsedComponent]  
})  
export class FeatureModule {}
```
-   **Tree-Shaking Benefit:** Since UnusedComponent is never imported or used, Angular removes it during the build.

**4. Tree-Shaking with Lazy Loading**

Tree-shaking works well with lazy-loaded modules by eliminating unused feature modules from the initial bundle.

**Lazy Loaded Module (FeatureModule is loaded only when needed)**
```javascript
const routes: Routes = [  
 { path: 'feature', loadChildren: () => import('./feature.module').then(m =>  
m.FeatureModule) }  
];
```
-   **Tree-Shaking Benefit:** The FeatureModule is excluded from the main bundle and only loaded when necessary.

# How Angular Supports Tree Shaking Under The Hood

Angular applications utilize tree shaking in the following ways:

-   **AOT Compilation** eliminates unused Angular decorators and metadata before bundling.
-   **ES6 Modules** allow Webpack to analyze dependencies effectively.
-   **Webpack Optimization Plugins** remove dead code.
-   **TypeScript Compiler** helps ensure code is statically analyzable.

## **JIT vs. AOT Compilation and Their Impact on Tree-Shaking**

Angular supports two compilation modes:

1.  **JIT Compilation (The Old Way)**

JIT compilation is performed at runtime in the browser. Key characteristics include:

-   **Compilation at Runtime:** Angular compiles components and modules dynamically when the application loads.
-   **Larger Bundle Size:** The compiler itself is included in the final bundle, leading to a bloated size.
-   **Limited Tree-Shaking:** Due to dynamic dependencies, the bundler cannot determine which parts of the application can be safely removed.

**2. AOT Compilation (The New Way with Ivy)**

With AOT, Angular compiles templates and dependencies during the build phase. Benefits include:

-   **Smaller Bundle Size:** The Angular compiler is removed from the production bundle.
-   **Enhanced Tree-Shaking:** AOT ensures unused components, services, and dependencies are eliminated before the final build.
-   **Faster Performance:** Precompiled templates lead to faster rendering and improved startup times.

## **Webpack's Role in Angular's JIT and AOT Compilation**

Webpack is a module bundler that plays a critical role in both JIT and AOT compilation in Angular. The way Webpack processes dependencies in these two modes differs significantly.

**Webpack with JIT Compilation (The Old Way)**

With JIT, Webpack includes all necessary dependencies, but because Angular compiles templates dynamically at runtime, Webpack cannot fully optimize the output.

**JIT Webpack Configuration Example**
```json
{  
 "mode": "development",  
 "entry": "./src/main.ts",  
 "output": {  
   "filename": "bundle.js"  
  },  
 "module": {  
   "rules": [  
     {  
       "test": /.ts$/,  
       "use": "ts-loader",  
       "exclude": /node_modules/  
     }  
   ]  
 }  
}
```

-   Webpack includes Angular's compiler in the bundle.
-   Templates are compiled at runtime, leading to larger bundles.
-   Limited tree-shaking due to runtime dependency resolution.

**Webpack with AOT Compilation (The New Way with Ivy)**

With AOT, Angular compiles templates at build time, allowing Webpack to optimize the output more effectively.

**AOT Webpack Configuration Example**
```json
{  
 "mode": "production",  
 "entry": "./src/main.ts",  
 "output": {  
   "filename": "bundle.min.js"  
  },  
 "module": {  
   "rules": [  
     {  
       "test": /.ts$/,  
       "use": "@ngtools/webpack",  
       "exclude": /node_modules/  
     }  
   ]  
 }  
}
```
-   Webpack uses the @ngtools/webpack loader to perform AOT compilation.
-   The Angular compiler is **not included** in the final bundle.
-   Tree-shaking is fully effective because templates are precompiled.

## Common Pitfalls That Prevent Tree Shaking

1.  Using **require()** Instead of **import**

-   Tree shaking works only with ES6 import statements, not with CommonJS require()

2. Side Effects in Modules

-   Avoid side effects such as:
```javascript
// side-effects.ts  
console.log("This module has a side effect!");  
export function usefulFunction() {  
 console.log("This function might be used somewhere");  
}

// main.ts  
import { usefulFunction } from "./side-effects";  
usefulFunction();
```
Even if usefulFunction is removed by tree shaking, the console.log(“This module has a side effect!”) will still execute, preventing the entire module from being removed.

-   A “side effect” is defined as code that performs a special behavior when imported, other than exposing one or more exports. An example of this is polyfills, which affect the global scope and usually do not provide an export.
-   If you are sure there are no side effects, you can mark modules as side-effect-free using Webpack configuration in package.json.

Example:
```json
{  
 "sideEffects": false  
}
```

This tells Webpack that all files are pure (free of side effects), allowing aggressive tree shaking.

**3. Dynamic Imports in a Non-Optimal Way**

-   Use lazy loading for modules instead of importing everything upfront:
```javascript
loadChildren: () => import('./feature/feature.module').then(m =>  
m.FeatureModule)
```
## Importance of TypeScript with AOT and Ivy in Contrast to JIT

TypeScript plays a crucial role in Angular's AOT compilation process, offering significant advantages over JavaScript by enabling **static typing, better tooling, and enhanced tree-shaking.**

**TypeScript and AOT: A Strong Combination**

-   TypeScript allows **static analysis**, making it easier for the AOT compiler to perform ahead-of-time optimizations.
-   Strong **type safety** reduces runtime errors, which is crucial for large-scale enterprise applications.
-   TypeScript's support for **decorators and metadata reflection** integrates seamlessly with Angular's dependency injection and module resolution system.

**JIT and Hybrid Applications: Mixing JavaScript and TypeScript**

JIT compilation allows developers to write hybrid applications that combine **both TypeScript and JavaScript** within the same project. This approach is particularly beneficial for:

-   **Gradual Migration:** Applications transitioning from JavaScript to TypeScript can mix both languages.
-   **Dynamic Code Execution:** JIT enables runtime template compilation, which can be useful in cases requiring dynamic component rendering.
-   **Rapid Prototyping:** Since JIT compiles in the browser, changes are reflected instantly without a full rebuild, making it ideal for debugging.

**Historical Context of TypeScript Adoption in Angular**

-   **Before TypeScript (AngularJS 1.x):** AngularJS applications were written purely in JavaScript, making them prone to runtime errors due to lack of type safety.
-   **Angular 2 and the TypeScript Shift (2016):** Google officially adopted TypeScript as the primary language for Angular, introducing better developer experience and improved maintainability.
-   **Integration with AOT (Angular 4+):** TypeScript-powered AOT compilation became the standard, leading to smaller and faster production builds.
-   **Ivy and Further TypeScript Optimizations (Angular 9+):** The Ivy renderer further enhanced TypeScript's role by enabling better tree-shaking, lazy loading, and runtime efficiency.

**Comparing TypeScript with AOT vs. JavaScript with JIT**

![](https://miro.medium.com/v2/resize:fit:768/1*pkGbhhl0A7pSGj6Ni1iQNA.png)

## Conclusion

Tree shaking in Angular is a crucial optimization technique that relies on **static analysis, ES6 modules, AOT compilation, and Webpack optimizations.** By following best practices and understanding how Angular processes dependencies, developers can significantly reduce bundle sizes and improve application performance.

By leveraging tree-shakable providers ( providedIn: 'root' ) and component-level lazy loading, developers can build faster and more efficient Angular applications.

---

# Mastering Angular's @defer Block: A Lazy Loading Powerhouse
### What is the `@defer` Block?

The `@defer` block, introduced in Angular 16, lets you delay rendering parts of your template until certain conditions are met. It's a smarter way to prioritize what gets loaded first, optimizing the performance of your app.

For example:

-   **Lazy load non-critical components** after user interaction.
-   **Load content only when it's visible** in the viewport.
-   **Reduce initial bundle size** by deferring resource-heavy modules.

### Why Use the `@defer` Block?

The `@defer` block is perfect for scenarios like:

-   **Interactive Dashboards**: Load widgets only when needed.
-   **Complex Components**: Postpone rendering heavy components.
-   **Optimizing Mobile Apps**: Load lightweight elements upfront and heavy ones later.

Here's what you gain:

1.  **Faster initial page loads**.
2.  **Improved resource utilization**.
3.  **Dynamic, responsive user interfaces**.

### The `@defer` Syntax

The `@defer` block uses Angular's new control flow syntax to define when and how content should be loaded.

Here's the general structure:
```html
@defer (when <condition>) {  
  <!-- Content to load lazily -->  
} @placeholder {  
  <!-- Fallback content (optional) -->  
} @loading {  
  <!-- Content during the loading process (optional) -->  
} @error {  
  <!-- Content if loading fails (optional) -->  
}
```
**Key parts:**

-   `**when**`: The condition that triggers the deferred loading.
-   `**@placeholder**`: Shown before the condition is met.
-   `**@loading**`: Shown while the deferred content is being loaded.
-   `**@error**`: Shown if loading fails.

### Example: Loading a User Profile Lazily

Let's build a simple app where we load a user profile only when the user clicks a button.

###### Template
```html
<button (click)="loadProfile = true">Load Profile</button>  
  
@defer (when loadProfile) {  
  <app-user-profile></app-user-profile>  
} @placeholder {  
  <p>Click the button to load the user profile.</p>  
} @loading {  
  <p>Loading user profile...</p>  
} @error {  
  <p>Failed to load the profile. Please try again later.</p>  
}
```
// Component Class
```javascript
import { Component } from '@angular/core';  
  
@Component({  
  selector: 'app-defer-demo',  
  templateUrl: './defer-demo.component.html',  
  styleUrls: ['./defer-demo.component.css']  
})  
export class DeferDemoComponent {  
  loadProfile = false; // Trigger for lazy loading  
}
```
**What happens here:**

1.  Initially, the placeholder message is displayed.
2.  When the button is clicked, `loadProfile` becomes `true`, triggering the `@defer` block.
3.  If there's a delay, the loading message is displayed.
4.  If the user profile fails to load, the error message is shown.

### Advanced Example: Loading on Idle

Angular's `@defer` block supports advanced triggers like `on idle`. This trigger waits until the browser is idle before loading the content.
```html
@defer (on idle) {  
  <app-analytics-widget></app-analytics-widget>  
} @placeholder {  
  <p>Analytics widget will load shortly...</p>  
} @loading {  
  <p>Crunching numbers...</p>  
}
```
In this example, the analytics widget loads only when the browser is idle, ensuring critical content is prioritized first.

### How Does `@defer` Improve Performance?

-   **Prioritized Loading**: Load what users need first.
-   **Reduced Time to Interactive (TTI)**: Improve perceived performance by deferring non-essential elements.
-   **Smaller Initial Bundles**: Load heavy modules or components on demand.

### When Should You Use `@defer`?

Use `@defer` in situations where:

-   Non-critical content can wait (e.g., charts, analytics).
-   Content is dependent on user interaction (e.g., clicking a button).
-   You want to optimize for slow connections or devices.

### Best Practices for Using `@defer`

1.  **Always Use Placeholders**: Keep users informed while content is loading.
2.  **Handle Errors Gracefully**: Provide meaningful error messages.
3.  **Combine with Preloading**: Preload critical resources in the background for faster display.

### Conclusion

Angular's `@defer` block is a powerful tool for creating high-performance, user-friendly applications. By allowing you to defer the rendering of specific content, it optimizes load times and enhances the overall experience for your users.

So, whether you're building complex dashboards or lightweight mobile apps, the `@defer` block is your go-to feature for efficient lazy loading.
