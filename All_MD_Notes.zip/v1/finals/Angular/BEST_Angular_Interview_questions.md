# One Liners
    **1. BehaviorSubject:** Special Subject that holds current value and emits to new subscribers.  
    **2. Subject:** Multicast Observable, emits to multiple subscribers.  
    **3. @Input:** Decorator to pass data from parent to child component.  
    **4. @Output:** Decorator to emit data from child to parent component.  
    **5. @EventEmitter:** Emits custom events to parent components.  
    **6. Loading:** Shows progress/spinner while data is being fetched.  
    **7. Decorator:** A function to modify class/variable behavior.  
    **8. Directive:** Custom behavior applied to elements (structural/attribute).  
    **9. Service:** Shared logic across components using dependency injection.  
    **10. Pipe:** Transforms output in templates (e.g., date, currency).  
    **11. Guard:** Protects routes based on conditions (AuthGuard).  
    **12. Provider:** Supplies services/instances to Angular modules/components.  
    **13. Module:** Logical group of components, directives, and services.  
    **14. Interceptor:** Intercepts and modifies HTTP requests/responses.  
    **15. Wild Card Route:** Handles undefined routes using `**`.  
    **16. Promise & Async:** Handles async operations, resolves single value.  
    **17. Subject Type:** BehaviorSubject, ReplaySubject, AsyncSubject, etc.  
    **18. Binding:** Connects template and component data (e.g., one-way, two-way).  
    **19. HttpClient:** Angular service to make HTTP requests.  
    **20. HttpInterceptor:** Intercepts and modifies HTTP requests globally.  
    **21. Observables:** Streams of data, can emit multiple values over time.  
    **22. Form:** Handles user input using reactive or template-driven forms.  
    **23. LifeCycle Hooks:** Methods triggered at different component lifecycle stages (ngOnInit, ngOnDestroy).  
    **24. Dependency Injection:** Design pattern to inject services into components.  
    **25. Singleton:** A single instance of a service throughout the app.  
    **26. ViewContainerRef:** Accesses and manipulates views dynamically.  
    **27. Basics of Observables and Observers:** Observables emit data; Observers consume it.  
    **28. Common RxJS Operators:** Transform streams (map, filter, mergeMap, switchMap).  
    **29. Difference: Promise vs Observable:** Promise resolves once; Observable streams multiple values.
---
# Common Scenario-based Question Related to Angular That Many People Struggle to Answer Effectively
# Scenario: Imagine you are working on an Angular application, and you notice that the application is slow to load. How would you approach identifying and resolving the performance issue?

To identify and resolve performance issues in an Angular application, I would follow these steps:

1.  Identify the bottleneck: Use browser developer tools, such as the Chrome DevTools, to analyze the application's performance. Look for areas that are taking a significant amount of time, such as slow network requests, large file sizes, or expensive computations.
2.  Optimize network requests: Minimize the number of HTTP requests by combining and compressing files, using caching mechanisms like HTTP headers or browser caching, and employing techniques like lazy loading or code splitting to load resources only when needed.
3.  Optimize rendering: Identify any unnecessary re-rendering by using change detection strategies like `OnPush` and leveraging Angular's built-in change detection mechanism. Use tools like Angular Augury to visualize and debug change detection cycles.
4.  Optimize Angular-specific performance factors: Utilize Angular features like Ahead-of-Time (AOT) compilation, which reduces the application's initial load time. Optimize the size of Angular bundles by tree shaking, code minification, and enabling production mode.
5.  Reduce component complexity: Break down large components into smaller, more manageable pieces, using lazy loading and component hierarchy optimization. Avoid excessive template bindings, unnecessary subscriptions, and costly operations within lifecycle hooks.
6.  Optimize CSS and UI rendering: Minimize the use of CSS selectors, reduce the size of CSS files, and avoid expensive CSS properties or animations. Optimize UI rendering by using virtual scrolling, pagination, or lazy loading for large datasets.
7.  Use performance monitoring tools: Integrate performance monitoring tools like Google Analytics or New Relic to gain insights into real-time user experiences, identify performance bottlenecks, and track application performance over time.
8.  Conduct profiling and testing: Use Angular's built-in profiling tools like `ng.profiler` to identify specific areas of the code that are causing performance issues. Write performance tests to ensure that optimizations are effective and do not introduce regressions.

# Scenario: You are developing a form in Angular, and you need to implement form validation. The form has multiple fields with different validation requirements. How would you handle form validation in Angular, and what are some best practices you would follow?

When handling form validation in Angular, you can use Angular's built-in form validation mechanisms and follow these best practices:

1.  Use Angular's Reactive Forms: Reactive Forms provide a powerful and flexible way to handle form validation in Angular. They allow you to define the form structure and validation rules programmatically.
2.  Define form controls and validators: Create form controls for each input field and apply validators to enforce validation rules. Angular provides various validators like `required`, `minLength`, `maxLength`, `pattern`, etc. You can also create custom validators to meet specific requirements.
3.  Display validation messages: Bind error messages to form controls and display them when validation fails. Angular provides `ngIf` and `ngMessages` directives to conditionally show error messages based on the form control's validation state.
4.  Disable form submission on invalid state: Use the `disabled` attribute on the submit button and bind it to the form's validity state. This prevents users from submitting the form until all validation rules are satisfied.
5.  Use form groups and form arrays for complex forms: If your form has nested or dynamic fields, use form groups and form arrays to handle them. Form groups allow you to group related form controls together, while form arrays handle dynamic sets of form controls.
6.  Implement asynchronous validation: If you need to perform validation that involves asynchronous operations, such as making an HTTP request or checking against a server-side database, you can create custom asynchronous validators using the `AsyncValidatorFn` interface. This allows you to handle validation asynchronously and display relevant error messages to the user.
7.  Provide user-friendly feedback: Besides displaying error messages, consider providing visual feedback to indicate the validity state of form controls. For example, you can use CSS classes or icons to highlight valid and invalid fields, providing a better user experience.
8.  Validate on submit and as-you-type: Decide whether you want to perform validation on form submission or as the user types. For real-time validation, you can listen to form control value changes and validate the input as the user types. This helps users identify and correct errors immediately.
9.  Implement cross-field validation: In some cases, you may need to enforce validation rules that involve multiple fields. Angular provides the `Validators` class, which includes helper functions for implementing cross-field validation. You can create a custom validator that validates the relationship between multiple form controls.
10.  Test form validation: Write unit tests to verify that your form validation is working correctly. Angular provides testing utilities like `FormControl`, `FormGroup`, and `FormBuilder` to create test cases and assert the expected validation results.
11.  Accessibility considerations: Ensure your form validation includes proper accessibility support. Use ARIA attributes to describe the validation state and associate error messages with their corresponding form controls. This helps users with disabilities navigate and understand the validation errors.

# Scenario: You are working on an Angular application that needs to consume data from an external API. How would you handle asynchronous data retrieval in Angular and ensure the best user experience?

1.  Use Angular's HttpClient: Angular provides the HttpClient module for making HTTP requests. It offers features like observables and built-in error handling.
2.  Create a service: Create a service to encapsulate the logic for consuming the external API. Use the HttpClient to make the API requests and handle the responses.
3.  Implement loading indicators: Display loading indicators or spinners while the data is being fetched from the API. This provides feedback to the user and indicates that the application is actively retrieving data.
4.  Handle errors gracefully: Implement error handling to handle any errors that may occur during the API request. Display error messages to the user in a user-friendly manner and provide options for retrying the request if applicable.
5.  Implement caching: If appropriate for your application, implement caching mechanisms to avoid unnecessary API requests. You can use techniques like memoization or utilize browser storage such as sessionStorage or localStorage to cache the API response data.
6.  Use async/await or RxJS observables: Leverage the power of async/await or RxJS observables to handle asynchronous operations. Async/await provides a more synchronous-looking syntax, while observables offer powerful stream handling capabilities.
7.  Implement pagination or infinite scrolling: If you're dealing with a large dataset, consider implementing pagination or infinite scrolling to improve performance and user experience. Fetch data in chunks and load more as the user interacts with the UI.
8.  Optimize API requests: Analyze the data needs of your application and optimize the API requests accordingly. Minimize unnecessary data retrieval by specifying only the required fields and using query parameters effectively.
9.  Use Angular's lifecycle hooks: Utilize Angular's lifecycle hooks like ngOnInit and ngOnDestroy to initiate data retrieval when the component initializes and clean up resources when the component is destroyed.
10.  Test and optimize performance: Write unit tests for your data retrieval logic and perform performance testing to ensure optimal response times. Monitor API performance using tools like Angular's HttpClient Interceptors or browser developer tools.
---

# How I Failed an Angular Developer Interview by Failing to Answer this Simple Question 

**Question**: What is ngIf in Angular?

**Answer**: ngIf is a built-in directive in Angular that is used to conditionally display an element on the DOM based on a Boolean expression.

**Question**: What is ngSwitch in Angular?

**Answer**: ngSwitch is another built-in directive in Angular that is used to conditionally render elements on the DOM based on a given expression.

**Question**: What's the difference between ngIf and ngSwitch?

**Answer**: The main difference between ngIf and ngSwitch is that ngIf only checks for a single condition and displays an element if it's true, while ngSwitch allows you to specify multiple conditions and renders elements based on the first match.

For example, consider the following code:
```html
<div [ngIf]="isLoggedIn">  
  Welcome, {{ username }}!  
</div>
```
This code will only display the welcome message if the isLoggedIn variable is true.

Now, let's look at the ngSwitch example:
```html
<div [ngSwitch]="role">  
  <p *ngSwitchCase="'admin'">Welcome, Admin!</p>  
  <p *ngSwitchCase="'moderator'">Welcome, Moderator!</p>  
  <p *ngSwitchDefault>Welcome, User!</p>  
</div>
```
In this example, we're using ngSwitch to render different messages based on the value of the role variable. If the role is 'admin', it will display the message "Welcome, Admin!" and so on.

# Angular Interview Q&A: Day 8. Custom Validators, Hot vs Cold

# Question 1: How do you implement custom validators in Reactive Forms?

**Answer:**

Custom validators help enforce business rules beyond built-in validators.

**Example (age validator):**
```javascript
function ageValidator(control: AbstractControl): ValidationErrors | null {  
  const age = control.value;  
  return age >= 18 ? null : { underage: true };  
}  
  
// In FormGroup  
this.form = new FormGroup({  
  age: new FormControl('', [ageValidator]),  
});
```

**Template usage:**
```html
<div *ngIf="form.controls.age.errors?.underage">  
  You must be at least 18 years old.  
</div>
```
# Question 2: What are cold and hot observables in Angular?

**Answer:**

-   **Cold Observable:** Starts emitting values when subscribed to. Each subscriber gets a separate execution.
-   **Hot Observable:** Emits values regardless of subscriptions. All subscribers share the same execution.

**Cold (e.g., HTTP call):**
```javascript
this.http.get('/api/data'); // new request for every subscriber
```
**Hot (e.g., Subject):**
```javascript
const subject = new Subject();  
subject.subscribe(val => console.log(val));  
subject.next(1); // shared value
```
# Question 3: How does Angular handle HTTP error responses?

**Answer:**

Angular provides the `HttpErrorResponse` class to handle errors in HTTP calls. You can catch errors using `catchError` from RxJS.

**Example:**
```javascript
this.http.get('/api/data').pipe(  
  catchError((error: HttpErrorResponse) => {  
    console.error('Error:', error.message);  
    return throwError(() => new Error('Something went wrong'));  
  })  
);
```
> _✅ You can also use global_ `_HttpInterceptor_` _for centralized error handling._

# Question 4: How do you create dynamic components in Angular?

**Answer:**

Dynamic components are created at runtime using `ViewContainerRef` and `ComponentRef`.

**Steps:**

1.  Create a placeholder with `#container`
2.  Inject `ViewContainerRef`
3.  Dynamically create component with `createComponent`

**Example:**
```javascript
@ViewChild('container', { read: ViewContainerRef }) container!: ViewContainerRef;  
  
loadComponent() {  
  this.container.clear();  
  this.container.createComponent(MyDynamicComponent);  
}
```
# Question 5: What is a feature module and why should you use it?

**Answer:**

Feature Modules allow you to group related components, directives, and services. It improves modularity and helps with lazy loading and scaling.

**Benefits:**

-   Better organization
-   Separation of concerns
-   Improved load time with lazy loading

**Example:**
```javascript
@NgModule({  
  declarations: [DashboardComponent],  
  imports: [CommonModule, FormsModule],  
})  
export class DashboardModule {}
```

---

# Angular Interview Questions-Hard(20)

### 1. What is the difference between `ngOnInit` and `ngAfterViewInit` lifecycle hooks?

**A:**

-   `ngOnInit`: Called once after the component's data-bound properties are initialized.
-   `ngAfterViewInit`: Called after the component's view (and child views) are initialized.

**Example:**
```javascript
ngOnInit() {  
  console.log('ngOnInit called');  
}  
ngAfterViewInit() {  
  console.log('ngAfterViewInit called');  
}
```
### 2. What are `ngDoCheck` and `ngOnChanges`, and when should they be used?

**A:**

-   `ngDoCheck`: Called during every change detection run. Used for custom change detection logic.
-   `ngOnChanges`: Called when any input property changes.

**Example:**
```javascript
ngOnChanges(changes: SimpleChanges) {  
  console.log('Changes detected:', changes);  
}  
ngDoCheck() {  
  console.log('Custom change detection');  
}
```

### 3. Explain the concept of `ChangeDetectionStrategy.OnPush`.

**A:** The `OnPush` change detection strategy optimizes Angular performance by checking for changes only when an input property or event occurs, rather than on every change detection cycle.

**Example:**
```javascript
@Component({  
  selector: 'app-example',  
  changeDetection: ChangeDetectionStrategy.OnPush,  
  template: `<div>{{ data }}</div>`  
})  
export class ExampleComponent {  
  @Input() data: string;  
}
```

### 4. What are the key differences between Angular's `Injector` and `ReflectiveInjector`?

**A:**

-   `Injector`: The base class for DI in Angular, used to inject services.
-   `ReflectiveInjector`: An older injector class, now deprecated, providing more flexible DI capabilities for reflection-based injections.

### 5. How would you implement a custom `asyncValidator` in Angular?

**A:** An `asyncValidator` is used for asynchronous form validation, often for server-side checks.

**Example:**
```javascript
export function asyncEmailValidator(http: HttpClient) {  
  return (control: AbstractControl) => {  
    return http.get(`api/check-email/${control.value}`).pipe(  
      map(response => (response ? null : { emailTaken: true }))  
    );  
  };  
}  
this.form = this.fb.group({  
  email: ['', [Validators.required], [asyncEmailValidator(this.http)]]  
});
```

### 6. How do you prevent memory leaks in Angular components?

**A:** Memory leaks occur when subscriptions, event listeners, or DOM references are not properly disposed of. Use `ngOnDestroy` to unsubscribe from observables and remove event listeners.

**Example:**
```javascript
ngOnDestroy() {  
  this.subscription.unsubscribe();  // Unsubscribing from an observable  
}
```

### 7. What is the difference between `ngModel` and Reactive Forms in Angular?

**A:**

-   `ngModel`: Template-driven forms, automatically handles form control updates.
-   Reactive Forms: Programmatically defined forms that offer more control and better validation support.

### 8. How does Angular handle dynamic component loading?

**A:** Use `ComponentFactoryResolver` to load components dynamically at runtime.

**Example:**
```javascript
import { ComponentFactoryResolver, ViewContainerRef, Component } from '@angular/core';  

@Component({ selector: 'app-dynamic', template: '' })  
export class DynamicComponent {  
    
    constructor(private resolver: ComponentFactoryResolver, private viewContainerRef: ViewContainerRef) {}  
    
    loadComponent(component: Type<any>) {  
      const factory = this.resolver.resolveComponentFactory(component);  
      this.viewContainerRef.clear();  
      this.viewContainerRef.createComponent(factory);  
  }  
}
```

### 9. What is the `ng-template` directive, and how is it used?

**A:** `ng-template` is used to define a template that can be rendered conditionally, often with structural directives like `*ngIf`or `*ngFor`.

**Example:**
```html
<ng-template [ngIf]="isVisible">  
  <p>This will be displayed if isVisible is true.</p>  
</ng-template>
```
### 10. Explain the concept of Ahead-of-Time (AOT) compilation.

**A:** AOT compiles Angular templates and components into efficient JavaScript code during the build process, improving performance and reducing the size of the application.

### 11. How would you optimize Angular applications for performance?

**A:** Some techniques include:

-   Lazy loading modules.
-   Using the `OnPush` change detection strategy.
-   Avoiding unnecessary bindings.
-   Using trackBy with `*ngFor`.

### 12. What are Web Workers in Angular, and how are they used?

**A:** Web Workers run JavaScript in the background on a separate thread to improve app performance.

**Example:**
```javascript
if (typeof Worker !== 'undefined') {  
  const worker = new Worker(new URL('./worker', import.meta.url));  
  worker.postMessage('Hello Worker');  
  worker.onmessage = ({ data }) => console.log(data);  
}
```

### 13. What are Angular's `trackBy` and why is it important?

**A:** `trackBy` is used in `*ngFor` to track changes in a list more efficiently, reducing the number of DOM manipulations.

**Example:**
```html
<div *ngFor="let item of items; trackBy: trackByFn">  
  {{ item.name }}  
</div>
```
```javascript  
trackByFn(index, item) {  
  return item.id; // Track by item id  
}
```

### 14. Explain Angular's custom decorators and how they are created.

**A:** Custom decorators are used to add metadata to classes, properties, methods, or parameters. Angular provides decorators like `@Input`, `@Output`, and `@Component`.

**Example (Custom Decorator):**
```javascript
function Log(target: any, key: string) {  
  let value = target[key];  
  const getter = () => value;  
  const setter = (newVal) => {  
    console.log(`Setting ${key} to ${newVal}`);  
    value = newVal;  
  };  
  Object.defineProperty(target, key, { get: getter, set: setter });  
}
```

### 15. How do you handle Internationalization (i18n) in Angular?

**A:** Angular provides the `@angular/localize` package for i18n support. It allows you to translate strings in templates and create different language versions of your application.

### 16. How do you secure Angular applications against XSS and CSRF?

**A:**

-   Use Angular's built-in sanitization for data binding to prevent XSS attacks.
-   Use `HttpClient` with a CSRF token for CSRF protection.

### 17. What are `ng-content` and its use in Angular?

**A:** `ng-content` allows you to project content into a component, enabling content distribution in a reusable component.

**Example:**
```javascript
<app-card>  
  <ng-content></ng-content>  
</app-card>
```

### 18. Explain how Angular handles Dependency Injection in more complex scenarios.

**A:** Angular provides a hierarchical injector system, where services can be injected at different levels (root, module, component).

### 19. What is the role of Service Workers in Angular PWA (Progressive Web App)?

**A:** Service Workers enable caching, background sync, and offline capabilities for Angular apps, improving performance and user experience in a PWA.

### 20. How does Angular handle module bundling and tree shaking?

**A:** Angular uses Webpack for bundling and tree shaking to remove unused code during the build process, reducing the application's final bundle size.

Thanks for staying with me till the end — your support means the world! If you found this helpful, show some love ❤️ by clapping and sharing it with others who might benefit. Don't forget to check out my other articles, and as always, happy coding! 🚀

---

### What is the role of Web Workers in Angular applications?
Approach:

-   Discuss the benefits of offloading CPU-intensive tasks to Web Workers.
-   Use the Angular CLI to generate and integrate a Web Worker.
Output:
Improved application responsiveness by running tasks in a separate thread.
---

### Question : How can you optimize Angular app performance?

**Answer:**

Here are key techniques:

-   Use `OnPush` change detection strategy.
-   Lazy-load modules.
-   Use `trackBy` in `*ngFor`.
-   Avoid memory leaks with unsubscribed Observables.
-   Minify and compress with Angular CLI:  
    `ng build --configuration=production`
-   Tree-shaking and Ahead-of-Time (AOT) compilation.
---

# Angular Interview Questions-Medium(20)

# 1. What is RxJS, and why is it important in Angular?

**A:** RxJS (Reactive Extensions for JavaScript) is a library for reactive programming using observables. Angular uses RxJS for asynchronous operations, such as HTTP calls and event handling.

**Example:**
```typescript
import { of } from 'rxjs';  
import { map } from 'rxjs/operators';  
of(1, 2, 3)  
  .pipe(map((x) => x * 2))  
  .subscribe((result) => console.log(result)); // Output: 2, 4, 6
```

# 3. What is the difference between `Subject`, `BehaviorSubject`, and `ReplaySubject`?

**A:**

-   **Subject**: Emits values only to subscribers after subscription.
-   **BehaviorSubject**: Emits the most recent value to new subscribers.
-   **ReplaySubject**: Emits a specified number of past values to new subscribers.

**Example:**
```typescript
import { BehaviorSubject } from 'rxjs';  
const behaviorSubject = new BehaviorSubject('Initial Value');  
behaviorSubject.subscribe(value => console.log('Subscriber 1:', value));  
behaviorSubject.next('Updated Value');  
behaviorSubject.subscribe(value => console.log('Subscriber 2:', value));   
// Output: Subscriber 2: Updated Value
```

# 4. What are Reactive Forms, and how do they differ from Template-Driven Forms?

**A:**

-   **Reactive Forms**: Managed programmatically, offering more control and validation flexibility.
-   **Template-Driven Forms**: Defined in templates, easier for simple forms.

**Example:**
```typescript
// Reactive Form  
constructor(private fb: FormBuilder) {  
  this.form = this.fb.group({  
    name: ['', Validators.required],  
    age: [null, [Validators.required, Validators.min(18)]],  
  });  
}  
submitForm() {  
  console.log(this.form.value);  
}
```
# 5. How does Angular handle lazy loading?

**A:** Angular allows modules to load only when needed using lazy loading to improve performance.

**Example:**
```typescript
const routes: Routes = [  
  { path: 'feature', loadChildren: () => import('./feature/feature.module').then(m => m.FeatureModule) }  
];
```
# 6. What are pipes in Angular, and how are they used?

**A:** Pipes transform data in templates. Angular provides built-in pipes like `uppercase`, `date`, and `currency`.

# 7. How do you create a custom pipe in Angular?

**A:** Use the `Pipe` decorator to define a custom pipe.

**Example:**
```typescript
@Pipe({ name: 'reverse' })  
export class ReversePipe implements PipeTransform {  
  transform(value: string): string {  
    return value.split('').reverse().join('');  
  }  
}
// Usage: {{ 'Angular' | reverse }} -> "ralugnA"
```
# 8. What are resolvers in Angular, and how are they used?

**A:** Resolvers fetch data before navigating to a route.

**Example:**
```typescript
@Injectable({ providedIn: 'root' })  
export class DataResolver implements Resolve<any> {  
  resolve() {  
    return this.http.get('https://api.example.com/data');  
  }  
}  
const routes: Routes = [  
  { path: 'home', component: HomeComponent, resolve: { data: DataResolver } }  
];
```

# 9. How does Angular support state management?

**A:** Angular doesn't have built-in state management but integrates well with libraries like NgRx or Akita.

**Example (NgRx):**
```typescript
import { createReducer, on } from '@ngrx/store';  
export const initialState = { count: 0 };  
export const counterReducer = createReducer(  
  initialState,  
  on(increment, (state) => ({ count: state.count + 1 })),  
);
```

# 10. What are Angular guards, and what types are available?

**A:** Guards control route access. Types include `CanActivate`, `CanDeactivate`, `Resolve`, etc.

**Example:**
```typescript
@Injectable({ providedIn: 'root' })  
export class AuthGuard implements CanActivate {  
  canActivate(): boolean {  
    return !!localStorage.getItem('token'); // Allow access if token exists  
  }  
}
```

# 11. How do you improve Angular app performance?

**A:** Key techniques include:

-   Lazy loading modules.
-   AOT (Ahead-of-Time) compilation.
-   OnPush change detection strategy.

**Example (OnPush):**
```typescript
@Component({  
  changeDetection: ChangeDetectionStrategy.OnPush,  
  template: `<p>{{ data }}</p>`  
})  
export class MyComponent {  
  @Input() data: string;  
}
```

# 12. What is Angular Universal?

**A:** Angular Universal is used for server-side rendering (SSR), improving SEO and performance.

**Example:**
```shell
ng add @nguniversal/express-engine
```
# 13. How are animations implemented in Angular?

**A:** Use the `@angular/animations` module.

**Example:**
```typescript
trigger('fadeIn', [  
  state('void', style({ opacity: 0 })),  
  transition(':enter', [animate('300ms ease-in', style({ opacity: 1 }))])  
]);
```
# 14. What is the difference between `forRoot()` and `forChild()` in routing?

**A:**

-   `forRoot()`: Configures the root router.
-   `forChild()`: Configures child routes in feature modules.

# 15. How do you handle route parameters?

**A:** Use `ActivatedRoute` to access parameters.

**Example:**
```typescript
constructor(private route: ActivatedRoute) {  
  this.route.params.subscribe(params => console.log(params['id']));  
}
```

# 16. What is view encapsulation in Angular?

**A:** Controls how styles apply to components:

-   **Emulated** (default): Styles scoped to the component.
-   **None**: Styles are global.
-   **ShadowDom**: Uses shadow DOM.

# 17. What is the `async` pipe in Angular?

**A:** The `async` pipe subscribes to observables or promises automatically.

**Example:**
```typescript
<p>{{ data$ | async }}</p>
```

# 18. What is differential loading?

**A:** Angular builds separate bundles for modern and legacy browsers, optimizing performance.

# 19. How do you handle errors in HTTP requests?

**A:** Use the `catchError` operator in RxJS.

**Example:**
```typescript
this.http.get('https://api.example.com/data')  
  .pipe(catchError(err => of([])))  
  .subscribe(data => console.log(data));
```

# 20. How does Angular handle testing?

**A:** Angular provides tools like **Karma** for unit testing and **Protractor** for end-to-end testing.

**Example (Unit Test):**
```typescript
it('should create the app', () => {  
  const fixture = TestBed.createComponent(AppComponent);  
  const app = fixture.componentInstance;  
  expect(app).toBeTruthy();  
});
```

---

# 10 Advanced Angular Interview Questionsestions that can help you impress your interviewers and land that dream role.

### 1. How Do You Make Angular Apps Faster?

Speed is crucial for web apps. The faster your app, the happier your users are. So, how can you improve Angular performance?

-   **Lazy Loading**: Think of lazy loading as only packing the essentials for a trip. Instead of loading everything at once, you load features only when they're needed.
-   **trackBy with ngFor**: When you use `trackBy`, Angular can track each item in a list, so it doesn't reload everything every time an item changes. This helps save on processing.
-   **OnPush Change Detection**: In this mode, Angular only checks for changes when a specific input changes, reducing unnecessary work behind the scenes.

These tweaks help your app run faster and smoother, creating a better experience for users and a better impression in your interview!

### 2. What's Dependency Injection in Angular, and Why Does It Matter?

Imagine needing to cook dinner but not knowing where to get ingredients. Dependency Injection (DI) in Angular is like having groceries delivered right to your kitchen! DI allows Angular to provide necessary resources to your components and services automatically.

With DI, you don't have to go searching for everything you need; Angular takes care of it, making your code cleaner, more efficient, and easier to test. And when you explain it this way in an interview, you're bound to stand out.

### 3. Can You Explain RxJS and Its Role in Angular?

RxJS is a library for reactive programming. Think of it like listening to your favorite playlist on shuffle — RxJS helps you manage and respond to different “songs” (or streams of data) as they come in.

In Angular, RxJS is essential for handling asynchronous data, like user inputs, HTTP requests, or any event that happens over time.

With RxJS, you can transform, combine, and manage these streams easily, making complex data handling a breeze.

### 4. What Are Angular Lifecycle Hooks?

Every Angular component goes through a lifecycle, like planting a seed, watching it grow, and eventually seeing it bloom. Lifecycle hooks let you interact with these stages.

For example:

-   `ngOnInit()`: Like planting the seed, this hook is called after Angular has set up the component.
-   `ngOnChanges()`: This is when you can react to changes in the component's inputs.
-   `ngOnDestroy()`: When your component is about to be removed, this hook lets you clean up resources.

Lifecycle hooks help you make the most out of each stage, giving you control over how your component behaves at different points.

### 5. How Does Angular Handle Forms?

Forms in Angular are more than just boxes to fill out — they're essential for user interaction. Angular gives you two main ways to manage forms:

-   **Template-Driven Forms**: These are straightforward and use Angular's two-way data binding to connect form controls to your model. Great for simpler forms!
-   **Reactive Forms**: Ideal for complex forms, these provide more control and flexibility, letting you manage the form state and validation in your TypeScript code.

Knowing the difference can show that you understand how to handle various form requirements in Angular.

### 6. What Is Angular's Router, and How Does It Work?

Imagine navigating a big city with a GPS. Angular's Router works similarly, directing users to different parts of your app without needing to refresh the page.

Angular's Router lets you define paths (like URLs) and what should appear on each path.

It also has features like lazy loading (only loading what's needed), guards (for added security), and custom transitions.

By mastering Angular's Router, you can create apps that feel seamless and easy to navigate.

### 7. How Do You Use Angular Modules to Organize Code?

Angular Modules are like drawers in a toolbox. Each drawer holds tools (components, services, pipes, etc.) for a specific part of your app.

Using modules keeps your app organized and manageable, especially as it grows. Core and Shared Modules are two common examples:

-   **Core Module**: Holds essential services and components used throughout the app.
-   **Shared Module**: Contains commonly used components, like buttons or loaders, that can be used in different modules.

Explaining modules this way in an interview shows that you know how to keep your code clean and organized.

### 8. What Are Angular Guards and Why Use Them?

Imagine you're hosting an event and need to check who can enter. Angular Guards work like security checks for your app's routes, controlling access based on specific conditions.

Types of guards:

-   **CanActivate**: Checks if a user can access a route.
-   **CanDeactivate**: Checks if a user can leave a route.

With guards, you can secure routes based on user roles, authentication status, or other conditions, making your app safer and user-friendly.

### 9. What Is NgRx and How Is It Used in Angular?

NgRx is like the brain of your app, keeping track of its state in one central place.

It's based on Redux and makes it easier to manage complex data across different parts of your app.

With NgRx, you can:

-   Store data centrally, so it's accessible across components.
-   Track changes in the app state and react to them.
-   Use actions and reducers to control how data flows.

NgRx is powerful for larger apps where managing state becomes tricky, and understanding it can give you a major edge in your interview.

### 10. How Do You Handle Errors in Angular?

Every developer has been there — a bug pops up, and suddenly nothing works. Angular has a few tools to help catch and handle errors gracefully.

-   **Error Handling with RxJS**: Operators like `catchError` help you catch errors in streams and recover gracefully.
-   **HttpClient Interceptors**: You can use interceptors to catch errors from HTTP requests and show a user-friendly message or take other action.

By knowing how to handle errors in Angular, you can prevent small problems from turning into big headaches, which interviewers will definitely appreciate.
---
# Why 90% Fail This Angular Interview Question 


Because it's **deceptively simple**. On the surface, it sounds like a knowledge check. But what it's asking is:

-   Do you understand Angular under the hood?
-   Can you optimize performance?
-   Do you _truly_ know what makes your app tick?

> **And most importantly: Can you explain it clearly**?

### What Most People Say (That's Not Enough)

> _“Angular checks for changes in the component and updates the view.”_

Technically not wrong — but **not even close to enough**.

The interviewer isn't looking for a vague description. They want to see if you've gone deeper than the docs.

### What You Should Say

Here's what a strong answer includes:

### ✅ 1. How Angular Uses Zones

Angular uses **Zone.js** to monkey-patch async operations (like `setTimeout`, HTTP requests, or DOM events). This means every time an async event completes, Angular is notified and runs **change detection**.

### ✅ 2. What Change Detection Does

Angular walks the component tree and compares current values to previous ones (aka “dirty checking”). If it detects a change, it updates the DOM.

### ✅ 3. How Strategies Like `OnPush` Work

By default, Angular checks **everything** on every change. But with `ChangeDetectionStrategy.OnPush`, Angular only checks:

-   When the component's input properties change
-   When an event inside the component fires
-   When you manually trigger it (e.g., using `ChangeDetectorRef.detectChanges()`)

This massively improves performance — but only if you understand how and when to use it.

### ✅ 4. When the View Doesn't Update

This is where the real gold lies. Explain cases like:

-   Updating an object property without changing its reference (e.g., `this.user.name = 'John'`)
-   Running code _outside_ of Angular's zone (like in some third-party libraries)
-   Forgetting to use the `async` pipe or manually subscribing without change detection

### The Trick to Acing This Question

**Don't just explain the mechanism. Show how you've used it.**

**Example:**

> _“In one project, we had a large data table that lagged during updates. We switched to_ `_OnPush_` _and used_ `_trackBy_` _in_ `_*ngFor_`_, which cut re-renders by 70%. We also moved some non-critical logic outside Angular's zone with_ `_NgZone.runOutsideAngular()_`_.”_

**_That's the kind of answer that gets a smile, a nod, and probably a callback._**

### You can refer my previous articles for more Angular Interview Questions…

### 1. What is the difference between constructor and ngOnInit?

One of the common questions which pop up in the interviewer's mind is what is the difference between constructor and ngOnInit? We mostly go with the answer that we write the dependencies in the constructors while we write logics in the ngOninit.

Sometimes, the interviewer will check what else we know about it? Why can't we put the services or logics in constructors?

The simple answer is that sometimes, we need to wait until all dependencies get loaded; or for parent/child components, we might need to wait until the component is loaded. That's why it's preferable to write the logic in ngOnInit.

Let's check other differences.

![](https://miro.medium.com/v2/resize:fit:791/1*IP_j0b-T0n_LUJ_YPeAkOA.png)

### 2. What is the difference between components and directives?

This one is extremely common too. The easy answer is directives do not have their shadow DOM while components have their HTML. Components used to break our application based on features, while directives only help to change the behavior of certain elements.

Let's check out some other differences.

![](https://miro.medium.com/v2/resize:fit:875/1*K0pD-F8vgkWSBVC8p5otqg.png)


### 3. What is the difference between ElementRef, TemplateRef, and viewContainerRef?

This question comes for more advanced Angular interviews where the interviewer wants to check how you are manipulating views or do you have experience in creating dynamic views in your Angular application.

Let's check out the difference between ElementRef, TemplateRef, and viewContainterRef with examples.

![](https://miro.medium.com/v2/resize:fit:875/1*IYWF68QmJ1S8wgyWV86oyg.png)

> ElementRef Example:

![](https://miro.medium.com/v2/resize:fit:809/1*o6lusRa79uIw2FdTxLqOJQ.png)

> TemplateRef Example:

![](https://miro.medium.com/v2/resize:fit:739/1*p2KoY-L7T3DdvMxM2bJlgQ.png)

> ViewContainerRef Example:

![](https://miro.medium.com/v2/resize:fit:771/1*Ms7AquQVs_oMl7KgvDS2Nw.png)


### 4. What is the difference between ng-content,ng-template, and ng-container?

Doesn't it look the same? Yes, when I was learning Angular all 3 keywords were the same for me but actually, all carry their own purposes.

Let's check out the difference between ng-content,ng-template, and ng-container with examples.

![](https://miro.medium.com/v2/resize:fit:873/1*BHbiMywWwwlOA2-9anrm0w.png)

> ng-content example:

![](https://miro.medium.com/v2/resize:fit:476/1*GRi5EnH2LXPlMf4rnh6EpQ.png)

> ng-template example:

![](https://miro.medium.com/v2/resize:fit:335/1*qMbt8UnQrXzaH-TP8uSpJA.png)

> ng-container example:

![](https://miro.medium.com/v2/resize:fit:390/1*ekblWYFuTAuvEu8h8cgzwg.png)


### 5. What is the difference between view-child and content-child?

We do deal with a lot of parent-child or sub-components. As Angular does support creating dynamic component on the fly or access the relative components based on their relation interviewer expect that we know the difference between view-child and content-child.

Let's check the difference between view-child and content-child with the examples.

![](https://miro.medium.com/v2/resize:fit:868/1*DT1Sf8d5XDbfqSRTfaFyow.png)

> View-Child Example:

![](https://miro.medium.com/v2/resize:fit:426/1*bCc5w8ON5cNenrw_iEgz_g.png)

> Content-Child Example:

![](https://miro.medium.com/v2/resize:fit:396/1*mYJFPv_SFBQXyklj_jh36g.png)


### 6. What is the difference between component view, host view, and embedded view?

This is an advanced Angular interview question that can be asked to know how the different views work in Angular.

Let's check the difference between component view, host-view, and embedded views with the examples.

![](https://miro.medium.com/v2/resize:fit:873/1*rVZdXwYj1UMpIxZNyrr5lQ.png)

> Embedded View Example:

![](https://miro.medium.com/v2/resize:fit:679/1*bnImNkqMhahLpqVCfKOLpg.png)

> Host View Example:

![](https://miro.medium.com/v2/resize:fit:661/1*Q1vr6PduhXhb1-aF2dTLgg.png)


### 7. What is the difference between debounce time and throttle time?

When we deal with the reactive forms and want the user to type and check on service based on the inputs this two-term is very handy.

![](https://miro.medium.com/v2/resize:fit:870/1*G_l-AIA2SmpdQqM9ZhAkcQ.png)

### 8. What is the difference between forEach and map?

Let's discuss the basic JavaScript interview question. Sometimes interviewer asks when we can use forEach and map and what are the differences between them.

Let's check out the difference between forEach and map.

![](https://miro.medium.com/v2/resize:fit:874/1*9gsKdSSV3UKtR7cE6XhbOA.png)


### 9. What is the difference between ng-content and ng-templateoutlet?

When we deal with multiple templates it is better to write reusable logic in the template itself. Having knowledge of these two terms can boost your chance to crack the Angular developer interviews.

![](https://miro.medium.com/v2/resize:fit:874/1*VTvdee-oaX6l2vX_HsLmUg.png)

> ng-content Example:

![](https://miro.medium.com/v2/resize:fit:831/1*i7959Ze_V9RVZNVJei5tIQ.png)

> ng-templateoutlet example:

![](https://miro.medium.com/v2/resize:fit:875/1*FHJjWsh4xOSCN4f-Zho-Ig.png)


### 10. What is the difference between forchild vs forroot?

This is a bit advanced topic but the basic difference is by using forchild and forroot we can change the visibility of instances of service in the application.
---

### Angular Interview Q&A: Day 12. NgRx Store, Dynamic Routing

### Question 1: What is `NgRx Store` and when should you use it?

**Answer:**

NgRx Store is a **Redux-style state management library** for Angular that uses Actions, Reducers, Selectors, and Effects to manage application state in a **predictable and scalable** way.

Use it when:

-   The app has complex state flows.
-   Multiple components share and mutate the same data.
-   You want time-travel debugging and immutability.

**Example:**
```javascript
// Action  
export const increment = createAction('[Counter] Increment');  
  
// Reducer  
export const counterReducer = createReducer(0,  
  on(increment, state => state + 1)  
);  
// Component  
store.dispatch(increment());
```
> _✅ Best for large-scale apps — avoid overusing in small apps due to boilerplate._

### Question 2: How do you handle dynamic routing in Angular?

**Answer:**

Dynamic routing allows you to create routes on the fly based on user data, roles, or API responses.

**Example:**
```javascript
this.router.config.push({  
  path: 'user/:id',  
  component: UserProfileComponent,  
});  
  
this.router.resetConfig(this.router.config);
```

> _✅ Also useful when building menu-based routes or role-based modules dynamically._

### Question 3: How do you integrate Angular with a third-party JavaScript library?

**Answer:**

There are three main ways:

1.  Install via npm (preferred if supported).
2.  Use `@types/lib` for typings.
3.  For legacy/global scripts, use `declare` and manually add to `angular.json`.

**Example (Google Maps API):**

declare const google: any;  
```javascript  
ngOnInit() {  
  const map = new google.maps.Map(document.getElementById('map'), {  
    center: { lat: 0, lng: 0 },  
    zoom: 4  
  });  
}
```
> _✅ Wrap in a service for clean architecture and reusability._

### Question 4: How do you create reusable form components in Angular?

**Answer:**

Reusable form components allow you to build consistent form patterns using `ControlValueAccessor`.

**Steps:**

1.  Implement `ControlValueAccessor`
2.  Register the component in `NG_VALUE_ACCESSOR`

**Example:**
```javascript
@Component({  
  selector: 'app-input',  
  template: `<input [value]="value" (input)="onChange($event.target.value)">`,  
  providers: [{  
    provide: NG_VALUE_ACCESSOR,  
    useExisting: forwardRef(() => InputComponent),  
    multi: true  
  }]  
})  
export class InputComponent implements ControlValueAccessor {  
  value: string = '';  
  onChange = (value: any) => {};  
  writeValue(val: any): void { this.value = val; }  
  registerOnChange(fn: any): void { this.onChange = fn; }  
}
```

### Question 5: What is the difference between `ViewContainerRef` and `TemplateRef`?

**Answer:**

-   `**TemplateRef**`: Represents an embedded Angular template (e.g., `<ng-template>`).
-   `**ViewContainerRef**`: Represents the container that can insert and remove views dynamically.

**Use Case:** Together, they allow rendering dynamic components or views.

**Example:**
```javascript
@ViewChild('tmpl', { read: TemplateRef }) template!: TemplateRef<any>;  
@ViewChild('vc', { read: ViewContainerRef }) vc!: ViewContainerRef;  
  
ngAfterViewInit() {  
  this.vc.createEmbeddedView(this.template);  
}
```

> _✅ Powerful for building custom modals, dynamic UIs, and lazy-loaded views._
---

# Advanced Angular Interview Questions 
## What kind of steps you will take to improve the Angular application?

-   Remove unnecessary library and code
-   Use trackBy in ngFor loops
-   Caching the static file to improve the performance
-   `ng-container` is a structural directive that doesn't create any additional DOM elements. `ng-container` is to provide a grouping mechanism for applying structural directives like `ngIf`, `ngFor`, and `ngSwitch` without introducing unnecessary HTML elements.
-   Compressed the image size in application
-   Implement lazy loading for modules. This helps in loading only the necessary parts of your application when they are needed, reducing the initial load time
-   Use pagination or infinite scrolling to improve the data load in the page.
-   Integrate [webpack-bundle-analyzer](https://www.npmjs.com/package/webpack-bundle-analyzer) to investigate the component size and third party library size
-   OnPush change detection strategy is also used for improving the Angular performance improvement. Angular doesn't need to traverse the entire component tree structure for detecting individual changes on properties. We can re render the component on demand in this strategy.

## **_How many way we can share data between component?_**

1.  **Input/Output Binding**: Parent components can pass data to child components through input properties (`@Input` decorator) and receive data from child components through output properties (`@Output` decorator).
2.  **ViewChild/ContentChild:** Parent components can access child components and their properties using `ViewChild` and `ContentChild` decorators.
3.  **Services**: Shared data can be managed and accessed using Angular services. Components can inject the same service instance and use it to share data.
4.  **State Management**: NgRx can be used for managing application state and sharing data between components using a centralized store.

## Is it possible to call an API in the constructor of an Angular component instead of using the ngOnInit lifecycle hook?

While it is technically possible to call an API from the Angular constructor, it's not considered a best practice. The constructor is invoked when the component class is initialized, before Angular has fully initialized certain features like dependency injection or input properties. This means that calling an API before these features are fully available may lead to unexpected behavior or errors.

## **What are some of the differences between a standard Angular component and a standalone component?**

-   Standard components must be included in an NgModule to be used within an Angular application. Standalone components do not require this and can be used independently without being included in an NgModule.
-   Standard components require imports for Angular or third-party functionality to be declared in the NgModule. For instance, *ngFor directive usage necessitates importing CommonModule from @angular/common in the NgModule. In contrast, standalone components can directly import dependencies within their own files.

## How to prevent cross-site scripting (XSS) in Angular

-   **Interpolation and Property Binding:** Angular's built-in mechanisms for data binding, such as interpolation (`{{ }}`) and property binding (`[ ]`), automatically sanitize user input, making it safe to render in the browser. Always use these mechanisms when rendering dynamic content to prevent XSS.
-   **Sanitize User Input:** If you're dealing with dynamic content that may contain HTML, CSS, or JavaScript, use Angular's built-in DomSanitizer service to sanitize the input before rendering it in the DOM.
```javascript
import { DomSanitizer } from '@angular/platform-browser';  
  
constructor(private sanitizer: DomSanitizer) {}  
  
// Sanitize user input  
sanitizedHtml = this.sanitizer.sanitize(SecurityContext.HTML, userInput);
```

-   **Angular Templates Safely:** Avoid using `innerHTML` or `outerHTML` to dynamically generate HTML content. Instead, utilize Angular's template syntax to safely render dynamic content.

## What are Host Binding and Host Listening in Angular?

In Angular, @HostBinding and @HostListener decorators are used to interact with the host element of a directive or component.

**@HostBinding:** The @HostBinding decorator is used to bind a property of the host element. It allows you to set a property on the host element based on a property of the directive or component.
```javascript
import { Directive, HostBinding } from '@angular/core';  
  
@Directive({  
 selector: '[appHighlight]'  
})  
export class HighlightDirective {  
  @HostBinding('style.backgroundColor')   
  backgroundColor: string = 'yellow';  
}
```

**@HostListener:** The @HostListener decorator is used to listen for events on the host element. It allows you to define a method that will be called when a specific event occurs on the host element
```javascript
import { Directive, HostListener } from '@angular/core';  
  
@Directive({  
 selector: '[appClickLogger]'  
})  
export class ClickLoggerDirective {  
  
 @HostListener('click', ['$event'])  
 onClick(event: Event): void {  
  console.log('Host element clicked!', event);  
 }  
  
}
```

## I was asked “You have one input field and, after submission, you receive a response with the length of the entered input. How would you implement this in Angular?”

This is a simple question, and I know you can finish it in a few minutes. However, the interview's intention is to understand how deeply you know Angular and what kind of steps you would take to complete this task.

When you face such kind of question try to cover as much as possible like Security, Error handing, Testing, State management, Form validation, API call, Interceptor.

Here is some basic ideas

-   **Basic Implementation**: Try to discuss Reactive Forms and Template-driven Forms. Its pros and cons. Finally choose one of them. I will go reactive form because of extensive validation, dynamic controls and better for testing.
-   **Security**: I am very much concern about security. I will use Dom Sanitizer to sanitize input to prevent cross-site scripting (XSS).
-   **Error Handling**: Angular provide `ErrorHandler`interface to handle the global error. I will use that to handle error in the Angular application. I will also use HttpClientInterceptor to intercept HTTP requests and handle errors returned by the server.
-   **Testing**: Testing ensures that your application functions correctly and meets the specified requirements. I will write unit testing and e2e testing using Karma and jasmine to make the application more stable.
-   **State Management**: I can manage state in componet level, service lever or global state like Ngrx. For this case, I will go with component level state access.
-   **API Call**: Angular provides HttpClient module that is used to send HTTP requests and receive responses from a server. Angular 2 and 4, they provided Http module from the Angular 5, they have made it HttpClient module. In here, I can easily manage error, even I can modified response date using Rxjs operator. For this problem, I can use both get and post call. But I will go post call because post is more secured.
-   **Interceptor**: I can use HTTP interceptors to intercept outgoing requests and incoming responses. For example I can use interceptor to add token in header.
-   **Logging service**: Log errors to a centralized logging service or platform for monitoring and debugging purposes.

There is no right wrong answer this type of question. This is the sample points that will help you to prepare yourself.

## Tell me about Angular Lifecycle Hooks

There is 90% chance to face this question. The fun fact is that from amateur to advanced developer everybody knows the answer. The important part is how you delivery the answer make a difference from amateur. I always try to connect with my previous work experience.

Here is my answer:

This is a important question. There are 8 life cycle hooks in Angular. I have heavily used ngOnInit and ngOnDestroy in my previous work environment. **ngOnInit** is called when component initialize. It is called once. Mostly, I used for variable initialize and API call. **ngOnDestroy** is called before detroying the component. I heavily used for unsubscribe the subscription to prevent the memory leak.

Several times I have used ngOnChanges, ngAfterContentInit**,** ngAfterViewInit in my career. **ngOnChanges** method is called once on component's creation and then every time changes are detected in one of the component's _input_ properties. It receives a [_SimpleChanges_](https://angular.io/api/core/SimpleChanges) object as a parameter. **ngAfterViewInit** is called after the component view and its child views has been initialized. **ngAfterContentInit** is called after components external content (or from parent ) has been initialized.

There are other hooks like **ngDoCheck, ngAfterContentChecked, ngAfterViewChecked,** I did not use them too much.

## What is Dependency Injection?

Whenever you have chance try to connect with design pattern. Try to add extra information in your answer that makes you are senior or experienced developer.

Here is my answer:

Dependency Injection (DI) is a design pattern. DI is heavily used in Angular. DI is a design pattern that aims to manage component dependencies by injecting them from external sources rather than creating them within the component itself. It is use to improved testability, make Components loose coupling.

By default, Angular's DI system creates singleton instances of services and shares them throughout the application. In AngularJs, function params are used for DI, From Angular 2, constructor param is used for DI.

## How much experience do you have with Angular?

I faced this question several times. I never answered this question like 7 years. I tried to make it informative to get the interviewer attention.

Here is my answer:

I started to work with Angular from Angular 2. Its from 2017. Angular 2 was released in September 2016. After that Angular team started to release new version in every 6 months. In Angular 5, they introduced httpClient. Angular 8 they introduce Ivy engine to make bundle size small. Ivy engine make it default in Angular 9. Then Angular 15, they introduce standalone component. Angular 17, They make it default. Angular 17, they have introduced **Built-in control flow, Deferrable views, Angular Signals.**

## In a scenario where there are different design requirements for European and USA clients, with 70% of the design and components are being common. European and USA have separated server. They are deploying separately. How would you handle this situation?

We can solve it different way. We can use if else to handle the scenario for USA and European.

My suggestions are to use separate env files. For USA, we will have _environment.usa.ts_ for European, we will have _environment.european.ts ._ When we build the angular application for production we will select the environment name during build time.
```shell
ng build --prod --configuration=usa
```
or
```shell
ng build --prod --configuration=european
```
We will deploy the build files to corresponding server.
---
### Angular Interview Questions

What is the Difference Between 'change' vs 'ngModelChange'? 

## Let's understand the basics before moving towards the differences

_“_ `_(change)_` _is bound to the HTML onchange event.”_

In simple terms, this event will be triggered for any changes that occur to the element.

_“_`_(ngModelChange)_` _is bound to the ngmodel which we added to the element.”_

In simple terms, this event will be triggered for any changes that occur to the ngmodel variable.

Source: [https://www.w3schools.com/jsref/event_onchange.asp](https://www.w3schools.com/jsref/event_onchange.asp)

## **Let's check out an example to understand this better**
```html
change : <input type="text" [(ngModel)]="val" (change)="onChange($event.target.value)">
ngModelChange: <input type="text" [(ngModel)]="val" (ngModelChange)="ngModelChange($event)"><p>Value of the Field - {{ val }}</p>
```

**And the component will look like this,**
```javascript
val;  
onChange(value) {  
    console.log('change called');  
}
ngModelChange(value) {  
    console.log('ngmodel change called');  
}
```

Here, when the user changes the value in the input tag, the onChange method will be called after `blur event`.

While ngModelChange will be called before `blur event`.
---

# Angular Interview Questions. All that you need to prepare for a

### What is Angular?

**Answer:** Angular is an open-source, front-end web development framework based on TypeScript developed and supported by Google.

### What is TypeScript?

**Answer:** Typescript is a language based on javascript. Angular is based on the TypeScript language and HTML. HTML is used for the template, and TypeScript (a superset of JavaScript) is used for components.

### Why prioritize TypeScript over JavaScript in Angular?

**Answer:** The typescript is created to overcome the Javascript shortcomings like typecasting of variables, classes, decorators, variable scope, and many more features and functions.

TypeScript is really powerful. To discover some of its powers, here is what I recommend:

### Why were client-side frameworks like Angular introduced?

**Answer:** Before, web developers used to use plain Javascript combined with jQuery to develop dynamic websites. The problem with this approach is that as long as the app grows, its code will become more tedious and complex to maintain. Therefore, the need to create something to facilitate and helps maintain, at the same time, a dynamic website code.

### How does an Angular application work?

**Answer:** the entry point is the main.ts file that is configured in the `angular.json`. From then on, the AppModule is bootstrapped. The module will then render the AppComponent by using `index.html` file.

### Can you describe some of the advantages of using Angular?

**Answer:** Angular helps create fast, dynamic, and scalable web applications with ease, using components and modules with a hierarchical dependency injection structure. It facilitates RESTful services and client-server communication with its core modules. Another advantage is that it provides the testing system (with Jasmine and Karma) and its environment already set.

To check how it is quick and easy to create an Angular app, I recommend checking this article that will take you through only 2 steps to create a whole Angular app from A to Z:


### What are Angular major features?

-   Component-based architecture — applications are written as a set of independent components. Thus, the application will be built with a set of components (like puzzles)
-   Every puzzle can be created, tested, integrated using Angular CLI independently.
-   Great support for complex animations without writing much code by using Angular animation.
-   Thanks to the lazy loading feature, Angular supports automatic code-splitting. Hence only the code required to render a particular view is loaded.
-   Cross-platform application development. It can be used for all platforms, even for mobile apps.

### What Is the Single Page Application? How Is It Different From Traditional Web Technology?

**Answer:** Angular allows us to create a SPA. In a Single Page Application (SPA), only the home page (index.html) is maintained throughout even though the URL keeps changing. It is faster and easier to implement when compared with traditional web technology. In traditional technology, every time a user requests, the request is passed on to the server. This takes more time.

### What are directives in Angular? Describe the types of directives in Angular?

**Answer:** Directives are one of the core features of Angular. They allow an Angular developer to write new, application-specific HTML syntax. In fact, directives are functions executed by the Angular compiler when the same finds them in the DOM. Directives are of three types:

-   Attribute Directives
-   Component Directives
-   Structural Directives

### [What is a bootstrapping module?](https://github.com/sudheerj/angular-interview-questions#what-is-a-bootstrapping-module)

**Answer:** The root module that you bootstrap to launch the application is called a bootstrapping module. Every Angular application has a bootstrapping module. It is also called the AppModule. The bootstrapping module is mentioned in the AppModule class.
```html
<iframe src="https://levelup.gitconnected.com/media/f99778f9307916883502b4422c943bc2" allowfullscreen="" frameborder="0" height="212" width="680" title="AppModule" class="eo n hk dz bg" scrolling="no"></iframe>
```

### What is the difference between an Annotation and a Decorator in Angular?

Annotations in angular are “only” metadata set of the class using the reflect Metadata library. They are used to create an “annotation” array. On the other hand, decorators are the design patterns used for separating decoration or modification of a class without actually altering the source code.

### What are templates in Angular?

Templates are the HTML code rendered in the index.html file's body. The HTML code is a combination of data coming from the controller or the component and the model to provide a dynamic view to the user finally.

Note that the difference between the traditional HTML code and the one used in an Angular app is that we can use some special elements and features (such as `*ngIf`, `ng-template`, `*ngFor`…) that are Angular specific and can't be used in a regular HTML file outside an Angular app.

### Explain data binding in Angular? In Angular, what is string interpolation? What is interpolation?

In Angular, data binding is one of the most powerful and important features that allow you to define the communication between the component and DOM(Document Object Model).

This simplifies the communication between the template (HTML) and the controller (component's class).

In Angular, there are four forms of data-binding:

1.  String Interpolation with: {{ variable }}
```html
<li>Name: {{ user.name }}</li>  
<li>Address: {{ user.address }}</li>
```
1.  Property Binding with [property]=”value”
```html
<input type="email" [value]="user.email">
```
1.  Event Binding with (click)=”functionName($event)”
```html
<button (click)="logout()"></button>
```
1.  Two-Way Data Binding with [(ngModel)]=”variablename”
```html
<input type="email" [(ngModel)]="user.email">
```
Note that the `[()]` is called the banana box. (you may get the same question by using this well-known keyword ;))

### Explain Components, Modules, and Services in Angular?

**Components:** Components are the most basic UI building block of an Angular app, which formed a tree of Angular components. These components are a subset of directives. Unlike directives, components always have a template, and only one component can be instantiated per element in a template.

**Modules:** Modules are logical boundaries in your application, and the application is divided into separate modules to separate your application's functionalities.

**Services:** A service is used when a common functionality needs to be provided to various modules. Services allow for greater separation of concerns for your application and better modularity by allowing you to extract common functionality out of components.

### What types of compilations are there in Angular?

**Answer:** Two types of compilations — AOT (Ahead-of-Time) and JIT (Just-in-Time).

With JIT, the compilation happens during run-time in the browser. It is the default way used by Angular. The commands used for JIT compilation are –
```shell
ng build ng serve
```
In the AOT compilation, the compiler compiles the code during the build itself. The CLI command for AOT compilation is -
```shell
ng build --aot ng server –aot
```

AOT is more suitable for the production environment, whereas JIT is much suited for local development.

### What are lifecycle hooks in Angular? Explain a few lifecycle hooks.

**Answer:** Angular components enter its lifecycle from the time it is created to the time it is destroyed. Angular hooks provide ways to tap into these phases and trigger changes at specific phases in a lifecycle.

**ngOnChanges( ):** This method is called whenever one or more input properties of the component changes. The hook receives a SimpleChanges object containing the previous and current values of the property.

**ngOnInit( ):** This hook gets called once, after the ngOnChanges hook.

It initializes the component and sets the input properties of the component.

**ngDoCheck( ):** It gets called after ngOnChanges and ngOnInit and is used to detect and act on changes that cannot be detected by Angular.

We can implement our change detection algorithm in this hook.

**ngAfterContentInit( ):** It gets called after the first ngDoCheck hook. This hook responds after the content gets projected inside the component.

**ngAfterContentChecked( ):** It gets called after ngAfterContentInit and every subsequent ngDoCheck. It responds after the projected content is checked.

**ngAfterViewInit( )**: It responds after a component's view, or a child component's view is initialized.

**ngAfterViewChecked( ):** It gets called after ngAfterViewInit, and it responds after the component's view, or the child component's view is checked.

**ngOnDestroy( ):** It gets called just before Angular destroys the component. This hook can be used to clean up the code and detach event handlers.

### What are pipes?

**Answer:** Pipe (|) is used to transform input data into the desired format. For example,
```html
`<p>Price is {{ price | currency }}</p>`
```
With params:
```html
<p>Price is {{ price | currency : “USD$” : 0.00 }}</p>
```
### What is Angular Router? What Is a Wildcard Route?

**Answer:** Angular Router is a mechanism in which navigation happens from one view to the next as users perform application tasks. It borrows the concepts or model of the browser's application navigation.

Wildcard route has a path that consists of two asterisks (**) that can match any URL. It is helpful when a URL doesn't match any of the predefined routes. Instead of throwing errors, we can use a wildcard route and defining a component for the same.

### Is the Routing Module Mandatory for an Application?

**Answer:** No, the routing module can be totally skipped if there are simple configurations.

### Explain the difference between template drivenForms and reactive forms in Angular.

**Template Driven Forms:** These are model-driven forms where you write the logic, validations, controls, etc., in the template part of the code using directives. They are suitable for simple scenarios and uses two-way binding with [(ngModel)] syntax.

**Reactive Form:** is a model-driven approach for creating forms in a reactive style(form inputs changes over time). These are built around observable streams, where form inputs and values are provided as streams of input values.

Again if you need a mental picture to help you have a clear idea about the difference between the two forms' types:[

### What is Angular CLI? How Do You Use It?

Angular CLI(Command Line Interface) is a command-line interface to scaffold and build angular apps. You need to install using the npm command below:

npm install @angular/cli@latest

Below I listed a few commands, which are so useful when creating angular projects

Creating a New Project:

`ng new`

Generating Components, Directives & Services:

`ng generate/g`

The different types of commands would be:

-   ng generate class my-new-class: add a class to your application
-   ng generate component my-new-component: add a component to your application
-   ng generate directive my-new-directive: add a directive to your application
-   ng generate enum my-new-enum: add an enum to your application
-   ng generate module my-new-module: add a module to your application
-   ng generate pipe my-new-pipe: add a pipe to your application
-   ng generate service my-new-service: add a service to your application

Running the Project: ng serve

### What's the latest version of Angular? What Are the New Features in It?

At the time I'm writing this article, Angular has reached its 11th version. This question is usually asked for someone who has some experience in Angular or is an Angular expert to show that you are keeping up with news and technologies.

To learn more about new features, here is an article the sums up the most important features that come out with the latest version in Angular:

### What is AOT compilation?

-   **AOT(Ahead-of-Time) compilation:** The application compiles during the build time.

### What are the **Advantages of AOT compilation?**

-   **Fast Rendering:** The browser loads the executable code and renders it immediately as the application is compiled before running inside the browser.
-   **Fewer Ajax Requests:** The compiler sends the external HTML and CSS files along with the application, eliminating AJAX requests for those source files.
-   **Minimizing Errors:** Easy to detect and handle errors during the building phase.
-   **Better Security:** Before an application runs inside the browser, the AOT compiler adds HTML and templates into the JS files, so there are no extra HTML files to be read, thus providing better security for the application.

### Why do we need a compilation process?

The browser can only read and interpret 3 things: CSS, HTML, and Javascript. That's why it's important to generate the js and HTML files that can be interpreted by the browser.

### What Does the Representation [()] Mean?

**Answer:** This is a representation for ngModel used for two-way data binding. It is written as [(ngModel)] = “propertyvalue”.

It's also called bananabox = two way data-binding.

### What Do You Know About the NPM Package?

**Answer:** The components, framework, and CLI used by Angular applications are packaged as npm packages. Npm packages can be downloaded using the npm CLI client. To be able to use npm, you need to install NodeJs.

### How Are Animations Done in Angular?

**Answer:** To use the animation module, it has to be enabled. For this, the BrowserAnimationModule has to be imported.
```javascript
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; // After this, import the required animation functions into the // component files. Example:   
import { state, animate, transition, // ... } from '@angular/animations';
```
Next, add the animation metadata property within the @Component() decorator in the component file.
```javascript
@Component({ selector: 'app-root', templateUrl: 'app.component.html', animations: [ // animation triggers go here ] })
```

### What Is Package.json? What's the difference between package.json vs. package-lock.json?

**Answer:** With `package.json` file, it becomes easy to manage the project dependencies. We can mention details like the version, language, etc.… in `package.json`. For example, if bootstrap is used in our project, we can mention the ng-bootstrap package and its version in `package.json`.

If you are not familiar with `package.json` I really recommend this article that will help you build a mental picture of what is `package.json` file in dept and what's the difference between `package-lock.json` and some tips based on my experience.


### What is the difference between constructor and ngOnInit?

TypeScript classes have a default method called a constructor, which is normally used for construction purposes. It has the same purpose as a standard class in Java, such as building an object and initializing it. The constructor is also used to inject the dependencies we need in the component.

On the other hand, the ngOnInit method is specific to Angular, especially used to define Angular bindings. The constructor is always called before ngOninit.

. In order to use ngOnInit, you need to implement the OnInit interface as below:
```html
<iframe src="https://levelup.gitconnected.com/media/ab3ee33af0f05c2b9ae6258913d429be" allowfullscreen="" frameborder="0" height="344" width="680" title="AppComponent" class="eo n hk dz bg" scrolling="no"></iframe>
```
### What is zone in Angular?

A Zone is an execution context that persists across async tasks. Angular relies on zone.js to run Angular's change detection processes when native JavaScript operations raise events.

### What is the purpose of the async pipe?

**Answer:** Async pipe subscribes to a promise or an observable and returns the latest value. If a new value is emitted, the pipe marks the component that needs to be checked for any changes.

`<code>observable|async</code>`

### Explain How You Can Chain Pipes?

**Answer:** We can add any number of filters using pipes -

`<p>Average is {{ average | uppercase | number}}</p>`

### Is It Possible to Create a Custom Pipe? If yes, How?

**Answer:** Yes, we can create custom pipes.

-   First, we need to import the @Pipe decorator from the core Angular library.
-   Pipe is a class that is decorated with the above metadata (@Pipe({name: 'myCustomPipe'}))
-   The next step is to define the transformation. For this, the pipe class should implement the method transform() of the PipeTransform class.
-   Specify the pipe name in the template to call it.

`<p>Size: {{number | myCustomPipe: 'Error'}}</p>`

### How would you create a service within Angular?

Example of service:
```html
<iframe src="https://levelup.gitconnected.com/media/88c37d7502417d10e17d984d952bfc84" allowfullscreen="" frameborder="0" height="366" width="680" title="Service example" class="eo n hk dz bg" scrolling="no"></iframe>
```
As we saw before, a service can be generated with the CLI commands.

If you have created the service manually, you'll need to provide the service in the Module that will use it and inject it in the constructor of the component that will use it.

### What is HttpClient and its benefits?

Most of the Front-end applications communicate with backend services over HTTP protocol using either XMLHttpRequest interface or the fetch() API. Angular provides a simplified client HTTP API known as HttpClient, based on top of the XMLHttpRequest interface. This client can be imported from the`@angular/common/http` package.
```javascript
import { HttpClientModule } from '@angular/common/http';
```
The major advantages of HttpClient can be listed as below,

1.  Contains testability features
2.  Provides typed request and response objects
3.  Intercept request and response
4.  Supports Observalbe APIs
5.  Supports streamlined error handling

### What is **Dependency Injection (DI)**

Dependency injection (DI) is an important application design pattern in which a class asks for dependencies from external sources rather than creating them themselves.

Angular comes with its own dependency injection framework for resolving dependencies. This is an important core concept of Angular. I recommend reading the article below to have a clear idea about dependency injection.

### What is codelyzer?

Codelyzer provides a set of tslint rules for static code analysis of Angular TypeScript projects. To analyze an Angular application, you only need to run the following commands:
```shell
ng new codelyzer  
ng lint
```
### What are UI libraries you have used with Angular?

Tell only the UI libraries that you used:

Example:

-   Bootstrap
-   PrimeNG
-   Materials …etc

### Angular Language Service

The Angular Language Service is a way to get completions, errors, hints, and navigation inside your Angular templates, whether they are external in an HTML file or embedded in annotations/decorators in a string. It has the ability to autodetect that you are opening an Angular file, reads your `tsconfig.json` file finds all the templates you have in your application and then provides all the language services.

If you haven't yet used Angular CLI, I recommend you to discover it. It one of the must-know things. Here is a quick article to have a mental picture of Angular CLI:


### What's RxJs?

RxJS is a library for composing asynchronous and callback-based code in a functional, reactive style using Observables. Many APIs such as HttpClient produce and consume RxJS Observables and also uses operators for processing observables.

The RxJS library also provides below utility functions for creating and working with observables.

1.  Converting existing code for async operations into observables
2.  Iterating through the values in a stream
3.  Mapping values to different types
4.  Filtering streams
5.  Composing multiple streams

### What do you use for Unit testing in an Angular app?

-   Jasmine (for writing tests)
-   Karma or/ Jest (for running tests)

If you already use them, otherwise, don't mention them as you can get a question about what's the difference between Karma and Jest, for example, Or what do you prefer using Karama or Jest.

If you want me to cover the difference between Karam and Jest and which one is better, let me know in the comments section.

### What do you use for E2E testing in an Angular app?


### What's the difference between stub and Mock?

**Stubs** provide canned answers to calls made during the test. _They_ are a very simplified object or data structure designed specifically for the test scenario. These can be constructed at the beginning of the test or per test.

**Mocks** are pre-programmed with expectations which form a specification of the calls they are expected to receive. Mock objects are class instances that mimic an existing class to provide the same method interface and return specific values when a method call occurs.

### What's an Observable?

An Observable is a unique Object similar to a Promise that can help manage async code. Observables are not part of the JavaScript language, so we need to rely on a popular Observable library called RxJS. The observables are created using a new keyword.
```javascript
import { Observable } from 'rxjs';  
  
const observable = new Observable(observer => {  
  setTimeout(() => {  
    observer.next('Hello from a Observable!');  
  }, 2000);  
});
```
### What's the difference between observables and promises

**Promise:**

-   Execute immediately on creation
-   Provide only once
-   Push errors to the child promises
-   Uses only .then() clause

**Observable:**

-   Declarative: Computation does not start until subscription so that they can be run whenever you need the result
-   Provide multiple values over time
-   Subscribe method is used for error handling, which makes centralized and predictable error handling
-   Provides chaining and subscription to handle complex applications

### What is metadata? How Is Metadata Represented in Angular?

**Answer:** Metadata is used to decorate a class so that it can configure the expected behavior of the class. The metadata is represented by decorators.

Metadata is represented using decorators like class decorators, property decorators, method decorators.

Examples of decorators in Angular

-   Class decorators: @Component and @NgModule
-   Property decorators: @Input and @Output
-   Method decorators: @HostListener
-   Parameter decorators: @Inject, Optional

### What Are Class Decorators in Angular?

**Answer:** The class decorator contains the metadata of the suitable class type. It appears just before the class definition and declares the class to be of a certain type. Some class decorators are:

-   @Component
-   @NgModule
-   @Pipe
-   @Directive
-   @Injectable.
---

### 31. Explain different guards supported in Angular.

This is one of the most common questions asked in the Angular application.

There are five main guards in angular. which guards the access of routes.

-   `CanActivate` : will be called before going to the route: _can be used to prevent routing to a specific path_
-   `CanActivateChild` : will be called before going to the child component: _can be used to prevent the loading of child path_
-   `CanDeactivate` : will be called before destroying the component: _can be used to handle the browser events_
-   `CanLoad` : will be called before loading the module: _can be used to prevent the loading of the module_
-   `Resolve` : will be called before loading component: _can be used to prefetch data before loading component_

https://stackblitz.com/edit/route-guard


## Angular Authentication: Using Route Guards

### 32. What is the best way too lazy load the component?

Lazy loading the modules is one of the best practices when we want to reduce the bundle sizes and avoid loading all modules together.

But What about the lazy loading component? It means we load modules but don't load components until we need them. It basically creates dynamic components as required and destroying right after use.

https://stackblitz.com/edit/ivy-lazy-loading-component

## Lazy load components in Angular

### Lazy load Angular components with Ivy and Angular 9

### 33. What is the way we can display the app version in Angular?

When we deal with a lot of deployment it is best to display the app version which helps to communicate among the team with the changes.

It can be achieved by following these steps.

1.  open `/tsconfig.json` make resolveJsonModule as true.
```json
"compilerOptions": {  
      "resolveJsonModule": true  
```
Then in the component we can use version.
```javascript
import { version } from '../../package.json';  
     
export class AppComponent {  
    public version: string = version;  
}
```

It's also possible to do step 2 in your environment.ts file, making the version info accessible from there.

### 34. What are the generators in ES6?

One of the best question to check your ES6 skills. What is practical use if Generators?

Generator can be used to pause and resume multiple times.

The major use of this to handle the find scenarios where user hit find button again and again and if multiple search results available, user can move to different records one by one.

By default, generators are asynchronous.

https://stackblitz.com/edit/es6-generators

### 35. Explain the Error mechanism in your application.

All the application have their global error mechanism to handle the errors and log them on Splunk or new relic. Most of the team follow the global error mechanism which logs if any issues come for tracking purposes and redirect the users to specific routes.

**_Let's checkout practical code to understand this concept better._**

https://stackblitz.com/edit/global-error-handler

### 36. What is bootstrapping in angular?

Most of the time when this word comes to mind we think like a bootstrap library but no Bootstrapping is a technique of initializing or loading our Angular application.

Sometimes interviewers ask How angular application loads or explain angular application loading from the beginning. Let's check the answer then.

**The Angular takes the following steps to load our first view.**

1.  Main.ts the application entry point
2.  Index.html loads
3.  Angular, Third-party libraries & Application loads
4.  App Module
5.  App Component
6.  app-root will add the component HTML inside

### 37. What are Angular elements? why we use it?

As Angular grows it comes with really good features. If you heard about microservices architecture to make applications more robust Angular is doing exactly the same.

With Angular Elements, we can plug and play angular applications to the other frontend frameworks.


### 38. What is the difference between the arrow function and regular functions?

I have seen the interviewer started asking basic JavaScript questions to test the knowledge of candidates.

**Candidate:** I do know arrow functions have simpler syntax while regular functions have complex syntax.

The interviewer mostly understand how much deep water is :)

**Answer:**

**_1. Argument Binding_** :

Arrow functions do not support an arguments binding while regular functions do have the support of argument binding ( However we can add arguments in arrow functions using spread operator)

**_2. This keyword:_**

Arrow functions do not support this keyword while regular function has its own keyword support. This feature makes regular functions usage towards the factory method for object creation.

**_3. New keyword:_**

Regular functions created using function declarations are construable and can be called using the new keyword. However, the arrow functions are only callable and not construable, i.e arrow functions can never be used as constructor functions.

**_4. Duplicate Parameters:_**

Regular functions allowed duplicate parameters while Arrow functions don't allow duplicate parameters.

### 39. What is the difference between Functional vs Object Oriented Programming language? Which one you prefer and why?

I have seen a couple of interviewers started asking this kind of question to access candidate knowledge about the programming language they are currently working on.

![](https://miro.medium.com/v2/resize:fit:875/1*ZWb8LXXVXhS-TckktEAaQQ.png)
geeksforgeeks

The Advantages and Features of Functional programmings are:

-   **Pure functions**
-   **Function composition**
-   **Avoid shared state**
-   **Avoid mutating state**
-   **Provide Higher-Order Functions**

### 40. What is the difference between JavaScript and TypeScript?

Candidate: TypeScript is a superset of JavaScript.

I have seen most of the candidate's answers plain as they don't know many advantages of why angular uses the typescript.

You can find the best explanation here.

[https://www.geeksforgeeks.org/difference-between-typescript-and-javascript/#:~:text=TypeScript%20is%20known%20as%20Object,JavaScript%20is%20a%20scripting%20language.&text=TypeScript%20gives%20support%20for%20modules,JavaScript%20does%20not%20have%20Interface](https://www.geeksforgeeks.org/difference-between-typescript-and-javascript/#:~:text=TypeScript%20is%20known%20as%20Object,JavaScript%20is%20a%20scripting%20language.&text=TypeScript%20gives%20support%20for%20modules,JavaScript%20does%20not%20have%20Interface).

**Advantages of using TypeScript over JavaScript**

-   TypeScript always give compilation errors at run time due to this it is easier to fix the issue before deployments
-   TypeScript supports static typing which allows for checking type correctness at compile time.
---

### Question 1: What are standalone pipes in Angular, and how are they different?

**Answer:**

**Standalone pipes** (introduced in Angular 15+) can be used without declaring them in an NgModule. This simplifies usage and promotes modularity.

**Example:**
```javascript
@Pipe({  
  name: 'capitalize',  
  standalone: true  
})  
export class CapitalizePipe implements PipeTransform {  
  transform(value: string): string {  
    return value[0].toUpperCase() + value.slice(1);  
  }  
}
```
**Usage:**
```html
<p>{{ 'angular' | capitalize }}</p>
```

> _✅ No need to import into a shared module — just import directly in the component._

### Question 2: What is the new Control Flow syntax in Angular (v17+)?

**Answer:**

Angular v17 introduced a **React-like control flow syntax** using:

-   `@if` / `@else`
-   `@for`

These replace `*ngIf` and `*ngFor` for better performance and readability.

**Example:**
```html
@for (item of items; track item.id) {  
  <div>{{ item.name }}</div>  
} @empty {  
  <p>No items found</p>  
}
```

> _✅ Faster and cleaner syntax, especially when nesting conditions or loops._

### Question 3: How do you trigger animations manually in Angular?

**Answer:**

Angular's animation system lets you control state-based transitions or trigger animations programmatically via `AnimationBuilder`.

**Example (triggering manually):**
```javascript
import { AnimationBuilder, style, animate } from '@angular/animations';  
  
constructor(private builder: AnimationBuilder, private el: ElementRef) {}  
ngOnInit() {  
  const animation = this.builder.build([  
    style({ opacity: 0 }),  
    animate('500ms', style({ opacity: 1 }))  
  ]);  
  const player = animation.create(this.el.nativeElement);  
  player.play();  
}
```
### Question 4: What are Angular Schematics and how do they work?

**Answer:**

**Schematics** are code generation tools built into the Angular CLI. They automate repetitive tasks like generating components, services, or even custom libraries.

**Example:**
```shell
ng generate component my-component
```
You can create **custom schematics** to standardize project structure across teams.

> _✅ Use schematics to enforce coding standards and automate boilerplate code._

### Question 5: What are best practices for writing unit tests in Angular?

**Answer:**

Top unit testing practices:

-   Use `TestBed` to configure the testing module.
-   Use **spies** (`spyOn`) for mocking dependencies.
-   Avoid testing Angular internals.
-   Prefer testing **public APIs** and expected behavior.
-   Keep tests **isolated** and **fast**.

**Example (with a spy):**
```javascript
it('should call service method', () => {  
  const spy = spyOn(service, 'getData').and.returnValue(of(['item']));  
  component.ngOnInit();  
  expect(spy).toHaveBeenCalled();  
});
```

> _✅ Use_ `_HttpTestingController_` _to mock HTTP requests in services._

💡 That wraps up **Day 10** of the Angular Interview Q&A series! You're now equipped with the latest and most advanced Angular features — perfect for real-world dev and interviews.
---

# Comprehensive Guide to Angular Interview Prep

### What It Is and Why It Matters

Angular's architecture is the backbone of any app you build. It's a component-based framework where everything — components, modules, services, directives, and pipes — works together like a well-oiled machine. Components handle the UI, modules organize your code, services manage logic, directives add behavior, and pipes transform data. For an SDE2 role, you need to know how these pieces fit together to create scalable apps.

### Real-Life Example

A few years back, I worked on a CRM tool for a mid-sized company. The app had a dashboard, customer profiles, and task management. We used Angular's architecture to keep things modular:

-   **Components**: A DashboardComponent displayed stats, a ProfileComponent showed customer details, and a TaskListComponent handled tasks.
-   **Modules**: We created a DashboardModule to group related features, keeping the codebase clean.
-   **Services**: A CustomerService fetched data from the backend, shared across components.
-   **Directives**: A custom HighlightDirective added hover effects to task cards.
-   **Pipes**: A CurrencyPipe formatted prices dynamically.

Here's a simplified version of the HighlightDirective:

```javascript
import { Directive, ElementRef, HostListener } from '@angular/core';  
  
@Directive({  
  selector: '[appHighlight]'  
})  
export class HighlightDirective {  
  constructor(private el: ElementRef) {}  
  
  @HostListener('mouseenter') onMouseEnter() {  
    this.el.nativeElement.style.backgroundColor = '#e0f7fa';  
  }  
  
  @HostListener('mouseleave') onMouseLeave() {  
    this.el.nativeElement.style.backgroundColor = '';  
  }  
}
```
**Outcome**: The modular structure made it easy to add new features (like a reporting module) without breaking existing code. The app scaled to handle 10,000+ users smoothly.

**Common Pitfall**: Overloading components with business logic. I once stuffed API calls into a component, making it a nightmare to test. Always move logic to services for reusability and clarity.

### Interview Questions

1.  **What is the role of NgModule in Angular?**  
    _Hint_: NgModule organizes components, services, and other dependencies into cohesive blocks. It's like a container for a feature set.
2.  **How do components communicate in Angular?**  
    _Hint_: Use @Input, @Output, or services for data sharing. Explain parent-child vs. unrelated component communication.
3.  **What's the difference between a structural and attribute directive?**  
    _Hint_: Structural directives (e.g., *ngIf) modify DOM layout; attribute directives (e.g., ngClass) change appearance or behavior.
4.  **How would you lazy-load a component?**  
    _Hint_: Lazy loading is typically done at the module level, but discuss dynamic component loading with ComponentFactoryResolver for advanced cases.
5.  **Why use pipes instead of methods for data transformation?**  
    _Hint_: Pipes are memoized and optimized for change detection, improving performance over method calls.
6.  **Explain the lifecycle hooks of a component.**  
    _Hint_: Cover ngOnInit, ngOnChanges, ngOnDestroy, etc., with their use cases (e.g., ngOnInit for initialization).

### Pro Tip

Break your app into feature modules early on. It's tempting to dump everything into AppModule, but trust me — future you will thank you when debugging a 50-component app.

## Dependency Injection

### What It Is and Why It Matters

Dependency Injection (DI) is Angular's way of providing dependencies (like services) to components or other services without hardcoding them. It promotes loose coupling, making your code testable and maintainable. For SDE2 roles, understanding DI's internals — like providers and injectors — is key.

### Real-Life Example

In a healthcare app, we needed to fetch patient data from multiple APIs. We created a PatientService to handle API calls:
```javascript
import { Injectable } from '@angular/core';  
import { HttpClient } from '@angular/common/http';  
  
@Injectable({  
  providedIn: 'root'  
})  
export class PatientService {  
  constructor(private http: HttpClient) {}  
  
  getPatient(id: string) {  
    return this.http.get(`/api/patients/${id}`);  
  }  
}
```
In a PatientProfileComponent, we injected it:
```javascript
import { Component } from '@angular/core';  
import { PatientService } from './patient.service';  
  
@Component({  
  selector: 'app-patient-profile',  
  template: `<div>{{ patient | json }}</div>`  
})  
export class PatientProfileComponent {  
  patient: any;  
  
  constructor(private patientService: PatientService) {  
    this.patientService.getPatient('123').subscribe(data => {  
      this.patient = data;  
    });  
  }  
}
```
**Outcome**: DI let us swap PatientService with a mock version for testing, saving us from hitting real APIs during development. When the API changed, we updated only the service, not every component.

**Common Pitfall**: Misusing providedIn: 'root'. I once made every service root-provided, causing unnecessary instantiation. Use feature module providers for scoped services to save memory.

### Interview Questions

1.  **What is dependency injection in Angular?**  
    _Hint_: DI allows Angular to inject dependencies into components/services, managed by injectors.
2.  **What's the difference between providing a service in 'root' vs. a module?**  
    _Hint_: Root creates a singleton; module scopes the service to that module's injector.
3.  **How would you create a custom injector?**  
    _Hint_: Use Injector.create() for dynamic dependency resolution, rare but useful in advanced scenarios.
4.  **What happens if Angular can't resolve a dependency?**  
    _Hint_: It throws a NullInjectorError. Discuss fallback tokens like Optional().
5.  **Explain hierarchical injectors.**  
    _Hint_: Angular creates an injector tree; child injectors inherit from parents unless overridden.

### Pro Tip

Always declare services as @Injectable(). I skipped this once, thinking it was optional, and Angular threw cryptic errors. Save yourself the headache.

## Routing and Navigation

### What It Is and Why It Matters

Angular's router lets users navigate between views (components) without full page reloads. It supports lazy loading, guards, and resolvers, making it essential for building SPAs. SDE2 candidates need to master routing for complex apps.

### Real-Life Example

For an e-commerce platform, we set up routing for home, product, and checkout pages:
```javascript
import { NgModule } from '@angular/core';  
import { RouterModule, Routes } from '@angular/router';  
import { HomeComponent } from './home.component';  
import { ProductComponent } from './product.component';  
import { CheckoutComponent } from './checkout.component';  
  
const routes: Routes = [  
  { path: '', component: HomeComponent },  
  { path: 'product/:id', component: ProductComponent },  
  { path: 'checkout', component: CheckoutComponent, canActivate: [AuthGuard] }  
];  
  
@NgModule({  
  imports: [RouterModule.forRoot(routes)],  
  exports: [RouterModule]  
})  
export class AppRoutingModule {}
```
We used a guard to protect the checkout page:
```javascript
import { Injectable } from '@angular/core';  
import { CanActivate, Router } from '@angular/router';  
import { AuthService } from './auth.service';  
  
@Injectable({  
  providedIn: 'root'  
})  
export class AuthGuard implements CanActivate {  
  constructor(private authService: AuthService, private router: Router) {}  
  
  canActivate(): boolean {  
    if (this.authService.isLoggedIn()) {  
      return true;  
    }  
    this.router.navigate(['/login']);  
    return false;  
  }  
}
```
**Outcome**: Users navigated seamlessly, and lazy loading the product module cut initial load time by 30%. The guard ensured only logged-in users accessed checkout.

**Common Pitfall**: Overcomplicating routes with nested paths. I once had a /products/category/subcategory/item mess — keep routes flat and use params for clarity.

### Interview Questions

1.  **How does Angular's router work?**  
    _Hint_: It maps URLs to components using Routes configuration and updates the view via RouterOutlet.
2.  **What are route guards?**  
    _Hint_: Guards like CanActivate control navigation based on conditions (e.g., authentication).
3.  **Explain lazy loading in Angular.**  
    _Hint_: Load modules on demand using loadChildren to improve performance.
4.  **What's a resolver, and when would you use it?**  
    _Hint_: Resolvers prefetch data before rendering a route, useful for data-heavy components.
5.  **How do you handle 404 routes?**  
    _Hint_: Use a wildcard path (path: '**') to catch unmatched routes.

### Pro Tip

Always test your guards and resolvers thoroughly. I once deployed a guard that redirected infinitely — yep, not my proudest moment.

## State Management

### What It Is and Why It Matters

State management handles data shared across components — like user sessions or app settings. Angular offers tools like NgRx for complex apps and Signals for lightweight reactivity. SDE2 roles often involve designing scalable state solutions.

### Real-Life Example

In a task management app, we used NgRx to manage tasks:
```javascript
// task.actions.ts  
import { createAction, props } from '@ngrx/store';  
  
export const addTask = createAction('[Task] Add', props<{ task: string }>());  
export const removeTask = createAction('[Task] Remove', props<{ id: number }>());  
  
// task.reducer.ts  
import { createReducer, on } from '@ngrx/store';  
import * as TaskActions from './task.actions';  
  
export interface TaskState {  
  tasks: { id: number; name: string }[];  
}  
  
const initialState: TaskState = { tasks: [] };  
  
export const taskReducer = createReducer(  
  initialState,  
  on(TaskActions.addTask, (state, { task }) => ({  
    tasks: [...state.tasks, { id: state.tasks.length + 1, name: task }]  
  })),  
  on(TaskActions.removeTask, (state, { id }) => ({  
    tasks: state.tasks.filter(task => task.id !== id)  
  }))  
);
```
In a component:
```javascript
@Component({  
  selector: 'app-task-list',  
  template: `  
    <ul>  
      <li *ngFor="let task of tasks$ | async">{{ task.name }}</li>  
    </ul>  
    <input #taskInput (keyup.enter)="addTask(taskInput.value)" />  
  `  
})  
export class TaskListComponent {  
  tasks$ = this.store.select(state => state.tasks);  
  
  constructor(private store: Store<TaskState>) {}  
  
  addTask(name: string) {  
    this.store.dispatch(addTask({ task: name }));  
  }  
}
```

**Outcome**: NgRx centralized task state, making it easy to add features like undo/redo. Signals were later used for local component state, reducing boilerplate.

**Common Pitfall**: Overusing NgRx for simple state. I once built a whole store for a toggle — use Signals or services for lightweight cases.

### Interview Questions

1.  **What is NgRx, and when should you use it?**  
    _Hint_: NgRx implements Redux for predictable state management, ideal for complex apps.
2.  **How do Signals differ from NgRx?**  
    _Hint_: Signals are reactive primitives for local state, simpler than NgRx's store.
3.  **What's a selector in NgRx?**  
    _Hint_: Selectors extract specific state slices efficiently.
4.  **How would you debug state mismatches in NgRx?**  
    _Hint_: Use Redux DevTools and log actions to trace state changes.
5.  **When would you avoid state management libraries?**  
    _Hint_: For small apps, services or component state suffice.

### Pro Tip

Start with services for state. Only adopt NgRx when your app's complexity justifies the overhead — trust me, it's a beast to tame.

## Reactive Forms and Template-Driven Forms

### What It Is and Why It Matters

Forms are the heart of user interaction. Angular offers reactive forms (programmatic, scalable) and template-driven forms (simpler, directive-based). SDE2s need to know when to use each and how to handle validation.

### Real-Life Example

In a fintech app, we built a loan application form using reactive forms:
```javascript
import { Component } from '@angular/core';  
import { FormBuilder, FormGroup, Validators } from '@angular/forms';  
  
@Component({  
  selector: 'app-loan-form',  
  template: `  
    <form [formGroup]="loanForm" (ngSubmit)="submit()">  
      <input formControlName="amount" placeholder="Loan Amount" />  
      <div *ngIf="loanForm.get('amount')?.invalid">Amount is required</div>  
      <button type="submit" [disabled]="loanForm.invalid">Apply</button>  
    </form>  
  `  
})  
export class LoanFormComponent {  
  loanForm: FormGroup;  
  
  constructor(private fb: FormBuilder) {  
    this.loanForm = this.fb.group({  
      amount: ['', [Validators.required, Validators.min(1000)]]  
    });  
  }  
  
  submit() {  
    console.log(this.loanForm.value);  
  }  
}
```

**Outcome**: Reactive forms made validation and dynamic fields (like co-applicant details) a breeze. We reused the form logic across multiple pages.

**Common Pitfall**: Mixing reactive and template-driven forms. I did this early on, and debugging became a mess — pick one and stick to it.

### Interview Questions

1.  **What's the difference between reactive and template-driven forms?**  
    _Hint_: Reactive forms are code-driven and scalable; template-driven are template-based and simpler.
2.  **How do you add custom validators?**  
    _Hint_: Create a function returning a ValidatorFn for reactive forms.
3.  **What's FormBuilder used for?**  
    _Hint_: Simplifies creating complex FormGroups and FormControls.
4.  **How do you handle form submission errors?**  
    _Hint_: Use form status and server-side error mapping.
5.  **When would you choose template-driven forms?**  
    _Hint_: For simple forms with minimal logic, like a login page.

### Pro Tip

Use reactive forms for anything complex. They're verbose but worth it for maintainability — especially when your PM decides to add 10 new fields at the last minute.

## Observables and RxJS

### What It Is and Why It Matters

Observables (via RxJS) power asynchronous operations in Angular, like HTTP requests or event streams. Mastering operators like map, mergeMap, and debounceTime is crucial for SDE2 roles.

### Real-Life Example

In a search feature for a retail app, we used RxJS to debounce user input:
```javascript
import { Component } from '@angular/core';  
import { FormControl } from '@angular/forms';  
import { debounceTime, switchMap } from 'rxjs/operators';  
import { ProductService } from './product.service';  
  
@Component({  
  selector: 'app-search',  
  template: `  
    <input [formControl]="searchControl" placeholder="Search products" />  
    <div *ngFor="let product of products$ | async">{{ product.name }}</div>  
  `  
})  
export class SearchComponent {  
  searchControl = new FormControl();  
  products$ = this.searchControl.valueChanges.pipe(  
    debounceTime(300),  
    switchMap(query => this.productService.search(query))  
  );  
  
  constructor(private productService: ProductService) {}  
}
```
**Outcome**: Debouncing cut API calls by 50%, improving performance and UX. switchMap ensured only the latest search query ran, avoiding race conditions.

**Common Pitfall**: Forgetting to unsubscribe. I once caused a memory leak by leaving subscriptions open — use async pipe or takeUntil to clean up.

### Interview Questions

1.  **What's an Observable vs. a Promise?**  
    _Hint_: Observables handle multiple values over time; Promises resolve once.
2.  **What does switchMap do?**  
    _Hint_: Cancels prior requests and maps to a new Observable.
3.  **How do you handle errors in RxJS?**  
    _Hint_: Use catchError to gracefully handle failures.
4.  **What's the purpose of debounceTime?**  
    _Hint_: Delays emissions to reduce frequent updates, ideal for search.
5.  **How do you combine multiple Observables?**  
    _Hint_: Use combineLatest, forkJoin, or merge based on needs.

### Pro Tip

Learn 5–10 RxJS operators cold (e.g., map, filter, switchMap). They cover 90% of use cases, and you'll look like a wizard in interviews.

## Performance Optimization

### What It Is and Why It Matters

Performance is critical for user satisfaction. Angular offers tools like lazy loading, OnPush change detection, and trackBy to keep apps snappy. SDE2s must optimize large-scale apps effectively.

### Real-Life Example

In a dashboard app, a table rendering 1,000 rows was sluggish. We used OnPush and trackBy:
```javascript
@Component({  
  selector: 'app-data-table',  
  template: `  
    <table>  
      <tr *ngFor="let item of items; trackBy: trackById">  
        <td>{{ item.name }}</td>  
      </tr>  
    </table>  
  `,  
  changeDetection: ChangeDetectionStrategy.OnPush  
})  
export class DataTableComponent {  
  @Input() items: { id: number; name: string }[] = [];  
  
  trackById(index: number, item: { id: number }) {  
    return item.id;  
  }  
}
```
**Outcome**: OnPush reduced unnecessary checks, and trackBy minimized DOM updates, cutting render time from 2s to 200ms.

**Common Pitfall**: Overusing OnPush without understanding inputs. I once broke a component by forgetting to mark it for check — use ChangeDetectorRef wisely.

### Interview Questions

1.  **What is change detection in Angular?**  
    _Hint_: It syncs model and view; default checks all components.
2.  **How does OnPush improve performance?**  
    _Hint_: Only checks when inputs or events change.
3.  **What's the purpose of trackBy in ngFor?**  
    _Hint_: Tracks items by unique IDs to avoid re-rendering.
4.  **How do you lazy-load modules?**  
    _Hint_: Use loadChildren in routes to defer module loading.
5.  **How would you optimize a slow component?**  
    _Hint_: Profile with DevTools, use OnPush, and memoize expensive computations.

### Pro Tip

Always profile before optimizing. I wasted hours tweaking a component that wasn't the bottleneck — Chrome's Performance tab is your friend.

## Angular CLI and Build Tools

### What It Is and Why It Matters

Angular CLI streamlines development with commands for generating code, building, and testing. SDE2s need to leverage it for productivity and optimized builds.

### Real-Life Example

For a startup's MVP, we used Angular CLI to scaffold a blog app:
```shell
ng new blog-app  
ng generate component post-list  
ng generate service post  
ng build --prod
```
We customized the build in angular.json to reduce bundle size:
```json
"configurations": {  
  "production": {  
    "optimization": true,  
    "outputHashing": "all",  
    "sourceMap": false,  
    "extractCss": true,  
    "namedChunks": false,  
    "aot": true,  
    "vendorChunk": true,  
    "buildOptimizer": true  
  }  
}
```

**Outcome**: CLI cut setup time, and the optimized build shaved 40% off the bundle size, making the app load faster on mobile.

**Common Pitfall**: Ignoring build configs. I once deployed without AOT, bloating the bundle — always enable production optimizations.

### Interview Questions

1.  **What does ng generate do?**  
    _Hint_: Creates components, services, etc., with boilerplate code.
2.  **How do you optimize an Angular build?**  
    _Hint_: Use AOT, tree-shaking, and minification.
3.  **What's the difference between ng serve and ng build?**  
    _Hint_: ng serve is for development; ng build creates deployable artifacts.
4.  **How do you add a custom webpack config to Angular CLI?**  
    _Hint_: Use @angular-builders/custom-webpack for advanced tweaks.
5.  **What's AOT compilation?**  
    _Hint_: Compiles templates at build time for faster rendering.

### Pro Tip

Memorize ng g c/s/m shortcuts for components, services, and modules. It's a small thing, but it saves time and impresses interviewers.

## Testing

### What It Is and Why It Matters

Testing ensures your app works as expected. Angular supports unit tests (Jasmine/Karma) and e2e tests (Cypress/Protractor). SDE2s must write robust tests for maintainable code.

### Real-Life Example

In a booking app, we tested a BookingService:
```javascript
import { TestBed } from '@angular/core/testing';  
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';  
import { BookingService } from './booking.service';  
  
describe('BookingService', () => {  
  let service: BookingService;  
  let httpMock: HttpTestingController;  
  
  beforeEach(() => {  
    TestBed.configureTestingModule({  
      imports: [HttpClientTestingModule],  
      providers: [BookingService]  
    });  
    service = TestBed.inject(BookingService);  
    httpMock = TestBed.inject(HttpTestingController);  
  });  
  
  it('should fetch bookings', () => {  
    const mockBookings = [{ id: 1, date: '2025-04-10' }];  
  
    service.getBookings().subscribe(bookings => {  
      expect(bookings).toEqual(mockBookings);  
    });  
  
    const req = httpMock.expectOne('/api/bookings');  
    req.flush(mockBookings);  
  });  
  
  afterEach(() => {  
    httpMock.verify();  
  });  
});
```
**Outcome**: Tests caught a bug where failed API calls weren't handled, saving us from a production issue. Cypress e2e tests ensured the booking flow worked end-to-end.

**Common Pitfall**: Skimping on test coverage. I once ignored edge cases, and a null error slipped through — aim for 80%+ coverage.

### Interview Questions

1.  **What's the difference between unit and e2e tests?**  
    _Hint_: Unit tests check components/services; e2e tests verify user flows.
2.  **How do you mock dependencies in Jasmine?**  
    _Hint_: Use TestBed and spies to mock services.
3.  **What's HttpClientTestingModule used for?**  
    _Hint_: Mocks HTTP requests for testing services.
4.  **How do you test a component with async operations?**  
    _Hint_: Use fakeAsync or waitForAsync to handle promises/Observables.
5.  **Why use Cypress over Protractor?**  
    _Hint_: Cypress is faster and easier to debug, though Protractor's Angular-specific.

### Pro Tip

Write tests as you code, not after. It feels tedious, but catching bugs early is worth it — especially when your PM asks for “one small change” before launch.

## Angular Universal and SSR

### What It Is and Why It Matters

Angular Universal enables server-side rendering (SSR) for better SEO and faster initial loads. SDE2s need to understand SSR's benefits and challenges for public-facing apps.

### Real-Life Example

For a news portal, we implemented SSR to boost SEO:
```javascript
import { NgModule } from '@angular/core';  
import { BrowserModule } from '@angular/platform-browser';  
import { AppComponent } from './app.component';  
import { ServerModule } from '@angular/platform-server';  
  
@NgModule({  
  declarations: [AppComponent],  
  imports: [  
    BrowserModule.withServerTransition({ appId: 'news-app' }),  
    ServerModule  
  ],  
  bootstrap: [AppComponent]  
})  
export class AppServerModule {}
```
We prerendered routes in angular.json:
```json
"server": {  
  "builder": "@angular-devkit/build-angular:server",  
  "options": {  
    "outputPath": "dist/server",  
    "main": "src/main.server.ts",  
    "tsConfig": "tsconfig.server.json"  
  }  
}
```
**Outcome**: Google indexed our articles faster, and first paint dropped from 3s to 1s, increasing user retention by 15%.

**Common Pitfall**: Ignoring browser-only APIs. I once used window in SSR code, crashing the server — use PLATFORM_ID to check the environment.

### Interview Questions

1.  **What is Angular Universal?**  
    _Hint_: Enables SSR for Angular apps, improving SEO and load times.
2.  **How does SSR differ from client-side rendering?**  
    _Hint_: SSR renders HTML on the server; CSR renders in the browser.
3.  **What's prerendering in Angular Universal?**  
    _Hint_: Generates static HTML at build time for specific routes.
4.  **How do you handle browser-only APIs in SSR?**  
    _Hint_: Use isPlatformBrowser() or TransferState to share data.
5.  **What are the downsides of SSR?**  
    _Hint_: Increases server load and complexity; not ideal for all apps.

### Pro Tip

Start with prerendering for static pages before diving into full SSR. It's simpler and often enough for SEO gains.

## Angular Material and UI Integration

### What It Is and Why It Matters

Angular Material provides pre-built UI components (buttons, dialogs, etc.) following Material Design. SDE2s must integrate it efficiently for consistent, accessible UIs.

### Real-Life Example

In an HR portal, we used Angular Material for a user table:
```javascript
import { Component } from '@angular/core';  
import { MatTableDataSource } from '@angular/material/table';  
  
@Component({  
  selector: 'app-user-table',  
  template: `  
    <table mat-table [dataSource]="dataSource">  
      <ng-container matColumnDef="name">  
        <th mat-header-cell *matHeaderCellDef>Name</th>  
        <td mat-cell *matCellDef="let user">{{ user.name }}</td>  
      </ng-container>  
      <tr mat-header-row *matHeaderRowDef="['name']"></tr>  
      <tr mat-row *matRowDef="let row; columns: ['name']"></tr>  
    </table>  
  `  
})  
export class UserTableComponent {  
  dataSource = new MatTableDataSource([{ name: 'Alice' }, { name: 'Bob' }]);  
}
```
**Outcome**: Material's table component gave us sorting and pagination out of the box, saving days of custom coding. The UI was accessible and responsive.

**Common Pitfall**: Overriding Material styles. I once hacked CSS to “fix” a button, breaking its responsiveness — use theme variables instead.

### Interview Questions

1.  **What is Angular Material?**  
    _Hint_: A UI component library implementing Material Design.
2.  **How do you customize Angular Material themes?**  
    _Hint_: Override SCSS variables or use custom themes in angular.json.
3.  **What's MatTableDataSource used for?**  
    _Hint_: Manages data for Material tables, supporting filtering/sorting.
4.  **How do you ensure accessibility with Angular Material?**  
    _Hint_: Use built-in ARIA attributes and test with screen readers.
5.  **When would you avoid Angular Material?**  
    _Hint_: For custom designs not aligned with Material guidelines.

### Pro Tip

Use Material's CDK (Component Dev Kit) for reusable behaviors like drag-drop, even if you don't use the full component set.

## Interceptors and HTTP Client

### What It Is and Why It Matters

Angular's HttpClient handles API calls, and interceptors modify requests/responses globally (e.g., adding headers). SDE2s must use them for clean, reusable networking code.

### Real-Life Example

In a SaaS app, we used an interceptor to add auth tokens:
```javascript
import { Injectable } from '@angular/core';  
import { HttpInterceptor, HttpRequest, HttpHandler } from '@angular/common/http';  
  
@Injectable()  
export class AuthInterceptor implements HttpInterceptor {  
  intercept(req: HttpRequest<any>, next: HttpHandler) {  
    const authToken = localStorage.getItem('token');  
    const authReq = req.clone({  
      setHeaders: { Authorization: `Bearer ${authToken}` }  
    });  
    return next.handle(authReq);  
  }  
}
```

Registered in AppModule:
```javascript
providers: [  
  { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true }  
]
```

**Outcome**: Every API call got the token automatically, reducing boilerplate and ensuring secure requests.

**Common Pitfall**: Mutating requests incorrectly. I once forgot to clone the request, breaking other interceptors — always use clone().

### Interview Questions

1.  **What's an HTTP interceptor?**  
    _Hint_: Modifies HTTP requests/responses globally.
2.  **How do you handle API errors centrally?**  
    _Hint_: Use an interceptor with catchError to log or redirect.
3.  **What's the benefit of HttpClient over fetch?**  
    _Hint_: HttpClient integrates with Angular's DI and RxJS.
4.  **How do you add multiple interceptors?**  
    _Hint_: Angular chains them in the order provided.
5.  **How do you mock HTTP calls in tests?**  
    _Hint_: Use HttpClientTestingModule and HttpTestingController.

### Pro Tip

Chain interceptors thoughtfully. Logging, auth, and error handling should each have their own — keep them single-purpose for clarity.

# Security Best Practices

### What It Is and Why It Matters

Security protects users from threats like XSS or CSRF. Angular has built-in safeguards, but SDE2s must apply best practices to keep apps safe.

### Real-Life Example

In a social media app, we prevented XSS in user comments:
```javascript
@Component({  
  selector: 'app-comment',  
  template: `  
    <div [innerHTML]="comment | sanitize"></div>  
  `  
})  
export class CommentComponent {  
  @Input() comment: string;  
}  
  
import { Pipe, PipeTransform } from '@angular/core';  
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';  
  
@Pipe({ name: 'sanitize' })  
export class SanitizePipe implements PipeTransform {  
  constructor(private sanitizer: DomSanitizer) {}  
  
  transform(value: string): SafeHtml {  
    return this.sanitizer.sanitize(SecurityContext.HTML, value);  
  }  
}
```

**Outcome**: Malicious scripts in comments were stripped, protecting users. We also used CSP headers to lock down external scripts.

**Common Pitfall**: Bypassing sanitization. I once used bypassSecurityTrustHtml for convenience and regretted it — always sanitize user input.

### Interview Questions

1.  **How does Angular prevent XSS?**  
    _Hint_: Escapes template bindings and sanitizes HTML.
2.  **What's the DomSanitizer used for?**  
    _Hint_: Safely handles dynamic HTML, URLs, or styles.
3.  **How do you prevent CSRF in Angular?**  
    _Hint_: Use HttpClient, which includes XSRF tokens by default.
4.  **What's a Content Security Policy?**  
    _Hint_: Restricts resource loading to prevent malicious scripts.
5.  **How do you secure API keys in Angular?**  
    _Hint_: Store them server-side, not in client code.

### Pro Tip

Audit your app with tools like OWASP ZAP. It's eye-opening to see what you missed, and it's better to catch it before a hacker does.

## Standalone Components and Modern Features

### What It Is and Why It Matters

Standalone components (introduced in Angular 14) eliminate the need for NgModules in many cases. Features like Signals and deferrable views (Angular 17+) simplify reactivity and performance. SDE2s must stay current with these trends.

### Real-Life Example

In a weather app, we used a standalone component with Signals:
```javascript
import { Component, signal } from '@angular/core';  
import { HttpClient } from '@angular/common/http';  
  
@Component({  
  selector: 'app-weather',  
  standalone: true,  
  template: `  
    <input (input)="city.set($event.target.value)" />  
    <div>{{ weather() | json }}</div>  
    @defer (when city()) {  
      <app-forecast [city]="city()" />  
    }  
  `  
})  
export class WeatherComponent {  
  city = signal('');  
  weather = signal<any>(null);  
  
  constructor(private http: HttpClient) {  
    effect(() => {  
      this.http.get(`/api/weather/${this.city()}`).subscribe(data => {  
        this.weather.set(data);  
      });  
    });  
  }  
}
```

**Outcome**: No module boilerplate, and Signals made state updates reactive. @defer lazy-loaded the forecast, improving initial render.

**Common Pitfall**: Mixing standalone and module-based components. I tried this and got injector errors — migrate gradually.

### Interview Questions

1.  **What are standalone components?**  
    _Hint_: Components that don't require NgModules, simplifying structure.
2.  **How do Signals work in Angular?**  
    _Hint_: Reactive primitives for fine-grained state updates.
3.  **What's the benefit of deferrable views?**  
    _Hint_: Lazy-loads template blocks for better performance.
4.  **How do you migrate to standalone components?**  
    _Hint_: Convert modules to standalone, updating imports and providers.
5.  **What's the role of effect() in Signals?**  
    _Hint_: Runs side effects when Signals change.

### Pro Tip

Experiment with Signals in a side project. They're a game-changer, but you'll need practice to avoid overcomplicating simple state.

## Integration with APIs and Third-Party Libraries

### What It Is and Why It Matters

Angular apps often connect to APIs and libraries (e.g., charts, auth). SDE2s must integrate them seamlessly while keeping code clean.

### Real-Life Example

In a dashboard, we used Chart.js for analytics:
```javascript
import { Component, AfterViewInit } from '@angular/core';  
import { Chart } from 'chart.js/auto';  
  
@Component({  
  selector: 'app-analytics',  
  template: `<canvas #chart></canvas>`  
})  
export class AnalyticsComponent implements AfterViewInit {  
  @ViewChild('chart') chartCanvas!: ElementRef;  
  
  ngAfterViewInit() {  
    new Chart(this.chartCanvas.nativeElement, {  
      type: 'bar',  
      data: {  
        labels: ['Jan', 'Feb', 'Mar'],  
        datasets: [{ data: [10, 20, 30] }]  
      }  
    });  
  }  
}
```
**Outcome**: Chart.js integrated smoothly, and wrapping it in a component kept the code reusable across dashboards.

**Common Pitfall**: Not typing third-party libraries. I skipped @types/chart.js once, and TypeScript errors haunted me — install types or declare modules.

### Interview Questions

1.  **How do you integrate a third-party library in Angular?**  
    _Hint_: Install via npm, import, and wrap in components/services.
2.  **What's the benefit of wrapping libraries in services?**  
    _Hint_: Encapsulates logic for testability and reuse.
3.  **How do you handle API rate limits?**  
    _Hint_: Use RxJS operators like debounceTime or queue requests.
4.  **What's a typed API response?**  
    _Hint_: Use interfaces to define API response shapes.
5.  **How do you lazy-load a heavy library?**  
    _Hint_: Dynamically import it with import() in a service.

### Pro Tip

Create an ExternalLibsModule to import and provide third-party dependencies. It keeps your AppModule clean and makes upgrades easier.

# Deployment and CI/CD Pipelines

### What It Is and Why It Matters

Deploying Angular apps requires optimized builds and CI/CD pipelines for automation. SDE2s must ensure reliable, repeatable deployments.

### Real-Life Example

For a startup's app, we set up a GitHub Actions pipeline:
```yaml
name: Deploy Angular App  
on:  
  push:  
    branches: [main]  
jobs:  
  build:  
    runs-on: ubuntu-latest  
    steps:  
      - uses: actions/checkout@v3  
      - uses: actions/setup-node@v3  
        with:  
          node-version: '18'  
      - run: npm ci  
      - run: npm run build -- --prod  
      - uses: aws-actions/configure-aws-credentials@v1  
        with:  
          aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}  
          aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}  
          aws-region: us-east-1  
      - run: aws s3 sync dist/ s3://my-bucket
```

**Outcome**: Automated builds and deployments to S3 cut release time from hours to minutes. Rollbacks were painless with versioned buckets.

**Common Pitfall**: Hardcoding secrets. I exposed an API key in a pipeline once — use environment variables or secrets management.

### Interview Questions

1.  **How do you deploy an Angular app?**  
    _Hint_: Build with ng build — prod and host on S3, Firebase, or Netlify.
2.  **What's the role of environment.ts?**  
    _Hint_: Configures environment-specific settings like API URLs.
3.  **How do you set up CI/CD for Angular?**  
    _Hint_: Use GitHub Actions or Jenkins to build, test, and deploy.
4.  **What's a multi-stage build?**  
    _Hint_: Separates build and runtime environments for smaller images.
5.  **How do you handle rollbacks in CI/CD?**  
    _Hint_: Use versioned deployments or blue-green strategies.

### Pro Tip

Test your pipeline locally with tools like act. It's a lifesaver when your deploy fails at 2 a.m.

# Common Design Patterns

### What It Is and Why It Matters

Design patterns like singleton, facade, or container-presenter make Angular apps maintainable. SDE2s must apply them appropriately.

# Real-Life Example

In a logistics app, we used a facade pattern to simplify state access:
```javascript
import { Injectable } from '@angular/core';  
import { Store } from '@ngrx/store';  
import { selectShipment } from './shipment.selectors';  
  
@Injectable({  
  providedIn: 'root'  
})  
export class ShipmentFacade {  
  shipment$ = this.store.select(selectShipment);  
  
  constructor(private store: Store) {}  
  
  loadShipment(id: string) {  
    this.store.dispatch(loadShipment({ id }));  
  }  
}
```

**Outcome**: Components called facade.loadShipment() instead of dispatching actions, reducing complexity and improving testability.

**Common Pitfall**: Overengineering patterns. I once built a mediator for a simple app — use patterns only when they solve real problems.

### Interview Questions

1.  **What's a singleton pattern in Angular?**  
    _Hint_: Services providedIn: 'root' create a single instance.
2.  **How does the facade pattern help?**  
    _Hint_: Simplifies access to complex subsystems like NgRx.
3.  **What's a container-presenter pattern?**  
    _Hint_: Containers handle logic; presenters display data.
4.  **When would you use a strategy pattern?**  
    _Hint_: For interchangeable algorithms, like sorting methods.
5.  **What's the observer pattern in Angular?**  
    _Hint_: Implemented via EventEmitter and RxJS Observables.

### Pro Tip

Learn the facade pattern — it's a lifesaver for hiding NgRx complexity from components. Your team will love you for it.

### Remaining Interview Questions

To hit exactly 111 questions, here are additional ones spread across topics, with brief hints:

1.  **How do you handle dynamic component creation?**  
    _Hint_: Use ComponentFactoryResolver for runtime components.
2.  **What's the purpose of NgZone?**  
    _Hint_: Manages change detection for async operations.
3.  **How do you optimize Angular animations?**  
    _Hint_: Use lightweight keyframes and avoid heavy CSS.
4.  **What's a custom pipe, and when do you use it?**  
    _Hint_: Transforms data in templates, like formatting dates.
5.  **How do you share code between Angular projects?**  
    _Hint_: Use Nx workspaces or publish an npm library.
6.  **What's the benefit of Ivy renderer?**  
    _Hint_: Faster compilation and smaller bundles.
7.  **How do you handle internationalization (i18n)?**  
    _Hint_: Use Angular's i18n tools or libraries like Transloco.
8.  **What's a multi-provider in DI?**  
    _Hint_: Allows multiple values for a single token, like interceptors.
9.  **How do you debug a production Angular app?**  
    _Hint_: Use source maps and logging services.
10.  **What's the role of APP_INITIALIZER?**  
    _Hint_: Runs setup code before app bootstrap.
11.  **How do you handle large forms with many controls?**  
    _Hint_: Break into FormGroup subsections or use libraries like Ngx-Formly.
12.  **What's the difference between providedIn: 'root' and 'platform'?**  
    _Hint_: Platform is for shared services in multi-app setups.
13.  **How do you implement a custom change detection strategy?**  
    _Hint_: Extend DefaultChangeDetectionStrategy for rare cases.
14.  **What's the benefit of ViewEncapsulation?**  
    _Hint_: Scopes styles to components, preventing leaks.
15.  **How do you handle browser compatibility issues?**  
    _Hint_: Use polyfills and test with BrowserStack.
16.  **What's a resolver's role in data fetching?**  
    _Hint_: Prefetches data before route activation.
17.  **How do you optimize NgRx performance?**  
    _Hint_: Use memoized selectors and minimal state updates.
18.  **What's the purpose of TransferState in SSR?**  
    _Hint_: Shares server-side data with the client.
19.  **How do you test a directive?**  
    _Hint_: Create a test component and apply the directive.
20.  **What's a schematic in Angular CLI?**  
    _Hint_: Automates code generation, like ng generate.
21.  **How do you handle real-time updates?**  
    _Hint_: Use WebSockets or polling with RxJS.
22.  **What's the role of ContentChildren?**  
    _Hint_: Queries projected content in components.
23.  **How do you secure sensitive data in Angular?**  
    _Hint_: Avoid storing in localStorage; use server-side encryption.
24.  **What's a zone-less Angular app?**  
    _Hint_: Uses Signals and manual change detection for performance.
25.  **How do you mentor junior devs on Angular?**  
    _Hint_: Teach core concepts, pair program, and review code.
---

### Top 20 Angular Interview Questions 

1.  **What are Angular Signals, and how do they differ from RxJS Observables?**

**Answer**: Signals are reactive primitives that track state changes efficiently. Unlike Observables (which handle async streams), Signals simplify synchronous state management. Use Signals for local component state and Observables for complex async operations like HTTP calls.

**2. Explain standalone components. Why replace NgModules?**

**Answer**: Standalone components are self-contained, eliminating the need for NgModules. They reduce boilerplate, simplify lazy loading, and make apps more modular. Angular 17+ defaults to standalone, streamlining app architecture.

**3. How does hydration improve SSR in Angular?**

**Answer**: Hydration prevents flickering by reusing server-rendered HTML in the browser instead of re-rendering. Angular 19's enhanced hydration reduces load times and improves SEO by making SSR smoother.

### Advanced Features

**4. What is zoneless change detection?**

**Answer**: Zoneless mode (introduced in Angular 18+) removes dependency on `zone.js`, reducing bundle size and improving performance. It uses signals or manual triggers to detect changes, giving developers finer control.

**5. How would you optimize Angular app performance?**

**Answer**:

-   Use `OnPush` change detection.
-   Lazy load standalone components.
-   Analyze bundles with `source-map-explorer`.
-   Enable SSR hydration and caching.

**6. What's an interceptor? Give an example.**

-   **Answer**: Interceptors modify HTTP requests/responses. Example: Adding a JWT token to headers.
```javascript
@Injectable()    
export class AuthInterceptor implements HttpInterceptor {    
  intercept(req: HttpRequest<any>, next: HttpHandler) {    
    const cloned = req.clone({ setHeaders: { Authorization: 'Bearer token' } });    
    return next.handle(cloned);    
  }    
}  
```
### State Management

**7. NgRx vs. Signals for state: When to use each?**

**Answer**: Use **NgRx** for complex global state (e.g., multi-step workflows). Use **Signals** for local state or simple apps. Signals are lightweight and integrated into Angular's reactivity model.

**8. How do you prevent memory leaks?**

**Answer**:

-   Unsubscribe from Observables (or use `takeUntilDestroyed`).
-   Avoid manual DOM manipulations.
-   Use Angular's `async` pipe in templates.

### Security & Testing

**9. How secure Angular apps against XSS?**

**Answer**:

-   Sanitize user input with `DomSanitizer`.
-   Avoid `innerHTML` with untrusted data.
-   Use CSP headers and sanitize third-party libraries.

**10. What's your testing strategy?**

**Answer**:

-   **Unit tests**: Test components/services in isolation (Jest).
-   **Integration tests**: Validate component interactions.
-   **E2E tests**: Use Cypress for user flow testing.

### Modern Patterns

**11. How to lazy load standalone components?**

**Answer**: Use `loadComponent` in the router:
```javascript
{ path: 'dashboard', loadComponent: () => import('./dashboard.component') }  
```
**12. Design a dynamic form with validation.**

**Answer**: Use reactive forms with `FormBuilder`:
```javascript
this.form = this.fb.group({    
  email: ['', [Validators.required, Validators.email]],    
  password: ['', [Validators.minLength(8)]]    
});  
```

### Debugging & Tools

**13. Debug a memory leak. Steps?**

**Answer**:

-   Use Chrome DevTools' Memory tab.
-   Look for detached DOM nodes or orphaned subscriptions.
-   Audit components with `ng.profiler.timeChangeDetection()`.

**14. What's Angular's new control flow syntax?**

**Answer**: Replace `*ngIf` and `*ngFor` with `@if` and `@for`:
```html
@if (user.isAdmin) {    
  <button>Delete</button>    
}  
```

### Future-Forward Skills

**15. Integrate WebSockets in Angular.**

**Answer**: Use RxJS's `webSocket`:
```javascript
import { webSocket } from 'rxjs/webSocket';    
const socket$ = webSocket('ws://localhost:8080');    
socket$.subscribe((data) => console.log(data));  
```
**16. What's exciting in Angular 19?**

**Answer**: Stable signals, partial hydration for faster SSR, and DevTools improvements for debugging reactivity.

### Architecture

**17. Implement micro-frontends with Angular.**

**Answer**: Use Module Federation (via Nx or Webpack) to split the app into independently deployable modules.

**18. Structure a large-scale app.**

**Answer**:

-   Group features by domain (e.g., `auth`, `dashboard`).
-   Use standalone components and lazy loading.
-   Centralize state with Signals or NgRx.

### Final Questions

**19. Upgrade Angular from v14 to v19?**

**Answer**:

-   Incrementally update one major version at a time.
-   Use `ng update` and fix breaking changes.
-   Migrate to standalone components and signals.

**20. Why choose Angular over other frameworks?**

**Answer**: Angular offers a full-stack solution with built-in tools (RxJS, SSR, CLI), enterprise-grade scalability, and a strong ecosystem.

---

# Angular Interview Q&A: Day 9. Module Federation, Accessibility, SSR

### Question 1: What is Module Federation and how can it be used with Angular?

**Answer:**

**Module Federation** (introduced with Webpack 5) allows multiple Angular applications to dynamically share and consume code (like components or modules) at runtime without recompiling.

It's commonly used in **micro frontend architectures**.

**Basic Setup:**

-   Configure `webpack.config.js` with `ModuleFederationPlugin`
-   Expose modules in one app (host) and consume in another (remote)

> _✅ Use_ `_@angular-architects/module-federation_` _to simplify integration._

### Question 2: How does Angular support Accessibility (a11y)?

**Answer:**

Angular promotes accessibility through:

-   Semantic HTML
-   Built-in directives like `aria-*`
-   `@angular/cdk/a11y` package
-   Keyboard interaction support

**Example (Focusable element with ARIA):**
```html
<button aria-label="Close modal" (click)="close()">X</button>
```
> _✅ Tools like_ **_axe-core_**_,_ **_NVDA_**_, and_ **_Chrome DevTools_** _help audit accessibility._

### Question 3: What is Angular Universal and why is it used?

**Answer:**

**Angular Universal** enables **server-side rendering (SSR)** of Angular applications.

**Benefits:**

-   Improved SEO (Google can crawl HTML content)
-   Faster initial load
-   Better performance on low-end devices

**Basic Workflow:**

-   Create a Universal app using `ng add @nguniversal/express-engine`
-   Server renders HTML and sends it to the browser

> _✅ Ideal for public-facing apps with SEO needs (e.g., e-commerce, blogs)_

### Question 4: Explain Dependency Injection Hierarchy in Angular.

**Answer:**

Angular has a **hierarchical injector system**:

-   **Root injector:** Created at application start
-   **Module injector:** Specific to a lazy-loaded module
-   **Component injector:** Scoped to a component and its children

**Example:**
```javascript
@Injectable({ providedIn: 'root' }) // Singleton  
export class ApiService {}
```
**Use** `**providers: []**` **in components** if you want scoped services.

> _✅ Use caution: providing the same service in multiple injectors can create unexpected multiple instances._

### Question 5: What is `switchMap` in RxJS and how does it differ from `mergeMap`?

**Answer:**

-   `switchMap`: Cancels previous inner observable when a new value arrives.
-   `mergeMap`: Keeps all inner observables running simultaneously.

**Use Case for** `**switchMap**`**:** HTTP search autocomplete – cancel previous request when user types again.

**Example:**
```javascript
this.searchInput.valueChanges.pipe(  
  debounceTime(300),  
  switchMap(query => this.api.search(query))  
).subscribe(results => this.items = results);
```
> _✅ Use_ `_switchMap_` _to avoid race conditions with HTTP requests._

🎯 That's it for **Day 9**! You're mastering some of the most powerful features Angular has to offer. Stick around for Day 10 — we'll go even deeper!

---
# Angular Interview Questions - 8

### Question 1: How do you implement lazy loading of standalone components?

**Answer:**

Angular now allows lazy loading of **standalone components** without wrapping them in modules.

**Example (in routes):**
```javascript
const routes: Routes = [  
  {  
    path: 'profile',  
    loadComponent: () =>  
      import('./profile.component').then(m => m.ProfileComponent)  
  }  
];
```
> _✅ Useful for improving initial load time and modularizing large apps._

### Question 2: What is multi-slot content projection and how does it work?

**Answer:**

Multi-slot content projection allows you to pass multiple content sections to different areas inside a component using `select` attributes.

**Parent Template:**
```html
<app-card>  
  <div slot="title">Card Title</div>  
  <div slot="content">Card Content</div>  
</app-card>
```
**Child Component (app-card):**
```html
<ng-content select="[slot=title]"></ng-content>  
<ng-content select="[slot=content]"></ng-content>
```
> _✅ It gives you fine control over how content is rendered in reusable components._

### Question 3: What is the `inject()` function in Angular and when should you use it?

**Answer:**

The `inject()` function (Angular 14+) allows you to inject services without using a constructor. It works in:

-   Components
-   Services
-   Functions
-   Guards, Pipes, Interceptors, etc.

**Example:**
```javascript
const logger = inject(LoggerService);  
logger.log('Hello from inject()');
```
> _✅ Especially useful in standalone components and functional services._

### Question 4: How can directives communicate with each other in Angular?

**Answer:**

You can use `@Host`, `@Optional`, or `@Self` decorators to inject one directive into another when they are applied on the same DOM element.

**Example:**
```javascript
@Directive({ selector: '[childDir]' })  
export class ChildDirective {  
  constructor(@Optional() @Host() private parent: ParentDirective) {  
    if (parent) parent.register();  
  }  
}
```
> _✅ Useful when building component libraries with reusable behavior._

### Question 5: How do you use Angular Material in real-world applications?

**Answer:**

Angular Material provides pre-built, accessible, and responsive UI components.

**Installation:**
```shell
ng add @angular/material
```
**Example:**
```html
<mat-form-field>  
  <mat-label>Username</mat-label>  
  <input matInput placeholder="Enter your name">  
</mat-form-field>
```
---

# Angular Interview Question: Dependency Injection for Services 

Angular components are meant to be the user interface and nothing more. They display data and enable user interaction, react on user clicks and inputs. The application logic should be done in services. When you need a service in a component, you usually don't create an instance yourself using `new`. You mark the service as `injectable` and you add it as a parameter to the component's constructor. The Angular Dependency Injection (DI) will take care of creating an instance and will inject it for you.

It is common not to think too much about this process. When you create a service to fetch data from the server, you need only one instance of it, and it doesn't really matter to you where it lives. But you sometimes need services to be available only inside a module, or even a component and its children. You might need to inject different instances of the service in different components. That is why a good understanding of how the Angular DI works is an important quality for an Angular developer.

### Injectors

Injectors are responsible for creating instances of the service classes and injecting them in the components that request them. Services are singletons inside an injector scope, there can be at most only one instance of a service.

Injectors are created by Angular. A _root_ injector is created in the bootstrap process. Angular will also create injectors for components, pipes or directives, but they stay empty unless you declare a _providers_ array in their decorators. Each lazy-loaded module also gets its own injector.

Injectors are inherited. When you request a service in a component, Angular will look in the injector of the component, then in the one of its parent, then of its parent's parent's… etc, until it either finds it or runs out of ancestors. If it hasn't found it in the element injectors, Angular starts looking in the modules injectors, until it finds a provider (or runs out of injectors).

### Providers

Injectors create instances and inject them but you need to tell them **how** to create these instances. When you inject a service in a component, you give a _DI Token_ to the closest injector. By default the token is the service class, TestService in the example below. The injector has a map _token-provider_, the token is the key. The provider of a service is usually the class itself:
```html
<iframe src="https://levelup.gitconnected.com/media/12241bd0f1cb1e3ae1249ad083e31f55" allowfullscreen="" frameborder="0" height="746" width="680" title="test.component.html" class="eo n hk dz bg" scrolling="no"></iframe>
```
In this example the service is provided only in the TestComponent and we tell Angular to use the class TestService to create an instance when injecting TestService. This is such a common behaviour that Angular gives you a shortcut for it:
```javascript
providers: [TestService]
```
That also means that we can tell the injector to use some other class when injecting TestService. In the following example, we tell the injector to return an instance of the HelloWorldService when being requested the TestService.
```html
<iframe src="https://levelup.gitconnected.com/media/b0d881f3af48aeb27a401017381558ec" allowfullscreen="" frameborder="0" height="710" width="680" title="hello-word.service.ts" class="eo n hk dz bg" scrolling="no"></iframe>
```
The result will then be:

![](https://miro.medium.com/v2/resize:fit:485/1*H61iml5ZGmOmjPjUF0KkIg.png)

### Injectors Hierarchy

###### Root Injector

You might not be providing services in your components that regularly. By default when you create a service with the Angular cli, the service is provided in the _root_ injector.
```html
<iframe src="https://levelup.gitconnected.com/media/c380f775f2659863eaf36e8179d1bc35" allowfullscreen="" frameborder="0" height="688" width="680" title="test.component.ts" class="eo n hk dz bg" scrolling="no"></iframe>
```
In this case, we don't need to provide the service in the component's injector. An instance of the service will be created in the _root_ injector and injected in our component. This instance will be available everywhere in the application.

![](https://miro.medium.com/v2/resize:fit:375/1*3rdXC4T-Vbl13QgsRuq87g.png)

We don't need to provide the service anywhere else, but we can.

###### Element Injectors

Even though the service can be injected by the _root_ injector, it doesn't have to. We can decide to create an instance of our service for this component (and its children). To do so, we need to define a provider like we did earlier.
```html
<iframe src="https://levelup.gitconnected.com/media/15e8a7e7a27052b4970be1886d8caede" allowfullscreen="" frameborder="0" height="1032" width="680" title="app.component.html" class="eo n hk dz bg" scrolling="no"></iframe>
```
We provided the service TestService in the TestComponent. An injector was created for the component, and will create an instance of TestService when the service gets injected.

In the AppComponent, we inject the service too. We didn't declare any provider in this component so the instance will be created and injected by the _root_ injector. We therefore have two instances of our service in the application. In the example we created a static variable to store the number of instances:

![](https://miro.medium.com/v2/resize:fit:610/1*GyZxuIIhIW7ZpXqaw7HlZw.png)

One consequence of the hierarchy of injectors is that if you provide a service in a parent component, the same instance will be used in every child component.
```html
<iframe src="https://levelup.gitconnected.com/media/6db61fe8edab31eb36c2841c470961fd" allowfullscreen="" frameborder="0" height="1200" width="680" title="hello-word.service.ts" class="eo n hk dz bg" scrolling="no"></iframe>
```
In this example, we will once again see:

![](https://miro.medium.com/v2/resize:fit:485/1*H61iml5ZGmOmjPjUF0KkIg.png)

Another important thing to note is that the instances of services don't live longer than the injectors that created them. That means that if you provide a service in a component, the instance of the service the component is using will die with the component. You might want to think about this when the data needs to be persisted.

###### Module Injector

Applications are usually organized in different modules. As by default services are provided in the _root_ injector, they are accessible from anywhere in the application, even in other modules. For example, if you have Module1 in which you defined a service TestService provided in _root_, you can use this service in a module Module2. As the service is injected by the _root_ injector, there will be only one instance of it.

If you provide the service in the module Module1 instead of in _root_, the service will still be available in Module2. That might be surprising but if Module1 is eager-loaded, it is imported in the AppModule. Module injectors flatten the providers of all the imports, so TestService will be provided in the AppModule.

If Module1 is lazy-loaded on the other hand, it is not imported in the AppModule. Providing the service in the module would make it only available inside it.

If you only provide the service in a component in Module1, the service will only be provided in the component's injector, neither in Module1 nor in _root_. In the two last cases, trying to inject the service in a component in Module2 will result in a _No provider_ error:

![](https://miro.medium.com/v2/resize:fit:875/1*N5T-t0F3ZAD-gK23x8mxUQ.png)

You have to explicitly provide the service whether in the Module2 or in the component where you are trying to inject it or directly in the _root_ injector.

The Angular DI generally allows you to keep a low amount of service instances without having to pay too much attention to it. In most of the cases, you don't have to worry about it. But it can become necessary to have a deeper understanding of this mechanism when you work with many modules, lazy-loaded ones, or when you need different instances of your service in your components.

Angular provides some more tool for an even greater flexibility. You might want to check the modifiers (@Optional, @SkipSelf, @Self. …) for more information.

We only covered the service case in this article. The DI can do more than this. You can for example provide values instead of classes. You can also create your own DI Token and inject elements manually using the @Inject annotation. For more details about these or about the Dependency Injection in general, I recommend you to read the Angular documentation.

###### Embedded Content

{{text}}

[view raw](https://gist.github.com/Dornhoth/b4f82ffdf9f1e56fcc61efe6b2a5ee11/raw/2301a8c6a41e667957bf939a08186dee02c3bf3e/test.component.html) [test.component.html](https://gist.github.com/Dornhoth/b4f82ffdf9f1e56fcc61efe6b2a5ee11###file-test-component-html) hosted with ❤ by [GitHub](https://github.com)
```javascript
import { Component, OnInit } from '@angular/core';
import { TestService } from 'src/app/services/test.service';

@Component({
selector: 'app-test',
templateUrl: './test.component.html',
styleUrls: ['./test.component.scss'],
providers: [{ provide: TestService, useClass: TestService }]
})

export class TestComponent implements OnInit {
text: string;
constructor(private testService: TestService) { }

    ngOnInit() {
        this.text = this.testService.getTest();
    }
}
```

[view raw](https://gist.github.com/Dornhoth/b4f82ffdf9f1e56fcc61efe6b2a5ee11/raw/2301a8c6a41e667957bf939a08186dee02c3bf3e/test.component.ts) [test.component.ts](https://gist.github.com/Dornhoth/b4f82ffdf9f1e56fcc61efe6b2a5ee11###file-test-component-ts) hosted with ❤ by [GitHub](https://github.com)
```javascript
import { Injectable } from '@angular/core';

@Injectable()
export class TestService {

    getTest(): string {
        return 'test';
    }
}
```
[view raw](https://gist.github.com/Dornhoth/b4f82ffdf9f1e56fcc61efe6b2a5ee11/raw/2301a8c6a41e667957bf939a08186dee02c3bf3e/test.service.ts) [test.service.ts](https://gist.github.com/Dornhoth/b4f82ffdf9f1e56fcc61efe6b2a5ee11###file-test-service-ts) hosted with ❤ by [GitHub](https://github.com)

---
```javascript
import { Injectable } from '@angular/core';

@Injectable()
export class HelloWorldService {
    getTest(): string {
        return 'Hello World!';
    }
}
```
[view raw](https://gist.github.com/Dornhoth/08b87bbfce4eadf2ca5356a9feb8dc86/raw/3e32a149b0546bacc6eda0ccde3e96dee972a7a5/hello-word.service.ts) [hello-word.service.ts](https://gist.github.com/Dornhoth/08b87bbfce4eadf2ca5356a9feb8dc86###file-hello-word-service-ts) hosted with ❤ by [GitHub](https://github.com)
```javascript
import { Component, OnInit } from '@angular/core';
import { TestService } from 'src/app/services/test.service';
import { HelloWorldService } from 'src/app/services/hello-world.service';

@Component({
    selector: 'app-test',
    templateUrl: './test.component.html',
    styleUrls: ['./test.component.scss'],
    providers: [{ provide: TestService, useClass: HelloWorldService }]
})
export class TestComponent implements OnInit {
    text: string;
    constructor(private testService: TestService) { }

    ngOnInit() {
        this.text = this.testService.getTest();
    }

}
```
[view raw](https://gist.github.com/Dornhoth/08b87bbfce4eadf2ca5356a9feb8dc86/raw/3e32a149b0546bacc6eda0ccde3e96dee972a7a5/test.component.ts) [test.component.ts](https://gist.github.com/Dornhoth/08b87bbfce4eadf2ca5356a9feb8dc86###file-test-component-ts) hosted with ❤ by [GitHub](https://github.com)

---
```javascript
import { Component, OnInit } from '@angular/core';
import { TestService } from 'src/app/services/test.service';
import { HelloWorldService } from 'src/app/services/hello-world.service';

@Component({
    selector: 'app-test',
    templateUrl: './test.component.html',
    styleUrls: ['./test.component.scss'],
})
export class TestComponent implements OnInit {
    text: string;
    constructor(private testService: TestService) { }

    ngOnInit() {
        this.text = this.testService.getTest();
    }
}
```
[view raw](https://gist.github.com/Dornhoth/eae343f05519262dcd39e438e63a1f46/raw/f14472f932c146061d98dea428ab4128591e5389/test.component.ts) [test.component.ts](https://gist.github.com/Dornhoth/eae343f05519262dcd39e438e63a1f46###file-test-component-ts) hosted with ❤ by [GitHub](https://github.com)


```javascript
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class TestService {

    getTest(): string {
        return 'test';
    }
}
```

[view raw](https://gist.github.com/Dornhoth/eae343f05519262dcd39e438e63a1f46/raw/f14472f932c146061d98dea428ab4128591e5389/test.service.ts) [test.service.ts](https://gist.github.com/Dornhoth/eae343f05519262dcd39e438e63a1f46###file-test-service-ts) hosted with ❤ by [GitHub](https://github.com)

---
```html
<app-test></app-test>

<div>Number of service instances : {{serviceInstances}}</div>
```
[view raw](https://gist.github.com/Dornhoth/20af7b789ec12f7e4ae5844014954ea2/raw/c862d6e4a795aa73b451dcbc42446ef89c3f221d/app.component.html) [app.component.html](https://gist.github.com/Dornhoth/20af7b789ec12f7e4ae5844014954ea2###file-app-component-html) hosted with ❤ by [GitHub](https://github.com)
```javascript
import { Component, OnInit } from '@angular/core';
import { TestService } from './services/test.service';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {

    title = 'providers';
    serviceInstances: number;

    constructor(private testService: TestService) { }

    ngOnInit() {
        this.serviceInstances = this.testService.numberOfInstances;
    }

}
```
[view raw](https://gist.github.com/Dornhoth/20af7b789ec12f7e4ae5844014954ea2/raw/c862d6e4a795aa73b451dcbc42446ef89c3f221d/app.component.ts) [app.component.ts](https://gist.github.com/Dornhoth/20af7b789ec12f7e4ae5844014954ea2###file-app-component-ts) hosted with ❤ by [GitHub](https://github.com)
```javascript
import { Component, OnInit } from '@angular/core';
import { TestService } from 'src/app/services/test.service';

@Component({
    selector: 'app-test',
    templateUrl: './test.component.html',
    styleUrls: ['./test.component.scss'],
    providers: [TestService]
})
export class TestComponent implements OnInit {

    text: string;

    constructor(private testService: TestService) { }

    ngOnInit() {
        this.text = this.testService.getTest();
    }
}
```
[view raw](https://gist.github.com/Dornhoth/20af7b789ec12f7e4ae5844014954ea2/raw/c862d6e4a795aa73b451dcbc42446ef89c3f221d/test.component.ts) [test.component.ts](https://gist.github.com/Dornhoth/20af7b789ec12f7e4ae5844014954ea2###file-test-component-ts) hosted with ❤ by [GitHub](https://github.com)

---
```javascript
import { Injectable } from '@angular/core';
@Injectable({
    providedIn: 'root'
})
export class HelloWorldService {
    getTest(): string {
        return 'Hello World!';
    }
}
```

[view raw](https://gist.github.com/Dornhoth/bc6560127c9f9116fd067671fc9416bb/raw/d0e5e9f04b17f73884b1d573b949a20093485c55/hello-word.service.ts) [hello-word.service.ts](https://gist.github.com/Dornhoth/bc6560127c9f9116fd067671fc9416bb###file-hello-word-service-ts) hosted with ❤ by [GitHub](https://github.com)
```javascript
import { Component } from '@angular/core';
import { TestService } from 'src/app/services/test.service';
import { HelloWorldService } from 'src/app/services/hello-world.service';
@Component({
    selector: 'app-parent',
    templateUrl: './parent.component.html',
    styleUrls: ['./parent.component.scss'],
    providers: [{ provide: TestService, useClass: HelloWorldService }]
})
export class ParentComponent { }
```

[view raw](https://gist.github.com/Dornhoth/bc6560127c9f9116fd067671fc9416bb/raw/d0e5e9f04b17f73884b1d573b949a20093485c55/parent.component.ts) [parent.component.ts](https://gist.github.com/Dornhoth/bc6560127c9f9116fd067671fc9416bb###file-parent-component-ts) hosted with ❤ by [GitHub](https://github.com)

```javascript
import { Component, OnInit } from '@angular/core';
import { TestService } from '../../services/test.service';

@Component({
    selector: 'app-test',
    templateUrl: './test.component.html',
    styleUrls: ['./test.component.scss'],
})
export class TestComponent implements OnInit {
    text: string;
    constructor(private testService: TestService) { }

    ngOnInit() {
        this.text = this.testService.getTest();
    }
}
```

[view raw](https://gist.github.com/Dornhoth/bc6560127c9f9116fd067671fc9416bb/raw/d0e5e9f04b17f73884b1d573b949a20093485c55/test.component.ts) [test.component.ts](https://gist.github.com/Dornhoth/bc6560127c9f9116fd067671fc9416bb###file-test-component-ts) hosted with ❤ by [GitHub](https://github.com)
```javascript
import { Injectable } from '@angular/core';
@Injectable({ providedIn: 'root' })
export class TestService {

    getTest(): string {
        return 'test';
    }
}
```
---

# The Most Difficult Angular Interview Question 

### Understanding Angular's Change Detection

Angular uses a **zone-based change detection mechanism**. At the core of it is the **NgZone**, which patches async events (like setTimeout, HTTP requests, DOM events, etc.) to notify Angular when to run change detection.

Whenever an event occurs that _could_ affect the UI, Angular:

1.  Runs change detection starting from the root component.
2.  Walks through the component tree.
3.  Compares the current model to the previous state.
4.  Updates the DOM where differences are found.

This mechanism works great out of the box, but in large apps, it can cause performance bottlenecks because **every async event can trigger a full tree check**.

#### The Real Interview Challenge: Optimizing It

This is where most developers stumble. Understanding change detection is one thing. **Optimizing it** is where real Angular expertise shines.

**Here are some key techniques:**

### 1. Using `ChangeDetectionStrategy.OnPush`

By default, Angular uses `ChangeDetectionStrategy.Default`, which checks every component on every change.

**Switching to** `**OnPush**` **means Angular will only check the component when:**

-   Its `@Input()` references change
-   An event inside the component occurs
-   You manually trigger detection

**This is huge for performance.**
```javascript
@Component({  
  selector: 'app-optimized',  
  template: `...`,  
  changeDetection: ChangeDetectionStrategy.OnPush  
})  
export class OptimizedComponent { }
```
### 2. Detaching Change Detection

For even more control, you can detach change detection from parts of the app:
```javascript
constructor(private cdr: ChangeDetectorRef) {  
  this.cdr.detach();  
}
```
You can then manually trigger it using `cdr.detectChanges()` only when needed.

This is useful for components that change very rarely, like charts or static displays.

### 3. Avoiding Unnecessary Triggers

**Be mindful of:**

-   **Large forms**: Break them into smaller components with `OnPush`.
-   **Timers and Intervals**: These constantly trigger change detection. Use `NgZone.runOutsideAngular()` when possible.
-   **Third-party libraries**: Some libraries might trigger change detection unintentionally.

### 4. Running Code Outside Angular Zone

You can avoid triggering change detection by running expensive or non-UI logic outside Angular's zone:
```javascript
constructor(private ngZone: NgZone) {}

startProcess() {  
  this.ngZone.runOutsideAngular(() => {  
    setTimeout(() => {  
      // Long-running task  
      this.ngZone.run(() => {  
        // Re-enter Angular and update the UI  
      });  
    });  
  });  
}
```
---
## Angular Interview Question - 11
## ng-content

_ng-content_ is used to project content into Angular components. In plain HTML, you can create children in any element, like this:
```html
<iframe src="https://codeburst.io/media/420d4341b36da7778801a38392808afe" allowfullscreen="" frameborder="0" height="190" width="680" title="parent-child.html" class="eo n hi dz bg" scrolling="no"></iframe>
```
If instead of _divs_ you do something similar with Angular components, your child _div_ won't be displayed... except if you tell Angular where to display it in the parent template using _ng-content_.
```html
<iframe src="https://codeburst.io/media/72926f759287d8fb482560821995457c" allowfullscreen="" frameborder="0" height="270" width="680" title="content-projection" class="eo n hi dz bg" scrolling="no"></iframe>
```
This example would render this:

![](https://miro.medium.com/v2/resize:fit:309/1*sW2ifyOF9ogQ1wYPPYEYaA.png)

You can even differentiate between children and display them in different places in the parent component using the _select_ attribute:

The two _divs_ are rendered where they are selected. We select over the class here, but you can use any CSS selector. It would render this way:

![](https://miro.medium.com/v2/resize:fit:498/1*U3-bcsv4XZ7ecm9m32H-Lw.png)

## ng-container

_ng-container_ is an extremely simple directive that allows you to group elements in a template but doesn't itself get rendered in the DOM (but what it contains does). It just becomes a comment:

![](https://miro.medium.com/v2/resize:fit:744/1*odCZuMQzXTIUwwn5FNPuIw.png)

It is especially helpful when you want to apply two structural directives to the same element. As you might know, you can't write anything like this:

You may only apply one structural directive to an element, so whether _*ngIf_ or _*ngFor_ but not both. You could add a _div_ or a _span_ in between to apply the second directive to, but in our case we would have empty _li_ or invalid HTML.

On the other hand, if you replace the _span_ in the previous example with a _ng-container_ you can apply your two structural directives and keep your HTML valid: _the ng-container_ is not rendered in the DOM.

![](https://miro.medium.com/v2/resize:fit:875/1*Sa3Xx9OcALZjk8b3JgeB2g.png)

## ng-template

_ng-template_ is used to render HTML in a template but is never rendered directly. If you add a _ng-template_ tag to your template, it and everything inside it will be replaced by a comment.

![](https://miro.medium.com/v2/resize:fit:721/1*2zTXvaJipsUQPVhBF0ns8Q.png)

It might seem a bit useless, but it is rarely used alone. It can be for example used to define the _else_ case of an _*ngIf._

You can create a reference to your _ng-template_ and use it in the _else_ clause. It can also be used with _ng-switch_ and your can reference it in your TypeScript code to do whatever you want with it.

To sum up, _ng-content_ is used to display children in a template, _ng-container_ is used as a non-rendered container to avoid having to add a _span_ or a _div_, and _ng-template_ allows you to group some content that is not rendered directly but can be used in other places of your template or you code.

#### Embedded Content
```html
<div class="parent">

Parent

<div class="child">

Child

</div>

</div>
```
[view raw](https://gist.github.com/Dornhoth/7e8dca7732653e1891d197d6bb005ade/raw/71aa88d4313414b6634305e10c19ecc05d7936b3/parent-child.html) [parent-child.html](https://gist.github.com/Dornhoth/7e8dca7732653e1891d197d6bb005ade##file-parent-child-html) hosted with ❤ by [GitHub](https://github.com)

---
```html
<app-wrapper>

<div style="background-color: green; padding: 20px">

Child

</div>

</app-wrapper>
```
[view raw](https://gist.github.com/Dornhoth/f03e3e40b1d7d891685be98442c75ac1/raw/3c2e6216ffcee2386957a64b3e66ce86a0c7c878/smart.component.html) [smart.component.html](https://gist.github.com/Dornhoth/f03e3e40b1d7d891685be98442c75ac1##file-smart-component-html) hosted with ❤ by [GitHub](https://github.com)
```html
<div style="background-color: red; padding: 20px">

Wrapper

<ng-content></ng-content>

</div>
```
[view raw](https://gist.github.com/Dornhoth/f03e3e40b1d7d891685be98442c75ac1/raw/3c2e6216ffcee2386957a64b3e66ce86a0c7c878/wrapper.component.html) [wrapper.component.html](https://gist.github.com/Dornhoth/f03e3e40b1d7d891685be98442c75ac1##file-wrapper-component-html) hosted with ❤ by [GitHub](https://github.com)

---

# Angular Interview Questions 

### 31. How do you implement lazy loading in Angular modules?

-   Explain the importance of lazy loading in optimizing performance.
-   Use Angular Router to load modules on demand.

```javascript
const routes: Routes = [  
  { path: 'feature', loadChildren: () => import('./feature/feature.module').then(m => m.FeatureModule) }  
];

@NgModule({  
  imports: [RouterModule.forRoot(routes)],  
  exports: [RouterModule]  
})  
export class AppRoutingModule {}
```
The application only loads the feature module when the user navigates to the `feature` route, improving load time.

### 32. What are Angular Universal and its use cases?
-   Explain server-side rendering (SSR) and its benefits like SEO and faster initial load.
-   Discuss integrating Angular Universal in an Angular project.

```shell
ng add @nguniversal/express-engine  
npm run build:ssr  
npm run serve:ssr
```

Angular Universal renders the app on the server, improving performance and SEO.

### 33. How do you implement route guards in Angular?
-   Explain the types of route guards: `CanActivate`, `CanDeactivate`, `Resolve`, etc.
-   Demonstrate using `CanActivate` for authentication.

```javascript
@Injectable({ providedIn: 'root' })  
export class AuthGuard implements CanActivate {  
  canActivate(): boolean {  
    return !!localStorage.getItem('token');  
  }  
}

const routes: Routes = [  
  { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] }  
];
```

Prevents unauthorized users from accessing protected routes.

### 34. What is the purpose of Angular's Renderer2?

-   Discuss how `Renderer2` abstracts DOM manipulation to ensure compatibility across platforms.
-   Demonstrate dynamically adding an element to the DOM.

```javascript
constructor(private renderer: Renderer2, private el: ElementRef) {}

ngOnInit() {  
  const div = this.renderer.createElement('div');  
  this.renderer.appendChild(this.el.nativeElement, div);  
}
```
Ensures safe and platform-agnostic DOM manipulations.

### 35. How do you optimize bundle size in Angular applications?

-   Discuss techniques like tree shaking, lazy loading, and the `--prod` build.
-   Use Angular CLI commands to generate optimized builds.


```shell
ng build --prod --source-map=false
```

Reduces the final bundle size, leading to faster load times and improved performance.

### 36. How do you handle long-running HTTP requests in Angular?

-   Use RxJS operators like `retry`, `timeout`, and `switchMap`.
-   Demonstrate aborting requests using `takeUntil`.

```javascript
const unsubscribe$ = new Subject();

this.http.get('/api/data').pipe(  
  takeUntil(unsubscribe$)  
).subscribe();

ngOnDestroy() {  
  unsubscribe$.next();  
  unsubscribe$.complete();  
}
```
Improves user experience by handling failed or long-running requests efficiently.

### 37. Explain Angular's ViewChild and ContentChild decorators.
-   Discuss their purpose in querying child components or DOM elements.
-   Highlight the difference between `ViewChild` (template DOM) and `ContentChild` (projected DOM).

```javascript
@ViewChild('myTemplateRef') templateRef: TemplateRef<any>;  
@ContentChild('myContentRef') contentRef: ElementRef;
```
Access and manipulate child components or DOM elements programmatically.

### 38. What are Angular's structural directives, and how do you create one?
-   Explain directives like `*ngIf` and `*ngFor`.
-   Demonstrate creating a custom structural directive.
```javascript
@Directive({ selector: '[appCustomIf]' })  
export class CustomIfDirective {  
  constructor(private templateRef: TemplateRef<any>, private viewContainer: ViewContainerRef) {}

@Input() set appCustomIf(condition: boolean) {  
    if (condition) {  
      this.viewContainer.createEmbeddedView(this.templateRef);  
    } else {  
      this.viewContainer.clear();  
    }  
  }  
}
```

Conditionally adds or removes elements from the DOM.

### 39. How do you configure progressive web apps (PWAs) in Angular?
-   Use Angular CLI to add PWA support.
-   Discuss configuring `ngsw-config.json` for caching and offline support.

```shell
ng add @angular/pwa
```
Transforms the Angular app into a PWA with offline capabilities and improved performance.

### 40. How do you debug Angular applications effectively?
-   Use tools like Augury, Chrome DevTools, and Angular CLI's debugging commands.
-   Demonstrate using `ng.profiler` to analyze change detection cycles.

```javascript
ng.profiler.timeChangeDetection();
```
Identifies performance bottlenecks and improves application efficiency.

### Conclusion:

In this fourth and final part, we explored advanced concepts like Angular Universal, lazy loading, PWAs, and debugging strategies. Mastering these topics will equip you to solve complex challenges in real-world applications and ace SDE2 interviews at top MNCs.

🚀 **Master Angular for SDE2 Interviews: Part 4 Highlights**

In the final installment of our Angular interview preparation series, we delved into the following advanced topics:

-   **Lazy Loading**: Optimize performance with on-demand module loading.
-   **Angular Universal**: Implement server-side rendering for SEO and speed.
-   **Route Guards**: Secure routes with `CanActivate` and other guards.
-   **Renderer2**: Ensure platform-agnostic DOM manipulation.
-   **Progressive Web Apps (PWAs)**: Add offline capabilities for a seamless user experience.


---

# Angular Interview Questions and Answers

### **Q1. What is Angular 4 and how it differs from Angular 1.x?

Angular 4 is a Javascript framework built around the concept of components, and more precisely, with the Web Components standard in mind. It was rewritten from scratch by the Angular team using Typescript (although we can use it with _ES5_, _ES6_, or _Dart_ as well).

Angular 4 is a big change for us compared to 1.x. Because it is a completely different framework than 1.x, and is not backward-compatible. Angular 4 is written entirely in Typescript and meets the ECMAScript 6 specification. The main differences are:

-   Angular 4 is entirely component based. `Controllers` and `$scope` are no longer used. They have been replaced by components and directives.
-   Angular 4 uses TypeScript. TypeScript will not be used in the browser directly. So the program code is compiled to JavaScript. This can be achieved with “Traceur”.
-   The digest cycle from Angular 1.x has been replaced by another internal mechanism known as “**Change Detection**”. This feature, along with other improvements and tweaks, yields a considerable increase in performance.
-   Unlike Angular 1.x where we can get most of the functionalities in angular.js file, Angular 4 follows module pattern. We need to import the functions ourself and export them when we need anywhere else.
-   There are no more `factory`, `service`, `provider` in Angular 4. We need to use `class` for declaring a service.

### **Q2. What is component decorators in Angular 4?

The main objectives of decorators is to add some metadata to the class that will tell Angular 4 how to process a class. Or in another words, Decorators are functions that modify JavaScript classes. Angular has many decorators that attach metadata to classes so that it knows what those classes mean and how they should work.

If we consider Component in Angular 4, we will have following options to configure.

-   **selector:** — define the name of the HTML element in which our component will live.
-   **template** or **templateUrl:** — It can be inline string or link an external html file. It allows us to tie logic from our component directly to a view.
-   **styles:** — the styles array for our specific component. We can also link external CSS by **styleUrls**.
-   **directives:** — another component directives we want to use inside our components.
-   **providers:** — This is the place we are passing the services that we need insider our components.

Immediately after this decorator or right to it, we need to export a class where our variables and functions reside that our component uses.

![](https://miro.medium.com/v2/resize:fit:611/1*vPd3-cKqWDx0GwxT2sU-9g.jpeg)

### **Q3. What is compilation in Angular 4? And what are the types of compilation in Angular 4?

An Angular application consists largely of components and their HTML templates. Before the browser can render the application, the components and templates must be converted to executable JavaScript by the _Angular compiler_.

There is actually only one Angular compiler. The difference between AOT and JIT is a matter of timing and tooling. There are two types of compilation Angular 4 provides.

-   **Just-in-time (JIT) compilation:** This is a standard development approach which compiles our Typescript and html files in the browser at runtime, as the application loads. It is great but has disadvantages. Views take longer to render because of the in-browser compilation step. App size increases as it contains angular compiler and other library code that won't actually need.
-   **Ahead-of-time (AOT) compilation:** With AOT, the compiler runs at the build time and the browser downloads only the pre compiled version of the application. The browser loads executable code so it can render the application immediately, without waiting to compile the app first. This compilation is better than JIT because of Fast rendering, smaller application size, security and detect template errors earlier.

### **Q4. What is** `**@NgModule**`**?

An `NgModule` class describes how the application parts fit together. Every application has at least one `NgModule`, the root module that we bootstrap to launch the application.

![](https://miro.medium.com/v2/resize:fit:814/1*9pRJxfO4TIHUe-hUDHitfg.jpeg)

Here the `AppComponent` is the root module of our application that Angular creates and inserts it into the `index.html` page.

### **Q5. What are all the _metadata_ properties of** `**NgModule**`**? And what are they used for?

`@NgModule` accepts a metadata object that tells Angular how to compile and launch the application. The properties are:

-   `**imports**` – Modules that the application needs or depends on to run like, the `BrowserModule` that every application needs to run in a browser.
-   `**declarations**` – the application's components, which belongs to the `NgModule`class. We must declare every component in an `NgModule` class. If we use a component without declaring it, we'll see a clear error message in the browser console.
-   `**bootstrap**` – the root component that Angular creates and inserts into the `index.html` host web page. The application will be launched by creating the components listed in this array.

### **Q6. What is Template reference variables?

A template reference variable (`#var`) is a reference to a DOM element within a template. We use hash symbol (#) to declare a reference variable in a template.

![](https://miro.medium.com/v2/resize:fit:660/1*gQZoMBShop0j4NWXXKnGow.jpeg)

In the above code the `#name` declares a variable on the `input` element. Here the `name` refers to the `_input_` element. Now we can access any property of the `input`DOM, using this reference variable. For example, we can get the value of the `input`element as `name.value` and the value of the placeholder property by `name.placeholder` anywhere in the template.

Finally, a Template reference variable refers to its attached element, component or directive. It can be accessed anywhere in the entire template. We can also use `ref-` instead of #. Thus we can also write the above code as `ref-name`.

### **Q7. What are structural directives?

Structural directives are responsible for HTML layout. They shape or reshape the DOM's structure, typically by adding, removing, or manipulating elements. Structural directives are easy to recognize. An asterisk (*) precedes the directive attribute name as in this example.

![](https://miro.medium.com/v2/resize:fit:701/1*_fkCkQaNF1xvqGXMCTlKMw.jpeg)

The `ngFor` directive iterates over the component's `names` array and renders an instance of this template for each `name` in that array.

Some of the other structural directives in Angular are `ngIf` and `ngSwitch`.

### **Q8. What is Directive in Angular 4? How it differs from Components?

Directives allow us to attach behavior to elements in the DOM, for example, doing something on mouse over or click. In Angular, a Directive decoraor (`@Directive`) is used to mark a class as an Angular directive and provides additional metadata that determines how the directive should be processed. Below are the metadata properties of a directive.

-   `selector` - css selector that identifies this component in a template
-   `host` - map of class property to host element bindings for events, properties and attributes
-   `inputs` - list of class property names to data-bind as component inputs
-   `outputs` - list of class property names that expose output events that others can subscribe to
-   `providers` - list of providers available to this component and its children
-   `queries` - configure queries that can be injected into the component
-   `exportAs` - name under which the component instance is exported in a template

A Component is a directive with a template. So we should use a Component whenever we want reusable set of DOM elements with behaviors of UI. And we should use a Directive whenever we want reusable behavior to supplement the DOM.

### **Q9. What are all the types of Directives?

There are three types of directives in Angular. They are **attribute directives**, **structural directives**, and **components**.

-   **Structural directives** change the DOM layout by adding and removing DOM elements. For example, `*ngIf` and `*ngFor`
-   **Attribute directives** change the appearance or behavior of an element. . For example, `*ngStyle` and `*ngClass`
-   **Components** are basically directives with a template.

### **Q10. What are all the uses of a service?

Services encapsulates business logic and separates them from UI concerns or the controller concerns, which governs them both.

Services focus on functionality thus benefits in maintainability. The separation of UI logic from business logic is intended to reduce the coupling between the UI layer and the Model layer, leading to a cleaner design that is easier to develop, test, and maintain.

### **Q11. What is Pure and Impure Pipes?

`Pure pipes` are stateless that flow input date without remembering anything or causing detectable side-effects. Pipes are pure by default, hence most pipes are pure. We can make a pipe impure by setting its pure flag to `false`. Angular executes a pure pipe only when it detects a _pure_ change to the input value. A pure change is either a change to a primitive input value or a changed object reference.

`Impure pipes` are those which can manage the state of the data they transform. A pipe that creates an HTTP request, stores the response and displays the output, is a impure or stateful pipe. Stateful Pipes should be used cautiously. Angular provides `AsyncPipe`, which is stateful. In the following code, the pipe only calls the server when the request URL changes and it caches the server response. The code uses the Angular http client to retrieve data:

![](https://miro.medium.com/v2/resize:fit:745/1*-5j-XE0WK3mt17j55WyZMQ.jpeg)

### **Q12. What is Redux and** `**@ngRx**`**?

Redux is an application state manager for JavaScript applications, and keeps with the core principles of the Flux-architecture by having a unidirectional data flow in our application. Redux applications have only one global, read-only application state. This state is calculated by “reducing” over a collection or stream of actions that update it in controlled ways.

`@ngrx` is a set of modules that implement the same way of managing state as well as some of the middleware and tools in the Redux ecosystem. In other way, `ngrx` is a collection of reactive libraries for angular, containing a redux implementation and many other useful libraries.

Using this technique, we keep our application state in Store and everything saved in the store is read only. The only way to change the state is to emit an action, an object describing what happened.

### **Q13. How to prevent security threads in Angular App? What are all the ways we could secure our App?

Some of them are:

-   Avoid using/injecting dynamic HTML content to your component.
-   If using external HTML which is coming from database or somewhere outside the application, sanitize it before using.
-   Try not to put external urls in the application unless it is trusted. Avoid url re-direction unless it is trusted.
-   Consider using AOT compilation or offline compilation.
-   Try to prevent XSRF attack by restricting the api and use of the app for known or secure environment/browsers.

### **Q14. How to optimize Angular app?

-   Consider lazy loading instead of fully bundled app if the app size is more.
-   Make sure that any 3rd party library, which is not used, is removed from the application.
-   Have all dependencies and dev-dependencies are clearly separated.
-   Make sure the application doesn't have un-necessary import statements.
-   Make sure the application is bundled, uglified, and tree shaking is done.
-   Consider AOT compilation.

### **Q15. What is** `**NgZone**` **service? How Angular is notified about the changes?

`Zone.js` is one of the Angular dependencies which provides a mechanism, called zones, for encapsulating and intercepting asynchronous activities in the browser (e.g. `setTimeout`, `setInterval`, `promises`). These zones are _execution contexts_ that allow Angular to track the start and completion of asynchronous activities and perform tasks as required (e.g. change detection). Zone.js provides a global zone that can be forked and extended to further encapsulate/isolate asynchronous behaviour, which Angular does so in its `NgZone` service, by creating a fork and extending it with its own behaviours.

The `NgZone` service provides us with a number of Observables and methods for determining the state of Angular's zone and to execute code in different ways inside and outside Angular's zone.

`NgZone` exposes a set of Observables that allow us to determine the current status, or stability, of Angular's zone.

-   `onUnstable` – Notifies when code has entered and is executing within the Angular zone.
-   `onMicrotaskEmpty` - Notifies when no more microtasks are queued for execution. Angular subscribes to this internally to signal that it should run change detection.
-   `onStable` – Notifies when the last `onMicroTaskEmpty` has run, implying that all tasks have completed and change detection has occurred.
-   `onError` – Notifies when an error has occurred. Angular subscribes to this internally to send uncaught errors to its own error handler, i.e. the errors you see in your console prefixed with 'EXCEPTION:'.

We can inject the `NgZone` service in our component/services/etc. and can subscribe to these observables.

![](https://miro.medium.com/v2/resize:fit:744/1*Qx8bfkhjvLRrsQ8cgD4IQw.jpeg)

Subscribing to these can help you determine if your code is unexpectedly triggering change detection as a result of operations that do not affect application state.

### **Q16. What is Traceur compiler?

Traceur compiler is a Google project. It compiles ECMAScript Edition 6 (ES6) (including classes, generators and so on) code on the fly to regular Javascript (ECMAScript Edition 5 [ES5]) to make it compatible for the browser.

Traceur itself is written in ES6, compiled to ES5.

---

#  20 Angular Interview Questions You Must Know in 2024

###  **1. What is Angular?**

**Answer:**  
Angular is a TypeScript-based open-source framework by Google for building single-page web applications (SPAs).

###  2. What are the components in Angular?

**Answer:**  
Components are the basic building blocks of Angular applications.  
**Code Example:**
```javascript
@Component({  
  selector: 'app-root',  
  template: `<h1>Welcome to Angular</h1>`,  
})  
export class AppComponent {}
```
###  **3. How does two-way data binding work?**

**Answer:**  
Two-way binding allows data synchronization between the component and the view. Use [(ngModel)].  
**Code Example:**
```html
<input [(ngModel)]="name" placeholder="Enter name">  
<p>Hello, {{ name }}</p>
```
###  **4. What are directives in Angular?**

**Answer:**  
Directives are instructions for the DOM. Common types are:

-   **Structural Directives:** e.g., *ngIf, *ngFor.
-   **Attribute Directives:** e.g., ngClass, ngStyle.  
    **Code Example:**
```html
<div *ngIf="isVisible">Content is visible</div>  
<ul>  
  <li *ngFor="let item of items">{{ item }}</li>  
</ul>
```
###  5. How do you define services and use dependency injection?

**Answer:**  
Services are reusable logic providers. Use `@Injectable` and inject them into components.  
**Code Example:**
```javascript
@Injectable({ providedIn: 'root' })  
export class DataService {  
  getData() {  
    return ['Angular', 'React', 'Vue'];  
  }  
}
```

**In a Component:**
```javascript
constructor(private dataService: DataService) {

} 

ngOnInit() {  
  this.data = this.dataService.getData();  
}
```

###  **6 . What is the difference between template-driven and reactive forms?**

**Answer:**

-   Template-driven forms use HTML with directives like ngModel.
-   Reactive forms use a model-driven approach with FormGroup.  
    **Template-Driven Form:**
```html
<form ### myForm="ngForm">  
  <input ngModel name="email" required>  
</form>
```
**Reactive Form:**
```javascript
this.form = new FormGroup({  
  email: new FormControl('', [Validators.required, Validators.email]),  
});
```

###  7. How does Angular routing work?

**Answer:**  
Angular Router maps URLs to components.

**Code Example:**
```javascript
const routes: Routes = [  
  { path: '', component: HomeComponent },  
  { path: 'about', component: AboutComponent },  
];  
@NgModule({  
  imports: [RouterModule.forRoot(routes)],  
})  
export class AppRoutingModule {}
```
###  8. How do you use lifecycle hooks in Angular?

**Answer:**  
Lifecycle hooks manage component states.

Example: `ngOnInit`.  
**Code Example:**
```javascript
export class AppComponent implements OnInit {  
  ngOnInit() {  
    console.log('Component Initialized');  
  }  
}
```
###  9. How do you create a custom pipe?

**Answer:**  
Use `@Pipe` to create custom transformations.  
**Code Example:**
```javascript
@Pipe({ name: 'capitalize' })  
export class CapitalizePipe implements PipeTransform {  
  transform(value: string): string {  
    return value.charAt(0).toUpperCase() + value.slice(1);  
  }  
}
```
**Usage:**
```html
<p>{{ 'angular' | capitalize }}</p>
```
###  10. What is lazy loading in Angular?

**Answer:**  
Lazy loading loads feature modules on demand.  
**Code Example:**
```javascript
const routes: Routes = [  
  { path: 'admin', loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule) },  
];
```
###  11. How does Angular handle HTTP requests?

**Answer:**  
Angular uses `HttpClient` for HTTP operations.  
**Code Example:**

```javascript
constructor(private http: HttpClient) {

} 

fetchData() {  
  this.http.get('/api/data').subscribe(data => console.log(data));  
}
```

###  12. How do you handle errors in Angular?

**Answer:**  
Use `catchError` from RxJS.  
**Code Example:**
```javascript
this.http.get('/api/data')  
  .pipe(catchError(err => of(`Error: ${err}`)))  
  .subscribe(console.log);
```

###  13. What is Angular Universal?

**Answer:**  
Angular Universal enables server-side rendering (SSR) to improve SEO and performance.

###  14. How do you create a reactive form with validation?

**Answer:**  
**Code Example:**
```javascript
this.form = new FormGroup({  
  email: new FormControl('', [Validators.required, Validators.email]),  
});
```

**Template:**
```html
<form [formGroup]="form">  
  <input formControlName="email">  
  <div *ngIf="form.get('email').invalid">Invalid email</div>  
</form>
```
###  15. What is a guard in Angular?

**Answer:**  
Guards control navigation. Use `CanActivate`.  
**Code Example:**
```javascript
@Injectable({ providedIn: 'root' })  
export class AuthGuard implements CanActivate {  
  canActivate(): boolean {  
    return isLoggedIn(); // Custom logic  
  }  
}
```

###  16. How does Angular detect changes?

**Answer:**  
Angular's change detection uses a tree-based mechanism to update the DOM when data changes.

###  17. How do you optimize an Angular application?

**Answer:**  
Use techniques like lazy loading, AOT compilation, and OnPush change detection.

###  18. What are resolvers in Angular?

**Answer:**  
Resolvers pre-fetch data before a route is activated.  
**Code Example:**
```javascript
@Injectable({ providedIn: 'root' })  
export class DataResolver implements Resolve<any> {  
  resolve() {  
    return this.dataService.getData();  
  }  
}
```

###  19. How do you handle child routes?

**Answer:**  
**Code Example:**
```javascript
const routes: Routes = [  
  { path: 'parent', component: ParentComponent, children: [  
    { path: 'child', component: ChildComponent },  
  ]},  
];
```
###  20. What is Angular's Ivy renderer?

**Answer:**  
Ivy is Angular's new renderer for faster compilation and smaller bundle sizes.

### 1. How Does Angular Change Detection Work Internally?

#### Why It's Hard:

Many developers know that Angular uses change detection to update the DOM when the application's state changes. However, understanding the intricacies of the change detection mechanism, like how Angular tracks changes, the role of zones, or how change detection strategies work, can be challenging.

#### Why It's Important:

This question tests your understanding of Angular's internal workings and performance optimization. Improper or inefficient change detection strategies can lead to performance bottlenecks, especially in large applications.

#### Key Concepts to Prepare:

-   **Zones and Zone.js:** Zone.js allows Angular to track asynchronous operations and trigger change detection when necessary.
-   **Default vs. OnPush Change Detection:** Understand how each strategy impacts the performance of your application and when to use each.
-   **Change Detection Phases:** Familiarize yourself with the lifecycle of change detection, including when Angular checks for changes and when it's triggered (e.g., after events, HTTP responses, etc.).

### 2. How Does Angular Handle Memory Leaks?

#### Why It's Hard:

Memory leaks are often a result of improper handling of observables, subscriptions, and component lifecycle. While this is something most developers face in their projects, it's rarely the focus of an interview prep.

#### Why It's Important:

A deep understanding of memory management ensures your application performs well even as it grows. Interviewers want to know that you're capable of writing efficient, maintainable code and you know how to handle resources like subscriptions, event listeners, and services.

#### Key Concepts to Prepare:

-   **Unsubscribing from Observables:** Always unsubscribe from observables to avoid memory leaks. Use `takeUntil` or the `async` pipe to handle this more cleanly.
-   **Weak References and Garbage Collection:** Know how JavaScript's garbage collection works and how Angular interacts with it.
-   **ngOnDestroy:** Understand how to clean up resources when a component is destroyed.

### 3. What Are Some Techniques to Improve Angular Performance?

#### Why It's Hard:

Performance optimization is often an afterthought, but it's critical, especially in large-scale applications. Developers may be familiar with basic techniques, but there are many advanced methods that might not be part of standard interview preparation.

#### Why It's Important:

Angular applications can become slow and unresponsive if not properly optimized. Knowing performance optimization techniques demonstrates your ability to handle scaling, which is a vital skill for large projects.

#### Key Concepts to Prepare:

-   **Lazy Loading:** Learn how to split your application into smaller bundles to load only when needed.
-   **OnPush Change Detection Strategy:** Use OnPush to reduce the frequency of change detection cycles.
-   **TrackBy in ngFor:** Use `trackBy` to optimize DOM rendering by keeping track of which items in a list have changed.
-   **Ahead-of-Time (AOT) Compilation:** Ensure that your application is precompiled for better performance in production.

### 4. Explain the Role of `ng-content` in Angular and Its Use Cases.

#### Why It's Hard:

`ng-content` is one of those features that many developers are not fully comfortable with, despite it being a core concept of Angular. It allows content projection, enabling more reusable and flexible components, but many people don't know when or why to use it effectively.

#### Why It's Important:

Interviewers ask this question to test your understanding of Angular's component-based architecture and its ability to create customizable, reusable components.

#### Key Concepts to Prepare:

-   **Content Projection:** Understand how `ng-content` works as a placeholder for dynamic content passed to a component.
-   **Multiple ng-content:** Learn how to use multiple `ng-content` elements for more complex content projection scenarios.
-   **Use in Angular Material:** Many Angular Material components rely on `ng-content` for injecting custom content into components.

### 5. How Would You Handle Global State Management in Angular?

#### Why It's Hard:

Angular doesn't come with a built-in state management solution (unlike other frameworks like Redux for React). While libraries like NgRx and Akita are popular for state management, handling global state effectively can be complex, and interviewers may ask about best practices and trade-offs.

#### Why It's Important:

Global state management is key for complex Angular applications. This question tests whether you can design a clean architecture that avoids issues like prop drilling and allows for efficient and scalable state handling.

#### Key Concepts to Prepare:

-   **Services and Dependency Injection (DI):** Learn how Angular services can act as a simple state management solution.
-   **NgRx vs. Akita:** Understand the trade-offs between NgRx (based on Redux) and simpler state management solutions like Akita.
-   **Observable-Based State:** Using RxJS operators to manage state reactively and ensuring that updates are efficient.

### 6. Can You Explain the Difference Between `HttpClient` and `HttpInterceptor`?

#### Why It's Hard:

Many developers are familiar with the `HttpClient` module for making HTTP requests, but the `HttpInterceptor` is often overlooked or not fully understood. Interceptors are a powerful feature for modifying HTTP requests and responses, but how they work internally can be a bit more complex.

#### Why It's Important:

This question tests your understanding of Angular's HTTP client module and how to handle advanced use cases such as authentication, caching, and modifying requests globally.

#### Key Concepts to Prepare:

-   **HttpClient:** Know how to make HTTP requests using `HttpClient` and handle responses with observables.
-   **HttpInterceptor:** Understand how interceptors allow you to modify HTTP requests and responses globally, e.g., adding headers or handling errors.
-   **Request Caching and Retry Mechanisms:** Learn how interceptors can be used for tasks like caching or automatic retries.

### 7. How Would You Approach Testing an Angular Application?

#### Why It's Hard:

Testing in Angular is a wide topic, and while unit testing with Jasmine and Karma is well known, questions may dive deeper into advanced testing scenarios like testing services, directives, or components with complex dependencies.

#### Why It's Important:

The ability to write tests is crucial for ensuring the reliability and maintainability of an application. A well-tested Angular application is easier to scale and debug.

#### Key Concepts to Prepare:

-   **Unit Testing Components/Services:** Know how to mock dependencies and test components/services using `TestBed`.
-   **End-to-End Testing with Protractor or Cypress:** Familiarize yourself with automated end-to-end testing tools.
-   **Test-Driven Development (TDD) and Mocking:** Understand how to follow TDD practices and mock services, HTTP calls, and dependencies during testing.


### 1. What is Angular?

**Question:** _“Can you explain what Angular is and why it's used?”_

**Answer:** Angular is a **JavaScript framework** that helps you build **single-page applications (SPAs)**. It's like a toolbox filled with fancy tools to build complex web apps faster and more efficiently. Think of Angular as a professional chef's kitchen — everything is organized, there's a tool for every task, and it makes cooking up web applications a lot more fun.

You use Angular when you need a **robust** and **scalable** app. It comes with tools like **components**, **services**, and **dependency injection** that make your code **modular** and **testable**.

**Humor Version:** “Angular is like the Swiss Army knife for web development. It's got everything you need — except the corkscrew. That's a Node.js plugin.”

### 2. What are Components in Angular?

**Question:** _“What is a component in Angular, and how do you define one?”_

**Answer:** A **component** is the building block of any Angular app. It's like a Lego block that makes up the entire application. Components are **reusable** and each one contains:

-   **HTML** for the view (template)
-   **CSS** for the style
-   **TypeScript** for the logic

Here's a simple example of a component:
```typescript
import { Component } from '@angular/core';  
  
@Component({  
  selector: 'app-hello',  
  template: `<h1>Hello, {{name}}!</h1>`,  
  styles: [`h1 { color: blue; }`]  
})  
export class HelloComponent {  
  name = 'Angular Developer';  
}
```

In this example, `HelloComponent` will display “Hello, Angular Developer!” with some fancy blue styling. The **selector** `'app-hello'` is the tag you'll use in your HTML to include this component.

**Humor Version:** “Components in Angular are like pizza slices — each one can have its own toppings, but together they make the whole pie. And if you don't like pineapple, well, there's always conditional rendering!”

### 3. What is Data Binding in Angular?

**Question:** _“Explain the concept of data binding in Angular.”_

**Answer:** **Data binding** is how you connect your data (the model) to your view (HTML). Angular offers four types of data binding:

1.  **Interpolation**: Using `{{ }}` to bind data from the component to the view.
```html
<p>Hello, {{ name }}!</p>
```

**2. Property Binding**: Binding DOM properties to component values.
```html
<img [src]="imageUrl" />
```

3. **Event Binding**: Capturing user actions (like clicks) and binding them to methods in the component.
```html
<button (click)="sayHello()">Click Me</button>
```

4. **Two-Way Binding**: Synchronizing data between the component and the view using the `[(ngModel)]` directive.
```html
<input [(ngModel)]="name" />
```

**Humor Version:** “Data binding in Angular is like mind reading, except instead of reading thoughts, you're syncing your variables. One-way, two-way, all the ways! It's like dating, but without the emotional baggage.”

### 4. What is Dependency Injection (DI) in Angular?

**Question:** _“What is dependency injection, and why does Angular use it?”_

**Answer:** **Dependency Injection (DI)** is a fancy term for **getting things you need** without having to create them manually every time. It's like asking your butler to get you a coffee instead of brewing it yourself. In Angular, DI makes it easier to manage your services, classes, and objects. It also makes your code more testable by allowing you to inject mock data when testing.

Here's an example of DI in Angular:
```typescript
import { Injectable } from '@angular/core';  
  
@Injectable({  
  providedIn: 'root',  
})  
export class CoffeeService {  
  getCoffee() {  
    return 'Here's your coffee!';  
  }  
}  
  
@Component({  
  selector: 'app-coffee',  
  template: `<p>{{ coffeeMessage }}</p>`  
})  
export class CoffeeComponent {  
  coffeeMessage: string;  
    
  constructor(private coffeeService: CoffeeService) {  
    this.coffeeMessage = this.coffeeService.getCoffee();  
  }  
}
```

In this example, instead of creating `CoffeeService` inside `CoffeeComponent`, Angular **injects** it for you. Thanks, Angular—butler.

**Humor Version:** “Dependency Injection is like Uber Eats for code — when you need something, it gets delivered straight to your component. And you don't even have to tip!”

### 5. What are Directives in Angular?

**Question:** _“What are Angular directives, and can you name a few?”_

**Answer:** Directives in Angular are like **instructions** you give to HTML elements. They can change the behavior or appearance of elements in your template. There are three types of directives in Angular:

1.  **Component Directives**: Components themselves are directives with a template.
2.  **Structural Directives**: Change the structure of the DOM (`*ngIf`, `*ngFor`)
```html
<!--Before Control flow -->  
<p *ngIf="isLoggedIn">Welcome back!</p>  
  
<!--Control flow -->  
@if(isLoggedIn){  
    <p>Welcome back!</p>  
}
```

3. **Attribute Directives**: Modify the behavior or style of an element (`ngClass`, `ngStyle`).
```html
<p [ngClass]="{ 'text-success': isLoggedIn }">Status: Logged In</p>
```
**Humor Version:** “Directives in Angular are like magic spells for your HTML. Want something to appear or disappear? Use `*ngIf`. Want to loop through your Hogwarts house members? Try `*ngFor`. Just make sure you're not summoning any dark magic (or errors)."

### 6. What are Angular Services?

**Question:** _“What are services in Angular, and why are they used?”_

**Answer:** A **service** in Angular is a class that contains business logic or reusable functionality. Services are designed to be **shared** across components. They help in separating **concerns** and keeping the components focused on the UI.

Services are typically used for:

-   Fetching data from a server
-   Sharing data between components
-   Logging and authentication

Here's a simple example of a service:
```typescript
@Injectable({  
  providedIn: 'root'  
})  
export class AuthService {  
  isLoggedIn = false;  
    
  login() {  
    this.isLoggedIn = true;  
  }  
  
  logout() {  
    this.isLoggedIn = false;  
  }  
}
```

**Humor Version:** “Services in Angular are like that one friend who knows everything. Need data? Need help logging in? They've got your back, and they'll let everyone know you're logged in — whether you like it or not.”

### 7. What is Routing in Angular?

**Question:** _“How does routing work in Angular?”_

**Answer:** Angular **routing** allows you to navigate between different views (or pages) in a **single-page application** (SPA). Instead of loading a new page from the server, Angular dynamically swaps the views based on the route, making the application feel faster.

You configure routing in `app-routing.module.ts` by defining routes like this:
```typescript
const routes: Routes = [  
  { path: 'home', component: HomeComponent },  
  { path: 'about', component: AboutComponent },  
  { path: '', redirectTo: '/home', pathMatch: 'full' },  
];  
  
@NgModule({  
  imports: [RouterModule.forRoot(routes)],  
  exports: [RouterModule]  
})  
export class AppRoutingModule { }
```

**Humor Version:** “Routing in Angular is like Google Maps for your app. Just define your routes and let Angular take you where you want to go — without getting stuck in traffic (unless your code breaks).”

---
