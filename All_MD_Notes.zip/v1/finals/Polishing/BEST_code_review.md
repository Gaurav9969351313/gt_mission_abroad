# Are You Missing These 9 Performance Killers During Code Review? 

### 1. Algorithm & Data Structure Efficiency

-   Check time and space complexity.
-   Avoid nested loops and redundant computations.
-   Replace `List` with `Set` for lookups.
-   Use `Map` when key-based access is needed.

**Ask:** _Is this the most efficient approach to solve the problem?_

### 2. Avoiding Unnecessary Object Creation

-   🔁 Reuse objects where possible.
-   🧼 Avoid boxing/unboxing in tight loops.
-   💾 Use primitive types when high-performance matters.

**Look for:** Repeated creation of `String`, `BigDecimal`, or new instances in loops.

### 3. Database & External Calls

-   **N+1 query issues** (especially with ORMs like Hibernate).
-   Use batch operations instead of one-by-one inserts.
-   Watch out for blocking I/O (e.g., network/database calls in loops).
-   Ensure proper indexing and query optimization.

_Is this DB query optimal? Is it paginated? Indexed?_

### 4. Loops and Recursion

-   Avoid heavy processing inside loops (like logging, DB calls).
-   Prefer `for` over `forEach` in performance-critical paths.
-   Avoid recursion without proper tail call optimization or exit conditions.

### 5. Memory and Resource Management

-   Avoid memory leaks (e.g., listeners not removed, static caches).
-   Use try-with-resources for file/stream/db handling.
-   Watch for large object retention or unnecessary caching.

### 6. Concurrency and Parallelism

-   Use thread pools properly (avoid `new Thread()`).
-   Avoid shared mutable state or race conditions.
-   Use `CompletableFuture`, `ExecutorService`, or reactive constructs (WebFlux, Project Reactor) appropriately.

### 7. Logging

-   Avoid excessive logging in tight loops or hot paths.
-   Use lazy logging (`log.debug("Result: {}", () -> result)`) or guard with `isDebugEnabled()`.

### 8. Caching Opportunities

-   Can the result be cached?
-   Consider in-memory caching (e.g., Caffeine) for frequently accessed data.
-   Validate existing cache strategies (TTL, size, eviction).

### 9.Framework-Level Checks

-   Are framework defaults being used optimally (e.g., Spring Boot thread pool sizes)?
-   Any heavy filters/interceptors/middleware slowing the request?

### Best Practices for Performance-Oriented Code Reviews

### Do:

-   Benchmark critical paths (use JMH or logs).
-   Encourage profiling tools (VisualVM, JFR, YourKit).
-   Focus on 80/20: optimize hotspots, not everything.
-   Encourage writing unit + performance test cases.

### Don’t:

-   Prematurely optimize non-critical paths.
-   Ignore readability for micro-optimizations.
-   Approve code with blocking calls in async code.

### Performance Review Checklist

-   Are algorithms efficient (O(n) vs O(n²))?
-   Are DB queries optimized and paginated?
-   Any unnecessary object creation or boxing?
-   Any tight loops with logging or I/O?
-   Is caching used where applicable?
-   Are thread pools used correctly?
-   Are async/non-blocking patterns followed?
-   Any redundant library/framework calls?

---
### Inefficient Database Query Execution (N+1 Problem)

### Problem:

Fetching users and their associated orders using a loop, causing **N+1 queries**.
```java
List<User> users = userRepository.findAll();  
for (User user : users) {  
    List<Order> orders = orderRepository.findByUserId(user.getId());  
    user.setOrders(orders);  
}
```
-   **Issue:** This results in **N additional queries** for each user.
-   **Impact:** Slower response time, higher DB load.

![](https://miro.medium.com/v2/resize:fit:513/1*m28uMxvhaSC1Ay8mIHBaKg.png)

### Fix: Use `JOIN FETCH` or Batch Fetching
```java
@Query("SELECT u FROM User u JOIN FETCH u.orders")  
List<User> findAllUsersWithOrders();
```
OR use **EntityGraph** in Spring Data JPA:
```java
@EntityGraph(attributePaths = {"orders"})  
List<User> findAll();
```
**Benefit:** Reduces database queries from **N+1 to 1**.

### Blocking API Calls in Microservices

### Problem:

A synchronous API call **blocks the thread**, leading to scalability issues.
```java
public String getUserData() {  
    return restTemplate.getForObject("http://user-service/api/users", String.class);  
}
```
-   **Issue:** Blocks the thread until the response is received.
-   **Impact:** Reduces throughput in high-traffic microservices.

### Fix: Use Async Calls with CompletableFuture
```java
public CompletableFuture<String> getUserData() {  
    return CompletableFuture.supplyAsync(() ->   
        restTemplate.getForObject("http://user-service/api/users", String.class)  
    );  
}
```

**Benefit:** Improves concurrency and **frees up resources** for other requests.

### Improper Exception Handling & Debugging

### Problem:

Catching a **generic exception** without proper logging.
```java
try {  
    processOrder(order);  
} catch (Exception e) {  
    System.out.println("Error occurred: " + e);  
}
```

-   **Issue:** Doesn’t log the stack trace, making debugging difficult.
-   **Impact:** Hard to diagnose errors in production.

### Fix: Catch Specific Exceptions & Use Proper Logging
```java
private static final Logger logger = LoggerFactory.getLogger(OrderService.class);

try {  
    processOrder(order);  
} catch (IOException e) {  
    logger.error("IO Error while processing order {}: {}", order.getId(), e.getMessage(), e);  
} catch (SQLException e) {  
    logger.error("Database error for order {}: {}", order.getId(), e.getMessage(), e);  
}
```
**Benefit:** **Better observability & traceability** in logs.

### Security Issue — Hardcoded Secrets in Code

### Problem:

Database credentials are hardcoded in the code.
```java
String dbPassword = "mySuperSecretPassword";
```
-   **Issue:** Credentials are exposed, leading to **security risks**.
-   **Impact:** If code is leaked, **data breaches** can occur.

### Fix: Use Environment Variables or Secrets Manager
```java
String dbPassword = System.getenv("DB_PASSWORD");
```
OR use **AWS Secrets Manager, HashiCorp Vault, or Kubernetes Secrets**.
```java
@Value("${db.password}")  
private String dbPassword;
```
**Benefit:** Prevents **credential leaks** in version control.

### Poorly Optimized String Concatenation in Loops

### Problem:

Using `+` for string concatenation inside a loop.
```java
String result = "";  
for (int i = 0; i < 1000; i++) {  
    result += "data" + i;  
}
```
-   **Issue:** Creates a new `String` object in each iteration.
-   **Impact:** **High memory consumption & performance degradation**.

### Fix: Use `StringBuilder` for Efficient Concatenation
```java
StringBuilder result = new StringBuilder();  
for (int i = 0; i < 1000; i++) {  
    result.append("data").append(i);  
}
```
**Benefit:** **Faster execution** & **lower memory footprint**.

### No Rate Limiting in Public API

### Problem:

An API allows unlimited requests per second, causing abuse.
```java
@GetMapping("/users")  
public List<User> getUsers() {  
    return userService.getAllUsers();  
}
```
-   **Issue:** DDoS attacks or excessive API requests can crash the service.
-   **Impact:** **Scalability & security risk**.

### Fix: Apply Rate Limiting Using Resilience4J
```java
@RateLimiter(name = "userApi", fallbackMethod = "rateLimitFallback")  
@GetMapping("/users")  
public List<User> getUsers() {  
    return userService.getAllUsers();  
}

public List<User> rateLimitFallback(Throwable t) {  
    return Collections.emptyList(); // Return a default response  
}
```
**Benefit:** **Protects the system** from excessive load.

### Inefficient Collection Usage

### Problem:

Using `ArrayList` for frequent insertions & deletions.
```java
List<String> names = new ArrayList<>();  
names.add(0, "Alice");  
names.add(0, "Bob");  // Shifts all elements, causing performance issues
```
-   **Issue:** `ArrayList` **shifts elements**, making it slow for frequent inserts/deletes.
-   **Impact:** **Poor performance in large-scale applications**.

### Fix: Use `LinkedList` for Frequent Inserts & Deletes
```java
List<String> names = new LinkedList<>();  
names.addFirst("Alice");  
names.addFirst("Bob");
```
**Benefit:** **O(1) insertion/deletion** compared to **O(n) in ArrayList**.

### Thread Safety Issue in Multi-Threaded Environment

### Problem:

Using a non-thread-safe collection in a multi-threaded application.
```java
private List<String> users = new ArrayList<>();
```
-   **Issue:** If multiple threads modify the list simultaneously, **race conditions** occur.
-   **Impact:** **Data corruption & unpredictable behavior**.

### Fix: Use `CopyOnWriteArrayList` for Thread Safety
```java
private List<String> users = new CopyOnWriteArrayList<>();
```
**Benefit:** **Ensures thread safety** without external synchronization.

### Overuse of If-Else Statements (Refactor to Enum Strategy Pattern)

### Problem:

Too many `if-else` statements for different payment methods.
```java
if (paymentType.equals("CREDIT_CARD")) {  
    processCreditCard();  
} else if (paymentType.equals("PAYPAL")) {  
    processPayPal();  
} else {  
    processDefault();  
}
```
### Fix: Use Enum with Strategy Pattern
```java
enum PaymentType {  
    CREDIT_CARD {  
        void process() { processCreditCard(); }  
    },  
    PAYPAL {  
        void process() { processPayPal(); }  
    };  
    abstract void process();  
}
```

**Benefit:** **Scalability** — Adding new payment methods doesn’t require modifying existing code.

### Floating-Point Precision Issues in Financial Calculations

### Problem:

Using `double` for monetary values causes **precision errors** in transactions.
```java
double balance = 100.05;  
double amountToWithdraw = 10.02;  
double newBalance = balance - amountToWithdraw;    
System.out.println(newBalance); // 90.02999999999999 (Precision issue)
```
-   **Issue:** Floating-point arithmetic **causes rounding errors**.
-   **Impact:** Can lead to incorrect balances in banking systems.

### Fix: Use `BigDecimal` for Precision
```java
BigDecimal balance = new BigDecimal("100.05");  
BigDecimal amountToWithdraw = new BigDecimal("10.02");  
BigDecimal newBalance = balance.subtract(amountToWithdraw);  
System.out.println(newBalance); // 90.03 (Correct)
```
**Benefit:** Ensures **accurate financial transactions** without rounding errors.

### SQL Injection Risk

### Problem:

Using **string concatenation** in SQL queries.
```java
String query = "SELECT * FROM accounts WHERE account_number = '" + accountNumber + "'";  
Statement stmt = connection.createStatement();  
ResultSet rs = stmt.executeQuery(query);
```
-   **Issue:** Exposes the system to **SQL Injection attacks**.
-   **Impact:** Attackers can **steal or modify banking records**.

### Fix: Use Prepared Statements
```java
String query = "SELECT * FROM accounts WHERE account_number = ?";  
PreparedStatement stmt = connection.prepareStatement(query);  
stmt.setString(1, accountNumber);  
ResultSet rs = stmt.executeQuery();
```
**Benefit:** **Prevents SQL injection**, ensuring **database security**.

### Pro Tips:

> Use Enum Instead of String Constants
> Use Bulk Updates Instead of Single Queries in Loops wherever possible
> Optimize String Handling (Avoid `+` in Loops)
> Use Thread-Safe Collections in Multi-Threaded Environments
> Use Factory Method / Builder Pattern for object creation
> Close Resources Properly (Avoid Resource Leaks)
> Use Optional to Avoid NullPointerException (NPE)
> Prevent Hardcoded Values (Use Constants & Configs) and avoid exposing sensitive info by masking the data
> Use Structured Logging
> Use Streams & Efficient Loops
> Small, Focused Methods (Single Responsibility Principle — SRP)
> Meaningful Variable & Method Names
> Avoid Unnecessary Object Creation
> Ensure Sufficient Test Coverage
> Use Circuit Breakers for Fault Tolerance
> Use Rate Limiting instead of API allowing unlimited requests per second, causing abuse.

--- 

# How I Made My Java Code 15x Faster

### The Problem: Slow Batch Processing in a Critical Workflow

We had a Java microservice responsible for processing incoming financial transactions. As traffic increased, the service started to lag significantly. What once took under a second per batch ballooned to 15 seconds. With business stakeholders breathing down our necks, optimization became top priority.

### Step 1: Profiling with JFR and JVisualVM

I began by profiling the application under load using Java Flight Recorder (JFR) and JVisualVM.

### Findings:

-   Excessive object creation and garbage collection.
-   Unnecessary string concatenations in loops.
-   Heavy reflection-based deserialization.

These were the red flags I knew I needed to tackle.

### Step 2: Reducing Object Allocations

Previously, we were creating new DTO objects for every transaction inside a loop. This caused a spike in memory allocations and GC activity.

### Before:
```java
List<TransactionDTO> dtos = new ArrayList<>();  
for (Transaction tx : transactions) {  
    dtos.add(new TransactionDTO(tx));  
}
```

### After:

We reused DTO instances by maintaining a pool.
```java
ObjectPool<TransactionDTO> dtoPool = new ObjectPool<>(TransactionDTO::new);  
for (Transaction tx : transactions) {  
    TransactionDTO dto = dtoPool.borrow();  
    dto.populateFrom(tx);  
    dtos.add(dto);  
}
```

✅ **Result:** 30% reduction in memory usage.

### Step 3: Optimizing String Handling

We had string concatenations inside tight loops. This was a silent killer.

### Before:
```java
String report = "";  
for (Transaction tx : transactions) {  
    report += tx.toSummary();  
}
```
### After:
```java
StringBuilder reportBuilder = new StringBuilder();  
for (Transaction tx : transactions) {  
    reportBuilder.append(tx.toSummary());  
}  
String report = reportBuilder.toString();
```
✅ **Result:** Reduced CPU usage by 20% during peak processing.

### Step 4: Avoiding Reflection in Serialization

We were using a reflection-heavy JSON library. Switching to a faster, annotation-based alternative like Jackson with precompiled schemas made a big difference.

✅ **Result:** Serialization/deserialization time dropped by 50%.

### Step 5: Parallelism and Concurrency

The processing was done sequentially, but our system had more than enough CPU to parallelize work.

### Before:
```java
for (Transaction tx : transactions) {  
    process(tx);  
}
```
### After:
```java
transactions.parallelStream().forEach(this::process);
```
✅ **Result:** Throughput increased 3x.

Note: We made sure the `process()` method was thread-safe before doing this.

### Step 6: Connection Pool Tuning

Our service made multiple DB calls but used the default HikariCP config.

### Optimization:

-   Increased pool size from 10 to 50.
-   Tuned connection timeout and idle time.

✅ **Result:** DB wait time dropped significantly, improving end-to-end latency.

### Final Outcome

After applying these optimizations:

-   **Batch processing time dropped from 15s to under 1s.**
-   **Memory footprint reduced by 40%.**
-   **CPU usage stabilized under high load.**

What started as a sluggish service became one of our most efficient pipelines.

### Key Takeaways

1.  **Profile before optimizing** — Always measure before making changes.
2.  **Avoid unnecessary object creation** — Especially inside loops.
3.  **Use efficient data handling techniques** — Like `StringBuilder` for string manipulation.
4.  **Be cautious with reflection** — It's powerful but often slow.
5.  **Leverage parallelism wisely** — Only when your code is thread-safe.
6.  **Tune infrastructure settings** — Like DB connection pools.

### One Final Thought:

Optimization isn't about guesswork. It's about understanding what your system is doing — and then doing it better.
---

# Showcase your coding skills during an interview to demonstrate that you are an above-average software engineer.
Here are some effective ways to showcase your coding skills during an interview to demonstrate that you are an above-average software engineer:

1.  **Understand the Problem Thoroughly**:

-   Take time to understand the problem statement before jumping into coding.
-   Ask clarifying questions to ensure you grasp all aspects of the problem.

**2. Think Out Loud**:

-   Verbalize your thought process and reasoning as you work through the problem.
-   This helps the interviewer understand your approach and problem-solving skills.

**3. Break Down the Problem**:

-   Decompose the problem into smaller, manageable parts.
-   Explain how you plan to tackle each part before writing code.

**4. Write Clean, Readable Code**:

-   Follow best practices for code readability and maintainability.
-   Use meaningful variable names, consistent indentation, and appropriate comments.

**5. Optimize Your Solution**:

-   Discuss the time and space complexity of your solution.
-   If possible, suggest and implement optimizations to improve efficiency.

6. **Handle Edge Cases**:

-   Think about and address potential edge cases and input constraints.
-   Explain how your code handles these scenarios.

**7. Use Data Structures and Algorithms Effectively**:

-   Choose the right data structures and algorithms for the problem at hand.
-   Explain why you selected a particular approach and how it benefits your solution.

**8. Test Your Code**:

-   Write test cases to verify the correctness of your solution.
-   Demonstrate how your code handles different inputs and edge cases.

**9. Refactor When Necessary**:

-   Identify areas of your code that can be improved or simplified.
-   Show your ability to refactor code for better performance or readability.

**10. Stay Calm Under Pressure**:

-   Maintain composure and a positive attitude, even if you encounter difficulties.
-   Demonstrate problem-solving resilience and adaptability.

**11. Demonstrate Knowledge of Tools and Technologies**:

-   Mention relevant tools, libraries, or frameworks that can aid in solving the problem.
-   Show familiarity with version control systems, debugging tools, and development environments.

12. **Showcase Collaboration Skills**:

-   Be open to feedback and willing to discuss alternative solutions.
-   Demonstrate your ability to work well with others, as teamwork is often a key aspect of software engineering.

By following these strategies, you can effectively showcase your coding skills and demonstrate that you are an above-average software engineer during an interview.

# 6 Micro Habits of Highly Effective Managers

What makes managers highly effective?

_Making too many suboptimal decisions throughout the day or making a few decisions well?_

_Keeping busy by reactively solving problems or proactively turning opportunities into results?_

_Trying to take giant leaps and give up when progress seems far-fetched or setting an easy pace and continuing each day steadily?_

_Sticking to their outdated beliefs or showing curiosity to expand their knowledge?_

The answers are obvious, and yet most managers struggle to be effective. They try to adopt complicated frameworks and practices even before they have developed the right habits. But without the basics in place, all their effort goes to waste.

> _“__Intelligence, imagination, and knowledge are essential resources, but only effectiveness converts them into results.” —_ Peter Drucker

For a manager, being effective is not optional; it’s a crucial part of their job. Without effectiveness:

1.  More time is spent on inconsequential tasks and less on forward-moving activities.
2.  Effort spent never matches up to the results.
3.  There’s no sense of control over time.
4.  Priorities are either not set or not honored.
5.  Opportunities are missed, and problems linger on.

Effectiveness is nothing but a habit; much like other habits in life, it, too, can be learned. If you want to be an effective manager, master these six micro habits:

### Don’t let fear win

What can cause managers to play safe — pass on great opportunities, refuse to take risks, and do the work they’ve always done before?

_Fear._

_Fear of failure._

_Fear of not meeting others’ expectations._

_Fear of losing credibility._

Fear is often what makes even highly competent managers ineffective. Not being able to separate healthy emotions from unhelpful ones keeps them confined within their comfort zone. Comfort zone feels safe, but it also limits their growth.

Highly effective managers don’t brim with confidence. They’re as fearful as others. However, they don’t let fear get in the way of doing their job or fulfilling their responsibilities as a manager. They do this by:

1.  Acknowledging fear is a part of being human.
2.  Reframing it from doubting their skills to considering it as a sign that they’re doing worthwhile work.
3.  Using fear to re-evaluate their decision, question their choices and reconsider their assumptions.

> _“Courage is feeling fear, not getting rid of fear, and taking action in the face of fear. ” — Roy T. Bennett_

### Stay away from naysayers

What happens when managers are surrounded by people who constantly criticize, crush ideas, and object to new ways of doing things?

Their cynicism makes it hard to get anything done.

_Decisions take longer._

_Discussions go on forever._

_Status quo is preserved._

_New ideas are rejected._

Under their influence, managers also become critical and disapproving of others. Negativity can be contagious. Not being careful around such people can turn even a highly optimist person into a defeatist, motivator into a complainer, and supporter into a cynic.

Highly effective managers check the energy of the people around them — are they raising their concerns with the right intent or simply spreading their negativity?

Consciously staying away from cynics and naysayers or minimizing their impact helps them make better decisions. They can weigh in different options before making a choice.

> _“Naysayers are everywhere. They feel it’s the safest position to be in. It’s the easiest armor to wear . . . And they may be right in their negativity; reality may be on their side. But chances are very good that it’s not. You can only use their naysaying as one line in the spectrum of inputs to your decision. Listen to everyone you need to, and then go with your fearless instinct.” — Colin Powell_

### Actively deal with cognitive biases

How do managers behave when they don’t pay attention to their cognitive biases?

They assume they’re rational in their thinking and judge others without realizing how their mind is playing games and keeping them biased.

Many cognitive biases like fundamental attribution error, confirmation bias, illusion of transparency, framing effect, and all-or-nothing thinking lead to habitual errors in thinking, which creates an inaccurate view of reality.

> _“We all want explanations for why we behave as we do and for the ways the world around us functions. Even when our feeble explanations have little to do with reality. We’re storytelling creatures by nature, and we tell ourselves story after story until we come up with an explanation that we like and that sounds reasonable enough to believe. And when the story portrays us in a more glowing and positive light, so much the better. ” — Dan Ariely_

Managers falling for these biases follow unhealthy and toxic practices at work — they are quick to blame, point out character flaws in others, reject great ideas, and treat employees unfairly.

Highly effective managers are not free from biases. They deal with the same limitations of the mind as others. However, they’re also highly self-aware. They follow good practices and habits of the mind to ensure their biases do not get in the way of how they communicate, collaborate, and work with others. For example:

1.  Implement feedback loops to learn from mistakes.
2.  Encourage contradicting viewpoints.
3.  Lead with questions instead of answers.
4.  Apply Occam’s razor to choose simplicity over complexity, Hanlon’s razor to look beyond their personal narrative and imagine the situation from another person’s perspective, and other such useful mental models.

Making these simple practices as part of their daily habits reduces the negative effects of cognitive biases on their decisions and how they lead.

### Lift others up

What prevents managers from utilizing their team’s talent, maximizing their potential, and creating an environment that enables them to do some of their best work?

Their false sense of superiority and the need to always be above others.

The desire to prove their brilliance shows up in how they communicate, decide, and act. Their brilliant mindset makes them hog the limelight for themselves instead of putting the spotlight on others. They trust no one with the decisions and try to make all decisions themselves. They diminish their team’s potential by confining them to boxes and defining strict boundaries on what’s within their reach and what’s definitely out of scope.

Highly effective managers act as multipliers who enhance their team’s thinking and capability. They empower their people to unblock themselves, utilize each person’s unique intelligence and connect them with the right opportunities.

> _“Leaders rooted in the logic of multiplication believe: 1. Most people in organizations are underutilized. 2. All capability can be leveraged with the right kind of leadership. 3. Therefore, intelligence and capability can be multiplied without requiring a bigger investment.” — Liz Wiseman_

While diminishers stifle their teams and push them down, multipliers lift their people by giving them an opportunity to shine and succeed.

### Operate within the circle of influence

What makes some managers give up as soon as they encounter an obstacle or face a challenge?

Low agency.

Low agency managers focus their efforts in their circle of concern. Spending their time and energy on things they have no control over makes them neglect areas with scope for improvement. Blaming other people, their circumstances, and their environment leads to a downward spiral of negativity which diminishes their circle of influence.

Highly effective managers have high agency. They focus their efforts in their circle of influence. Paying attention to things within their control enables them to experiment, try different strategies, and solve real problems.

Instead of judging and criticizing others when things don’t go as expected, they look internally at their own decisions and actions. This shifts their focus from other people’s weaknesses to their own strengths. Positive energy from exercising their control enlarges their circle of influence.

When faced with a tough problem or a difficult decision, they ask these questions:

-   Is it within my circle of influence?
-   What can I change about myself or the way I do things that can fix this problem?
-   Can I influence and inspire others to enable change?
-   What other alternatives do I have to get the outcome I desire?

Highly effective managers feel empowered to act because they don’t engage in a victim mentality or waste time worrying about people, circumstances, or conditions outside their control.

### Match energy with the physical and mental demands of work

What can cause managers to become reckless, get stuck with analysis paralysis, or choose the status quo?

Not being able to recognize when they’re running on a low mental battery or failing to save their cognitive resources for important decisions or tasks.

> _“If your work requires you to make hard decisions all day long, at some point you’re going to be depleted and start looking for ways to conserve energy. You’ll look for excuses to avoid or postpone decisions. You’ll look for the easiest and safest option, which often is to stick with the status quo. ” — Roy Baumeister_

Highly effective managers organize their schedule for optimal utilization by matching their energy with physical and mental demands of work. They use their peak productivity period to do some of their most important work. Prioritizing important work when their reserved bank of mental energy is at its best enables them to think clearly and make conscious decisions.

### Summary

1.  Great managers follow simple habits and practices to stay highly effective.
2.  They reframe fear as a sign to evaluate multiple options, ask questions, or reconsider assumptions instead of letting fear get in the way of making decisions or taking action.
3.  Instead of giving power to naysayers by allowing them to influence their thinking or how they make decisions, highly effective managers stay away from them.
4.  By working on things within their control instead of wasting time on things outside their control, highly effective managers expand their circle of influence.
5.  Maximizing their team’s potential is their primary focus. By highlighting each individual’s strengths and combining them with the right opportunities, highly effective managers build high-performance teams.
6.  Effective managers are highly self-aware of the limitations of their minds. They don’t let cognitive biases get in the way of how they think or make decisions.
7.  They use their peak productivity period to do some of their best work. Matching energy to the cognitive demand of their work makes them highly effective.

# How to empower your Teams to make Better Decisions
In my view, fundamentally, there are two ways to lead:

-   Type A (self-managed): Tell them the goal, define and agree on what success looks like, decide on resource commitments, and then hold them accountable for the goal while giving them autonomy in operation.
-   Type B (directed): Tell them what to do and how to do it. Monitor, manage, and enforce quality day today, and reward effort regardless of the outcome.

In this post, we will dig deep and debate these two methods, their pros and cons, and their strengths and weaknesses.

### Side Effects of Each Method

There are side effects of choosing each method.

If you choose to do Type-A (self-managed):

1.  We need to decide how far autonomy goes. Is it just day-to-day decisions, PAR, or does that mean leaders get to define their team’s bonus criteria? Type-A can create stronger sub-teams and sometimes turfs. It is a tradeoff leadership needs to make about an organization. One promising remedy is allowing a free flow of people across different departments, reducing the chance for toxic subcultures.
2.  If you choose type A, the definition of outcomes decides your effectiveness. Therefore, the leader must define goals and KPIs carefully in consultation with the team. There is a famous management maximum that whatever gets measured gets improved, in which case your KPIs are better to be things that matter.
3.  The second decider is human nature. People put a lot of value on their ideas. (Remember the movie “Inception”). There is great value in letting people figure out their actions, as that creates a sense of ownership and passion.

If you choose type B (directed):

1.  It is hard to hold the team responsible for the outcomes. After all, you told them what to do.
2.  Because type B rewards effort but not the outcome, you have to measure the effort, in which case, either you need a complicated score or to go by judgment. Most measurements of this Type become a social score, which leads to many complications. Using judgment can work, but it is sensitive to leadership quality and shared understanding. If your middle management is weak, it is natural to want to bypass them and go for a social score. However, the social score is blind to circumstantial knowledge, and soon people learn to optimize the score rather than the outcomes. If we don’t trust the middle management, we should fix them or replace them rather than putting a social score. The judgment-based system does not work without trust in middle management. We must give leads discretion to decide their people’s ratings ( trust them) and hold the leaders accountable. Note that with type A, you do not have a choice because you can’t give them autonomy unless you can trust the leadership.
3.  People are reluctant to follow a course someone else has charted for them. We can discuss the need for objectivity, but humans are subjective by nature. I am not debating morality here, just how things are. Getting people to follow such a course needs a lot of credibility and effort from the leader. If you are choosing type B, you must make allowances for this aspect of human nature.

### Tradeoffs related to each method

There are three tradeoffs related to each choice.

#### Circumstantial knowledge

The first step towards understanding the key differences between the two models is understanding the role of information in decision-making. An excellent discussion can be found in the seminal essay “[The Use of Knowledge in Society](https://www.econlib.org/library/Essays/hykKnw.html)” By Friedrich A. Hayek, which makes several key points.

-   Decision-making takes the knowledge distributed across (e.g., an organization) into account and makes the best decision.
-   If it is easy to collect information, then decision-making is often easier.
-   One model is analytics — we can aggregate data and do central planning.
-   However, not all knowledge is scientific and can be reduced to the summarized form. There is circumstantial knowledge, which only applies to a particular time, space, or circumstances. This kind of knowledge can’t be summarized, and if circumstantial knowledge is vital, the central planners need to leave those decisions to people on the ground. Due to this reason, most professional jobs need training.
-   Sometimes we create constructs to communicate between different parties in the system and avoid central planning. Price, money, and various types of markets are excellent examples of such constructs.

  
+===============================+====================+========================+  
|               _               | For creative tasks | For well-defined tasks |  
+===============================+====================+========================+  
| summarizable knowledge        | Type A             | Type B                 |  
+-------------------------------+--------------------+------------------------+  
| need circumstantial knowledge | Type A             | Type A                 |  
+-------------------------------+--------------------+------------------------+

Consequently, when the environment or the task is well understood (e.g., factory floor) and information can be summarized, type B (directed) leadership is preferred. On the other hand, when circumstantial knowledge is critical, or the task is not well understood, type A leadership is preferred.

We often error by expecting brilliance to compensate for the lack of circumstantial knowledge., which seldom works well. When circumstantial knowledge is needed, you can get better and predictable results by empowering your team, who has the most information to make decisions.

### Type A favors creative work.

With creative/exploratory work (e.g., art, research, writing, design), or intuitive (diagnosis, stock trading, design) work, leaders can’t explain how to do the task in detail. Hence type A (self-managed) leadership is preferred.

It is important to note that as you go up the leadership hierarchy, the roles become more and more type A. A CEO has a lot of autonomy but must deliver financial targets, or the company will die. In contrast, a new employee, especially a fresh hire starting his first job, is led with much more type B, where he was told how to do it, best practices, and less responsible for outcomes.

### Relentlessly Resourceful

This is a term introduced by Paul Graham, which explains the relentless pursuit of a goal. As Hayek suggests, many complex problems need deep consideration of circumstantial knowledge and a relentlessly resourceful attitude, which make a difference between the world-class and mediocre performance. Circumstantial knowledge and a relentlessly resourceful attitude are strongly associated with Type A leadership, which provides the best chance for world-changing outcomes.

### Type A require a mature team.

Type A team needs people who can think, are curious, and are ready to leap faith. Few can do it; even fewer are willing to do it.

“Most people would rather die than think, and many of them do!” ― Bertrand Russell, The ABC of Relativity.

Even the right people would need a lot of training and coaching.

The team needs to be able to manage themselves, which involves goal definition, criteria, resource allocation discussions, ongoing self-assessment, goal adjustment, and course correction.

### Type B is faster

Type A needs the team to figure out some things by trial and error. So type A is slow at first and takes time to hit the full swing, although they could be much more effective in the long term. On the other hand, type B leadership can give results faster and also can be tuned to provide high efficiency.

### There are several fallacies.

1.  One may argue that A is not fair because, likes it or not, luck plays a significant role in outcomes, and luck would factor into the rewards people receive. You may factor luck and judgment into performance appraisal, yet results must mostly decide their performance for type A to be effective. Factoring out luck is hard ( see Thinking in Bets: Making Smarter Decisions When You Don’t Have All the Facts (https://www.amazon.com/Thinking-Bets-Making-Smarter-Decisions/dp/0735216355)).
2.  One may argue that type B does not use the leader’s knowledge. However, this is not true. While providing autonomy to operate, the leader should actively engage in coaching and consultancy. He should listen and ask questions. “Many think leadership is the right to command and fix things. A different view is to ask questions, listen, make connections, and resolve difficulties. It is to take out the best in your team.” — Book Ask for More. However, type B uses the leader’s knowledge faster than type A.

### What does Type A vs. B mean for the follower?

The role of team members is far from simple. First of all, we are all followers. Even the CEO has a boss, the board.

**When type A leadership in action**

As followers, type A management gives us a lot of freedom, but at the same time requires a lot of energy and willingness to think. We need to work on our leadership skills.

**When type B leadership is in action**

As a follower, we need to remember that people on the ground have the most information, and the information could help many decisions. When decisions are not left to ground level, there are several things followers can do.

-   If your knowledge is not reflected in the organization’s decisions, it is your failure.
-   To communicate and make your case, you have to do your homework. Think and have a model.

Decisions may or may not go in your way. If you are vetoed:

-   We are not always correct, and often you do not have full information about the situation. You need to be able to disagree and commit.
-   If you are wrong, you must learn from that and update your mental models.
-   If you are right, you will get more credibility next time.

Of course, you are repeatedly proved right, but they do not listen; it is time to find a different job.

### Conclusion

There are two ways to lead the team. Type A: give them the problem and hold them accountable for the outcome; Type B: tell them what to do and follow up.

The following table summarizes two styles:

  
+=======================================+==================================+  
|                Type A                 |              Type B              |  
+=======================================+==================================+  
| measure by outcomes                   | mesure by effort                 |  
+---------------------------------------+----------------------------------+  
| for creative tasks                    | for well-defined tasks           |  
+---------------------------------------+----------------------------------+  
| can use circumstantial knowledge      | when knowledge can be summarized |  
+---------------------------------------+----------------------------------+  
| slow to start                         | faster                           |  
+---------------------------------------+----------------------------------+  
| Lead to a better team in the long run | can be fine-tuned                |  
+---------------------------------------+----------------------------------+  
| higher risks                          | predictable                      |  
+---------------------------------------+----------------------------------+  
| better ownership and passion          | continous motivation needed      |  
+---------------------------------------+----------------------------------+  
| could be "relentlessly resourceful."  |                                  |  
+---------------------------------------+----------------------------------+

If your team’s work is well-defined and there is a well-defined process without the need to make a lot of decisions, type B (managed) works and is often cheaper. In this situation, people become replaceable, which is an advantage.

However, if work is not well defined and requires creativity when you have a longer time horizon, and if you have a mature team who can act autonomously, type A is much better. However, you may need to do type B because of tough deadlines. Furthermore, when an organization is facing pressure (e.g., a bad economy), the margin of error is small, and we often have to switch to type B leadership ( read about “Wartime CEO”).

There is no single correct choice. Both classes have their strengths and weaknesses. Regardless of choice, you can get the best results by understanding the strengths and weaknesses of your choice and making allowances for that.

