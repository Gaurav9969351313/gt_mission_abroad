# Part 1 : microservices API Gateway 

An API Gateway is an essential component in a microservices architecture for several reasons. It serves as a single entry point for client requests, routing them to the appropriate backend services. Here are some key reasons why an API Gateway is needed:

1.  **Simplifies Client Interaction:**

-   **Single Entry Point:** Instead of interacting with multiple microservices, clients communicate with a single API Gateway, which simplifies the architecture and reduces complexity.
-   **Aggregation:** The gateway can aggregate responses from multiple microservices into a single response, reducing the number of client-server interactions.

**2. Security:**

-   **Authentication and Authorization:** The API Gateway can handle user authentication and authorization, ensuring that only authenticated and authorized requests reach the backend services.
-   **Rate Limiting and Throttling:** It can protect backend services from being overwhelmed by limiting the number of requests a client can make in a given period.
-   **Logging and Monitoring:** Centralized logging and monitoring of requests passing through the gateway help in detecting and responding to security incidents.

**3. Load Balancing and Fault Tolerance:**

-   **Load Balancing:** The API Gateway can distribute incoming requests across multiple instances of backend services, improving scalability and availability.
-   **Fault Tolerance:** It can handle failures gracefully by implementing circuit breakers, retries, and fallbacks.

**4. Routing and Composition:**

-   **Routing:** The gateway can route requests to the appropriate service based on the URL path, request parameters, or other criteria.
-   **Request/Response Transformation:** It can modify requests and responses (e.g., format conversion, adding/removing headers) to meet the client’s needs or to maintain backward compatibility.

**5. Centralized Cross-Cutting Concerns:**

-   **Cross-Cutting Concerns:** Common functionalities such as logging, metrics collection, and request validation can be implemented once at the API Gateway level, rather than in each microservice.
-   **Caching:** The gateway can cache responses to reduce load on backend services and improve response times for clients.

**6. Decoupling Clients from Services:**

-   **Service Discovery:** The API Gateway can act as a service discovery client, finding the appropriate service instance for a request dynamically.
-   **Versioning:** It can handle versioning of APIs, allowing multiple versions of a service to coexist and clients to migrate to newer versions gradually.

**7. Protocol Translation:**

-   **Protocol Translation:** The gateway can translate between different protocols, such as HTTP to WebSocket, or between different data formats like JSON to XML.

### Example Use Case

Consider a retail application with separate microservices for user management, product catalog, order processing, and payment processing. Without an API Gateway, the client would need to directly interact with each of these services, managing multiple endpoints and handling concerns like authentication and request aggregation.

With an API Gateway, the client makes requests to a single endpoint, and the gateway routes and aggregates these requests, handles security, and manages cross-cutting concerns, simplifying the overall architecture and improving maintainability.

### Popular API Gateway Solutions

-   **AWS API Gateway:** A fully managed service that makes it easy to create, publish, maintain, monitor, and secure APIs at any scale.
-   **Kong:** An open-source API Gateway and Microservices Management Layer, delivering high performance and reliability.
-   **Netflix Zuul:** An open-source edge service that provides dynamic routing, monitoring, resiliency, security, and more.
-   **Nginx:** A high-performance, scalable web server that can be configured as an API Gateway.
-   **Spring Cloud Gateway:** Part of the Spring Cloud ecosystem, it provides a simple, yet powerful way to route requests and handle cross-cutting concerns.

By using an API Gateway, organizations can manage and scale their microservices more efficiently, enhance security, and improve the developer and user experience.


# Service Discovery in Microservice Architecture

In a microservices architecture, an application is broken down into smaller services, each running on different servers or containers. This makes it easier to update or deploy them independently, saving time and effort. But with so many services running separately, how do they find and talk to each other? That’s where service discovery comes in.

Service discovery is a system that helps applications automatically find and connect with different services in a microservices architecture.

### What is Service Discovery?

Service discovery is the process by which services in a microservices architecture automatically find each other on the network. Imagine you have **10, 20, or even 100** services running. Instead of **hardcoding IP addresses or URLs** for each service connection, the system dynamically locates services based on their **service name or other identifiers**.

A crucial part of service discovery is the **service registry** — a centralized system that keeps track of all available services. It must always be up-to-date and highly available because services are constantly registering when they start and deregistering when they shut down. This ensures that requests are always routed to active, healthy services.

![](https://miro.medium.com/v2/resize:fit:875/1*qK39yWoGXLC_b8rxSFHh2A.jpeg)

In cloud platforms, each service runs multiple instances, and these instances handle requests from applications or users. When a new service is added, it needs to register itself so other services can find it. There are two common ways to handle this registration:

### Self-Registration Pattern

Here, the **service instance is responsible for registering and deregistering itself** with the service registry. also if required, a service instance sends a **heartbeat request** to prevent its registration from expiring.

![](https://miro.medium.com/v2/resize:fit:875/1*fRT1rCd3I0ja2-B6_3mCkA.jpeg)

### Third-Party Registration Pattern

In this approach, the responsibility of registering and deregistering services is delegated to a third-party register such as a **service manager**(e.g., Kubernetes Service Registry, HashiCorp Consul, or AWS Service Discovery). When a service instance **starts up**, the service manager **automatically detects** it and registers it with the **service registry** (e.g., Eureka, Consul, or Zookeeper). Similarly, when the service **shuts down or crashes**, the service manager **deregisters** it, ensuring that only healthy services are discoverable.

-   **Enhanced Service Resiliency** — The service manager continuously monitors service health and removes failing instances quickly.
-   **Automated Discovery** — No need for services to handle registration manually.
-   **Better Fault Tolerance** — Works well in dynamic environments where instances scale up or down automatically.

![](https://miro.medium.com/v2/resize:fit:875/1*Rd6aW9m_29qYChH-Y4GSXg.jpeg)

# Types of Service Discovery

Service discovery operates in two main ways:

### Client-Side Discovery

Here, the **client** is responsible for determining the service locations. It queries a **service registry** and connects to the appropriate service.

Imagine you are running an **e-commerce platform** with separate services for:

-   Payment Service
-   User service
-   Inventory Service

![](https://miro.medium.com/v2/resize:fit:875/1*jkdmB8RJb1Pv6gzaUQfsiQ.jpeg)

When a customer places an order, the **order service** needs to communicate with:

-   The **inventory service** to check stock availability.

With **client-side discovery**, the order service queries a **service registry** like **Eureka or Consul** to find the inventory service. The registry responds with a list of available instances, and the order service selects one to send its request. This **dynamic discovery** ensures that if an instance goes down or is moved, the system can automatically find a healthy instance.

### Server-Side Discovery

In this model, the client sends a **generic request to a central load balancer or gateway**, which handles the discovery process and forwards the request to the correct service.

Consider an **online banking system** where a user logs in. The system needs to fetch:

-   **Account details**
-   **Transactions history**
-   **Loan information**

![](https://miro.medium.com/v2/resize:fit:875/1*dGLGbt454ADDNijZymI48Q.jpeg)

Instead of each microservice **querying the registry directly**, the request is routed through a **server-side load balancer** like **AWS Elastic Load Balancer (ELB)**. The load balancer:

1.  Queries the service registry for available services.
2.  Selects a healthy instance.
3.  Forwards the request to the appropriate microservice.

In this case, the **load balancer abstracts the discovery process from the client**, making it easier to manage. The registry tracks the availability of services using **heartbeat mechanisms**.

### Key Components of Service Discovery

To make service discovery work, several critical components are involved:

-   A **service registry** is essentially a database or directory that holds information about the network locations of microservices. It’s the place where services can register themselves and where other services can find them. for examples: **Eureka, Consul, Zookeeper**
-   **Health Checks :** Ensures that only healthy services are listed in the registry. If a service goes down, it is removed until it becomes available again.
-   **Load Balancing :** Ensures even distribution of requests among available service instances. Can be **client-side (Ribbon, Spring Cloud LoadBalancer)** or **server-side (AWS ELB, Nginx, HAProxy)**

### Why is Service Discovery Important?

Service discovery is **crucial** for three main reasons:

-   **Scalability** As new service instances are added or removed, service discovery dynamically adjusts, enabling seamless scaling.
-   **Resilience** If a service instance fails, service discovery ensures that other healthy instances are used without manual intervention.
-   **Simplifies Service Management** Reduces complexity, allowing developers to focus on core business logic.

# Implementing Service Discovery with Eureka

**Eureka** is one of the most popular **service discovery solutions**, primarily used in microservices architecture for **dynamic service registration and discovery**. It is part of **Netflix’s open-source Spring Cloud stack**.

### → Set Up Eureka Server | Server Side Setup

**Add Dependency to** `pom.xml`

To set up a Eureka Server in your Spring Boot application, add the following dependency in your `pom.xml` file:
```xml
<dependency>  
    <groupId>org.springframework.cloud</groupId>  
    <artifactId>spring-cloud-starter-netflix-eureka-server</artifactId>  
</dependency>
```
**Configure Eureka Server in** `application.properties`

Create a `application.properties` or `application.yml` file and add the following configurations:
```shell
server.port=8761  
spring.application.name=EUREKA-SERVER  
eureka.instance.hostname=localhost  
eureka.client.register-with-eureka=false  
eureka.client.fetch-registry=false  
eureka.client.service-url.defaultZone=http://${eureka.instance.hostname}:${server.port}/eureka
```
**Enable Eureka Server in Spring Boot Application**

Annotate the main class with `@EnableEurekaServer` to enable the Eureka Server functionality.
```java
@SpringBootApplication  
@EnableEurekaServer  
public class EurekaServerApplication {  
    public static void main(String[] args) {  
        SpringApplication.run(EurekaServerApplication.class, args);  
    }  
}
```

Once you start this application, the Eureka dashboard will be available at `http://localhost:8761/` .

### → Register a Client Service with Eureka | Client Side Setup

For example, let’s register a **User Service** with Eureka:

**Add Dependency to** `pom.xml`

Add the Eureka client dependency to the **User Service** `pom.xml` file:
```xml
<dependency>  
    <groupId>org.springframework.cloud</groupId>  
    <artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>  
</dependency>
```
**Configure Eureka Client in** `application.properties`

Configure the Eureka Client properties to register the service with the Eureka Server.
```shell
server.port=${PORT:0}  
spring.application.name=users-ws  
  
#eureka-server  
eureka.client.serviceUrl.defaultZone=http://localhost:8761/eureka/  
eureka.client.register-with-eureka=true  
eureka.client.fetch-registry=true  
eureka.instance.prefer-ip-address=true  
eureka.instance.instance-id=${spring.application.name}:${spring.application.instance_id:${random.value}}
```
**Enable Discovery Client in Spring Boot Application**

Annotate the main class with `@EnableDiscoveryClient` to register the UserService with Eureka.
```java
@SpringBootApplication  
@EnableDiscoveryClient  
public class UserServiceApplication {  
    public static void main(String[] args) {  
        SpringApplication.run(UserServiceApplication.class, args);  
    }  
}
```
# Running the Application

1.  Start the **Eureka Server** first.
2.  Start the **User Service** application.
3.  Check the Eureka Dashboard at `http://localhost:8761/`, and you should see the **users-ws** service registered successfully.

# Summary

-   **Eureka Server** acts as a **central registry** where services can register.
-   **User Service** registers itself with **Eureka Server**.
-   **Order Service** discovers **User Service** dynamically via **Eureka** instead of hardcoding its URL.
-   **Spring Cloud LoadBalancer** automatically picks a **healthy instance**.

---
# MicroService Circuit Breaker with Spring Boot

Micro services are the most important implementation aspect used in the industry now. With the use of micro service architecture, developers could eliminate so many issues they had previously with monolithic applications. Moving forward, people started to search and adopt various patterns into the micro services. Most of the times, new pattern was originated to address a common issue seen in another pattern. In this way, a lot of patterns came into the practice with evolution of time. You can get a whole summary from here: [https://microservices.io/patterns/microservices.html](https://microservices.io/patterns/microservices.html)

These micro service patterns were further broken down into several categories, considering their scopes. Among all these patterns, there are some very important and popular patterns used by so many developers. **Circuit Breaker** is one of them which helps to **manage downstream service failures** in a proper manner. Let’s understand what this pattern does. 💪

## What is Circuit Breaker Pattern?

You may have already heard of circuit breakers we find in electronic items. What is the main purpose of it? **Simply, break the electric flow in an unexpected scenario**. Same as that, here also this micro service pattern has go the name due to the same nature it has.

This pattern comes into the picture while **communicating between services**. Let’s take a simple scenario. Let’s say we have two services: Service A and B. Service A is calling Service B(API call) to get some information needed. When Service A is calling to Service B, if Service B is down due to some infrastructure outage, what will happen? **Service A is not getting a result and it will be hang by throwing an exception**. Then another request comes and it also faces the same situation. Like this request threads will be blocked/hanged until Service B is coming up! As a result, the network resources will be exhausted with low performance and bad user experience. **Cascading failures** also can happen due to this.

In such scenarios, we can use this **Circuit Breaker pattern to solve the problem**. It is giving us a way to handle the situation without bothering the end user or application resources.

### How the pattern works? 💥

Basically, it will behave same as an electrical circuit breaker. When the application gets remote service call failures more than a given threshold circuit breaker trips for a particular time period. After this timeout expires, the circuit breaker allows a limited number of requests to go through it. If those requests are getting succeeded, then circuit breaker will be closed and normal operations are resumed. Otherwise, it they are failing, timeout period starts again and do the rest as previous.

Let’s figure out this using the upcoming example scenario that I’m going to explain. 😎

### Life Cycle of Pattern States 💥

There are 3 main states discussed in Circuit Breaker pattern. They are:

1.  CLOSED
2.  OPEN
3.  HALF OPEN

Let’s understand the states briefly….

### CLOSED State

When both services which are interacting are up and running, circuit breaker is CLOSED. Circuit breaker is counting the number of remote API calls continuously.

### OPEN State

As soon as the percentage of failing remote API calls is exceeding the given threshold, circuit breaker changes its state to OPEN state. Calling micro service will fail immediately, and an exception will be returned. That means, the flow is interrupted.

### **HALF OPEN State**

After staying at OPEN state for a given timeout period, breaker automatically turns its state into HALF OPEN state. In this state, only a LIMITED number of remote API calls are allowed to pass through. If the failing calls count is greater than this limited number, breaker turns again into OPEN state. Otherwise it is CLOSED.

![](https://miro.medium.com/v2/resize:fit:875/1*SkelDcFojg57s4LNMvobtg.png)
Pattern states

To demonstrate the pattern practically, I will use **Spring Boot** framework to create the micro services. **Resilience4j** library is used to implement the circuit breaker.

## What is **Resilience4j?**

**Resilience4j** is a lightweight, easy-to-use **fault tolerance library** inspired by  
[Netflix Hystrix](https://github.com/Netflix/Hystrix). It provides various features.

-   **Circuit Breaker — fault tolerance**
-   Rate Limiter — block too many requests
-   Time Limiter — limit time while calling remote operations
-   Retry Mechanism — automatic retry for failed operations
-   Bulkhead — limit number of concurrent requests
-   Cache — store results of costly remote operations

We are going to use the very first feature with Spring Boot in this article. 😎

Let’s start!!

## Create 2️⃣ Micro Services

I’m going to implement a simple inter service communication scenario using two services called loan-service and rate-service.

**Technical details:**  
Spring Boot with H2 in-memory DB, JPA, Hibernate, Actuator, Resilience4j

**Scenario:**  
Loan service can fetch Loans saved in DB and each loan object has loan type. There are separate interest rate percentages according to the loan type. So, Rate service is having those Rate object details with it’s name.

-   I will make a call to Rate service from Loan service requesting the interest rate of the given loan type.
-   Then I have to calculate the total interest value for the loans depending on their loan type.
-   Then I will update all the Loan objects with the interest amount using the rate I got from Rate service.

![](https://miro.medium.com/v2/resize:fit:875/1*Ru9rM-XS2JZ08PNcTUrVsQ.png)
Project setup

Since **rate-service** is independent, I will first implement basic functionalities for the **rate-service**.

Create a new Spring Boot project with the dependencies provided inside below POM file. I have named it as rate-service.

[https://github.com/SalithaUCSC/spring-boot-circuit-breaker/blob/main/rate-service/pom.xml](https://github.com/SalithaUCSC/spring-boot-circuit-breaker/blob/main/rate-service/pom.xml)

**Controller:**
```java
@RestController  
@RequestMapping("api")  
public class RateController {  
  
    @Autowired  
    private RateService rateService;  
  
    @GetMapping(path = "/rates/{type}")  
    public ResponseEntity<Rate> getRateByType(@PathVariable("type") String type) {  
        return ResponseEntity.ok().body(rateService.getRateByType(type));  
    }  
}
```

**Service:**
```java
@Service  
public class RateService {  
  
    @Autowired  
    private RateRepository repository;  
  
    public Rate getRateByType(String type) {  
        return repository.findByType(type).orElseThrow(() -> new RuntimeException("Rate Not Found: " + type));  
    }  
}
```
**Repository:**
```java
@Repository  
public interface RateRepository extends JpaRepository<Rate, Integer> {  
    Optional<Rate> findByType(String type);  
}
```
**Entity:**
```java
@Builder  
@Getter  
@Setter  
@AllArgsConstructor  
@NoArgsConstructor  
@Entity  
@Table(name = "rates")  
public class Rate {  
    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    Integer id;  
    String type;  
    @Column(name = "rate")  
    Double rateValue;  
}
```
**Configuration:**
```yml
server:  
  port: 9000  
spring:  
  application:  
    name: rate-service  
  datasource:  
    url: jdbc:h2:mem:cb-rate-db  
    username: root  
    password: 123  
    driverClassName: org.h2.Driver  
  jpa:  
    database-platform: org.hibernate.dialect.H2Dialect  
    hibernate:  
      ddl-auto: create-drop  
  h2:  
    console:  
      enabled: true
```
**Entry Point:** Main class will add 2 types of loan rates when service is coming up.
```java
@SpringBootApplication  
public class RateServiceApplication {  
  
   @Autowired  
   private RateRepository rateRepository;  
  
   public static void main(String[] args) {  
      SpringApplication.run(RateServiceApplication.class, args);  
   }  
  
   @PostConstruct  
   public void setupData() {  
      rateRepository.saveAll(Arrays.asList(  
         Rate.builder().id(1).type("PERSONAL").rateValue(10.0).build(),  
         Rate.builder().id(2).type("HOUSING").rateValue(8.0).build()  
      ));  
   } 
}
```
Now we can start rate-service and see check the API we need. Go to [http://localhost:9000/api/rates/PERSONAL](http://localhost:9000/api/rates/PERSONAL) and see the result. You should get this response.

**{**"id": **1**,"type": "PERSONAL","rateValue": **10}**

Now I need to implement **loan-service**. The circuit breaker is needed inside **loan-service** since it’s calling to rate-service. Therefore, **Resilience4j** library is needed. And I need to check the status of the breaker. For that, I need **Actuator** enabled in the loan-service.

Create a new Spring Boot project with the dependencies provided inside below POM file. I have named it as loan-service.

[https://github.com/SalithaUCSC/spring-boot-circuit-breaker/blob/main/loan-service/pom.xml](https://github.com/SalithaUCSC/spring-boot-circuit-breaker/blob/main/loan-service/pom.xml)

Let’s add basic functionalities for the **loan-service**.

**Controller:**
```java
@RestController  
@RequestMapping("api")  
public class LoanController {  
  
    @Autowired  
    private LoanService loanService;  
  
    @GetMapping(path = "/loans")  
    public ResponseEntity<List<Loan>> getLoansByType(@RequestParam("type") String type) {  
        return ResponseEntity.ok().body(loanService.getAllLoansByType(type.toUpperCase()));  
    }  
}
```
**Repository:**
```java
public interface LoanRepository extends JpaRepository<Loan, Integer> {  
    List<Loan> findByType(String type);  
}
```
**DTO:** This is used to convert the response coming from rate-service API call. Since it’s in the type of Rate. Same as rate-service Rate entity class(only omitted the ORM related things)
```java
@Data  
@AllArgsConstructor  
@NoArgsConstructor  
public class InterestRate {  
    Integer id;  
    String type;  
    Double rateValue;  
}
```
**Entity:**
```java
@Builder  
@Getter  
@Setter  
@AllArgsConstructor  
@NoArgsConstructor  
@Entity  
@Table(name = "loans")  
public class Loan {  
    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    Integer id;  
    String type;  
    Double amount;  
    Double interest;  
}
```
**Entry Point:**

-   Main class will add 3 loan objects when service is coming up. Interest amount has been set as zero since we later update it with the remote call to rate-service.
-   We need a Bean of **RestTemplate** class to perform a remote API call. If you do not know about it, please read about it from here: [https://salithachathuranga94.medium.com/rest-template-with-spring-boot-e2001a8219e6](/rest-template-with-spring-boot-e2001a8219e6)
```java
@SpringBootApplication  
public class LoanServiceApplication {  
  
   @Autowired  
   private LoanRepository loanRepository;  
  
   public static void main(String[] args) {  
      SpringApplication.run(LoanServiceApplication.class, args);  
   }  
  
   @Bean  
   public RestTemplate restTemplate() {  
      return new RestTemplate();  
   }  
  
   @PostConstruct  
   public void setupData() {  
      loanRepository.saveAll(Arrays.asList(  
         Loan.builder().id(1).type("PERSONAL").amount(200000.0).interest(0.0).build(),  
         Loan.builder().id(2).type("HOUSING").amount(6000000.0).interest(0.0).build(),  
         Loan.builder().id(3).type("PERSONAL").amount(100000.0).interest(0.0).build()  
      ));  
   }**  
}
```
**Service:**

This is the most important place where we perform the remote call. We need to call this API using **RestTemplate**: [http://localhost:9000/api/rates/{type}](http://localhost:9000/api/rates/{type}) in rate service to get the % of the loan type. Then we calculate the interest amount as _loan amount * (rate/100) and update loan interest amount._
```java
@Service  
public class LoanService {    
    @Autowired  
    private LoanRepository loanRepository;    
    @Autowired  
    private RestTemplate restTemplate;    
    private static final String SERVICE_NAME = "loan-service";    
    private static final String RATE_SERVICE_URL = "http://localhost:9000/api/rates/";    
    // public List<Loan> getAllLoansByType(String type) {  
        HttpHeaders headers = new HttpHeaders();  
        headers.setContentType(MediaType.APPLICATION_JSON);  
        HttpEntity<InterestRate> entity = new HttpEntity<>(null, headers);  
        ResponseEntity<InterestRate> response = restTemplate.exchange(  
            (RATE_SERVICE_URL + type),  
            HttpMethod.GET, entity,  
            InterestRate.class  
        );  
        InterestRate rate = response.getBody();  
        List<Loan> loanList = new ArrayList<>();  
        if (rate != null) {  
            loanList = loanRepository.findByType(type);  
            for (Loan loan : loanList) {  
                loan.setInterest(loan.getAmount() * (rate.getRateValue() / 100));  
            }  
        }  
        return loanList;  
    }}
```
**Configuration:**
```yml
server:  
  port: 8000  
spring:  
  application:  
    name: loan-service  
  datasource:  
    url: jdbc:h2:mem:cb-loan-db  
    username: root  
    password: 123  
    driverClassName: org.h2.Driver  
  jpa:  
    database-platform: org.hibernate.dialect.H2Dialect  
    hibernate:  
      ddl-auto: create-drop  
  h2:  
    console:  
      enabled: true  
management:  
  endpoint:  
    health:  
      show-details: always  
  endpoints:  
    web:  
      exposure:  
        include: health  
    health:  
      circuitbreakers:  
        enabled: true
```

🔴 I have only allowed actuator to display circuit breaker details. Later we will add the circuit breaker configuration here. For now, it’s not needed.

Now we can start rate-service and see check the API we need. Go to [http://localhost:8000/api/loans?type=personal](http://localhost:8000/api/loans?type=personal) and see the result. You should get this response.

[  
{"id": 1,"type": "PERSONAL","amount": 200000,"interest": 20000},    {"id": 3,"type": "PERSONAL","amount": 100000,"interest": 10000}  
]

## Enable Circuit Breaker with fallback method 💥

Now we have to enrich our Loan service method with an annotation. It is called “**@CircuitBreaker”.** Here, **SERVICE_NAME** is taken as **“loan-service”**. Then we have to provide a **fallbackMethod.** The purpose of that is to **call it by default when the downstream service(rate-service) is failing to respond.**
```java
@CircuitBreaker(name = SERVICE_NAME, fallbackMethod = "getDefaultLoans") 
public List<Loan> getAllLoansByType(String type) {  
   
}
```

I have setup the method to return an **empty List** by default when rate service is not responding.

🔴 You can setup this method to show an error message also without sending an empty message. You can return something like this — “Rate service is not responding. Request failed!”. Sending empty array or a default set of data is not the ideal way. Because it will make a confusion to the users. But you MUST make sure that both methods are returning the same type of data. In my case: both methods are returning Lists!
```java
public List<Loan> getDefaultLoans(Exception e) {  
    return new ArrayList<>();  
}
```
## **Add Circuit Breaker Configs 💥**

Let’s add Resilience4j circuit breaker configurations. Add this to application.yml in **loan-service**.
```yml
resilience4j:  
  circuitbreaker:  
    instances:  
      loan-service:  
        registerHealthIndicator: true  
        failureRateThreshold: 50  
        minimumNumberOfCalls: 5  
        automaticTransitionFromOpenToHalfOpenEnabled: true  
        waitDurationInOpenState: 5s  
        permittedNumberOfCallsInHalfOpenState: 3  
        slidingWindowSize: 10  
        slidingWindowType: COUNT_BASED
```

-   **failureRateThreshold**—Expected percentage of the failure threshold.  
    I have set it as 50%. It means, when total failed remote calls % is equal or greater than 50%, breaker will be active to stop furthermore requests.
-   **minimumNumberOfCalls** — Minimum number of total API calls to decide failure percentage to enable the breaker.  
    I have set it as 5. Let’s say 3 API calls are failing from the the first 5 API calls. It means failureRateThreshold = (3/5) * 100 = 60%.
-   **automaticTransitionFromOpenToHalfOpenEnabled** — I have set this as true. It will automatically transfer OPEN state to HALF OPEN state when it comes the right time for that transition.
-   **waitDurationInOpenState** — Timeout period before going to HALF OPEN state from OPEN state. After 5 seconds, breaker will change the state, here.
-   **permittedNumberOfCallsInHalfOpenState** — Number of LIMITED API calls that should be sent while in HALF OPEN state. I have set it as 3. So, after 3 API calls, if they are failed, then breaker will again go to OPEN state. Otherwise breaker will be CLOSED since rate-service is UP.
-   **slidingWindowType**: Here I have set the type to keep the circuit breaker behavior based on the requests counts.

**Start** both services. Now go to loan service actuator URL and see how circuit breaker is shown there: [http://localhost:8000/actuator/health](http://localhost:8000/actuator/health). Circuit breaker details has been highlighted in the response.
```json
{  
  "status": "UP",  
  "components": {  
    **"circuitBreakers": {  
      "status": "UP",  
      "details": {  
        "loan-service": {  
          "status": "UP",  
          "details": {  
            "failureRate": "-1.0%",  
            "failureRateThreshold": "50.0%",  
            "slowCallRate": "-1.0%",  
            "slowCallRateThreshold": "100.0%",  
            "bufferedCalls": 1,  
            "slowCalls": 0,  
            "slowFailedCalls": 0,  
            "failedCalls": 0,  
            "notPermittedCalls": 0,  
            "state": "CLOSED"  
          }  
        }  
      }  
    }**,  
  }  
}
```

-   **bufferedCalls** —Total API calls from loan-service to rate-service
-   **failedCalls** — Total count of failed API calls from loan-service to rate-service
-   **failureRate** — (failedCalls/bufferedCalls) * 100%

## Test Circuit Breaker 💥

We have to follow some ordered steps to see the changes exactly. In each step, we have to see the actuator endpoint and see how circuit breaker is behaving by changing its state. Let’s start!!! 💪

-   Start both micro services. Loan service is running on 8000 and Rate service is running on 9000. Am i right???
-   Now hit this API 2 times: [http://localhost:8000/api/loans?type=personal](http://localhost:8000/api/loans?type=personal). Then go and check the actuator: [http://localhost:8000/actuator/health](http://localhost:8000/actuator/health). Now **bufferedCalls count** has been **updated into 2** as expected. Still breaker is CLOSED since rate service is UP.
```json
{  
    "loan-service": {  
        "status": "UP",  
        "details": {  
            "failureRate": "-1.0%",  
            "failureRateThreshold": "50.0%",  
            "slowCallRate": "-1.0%",  
            "slowCallRateThreshold": "100.0%",  
            **"bufferedCalls": 2,**  
            "slowCalls": 0,  
            "slowFailedCalls": 0,  
            "failedCalls": 0,  
            "notPermittedCalls": 0,  
            "state": "CLOSED"  
        }  
    }  
}
```

-   Now STOP the rate-service!! Then hit loan service API URL 3 times: [http://localhost:8000/api/loans?type=personal](http://localhost:8000/api/loans?type=personal). You should get an empty array we setup as fallback! This will lead **bufferedCalls count** to 5(Previous 2 and this 3). Right? At the same time, **failedCalls count** is **updated into 3.** Right?? Now **failureRate** becomes **60%**( (3/5) * 100% )**.** Then it has **exceeded our threshold: 50%. 😅 Then the circuit breaker changes its state to OPEN! 😍**
```json
{  
    "loan-service": {  
        "status": "**CIRCUIT_OPEN**",  
        "details": {  
            **"failureRate": "60.0%",**  
            "failureRateThreshold": "50.0%",  
            "slowCallRate": "0.0%",  
            "slowCallRateThreshold": "100.0%",  
            **"bufferedCalls": 5,**  
            "slowCalls": 0,  
            "slowFailedCalls": 0,  
            **"failedCalls": 3,**  
            "notPermittedCalls": 0,  
            "state": "OPEN"  
        }  
    }  
}
```
-   Then wait for 5 seconds. It should then convert into HALF OPEN state after 5 seconds right? According to our configurations we have set **waitDurationInOpenState to 5s**…This is the timeout period…After this time period, request counts also will be reset.
```json
{  
    "loan-service": {  
        **"status": "CIRCUIT_HALF_OPEN",**  
        "details": {  
            "failureRate": "-1.0%",  
            "failureRateThreshold": "50.0%",  
            "slowCallRate": "-1.0%",  
            "slowCallRateThreshold": "100.0%",  
            "bufferedCalls": 0,  
            "slowCalls": 0,  
            "slowFailedCalls": 0,  
            "failedCalls": 0,  
            "notPermittedCalls": 0,  
            **"state": "HALF_OPEN"**  
        }  
    }  
}
```
-   Within HALF OPEN state, **limited number of requests will be allowed** to pass. In our case it is 3 in the configs the relevant value has been set as permittedNumberOfCallsInHalfOpenState: 3.  
    Since still rate-service is down, just try loan-service API 3 times again! [http://localhost:8000/api/loans?type=personal](http://localhost:8000/api/loans?type=personal)…What happened? All 3 calls failed! Then **failureRate is 100%**. Again our circuit breaker will be opened.
```json
{  
    "loan-service": {  
        **"status": "CIRCUIT_OPEN",**  
        "details": {  
            **"failureRate": "100.0%",**  
            "failureRateThreshold": "50.0%",  
            "slowCallRate": "0.0%",  
            "slowCallRateThreshold": "100.0%",  
            **"bufferedCalls": 3,**  
            "slowCalls": 0,  
            "slowFailedCalls": 0,  
            **"failedCalls": 3,**  
            "notPermittedCalls": 0,  
            "state": "OPEN"  
        }  
    }  
}
```
-   After 5 seconds of timeout, again it will become HALF OPEN! Check again using actuator. You should be getting an empty array for loan service API call still…
-   Now start the rate-service!!! 😎 Then try this API 3 times again: [http://localhost:8000/api/loans?type=personal](http://localhost:8000/api/loans?type=personal)..What happened? You should get the actual result now! And what about the actuator results? See…Now circuit breaker is CLOSED! 😍 Because expected limited API calls count is successfully executed.
```json
{  
    "loan-service": {  
       ** "status": "UP",**  
        "details": {  
            "failureRate": "-1.0%",  
            "failureRateThreshold": "50.0%",  
            "slowCallRate": "-1.0%",  
            "slowCallRateThreshold": "100.0%",  
            "bufferedCalls": 0,  
            "slowCalls": 0,  
            "slowFailedCalls": 0,  
            "failedCalls": 0,  
            "notPermittedCalls": 0,  
            **"state": "CLOSED"**  
        }  
    }  
}
```

# Microservices Distributed Transaction Management — Part 1

### What is a transaction?

A transaction is nothing but a series of actions that must execute successfully. Even if one of the operations fails, the entire steps must be rolled back in order to leave the application in the previous stable state. A transaction has the following ACID properties

![](https://miro.medium.com/v2/resize:fit:875/1*NiBUO-GUctIeR6bgHTb51g.png)
Image Source: https://media.geeksforgeeks.org/wp-content/cdn-uploads/20191121102921/ACID-Properties.jpg

### Transactions in Monolith and Microservices

In a traditional Monolithic application, there will be a single large application connecting to a single large database and such applications stick to ACID properties.

The transaction boundary starts inside the service layer and can be committed or rolled back based on the outcome of all the steps in that transaction. In the case of Microservices, each microservice runs a specific business area and maintains the [**Single Repository Principle(SRP)**](https://javarevisited.blogspot.com/2017/04/single-responsibility-principle-example.html), which means each microservice maintains its own database and another service should not the other service’s database directly. So the transactions are distributed across the microservices.

**Example: Let us consider an online order processing for the Monolith and Microservices Architecture for the below scenario**

1.  The user adds a product to a cart on an e-commerce site and buys it
2.  An order is created for the user with an order number generated
3.  The item stock is reduced by 1 as the user has bought the product
4.  An invoice is generated for the item
5.  Payment has been completed successfully
6.  The invoice is sent to the user via email

![](https://miro.medium.com/v2/resize:fit:718/1*koQ4Bdk4zrdEyHXiiRAogw.png)
Image Source: https://www.sam-solutions.com/blog/wp-content/uploads/2017/10/Monolithic-vs-Microservices-architecture-image-704x540.png

In the Monolith application, all the steps take place inside a single application and single database. All the steps are executed from a service class; if any of the steps fail, the whole transaction can be rolled back.

In the case of a Microservice application, each of the above steps takes place individually inside the specific microservice and its specific database

-   Order will be processed in the Order service
-   Stocks are checked and calculated inside the Account Service
-   The invoice is processed by Invoice Service
-   Payment is processed in the Payment service
-   Email is triggered by the Notification service

Since each of the steps runs inside a different microservice and its database, maintaining the ACID principle for the entire transaction is extremely difficult and complicated. **It is better to avoid distributed transaction management completely if possible.**

If not, then there are some standard patterns for the distributed transaction management

### Patterns for Distributed Transaction Management

1.  Synchronous Patterns

-   Two-Phase Commit
-   Three Phase Commit

2. Asynchronous Pattern

-   Orchestration-Based Saga Pattern
-   Choreography-Based Saga Pattern

# **Synchronous Patterns**

**Two-Phase Commit (2 PC)**

2 Phase Commit is a standard protocol to handle distributed transactions using 2 stages namely Prepare stage and the Commit stage. There is a transaction coordinator component that coordinates the entire transaction by talking to all the services

![](https://miro.medium.com/v2/resize:fit:875/1*WCY8ypG1pEpKIIn9IfGbqA.png)
Image Source: https://thorben-janssen.com/wp-content/uploads/2020/02/Distributed-Transactions-2phase-commit-1024x576.png

**Success Scenario**

1.  The transaction coordinator instructs each service to prepare for **commit** and every service then checks if the commit can be done without any issue
2.  After checking, each service sends a **Prepared** response to the coordinator.
3.  Once the Coordinator receives all the Prepared responses, it tells all the services to **commit** the data to the database
4.  Now the transaction is successful and all the changes get committed across the services

**Rollback Scenario**

1.  The transaction coordinator instructs each service to prepare for **commit** and every service then checks if the commit can be done without any issue
2.  After checking, imagine that one service responds with **failed** status
3.  The Coordinator will send an **abort** command to abort the transaction to rollback any changes performed in the transaction to maintain the ACID principles

**Drawbacks of 2PC**

1.  It is very slow as the coordinator waits for all the responses and the transaction takes a long time to commit
2.  The data in every DB is locked until the commit or abort command is issued. These locks will slow down the system and causes a degradation in performance.

### Three Phase Commit (3 PC)

A two-phase commit protocol cannot recover from a failure of both the coordinator and a cohort member during the **Commit phase**.

The 3 PC is an extension of 2 Phase Commit and the commit phase is divided into 2 phases. 3 Phase commit is designed for fault-tolerance when the coordinator or any other services go down by using the **_prepare-to-commit_** _phase._

![](https://miro.medium.com/v2/resize:fit:875/1*i4BbUqO7wbnU7TRisKrqxg.png)
Image Source: https://xenovation.com/images/articles/development/java/2and3PhaseCommit/3-phase-commit-protocol.png

1.  If the transaction coordinator fails before sending the **prepared-to-commit** command to the microservices, then the other services will imagine that the operation was aborted
2.  The coordinator will not send a **doCommit** message to all the services until they have sent ACK for prepared-to-commit
3.  This will make sure that none of the services are blocked and waiting for other services

**Failure Scenario**

1.  The pre-commit stages help the system to be recovered when the coordinator or a service or both fails during the commit phase
2.  When the new transaction coordinator takes over after the coordinator has failed during the commit phase, it queries all the services to see which state they are in
3.  If the services are in the commit phase, then the new coordinator will know that the previous coordinator has issued the commit command before crashing
4.  If any of the services did not receive **prepare-to-commit** command, then the new coordinator will know that the previous coordinator has crashed even before it completed prepare-to-commit phase
5.  Hence it can safely abort the transaction

### **Drawbacks of Three-Phase Commit**

-   The 3 PC has to be implemented carefully to make sure that the network partitioning does not cause inconsistencies in the transaction
-   3 PC has more overhead as it involves one more step

# The need for an asynchronous pattern

While the Two-Phase commit and Three-phase commit work for distributed transactions across [microservices](/javarevisited/7-free-microservices-courses-for-java-programmers-c9b2f3a2ea7d), they are not efficient as it is blocking and synchronous in nature.

Generally, a database system completes a transaction within 50 ms. But microservices have a long delay as the transaction hops through different services through RPS and hence the locking for a long time becomes a bottleneck to the system. A deadlock could also arise between the transactions in the synchronous pattern.

All these drawbacks paved the way for the asynchronous way using the [**Saga pattern**](https://javarevisited.blogspot.com/2021/09/microservices-design-patterns-principles.html) which relies on eventual consistency and does not maintain atomicity

In this article, we saw what is a transaction and how it works in Monolith and Microservices. We also saw what are Two-Phase commit and Three-phase commits and their drawbacks.

In the next article, we will be exploring Saga-based patterns which are asynchronous and reactive

#  How to Use Microservices Saga Pattern

Using the microservices architecture has many benefits. It has become the norm for many large-scale applications. However, Microservices also comes with several challenges. One such challenge is handling transactions that span across multiple services.

###  Why We Need Saga Pattern?

The Microservice architecture allows us to maintain applications services and their databases separately. However, with the complexity of modern-day requirements, it is common to have data changes that need to propagate across multiple services.

For example, let’s consider a simple online booking ticket system built with Microservices. There are separate Microservices for;

-   Ticket booking.
-   Payment processing.
-   Updating available seats.
-   Sending confirmations to customers.

Suppose a customer makes a booking. It requires invoking several Microservices in sequence to complete the flow starting from booking, payment, reserve seats, and send confirmation.

But, what happens if any of these steps fail? We somehow need to roll back any previous steps to maintain data integrity.

![](https://miro.medium.com/v2/resize:fit:875/1*nHu95RyJQ2PmccSSHu_-3g.png)

However, since each Microservice performs local transactions, it is hard to maintain ACID (Atomicity, Consistency, Integrity, Durability) properties across Microservices.

> Therefore, we need a centralized communication and coordination mechanism to ensure all the transactions are completed successfully, and that’s where the Saga pattern comes in.

###  Introduction to Saga Pattern

The Saga pattern manages transactions that span across multiple Microservices using a sequence of local transactions. The following diagram contains the rollback events in red color, which is a part of the SAGA workflow.

![](https://miro.medium.com/v2/resize:fit:875/1*z9gSYyuRV-_5Qm5JOids5Q.png)

These events are triggered by the Saga Execution Controller in case of a failure happens to ensure the system’s stability.

### ###  What is Saga Execution Controller?

Saga execution controller (SEC) is the centralized component that controls the local transactions and rollback events.

> It tracks all the events of distributed transactions as a sequence and decides the rollback events in case of a failure.

Also, the SEC makes sure that rollback events do not have any additional effect other than reversing the local transactions.

> **Note: SEC internally uses a log named Saga log to keep track of all transactions**

I think now you have a high-level understanding of what the Saga pattern is and how it works. To get a better understanding, let’s see how we can implement it.

###  Implementing Saga Pattern

There are 2 approaches to implement the Saga pattern, Choreography-Based Saga and Orchestration-Based Saga. So, let’s see how these 2 approaches are different from each other and how they work.

###  1. Orchestration-Based Saga

> In Orchestration-Based Saga, a single orchestrator (arranger) manages all the transactions and directs services to execute local transactions.

The orchestrator acts as a centralized controller of all these local transactions and maintains the status of the complete transaction.

Let’s consider the same example I explained earlier and break down Orchestration-Based Saga into steps.

### **Step 1 — User makes the booking request**

When a user makes a new booking request, the booking service receives the POST request and creates a new Saga orchestrator for the booking process.

![](https://miro.medium.com/v2/resize:fit:875/1*qqV1UfZwruWOw4E9QKRRDw.png)

### Step 2 — Orchestrator creates a new booking

Then the orchestrator creates a new booking in the pending state and sends the payment process command to the payment service.

![](https://miro.medium.com/v2/resize:fit:875/1*VOTYwK8HwEGTpVmbISqVUw.png)

###  Step 3 — Executes all the services accordingly

After the payment is processed successfully, the orchestrator will call the seat updating service. Likewise, all the services will be called one by one, and the orchestrator will be notified whether the transactions are succeeded or failed.

### Step 4 — Approve or reject the booking

After each service completes its local transaction, they inform the transaction status to the orchestrator. Based on that feedback, the orchestrator can approve or reject the booking by updating its state.

![](https://miro.medium.com/v2/resize:fit:875/1*qZTRPv4IUlKtyyeumozexA.png)

Orchestration-Based Saga is more simple compared to Choreography-Based Saga, and it is most suitable for situations like,

-   When there are already implemented Microservices.
-   When a large number of Microservices participate in a single transaction.

###  2. Choreography-Based Saga

> In Choreography-Based Saga, all the services that are part of the distributed transaction publish a new event after completing their local transaction.

The Choreography-Based Saga approach does not have an orchestrator to direct and execute local transactions. Instead, each Microservice is responsible for generating a new event. And it will trigger the transaction of the next Microservice.

Saga execution controller keeps track of all these events using the SEC log and executes rollback events in case of a failure.

For example, the booking process we discussed earlier would look like this with the Choreography-Based Saga approach.

![](https://miro.medium.com/v2/resize:fit:875/1*1tvjWo5KWdHX5fxu6hhUmg.jpeg)

But, what would happen if the seat updating transaction fails? Then, the seat updating service will inform the SEC about the failure, and SEC will start the corresponding rollback events and ends the booking process by setting the state to fail.

![](https://miro.medium.com/v2/resize:fit:875/1*P54DZlPn-ek2F5NJl5lVAQ.jpeg)

As you can see, this approach is more complex than the Orchestration-Based Saga approach. So that the Choreography-Based Saga approach is more suitable for situations like,

-   When you implement new Microservices from scratch.
-   When a small number of Microservices participate in a single transaction.


# What is Zipkin?. Zipkin is a Microservices distributed tracing system
Zipkin is a distributed tracing system that helps gather timing data needed to troubleshoot latency problems in service architectures. It manages both the collection and lookup of this data. Zipkin is particularly useful for microservices architectures, where requests may flow through multiple services and it can be challenging to pinpoint performance issues.

Here are some key features and components of Zipkin:

1.  **Trace**: A trace represents a request as it moves through a distributed system. It is a collection of spans.
2.  **Span**: A span is a single unit of work within a trace. It includes metadata such as operation name, start and end timestamps, and any annotations.
3.  **Annotations**: These are additional data points that can be added to a span to provide more context.
4.  **Collector**: The component that receives trace data from the instrumentation libraries in your application.
5.  **Storage**: Zipkin stores trace data, typically in a backend database such as Elasticsearch, Cassandra, or MySQL.
6.  **Query**: The component that provides an API to query trace data.
7.  **UI**: A web-based interface to visualize traces and spans.

# How to use Microservice with Zipkin?

### 1. Set Up Zipkin

##### Option A: Using Docker

You can run Zipkin using Docker with the following command:
```shell
docker run -d -p 9411:9411 openzipkin/zipkin
```
This will start Zipkin and make it available at `http://localhost:9411`.

##### Option B: Using Kubernetes

You can deploy Zipkin in a Kubernetes cluster using Helm:
```shell
helm install --name my-zipkin stable/zipkin
```
### 2. Instrument Your Microservices

You’ll need to instrument your microservices to collect trace data and send it to Zipkin. The instrumentation process varies depending on the programming language and framework you are using.

##### Example for Java Spring Boot

1.  **Add Dependencies**: Add the Zipkin and Sleuth dependencies to your `pom.xml` file:
```xml
<dependency>  
    <groupId>org.springframework.cloud</groupId>  
    <artifactId>spring-cloud-starter-sleuth</artifactId>  
</dependency>  
<dependency>  
    <groupId>org.springframework.cloud</groupId>  
    <artifactId>spring-cloud-sleuth-zipkin</artifactId>  
</dependency>
```
**2. Configure Zipkin**: Add the following configuration to your `application.properties` or `application.yml` file:
```shell
spring.zipkin.base-url=http://localhost:9411  
spring.sleuth.sampler.probability=1.0
```
1.  This configuration sets the Zipkin server URL and enables sampling (set to 1.0 to sample all requests).
2.  **Run Your Application**: Run your Spring Boot application as usual. It will automatically send trace data to the Zipkin server.

### Visualize Traces in Zipkin

Once your microservices are instrumented and running, you can view trace data in the Zipkin UI. Open `http://localhost:9411` in your web browser to access the Zipkin web interface. You can search for traces, view detailed information about each trace, and analyze the flow of requests through your microservices.

### 4. Advanced Configuration

Depending on your needs, you may want to customize Zipkin’s behavior further:

-   **Sampling**: Adjust the sampling rate to control how many requests are traced.
-   **Propagation**: Configure how trace context is propagated between services.
-   **Backend Storage**: Set up a backend storage solution like Elasticsearch, Cassandra, or MySQL if you need to store a large volume of trace data.

By following these steps, you can effectively use Zipkin to trace and troubleshoot your microservices architecture.

---

# Idempotent Operations in Microservices Architecture
### Overview

This can be particularly important for maintaining data consistency and preventing duplicate requests in microservices architecture. For instance, if a client sends a request to create a new order, but the request fails due to a network error, the client may retry the request. If the order creation operation is not idempotent, this can result in duplicate orders being created in the system.

To implement idempotency in a microservices-based system, we can assign a unique identifier to each request that the client sends. This identifier can be generated by the client or by the service handling the request. When the service receives a request with a unique identifier, it checks to see if the same request has already been processed. If the request has already been processed, the service returns the same response as the previous request. If the request has not been processed, the service processes the request and returns a response.

### Example

For example, if we have an e-commerce application and a client sends a request to create a new order, the Order Service generates a unique identifier for the request and saves it in a database. The Order Service then processes the request and sends a response to the client. If the client retries the request with the same unique identifier, the Order Service returns the same response as before. If the request has not been processed, the Order Service processes the request and returns a new response.

By implementing idempotency in this way, we can ensure that duplicate orders are not created in the system and that data consistency is maintained. Additionally, clients can safely retry requests without worrying about creating duplicate data in the system.

### Summary

1.  In distributed systems, idempotent operations can be useful, as they ensure that operations are performed only once, even if the same operation is repeated multiple times.
2.  A distributed environment often requires the use of idempotent operations in conjunction with other techniques such as pessimistic locking, versioning, and transaction processing.
3.  The use of idempotent operations within a microservices architecture can help to ensure that requests to microservices are handled reliably, even if they are retried due to failures or delays.
4.  In order to avoid unintended consequences when applying non-idempotent operations more than once, it is important to carefully design operations so that they are idempotent when appropriate.
5.  The ability to make an operation idempotent may not always be possible, in which case it may be necessary to use other techniques, such as transactions or versioning, to ensure consistency.
