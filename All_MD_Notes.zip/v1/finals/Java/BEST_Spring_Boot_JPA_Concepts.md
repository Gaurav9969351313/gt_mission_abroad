# JPA Scenario-Based 

1) When using `@Transactional`, you notice that the changes are not reflecting in the database. **What could be the reason?**

### 1. Missing `@Transactional` Proxy (Self-Invocation Issue)

-   Issue: Spring uses proxies (AOP) to manage transactions. it creates a proxy around the bean that has transactional methods
-   If you call a `@Transactional` method from within the same class, Spring bypasses the proxy, and transactions don’t work.
-   Example (Incorrect)

> **If you’re not a member but want to read this article, see this** [**friend link**](/@bytebyteboot/jpa-interview-cheat-sheet-top-scenario-based-questions-answers-161f6414916d?sk=5bdb44b268dfe39d7b87a7691b52afc6)
```java
@Service  
public class UserService {  
    @Transactional  
    public void saveUser(User user) {  
        userRepository.save(user);  
    }  
  
    public void createUser() {  
        saveUser(new User());  // Direct call - bypasses proxy!  
    }  
}
```
-   The `saveUser()` method is annotated with `@Transactional` , which means Spring would normally manage the transaction when `saveUser()` is called.
-   However, in the `createUser()` method, you are calling `saveUser()` directly within the **same class**.
-   This causes Spring to **bypass the proxy** because the call doesn’t go through the proxy. Essentially, `saveUser()` is invoked as a normal method call within the same class, and Spring’s transactional management doesn't kick in.
-   Fix: Always call the transactional method from another Spring-managed bean.
```java
@Service  
public class ExternalService {  
    @Autowired  
    private UserService userService;  
  
    public void createUser() {  
        userService.saveUser(new User()); // Works correctly  
    }  
}
```
-   Instead of calling the `saveUser()` method directly within the same class (`UserService` ), we are **calling** `**saveUser()**` **from an external class**, `ExternalService` , which is another Spring-managed bean.
-   When `ExternalService` calls `saveUser()` on `UserService` , **Spring’s proxy is involved** because it’s an external call, and thus, the transactional behavior works as expected.
-   In this case, `UserService` is still a Spring-managed bean, so when `saveUser()` is invoked from the `ExternalService` (or any other class that is managed by Spring), Spring applies the transactional logic correctly.

### 2. Incorrect Transaction Propagation

-   Issue: If `@Transactional` is used with `Propagation.NEVER` or `Propagation.NOT_SUPPORTED` , the method will execute without a transaction.
-   Example (Incorrect)
```java
@Transactional(propagation = Propagation.NEVER)  
public void saveUser(User user) {  
    userRepository.save(user); // No transaction active!  
}
```

-   Fix: Use the correct propagation level (`REQUIRED` is the default and usually recommended).
```java
@Transactional(propagation = Propagation.REQUIRED)  
public void saveUser(User user) {  
    userRepository.save(user);  
}
```

### 3. No Exception Thrown (Transaction Not Rolled Back)

-   Issue: By default, Spring rolls back only unchecked exceptions (`RuntimeException` and `Error` ). If a method throws a checked exception (`Exception` ), the transaction commits instead of rolling back.
-   Example (Incorrect)
```java
@Transactional  
public void saveUser(User user) throws Exception {  
    userRepository.save(user);  
    throw new Exception("Checked Exception!"); // Transaction does NOT roll back  
}
```

Fix: Explicitly specify `rollbackFor = Exception.class` .
```java
@Transactional(rollbackFor = Exception.class)  
public void saveUser(User user) throws Exception {  
    userRepository.save(user);  
    throw new Exception("Checked Exception!"); // Transaction rolls back  
}
```

**Scenario: File or I/O Error in a Transaction**

Let’s assume you have a method that saves data to the database, and while performing the operation, a file or I/O error occurs.

Here’s a simplified example:
```java
@Transactional  
public void saveUserAndProcessFile(User user, File file) throws IOException {  
    userRepository.save(user);  // Saving user to the database  
    // Simulating some I/O operation (e.g., writing to a file)  
    processFile(file);  // Throws IOException if file can't be processed  
}
```

### What Happens by Default (Without Custom Rollback Behavior):

-   The `userRepository.save(user)` method saves the user to the database, and the transaction is open.
-   If an `IOException` (or any other I/O error) occurs in `processFile()` , the transaction will **not roll back** because `**IOException**` **is a checked exception**.

By default, Spring only rolls back transactions for **unchecked exceptions** (those extending `RuntimeException`). **Checked exceptions** like `IOException` do not trigger a rollback unless specified.

### Consequences:

-   If the `IOException` occurs after the user has been saved to the database, **the database changes (i.e., the user record) will still be committed**, even though the I/O operation failed.
-   This could lead to inconsistent data — for example, the user is saved, but the file processing failed, leaving the system in an inconsistent state.

### How to Ensure Data is Not Saved in Case of File or I/O Error:

To ensure that **both** the database operation and the I/O operation are part of the same transaction and **rollback** if an I/O error occurs, you should explicitly configure the transaction to roll back on `IOException` (and other relevant exceptions). This is done using the `rollbackFor` attribute of the `@Transactional` annotation.

### Fix: Explicitly Configure `rollbackFor`:

You can modify the `@Transactional` annotation to rollback on `IOException` (or any other specific exception):
```java
@Transactional(rollbackFor = IOException.class)  // Ensure rollback for I/O errors  
public void saveUserAndProcessFile(User user, File file) throws IOException {  
    userRepository.save(user);  // Saving user to the database  
    processFile(file);  // This will throw IOException if an error occurs  
}
```

### What Happens Now:

-   **When** `**IOException**` **is thrown** in the `processFile()` method, Spring will **rollback the transaction**. This means that **the user will not be saved** to the database if the I/O operation fails.
-   This ensures that your database remains in a consistent state, and no data is saved if there’s a failure during the process (such as a file error).

### Why It’s Important:

-   **Consistency**: In a typical system, we want database operations (like saving users) to be **atomic** — meaning if one part of the process fails (e.g., a file I/O error), the entire transaction should be rolled back to maintain consistency.
-   **Rollback on Checked Exceptions**: By default, Spring doesn’t rollback on checked exceptions (like `IOException` ), but by specifying `rollbackFor = IOException.class` , you make sure the transaction is properly rolled back, even if a checked exception occurs.

### Alternative: Multiple Exceptions

If you need to handle **multiple exceptions** (like `IOException`, `SQLException`, etc.), you can list them in the `rollbackFor` attribute:
```java
@Transactional(rollbackFor = {IOException.class, SQLException.class})  
public void saveUserAndProcessFile(User user, File file) throws IOException, SQLException {  
    userRepository.save(user);  
    processFile(file);  
}
```

This will ensure that the transaction rolls back if either an `IOException` or `SQLException` is thrown.

### 4. Database Flush Not Triggered

-   Issue: Hibernate caches operations in memory until the transaction commits. If an operation fails, but no `flush()` occurs before commit, changes may not persist.
-   Example (Incorrect)
```java
@Transactional  
public void saveUser(User user) {  
    userRepository.save(user); // Changes still in Hibernate cache  
    // No explicit flush, so changes may not be visible  
}
```
Fix: Call `flush()` explicitly to force database synchronization.
```java
@Transactional  
public void saveUser(User user) {  
    userRepository.save(user);  
    entityManager.flush(); // Forces changes to be written to the DB  
}
```

**By default**, Spring uses **lazy flushing**, meaning that changes are **not immediately written to the database** but will be **flushed at the end of the transaction**, just before the transaction is committed.

You don’t have to manually flush changes in most cases; Spring does this automatically when the transaction is committed.

### 5. Incorrect Isolation Level

-   Issue: If the transaction isolation level is too restrictive (e.g., `Isolation.READ_UNCOMMITTED` ), concurrent transactions might not see the updates.
-   Example (Incorrect)
```java
@Transactional(isolation = Isolation.READ_UNCOMMITTED)  
public void updateStock(int productId, int newStock) {  
    productRepository.updateStock(productId, newStock);  
}
```

-   Fix: Use a proper isolation level like `Isolation.REPEATABLE_READ` or `Isolation.READ_COMMITTED` .
```java
@Transactional(isolation = Isolation.READ_COMMITTED)  
public void updateStock(int productId, int newStock) {  
    productRepository.updateStock(productId, newStock);  
}
```

### 6. Read-Only Transaction

-   Issue: If `@Transactional(readOnly = true)` is used, the method will not persist any changes.
-   Example (Incorrect)
```java
@Transactional(readOnly = true)  
public void saveUser(User user) {  
    userRepository.save(user); // No effect! Transaction is read-only  
}
```

-   Fix: Remove `readOnly = true` for write operations.
```java
@Transactional  
public void saveUser(User user) {  
    userRepository.save(user); // Now it persists data  
}
```

### 7. Improper Spring Transaction Configuration

-   Issue: If Spring transaction management is not enabled, `@Transactional` has no effect.
-   Fix: Ensure that transaction management is enabled in the Spring configuration.
```java
@Configuration  
@EnableTransactionManagement  
public class AppConfig {  
    @Bean  
    public PlatformTransactionManager transactionManager(EntityManagerFactory emf) {  
        return new JpaTransactionManager(emf);  
    }  
}
```

# Interviewer Follow-up Questions

1.  What is the default propagation type in Spring transactions?`Propagation.REQUIRED`

2. How does Spring handle rollbacks for different exception types? Rolls back on `RuntimeException` but not on checked exceptions unless explicitly specified.

3. What happens if you call a `@Transactional` method from within the same class?

-   The transaction does not work because the Spring proxy is bypassed.

### Conclusion

If changes are not reflecting in the database despite using `@Transactional`, check the following:

-   Are you calling the transactional method from another bean? (Proxy issue)
-   Is the correct transaction propagation used? (`Propagation.REQUIRED`)
-   Are checked exceptions preventing rollback? (`rollbackFor = Exception.class`)
-   Is Hibernate flushing the session properly? (`flush()`)
-   Is the transaction isolation level appropriate? (`Isolation.READ_COMMITTED`)
-   Is `@Transactional(readOnly = true)` mistakenly set?
-   Is Spring transaction management enabled? (`@EnableTransactionManagement`)

# Mastering CriteriaBuilder & JPA Specification in Spring Boot: E-Commerce Project Example.

Briefly explain:

-   It’s a basic E-commerce backend
-   It contains `User`, `Order`, `OrderHistory`, and `Payment` entities
-   You want to filter `Order`s dynamically (e.g., by date, user, payment method, order status)

### 📘 Entity Model Overview (1–2 line descriptions with code snippets)

✅ **User**  
✅ **Order**  
✅ **OrderHistory**  
✅ **Payment**

_Show only key fields (like relationships and filters)_

### 📂 Repository

Show your `OrderRepository`:
```java
public interface OrderRepository extends JpaRepository<Order, Long>, JpaSpecificationExecutor<Order> {  
    List<Order> findByUserId(Long userId);  
}
```
Explain:

-   `JpaSpecificationExecutor` enables dynamic filtering
-   Great for REST APIs where filters are optional and combinable

### 🧠 What is JPA Specification?

Explain briefly:

-   Part of Spring Data JPA
-   Uses `CriteriaBuilder` under the hood
-   Allows dynamic, **type-safe**, and composable queries

### 🧠 What Is a Metamodel in JPA?

The **JPA Metamodel** is a set of generated classes that represent your entities’ structure. It allows **type-safe CriteriaBuilder** queries rather than relying on string-based field names.

> _Instead of:  
> _`_cb.equal(root.get("status"), "DELIVERED");_`_  
> You write:  
> _`_cb.equal(root.get(_**_OrderHistory_.STATUS_**_), "DELIVERED");_`

### ⚙️ How to Enable Metamodel Generation

To generate these `_` classes automatically (like `OrderHistory_)`You need to add the following dependency:
```shell
<dependency>  
  <groupId>org.hibernate</groupId>  
  <artifactId>hibernate-jpamodelgen</artifactId>  
</dependency>
```
### ✨ Use CriteriaBuilder with Metamodel
```java
public List<Order> getOrdersWithCriteria(EntityManager em, Long userId, String status) {  
    CriteriaBuilder cb = em.getCriteriaBuilder();  
    CriteriaQuery<Order> query = cb.createQuery(Order.class);  
    Root<Order> orderRoot = query.from(Order.class);  
  
    List<Predicate> predicates = new ArrayList<>();  
  
    if (userId != null) {  
        predicates.add(cb.equal(orderRoot.get(Order_.USER).get(User_.ID), userId));  
    }  
  
    if (status != null) {  
        Join<Order, OrderHistory> historyJoin = orderRoot.join(Order_.ORDER_HISTORIES);  
        predicates.add(cb.equal(historyJoin.get(OrderHistory_.STATUS), status));  
    }  
  
    query.select(orderRoot).where(cb.and(predicates.toArray(new Predicate[0]))).distinct(true);  
  
    return em.createQuery(query).getResultList();  
}
```
### ✅ Output Example

Use `curl` Or Postman to show API responses like:

[  
  {  
    "orderId": 101,  
    "user": "Samrat Alam",  
    "status": "DELIVERED",  
    "paymentMethod": "CARD"  
  }  
]

### 🔧 OrderSpecification Class

Show a modular and clean `OrderSpecification`:
```java
public class OrderSpecification {  
public static Specification<Order> hasUserId(Long userId) {  
        return (root, query, cb) -> cb.equal(  
            root.get(Order_.USER).get(User_.ID), userId  
        );  
    }  
    public static Specification<Order> orderDateBetween(LocalDateTime start, LocalDateTime end) {  
        return (root, query, cb) -> cb.between(  
            root.get(Order_.ORDER_DATE), start, end  
        );  
    }  
    public static Specification<Order> hasPaymentMethod(String method) {  
        return (root, query, cb) -> cb.equal(  
            root.join(Order_.PAYMENT).get(Payment_.PAYMENT_METHOD), method  
        );  
    }  
    public static Specification<Order> hasOrderStatus(String status) {  
        return (root, query, cb) -> cb.equal(  
            root.join(Order_.ORDER_HISTORIES).get(OrderHistory_.STATUS), status  
        );  
    }  
}
```
### 🧼 Best Practices

-   Modularize specifications
-   Use `join()` properly to avoid N+1 problems
-   Validate incoming filter params before calling the repo

### 🚀 The Specification with Multiple Joins

Using the JPA Metamodel, your specification will look like this:
```java
public class UserSpecification {  
  
    public static Specification<User> hasPaymentMethod(String paymentMethod) {  
        return (root, query, cb) -> {  
            // Join User to Orders (OneToMany)  
            Join<User, Order> orderJoin = root.join(User_.ORDERS);  
            // ADD conditons like [ON user.id = order.user_id AND order.status = 'PLACED']  
            orderJoin.on(cb.equal(orderJoin.get(Order_.status), "PLACED"));  
  
            // Join Order to Payment (OneToOne)  
            Join<Order, Payment> paymentJoin = orderJoin.join(Order_.PAYMENT);  
              
            // Build predicate: paymentMethod = ?  
            return cb.equal(paymentJoin.get(Payment_.PAYMENT_METHOD), paymentMethod);  
        };  
    }  
}
```
-   `root.join(User_.ORDERS)` starts from the User entity and joins to their Orders.
-   `User_.orders` is a **relational attribute** representing the `@OneToMany` association from `User` to `Order`.
-   You **cannot join on non-relation fields** like primitive types or simple columns (e.g., you can’t do `root.join(User_.name)` because `name` It's just a string, not an entity relation.
-   Join<SourceEnity, TargetEnity>, to filter or select columns, always call `.get()` on the **target entity’s metamodel attribute**, i.e., on the `Join` instance returned by `.join()`.
-   `orderJoin.join(Order_.PAYMENT)` Further joins each Order to its Payment.
-   The predicate checks if the `paymentMethod` field matches the desired value.

### 🎯 Use the Specification in the Repository Call

The repository must be extended `JpaSpecificationExecutor<User>.`
```java
List<User> users = userRepository.findAll(  
    UserSpecification.hasPaymentMethod("CARD")  
);
```
This will return all users who placed orders paid by `"CARD"`.

### 💡 Bonus: Combine Specifications Easily

You can combine multiple filters using `Specification.where()` and `and()`/`or()` methods.
```java
Specification<User> spec = Specification.where(UserSpecification.hasPaymentMethod("CARD"))  
    .and(UserSpecification.hasName("Alice")); // Assuming you have hasName defined  
  
List<User> filteredUsers = userRepository.findAll(spec);
```
### Advance Topic: Implement `Specification<Order>`
```java
public class OrderSpecification implements Specification<Order> {  
  
    private Long userId;  
    private LocalDateTime startDate;  
    private LocalDateTime endDate;  
    private String paymentMethod;  
    private String orderStatus;  
  
    public OrderSpecification(Long userId, LocalDateTime startDate, LocalDateTime endDate,  
                              String paymentMethod, String orderStatus) {  
        this.userId = userId;  
        this.startDate = startDate;  
        this.endDate = endDate;  
        this.paymentMethod = paymentMethod;  
        this.orderStatus = orderStatus;  
    }  
  
    @Override  
    public Predicate toPredicate(Root<Order> root, CriteriaQuery<?> query, CriteriaBuilder cb) {  
        Predicate predicate = cb.conjunction();  
  
        if (userId != null) {  
            predicate = cb.and(predicate, cb.equal(root.get(Order_.user).get(User_.id), userId));  
        }  
  
        if (startDate != null && endDate != null) {  
            predicate = cb.and(predicate, cb.between(root.get(Order_.orderDate), startDate, endDate));  
        }  
  
        if (paymentMethod != null) {  
            Join<Order, Payment> paymentJoin = root.join(Order_.payment);  
            predicate = cb.and(predicate, cb.equal(paymentJoin.get(Payment_.paymentMethod), paymentMethod));  
        }  
  
        if (orderStatus != null) {  
            Join<Order, OrderHistory> historyJoin = root.join(Order_.orderHistories);  
            predicate = cb.and(predicate, cb.equal(historyJoin.get(OrderHistory_.status), orderStatus));  
        }  
  
        return predicate;  
    }  
}
```
Then query orders like this:
```java
OrderSpecification spec = new OrderSpecification(  
    123L, // userId filter  
    null,  
    null,  
    "CARD",    // payment method filter  
    "DELIVERED" // order status filter  
);  
  
List<Order> orders = orderRepository.findAll(spec);
```
### Explanation:

-   Implements `Specification<Order>` With all criteria combined in `toPredicate()`.
-   Uses metamodel classes (`Order_`, `User_`, `Payment_`, `OrderHistory_`) for type-safe attribute references.
-   Performs joins on relationship attributes like `payment` and `orderHistories`.
-   Combines filters dynamically based on non-null input.

### 📚 Conclusion

Wrap up by highlighting:

-   Clean way to handle dynamic filters
-   More maintainable than if-else-based query logic
-   Real-world scalability and clean architecture


# JPA Scenario-Based Interview - N+1 Query Problem 

2) In a Spring Boot JPA entity, if we use `@GeneratedValue(strategy = GenerationType.AUTO)`, why are the generated IDs not sequential when inserting records? Explain the reason behind this behavior.

###### 1. Hibernate Chooses the ID Generation Strategy Based on the Database

`GenerationType.AUTO` allows Hibernate to choose between:

-   `IDENTITY` → Auto-increment (MySQL, PostgreSQL)
-   `SEQUENCE` → Database sequence (PostgreSQL, Oracle)
-   `TABLE` → Table-based ID generator

If Hibernate selects SEQUENCE, it may preallocate IDs in batches (default: 50), leading to gaps.

> **If you’re not a member but want to read this article, see this** [**friend link**](/@bytebyteboot/jpa-scenario-based-interview-n-1-query-problem-soft-delete-strategy-best-practices-1fb7c0c4739d?sk=dbfa1f2a535bcaabff20783c563dd63e)

###### 2. Sequence Preallocation (Default: 50)

-   If using `GenerationType.SEQUENCE` , Hibernate reserves a block of IDs (default: 50) to improve performance.
-   If a transaction fails or an application restarts before using all IDs, some numbers are skipped.

**Example:**

-   Hibernate reserves IDs 1–50 for batch inserts.
-   If only 10 records are inserted and the app restarts, the next batch starts from 51, skipping 11–50.

###### 3. Transaction Rollbacks and Failures

-   If a transaction fails or is rolled back after an ID is assigned, that ID is lost, causing gaps in the sequence.

###### 4. Multiple Application Instances (Concurrency)

-   In a distributed system, different instances may reserve different ID ranges, leading to gaps and non-sequential ordering.

###### 5. Database-Specific Behavior

-   MySQL with IDENTITY → Strictly sequential (except for rollbacks).
-   PostgreSQL with SEQUENCE → Uses preallocation, so gaps can occur.
-   Oracle → Uses sequences, but gaps happen if caching is enabled.

### How to Fix This?

### Option 1: Use `GenerationType.IDENTITY` for Strictly Sequential IDs

-   Works well for databases that support auto-increment (MySQL, PostgreSQL).
-   Ensures IDs are strictly sequential, but disables batch inserts.
-   Example:javaCopyEdit@Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
-   Limitation: Slower for bulk inserts.

###### Option 2: Use `GenerationType.SEQUENCE` with `allocationSize = 1`

-   Ensures strictly sequential IDs with sequences.
```java
@Id  
@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_seq")  
@SequenceGenerator(name = "my_seq", sequenceName = "my_sequence", allocationSize = 1)  
private Long id;
```
Slightly slower than default allocation (50), but avoids ID gaps.

### Option 3: Use a Table-Based ID Generator

-   Stores the last assigned ID in a table, avoiding gaps.
```java
@Id  
@GeneratedValue(strategy = GenerationType.TABLE)  
private Long id;
```
Less efficient for high-volume inserts.

### Conclusion

-   If sequential order is critical, use `IDENTITY` or `SEQUENCE` with allocationSize=1`.
-   If performance matters, allow preallocation and accept possible gaps.
-   If you want full control, use a table-based generator.

## N+1 Query Problem — Scenario-Based Interview Answers

### 1. What is the N+1 Query Problem?

The N+1 Query Problem happens when Hibernate or JPA executes one query to fetch the parent entities (N) and then executes N separate queries to fetch the associated child entities.

**Example of the Problem:**

Consider the entity relationship:
```java
@Entity  
public class Department {  
    @Id @GeneratedValue  
    private Long id;  
      
    @OneToMany(mappedBy = "department", fetch = FetchType.LAZY)  
    private List<Employee> employees;  
}
```
If you execute:
```java
List<Department> departments = departmentRepository.findAll();  
for (Department dept : departments) {  
    System.out.println(dept.getEmployees()); // Triggers separate queries!  
}
```
**Queries Executed (N+1 Issue)**

**First Query (fetches all departments — “1”)**
```sql
-   SELECT * FROM department;
```
**N Queries (fetches employees for each department separately)**
```sql
-   SELECT * FROM employee WHERE department_id = 1;
-   SELECT * FROM employee WHERE department_id = 2;
-   SELECT * FROM employee WHERE department_id = 3;
```
— and so on for every department…

Note: If there are 100 departments, this results in 101 queries (1 for departments + 100 for employees). This degrades performance significantly!

### 2. How can you fix it using `JOIN FETCH` or Entity Graphs?

The best way to fix N+1 queries is by fetching the related entities in a single query using `JOIN FETCH` or Entity Graphs.

**Solution 1: Using** `**JOIN FETCH**`

Modify the query to fetch departments along with employees in one query:
```java
@Query("SELECT d FROM Department d JOIN FETCH d.employees")  
List<Department> findAllWithEmployees();
```
Now, only ONE query executes:
```sql
SELECT d.*, e.* FROM department d   
LEFT JOIN employee e ON d.id = e.department_id;
```
This eliminates N+1 queries by fetching departments and employees together.

**Solution 2: Using Entity Graphs**

**Entity Graphs** are a feature in JPA that allow fine-grained control over which entity relationships should be eagerly fetched without modifying entity annotations (`FetchType.LAZY` or `FetchType.EAGER`) or writing custom queries (`JOIN FETCH`).

Entity Graphs allow dynamic fetching without modifying queries. Define an entity graph in the `Department` entity:
```java
@NamedEntityGraph(  
    name = "Department.employees",  
    attributeNodes = @NamedAttributeNode("employees")  
)  
@Entity  
public class Department {  
    @Id @GeneratedValue  
    private Long id;  
      
    @OneToMany(mappedBy = "department", fetch = FetchType.LAZY)  
    private List<Employee> employees;  
}
```
Now, modify the repository method:
```java
@EntityGraph(value = "Department.employees", type = EntityGraphType.LOAD)  
@Query("SELECT d FROM Department d")  
List<Department> findAllWithEmployees();
```
Now, departments and employees are fetched in one query, avoiding N+1 queries.

### 3. How would using `@BatchSize` or `@Fetch(FetchMode.SUBSELECT)` improve performance?

If you cannot modify queries directly (e.g., using `JOIN FETCH`), Hibernate provides two batch fetching strategies:

**1.** `**@BatchSize**` **(Batch Fetching)**

Fetches related entities in batches instead of one by one.
```java
@OneToMany(mappedBy = "department", fetch = FetchType.LAZY)  
@BatchSize(size = 10)  // Fetch employees in batches of 10  
private List<Employee> employees;
```
**How it works?**

-   Instead of fetching employees one-by-one for each department, Hibernate fetches them 10 at a time.
-   Reduces the number of queries from N to N/10.

**2.** `**@Fetch(FetchMode.SUBSELECT)**`

Fetches all child entities in one subquery instead of separate queries.
```java
@OneToMany(mappedBy = "department", fetch = FetchType.LAZY)  
@Fetch(FetchMode.SUBSELECT)  
private List<Employee> employees;
```
**How it works?**

Instead of:
```sql
SELECT * FROM employee WHERE department_id= 1;  
SELECT * FROM employee WHERE department_id= 2;
```
It executes one subquery:
```sql
SELECT * FROM employee WHERE department_id IN   
(SELECT id FROM department);
```

Reduces query count to 2 (1 for departments, 1 for all employees) instead of N+1 queries.

-   N+1 Query Problem happens when multiple queries fetch related entities lazily.
-   Best Fix: Use `JOIN FETCH` or Entity Graphs to load all data in one query.
-   Alternative Fixes: Use `@BatchSize` or `@Fetch(FetchMode.SUBSELECT)` if you can't modify queries.

### Soft Delete Implementation in JPA/Hibernate

### What is Soft Delete?

Soft delete means marking a record as inactive instead of physically deleting it from the database. This is useful when you need to retain historical data or recover deleted records.

### 1. How to Implement Soft Delete in JPA?

There are multiple ways to implement soft delete, but the most common approach is adding a “deleted” flag to the entity.

**Step 1: Add a Soft Delete Flag (**`**isDeleted**`**)**
```java
@Entity  
public class User {  
    @Id @GeneratedValue  
    private Long id;  
      
    private String name;  
      
    private boolean isDeleted = false;  // Soft delete flag  
  
    // Getters & Setters  
}
```
Instead of deleting a record, update `isDeleted` to `true`.

**Step 2: Modify the Delete Method**

Instead of calling `entityManager.remove(entity)`, update the flag:
```java
@Transactional  
public void softDeleteUser(Long userId) {  
    User user = entityManager.find(User.class, userId);  
    if (user != null) {  
        user.setDeleted(true);  
        entityManager.merge(user);  // Mark as deleted instead of removing  
    }  
}
```

This prevents actual deletion from the database.

### 2. How to Exclude Deleted Entities Automatically?

By default, JPA will still fetch soft-deleted records unless explicitly filtered out.

**Solution 1: Use** `**@Where**` **(Hibernate-Specific)**

Modify the entity to exclude soft-deleted records:
```java
@Entity  
@Where(clause = "is_deleted = false")  // Automatically filter out deleted rows  
public class User {  
    @Id @GeneratedValue  
    private Long id;  
      
    private String name;  
      
    @Column(name = "is_deleted")  
    private boolean isDeleted = false;  
}
```

Now, all queries will automatically exclude soft-deleted records without modifying them.

**Solution 2: Use** `**@SQLDelete**` **to Override the Delete Query**

Hibernate allows overriding the default `DELETE` operation to perform an `UPDATE` instead:
```java
@Entity  
@SQLDelete(sql = "UPDATE user SET is_deleted = true WHERE id = ?")  
@Where(clause = "is_deleted = false")  
public class User {  
    @Id @GeneratedValue  
    private Long id;  
  
    private String name;  
  
    private boolean isDeleted = false;  
}
```
Now, calling `entityManager.remove(user)` will soft delete instead of physically deleting the record.

### 3. Downsides of Using `@SQLDelete` with Hibernate

While `@SQLDelete` is powerful, it has some drawbacks:

**Soft-Deleted Entities are Still in the Cache**

-   Hibernate caches entities before applying `@SQLDelete` , so they may still be accessible if cached before deletion.
-   You may need to manually evict cache:entityManager.clear(); // Clears persistence context

**Relationships Are Not Automatically Handled**

-   If an entity has cascading relationships, `@SQLDelete` does not update child entities.
-   You may need to manually handle cascading soft deletes.

**Queries with** `**JOIN**` **May Still Fetch Deleted Records**

-   `@Where` only works on single-table queries.
-   If you run a `JOIN` query, soft-deleted entities may still be included.

**Best Practice**: Combine `@SQLDelete` with `@Where`, but be cautious when using complex queries.

### Conclusion

-   Soft Delete is implemented using a boolean flag (`isDeleted`) instead of removing records.
-   Use `@Where(clause = "is_deleted = false")` to automatically exclude deleted entities.
-   Use `@SQLDelete` to override the delete query and mark records as deleted instead of removing them.
-   Be aware of caching issues, cascading deletes, and `JOIN` queries that may still fetch deleted data.


# @Formula Annotation

### What is the `@Formula` Annotation?

The `@Formula` annotation in Hibernate allows you to define a calculated field in your entity class. This field is computed dynamically based on an SQL expression provided in the annotation. The result is fetched along with the entity data during runtime, without persisting the field in the database.

### Why Use `@Formula`?

Here are some reasons why `@Formula` is a game-changer:

1.  Dynamic Computation: It computes fields dynamically at runtime, saving you from persisting unnecessary data.
2.  Cleaner Code: By defining the logic in the entity itself, you eliminate the need for additional service or mapper logic.
3.  Database-Level Efficiency: The computation is performed at the database level, reducing the load on your application.
4.  Versatility: It can handle a wide range of use cases, from simple arithmetic to complex SQL expressions.

### Real-Life Example: Calculating Monthly Utility Bills

Let’s take a real-life example to understand the power of `@Formula`. Imagine you’re building a utility billing system for an apartment complex. Each apartment has multiple utility meters (e.g., electricity, water, gas), and you need to calculate the total monthly bill for each apartment based on the usage recorded by these meters.

### The Problem

Each utility meter records the usage in units (e.g., kilowatt-hours for electricity, cubic meters for water). The cost per unit varies for each utility. For example:

-   Electricity: $0.12 per kWh
-   Water: $0.05 per cubic meter
-   Gas: $0.08 per cubic meter

Your task is to calculate the total monthly bill for each apartment dynamically, without persisting the calculated value in the database.

### Step 1: Define the Entity

Here’s how you can define the `Apartment` entity with the `@Formula` annotation:
```java
@Entity  
public class Apartment {  
    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    private Long id;  
    private String apartmentNumber;  
    @OneToMany(mappedBy = "apartment")  
    private List<UtilityMeter> utilityMeters;  
    @Formula("(SELECT SUM(m.usage * CASE m.type " +  
             "WHEN 'ELECTRICITY' THEN 0.12 " +  
             "WHEN 'WATER' THEN 0.05 " +  
             "WHEN 'GAS' THEN 0.08 " +  
             "END) " +  
             "FROM utility_meter m WHERE m.apartment_id = id)")  
    private double totalMonthlyBill;  
    // Getters and Setters  
}
```
In this example:

-   The `@Formula` annotation calculates the `totalMonthlyBill` field dynamically.
-   The SQL expression sums up the usage of all utility meters for the apartment, multiplying each usage by the corresponding cost per unit based on the utility type.

### Step 2: Define the Utility Meter Entity

The `UtilityMeter` entity represents the individual utility meters for each apartment:
```java
@Entity  
public class UtilityMeter {  
    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    private Long id;  
    @ManyToOne  
    @JoinColumn(name = "apartment_id")  
    private Apartment apartment;  
    private String type; // ELECTRICITY, WATER, GAS  
    private double usage; // Usage in units  
    // Getters and Setters  
}
```
### Step 3: Fetch Data Dynamically

When you fetch the `Apartment` entity, the `totalMonthlyBill` field is computed dynamically based on the SQL expression. For example: code
```java
@RestController  
@RequestMapping("/apartments")  
public class ApartmentController {  
  @Autowired  
    private ApartmentRepository apartmentRepository;  
    @GetMapping  
    public List<Apartment> getAllApartments() {  
        return apartmentRepository.findAll();  
    }  
}
```
When you call the `getAllApartments` endpoint, the `totalMonthlyBill` field is included in the response without any additional logic.

### Step 4: Validate the Results

To validate that the `totalMonthlyBill` field is computed dynamically, you can check the generated SQL query. Hibernate will include the SQL expression in the query, ensuring that the computation is done at the database level.

For example, the generated SQL query might look like this:
```sql
SELECT a.id, a.apartment_number,   
       (SELECT SUM(m.usage * CASE m.type   
                             WHEN 'ELECTRICITY' THEN 0.12   
                             WHEN 'WATER' THEN 0.05   
                             WHEN 'GAS' THEN 0.08   
                             END)   
        FROM utility_meter m WHERE m.apartment_id = a.id) AS totalMonthlyBill  
FROM apartment a;
```
This proves that the computation is performed on the fly and not persisted in the database.

### Key Points to Remember

1.  Field Not Persisted: The field annotated with `@Formula` is not stored in the database. It is computed dynamically during runtime.
2.  SQL Expression: The logic inside the `@Formula` annotation must be a valid SQL expression.
3.  Database Dependency: The performance of the computation depends on the database’s ability to handle the query efficiently.
4.  Use Cases: `@Formula` is ideal for scenarios where you need to compute derived fields, such as total bills, aggregated metrics, or age based on the date of birth.

### When to Avoid `@Formula`

While `@Formula` is a powerful tool, it’s not suitable for every scenario. Here are some cases where you might want to avoid using it:

1.  Complex Logic: If the computation involves complex logic that cannot be expressed in SQL, it’s better to handle it in your Java code.
2.  Performance Concerns: For large datasets, the additional computation in the SQL query might impact performance.
3.  Database Portability: If you’re using multiple databases with different SQL dialects, the SQL expression in `@Formula` might not be portable.

### Conclusion

The `@Formula` annotation is a hidden gem in Hibernate that can significantly simplify your code and improve application performance. By allowing you to compute derived fields dynamically, it eliminates the need for redundant logic and reduces database queries. Whether you’re calculating utility bills, total working hours, or any other derived field, `@Formula` can be a game-changer.

So, the next time you find yourself writing custom logic to compute a derived field, consider using `@Formula`. It’s simple, efficient, and incredibly powerful.

---
# How Hibernate ORM Works Under the Hood

### 1. Overview of Hibernate ORM

Hibernate ORM acts as a bridge between your Java application and the database, abstracting away the complexities of data management. By mapping Java classes to database tables, Hibernate handles CRUD (Create, Read, Update, Delete) operations with ease.

###### 1.1 How Hibernate Maps Java Objects to Database Tables

At its core, Hibernate uses metadata annotations or XML configuration to define how Java classes are mapped to database tables. Each class represents a table, and each field in the class corresponds to a column in the table. For example:
```java
@Entity  
@Table(name = "users")  
public class User {  
    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    private Long id;  
  
    @Column(name = "username")  
    private String username;  
  
    @Column(name = "email")  
    private String email;  
  
    // Getters and setters  
}
```

Hibernate provides two primary ways to define mappings between Java objects and database tables:

-   **Annotations**: You can use annotations directly in your Java classes to define how they should be mapped to database tables. For example, **@Entity** denotes a class as an entity that should be mapped to a table, and **@Table** specifies the table name. Properties in the class can be annotated with **@Column** to map to specific columns in the table.
-   **XML Configuration**: Alternatively, Hibernate allows you to define mappings in XML configuration files. These files specify how each class maps to a table and how each property maps to a column.

Hibernate uses configuration files (e.g., hibernate.cfg.xml) to set up database connections, specify dialects, and define other properties. The configuration file tells Hibernate how to connect to the database and what the underlying database specifics are.

### 1.2 The Hibernate Session

A Session is used to interact with the database. It provides methods for CRUD operations (create, read, update, delete) and manages the persistence state of objects.

Hibernate uses a SessionFactory to create Session instances. It’s a thread-safe object that is responsible for creating sessions and managing cache and transactions.

![Image](https://miro.medium.com/v2/resize:fit:640/0*IuXLxBLOpRWhcKXM.png)

Here’s how Session works:

-   **Open Session**: Hibernate opens a session to interact with the database.
-   **Transaction Management**: Sessions are used within transactions to ensure atomicity.
-   **Session Operations**: CRUD operations are performed using the session.
-   **Close Session**: After operations are complete, the session is closed.

### 2. How Hibernate Handles Transactions

Transactions ensure that a series of operations either complete successfully or fail as a unit. Hibernate abstracts transaction management, allowing you to work with transactions in a more intuitive way.

Transactions in Hibernate are managed by the Transaction interface, which allows you to begin, commit, or rollback transactions. Here’s how it works:

-   **Begin Transaction**: Hibernate’s **Session** object is used. You begin a transaction with the **beginTransaction()** method on the **Session** object. This method returns a Transaction object, which represents the transactional context.
-   **Commit Transaction**: To save the changes made during the transaction to the database, you call the **commit()** method on the **Transaction** object. This method ensures that all the changes made during the transaction are persisted.
-   **Rollback Transaction**: If an error occurs during the transaction, you can call the **rollback()** method to undo all changes made during the transaction. This method reverts the database to its state before the transaction began.

![Image](https://miro.medium.com/v2/resize:fit:868/0*Q59veNm_8Cn5EmuQ.png)

A Session maintains a persistence context, which tracks changes to entities and manages their synchronization with the database.

-   **Auto-Flush**: Hibernate’s Session automatically flushes changes to the database when a transaction is committed. This means that any pending changes are sent to the database, ensuring consistency between the session and the database.
-   **Transaction Synchronization**: Hibernate synchronizes its transactions with the underlying database using the Java Transaction API (JTA) or JDBC transactions. This synchronization ensures that the transaction boundaries are properly managed and that changes are committed or rolled back as a single unit of work.

For applications that require distributed transactions or need to integrate with Java EE environments, Hibernate can be configured to use the Java Transaction API (JTA). JTA allows for managing transactions across multiple resources, such as databases and messaging systems.

### 3. Hibernate’s Internal Mechanisms

### 3.1 Bytecode Enhancement

**Bytecode enhancement** is a technique used by Hibernate to optimize the performance of entity operations. It involves modifying the bytecode of Java classes at runtime, enabling more efficient operations and reducing overhead.

**How Bytecode Enhancement Works**

**Instrumentation**: Hibernate uses bytecode instrumentation to modify the compiled bytecode of entity classes. This modification happens at runtime, allowing Hibernate to inject additional logic into the entity classes without altering the original source code. This process is typically done using tools like Java agents or bytecode manipulation libraries such as ASM or Javassist.

**Enhancement Capabilities:**

-   **Lazy Loading**: Enhancement allows for the lazy loading of entity properties. Instead of loading all properties immediately, Hibernate can delay the loading of specific fields until they are actually accessed. This helps in reducing the initial load time and memory usage.
-   **Dirty Checking**: Hibernate can enhance entities to support efficient dirty checking. This means it can keep track of changes to entities more effectively, only persisting modified fields to the database rather than the entire entity.
-   **Field Access**: Bytecode enhancement can optimize access to private fields of entities, allowing Hibernate to directly interact with fields instead of relying on getters and setters. This reduces the overhead associated with property access.

Enhancement can be applied at build time using tools integrated into the build process, such as Maven or Gradle plugins. Some enhancement operations are performed at runtime, often using Java agents or specific Hibernate configurations.

**Benefits of Bytecode Enhancement**

By optimizing entity operations, bytecode enhancement can significantly improve performance, particularly in scenarios with complex entity relationships or large datasets.

Lazy loading and field access optimizations reduce the amount of data loaded into memory and the frequency of database queries, which leads to more efficient resource usage.

### 3.2 Proxy Objects

**Proxy objects** are another critical mechanism used by Hibernate to optimize performance, specifically through lazy loading.

**How Proxy Objects Work**

**Lazy Loading**: Hibernate uses proxy objects to implement lazy loading for associations and entities. When you fetch an entity with associations that are marked as lazy, Hibernate does not load the associated data immediately. Instead, it returns a proxy object.

**Proxy Object Characteristics:**

-   **Placeholder**: A proxy object acts as a placeholder for the actual entity. It contains a reference to the entity’s identifier and the session it belongs to.
-   **On-Demand Loading**: The actual data is loaded from the database only when the properties or methods of the proxy are accessed. This is achieved through method interception.
-   **Transparent Access**: From the developer’s perspective, interacting with a proxy object is similar to interacting with a fully-loaded entity. Hibernate handles the behind-the-scenes data retrieval.

**How Proxies Are Created**

**Dynamic Proxies**: Hibernate generates dynamic proxies at runtime. These proxies extend the entity class and implement the entity’s interfaces, allowing them to intercept method calls and load data as needed.

**Static Proxies**: In some cases, static proxies can be used, especially when bytecode enhancement is employed. These proxies are pre-generated and provide the same lazy-loading benefits.

**Benefits of Proxy Objects**

Proxy objects enable efficient data loading by fetching related data only when it is actually required. This reduces the amount of data loaded into memory and minimizes unnecessary database queries.

By deferring data loading until it is needed, proxy objects help improve overall application performance, especially in scenarios involving complex relationships or large datasets.

### 4. Conclusion

Hibernate ORM is a powerful tool for managing database interactions in Java applications. By understanding its internal mechanisms, such as how it maps objects, handles transactions, and optimizes performance, you can leverage its full potential in your projects.