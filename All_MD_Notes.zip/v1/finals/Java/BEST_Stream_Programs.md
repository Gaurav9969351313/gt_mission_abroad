# BEST Stream Programs

- Emps with Salary greater than given range
    ```java
    import java.util.List;  
    import java.util.stream.Collectors;  
    
    class Employee {  
        String name;  
        double salary;  
    
        public Employee(String name, double salary) {  
            this.name = name;  
            this.salary = salary;  
        }  
    
        @Override  
        public String toString() {  
            return name + " - " + salary;  
        }  
    }  
    
    public class EmployeeStreamExample {  
        public static void main(String[] args) {  
            List<Employee> employees = List.of(  
                    new Employee("Alice", 50000),  
                    new Employee("Bob", 70000),  
                    new Employee("Charlie", 60000)  
            );  
    
            List<Employee> highEarners = employees.stream()  
                    .filter(e -> e.salary > 60000)  
                    .collect(Collectors.toList());  
    
            highEarners.forEach(System.out::println);  
        }  
    }
    ```
- Employee with the Highest Salary
    ```java
    Optional<Employee> highestPaid = employees.stream()  
            .max(Comparator.comparingDouble(e -> e.salary));  
    
    highestPaid.ifPresent(System.out::println);
    ```
- Group Employees by Department
    ```java
    Map<String, List<EmployeeWithDept>> groupedByDept = employees.stream()  
                    .collect(Collectors.groupingBy(e -> e.department));  
    
    groupedByDept.forEach((dept, empList) -> {  
            System.out.println(dept + ": " + empList);  
    });
    ```
- Compute Average Salary of Employees
    ```java
    OptionalDouble avgSalary = employees.stream()  
                    .mapToDouble(e -> e.salary)  
                    .average();  
    
    avgSalary.ifPresent(avg -> System.out.println("Average Salary: " + avg));
    ```
- Employees whose Names Start with ‘A’
    ```java
    List<Employee> filteredEmployees = employees.stream()  
            .filter(e -> e.name.startsWith("A"))  
            .collect(Collectors.toList());        
    filteredEmployees.forEach(System.out::println);   
    ```
    **Output:**
    ```shell
    Alice - 50000.0  
    Alex - 65000.0
    ```
- Employee List to a Map with Name as Key
    ```java
    Map<String, Double> employeeMap = employees.stream()  
                    .collect(Collectors.toMap(e -> e.name, e -> e.salary));  
            System.out.println(employeeMap);
    ```
    **Output:**
    ```shell
    {Alice=50000.0, Bob=70000.0, Charlie=60000.0}
    ```
- Count Employees in Each Department
    ```java
    Map<String, Long> departmentCount = employees.stream()  
              .collect(Collectors.groupingBy(e -> e.department, Collectors.counting()));  
            System.out.println(departmentCount);
    ```
    **Output:**
    ```shell
    {IT=2, HR=2, Finance=1}
    ```

- Total Salary Paid for Each Department
    ```java
    Map<String, Double> totalSalaryByDept = employees.stream()  
            .collect(Collectors.groupingBy(e -> e.department,   
                    Collectors.summingDouble(e -> e.salary)));  
    System.out.println(totalSalaryByDept);  
    ```
    ```shell
    **Output:**

    {IT=110000.0, HR=145000.0, Finance=55000.0}
    ```

- 2nd Highest Salary
    ```java
    OptionalDouble secondHighest = employees.stream()  
                    .mapToDouble(e -> e.salary)  
                    .distinct()  
                    .boxed()  
                    .sorted((a, b) -> Double.compare(b, a)) // Descending order  
                    .skip(1) // Skip the highest  
                    .findFirst();        
  secondHighest.ifPresent(sal -> System.out.println("Second Highest Salary: " + sal));    
    ```
    **Output:**
    ```shell
    Second Highest Salary: 70000.0
    ```
-  Employees Who Have the Same Salary
    ```java
    Map<Double, List<String>> salaryToEmployees = employees.stream()  
            .collect(Collectors.groupingBy(e -> e.salary,   
                    Collectors.mapping(e -> e.name, Collectors.toList())));        
                    salaryToEmployees.forEach((salary, names) -> {  
            if (names.size() > 1) { // Only print if there are duplicates  
            System.out.println("Salary: " + salary + " -> Employees: " + names);  
            }  
    });   
    ```
    **Output:**
    ```shell
    Salary: 50000.0 -> Employees: [Alice, Charlie]  
    Salary: 70000.0 -> Employees: [Bob, Eve]
    ```
- Employees with Top 3 Salaries
    ```java
    List<Employee> topThree = employees.stream()  
                 .sorted((e1, e2) -> Double.compare(e2.salary, e1.salary)) // Descending  
                    .limit(3)  
                    .collect(Collectors.toList());  
            topThree.forEach(System.out::println);    
    ```
    **Output:**
    ```shell
    Eve - 90000.0  
    David - 80000.0  
    Bob - 70000.0
    ```
- Department with the Highest Average Salary
    ```java
    Map<String, Double> avgSalaryByDept = employees.stream()  
            .collect(Collectors.groupingBy(e -> e.department,  
                    Collectors.averagingDouble(e -> e.salary)));        
    Optional<Map.Entry<String, Double>> highestAvgDept = avgSalaryByDept.entrySet().stream()  
            .max(Map.Entry.comparingByValue());        
            
  highestAvgDept.ifPresent(entry ->  
         System.out.println("Department with highest avg salary: " 
         	+ entry.getKey() + " - " + entry.getValue()));   
    ```
    **Output:**
    ```shell
    Department with highest avg salary: HR - 72500.0
    ```
- Employees Who Have Worked for More Than 5 Years in the Company
    ```java
    List<EmployeeWithExp> experiencedEmployees = employees.stream()  
            .filter(e -> e.yearsOfExperience > 5)  
            .collect(Collectors.toList());
    experiencedEmployees.forEach(System.out::println);    

    **Output:**
    ```shell
    Bob - 70000.0 - 7 years  
    Charlie - 60000.0 - 6 years  
    Eve - 75000.0 - 9 years
    ```
-  Flatten a List of Employee Projects
    ```java
    import java.util.List;  
    import java.util.stream.Collectors;  
    import java.util.stream.Stream;  
    class EmployeeWithProjects {  
        String name;  
        List<String> projects;  
        public EmployeeWithProjects(String name, List<String> projects) {  
            this.name = name;  
            this.projects = projects;  
        }  
    }  
    public class FlattenEmployeeProjects {  
        public static void main(String[] args) {  
            List<EmployeeWithProjects> employees = List.of(  
                    new EmployeeWithProjects("Alice", List.of("Project A", "Project B")),  
                    new EmployeeWithProjects("Bob", List.of("Project C", "Project D")),  
                    new EmployeeWithProjects("Charlie", List.of("Project E"))  
            );  
            List<String> allProjects = employees.stream()  
                    .flatMap(e -> e.projects.stream())  
                    .distinct()  
                    .collect(Collectors.toList());  
            System.out.println("All Projects: " + allProjects);  
        }  
    }
    ```
    **Output:**
    ```shell
    All Projects: [Project A, Project B, Project C, Project D, Project E]
    ```
- Count Employees in Each Department Using Parallel Streams
    ```java
    Map<String, Long> departmentCount = employees.parallelStream()  
            .collect(Collectors.groupingBy(e -> e.department, Collectors.counting()));        
    System.out.println(departmentCount);   
    ```
    **Output:**
    ```shell
    {IT=2, HR=2, Finance=1}
    ```

- Employees with highest salary department wise
    ```java
    Map<String, Employee> highestPaidPerDept = employees.stream()  
            .collect(Collectors.groupingBy(e -> e.department,  
                    Collectors.collectingAndThen(  
                            Collectors.reducing((e1, e2) -> e1.salary > e2.salary ? e1 : e2),  
                            Optional::get  
                    )));  
    
    highestPaidPerDept.forEach((dept, emp) ->   
    System.out.println("Department: " + dept + " -> Highest Paid: " + emp));    
    ```
    # Output
    ```shell
    Department: IT -> Highest Paid: Grace - 85000.0 - IT  
    Department: HR -> Highest Paid: Eve - 75000.0 - HR  
    Department: Finance -> Highest Paid: Frank - 90000.0 - Finance
    ```
    1.  `**groupingBy(e -> e.department)**` → Groups employees **by department**
    2.  `**reducing((e1, e2) -> e1.salary > e2.salary ? e1 : e2)**` → Finds the **highest paid** employee in each department
    3.  `**collectingAndThen(..., Optional::get)**` → Extracts the actual employee object

- Peek for Debugging
    Use `peek` to inspect elements mid-stream without altering the pipeline.
    ```java
    List<String> names = List.of("Alice", "Bob", "Charlie");  
    names.stream()  
        .peek(name -> System.out.println("Processing: " + name))  
        .filter(name -> name.startsWith("A"))  
        .forEach(System.out::println);  
    // Output:  
    // Processing: Alice  
    // Processing: Bob  
    // Processing: Charlie  
    // Alice
    ```
- Generate Infinite Streams
    Create infinite sequences with `Stream.generate` or `Stream.iterate`.
    ```java
    Stream.iterate(0, i -> i + 2)  
        .limit(5)  
        .forEach(System.out::println);  
    // Output: 0, 2, 4, 6, 8
    ```

- FlatMap for Nested Collections

    Flatten nested lists with `flatMap`.
    ```java
    List<List<String>> nested = List.of(List.of("A", "B"), List.of("C", "D"));  
    List<String> flat = nested.stream()  
                            .flatMap(List::stream)  
                            .collect(Collectors.toList());  
    // Output: [A, B, C, D]
    ```

- Grouping with Collectors
    Group data by a property using `Collectors.groupingBy`.
    ```java
    List<String> words = List.of("apple", "banana", "apricot");  
    Map<Character, List<String>> grouped = words.stream()  
                  .collect(Collectors.groupingBy(word -> word.charAt(0)));  
    // Output: {a=[apple, apricot], b=[banana]}
    ```
- Partitioning for Boolean Conditions
    Split data into true/false groups with `Collectors.partitioningBy`.
    ```java
    List<Integer> numbers = List.of(1, 2, 3, 4);  
    Map<Boolean, List<Integer>> partitioned = numbers.stream()  
          .collect(Collectors.partitioningBy(n -> n % 2 == 0));  
    // Output: {false=[1, 3], true=[2, 4]}
    ```

- Custom Collectors

    Create a custom collector for specialized aggregation.
    ```java
    Collector<String, ?, String> joinWithPrefix = Collector.of(  
        StringBuilder::new,  
        (sb, s) -> sb.append("prefix-").append(s),  
        StringBuilder::append,  
        StringBuilder::toString  
    );  
    List<String> items = List.of("a", "b");  
    String result = items.stream().collect(joinWithPrefix);  
    // Output: prefix-aprefix-b
    ```

- TakeWhile/DropWhile for Conditional Slicing (Genius!)

    Java 9’s `takeWhile` and `dropWhile` let you slice streams based on a condition—perfect for ordered data.
    ```java
    List<Integer> numbers = List.of(1, 2, 3, 4, 5, 2);  
    List<Integer> taken = numbers.stream()  
                                .takeWhile(n -> n < 4)  
                                .collect(Collectors.toList());  
    // Output: [1, 2, 3]
    ```

**Why It’s Genius**: Unlike `filter`, `takeWhile` stops processing once the condition fails, making it more efficient for large datasets. It’s ideal for scenarios like processing logs until a certain event occurs.

- Parallel Streams with Caution
    Use `parallelStream` for performance, but ensure thread safety.
    ```java
    List<Integer> numbers = List.of(1, 2, 3, 4);  
    int sum = numbers.parallelStream()  
                    .mapToInt(Integer::intValue)  
                    .sum();  
    // Output: 10
    ```
- Stream of Optional Values

    Handle `Optional` values in a stream with `stream()` (Java 9+).
    ```java
    List<Optional<String>> optionals = List.of(Optional.of("A"), 
                          Optional.empty(), Optional.of("B"));  
    List<String> values = optionals.stream()  
                                .flatMap(Optional::stream)  
                                .collect(Collectors.toList());  
    // Output: [A, B]
    ```
- Teeing Collector for Multiple Reductions

    Java 12’s `Collectors.teeing` lets you perform two reductions and combine the results.
    ```java
    List<Integer> numbers = List.of(1, 2, 3, 4);  
    String result = numbers.stream()  
                        .collect(Collectors.teeing(  
                            Collectors.summingInt(Integer::intValue),  
                            Collectors.counting(),  
                            (sum, count) -> "Sum: " + sum + ", Count: " + count  
                        ));  
    // Output: Sum: 10, Count: 4
    ```

- Swap Two Variables Without Temp Variable (Java 7+)
    ```java
    a = a + b - (b = a);
    ```
    **Explanation:**

    -   Smart arithmetic trick to swap two integers without using a third variable.
    -   But use carefully to avoid confusion — prefer readability when needed.

    Works great for quick algorithm tricks.

    ![](https://miro.medium.com/v2/resize:fit:875/1*elXzDiXpzYo-Uw3py2UXiA.png)

- Initialize a List in One Line (Java 9+)
    ```java
    List<String> fruits = List.of("Apple", "Banana", "Cherry");
    ```
    **Explanation:**

    -   `List.of()` quickly creates an **immutable list** without needing `new ArrayList<>()` and manual adds.

    Cleaner and faster setup for small lists.

    ![](https://miro.medium.com/v2/resize:fit:875/1*W9uKTxhCpJkthW3WDfF8_g.png)

- Find the Max of Two Numbers
    ```java
    int max = Math.max(a, b);
    ```
    **Explanation:**

    -   Built-in method — no need for manual `if-else` to find maximum.
    -   `Math.max(a, b)` returns the larger of the two values.
    -   Works for `int`, `long`, `float`, and `double` types as well.

    Clean and fast.

    ![](https://miro.medium.com/v2/resize:fit:875/1*VVoETWDjO6JrJ1IsAmQc2w.png)

- Read All Lines from a File
    ```java
    List<String> lines = Files.readAllLines(Path.of("file.txt"));
    ```
    **Explanation:**

    -   Java NIO makes reading a whole text file into a list super easy.

    No more messy `BufferedReader` loops if you just need all lines.

- Convert List to Comma-Separated String
    ```java
    String result = String.join(", ", fruits);
    ```
    **Explanation:**

    -   Quickly joins list elements into a single string with commas.
    -   `String.join(", ", fruits)` joins all elements of the list into a single string separated by `,` .
    -   Clean and efficient way to format list data for output, logs, or CSV.

    Very useful for logs, APIs, CSV formats.

    ![](https://miro.medium.com/v2/resize:fit:875/1*siJCxtVLnSXetQc5Hy0ZKQ.png)

- Remove Null Values from a List
    ```java
    list.removeIf(Objects::isNull);
    ```
    **Explanation:**

    -   `removeIf` + method reference removes all null entries in one line.

    No need for manual `for` loops and checks.

    ![](https://miro.medium.com/v2/resize:fit:875/1*dxVRcb_2AurMiM469msrbA.png)

    -   `Objects::isNull` is a method reference that checks for `null`.
    -   `removeIf(...)` removes all elements that match the given predicate.
    -   Very handy for cleaning lists with minimal code.

- Get a Random Element from a List
    ```java
    String randomFruit = fruits.get(new Random().nextInt(fruits.size()));
    ```
    **Explanation:**

    -   Pick a random item by generating a random valid index.

- Count Items Matching a Condition
    ```java
    long count = list.stream().filter(x -> x > 10).count();
    ```
    **Explanation:**

    -   Stream + filter + count in one clean line.
    -   `list.stream()` creates a stream from the list.
    -   `.filter(x -> x > 10)` filters elements greater than 10.
    -   `.count()` returns how many matched the condition.

    Great for statistics, data filtering, and analytics.

    ![](https://miro.medium.com/v2/resize:fit:875/1*ziPSjzJB5PK1ithGEKI2ng.png)

- Sort a List in Descending Order
    ```java
    list.sort(Comparator.reverseOrder());
    ```
    **Explanation:**

    -   Sorts the list in descending order with one simple call.
    -   `Comparator.reverseOrder()` provides a comparator that reverses natural order.
    -   Works for types like `Integer`, `String`, etc. that implement `Comparable`.
    -   Mutates the original list (in-place sort).

    No need to write custom comparators manually.

    ![](https://miro.medium.com/v2/resize:fit:875/1*j1uRcOHg24ppln19zYYJxQ.png)

- Check If a String is a Palindrome
    ```java
    boolean isPalindrome = str.equals(new StringBuilder(str).reverse().toString());
    ```
    **Explanation:**

    -   Reverse the string using `StringBuilder` and compare with the original.
    -   `new StringBuilder(str).reverse().toString()` creates a reversed version of the string.
    -   `.equals(...)` compares it to the original.
    -   Works for simple palindrome checks (case-sensitive and no space handling).



- `Collections.nCopies()`

    **Introduced in:** JDK 1.2  
    **Description:** This method creates an immutable list with a specified number of copies of a single object.

    **Use Case:** Useful for initializing lists with placeholder values or creating repeated elements, like a list filled with zeros or default strings.

    **Example:**
    ```java
    List<String> placeholders = Collections.nCopies(5, "N/A");  
    System.out.println(placeholders); // Output: [N/A, N/A, N/A, N/A, N/A]
    ```
    **Pros:**
    -   Convenient for initializing lists with repeated values.
    -   Immutable, so it’s thread-safe and reduces unintended modifications.
    **Cons:**
    -   Limited flexibility, as the list cannot be modified after creation.

- `Collections.frequency()`

    **Introduced in:** JDK 1.5  
    **Description:** Counts the number of occurrences of a specified element in a collection.

    **Use Case:** Handy for counting occurrences, like finding the number of times a word appears in a list.

    **Example:**
    ```java
    List<String> words = Arrays.asList("apple", "banana", "apple", "orange", "banana", "apple");  
    int count = Collections.frequency(words, "apple");  
    System.out.println(count); // Output: 3
    ```
    **Pros:**
    -   Simplifies counting operations.
    -   Increases readability by eliminating the need for custom loops.
    **Cons:**

    -   Can be inefficient for large collections, especially if not backed by a `Set` or `Map`.

- `Collections.disjoint()`

    **Introduced in:** JDK 1.5  
    **Description:** Checks if two collections have no elements in common, returning `true` if they’re disjoint.

    **Use Case:** Useful for validating if two sets or lists have any overlapping elements, such as checking for overlapping user permissions.

    **Example:**
    ```java
    List<String> list1 = Arrays.asList("apple", "banana", "cherry");  
    List<String> list2 = Arrays.asList("date", "fig", "grape");  
    boolean isDisjoint = Collections.disjoint(list1, list2);  
    System.out.println(isDisjoint); // Output: true
    ```
    **Pros:**
    -   Simplifies overlap checking.
    -   Improves readability compared to manual iteration.
    **Cons:**
    -   May have a high time complexity for large collections without efficient backing.

- `Collections.singleton()`

    **Introduced in:** JDK 1.2  
    **Description:** Creates an immutable set containing a single specified element.

    **Use Case:** Ideal for representing collections that are guaranteed to contain only one element, such as a single status or identifier.

    **Example:**
    ```java
    Set<String> singletonSet = Collections.singleton("onlyElement");  
    System.out.println(singletonSet); // Output: [onlyElement]
    ```
    **Pros:**
    -   Enforces a single-item structure.
    -   Immutable and thread-safe.
    **Cons:**
    -   Cannot be modified or hold more than one item.

- `Collections.rotate()`

    **Introduced in:** JDK 1.4  
    **Description:** Rotates elements in a list by a specified distance, with positive values moving elements to the right and negative values moving them to the left.

    **Use Case:** Helpful in situations requiring cyclic shifts, such as board games or circular data structures.

    **Example:**
    ```java
    List<String> list = Arrays.asList("A", "B", "C", "D");  
    Collections.rotate(list, 2);  
    System.out.println(list); // Output: [C, D, A, B]
    ```
    **Pros:**
    -   Provides an efficient way to rearrange list elements.
    -   Simplifies circular data handling.
    **Cons:**
    -   Only works on `List` types, not arrays or other collections.

- `Collections.shuffle()`

    **Introduced in:** JDK 1.2  
    **Description:** Randomly shuffles the elements in a list.

    **Use Case:** Great for randomizing lists, useful in applications like card games, simulations, or tests.

    **Example:**
    ```java
    List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);  
    Collections.shuffle(numbers);  
    System.out.println(numbers); // Output: Randomly shuffled list, e.g., [3, 1, 5, 2, 4]
    ```
    **Pros:**
    -   In-place randomization without additional code.
    -   Efficient and well-suited for gaming applications.
    **Cons:**
    -   Limited to `List` collections and not applicable to sets or maps.

- `Collections.reverse()`

    **Introduced in:** JDK 1.2  
    **Description:** Reverses the order of elements in a list.

    **Use Case:** Commonly used in reversing sequences, such as reversing recent items in an activity log.

    **Example:**
    ```java
    List<String> list = Arrays.asList("A", "B", "C");  
    Collections.reverse(list);  
    System.out.println(list); // Output: [C, B, A]
    ```
    **Pros:**
    -   Simple, in-place reverse operation.
    -   Avoids the need for custom reversing logic.
    **Cons:**
    -   Only works with `List` types.

- `Collections.unmodifiableList()`, `unmodifiableSet()`, and `unmodifiableMap()`

    **Introduced in:** JDK 1.2  
    **Description:** Creates an unmodifiable view of a collection to prevent modification.

    **Use Case:** Great for returning collections without allowing modification, such as read-only configuration data.

    **Example:**
    ```java
    List<String> list = new ArrayList<>(Arrays.asList("A", "B", "C"));  
    List<String> unmodifiableList = Collections.unmodifiableList(list);  
    System.out.println(unmodifiableList); // Output: [A, B, C]  
    // unmodifiableList.add("D"); // Throws UnsupportedOperationException
    ```
    **Pros:**
    -   Enforces immutability for data integrity.
    -   Helps create secure, read-only collections.
    **Cons:**
    -   Creating a new view may add slight overhead.

- `Collections.emptyList()`, `emptySet()`, and `emptyMap()`

    **Introduced in:** JDK 1.2  
    **Description:** Returns immutable empty collections, useful as method return values.

    **Use Case:** Provides a non-null alternative when returning empty collections from methods.

    **Example:**
    ```java
    List<String> emptyList = Collections.emptyList();  
    System.out.println(emptyList); // Output: []  
    // emptyList.add("A"); // Throws UnsupportedOperationException
    ```
    **Pros:**
    -   Avoids `null` values for empty collections.
    -   Immutable, simplifying handling in multi-threaded contexts.
    **Cons:**
    -   Collections can’t be modified.

- `Collections.addAll()`

    **Introduced in:** JDK 1.2  
    **Description:** Adds all specified elements to a collection in a single operation.

    **Use Case:** Useful for bulk-adding elements to a collection at once.

    **Example:**
    ```java
    List<String> list = new ArrayList<>();  
    Collections.addAll(list, "A", "B", "C");  
    System.out.println(list); // Output: [A, B, C]
    ```
    **Pros:**
    -   Simplifies adding multiple elements at once.
    -   Improves readability.
    **Cons:**
    -   In-place operation modifies the existing collection.

- `Collections.synchronizedList()`, `synchronizedSet()`, and `synchronizedMap()`

    **Introduced in:** Java 1.2  
    **Description:** Wraps a collection in a thread-safe synchronized view.

    **Use Case:** Useful for ensuring thread safety in shared data across multiple threads.

    **Example:**
    ```java
    List<String> list = new ArrayList<>();  
    List<String> synchronizedList = Collections.synchronizedList(list);  
    synchronizedList.add("A");  
    System.out.println(synchronizedList); // Output: [A]
    ```
    **Pros:**
    -   Makes collections thread-safe without additional effort.
    -   Useful in multi-threaded environments.
    **Cons:**
    -   Synchronization may reduce performance due to locking.

- `Collections.checkedList()`, `checkedSet()`, and `checkedMap()`

    **Introduced in:** JDK 1.5  
    **Description:** Adds runtime type-checking to collections, enforcing generic types.

    **Use Case:** Helpful in debugging and catching `ClassCastException` by ensuring type-safety at runtime.

    **Example:**
    ```java
    List<String> list = new ArrayList<>();  
    List<String> checkedList = Collections.checkedList(list, String.class);  
    checkedList.add("A");  
    // checkedList.add(1); // Throws ClassCastException
    ```
    **Pros:**
    -   Adds a layer of type safety in cases with mixed or raw types.
    -   Useful for debugging and validating collection contents.
    **Cons:**
    -   Adds runtime overhead due to type-checking.

- Find the maximum value in the List<Integer>.
    
    ```java
    List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);  
    int max = numbers.stream()  
                    .max(Integer::compareTo)  
    // Above code uses method referene,   
    // Below commented code uses lamnda expression.  
    // numbers.stream().max((a, b) -> a.compareTo(b));  
    System.out.println(max); // Output: 5
    ```

- Given List<Employee>, Find employee with higest salary.
    ```java
    List<Employee> employees = Arrays.asList(  
                new Employee("John", 50000),  
                new Employee("Jane", 60000),  
                new Employee("Mark", 55000),  
                new Employee("Sophia", 75000),  
                new Employee("Alex", 40000)  
            );  
    
    Optional<Employee> highestSalaryEmployee = employees.stream()  
                .max(Comparator.comparingDouble(Employee::getSalary));  
    highestSalaryEmployee.ifPresent(System.out::println);  
    // Output  
    // Employee{name='Sophia', salary=75000.0}
    ```
- Given List<String>, Return String concatenating all Strings of List.
    ```java
    List<String> words = Arrays.asList("apple", "banana", "cherry");  
    String result = words.stream()  
                        .collect(Collectors.joining(", "));  
    System.out.println(result);   
    // Output: apple, banana, cherry
    ```
- Group List<Integer> by their evenness. (even or odd)
    ```java
    List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6);  
    Map<Boolean, List<Integer>> grouped = numbers.stream()  
                                                .collect(Collectors.groupingBy(n -> n % 2 == 0));  
    System.out.println(grouped);   
    // Output: {false=[1, 3, 5], true=[2, 4, 6]}
    ```
    `**Collectors.groupingBy**`: This is a collector that groups the elements of the stream based on a classifier function.
     
    **Classifier Function**: The lambda expression `n -> n % 2 == 0` checks if a number is even. It returns `true` for even numbers and `false` for odd numbers.
     
    As a result, the stream will be split into two groups: one for numbers where the condition is `true` (even numbers) and another for numbers where the condition is `false` (odd numbers).

- Given List<Employee>, Group them by Designation.
    ```java
    List<Employee> employees = Arrays.asList(  
                new Employee("Alice", "Developer"),  
                new Employee("Bob", "Manager"),  
                new Employee("Charlie", "Developer"),  
                new Employee("David", "Manager"),  
                new Employee("Eve", "Designer")  
            );  
    
    Map<String, List<Employee>> groupedByDesignation = employees.stream()  
                .collect(Collectors.groupingBy(Employee::getDesignation));  
    
    // Output  
    // Developer: [Employee{name='Alice', designation='Developer'}, Employee{name='Charlie', designation='Developer'}]  
    // Manager: [Employee{name='Bob', designation='Manager'}, Employee{name='David', designation='Manager'}]  
    // Designer: [Employee{name='Eve', designation='Designer'}]
    ```

- Given List<String>, Count the number of Strings that have length greater than 4
    ```java
    List<String> words = Arrays.asList("apple", "banana", "kiwi", "cherry");  
    long count = words.stream()  
                    .filter(w -> w.length() > 4)  
                    .count();  
    System.out.println(count);   
    // Output: 3
    ```

- Sort a List<String> in reverse alphabetical order.
    ```java
    List<String> words = Arrays.asList("apple", "banana", "cherry");  
    List<String> sortedWords = words.stream()  
                                    .sorted(Comparator.reverseOrder())  
                                    .collect(Collectors.toList());  
    System.out.println(sortedWords);   
    // Output: [cherry, banana, apple]
    ```

- Find all distinct elements.
    ```java
    List<Integer> numbers = Arrays.asList(1, 2, 2, 3, 4, 4, 5);  
    List<Integer> distinctNumbers = numbers.stream()  
                                        .distinct()  
                                        .collect(Collectors.toList());  
    System.out.println(distinctNumbers); // Output: [1, 2, 3, 4, 5]
    ```
- Check if all elements in a List<Integer> are positive.
    ```java
    List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);  
    boolean allPositive = numbers.stream()  
                                .allMatch(n -> n > 0);  
    System.out.println(allPositive);   
    // Output: true
    ```
     `**allMatch(Predicate<T> predicate)**`
    
     Purpose: Checks if all elements in the stream satisfy the given predicate.
     Returns:
     `true` if all elements match the predicate.
     `false` if at least one element does not match the predicate or the stream is empty.

     `**anyMatch(Predicate<T> predicate)**`
     Purpose: Checks if at least one element in the stream matches the given predicate.
     Returns:
     `true` if at least one element matches the predicate.
     `false` if no elements match the predicate or the stream is empty.

     `**noneMatch(Predicate<T> predicate)**`
     Purpose: Checks if no elements in the stream match the given predicate.
     Returns:
     `true` if no elements match the predicate.
     `false` if at least one element matches the predicate or the stream is empty.

- How to sort List<Employee> by salary

    ```java
        // Get a new sorted list by salary  
        List<Employee> sortedEmployees = employees.stream()  
                .sorted(Comparator.comparing(Employee::getSalary))  
                .collect(Collectors.toList());  
    ```
- Given List<String>, Find anagrams (An anagram is a word or phrase formed by rearranging the letters of another word or phrase, using all the original letters exactly once)
    ```java
    List<String> words = Arrays.asList("listen", "silent", "enlist", "rat", "tar", "god", "dog", "evil", "vile", "veil");  
    
    Map<String, List<String>> anagrams =  words.stream()  
                .collect(Collectors.groupingBy(word -> {  
                    char[] charArray = word.toCharArray();  
                    Arrays.sort(charArray); // Sort the characters  
                    return new String(charArray); // Return the sorted string  
                }));  
    
    anagrams.values().stream()  
                    .filter(group -> group.size() > 1) // Filter only groups with more than one anagram  
                    .forEach(System.out::println); // Output the anagram groups  
    
    // Output  
    // [silent, listen, enlist]  
    // [tar, rat]  
    // [dog, god]  
    // [vile, evil, veil]
    ```
- Generate Fibonacci series
    ```java
    // Generate first 10 Fibonacci numbers  
            Stream.iterate(new long[]{0, 1}, fib -> new long[]{fib[1], fib[0] + fib[1]})  
                .limit(10) // Limit to the first 10 numbers  
                .map(n -> n[0]) // Extract the first element of each pair  
                .forEach(System.out::println);
    ```
    Please refer below to undestand how stream.iterate works

     **Stream<T> Stream.iterate(T seed, UnaryOperator<T> f)**  
     seed: The initial element of the stream.  
     f: A unary operator that takes the previous element and produces the next element.

- Given List<Employee>, Get a Map which has Department, and Employee Name drawing highest salary in the department.
    ```java
    Map<String, String> highestSalaryEmployees = employees.stream()  
                .collect(Collectors.groupingBy(Employee::getDepartment,  
                        Collectors.collectingAndThen(  
                            Collectors.maxBy(Comparator.comparingDouble(Employee::getSalary)),  
                            emp -> emp.map(Employee::getName).orElse(null)  
                        )  
                ));
    ```
 Explanation
 
 **Grouping by Department**:
 `Collectors.groupingBy(Employee::getDepartment)` groups the employees by their department.
 
 **Finding the Employee with Highest Salary**:
 `Collectors.maxBy(Comparator.comparingDouble(Employee::getSalary))` finds the employee with the maximum salary in each group.
 `collectingAndThen(..., emp -> emp.map(Employee::getName).orElse(null))` is used to extract the employee's name from the `Optional<Employee>` returned by `maxBy`.
 
 **Collecting to Map**:
 The result is collected into a `Map<String, String>`, where the key is the department and the value is the name of the employee with the highest salary.

- Given List<Employee>, Return Map with Employee Name and Salary
    ```java
    Map<String, Double> employeeSalaryMap = employees.stream()  
                .collect(Collectors.toMap(Employee::getName, Employee::getSalary);
    ```
- Given List<Employee>, Remove Employee with same Name from the List.
    ```java
    Set<String> seenNames = new HashSet<>();  
            
    List<Employee> uniqueEmployees = employees.stream()  
                .filter(emp -> seenNames.add(emp.getName())) // Add name to set and filter duplicates  
                .collect(Collectors.toList()); // Collect to list
    ```
- Given`List<Employee>` where each `Employee` has a `List<String>` of skills. Use `flatMap` to create a `List<String>` that contains all unique skills across all employees.
    ```java
    List<String> uniqueSkills = employees.stream()  
        .flatMap(emp -> emp.getSkills().stream())  
        .distinct()  
        .collect(Collectors.toList());
    ```
- Use `flatMap` to create a `List<String>` of all individual words from a list of sentences.
    ```java
    List<String> sentences = Arrays.asList("Hello world", "Java 8 Streams", "flatMap example");  
    
    List<String> words = sentences.stream()  
        .flatMap(sentence -> Arrays.stream(sentence.split(" ")))  
        .collect(Collectors.toList());  
    
    System.out.println(words);   
    // Output: [Hello, world, Java, 8, Streams, flatMap, example]
    ```

- Given List<Integer>, Find Pair of numbers whose sum is equal to given target number.
    ```java
    List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6);  
    int target = 7;  
    
    List<List<Integer>> pairs = numbers.stream()  
                .flatMap(num1 -> numbers.stream()  
                    .filter(num2 -> num1 + num2 == target)  
                    .map(num2 -> Arrays.asList(num1, num2)))  
                .collect(Collectors.toList());  
    // Output  
    // [1, 6]  
    // [2, 5]  
    // [3, 4]
    ```
- Find the employee with the second highest salary from a `List<Employee>`
    ```java
    List<Employee> employees = Arrays.asList(  
                new Employee("Alice", 70000),  
                new Employee("Bob", 80000),  
                new Employee("Charlie", 60000),  
                new Employee("David", 90000),  
                new Employee("Eve", 80000)  
            );  
    
    Optional<Employee> secondHighest =  employees.stream()  
                .sorted(Comparator.comparingDouble(Employee::getSalary).reversed())  
                .distinct() // To avoid duplicates in case of equal salaries  
                .skip(1) // Skip the highest salary  
                .findFirst(); // Get the second highest salary  
    // Output  
    // Employee{name='Bob', salary=80000.0}
    ```

    # 10 Java Snippets That Will Solve 90% of Your Coding Problems

### 1. Safe Getters Without Null Checks (Because NPEs are Evil)
```java
Optional.ofNullable(user)  
        .map(User::getAddress)  
        .map(Address::getCity)  
        .orElse("Unknown City");
```
**Reality:** If your app crashes because of a `NullPointerException`, you probably deserve it.

Start using `Optional` and stop treating `null` like an old friend.

### 2. Read a File in 1 Line (No More Scanner Torture)

List<String> lines = Files.readAllLines(Paths.get("file.txt"));

Remember manually reading files line by line with `BufferedReader`?

Yeah, we don’t do that here anymore. It’s 2025, bro.

### 3. One-Liner List Filtering (Lambdas FTW)
```java
List<String> filtered = list.stream()  
        .filter(s -> s.startsWith("A"))  
        .collect(Collectors.toList());
```
Use lambdas or die trying.

Iterating over lists like it’s 1999 is not a vibe.

### 4. Timing Your Code (Because “Fast Enough” Isn’t a Metric)
```java
long start = System.nanoTime();  
// your code here  
long end = System.nanoTime();  
System.out.println("Duration: " + (end - start) + " ns");
```
Benchmarks aren’t just for nerds in performance tuning meetings.

They’re how you catch that innocent-looking nested loop murdering your app.

### 5. Initialize a Map Like a Boss
```java
Map<String, Integer> map = new HashMap<>() {{  
    put("A", 1);  
    put("B", 2);  
}};
```

Is it a double-brace initialization hack? Yes.

Is it clean? Nope.

Do we care? Also no.

It works.

### 6. Convert List to Map Without a For-Loop
```java
Map<Integer, String> map = list.stream()  
        .collect(Collectors.toMap(String::length, Function.identity()));
```
If you’re still building maps with `for` loops, please hand in your Java badge.

### 7. Retry Logic That Doesn’t Make You Cry
```java
int attempts = 3;  
while (attempts-- > 0) {  
    try {  
        doSomethingRisky();  
        break;  
    } catch (Exception e) {  
        if (attempts == 0) throw e;  
    }  
}
```
Because the only thing worse than failure is failing without even trying again. Be stubborn. Retry.

### 8. Thread Sleep with Grace (No More Magic Numbers)
```java
TimeUnit.SECONDS.sleep(2);
```
Two seconds of sleep shouldn’t look like `Thread.sleep(2000)`.

That’s not readable, that’s punishment.

### 9. Logging Without the Pain
```java
private static final Logger log = LoggerFactory.getLogger(MyClass.class);  
log.info("Something happened: {}", value);
```

`System.out.println` is for beginners.

Real devs log like pros.

### 10. Immutable Lists for Sanity
```java
List<String> list = List.of("a", "b", "c");
```

Immutable means safe.

Safe means less rage quitting. It’s math.

# Understanding Function.identity()

The `Function.identity()` method was first introduced in Java 8. Java 8 introduced the java.util.function package, which includes functional interfaces to support functional programming in Java. The `Function` interface, along with the `identity()` method, is part of this package. Java 8, released in March 2014, brought significant enhancements to the language, including lambda expressions and the Stream API, to facilitate functional programming constructs.

In Java, `Function.identity()` is a static method provided by the `Function` interface in the `java.util.function` package. It returns a `Function` that always returns its input argument. In other words, it's a convenient way to create a function that takes an argument and returns the same argument.

The method signature of `identity()` is as follows:

static <T> Function<T, T> identity()

Here, `T` represents the type of the input and output elements.

### Example Usage:

### Example 1: Basic Usage
```java
import java.util.function.Function;  
  
public class IdentityExample {  
  
    public static void main(String[] args) {  
        // Create a Function that returns the input itself  
        Function<String, String> identityFunction = Function.identity();  
  
        // Use the identity function  
        String result = identityFunction.apply("Hello, World!");  
  
        System.out.println(result); // Output: Hello, World!  
    }  
}
```
In this example, `Function.identity()` is used to create a function that takes a `String` and returns the same `String`. When applied to the input "Hello, World!", it returns the same string.

###### Example 2: Using it with Streams
```java
import java.util.Arrays;  
import java.util.List;  
import java.util.stream.Collectors;  
  
public class StreamIdentityExample {  
  
    public static void main(String[] args) {  
        List<String> words = Arrays.asList("apple", "banana", "orange");  
  
        // Use identity() in a stream operation  
        List<String> result = words.stream()  
                .map(Function.identity())  
                .collect(Collectors.toList());  
  
        System.out.println(result); // Output: [apple, banana, orange]  
    }  
}
```

In this example, `Function.identity()` is used with the `map` operation in a stream. It serves as a convenient way to transform each element of the stream into itself, resulting in a list with the same elements.

### When to Use `Function.identity()`:

Transformations: Use it when you need a simple identity transformation, especially in scenarios like stream processing or when creating a default mapping function.

Default Function: When you need to provide a default mapping function to methods that expect a `Function` parameter.

Readability: It can improve code readability by explicitly stating that the transformation is an identity transformation.

Remember that while `Function.identity()` is concise and often convenient, you can achieve the same result by creating your own lambda expression or method reference that returns its input argument. The choice between these options depends on the context and the readability of your code.

While `Function.identity()` is often used for simple identity transformations, it might not be as common in more complex scenarios. However, I can provide examples that demonstrate its usage in the context of more complex transformations or scenarios.

What is an Identify transformation?

An identity transformation is a transformation that leaves the input unchanged. In mathematical terms, given a set of elements, an identity transformation is a function that maps each element to itself. In programming, particularly in functional programming, the concept of an identity transformation is often used to represent a simple, do-nothing transformation.

In Java, the `Function.identity()` method provides a convenient way to express an identity transformation using the `Function` functional interface. It returns a `Function` that, when applied to an argument, returns the same argument. This is useful in scenarios where a function is expected, but you want to perform an operation that doesn't actually transform the input.
```java
import java.util.Arrays;  
import java.util.List;  
import java.util.function.Function;  
import java.util.stream.Collectors;  
  
public class IdentityTransformationExample {  
  
    public static void main(String[] args) {  
        List<String> words = Arrays.asList("apple", "banana", "orange");  
  
        // Use identity transformation in a stream operation  
        List<String> result = words.stream()  
                .map(Function.identity())  
                .collect(Collectors.toList());  
  
        System.out.println(result); // Output: [apple, banana, orange]  
    }  
}
```

In this example, `Function.identity()` is used within a stream to represent an identity transformation. The `map` operation typically requires a function to transform elements, and `Function.identity()` provides a convenient way to say "don't transform, just keep the element as it is."

While this might seem trivial in simple cases, it becomes more useful when you are composing functions or working with APIs that expect functions but where you want to provide a default behavior.

_Use Cases:_

Default Mapping Function:
```java
Function<String, String> mappingFunction = someMappingFunction != null  
        ? someMappingFunction  
        : Function.identity();
```

This can be useful when you want to use a custom mapping function if provided, but fall back to the identity transformation if not.

Stream Processing:
```java
List<String> transformedList = originalList.stream()  
        .map(Function.identity())  
        .collect(Collectors.toList());
```

In stream processing, when you want to keep the elements as they are without any transformation.

Optional Transformation:
```java
Optional.ofNullable(value)  
        .map(Function.identity())  
        .orElse(defaultValue);
```
When using `Optional` and you want to provide a default value if the optional is empty without transforming the present value.

In summary, an identity transformation is a simple operation that leaves the input unchanged, and `Function.identity()` provides a concise and expressive way to represent this operation in Java.

### Example 1: Combining `Function.identity()` with Other Functions
```java
import java.util.Arrays;  
import java.util.List;  
import java.util.function.Function;  
import java.util.stream.Collectors;  
  
public class ComplexTransformationExample {  
  
    public static void main(String[] args) {  
        List<String> words = Arrays.asList("apple", "banana", "orange");  
  
        // Applying complex transformation: Uppercase the first letter of each word  
        List<String> result = words.stream()  
                .map(Function.identity()) // Identity transformation  
                .map(String::toUpperCase) // Uppercase transformation  
                .map(s -> s.substring(0, 1) + s.substring(1).toLowerCase())
  					// Uppercase first letter  
                .collect(Collectors.toList());  
  
        System.out.println(result); // Output: [Apple, Banana, Orange]  
    }  
}
```

In this example, `Function.identity()` is used to perform an identity transformation initially, and then additional transformations are applied using method references and lambda expressions.

### Example 2: Applying Conditional Transformations
```java
import java.util.Arrays;  
import java.util.List;  
import java.util.function.Function;  
import java.util.stream.Collectors;  
  
public class ConditionalTransformationExample {  
  
    public static void main(String[] args) {  
        List<String> words = Arrays.asList("apple", "banana", "orange", "grape");  
  
        // Applying complex transformation: Uppercase the word if it starts with 'a'  
        List<String> result = words.stream()  
                .map(Function.identity()) // Identity transformation  
                .map(s -> s.startsWith("a") ? s.toUpperCase() : s) 
  						// Conditional transformation  
                .collect(Collectors.toList());  
  
        System.out.println(result); // Output: [APPLE, banana, orange, grape]  
    }  
}
```

Here, `Function.identity()` is used to perform the identity transformation initially, and then a conditional transformation is applied based on a predicate.

While these examples might seem contrived for the purpose of demonstrating `Function.identity()`, in real-world scenarios, you might encounter situations where you dynamically compose functions, and `Function.identity()` can be part of such compositions. It is particularly useful when you want to include an identity function in a sequence of transformations for consistency or flexibility.

_Dynamic Function Composition in Real-World Java Scenarios:_

In real-world scenarios, composing functions is a powerful concept, especially in functional programming paradigms. The ability to dynamically compose functions allows you to build complex transformations by combining simpler functions. `Function.identity()` plays a role in these compositions by acting as a neutral element, allowing you to include it in a sequence of transformations for consistency or flexibility. Here are a couple of examples:

###### Example 1: Function Composition with Identity

Consider a scenario where you have a list of words, and you want to apply a series of transformations to each word: first, convert to uppercase, then append a prefix, and finally, reverse the string.
```java
import java.util.Arrays;  
import java.util.List;  
import java.util.function.Function;  
import java.util.stream.Collectors;  
  
public class FunctionCompositionExample {  
  
    public static void main(String[] args) {  
        List<String> words = Arrays.asList("apple", "banana", "orange");  
  
        // Define individual transformation functions  
        Function<String, String> toUpperCase = String::toUpperCase;  
        Function<String, String> addPrefix = s -> "Prefix_" + s;  
        Function<String, String> reverseString = s -> 
  				new StringBuilder(s).reverse().toString();  
  
        // Compose the transformations  
        Function<String, String> composedFunction = toUpperCase  
                .andThen(addPrefix)  
                .andThen(Function.identity()) // Using identity for flexibility  
                .andThen(reverseString);  
  
        // Apply the composed function to each word  
        List<String> result = words.stream()  
                .map(composedFunction)  
                .collect(Collectors.toList());  
  
        System.out.println(result);  
    }  
}
```
In this example, `Function.identity()` is used to include a placeholder in the composition. While it doesn't contribute to the transformation, it allows for flexibility in the sequence of transformations.

Here is another example:
```java
import java.util.Arrays;  
import java.util.List;  
import java.util.function.Function;  
import java.util.stream.Collectors;  
  
public class DynamicFunctionCompositionExample {  
  
    public static void main(String[] args) {  
        List<String> words = Arrays.asList("apple", "banana", "orange");  
  
        // Define individual transformation functions  
        Function<String, String> toUpperCase = String::toUpperCase;  
        Function<String, String> addPrefix = s -> "Prefix_" + s;  
        Function<String, String> reverseString = s -> 
  					new StringBuilder(s).reverse().toString();  
  
        // Some condition to determine which transformations to apply  
        boolean applyUpperCase = true;  
        boolean applyPrefix = false;  
        boolean applyReverse = true;  
  
        // Initialize composedFunction directly to the first transformation function  
        Function<String, String> composedFunction 
  				= applyUpperCase ? toUpperCase : Function.identity();  
  
        if (applyPrefix) {  
            composedFunction = composedFunction.andThen(addPrefix);  
        }  
  
        if (applyReverse) {  
            composedFunction = composedFunction.andThen(reverseString);  
        }  
  
        // Apply the composed function to each word  
        List<String> result = words.stream()  
                .map(composedFunction)  
                .collect(Collectors.toList());  
  
        System.out.println(result);  
    }  
}
```

In the above example, alternatively, you can initialize the composedFunction as below too:
```java
// Compose the transformations conditionally  
Function<String, String> composedFunction = Function.identity();  

if (applyUpperCase) {  
    composedFunction = composedFunction.andThen(toUpperCase);  
}
```
Here is another alternative, where you can skip Function.identity():
```java
// Initialize composedFunction directly to the first transformation function  
Function<String, String> composedFunction = applyUpperCase ? toUpperCase : null;
```

### Example 2: Conditional Composition

Suppose you have a list of numbers, and you want to apply different transformations based on whether the number is even or odd.
```java
import java.util.Arrays;  
import java.util.List;  
import java.util.function.Function;  
import java.util.stream.Collectors;  
  
public class ConditionalCompositionExample {  
  
    public static void main(String[] args) {  
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);  
  
        // Define individual transformation functions  
        Function<Integer, String> evenTransformation = i -> "Even: " + i;  
        Function<Integer, String> oddTransformation = i -> "Odd: " + i;  
  
        // Compose the transformations conditionally using identity  
        Function<Integer, String> composedFunction = n ->  
                (n % 2 == 0 ? evenTransformation : oddTransformation)  
                        .andThen(Function.identity()) // Using identity for flexibility  
                        .apply(n);  
  
        // Apply the composed function to each number  
        List<String> result = numbers.stream()  
                .map(composedFunction)  
                .collect(Collectors.toList());  
  
        System.out.println(result);  
    }  
}
```

Here, `Function.identity()` is used to include a placeholder in the composition, allowing the conditional part of the composition to be easily extended or modified.

In both examples, `Function.identity()` is used to make the composition more flexible and allow for easy modification or extension of the transformation pipeline. While these examples might be contrived, in real-world scenarios, composing functions with identity can simplify code maintenance and make it more adaptable to changes.