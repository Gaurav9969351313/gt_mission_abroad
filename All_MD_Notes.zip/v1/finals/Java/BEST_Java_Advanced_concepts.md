# Scenario-Based SOLID Principles in Java

### 🎯 What are SOLID Principles?

Before diving into scenarios, let’s quickly revisit what SOLID stands for:

-   **S** — Single Responsibility Principle (SRP)
-   **O** — Open/Closed Principle (OCP)
-   **L** — Liskov Substitution Principle (LSP)
-   **I** — Interface Segregation Principle (ISP)
-   **D** — Dependency Inversion Principle (DIP)

### SOLID Principles: Write Clean, Scalable, and Maintainable Code

### 1. Single Responsibility Principle (SRP)

📌 **Scenario**:  
You have a `UserService` class that handles user registration, sending welcome emails, and writing user logs to a file.
```java
public class UserService {  
    public void registerUser(User user) { ... }  
    public void sendEmail(User user) { ... }  
    public void writeLog(User user) { ... }  
}
```
💬 **Interviewer Question**:  
What’s wrong with this design, and how can you improve it?

**Answer**:  
The `UserService` class violates the **Single Responsibility Principle**. It handles **three responsibilities**: business logic, email communication, and logging. According to SRP, each class should have **only one reason to change**.

**Refactor:**
```java
public class UserService {  
    private EmailService emailService;  
    private LoggingService loggingService;  
public void registerUser(User user) {  
        // registration logic  
        emailService.sendEmail(user);  
        loggingService.log(user);  
    }  
}
```
Now each class focuses on a single concern.

### 2. Open/Closed Principle (OCP)

📌 **Scenario**:  
You have a payment processing class that supports multiple payment types.
```java
public class PaymentProcessor {  
    public void processPayment(String type) {  
        if (type.equals("CreditCard")) { ... }  
        else if (type.equals("PayPal")) { ... }  
        else if (type.equals("UPI")) { ... }  
    }  
}
```
💬 **Interviewer Question**:  
How does this violate OCP and how would you redesign it?

**Answer**:  
This class is **open for modification** whenever we introduce a new payment type. This violates the **Open/Closed Principle**, which states that classes should be **open for extension, but closed for modification**.

**Refactor with Strategy Pattern**:
```java
public interface PaymentMethod {  
    void pay();  
}  
public class CreditCardPayment implements PaymentMethod {  
    public void pay() { /* logic */ }  
}  
public class PayPalPayment implements PaymentMethod {  
    public void pay() { /* logic */ }  
}  
public class PaymentProcessor {  
    public void process(PaymentMethod method) {  
        method.pay();  
    }  
}
```

Now, new payment methods can be added **without modifying** existing code.

### 3. Liskov Substitution Principle (LSP)

📌 **Scenario**:  
Consider the following inheritance:
```java
public class Bird {  
    public void fly() {  
        System.out.println("Flying...");  
    }  
}  
  
public class Ostrich extends Bird {  
    @Override  
    public void fly() {  
        throw new UnsupportedOperationException("Ostriches can't fly!");  
    }  
}
```

💬 **Interviewer Question**:  
What’s the issue here with respect to LSP?

**Answer**:  
The **Liskov Substitution Principle** requires that subclasses must be substitutable for their base classes without breaking the behavior. Here, substituting `Bird` with `Ostrich` violates this, because `Ostrich` cannot fly and throws an exception.

**Fix using Composition**:
```java
public interface Bird {  
    void eat();  
}  
  
public interface Flyable {  
    void fly();  
}  
public class Sparrow implements Bird, Flyable {  
    public void eat() { }  
    public void fly() { }  
}  
public class Ostrich implements Bird {  
    public void eat() { }  
}
```
Separate behaviors help avoid invalid assumptions.

### 4. Interface Segregation Principle (ISP)

📌 **Scenario**:  
You have an interface:
```java
public interface Machine {  
    void print();  
    void scan();  
    void fax();  
}
```

But not all classes use all methods:
```java
public class PrinterOnly implements Machine {  
    public void print() { }  
    public void scan() {  
        throw new UnsupportedOperationException();  
    }  
    public void fax() {  
        throw new UnsupportedOperationException();  
    }  
}
```

💬 **Interviewer Question**:  
How does this design violate ISP?

**Answer**:  
**Interface Segregation Principle** says: **don’t force clients to depend on interfaces they don’t use**. Here, `PrinterOnly` is forced to implement `scan()` and `fax()`, which it doesn’t support.

**Refactor**:
```java
public interface Printer {  
    void print();  
}  
  
public interface Scanner {  
    void scan();  
}  
public interface Fax {  
    void fax();  
}  
public class PrinterOnly implements Printer {  
    public void print() { }  
}
```
Now, classes implement only what they need.

### 5. Dependency Inversion Principle (DIP)

📌 **Scenario**:  
You’re building a reporting module:
```java
public class ReportService {  
    private PdfReportGenerator pdfReportGenerator = new PdfReportGenerator();  
  
public void generate() {  
        pdfReportGenerator.generatePdf();  
    }  
}
```

💬 **Interviewer Question**:  
What’s the violation here and how can you apply DIP?

**Answer**:  
This design tightly couples `ReportService` to a concrete class. According to the **Dependency Inversion Principle**, **high-level modules should not depend on low-level modules**. Both should depend on abstractions.

**Refactor**:
```java
public interface ReportGenerator {  
    void generate();  
}  
  
public class PdfReportGenerator implements ReportGenerator {  
    public void generate() { /* generate PDF */ }  
}  
public class ReportService {  
    private ReportGenerator generator;  
    public ReportService(ReportGenerator generator) {  
        this.generator = generator;  
    }  
    public void generateReport() {  
        generator.generate();  
    }  
}
```
Now, `ReportService` depends on an **interface**, not a concrete class.

### Bonus: Combined Scenario

📌 **Scenario**:  
You’re designing a **Notification System** for a large application that can notify users via Email, SMS, or Push Notification.

💬 **Interviewer Question**:  
How would you design this system following **all SOLID principles**?

**Answer**:

1.  **SRP**: Separate classes for each notification channel.
2.  **OCP**: Add new notification types without modifying existing logic.
3.  **LSP**: Any notifier should be safely replaceable.
4.  **ISP**: If a client only needs Email, don’t force it to use SMS/Firebase logic.
5.  **DIP**: Use interfaces and inject dependencies.

**Sample Design**:
```java
public interface Notifier {  
    void notifyUser(String message);  
}  
  
public class EmailNotifier implements Notifier {  
    public void notifyUser(String message) { /* send email */ }  
}  
public class SMSNotifier implements Notifier {  
    public void notifyUser(String message) { /* send SMS */ }  
}  
public class NotificationService {  
    private final Notifier notifier;  
    public NotificationService(Notifier notifier) {  
        this.notifier = notifier;  
    }  
    public void send(String msg) {  
        notifier.notifyUser(msg);  
    }  
}
```
This design fully respects the **SOLID** principles and is highly **extensible**, **testable**, and **maintainable**.


## Introduction: The Power of Lombok — and Its Hidden Gems

### 1. @**StandardException**

**Purpose:** Generates standard exception constructors (e.g., message, cause) for custom exceptions.  
**Why Use It?** Skip writing repetitive exception boilerplate.
```java
@StandardException    
public class PaymentFailedException extends RuntimeException { }    
  
// Usage:    
throw new PaymentFailedException("Insufficient funds");    
throw new PaymentFailedException("Network error", cause);  
```
**Key Benefit:** Simplifies exception creation while adhering to Java’s exception best practices.

### 2. @Delegate

**Purpose:** The delegate annotation calls a field, promoting composition over inheritance.  
**Why Use It?** Reuse functionality without inheritance hierarchies.
```java
public class WorkflowLogger {    
    @Delegate    
    private final List<String> logs = new ArrayList<>();    
}    
  
// Usage:    
WorkflowLogger logger = new WorkflowLogger();    
logger.add("Task started"); // List's add() method    
logger.remove(0);           // List's remove() method  
```
**Key Benefit:** Exposes methods from a composed object without manual delegation.

### 3. @Cleanup

**Purpose:** Automatically closes resources (e.g., streams, files) at the end of a scope.  
**Why Use It?** Replace verbose _try-with-resources_ blocks with a single annotation.
```java
public void readFile() {    
    @Cleanup InputStream input = new FileInputStream("data.txt");    
    // input.close() is called automatically at the end of the scope    
}  
```
**Key Benefit:** Reduces boilerplate for resource management.

### 4. @Tolerate

**Purpose:** Instructs Lombok to ignore a method/constructor that conflicts with generated code.  
**Why Use It?** Override Lombok’s default behavior when custom logic is needed.
```java
@Builder    
public class Task {    
    private String title;    
    private boolean completed;    
  
    @Tolerate    
    public Task(String title) {    
        this.title = title;    
        this.completed = false;    
    }    
}    
  
// Usage:    
Task task = new Task("Debug code"); // Custom constructor  
```
**Key Benefit:** Resolves conflicts between Lombok-generated and custom code.

### 5. @ExtensionMethod

**Purpose:** Adds “extension methods” to existing classes via static imports.  
**Why Use It?** Enrich classes like _String_ or _List_ with custom methods.
```java
public class StringUtils {    
    public static String toTitleCase(String s) {    
        return s.substring(0, 1).toUpperCase() + s.substring(1).toLowerCase();    
    }    
}    
  
@ExtensionMethod(StringUtils.class)    
public class App {    
    void run() {    
        String name = "jOhN dOe".toTitleCase(); // "John Doe"    
    }    
} 
```
**Key Benefit:** Write fluent, domain-specific logic for existing classes.

### Conclusion: Unlock Lombok’s Full Potential

Lombok’s lesser-known annotations offer powerful shortcuts for Java developers:

-   **@StandardException** simplifies exception boilerplate.
-   **@Delegate** embraces composition.
-   **@Cleanup** automates resource management.
-   **@Tolerate** resolves code conflicts.
-   **@ExtensionMethod** adds Kotlin-like extensions.



# Scenario-Based Java Multithreading Interview Questions with a Focus on CompletableFuture 

## Scenario 1: Stock Market Live Data Aggregation

_“A financial application retrieves stock prices from three different APIs and needs to compute the average stock price. If any API fails, the system should return a default value for that source. How would you implement this using_ `_CompletableFuture_`_?"_

### Solution:

-   Use `**CompletableFuture.supplyAsync()**` for non-blocking calls.
-   Handle failures using `**exceptionally()**`.
-   Use `**thenCombine()**` to aggregate results.
```java
import java.util.concurrent.*;  
import java.util.Random;  
public class StockMarketAggregator {  
    public static void main(String[] args) {  
        CompletableFuture<Double> api1 = fetchStockPrice("API-1");  
        CompletableFuture<Double> api2 = fetchStockPrice("API-2");  
        CompletableFuture<Double> api3 = fetchStockPrice("API-3");  
        // Compute the average stock price once all APIs respond  
        CompletableFuture<Double> averagePrice = api1  
                .thenCombine(api2, Double::sum)  
                .thenCombine(api3, (sum, price) -> (sum + price) / 3);  
        System.out.println("📈 Final Stock Price: $" + averagePrice.join());  
    }  
    private static CompletableFuture<Double> fetchStockPrice(String api) {  
        return CompletableFuture.supplyAsync(() -> {  
            simulateDelay(new Random().nextInt(2000) + 500);  
            if (new Random().nextBoolean()) {  // Simulating failure  
                throw new RuntimeException(api + " failed!");  
            }  
            double price = 100 + new Random().nextDouble() * 10;  
            System.out.println(api + " returned $" + price);  
            return price;  
        }).exceptionally(ex -> {  
            System.err.println(ex.getMessage());  
            return 100.0;  // Default fallback price  
        });  
    }  
    private static void simulateDelay(int millis) {  
        try { Thread.sleep(millis); } catch (InterruptedException e) { e.printStackTrace(); }  
    }  
}
```
### Key Takeaways:

✅ **Resilient to API failures** → Uses **fallback values**.  
✅ **Asynchronous calls improve performance** → Aggregates data in **parallel**.  
✅ **Ensures fault tolerance** → `exceptionally()` prevents crashes.

## Scenario 2: E-Commerce Order Processing with Parallel Tasks

In an e-commerce system, when a user places an order, multiple tasks must run concurrently:

1.  Validate the order.
2.  Process the payment.
3.  Update the inventory.
4.  Send a confirmation email.

These tasks should execute asynchronously, and the system should proceed only when all are completed. How would you implement this using `CompletableFuture`?"_

### Solution:

Here, we need **parallel execution** of all tasks and then proceed with the next steps. `CompletableFuture.allOf()` ensures all tasks complete before proceeding further.
```java
import java.util.concurrent.*;  
public class ECommerceOrderProcessing {  
    public static void main(String[] args) {  
        CompletableFuture<Void> orderValidation = CompletableFuture.runAsync(() -> {  
            simulateDelay(1000);  
            System.out.println("✅ Order validated");  
        });  
        CompletableFuture<Void> paymentProcessing = CompletableFuture.runAsync(() -> {  
            simulateDelay(1500);  
            System.out.println("💰 Payment processed");  
        });  
        CompletableFuture<Void> inventoryUpdate = CompletableFuture.runAsync(() -> {  
            simulateDelay(1200);  
            System.out.println("📦 Inventory updated");  
        });  
        CompletableFuture<Void> confirmationEmail = CompletableFuture.runAsync(() -> {  
            simulateDelay(500);  
            System.out.println("📧 Confirmation email sent");  
        });  
        // Wait for all tasks to complete  
        CompletableFuture<Void> allTasks = CompletableFuture.allOf(orderValidation, paymentProcessing, inventoryUpdate, confirmationEmail);  
          
        allTasks.join();  
        System.out.println("🚀 Order successfully processed!");  
    }  
    private static void simulateDelay(int millis) {  
        try { Thread.sleep(millis); } catch (InterruptedException e) { e.printStackTrace(); }  
    }  
}
```
### Key Takeaways:

✅ **All tasks run in parallel** → Reduced response time.  
✅ **Non-blocking approach** → Uses thread pools efficiently.  
✅ **Ensures order consistency** → Proceeds only after all tasks complete.

> **Note** — In real world the above steps run in sequence, validate >> payment >> inventory update >> confirmation . If any of the step in betweek failed there is no point to execute next step. Here is the code to simulate that
```java
import java.util.concurrent.*;  
  
public class ECommerceOrderProcessing {  
    public static void main(String[] args) {  
        ExecutorService executor = Executors.newFixedThreadPool(4);  
  
        CompletableFuture<Void> orderProcessingFlow = CompletableFuture  
            .runAsync(() -> {  
                simulateDelay(1000);  
                System.out.println("✅ Order validated");  
                // throw new RuntimeException("Order validation failed"); // Uncomment to simulate failure  
            }, executor)  
            .thenRunAsync(() -> {  
                simulateDelay(1500);  
                System.out.println("💰 Payment processed");  
                // throw new RuntimeException("Payment failed"); // Uncomment to simulate failure  
            }, executor)  
            .thenRunAsync(() -> {  
                simulateDelay(1200);  
                System.out.println("📦 Inventory updated");  
                // throw new RuntimeException("Inventory update failed"); // Uncomment to simulate failure  
            }, executor)  
            .thenRunAsync(() -> {  
                simulateDelay(500);  
                System.out.println("📧 Confirmation email sent");  
            }, executor);  
  
        try {  
            orderProcessingFlow.join();  
            System.out.println("🚀 Order successfully processed!");  
        } catch (CompletionException e) {  
            System.out.println("🛑 Order processing aborted due to error: " + e.getCause().getMessage());  
        }  
  
        executor.shutdown();  
    }  
  
    private static void simulateDelay(int millis) {  
        try { Thread.sleep(millis); } catch (InterruptedException e) { e.printStackTrace(); }  
    }  
}
```
## Scenario 3: Real-time Fraud Detection in Payment Transactions

_“A banking system must analyze multiple parameters asynchronously (transaction amount, location, past history) and flag suspicious transactions if a fraud score exceeds a threshold. How would you implement this?”_

### Solution:

-   Use **multiple** `**CompletableFuture**`**s** to compute fraud risk factors asynchronously.
-   Combine results using `**thenCombine()**`.
-   Use **threshold logic** to detect fraud.
```java
import java.util.concurrent.*;  
import java.util.Random;  
public class FraudDetectionSystem {  
    public static void main(String[] args) {  
        CompletableFuture<Double> amountRisk = analyzeAmountRisk(5000);  
        CompletableFuture<Double> locationRisk = analyzeLocationRisk("Nigeria");  
        CompletableFuture<Double> historyRisk = analyzeTransactionHistory("User123");  
        CompletableFuture<Double> fraudScore = amountRisk  
                .thenCombine(locationRisk, Double::sum)  
                .thenCombine(historyRisk, Double::sum);  
        fraudScore.thenAccept(score -> {  
            if (score > 7.5) {  
                System.out.println("🚨 Fraud Detected! Score: " + score);  
            } else {  
                System.out.println("✅ Transaction Approved. Score: " + score);  
            }  
        }).join();  
    }  
    private static CompletableFuture<Double> analyzeAmountRisk(double amount) {  
        return CompletableFuture.supplyAsync(() -> amount > 3000 ? 4.0 : 1.0);  
    }  
    private static CompletableFuture<Double> analyzeLocationRisk(String location) {  
        return CompletableFuture.supplyAsync(() -> location.equals("Nigeria") ? 3.0 : 0.5);  
    }  
    private static CompletableFuture<Double> analyzeTransactionHistory(String userId) {  
        return CompletableFuture.supplyAsync(() -> new Random().nextDouble() * 3);  
    }  
}
```
### Key Takeaways:

✅ **Asynchronous risk analysis reduces latency**.  
✅ **Parallel execution improves scalability**.  
✅ **Threshold-based detection ensures robust fraud prevention**.

## Scenario 4: Parallel Data Processing in a Big Data Pipeline

A data pipeline receives raw sensor data from IoT devices and must process it in parallel through multiple stages:

1.  Cleanse the data (remove duplicates, invalid values).
2.  Enrich the data (add metadata, location info).
3.  Aggregate the data (compute averages, detect anomalies).

How would you implement this efficiently using `CompletableFuture`?"_

### Solution:

-   Each stage runs **independently in parallel** using `supplyAsync()`.
-   The final result is computed using `thenCompose()` to ensure **dependent transformations**.
```java
import java.util.*;  
import java.util.concurrent.*;  
public class IoTDataPipeline {  
    public static void main(String[] args) {  
        List<String> rawSensorData = Arrays.asList("Sensor1:45", "Sensor2:50", "Sensor1:45", "Sensor3:60", "InvalidData");  
        CompletableFuture<List<String>> cleanedData = CompletableFuture.supplyAsync(() -> cleanseData(rawSensorData));  
        CompletableFuture<List<String>> enrichedData = cleanedData.thenCompose(data -> CompletableFuture.supplyAsync(() -> enrichData(data)));  
        CompletableFuture<Map<String, Double>> aggregatedData = enrichedData.thenCompose(data -> CompletableFuture.supplyAsync(() -> aggregateData(data)));  
        System.out.println("🚀 Final Processed Data: " + aggregatedData.join());  
    }  
    private static List<String> cleanseData(List<String> raw) {  
        System.out.println("🔍 Cleaning data...");  
        return raw.stream().filter(d -> d.contains(":")).distinct().toList();  
    }  
    private static List<String> enrichData(List<String> data) {  
        System.out.println("📌 Enriching data...");  
        return data.stream().map(d -> d + " (Location: NY)").toList();  
    }  
    private static Map<String, Double> aggregateData(List<String> data) {  
        System.out.println("📊 Aggregating data...");  
        Map<String, List<Integer>> grouped = new HashMap<>();  
        for (String record : data) {  
            String[] parts = record.split(":");  
            grouped.computeIfAbsent(parts[0], k -> new ArrayList<>()).add(Integer.parseInt(parts[1].split(" ")[0]));  
        }  
        Map<String, Double> averages = new HashMap<>();  
        grouped.forEach((sensor, readings) -> {  
            averages.put(sensor, readings.stream().mapToInt(i -> i).average().orElse(0));  
        });  
        return averages;  
    }  
}
```
### Key Takeaways:

✅ **Parallel processing improves throughput** for high-volume IoT data.  
✅ **Non-blocking execution reduces wait time** using `thenCompose()`.  
✅ **Scales well** for streaming data architectures like **Kafka + Spark**.

## Scenario 5: Asynchronous Caching with Auto-Refresh

A high-traffic application uses an in-memory cache for frequently accessed data (e.g., product details). The cache should:

1.  Fetch fresh data from the database only when stale.
2.  Auto-refresh data every 10 minutes asynchronously without blocking requests.

How would you implement this using `CompletableFuture`?"_

### Solution:

-   The first request fetches from DB and caches it.
-   Future requests use the **cached version**.
-   A background task **auto-refreshes** every 10 minutes.
```java
import java.util.concurrent.*;  
public class AsyncCache {  
    private static final ConcurrentHashMap<String, String> cache = new ConcurrentHashMap<>();  
    private static final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);  
    public static CompletableFuture<String> getData(String key) {  
        return CompletableFuture.supplyAsync(() -> {  
            return cache.computeIfAbsent(key, AsyncCache::fetchFromDatabase);  
        });  
    }  
    private static String fetchFromDatabase(String key) {  
        simulateDelay(2000);  
        return "Data for " + key + " (Fetched from DB)";  
    }  
    public static void scheduleAutoRefresh() {  
        scheduler.scheduleAtFixedRate(() -> {  
            System.out.println("🔄 Auto-refreshing cache...");  
            cache.replaceAll((k, v) -> fetchFromDatabase(k));  
        }, 10, 10, TimeUnit.MINUTES);  
    }  
    public static void main(String[] args) {  
        scheduleAutoRefresh();  
        getData("product_123").thenAccept(System.out::println);  
        getData("product_123").thenAccept(System.out::println);  // Uses cache  
    }  
    private static void simulateDelay(int millis) {  
        try { Thread.sleep(millis); } catch (InterruptedException e) { e.printStackTrace(); }  
    }  
}
```
### Key Takeaways:

✅ **Reduces load on DB** by caching frequently used data.  
✅ **Non-blocking auto-refresh mechanism** keeps cache up-to-date.  
✅ **Ensures high availability** in **distributed caching systems**.

## Scenario 6: Distributed Computing with Worker Nodes

_“A large dataset must be processed across multiple worker nodes in a distributed environment. Each node processes a subset of data, and the final results are aggregated centrally. How would you implement this?”_

### Solution:

-   Each worker processes **a partition of data asynchronously**.
-   The main thread collects and **aggregates results** using `CompletableFuture.allOf()`.
```java
import java.util.*;  
import java.util.concurrent.*;  
public class DistributedComputing {  
    private static final ExecutorService workerPool = Executors.newFixedThreadPool(4);  
    public static void main(String[] args) {  
        List<Integer> dataset = Arrays.asList(10, 20, 30, 40, 50, 60);  
          
        List<CompletableFuture<Integer>> futures = new ArrayList<>();  
        for (Integer chunk : dataset) {  
            futures.add(CompletableFuture.supplyAsync(() -> processChunk(chunk), workerPool));  
        }  
        CompletableFuture<Void> allTasks = CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]));  
        CompletableFuture<List<Integer>> aggregatedResults = allTasks.thenApply(v ->  
            futures.stream().map(CompletableFuture::join).toList()  
        );  
        System.out.println("✅ Final Aggregated Result: " + aggregatedResults.join());  
        workerPool.shutdown();  
    }  
    private static Integer processChunk(Integer chunk) {  
        simulateDelay(1000);  
        return chunk * 2;  // Example transformation  
    }  
    private static void simulateDelay(int millis) {  
        try { Thread.sleep(millis); } catch (InterruptedException e) { e.printStackTrace(); }  
    }  
}
```

### Key Takeaways:

✅ **Improves scalability** by distributing workload across nodes.  
✅ **Reduces processing time** by leveraging parallel execution.  
✅ **Ideal for batch processing jobs** in **Hadoop, Spark, or Kubernetes-based ML pipelines**.

# Advanced Java Concurrency: Patterns and Best Practices
Concurrency is a cornerstone of modern software development, enabling applications to perform multiple tasks simultaneously and make efficient use of system resources. Java, as a versatile and powerful programming language, has evolved to include robust concurrency support, allowing developers to create high-performance, scalable applications. This article provides an in-depth look at advanced concurrency patterns and best practices in Java, equipping developers with the knowledge to tackle complex concurrency challenges and optimize their applications.

### 1. Fundamentals of Java Concurrency

### Basic Concurrency Concepts

Concurrency in Java begins with understanding the basic building blocks: threads and the Runnable interface. A thread is a lightweight process that can execute code concurrently with other threads. The Runnable interface provides a way to define a task that can be executed by a thread.
```java
public class BasicRunnable implements Runnable {  
    @Override  
    public void run() {  
        System.out.println("Hello from a thread!");  
    }  
    public static void main(String[] args) {  
        Thread thread = new Thread(new BasicRunnable());  
        thread.start();  
    }  
}
```
In this example, a new thread is created and started, executing the run method of the BasicRunnable class.

### Challenges in Concurrent Programming

Concurrent programming introduces several challenges that developers must address to ensure correctness and performance:

-   Race Conditions: Occur when multiple threads access shared data simultaneously, leading to unpredictable results.
-   Deadlocks: Happen when two or more threads are waiting indefinitely for each other to release resources.
-   Thread Starvation: Arises when threads are perpetually denied access to resources, preventing them from making progress.

Understanding these challenges is crucial for developing reliable concurrent applications.

### 2. Advanced Concurrency Constructs

### Locks and Semaphores

Java provides advanced concurrency constructs like locks and semaphores to manage access to shared resources more precisely than the synchronized keyword.

-   ReentrantLock: Offers more control over locking mechanisms, including the ability to interrupt and time out.
```java
import java.util.concurrent.locks.Lock;  
import java.util.concurrent.locks.ReentrantLock;  
public class LockExample {  
    private final Lock lock = new ReentrantLock();  
    private int counter = 0;  
    public void increment() {  
        lock.lock();  
        try {  
            counter++;  
        } finally {  
            lock.unlock();  
        }  
    }  
}
```
In this example, the ReentrantLock ensures that the increment method can be safely accessed by multiple threads.

-   Semaphore: Used to control access to a fixed number of resources.
```java
import java.util.concurrent.Semaphore;  
public class SemaphoreExample {  
    private final Semaphore semaphore = new Semaphore(3); // Allows 3 permits  
    public void accessResource() {  
        try {  
            semaphore.acquire();  
            // Access the resource  
        } catch (InterruptedException e) {  
            Thread.currentThread().interrupt();  
        } finally {  
            semaphore.release();  
        }  
    }  
}
```
Here, a semaphore is used to manage access to a resource, allowing only three threads to access it concurrently.

Real-life Example: Managing Database Connections

In a web application, a limited number of database connections can be managed using a semaphore, ensuring efficient use of resources without overwhelming the database server.
```java
import java.util.concurrent.Semaphore;  
public class DatabaseConnectionPool {  
    private final Semaphore semaphore;  
    public DatabaseConnectionPool(int maxConnections) {  
        semaphore = new Semaphore(maxConnections);  
    }  
    public void connect() {  
        try {  
            semaphore.acquire();  
            // Simulate database connection usage  
        } catch (InterruptedException e) {  
            Thread.currentThread().interrupt();  
        } finally {  
            semaphore.release();  
        }  
    }  
}
```
### Thread Pools

### Executors Framework

The Executors framework in Java provides a high-level API for managing a pool of threads, making it easier to handle a large number of concurrent tasks efficiently.

-   FixedThreadPool: Creates a thread pool with a fixed number of threads.
```java
import java.util.concurrent.ExecutorService;  
import java.util.concurrent.Executors;  
public class FixedThreadPoolExample {  
    private static final int N_THREADS = 5;  
    public static void main(String[] args) {  
        ExecutorService executor = Executors.newFixedThreadPool(N_THREADS);  
        for (int i = 0; i < 10; i++) {  
            executor.execute(() -> System.out.println("Task executed by " 
                + Thread.currentThread().getName()));  
        }  
        executor.shutdown();  
    }  
}
```
In this example, a fixed thread pool is used to execute ten tasks with five threads.

-   CachedThreadPool: Creates a thread pool that creates new threads as needed but reuses previously constructed threads when they are available.
```java
import java.util.concurrent.ExecutorService;  
import java.util.concurrent.Executors;  
public class CachedThreadPoolExample {  
    public static void main(String[] args) {  
        ExecutorService executor = Executors.newCachedThreadPool();  
        for (int i = 0; i < 10; i++) {  
            executor.execute(() -> System.out.println("Task executed by "
                 + Thread.currentThread().getName()));  
        }  
        executor.shutdown();  
    }  
}
```
In this example, a cached thread pool is used to execute tasks, dynamically adjusting the number of threads based on demand.

-   ScheduledThreadPool: Creates a thread pool that can schedule commands to run after a given delay or to execute periodically.
```java
import java.util.concurrent.Executors;  
import java.util.concurrent.ScheduledExecutorService;  
import java.util.concurrent.TimeUnit;  
  
public class ScheduledThreadPoolExample {  
    public static void main(String[] args) {  
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(2);  
        executor.scheduleAtFixedRate(() -> System.out.println("Task executed by " 
            + Thread.currentThread().getName()), 1, 3, TimeUnit.SECONDS);  
    }  
}
```
In this example, a scheduled thread pool is used to execute a task periodically, starting one second after the initial delay and then every three seconds.

Real-life Example: Web Server Handling Multiple Client Requests

A web server can handle multiple client requests concurrently using a thread pool, ensuring efficient resource utilization and faster response times.
```java
import java.io.IOException;  
import java.net.ServerSocket;  
import java.net.Socket;  
import java.util.concurrent.ExecutorService;  
import java.util.concurrent.Executors;  
  
public class WebServer {  
    private static final int PORT = 8080;  
    private static final int THREAD_POOL_SIZE = 10;  
    public static void main(String[] args) {  
        ExecutorService executor = Executors.newFixedThreadPool(THREAD_POOL_SIZE);  
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {  
            while (true) {  
                Socket clientSocket = serverSocket.accept();  
                executor.execute(new ClientHandler(clientSocket));  
            }  
        } catch (IOException e) {  
            e.printStackTrace();  
        }  
    }  
}  
class ClientHandler implements Runnable {  
    private final Socket clientSocket;  
    public ClientHandler(Socket clientSocket) {  
        this.clientSocket = clientSocket;  
    }  
    @Override  
    public void run() {  
        // Handle client request  
    }  
}
```
In this example, a fixed thread pool is used to manage a web server, handling multiple client connections concurrently.

### 3. High-Level Concurrency Utilities

### java.util.concurrent Package

The java.util.concurrent package provides a rich set of utilities for advanced concurrency control. Some of the most commonly used classes include:

-   CountDownLatch: Allows one or more threads to wait until a set of operations being performed by other threads completes.
```java
import java.util.concurrent.CountDownLatch;  
  
public class CountDownLatchExample {  
    private static final int N_TASKS = 3;  
    public static void main(String[] args) {  
        CountDownLatch latch = new CountDownLatch(N_TASKS);  
        for (int i = 0; i < N_TASKS; i++) {  
            new Thread(new Task(latch)).start();  
        }  
        try {  
            latch.await(); // Main thread waits until all tasks are done  
        } catch (InterruptedException e) {  
            Thread.currentThread().interrupt();  
        }  
        System.out.println("All tasks completed.");  
    }  
}  
class Task implements Runnable {  
    private final CountDownLatch latch;  
    public Task(CountDownLatch latch) {  
        this.latch = latch;  
    }  
    @Override  
    public void run() {  
        System.out.println("Task executed by " 
            + Thread.currentThread().getName());  
        latch.countDown(); // Decrement the count of the latch  
    }  
}
```
In this example, the CountDownLatch ensures that the main thread waits until all tasks have completed before proceeding.

-   CyclicBarrier: Allows a set of threads to all wait for each other to reach a common barrier point.
```java
import java.util.concurrent.BrokenBarrierException;  
import java.util.concurrent.CyclicBarrier;  
  
public class CyclicBarrierExample {  
    private static final int N_TASKS = 3;  
    private static final CyclicBarrier barrier = new CyclicBarrier(N_TASKS, () 
        -> System.out.println("All tasks are done!"));  
    public static void main(String[] args) {  
        for (int i = 0; i < N_TASKS; i++) {  
            new Thread(new Task(barrier)).start();  
        }  
    }  
}  
class Task implements Runnable {  
    private final CyclicBarrier barrier;  
    public Task(CyclicBarrier barrier) {  
        this.barrier = barrier;  
    }  
    @Override  
    public void run() {  
        System.out.println("Task executed by " +
             Thread.currentThread().getName());  
        try {  
            barrier.await(); // Wait for all threads to reach this point  
        } catch (InterruptedException | BrokenBarrierException e) {  
            Thread.currentThread().interrupt();  
        }  
    }  
}
```
In this example, the CyclicBarrier ensures that all tasks wait for each other to reach a common barrier point before proceeding.

-   Phaser: A more flexible synchronization barrier, allowing dynamic registration and deregistration of threads.
```java
import java.util.concurrent.Phaser;  
  
public class PhaserExample {  
    private static final int N_TASKS = 3;  
    public static void main(String[] args) {  
        Phaser phaser = new Phaser(1); // "1" to register the main thread  
        for (int i = 0; i < N_TASKS; i++) {  
            phaser.register();  
            new Thread(new Task(phaser)).start();  
        }  
        phaser.arriveAndAwaitAdvance(); // Main thread waits for all tasks to complete  
        System.out.println("All tasks completed.");  
    }  
}  
class Task implements Runnable {  
    private final Phaser phaser;  
    public Task(Phaser phaser) {  
        this.phaser = phaser;  
    }  
    @Override  
    public void run() {  
        System.out.println("Task executed by " 
            + Thread.currentThread().getName());  
        phaser.arriveAndDeregister(); // Signal arrival and deregister  
    }  
}
```
In this example, the Phaser provides a more flexible way to synchronize multiple threads.

### Concurrent Collections

Java provides thread-safe collections in the java.util.concurrent package to help manage concurrent access to data structures.

-   ConcurrentHashMap: A thread-safe variant of HashMap that allows concurrent access and modifications.
```java
import java.util.concurrent.ConcurrentHashMap;  
  
public class ConcurrentHashMapExample {  
    public static void main(String[] args) {  
        ConcurrentHashMap<String, Integer> map = new ConcurrentHashMap<>();  
        map.put("A", 1);  
        map.put("B", 2);  
        map.forEach((key, value) -> System.out.println(key + ": " + value));  
        map.computeIfPresent("A", (key, value) -> value + 1);  
        System.out.println("Updated value of A: " + map.get("A"));  
    }  
}
```
In this example, a ConcurrentHashMap is used to manage concurrent access to a map of key-value pairs.

-   CopyOnWriteArrayList: A thread-safe variant of ArrayList that provides safe iteration over the list, even while it is being modified.
```java
import java.util.List;  
import java.util.concurrent.CopyOnWriteArrayList;  
  
public class CopyOnWriteArrayListExample {  
    public static void main(String[] args) {  
        List<String> list = new CopyOnWriteArrayList<>();  
        list.add("A");  
        list.add("B");  
        for (String item : list) {  
            System.out.println(item);  
        }  
        list.remove("A");  
        System.out.println("Updated list: " + list);  
    }  
}
```
In this example, a CopyOnWriteArrayList is used to safely iterate over and modify the list.

Real-life Example: Implementing a Concurrent Caching Mechanism

Concurrent collections can be used to implement a thread-safe caching mechanism, ensuring that multiple threads can safely access and update the cache.
```java
import java.util.concurrent.ConcurrentHashMap;  
  
public class Cache<K, V> {  
    private final ConcurrentHashMap<K, V> map = new ConcurrentHashMap<>();  
    public V get(K key) {  
        return map.get(key);  
    }  
    public void put(K key, V value) {  
        map.put(key, value);  
    }  
    public void remove(K key) {  
        map.remove(key);  
    }  
}
```
In this example, a ConcurrentHashMap is used to implement a simple thread-safe cache.

### 4. Fork/Join Framework

The Fork/Join framework in Java is designed for parallel processing, making it easier to take advantage of multi-core processors. It uses a work-stealing algorithm to balance the load among available threads.

### Divide-and-Conquer Strategy

The Fork/Join framework is based on the divide-and-conquer strategy, where tasks are recursively split into smaller subtasks until they are simple enough to solve directly.

-   RecursiveTask: Used for tasks that return a result.
```java
import java.util.concurrent.ForkJoinPool;  
import java.util.concurrent.RecursiveTask;  
  
public class ForkJoinExample {  
    private static class SumTask extends RecursiveTask<Long> {  
        private final long[] array;  
        private final int start;  
        private final int end;  
        private static final int THRESHOLD = 10_000;  
        public SumTask(long[] array, int start, int end) {  
            this.array = array;  
            this.start = start;  
            this.end = end;  
        }  
        @Override  
        protected Long compute() {  
            if (end - start <= THRESHOLD) {  
                long sum = 0;  
                for (int i = start; i < end; i++) {  
                    sum += array[i];  
                }  
                return sum;  
            } else {  
                int mid = (start + end) / 2;  
                SumTask leftTask = new SumTask(array, start, mid);  
                SumTask rightTask = new SumTask(array, mid, end);  
                leftTask.fork();  
                long rightResult = rightTask.compute();  
                long leftResult = leftTask.join();  
                return leftResult + rightResult;  
            }  
        }  
    }  
    public static void main(String[] args) {  
        long[] array = new long[20_000];  
        for (int i = 0; i < array.length; i++) {  
            array[i] = i;  
        }  
        ForkJoinPool pool = new ForkJoinPool();  
        long sum = pool.invoke(new SumTask(array, 0, array.length));  
        System.out.println("Sum: " + sum);  
    }  
}
```
In this example, the SumTask class extends RecursiveTask to perform a parallel sum of an array of numbers.

-   RecursiveAction: Used for tasks that do not return a result.
```java
import java.util.concurrent.ForkJoinPool;  
import java.util.concurrent.RecursiveAction;  
  
public class ForkJoinActionExample {  
    private static class PrintTask extends RecursiveAction {  
        private final int start;  
        private final int end;  
        private static final int THRESHOLD = 10;  
        public PrintTask(int start, int end) {  
            this.start = start;  
            this.end = end;  
        }  
        @Override  
        protected void compute() {  
            if (end - start <= THRESHOLD) {  
                for (int i = start; i < end; i++) {  
                    System.out.println(Thread.currentThread().getName() + ": " + i);  
                }  
            } else {  
                int mid = (start + end) / 2;  
                PrintTask leftTask = new PrintTask(start, mid);  
                PrintTask rightTask = new PrintTask(mid, end);  
                invokeAll(leftTask, rightTask);  
            }  
        }  
    }  
    public static void main(String[] args) {  
        ForkJoinPool pool = new ForkJoinPool();  
        pool.invoke(new PrintTask(0, 100));  
    }  
}
```
In this example, the PrintTask class extends RecursiveAction to print numbers in parallel.

Real-life Example: Parallel Processing of Large Datasets

The Fork/Join framework can be used to parallelize the processing of large datasets, improving performance and efficiency.
```java
import java.util.concurrent.ForkJoinPool;  
import java.util.concurrent.RecursiveTask;  
  
public class ParallelSearch {  
    private static class SearchTask extends RecursiveTask<Integer> {  
        private final int[] array;  
        private final int start;  
        private final int end;  
        private final int target;  
        private static final int THRESHOLD = 10_000;  
        public SearchTask(int[] array, int start, int end, int target) {  
            this.array = array;  
            this.start = start;  
            this.end = end;  
            this.target = target;  
        }  
        @Override  
        protected Integer compute() {  
            if (end - start <= THRESHOLD) {  
                for (int i = start; i < end; i++) {  
                    if (array[i] == target) {  
                        return i;  
                    }  
                }  
                return -1;  
            } else {  
                int mid = (start + end) / 2;  
                SearchTask leftTask = new SearchTask(array, start, mid, target);  
                SearchTask rightTask = new SearchTask(array, mid, end, target);  
                leftTask.fork();  
                int rightResult = rightTask.compute();  
                int leftResult = leftTask.join();  
                return leftResult != -1 ? leftResult : rightResult;  
            }  
        }  
    }  
    public static void main(String[] args) {  
        int[] array = new int[100_000];  
        for (int i = 0; i < array.length; i++) {  
            array[i] = i;  
        }  
        ForkJoinPool pool = new ForkJoinPool();  
        int index = pool.invoke(new SearchTask(array, 0, array.length, 42));  
        System.out.println("Index of target: " + index);  
    }  
}
```

In this example, the SearchTask class extends RecursiveTask to perform a parallel search for a target value in an array.

### 5. CompletableFuture and Reactive Streams

### Asynchronous Programming with CompletableFuture

CompletableFuture provides a way to write non-blocking, asynchronous code in Java. It allows you to define a pipeline of actions to perform when a computation completes.

-   Creating and Combining CompletableFutures
```java
import java.util.concurrent.CompletableFuture;  
import java.util.concurrent.ExecutionException;  
  
public class CompletableFutureExample {  
    public static void main(String[] args) throws ExecutionException, InterruptedException {  
        CompletableFuture<String> future = CompletableFuture.supplyAsync(() -> "Hello")  
            .thenApplyAsync(greeting -> greeting + " World")  
            .thenApplyAsync(message -> message + "!");  
        System.out.println(future.get()); // Prints "Hello World!"  
    }  
}
```
In this example, CompletableFuture is used to create an asynchronous pipeline of actions.

-   Exception Handling in Asynchronous Tasks
```java
import java.util.concurrent.CompletableFuture;  
import java.util.concurrent.ExecutionException;  
  
public class CompletableFutureExceptionHandling {  
    public static void main(String[] args) {  
        CompletableFuture<String> future = CompletableFuture.supplyAsync(() -> {  
            if (true) {  
                throw new RuntimeException("Something went wrong!");  
            }  
            return "Hello";  
        }).exceptionally(ex -> "Recovered from: " + ex.getMessage());  
        try {  
            System.out.println(future.get()); // Prints "Recovered from: Something went wrong!"  
        } catch (InterruptedException | ExecutionException e) {  
            e.printStackTrace();  
        }  
    }  
}
```
In this example, exceptionally is used to handle exceptions in an asynchronous task.

Real-life Example: Non-blocking I/O Operations in a Web Application

CompletableFuture can be used to perform non-blocking I/O operations, improving the responsiveness of web applications.
```java
import java.util.concurrent.CompletableFuture;  
  
public class NonBlockingIOExample {  
    public static void main(String[] args) {  
        CompletableFuture.supplyAsync(() -> performIO())  
            .thenAccept(result -> System.out.println("I/O Result: " + result))  
            .exceptionally(ex -> {  
                System.err.println("Error: " + ex.getMessage());  
                return null;  
            });  
    }  
    private static String performIO() {  
        // Simulate I/O operation  
        return "I/O Operation Completed";  
    }  
}
```
In this example, CompletableFuture is used to perform a non-blocking I/O operation.

### Reactive Streams

Reactive programming is a paradigm that allows you to build systems that react to changes. In Java, you can use libraries like Project Reactor or RxJava to implement reactive streams.

-   Introduction to Reactive Programming

Reactive programming is based on the idea of building asynchronous data streams and reacting to changes in these streams.

-   Using Project Reactor
```java
import reactor.core.publisher.Flux;  
  
public class ReactiveExample {  
    public static void main(String[] args) {  
        Flux.just("Hello", "World")  
            .map(String::toUpperCase)  
            .subscribe(System.out::println);  
    }  
}
```
In this example, Project Reactor is used to create a reactive stream that transforms and prints data.

Real-life Example: Real-time Data Processing in a Stock Trading Application

Reactive streams can be used to process real-time stock market data, allowing applications to react to price changes and execute trades automatically.
```java
import reactor.core.publisher.Flux;  
  
public class StockTradingExample {  
    public static void main(String[] args) {  
        Flux.just(100, 102, 101, 103, 105)  
            .filter(price -> price > 102)  
            .subscribe(price -> System.out.println("Trade executed at price: " + price));  
    }  
}
```

In this example, a reactive stream is used to process stock prices and execute trades based on certain conditions.

### 6. Best Practices in Concurrency

### Ensuring Thread Safety

Ensuring thread safety is crucial for concurrent programming. Here are some best practices:

-   Immutability: Make objects immutable to avoid synchronization issues.
```java
public final class ImmutablePoint {  
    private final int x;  
    private final int y;  
  
public ImmutablePoint(int x, int y) {  
        this.x = x;  
        this.y = y;  
    }  
    public int getX() {  
        return x;  
    }  
    public int getY() {  
        return y;  
    }  
}
```
In this example, the ImmutablePoint class is immutable, making it thread-safe.

-   Atomic Variables and Operations: Use atomic variables and operations to ensure thread safety.
```java
import java.util.concurrent.atomic.AtomicInteger;  
  
public class AtomicExample {  
    private final AtomicInteger counter = new AtomicInteger(0);  
    public void increment() {  
        counter.incrementAndGet();  
    }  
    public int getCounter() {  
        return counter.get();  
    }  
}
```
In this example, AtomicInteger is used to ensure thread-safe increment operations.

### Avoiding Common Pitfalls

-   Deadlock Prevention Strategies: Use strategies like lock ordering, lock timeout, and deadlock detection to prevent deadlocks.
-   Identifying and Resolving Race Conditions: Use synchronization, locks, or atomic variables to prevent race conditions.

### Performance Optimization

-   Profiling and Tuning Concurrent Applications: Use profiling tools to identify bottlenecks and optimize the performance of concurrent applications.
-   Choosing the Right Concurrency Constructs for the Task: Use appropriate concurrency constructs based on the specific requirements of your application.

Concurrency is a powerful tool for building high-performance, scalable applications in Java. By understanding advanced concurrency patterns and best practices, developers can create robust, efficient, and safe concurrent applications. As the field of concurrency continues to evolve, staying up-to-date with the latest trends and techniques is essential for leveraging the full potential of Java’s concurrency capabilities.

# Understanding CyclicBarrier in Java


Java provides several powerful synchronization utilities to manage concurrent tasks, especially in multi-threaded environments. One such tool is the **CyclicBarrier**, which belongs to the `java.util.concurrent` package. It is designed to handle situations where multiple threads must wait for each other at a certain execution point, before continuing further. In this article, we'll explore what CyclicBarrier is, how it works, and when it can be useful in multi-threaded programming.

### What is a CyclicBarrier?

A **CyclicBarrier** is a synchronization tool that allows a set of threads to wait for each other to reach a common barrier point before proceeding. Once all participating threads (parties) have arrived at the barrier, the barrier is broken, and the threads are allowed to continue their execution. A key feature of the CyclicBarrier is that it can be reused after it has been broken, which makes it different from the `CountDownLatch`, where the latch cannot be reset.

The CyclicBarrier is especially useful in situations where you need multiple threads to perform some processing independently but require synchronization at specific points in their execution.

### Key Concepts of CyclicBarrier

To understand CyclicBarrier, let's break down some of its key concepts:

-   **Parties**: The number of threads that must wait at the barrier. The CyclicBarrier is initialized with this number, and once all the threads have reached the barrier, they are released.
-   **Barrier Action**: An optional action that is executed once the last thread reaches the barrier. This action is performed by one of the threads before any of them continue further.
-   **Reusability**: As the name suggests, the barrier is cyclic in nature, meaning it can be reused once it has been broken. This is useful for scenarios where threads need to meet at the barrier multiple times during their execution.
-   **Blocking Behavior**: If a thread reaches the barrier and other threads have not yet arrived, the thread will block (wait) until all the required threads have arrived.

### CyclicBarrier in Action

Let's walk through a basic example to understand how CyclicBarrier works.

package com.ionut.medium.cyclic_barrier;  
```java  
import java.util.concurrent.BrokenBarrierException;  
import java.util.concurrent.CyclicBarrier;  
  
public class CyclicBarrierExample {  
  
    public static void main(String[] args) {  
        int numberOfThreads = 3;  
  
        // Initialize CyclicBarrier with 3 parties (threads)  
        CyclicBarrier barrier = new CyclicBarrier(numberOfThreads, () -> System.out.println("All parties have arrived at the barrier. Barrier broken!"));  
  
        // Create and start 3 threads  
        for (int i = 0; i < numberOfThreads; i++) {  
            new Thread(new Task(barrier)).start();  
        }  
    }  
}  
  
class Task implements Runnable {  
    private final CyclicBarrier barrier;  
  
    public Task(CyclicBarrier barrier) {  
        this.barrier = barrier;  
    }  
  
    @Override  
    public void run() {  
        try {  
            System.out.println(Thread.currentThread().getName() + " is performing its task.");  
            Thread.sleep(1000);  // Simulate some work  
  
            System.out.println(Thread.currentThread().getName() + " has finished its task and is waiting at the barrier.");  
            barrier.await();  // Wait at the barrier  
  
            System.out.println(Thread.currentThread().getName() + " has crossed the barrier.");  
        } catch (InterruptedException | BrokenBarrierException e) {  
            e.printStackTrace();  
        }  
    }  
}
```
###### Explanation of the Example:

-   We initialize the `CyclicBarrier` with three parties (threads) and provide a barrier action that will print a message when all threads reach the barrier.
-   The `Task` class simulates some work (by sleeping for one second) and then calls the `barrier.await()` method, which causes the thread to wait at the barrier.
-   Once all three threads have reached the barrier, the barrier action is executed, and the threads are released to continue their execution.

### Key Methods of CyclicBarrier

1.  `**CyclicBarrier(int parties)**`: This constructor creates a new CyclicBarrier that will activate when the specified number of threads (parties) are waiting upon it.
2.  `**CyclicBarrier(int parties, Runnable barrierAction)**`: This constructor is similar to the previous one, but it allows you to specify a barrier action that will be executed by the last thread that arrives at the barrier.
3.  `**await()**`: This method is called by each thread when it reaches the barrier. It causes the thread to wait until all the other threads arrive. Once all threads have reached the barrier, they are released, and execution continues.
4.  `**await(long timeout, TimeUnit unit)**`: This method is similar to `await()`, but it allows you to specify a timeout. If all threads don't reach the barrier within the specified time, a `TimeoutException` is thrown.
5.  `**getParties()**`: Returns the number of parties (threads) required to trip the barrier.
6.  `**getNumberWaiting()**`: Returns the number of threads currently waiting at the barrier.
7.  `**reset()**`: Resets the barrier to its initial state. If any threads are currently waiting at the barrier, they will receive a `BrokenBarrierException`.

### Practical Use Cases for CyclicBarrier

CyclicBarrier can be used in a variety of situations where multiple threads must synchronize at certain points during their execution. Some common use cases include:

1.  **Simulating Concurrent Events**: CyclicBarrier can be used in simulations where multiple threads must represent concurrent events, but all threads need to reach a specific point before proceeding.
2.  **Multistage Computations**: If a computation is divided into multiple stages, and each stage requires input from several threads, CyclicBarrier can ensure that all threads complete the current stage before moving to the next one.
3.  **Parallel Data Processing**: In scenarios where large datasets are processed in parallel, CyclicBarrier can be used to synchronize the results of parallel threads at each phase of the computation.

### CyclicBarrier vs. CountDownLatch

At first glance, **CyclicBarrier** and **CountDownLatch** may seem similar since both are used for synchronization. However, they have some key differences:

-   **CyclicBarrier** is reusable, meaning that once the barrier is broken, it can be reset and used again. In contrast, **CountDownLatch** is a one-time use mechanism. Once the latch reaches zero, it cannot be reset or reused.
-   **CountDownLatch** allows threads to wait for a set of events (i.e., a countdown), while **CyclicBarrier** is used to wait for a fixed number of threads to reach a common barrier.
-   **CyclicBarrier** can perform an optional action (barrier action) when the last thread reaches the barrier, but **CountDownLatch** does not have this capability.

### Challenges and Pitfalls

While CyclicBarrier is a powerful synchronization tool, there are some challenges and pitfalls to be aware of:

1.  **BrokenBarrierException**: If a thread is interrupted while waiting at the barrier, or if the barrier is reset while threads are waiting, a `BrokenBarrierException` is thrown. This can cause threads to terminate prematurely, leading to unexpected behavior.
2.  **Timeouts**: When using the `await(long timeout, TimeUnit unit)` method, if all threads do not arrive at the barrier within the specified time, a `TimeoutException` is thrown. This requires careful handling to avoid leaving threads in an inconsistent state.
3.  **Deadlock**: If the number of threads waiting at the barrier is less than the required parties due to misconfiguration or thread termination, the program may hang indefinitely as the barrier will never be reached.
4.  **Thread Overhead**: In cases with a large number of threads and barriers, the overhead of managing thread synchronization can become significant. Proper thread management and resource allocation are critical for optimizing performance.

### Conclusion

The **CyclicBarrier** is a highly useful tool for synchronizing multiple threads at specific points in their execution, especially in parallel computing scenarios. It allows for reusable barriers and can perform a barrier action to further coordinate tasks across threads.

By understanding how to use CyclicBarrier effectively, Java developers can solve complex synchronization problems and ensure smooth multi-threaded execution. However, careful attention is needed to handle exceptions and potential pitfalls such as deadlocks and timeouts.

In a world of increasingly parallel and concurrent applications, mastering tools like CyclicBarrier gives developers more control and flexibility over thread management, leading to more efficient and responsive applications.

# Understanding CountDownLatch in Java

### Introduction

In concurrent programming, synchronization between threads is a crucial aspect that can significantly impact the performance and reliability of applications.

Java provides several utilities to help manage synchronization, one of which is `CountDownLatch`. This powerful synchronization aid allows one or more threads to wait until a set of operations being performed in other threads is complete.

In this article, we will delve deep into the workings of `CountDownLatch`, understand when and how to use it, explore its advantages and limitations, and provide practical examples to illustrate its application.

### What is CountDownLatch?

`CountDownLatch` is a part of the `java.util.concurrent` package and was introduced in Java 5. It is used to synchronize one or more threads by allowing them to wait for a certain condition to be met before proceeding. The condition is defined by a count, which represents the number of events or operations that must occur before the waiting threads can continue.

### Key Features of CountDownLatch

-   **Initialization with a Count**: `CountDownLatch` is initialized with a specific count, which represents the number of events to wait for.
-   **Countdown Mechanism**: Each event that occurs decrements the count by one.
-   **Waiting for Completion**: Threads can wait for the count to reach zero, meaning all events have occurred.
-   **One-Time Use**: `CountDownLatch` cannot be reset; it is a one-time use synchronization aid.

### When to Use CountDownLatch?

`CountDownLatch` is particularly useful in scenarios where you need to wait for a set of operations to complete before proceeding. Here are some common use cases:

-   **Starting Multiple Threads at the Same Time**: Ensure multiple threads start running at the same time.
-   **Waiting for Multiple Threads to Complete**: Wait for several threads to finish their tasks before proceeding.
-   **Splitting a Task into Subtasks**: Divide a task into subtasks and wait for all subtasks to complete.
-   **Simulating Complex Scenarios in Testing**: Simulate real-world scenarios in testing environments by coordinating thread execution.

### How to Use CountDownLatch?

Using `CountDownLatch` involves a few key steps:

1.  **Initialize the Latch**: Create an instance of `CountDownLatch` with a specified count.
2.  **Countdown Events**: Decrement the count each time an event occurs using the `countDown()` method.
3.  **Await Completion**: Use the `await()` method to block the current thread until the count reaches zero.

### Example: Basic Usage of CountDownLatch

Let's look at a simple example to illustrate the basic usage of `CountDownLatch`.
```java
import java.util.concurrent.CountDownLatch;  
  
public class CountDownLatchExample {  
  
    public static void main(String[] args) {  
        int threadCount = 3;  
        CountDownLatch latch = new CountDownLatch(threadCount);  
  
        for (int i = 0; i < threadCount; i++) {  
            new Thread(new Worker(latch)).start();  
        }  
  
        try {  
            latch.await();  // Wait for all workers to finish  
            System.out.println("All workers have finished their tasks.");  
        } catch (InterruptedException e) {  
            e.printStackTrace();  
        }  
    }  
}  
  
class Worker implements Runnable {  
    private final CountDownLatch latch;  
  
    Worker(CountDownLatch latch) {  
        this.latch = latch;  
    }  
  
    @Override  
    public void run() {  
        try {  
            System.out.println(Thread.currentThread().getName() + " is working.");  
            Thread.sleep((long) (Math.random() * 1000));  // Simulate work  
            System.out.println(Thread.currentThread().getName() + " has finished.");  
        } catch (InterruptedException e) {  
            e.printStackTrace();  
        } finally {  
            latch.countDown();  // Decrement the count  
        }  
    }  
}
```
In this example, three worker threads are created, each performing some work. The main thread waits for all worker threads to complete their tasks using the `await()` method.

### Advantages of CountDownLatch

-   **Simplifies Thread Coordination**: `CountDownLatch` simplifies the coordination of multiple threads by providing a straightforward mechanism to wait for a set of events to complete.
-   **Improves Performance**: By allowing threads to proceed only when necessary, `CountDownLatch` can help improve the performance and responsiveness of applications.
-   **Enhances Readability and Maintainability**: Code that uses `CountDownLatch` is often more readable and maintainable compared to using low-level synchronization constructs like `wait` and `notify`.

### Disadvantages of CountDownLatch

-   **One-Time Use**: `CountDownLatch` is a one-time use synchronization aid. Once the count reaches zero, it cannot be reset.
-   **Potential for Deadlock**: Incorrect usage can lead to deadlocks if the count is not decremented correctly or if threads are not properly synchronized.
-   **Limited Flexibility**: Compared to other synchronization tools like `CyclicBarrier` or `Semaphore`, `CountDownLatch` offers limited flexibility in terms of reset and reuse.

### Advanced Usage of CountDownLatch

### Waiting with Timeout

In some scenarios, you may want to wait for a specific duration and proceed if the count has not reached zero within that time. `CountDownLatch` provides an overloaded `await` method that accepts a timeout parameter.
```java
import java.util.concurrent.CountDownLatch;  
import java.util.concurrent.TimeUnit;  
  
public class CountDownLatchTimeoutExample {  
  
    public static void main(String[] args) {  
        CountDownLatch latch = new CountDownLatch(2);  
  
        new Thread(new Worker(latch)).start();  
        new Thread(new Worker(latch)).start();  
  
        try {  
            if (latch.await(1, TimeUnit.SECONDS)) {  
                System.out.println("All workers finished within the timeout.");  
            } else {  
                System.out.println("Timeout reached before all workers finished.");  
            }  
        } catch (InterruptedException e) {  
            e.printStackTrace();  
        }  
    }  
}  
  
class Worker implements Runnable {  
    private final CountDownLatch latch;  
  
    Worker(CountDownLatch latch) {  
        this.latch = latch;  
    }  
  
    @Override  
    public void run() {  
        try {  
            System.out.println(Thread.currentThread().getName() + " is working.");  
            Thread.sleep((long) (Math.random() * 2000));  // Simulate work  
            System.out.println(Thread.currentThread().getName() + " has finished.");  
        } catch (InterruptedException e) {  
            e.printStackTrace();  
        } finally {  
            latch.countDown();  // Decrement the count  
        }  
    }  
}
```
In this example, the main thread waits for up to 1 second for the worker threads to finish. If the count does not reach zero within the specified time, the main thread proceeds.

### CountDownLatch in Real-World Scenarios

`CountDownLatch` can be used in various real-world scenarios to synchronize and coordinate threads. Here are a few examples:

###### Example 1: Simulating a System Startup

Consider a scenario where multiple services need to be initialized before the system can start serving requests. `CountDownLatch` can be used to ensure that the system waits for all services to be initialized before proceeding.
```java
import java.util.concurrent.CountDownLatch;  
  
public class SystemStartup {  
  
    private static final int SERVICE_COUNT = 3;  
  
    public static void main(String[] args) {  
        CountDownLatch latch = new CountDownLatch(SERVICE_COUNT);  
  
        new Thread(new Service("Service 1", latch)).start();  
        new Thread(new Service("Service 2", latch)).start();  
        new Thread(new Service("Service 3", latch)).start();  
  
        try {  
            latch.await();  // Wait for all services to be initialized  
            System.out.println("All services are up. System is ready to start.");  
        } catch (InterruptedException e) {  
            e.printStackTrace();  
        }  
    }  
}  
  
class Service implements Runnable {  
    private final String name;  
    private final CountDownLatch latch;  
  
    Service(String name, CountDownLatch latch) {  
        this.name = name;  
        this.latch = latch;  
    }  
  
    @Override  
    public void run() {  
        try {  
            System.out.println(name + " is initializing.");  
            Thread.sleep((long) (Math.random() * 1000));  // Simulate initialization  
            System.out.println(name + " is initialized.");  
        } catch (InterruptedException e) {  
            e.printStackTrace();  
        } finally {  
            latch.countDown();  // Decrement the count  
        }  
    }  
}
```
In this example, the system waits for all three services to be initialized before starting. Each service runs in its own thread and simulates an initialization process.

###### Example 2: Parallel Data Processing

Consider a scenario where a large dataset needs to be processed in parallel by multiple worker threads. `CountDownLatch` can be used to wait for all worker threads to complete their processing before proceeding with the next step.
```java
import java.util.concurrent.CountDownLatch;  
  
public class ParallelDataProcessing {  
  
    private static final int WORKER_COUNT = 4;  
  
    public static void main(String[] args) {  
        CountDownLatch latch = new CountDownLatch(WORKER_COUNT);  
  
        for (int i = 0; i < WORKER_COUNT; i++) {  
            new Thread(new DataWorker(latch, i)).start();  
        }  
  
        try {  
            latch.await();  // Wait for all workers to finish  
            System.out.println("All workers have processed the data. Proceeding with the next step.");  
        } catch (InterruptedException e) {  
            e.printStackTrace();  
        }  
    }  
}  
  
class DataWorker implements Runnable {  
    private final CountDownLatch latch;  
    private final int workerId;  
  
    DataWorker(CountDownLatch latch, int workerId) {  
        this.latch = latch;  
        this.workerId = workerId;  
    }  
  
    @Override  
    public void run() {  
        try {  
            System.out.println("Worker " + workerId + " is processing data.");  
            Thread.sleep((long) (Math.random() * 1000));  // Simulate data processing  
            System.out.println("Worker " + workerId + " has finished processing data.");  
        } catch (InterruptedException e) {  
            e.printStackTrace();  
        } finally {  
            latch.countDown();  // Decrement the count  
        }  
    }  
}
```
In this example, the main thread waits for all worker threads to complete their data processing tasks before proceeding to the next step.

### Challenges and Considerations

While `CountDownLatch` is a powerful synchronization tool, it comes with its own set of challenges and considerations:

-   **Deadlocks**: Improper usage can lead to deadlocks if threads are not correctly coordinated or if the count is not decremented appropriately.
-   **One-Time Use**: Once the count reaches zero, `CountDownLatch` cannot be reused. For scenarios requiring reuse, consider using `CyclicBarrier` or `Semaphore`.
-   **Exception Handling**: Ensure that exceptions are properly handled to avoid leaving the latch in an inconsistent state.
-   **Timeouts**: Use timeouts to prevent indefinite waiting in cases where events may not occur as expected.

### Conclusion

`CountDownLatch` is a versatile and powerful synchronization aid in Java that simplifies the coordination of multiple threads. By providing a straightforward mechanism to wait for a set of events to complete, it enhances the readability, maintainability, and performance of concurrent applications. However, it is essential to use `CountDownLatch` carefully to avoid potential pitfalls such as deadlocks and improper synchronization.

In this comprehensive guide, we explored the key features, advantages, and disadvantages of `CountDownLatch`, provided practical examples, and discussed advanced usage scenarios and challenges. By understanding and applying the concepts covered in this article, developers can effectively leverage `CountDownLatch` to build robust and efficient concurrent applications in Java.


# CompletableFuture in Java.
Hi all, I came back with a very very important article for developers! It’s actually about how to do asynchronous programming with Java. You may have already heard of **Multi threading** with Java. That is the base of the asynchronous behaviors in Java. But I’m not going to explain threads, but I will explain stuff beyond that. Let’s say an advanced version of thread executions with Java. **CompletableFuture** class was introduced in Java 8. Until then Java had only **Future** class which came in Java 5.

Let’s discuss in detail…

## Synchronous Vs Asynchronous Programming

In **Synchronous** programming **one task is executed at a time**. After completion of that task, next task will be executed. So, it’s having **blocking** code.  
But in **Asynchronous** programming **multiple tasks are executed at the same time** simultaneously based on thread availability. Simply it’s **non blocking** code since we are not waiting one task to finish to start the next.

## Futures Vs CompletableFutures

I mentioned that we had Future before CompletableFuture came into picture. **Future** class represents a future result of asynchronous computation. It will have a result in future after completion.

Let’s take a simple code example.
```java
public class FutureExample {  
    public static void main(String[] args) throws ExecutionException, InterruptedException {  
        ExecutorService executorService = Executors.newFixedThreadPool(5);  
        Future<String> f1 = executorService.submit(getCallable("Task 1"));  
        Future<String> f2 = executorService.submit(getCallable("Task 2"));  
        Future<String> f3 = executorService.submit(getCallable("Task 3"));  
        String s1 = f1.get();  
        System.out.println(s1);  
        String s2 = f2.get();  
        System.out.println(s2);  
        String s3 = f3.get();  
        System.out.println(s3);  
        executorService.shutdown();  
    }  
    private static Callable<String> getCallable(String taskName) {  
        return () -> "Task:::" + taskName + 
                " => Thread:::" + Thread.currentThread().getName();  
    }  
}  
  
// output:  
// Task:::Task 1 => Thread:::pool-1-thread-1  
// Task:::Task 2 => Thread:::pool-1-thread-2  
// Task:::Task 3 => Thread:::pool-1-thread-3
```
Here, **ExecutorService** is a way of binding a **thread pool** into our java program. There are bunch of pools defined in Java. I took **newFixedThreadPool** for simplicity. I have setup the pool with 5 threads. We can pass either **Runnable** or **Callable** to **_submit_** method. Since **future.get()** can be used to retrieve data, I used a callable(Callable will return something but Runnable does not). Simply f1, f2, f3 will be executed together. But when we call **future.get()**— it’s a blocking call and it will wait until the result completion of our future. This way we had some sort of async programming till Java 8.

## **Drawbacks had in Future 💥**

-   **We can not complete a future manually** — Let’s say we call an API. Due to an issue we get an error. We need to return a cached response in that case. We can not do this with future.
-   **Multiple futures can not be chained together** — futures can not be chained or combined in a way where one future result is dependent on previous future result.
-   **No exception handling** — there is no proper way to deal with exception situations with futures.
-   **Blocking** — future.get() method will block the thread. So, it’s not completely asynchronous.

Providing answers to these issues, **CompletableFuture** came in Java 8 like a miracle. In summary, `CompletableFuture` provides a more flexible and powerful API for working with asynchronous computations than `[Future](https://javarevisited.blogspot.com/2015/01/how-to-use-future-and-futuretask-in-Java.html)`.

## **CompletableFuture** in Java 8

Let’s start discussing the core stuff. CompletableFuture class is **implementing** both **Future** and **CompletionStage** interfaces.
```java
public class CompletableFuture<T> implements Future<T>, CompletionStage<T> {  
    ...... ...... ......  
}
```
It’s an extension of Future. It has a lot of methods where we can create, run, combine, chain multiple futures together and has a very descriptive way of error handling also.

When we use this class, behind the scene it’s like we are delegating the tasks into several threads. It actually uses the global **ForkJoinPool** => **commonPool** to execute the tasks in parallel. If we want, we can pass our own thread pool also.

Let’s discover _CompletableFuture_ class methods…… 😎

## runAsync

This method takes a **Runnable** as an argument and returns nothing. It’s a **Void** asynchronous method. The processing is done by a separate thread in the `ForkJoinPool.commonPool()`.
```java
public class RunAsyncExample {  
    public static void main(String[] args) {  
        Runnable runnable1 = () -> {  
            System.out.println("Hello from Task 1::" + Thread.currentThread().getName());  
        };  
        CompletableFuture<Void> taskCompletableFuture1 = 
            CompletableFuture.runAsync(runnable);  
        System.out.println("Hello from Main::" + Thread.currentThread().getName());  
        taskCompletableFuture1.join();  
  
        Runnable runnable2 = () -> {  
            System.out.println("Hello from Task 2::" + Thread.currentThread().getName());  
        };  
        ExecutorService executorService = Executors.newCachedThreadPool();  
        CompletableFuture<Void> taskCompletableFuture2 = 
            CompletableFuture.runAsync(runnable2, executorService);  
        taskCompletableFuture2.join();  
        executorService.shutdown();  
    }  
}  
  
// output:  
// Hello from Main::main  
// Hello from Task 1::ForkJoinPool.commonPool-worker-1  
// Hello from Task 2::pool-1-thread-1
```
You can see the printed _thread name_ right? We can see 3 kind of threads! What are they?

-   **main** — Main thread which runs our application
-   **ForkJoinPool.commonPool-worker-1** — First task has been executed with the ForkJoinPool thread which is the default thread for CompletableFuture
-   **pool-1-thread-1** — Second task execution has an additional parameter. That’s a thread pool I have defined. So, second task is _not using the default thread pool_ anymore. It uses the _cached thread pool_ we created.

**Join method:** It is an instance method of the `CompletableFuture` class. It is used to _return the value when the future is complete_ or _throws an unchecked exception if completed exceptionally_. If the task involved in the completion of the `CompletableFuture` raises an exception, then this method throws a `CompletionException` with the underlying exception as its cause.

## supplyAsync

This method takes a **Supplier** as an argument and returns CompletableFuture of expected result data type. The processing is done by a separate thread in the `ForkJoinPool.commonPool()`.

If you need to learn more about Java 8 suppliers, please refer here: [https://salithachathuranga94.medium.com/consumer-and-supplier-in-java-8-ec8cf2aea9cf](/consumer-and-supplier-in-java-8-ec8cf2aea9cf)

Let’s try out a sample code.
```java
public class SupplyAsyncExample {  
    public static void main(String[] args) {  
        Supplier<String> supplier = () -> {  
            System.out.println("Hello from Task 1::" 
                + Thread.currentThread().getName());  
            return "Hello from Task 1::" + Thread.currentThread().getName();  
        };  
        CompletableFuture<String> taskCompletableFuture = 
            CompletableFuture.supplyAsync(supplier);  
        System.out.println("Hello from Main::" + Thread.currentThread().getName());  
        String value = taskCompletableFuture.join();  
        System.out.println("Value 1::" + value);  
  
        Supplier<String> supplier2 = () -> {  
            System.out.println("Hello from Task 2::" + Thread.currentThread().getName());  
            return "Hello from Task 1::" + Thread.currentThread().getName();  
        };  
        ExecutorService executorService = Executors.newCachedThreadPool();  
        CompletableFuture<String> taskCompletableFuture2 = 
            CompletableFuture.supplyAsync(supplier2, executorService);  
        String value2 = taskCompletableFuture2.join();  
        System.out.println("Value 2::" + value2);  
        executorService.shutdown();  
    }  
}  
  
// output:  
// Hello from Main::main  
// Hello from Task 1::ForkJoinPool.commonPool-worker-1  
// Value 1::Hello from Task 1::ForkJoinPool.commonPool-worker-1  
// Hello from Task 2::pool-1-thread-1  
// Value 2::Hello from Task 1::pool-1-thread-1
```
Always the CompletableFuture is running on a new **worker thread.** Main thread will execute independently **without bothering** whether the other asynchronous operations are completed or not. I have used our own thread pool for second task.

There are more things can be done with these futures. They will be explained below.

## Callback Methods 💥

These methods are mainly used to chain set of futures and do whatever we want according to the scenario addressed.

> Examples:
> 
> ThenApplyAsync, ThenAcceptAsync, ThenAcceptAsync, ThenRunAsync, ThenComposeAsync, ThenCombineAsync

🔴 **NOTE:**  
Each of this kind of method **has 3 versions**. For an example,

-   **thenApply(fn)** — runs `fn` on a thread defined by the `CompleteableFuture` on which it is called, so you generally cannot know where this will be executed. It might immediately execute if the result is already available.
-   **thenApplyAsync(fn)** — runs `fn` on a environment-defined executor regardless of circumstances. For `CompletableFuture` this will generally be `ForkJoinPool.commonPool()`.
-   **thenApplyAsync(fn,exec)** — runs `fn` on given `executor` instead of ForkJoinPool executor.

The main **difference** in these 3 versions will be how they gain thread control and execute — on which thread it will be executed. But remember! There is nothing in `thenApplyAsync` that is more asynchronous than `thenApply` from the contract of these methods. Both does the same job.

I will show it on next section 😎.

## thenApplyAsync

This method takes a **Function** as an argument and returns CompletableFuture of transformed data. As an example, if you want to modify a string returned from a previous future and return, you can use this method. The processing is done by a separate thread in the `ForkJoinPool.commonPool()`. Let’s understand with an example.
```java
public class ThenApplyExample {  
    public static void main(String[] args) {  
        CompletableFuture<String> taskCompletableFuture = 
            CompletableFuture.supplyAsync(() -> {  
            System.out.println("Hello from Task 1::supplyAsync::" 
                    + Thread.currentThread().getName());  
            return "Hey";  
        });  
        System.out.println("Hello from Main::" + Thread.currentThread().getName());  
        CompletableFuture<String> stringCompletableFuture = 
            taskCompletableFuture.thenApplyAsync(data -> {  
            System.out.println("Hello from Task 1::thenApplyAsync::" 
                    + Thread.currentThread().getName());  
            return data + " Developers!";  
        });  
        String result = stringCompletableFuture.join();  
        System.out.println(result);  
    }  
}  

// output:  
// Hello from Main::main  
// Hello from Task 1::supplyAsync::ForkJoinPool.commonPool-worker-1  
// Hello from Task 1::thenApplyAsync::ForkJoinPool.commonPool-worker-1  
// Hey Developers!
```
I have concatenated two strings using two futures. The first string was _transformed_ into another. You can see right?

There’s one important point there. According to the system logs, it shows that **both futures have been executed using the same thread**.

> What happens if we use **ThenApply** instead of **ThenApplyAsync**?

Just change the method name in the above code and see the logs.
```java
// Hello from Main::main  
// Hello from Task 1::supplyAsync::ForkJoinPool.commonPool-worker-1  
// Hello from Task 1::thenApplyAsync::main  
// Hey Developers!
```
It seems same right? Noooo!!! Look at the 3rd log line! Thread name has been changed to **main** instead of **ForkJoinPool** thread. 😮

So, **async method** was able to gain control, reuse and execute the future on the same thread where previous call was executed. But the other method could not access the same thread. **But** again, this will depends on how much time taken to execute futures also and how JVM is scheduling the threads on availability. Result of **non async** method can be varied based on that.

**All callback methods** will have the same behavior for _async_ and _non async_ methods. So, I will show it only here. Otherwise article will be lengthy. 😉

## thenAcceptAsync

This method takes a **Consumer** as an argument and returns nothing. It’s also a **Void** asynchronous method. The processing is done by a separate thread in the `ForkJoinPool.commonPool()`. Let’s understand with an example.
```java
public class ThenAcceptExample {  
    public static void main(String[] args) {  
        CompletableFuture<String> taskCompletableFuture =
         CompletableFuture.supplyAsync(() -> {  
            System.out.println("Hello from Task 1::supplyAsync::" + Thread.currentThread().getName());  
            return "Hey";  
        });  
        System.out.println("Hello from Main::" + Thread.currentThread().getName());  
        Consumer<String> consumer = (data) -> 
            System.out.println(data + " Developers! Hello from Task 1::thenAcceptAsync::" + 
                Thread.currentThread().getName());  
        taskCompletableFuture.thenAcceptAsync(consumer).join();  
    }  
}  
  
// output:  
// Hello from Main::main  
// Hello from Task 1::supplyAsync::ForkJoinPool.commonPool-worker-1  
// Hey Developers! Hello from Task 1::thenAcceptAsync::ForkJoinPool.commonPool-worker-1
```
I have printed the data came from previous future with some more data, in the example. Since we are using Async method, we have the executor thread to execute the futures.

**PS:** Usually a **Consumer** takes something and do some operation without returning anything. If you need to learn more about Java 8 consumers, please refer here: [https://salithachathuranga94.medium.com/consumer-and-supplier-in-java-8-ec8cf2aea9cf](/consumer-and-supplier-in-java-8-ec8cf2aea9cf)

## thenRunAsync

This method takes a **Runnable** as an argument and returns nothing. It’s also a **Void** asynchronous method. The processing is done by a separate thread in the `ForkJoinPool.commonPool()`. Let’s understand with an example.
```java
public class ThenRunExample {  
    public static void main(String[] args) {  
        CompletableFuture<String> taskCompletableFuture = CompletableFuture.supplyAsync(() -> {  
            System.out.println("Hello from Task 1::supplyAsync::" + 
                Thread.currentThread().getName());  
            return "Hey";  
        });  
        System.out.println("Hello from Main::" + Thread.currentThread().getName());  
        Runnable runnable = () -> System.out.println("Finishing Task 1::thenRunAsync::" + 
            Thread.currentThread().getName());  
        taskCompletableFuture.thenRunAsync(runnable).join();  
    }  
}  
  
// output:  
// Hello from Task 1::supplyAsync::ForkJoinPool.commonPool-worker-1  
// Hello from Main::main  
// Finishing Task 1::thenRunAsync::ForkJoinPool.commonPool-worker-1
```
We can use this method to run any void method or print statement after futures has been completed.

## thenComposeAsync

This method takes a **Function** as an argument and returns CompletableFuture of the expected result. It is used to chain two **dependent** futures sequentially. Let’s understand with an example.

_Scenario:_

We get customer information from an API and using that info we are calling payments API to get relevant payment details. Two calls are inter dependent.
```java
public class ThenComposeExample {  
    private static void sleep(int seconds) {  
        try {  
            TimeUnit.SECONDS.sleep(seconds);  
        } catch (InterruptedException e) {  
            throw new RuntimeException(e);  
        }  
    }  
    private static CompletableFuture<Map<String, String>> getUserDetails() {  
        return CompletableFuture.supplyAsync(() -> {  
            sleep(5);  
            System.out.println("getUserDetails:::" + Thread.currentThread().getName());  
            return getUser();  
        });  
    }  
  
    private static Map<String, String> getUser() {  
        Map<String, String> user = new ConcurrentHashMap<>();  
        user.put("userId", "1234");  
        user.put("userName", "salitha");  
        user.put("phoneNo", "0777123456");  
        return user;  
    }  
  
    private static CompletableFuture<List<String>> getPayments(String userName) {  
        return CompletableFuture.supplyAsync(() -> {  
            sleep(7);  
            System.out.println("getPayments:::" + Thread.currentThread().getName());  
            return Arrays.asList(  
                "USER: " + userName + " => $100",  
                "USER: " + userName + " => $65"  
            );  
        });  
    }  
  
    public static void main(String[] args) {  
        long startTime = System.currentTimeMillis();  
        CompletableFuture<List<String>> paymentsFuture = getUserDetails()  
                .thenComposeAsync(userData -> {  
                    return getPayments(userData.get("userName"));  
                });  
        System.out.println("Hello from Main::" + Thread.currentThread().getName());  
        sleep(4);  
        List<String> payments = paymentsFuture.join();  
        System.out.println(payments);  
        long endTime = System.currentTimeMillis();  
        System.out.println("Time taken::" + (endTime - startTime) / 1000);  
    }  
}  
// output:  
// getUserDetails:::ForkJoinPool.commonPool-worker-1  
// Hello from Main::main  
// getPayments:::ForkJoinPool.commonPool-worker-2  
// [USER: salitha => $100, USER: salitha => $65]  
// Time taken::12
```
If you see the logs, we have run the two tasks `getUserDetails` and `getPayments` methods on separate threads. Here, _worker-1_ and _worker-2_ are the ForkJoinPool threads allocated. Even though we have use sleep for 5 + 7 + 4 = 16 seconds, it has been executed within _12 seconds_ resulting asynchronous behavior.

## thenCombineAsync

This method takes a **BiFunction** as an argument and returns a CompletableFuture of the expected result. It is used to combine two **independent** futures parallel and combine some result. Let’s understand with an example.

_Scenario:_

We need to get a user email and weather report parallel and send an email to that user.
```java
public class ThenCombineExample {  
    private static void sleep(int seconds) {  
        try {  
            TimeUnit.SECONDS.sleep(seconds);  
        } catch (InterruptedException e) {  
            throw new RuntimeException(e);  
        }  
    }  
    private static CompletableFuture<String> getWeather() {  
        return CompletableFuture.supplyAsync(() -> {  
            sleep(5);  
            System.out.println("getUserDetails:::" + Thread.currentThread().getName());  
            return "Sunny, Temperature: 28C";  
        });  
    }  
  
    private static CompletableFuture<String> getUserEmail() {  
        return CompletableFuture.supplyAsync(() -> {  
            sleep(5);  
            System.out.println("getUserEmail:::" + Thread.currentThread().getName());  
            return "john@gmail.com";  
        });  
    }  
  
    public static void main(String[] args) {  
        long startTime = System.currentTimeMillis();  
        CompletableFuture<String> weatherEmailFuture = getUserEmail()  
                .thenCombineAsync(getWeather(), (email, weather) -> {  
                    System.out.println("Sending email to:::" + email + " Weather report => " + weather);  
                    System.out.println("Sending email:::" + Thread.currentThread().getName());  
                    return email + " => " + weather;  
                });  
        System.out.println("Hello from Main::" + Thread.currentThread().getName());  
        sleep(4);  
        String email = weatherEmailFuture.join();  
        System.out.println(email);  
        long endTime = System.currentTimeMillis();  
        System.out.println("Time taken::" + (endTime - startTime) / 1000);  
    }  
}  
  
// Hello from Main::main  
// getUserEmail:::ForkJoinPool.commonPool-worker-1  
// getUserDetails:::ForkJoinPool.commonPool-worker-2  
// Sending email to:::john@gmail.com Weather report => Sunny, Temperature: 28C  
// Sending email:::ForkJoinPool.commonPool-worker-1  
// john@gmail.com => Sunny, Temperature: 28C  
// Time taken::5
```
Following the same pattern, `getUserEmail` and `getWeather` methods have been executed on two separate threads. And it has reused the thread — _worker-1_ which was released. Even though we have used sleep for 5 + 5 + 4 = 14 seconds, it has been executed within _5 seconds_ with a great asynchronous behavior.

## Aggregation Methods 💥

Please mind this word — _aggregation_ is used by me just to differentiate methods. It’s not a standard classification! 😅

So far you know, we have several methods to deal with **two futures**, right?But how to deal with **_more than two futures_**? What are the methods available for this?

> allOf and anyOf methods…

## allOf

When you have multiple futures to deal and perform some action **after all those futures are completed** **only**, this is the method to use. It returns a new `CompletableFuture` object when all of the specified `CompletableFutures` are complete. So, this method accepts a list of completablefutures. We can define and run them parallel and provide the futures into _allOf_ method. If any of the specified `CompletableFutures` is completed with an exception, the resulting `CompletableFuture` does as well, with a `CompletionException` as the cause. Let’s understand with an example.
```java
public class AllOfExample {  
    private static void sleep(int seconds) {  
        try {  
            TimeUnit.SECONDS.sleep(seconds);  
        } catch (InterruptedException e) {  
            throw new RuntimeException(e);  
        }  
    }  
  
    private static CompletableFuture<String> futureOne() {  
        return CompletableFuture.supplyAsync(() -> {  
            System.out.println("futureOne::" + Thread.currentThread().getName());  
            sleep(4);  
            return "CF1";  
        });  
    }  
  
    private static CompletableFuture<String> futureTwo() {  
        return CompletableFuture.supplyAsync(() -> {  
            System.out.println("futureTwo::" + Thread.currentThread().getName());  
            sleep(3);  
            return "CF2";  
        });  
    }  
  
    private static CompletableFuture<String> futureThree() {  
        return CompletableFuture.supplyAsync(() -> {  
            System.out.println("futureThree::" + Thread.currentThread().getName());  
            sleep(2);  
            return "CF3";  
        });  
    }  
  
    public static void main(String[] args) {  
        long startTime = System.currentTimeMillis();  
        List<CompletableFuture<String>> completableFutures = Arrays.asList(futureOne(), futureTwo(), futureThree());  
        CompletableFuture<Void> future = CompletableFuture.allOf(completableFutures.toArray(new CompletableFuture[0]));  
        System.out.println("Hello from Main::" + Thread.currentThread().getName());  
        sleep(6);  
        CompletableFuture<List<String>> allFutureResults = future  
                .thenApply(t -> completableFutures.stream().map(CompletableFuture::join)  
                        .collect(Collectors.toList()));  
        System.out.println("Result: " + allFutureResults.join());  
        long endTime = System.currentTimeMillis();  
        System.out.println("Time taken::" + (endTime - startTime) / 1000);  
    }  
}    
  
// output:  
// Hello from Main::main  
// futureTwo::ForkJoinPool.commonPool-worker-2  
// futureOne::ForkJoinPool.commonPool-worker-1  
// futureThree::ForkJoinPool.commonPool-worker-3  
// Result: [CF1, CF2, CF3]  
// Time taken::6
```
The futures I have defined has been executed on 3 separate worker threads as per the logs. And if you execute the code, you will see they are executed parallel and not one after the other. Even though we have used sleep for 4 + 3 + 2 + 6 = 15 seconds, it has been executed within _6 seconds_. That’s how asynchronous code behaves.

## anyOf

When you have several asynchronous tasks and you want to **return a result as soon as 1 future** is completed, this is the method you would choose. The `anyOf()` method gets tricky when a list of completableFutures return multiple types of outcomes. Due to this, the user is not able to tell which future got completed first. Let’s understand with an example.
```java
public class AnyOfExample {  
    private static void sleep(int seconds) {  
        try {  
            TimeUnit.SECONDS.sleep(seconds);  
        } catch (InterruptedException e) {  
            throw new RuntimeException(e);  
        }  
    }  
  
    private static CompletableFuture<String> futureOne() {  
        return CompletableFuture.supplyAsync(() -> {  
            System.out.println("futureOne::" + Thread.currentThread().getName());  
            sleep(4);  
            return "CF1";  
        });  
    }  
  
    private static CompletableFuture<String> futureTwo() {  
        return CompletableFuture.supplyAsync(() -> {  
            System.out.println("futureTwo::" + Thread.currentThread().getName());  
            sleep(3);  
            return "CF2";  
        });  
    }  
  
    private static CompletableFuture<String> futureThree() {  
        return CompletableFuture.supplyAsync(() -> {  
            System.out.println("futureThree::" + Thread.currentThread().getName());  
            sleep(2);  
            return "CF3";  
        });  
    }  
  
    public static void main(String[] args) {  
        long startTime = System.currentTimeMillis();  
        List<CompletableFuture<String>> completableFutures = Arrays.asList(futureOne(), futureTwo(), futureThree());  
        CompletableFuture<Object> future = CompletableFuture.anyOf(completableFutures.toArray(new CompletableFuture[0]));  
        System.out.println("Hello from Main::" + Thread.currentThread().getName());  
        System.out.println(future.join());;  
        long endTime = System.currentTimeMillis();  
        System.out.println("Time taken::" + (endTime - startTime) / 1000);  
    }  
}  
  
// output:  
// futureTwo::ForkJoinPool.commonPool-worker-2  
// futureOne::ForkJoinPool.commonPool-worker-1  
// Hello from Main::main  
// futureThree::ForkJoinPool.commonPool-worker-3  
// CF3  
// Time taken::2
```

Let’s understand the logs first. As always, futures are executed on separate threads. But what is the result giving by future.join()? It is “CF3”. How it has happened? If you see the 3 completablefuture methods, **futureThree** method has the _less time of execution_ since I have slept it for _2 seconds_. As soon as it is completed, we have the result! That’s why we got “CF3”.

## **Handling Exceptions 💥**

There are 3 ways to handle exceptions while executing completable futures. Let’s look into them.

###### 1️⃣ handle

Takes a **BiFunction — result and exception** which is executed when the stage completes either successfully or exceptionally. It does not matter whether program is executed properly or not. I will quickly show how it works using an erroneous scenario.
```java
public class HandleExample {  
    public static void main(String[] args) {  
        CompletableFuture<Integer> future = CompletableFuture.supplyAsync(() -> {  
            int x = 10;  
            return x / 0;  
        }).handle((result, error) -> {  
            if (error != null) {  
                System.out.println("Error occurred!: " + error.getMessage());  
                return 0;  
            }  
            return result;  
        });  
        System.out.println(future.join());;  
    }  
}  
  
// output:  
// Error occurred!: java.lang.ArithmeticException: / by zero  
// 0
```
This future will definitely throw an Exception: Arithmetic Exception since I’m trying to divide by zero. So, handle method will catch that exception in the BiFunction and we can log the error message. If error is NOT NULL, we are returning _zero,_ Otherwise _result_ from our future. Since we have result and error at the same time, we have to perform a NULL check for one item. If I change the statement by replacing with this => _return x / 2_, then you will see the result as 5.

We can modify this example by chaining a callback method.
```java
public class HandleExample {  
    public static void main(String[] args) {  
        CompletableFuture<Integer> future = CompletableFuture.supplyAsync(() -> {  
            int x = 10;  
            return x / 2;  
        }).handle((result, error) -> {  
            if (error != null) {  
                System.out.println("Error occurred!: " + error.getMessage());  
                return 5;  
            }  
            return result;  
        }).thenApplyAsync(x -> x + 20);  
        System.out.println(future.join());  
    }  
}  
  
// output:  
// Error occurred!: java.lang.ArithmeticException: / by zero  
// 25
```
Output is 25 since return 5 when there’s an exception. So, _thenApplyAsync_ will take the result and add 20 and return.

This is one way that we can handle exceptions occurs while futures are executed.

###### 2️⃣ **exceptionally**

Takes a **Function — exception** which is executed when the stage completes exceptionally. We will only get the error and not the result as before. I will use the same scenario above to demonstrate this method.
```java
public class ExceptionallyExample {  
    public static void main(String[] args) {  
        CompletableFuture<Integer> future = CompletableFuture.supplyAsync(() -> {  
            int x = 10;  
            return x / 0;  
        }).exceptionally(error -> {  
            System.out.println("Error occurred!: " + error.getMessage());  
            return 0;  
        });  
        System.out.println(future.join());  
    }  
}  
  
// output:  
// Error occurred!: java.lang.ArithmeticException: / by zero  
// 0
```
Here, we only have the access to the exception. It does not catch the result. Output will be same as above. Both methods are catching exceptions, but in different ways.

We can modify this example also by chaining a callback method.
```java
public class ExceptionallyExample {  
    public static void main(String[] args) {  
        CompletableFuture.supplyAsync(() -> {  
            int x = 10;  
            return x / 0;  
        }).exceptionally(error -> {  
            System.out.println("Error occurred!: " + error.getMessage());  
            return 0;  
        }).thenAcceptAsync(x -> {  
            System.out.println(x + 10);  
        });  
    }  
}  
  
// output:  
// Error occurred!: java.lang.ArithmeticException: / by zero  
// 10
```
Output became 10 since return _zero_ when there’s an exception. So, _thenAcceptAsync_ will take the result and add 10 to it and print.

###### 3️⃣ whenComplete

This also takes a **BiFunction — result and exception** which is executed when the stage completes either successfully or exceptionally.
```java
public class WhenCompleteExample {  
    public static void main(String[] args) {  
        CompletableFuture.supplyAsync(() -> {  
            int x = 10;  
            return x / 2;  
        }).whenComplete((result, error) -> {  
            if (error != null) {  
                System.out.println("Error occurred!: " + error.getMessage());  
            } else {  
                System.out.println(result);  
            }  
        });  
    }  
}  
  
// output:  
// Error occurred!: java.lang.ArithmeticException: / by zero
```
If we chain a callback method after this, it won’t behave like **exceptionally** and **handle** methods. We **cannot return a result** a value inside this **whenComplete** method. That’s the reason.

✅ All done! Exceptions are handled 😎.

We have just finished the basic but essential guide on **CompletableFuture** in Java😃. This is too lengthy since I wanted to cover as much as I can. Actually it took 2️⃣ days to write this with examples. 😃

Asynchronous programming is very important and useful while we write real world applications. For an example, any database call will take some time to execute. But if we need to execute an API call without depending on the previous DB call? Then we have to delegate tasks into threads. Without going for naïve approach using thread pools and executors, we can use **CompletableFutures**! Otherwise the same thread will be blocked. At the end, user will experience a latency.


# Java Scenario-Based Interview Question

 Performance Considerations Based on Storage Choice

 Using an `ArrayList` (Not Recommended for Large User Lists)

-   **Complexity**: `O(n)` (linear search)
-   **Performance**: Slow for **>10,000 users**
-   **Impact**: For **high QPS (queries per second)** applications, lookups become expensive.

🚫 **Not suitable for heavily used applications with large user bases.**

 **Using a** `**HashSet**` **(Best for Java In-Memory Storage)**

-   **Complexity**: `O(1)` (constant-time lookup)
-   **Performance**: Handles **millions of users efficiently**.
-   **Memory Overhead**: Slightly more than a list due to hashing.

**Implementation:**
```java
Set<String> abTestUsers = ConcurrentHashMap.newKeySet(); // Thread-safe set

public boolean isFeatureEnabled(String userId) {  
    return abTestUsers.contains(userId);  
}
```

✅ **Can handle up to 1 million+ users efficiently** in-memory.  
✅ **Use** `**ConcurrentHashMap.newKeySet()**` **for thread safety in high-concurrency environments.**

🚀 **Recommendation**: Use **HashSet** for up to **1M users** if memory allows.

 Using Redis (Best for Large-Scale A/B Testing)

-   **Complexity**: `O(1)` using Redis `SISMEMBER`
-   **Performance**: **<1 ms lookup time**, scales to **millions of users**.
-   **Use Case**: If your **application handles high traffic**, Redis is the best solution.

 Implementation:

1.  **Add users to Redis**:
```java
jedis.sadd("ab_test_users", "user123", "user456", "user789");
```
1.  **Check if user is in A/B test**:
```java
public boolean isFeatureEnabled(String userId) {   
    return jedis.sismember("ab_test_users", userId);   
}
```

✅ **Scales to 10M+ users** without impacting performance.  
✅ **Works well in a distributed system.**

🚀 **Recommendation**: Use **Redis** for anything above **1 million users**.

 Using Bloom Filters (Best for Memory-Efficient Large-Scale A/B Testing)

-   **Complexity**: `O(1)` with slight false positives.
-   **Memory Usage**: **Much lower than HashSet**.
-   **Use Case**: If you need to check **billions of users** with minimal memory.

 Implementation using Google Guava:
```java
import com.google.common.hash.BloomFilter;  
import com.google.common.hash.Funnels;

BloomFilter<String> bloomFilter = BloomFilter.create(Funnels.unencodedCharsFunnel(), 10_000_000);public boolean isFeatureEnabled(String userId) {  
    return bloomFilter.mightContain(userId); // Low false-positive rate  
}
```

✅ **Memory-efficient for 10M+ users.**  
✅ **Better than Redis if false positives are acceptable.**

🚀 **Recommendation**: Use **Bloom Filters** if your A/B test size is **>10M users**.

 Final Recommendation Based on Number of Users

![](https://miro.medium.com/v2/resize:fit:875/1*afsDue4roQTn_dztV_Amcw.png)

 Final Answer

-   **For up to 1M users**, store in-memory using `HashSet` or `ConcurrentHashMap.newKeySet()`.
-   **For 1M+ users**, use **Redis** for low-latency, scalable lookups.
-   **For 10M+ users**, use a **Bloom Filter** to optimize memory usage.

🚀 **Best Choice for Large-Scale A/B Testing:** **Redis or Bloom Filter**

# This One Line of Java Code Can Prevent NullPointerExceptions Forever

Production systems crash at 3 AM because a single unchecked `null` reference brings down entire application servers.

Your customer-facing APIs return 500 errors instead of graceful responses, directly impacting revenue and user experience.

Development teams spend a lot of their debugging time hunting down NPE root causes according to recent IDE telemetry data, while QA cycles extend by weeks as edge cases surface in testing phases.

### The Simplicity of a Single Line: Embracing Optional

[Java 8’s Optional class](https://codippa.com/optional-in-java-8-with-example/) fundamentally changes how you handle potential null values by wrapping them in a container that forces explicit null-checking.

By wrapping potentially null values in `Optional`, you shift from defensive null checks to declarative, chainable operations.

### Implementing Optional.ofNullable(value).orElse(defaultValue)

This single line replaces dozens of traditional null-checking patterns with a clean, declarative approach.

The `ofNullable()` method safely wraps any potentially null value, while `orElse()` provides your fallback strategy in one fluid operation.

Instead of writing multiple if-statements and risking forgotten edge cases, you explicitly define what happens when the value is absent, making your code both safer and more maintainable.

This line eliminates branching logic by handling nullability in a single expression.

If `value` is null, it immediately returns `defaultValue` without throwing an exception.

The pattern works because `Optional.ofNullable()` internally checks for `null`, while `orElse()` provides an escape hatch.

Unlike traditional if-else blocks, this approach remains readable even when nested with other `Optional` operations like `.map()` or `.filter()`.

The beauty of this pattern lies in its versatility across different scenarios. When retrieving user preferences, you can write
```java
Optional.ofNullable(userSettings.getTheme()).orElse("default")
```
Instead of checking if `userSettings` is null, then if `getTheme()` returns null, then assigning a default value.

**Database queries** become:
```java
Optional.ofNullable(repository.findById(userId)).orElse(new User())
```
eliminating the need for separate null checks before object manipulation.

**Configuration management** transforms from multi-line defensive code into:
```java
Optional.ofNullable(config.getProperty("timeout")).orElse("30000");
```
where you handle missing properties gracefully.

This approach scales beautifully in complex applications where null values can cascade through multiple method calls, turning potential NPE minefields into predictable, self-documenting code that clearly communicates your handling strategy for absent values.

### Stream Integration: Optional in Collection Processing

Stream operations naturally complement Optional patterns, especially when processing collections that may contain null values or when transformations might fail.

The `flatMap()` operation eliminates empty Optionals from streams, while `map()` operations can safely transform values without null checks.

This combination reduces collection processing code compared to traditional approaches while maintaining type safety and eliminating potential NullPointerExceptions.

Stream integration becomes particularly powerful when dealing with database queries, API responses, or file processing operations where individual elements might be missing or invalid.

You can create processing pipelines that filter out problematic data automatically while preserving valid results.

The pattern
```java
stream().map(this::processItem).filter(Optional::isPresent).map(Optional::get);
```
becomes a standard idiom for safe collection transformation, though Java 9’s
```java
stream().map(this::processItem).flatMap(Optional::stream);
```
provides even cleaner syntax for modern applications.

### Hands-On Examples: Turning Complexity into Clarity

Real-world scenarios show `Optional`’s power. For instance, safely fetching a user’s street name:
```java
Optional.ofNullable(user).flatMap(User::getAddress).map(Address::getStreet).orElse("Unknown");
```
eliminates four potential NPEs in one line.

Consider a payment processing system where `Optional` streamlines validation:

1.  Chain `flatMap()` to navigate ``Payment` → `Card` → `ExpiryDate``.
2.  Use `filter()` to check for expired cards: `.filter(date -> !date.isBefore(LocalDate.now()))`.

---
### Top 10 Java Anti-Patterns You Must Avoid
### 1. God Class

### Anti-Pattern:

A single class does too much — handling business logic, database calls, validations, etc.
```java
public class OrderManager {  
    public void createOrder() { /* business logic */ }  
    public void validateOrder() { /* validation logic */ }  
    public void saveOrderToDB() { /* DB interaction */ }  
    public void sendEmailConfirmation() { /* Email logic */ }  
}
```
### Solution:

Split responsibilities into dedicated classes using **Single Responsibility Principle**.
```java
public class OrderService { ... }  
public class OrderValidator { ... }  
public class OrderRepository { ... }  
public class EmailService { ... }
```
### 2. Tight Coupling

### Anti-Pattern:

Direct instantiation of dependencies within classes.
```java
public class InvoiceService {  
    private EmailService emailService = new EmailService();  
}
```
### Solution:

Use **Dependency Injection (DI)**.
```java
public class InvoiceService {  
    private final EmailService emailService;

    public InvoiceService(EmailService emailService) {  
        this.emailService = emailService;  
    }  
}
```
### 3. Overuse of Static Methods

### Anti-Pattern:

Static methods are hard to test and mock.
```java
public class Utils {  
    public static void log(String msg) {  
        System.out.println(msg);  
    }  
}
```
### Solution:

Use instance methods and dependency injection for better testability.
```java
@Component  
public class LoggerService {  
    public void log(String msg) {  
        System.out.println(msg);  
    }  
}
```

### 4. Hardcoding Values

### Anti-Pattern:

Hardcoded strings, URLs, or config in code.
```java
String dbUrl = "jdbc:mysql://localhost:3306/mydb";
```
### Solution:

Externalize to `application.properties` or use environment variables.
```shell
### application.properties  
db.url=jdbc:mysql://localhost:3306/mydb
```
```java
@Value("${db.url}")  
private String dbUrl;
```
### 5. Empty Catch Blocks

### Anti-Pattern:

Swallowing exceptions silently.
```java
try {  
    someMethod();  
} catch (Exception e) {  
    // ignored  
}
```

### Solution:

At least log or rethrow with context.
```java
catch (Exception e) {  
    logger.error("Error occurred in someMethod", e);  
    throw new CustomException("Failure in someMethod", e);  
}
```
### 6. Duplicate Code

### Anti-Pattern:

Same logic copy-pasted in multiple places.
```java
if (str != null && !str.trim().isEmpty()) {  
    // do something  
}
```
### Solution:

Extract to utility methods or reusable classes.
```java
public static boolean isValid(String str) {  
    return str != null && !str.trim().isEmpty();  
}

```
### 7. Inefficient Loops / Streams

### Anti-Pattern:

Nested loops or unnecessary use of `stream().forEach()`.
```java
for (Order order : orders) {  
    for (Item item : order.getItems()) {  
        // logic  
    }  
}
```

### Solution:

Refactor into flatMaps or collect first, then process.
```java
orders.stream()  
    .flatMap(order -> order.getItems().stream())  
    .forEach(item -> {  
        // logic  
    });
```
### 8. Ignoring Null Checks / NPE

### Anti-Pattern:

No null safety leading to `NullPointerException`.
```java
String name = user.getProfile().getName();
```
### Solution:

Use Optional or null checks.
```java
String name = Optional.ofNullable(user)  
                      .map(User::getProfile)  
                      .map(Profile::getName)  
                      .orElse("N/A");
```

### 9. Not Writing Unit Tests

### Anti-Pattern:

Public methods with no test coverage.

### Solution:

Write unit tests using JUnit, Mockito, etc., with clear Arrange-Act-Assert structure.

### 10. Too Many If-Else or Switch Statements

### Anti-Pattern:

Complex if-else trees for logic handling.
```java
if (type.equals("EMAIL")) {  
    // ...  
} else if (type.equals("SMS")) {  
    // ...  
}
```

### Solution:

Use Strategy Pattern or polymorphism.
```java
interface NotificationSender {  
    void send(String message);  
}  
class EmailSender implements NotificationSender { ... }  
class SmsSender implements NotificationSender { ... }
```
---

# What Are Generics in Java and Why Should You Care? 
Java is well-known for its robustness, but when I first discovered generics, it felt like a game-changer. Generics allow us to write cleaner, safer, and more maintainable code. Today, I’m sharing how leveraging generics help me to transform my programming practices,

### What Are Generics and Why Should You Care?

Generics, introduced in Java 5, allow developers to create classes, interfaces, and methods that operate on typed parameters. In simple terms, they enable you to write flexible, reusable code that can handle different data types safely without casting.

### The Benefits of Using Generics:

-   **Type Safety**: Generics ensure that your code checks for type errors during compile-time.
-   **Code Reusability**: Write once, use many times with different data types.
-   **Cleaner Code**: Reduces the need for explicit typecasting, making your code more readable.
-   **Fewer Runtime Errors**: Detect type mismatches early, preventing potential `ClassCastException`.

### Creating a Generic Class

Let’s look at an example to see how generics improve code quality.

### Without Generics:
```java
public class Box {  
    private Object content;  
  
    public void setContent(Object content) {  
        this.content = content;  
    }  
  
    public Object getContent() {  
        return content;  
    }  
}
```
This class allows storing any type of object. However, when retrieving the content, we need to cast it, which can lead to runtime errors.

### Using Generics:
```java
public class Box<T> {  
    private T content;  
  
    public void setContent(T content) {  
        this.content = content;  
    }  
  
    public T getContent() {  
        return content;  
    }  
}
```
By introducing `<T>`, we allow `Box` to handle any type while maintaining type safety. If we try to put an integer in a `Box<String>`, the compiler will alert us—no more surprises at runtime.

### Using Generics with Methods:

Generics aren’t just limited to classes; you can use them with methods too:
```java
public static <T> void printArray(T[] array) {  
    for (T item : array) {  
        System.out.print(item + " ");  
    }  
    System.out.println();  
}
```
Now, `printArray()` can print arrays of any type, whether `String[]`, `Integer[]`, or `Double[]`, without additional overloads.

### How Generics Make Your Code More Maintainable

Generics play a huge role in making your codebase scalable and easier to maintain. Here’s why:

-   **No Type Casting**: Generics remove unnecessary type casting, making code more concise.
-   **Flexibility**: You can create utility classes and methods that work with different types without rewriting the logic for each type.
-   **Consistency**: Ensures uniform behavior across your code when handling different types.

### Common Pitfalls and How to Avoid Them

### **1. Type Erasure**:

Generics in Java are implemented using **type erasure**, meaning that type information is not available at runtime. This limits certain operations, such as:

-   **Creating Instances of Generic Types**: You cannot create instances of `T` directly (`T item = new T()` is not allowed).
-   **Generic Arrays**: Creating arrays of generic types (e.g., `T[] array = new T[10];`) is not permitted. Instead, use collections like `List<T>`.

### 2. Bounded Type Parameters:

You can constrain type parameters to ensure they only accept certain types:
```java
public <T extends Number> void printNumber(T number) {  
    System.out.println("Number: " + number);  
}
```
This ensures that `T` can only be of type `Number` or a subclass, such as `Integer` or `Double`.

### Generics in Collections: A Quick Overview

Collections in Java are one of the most common areas where generics are applied. Before generics, you had to use `Object` types, requiring casting:
```java
List list = new ArrayList();  
list.add("Hello");  
String s = (String) list.get(0); // Risky cast
```
With generics, the code becomes cleaner and type-safe:
```java
List<String> list = new ArrayList<>();  
list.add("Hello");  
String s = list.get(0); // No cast needed, type-safe
```
### Why You Should Use Generics in Your Next Project

Generics make your code **scalable and maintainable** by reducing boilerplate code and preventing errors. When I started using generics consistently, my projects saw fewer type-related bugs and had clearer, more maintainable structures. Here’s why generics should be your go-to:

-   **Universal Utility**: Implement utility classes and methods that adapt to different data types without modifying the logic.
-   **Compile-Time Safety**: Debug your code efficiently by catching type errors early.

**Interview Point of View:**

**What is the main purpose of using generics in Java?**

-   Generics provide type safety by allowing developers to create classes, interfaces, and methods that operate on typed parameters. They help prevent runtime type errors by catching issues during compile-time.

**What is type erasure, and how does it impact the use of generics in Java?**

-   Type erasure is a process where the compiler removes type information from generics during compilation to maintain backward compatibility. This means generic type information is not available at runtime, limiting certain operations like instantiating generic types.

**Can you create an instance of a generic type in Java?**

-   No, you cannot create an instance of a generic type (`T item = new T()`). Generics are only for compile-time checks, and type information is erased at runtime.

**What are bounded type parameters in generics, and how do they work?**

-   Bounded type parameters restrict the types that can be passed to a generic class or method. For example, `<T extends Number>` ensures `T` is either `Number` or a subclass.

**What are the limitations of using generics with arrays in Java?**

-   You cannot create generic arrays directly (e.g., `T[] array = new T[10];`). This is due to type erasure, which makes it unsafe. Instead, you should use `List<T>` or similar collections.

Generics can transform how you approach Java programming. Start experimenting with them today, and see how your code evolves into a more structured and reliable form! Happy Coding.

---

# SpringBoot @Async

The **@Async** annotation is like the secret weapon of performance optimization in a springboot project. Yeah, we can manually create our own executors and threadpools as well but **@Async** makes things much simpler and more magical.

The **@Async** annotation lets us run code in the background, so our main thread can keep chugging along without waiting for slower tasks to finish. But, like all secret weapons, it's important to use it wisely and know its limits. In this post, we're gonna dive deep into the **@Async** magic and the gotchas we should watch out for when we are using it in our Spring Boot projects. Let's get started!

First let's learn the basics of how to use @Async in our application.

First of all, we need to enable **@Async** in our Spring Boot application. To do this, we will need to add the **@EnableAsync** annotation to a configuration class or to our main application file. This will enable asynchronous behavior for all methods annotated with **@Async** in the application.
```java
@SpringBootApplication  
@EnableAsync  
public class BackendAsjApplication {  
}
```
We will also need to create a Bean specifying the configurations for methods annotated with @Async. We can set things like max threadpool size, queue size etc. Be careful while adding these configurations though. Otherwise, we might run out of memory very soon. I usually also add a log to warn me when the queue size is full and there are no more threads to pick up the new incoming task.
```java
 @Bean  
 public ThreadPoolTaskExecutor taskExecutor() {  
  ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();  
  executor.setCorePoolSize(2);  
  executor.setMaxPoolSize(2);  
  executor.setQueueCapacity(500);  
  executor.setThreadNamePrefix("MyAsyncThread-");  
  executor.setRejectedExecutionHandler((r, executor1) -> 
    log.warn("Task rejected, thread pool is full and queue is also full")
  );  
  executor.initialize();  
  return executor;  
 }
 ```

Now, let's use it. Suppose we have a service class that contains a method that we want to make asynchronous. We will annotate this method with **@Async**.
```java
@Service  
public class EmailService {  
    @Async  
    public void sendEmail() {  
     
    }  
}
```

_(In the code examples, you will see EmailService and PurchaseService mentioned many times. These are just examples. I don't wanna name everything as “MyService”. So, naming it to something which is more meaningful. In an e-commerce application, you would of course want your EmailService to be async so that customer requests are not blocked on that)_

Now, when we call this method, it will return immediately, freeing up the calling thread (usually the main thread) to continue with other tasks. The method will continue to execute in the background and the result will be returned to the calling thread at a later time. Since we have marked our @Async method here with void, we are not really interested in when it completes.

Pretty easy and pretty powerful, right? (Of course there are a lot more configurations that we can do but the above code is enough to run a task fully async)

But, before we start annotating all of our methods with @Async, there are a few gotchas that we need to be aware of.

## **@Async method needs to be in a different class**

When using the @Async annotation, it is important to note that we cannot call an @Async method from within the same class. This is because doing so will lead to an infinite loop and cause the application to hang.

Here's an example of what NOT to do:
```java
@Service  
public class PurchaseService {  
  
    public void purchase(){  
        sendEmail();  
    }  
  
    @Async  
    public void sendEmail(){  
        // Asynchronous code  
    }  
}
```
Instead, we should use separate classes or services for our asynchronous methods.
```java
@Service  
public class EmailService {  
  
   @Async  
    public void sendEmail(){  
        // Asynchronous code  
    }  
}  
  
@Service  
public class PurchaseService {  
  
    public void purchase(){  
        emailService.sendEmail();  
    }  
  
    @Autowired  
    private EmailService emailService;  
}
```

Now you might be wondering, can I call an async method from within another async method? The short answer is no. When an async method is called, it's executed in a different thread and the calling thread moves on to the next task. If the calling thread itself is an async method, it has no way of waiting for the called async method to finish before moving on, which can lead to unexpected behavior.

## @Async and @Transcational don't play well

The @Transactional annotation is used to indicate that a method or a class should participate in a transaction. It is used to ensure that a group of database operations are performed as a single unit of work and that the database is left in a consistent state in case of any failures.

When a method is annotated with @Transactional, Spring creates a proxy around the method, and all the database operations within the method are executed within the context of a transaction. Spring also takes care of starting the transaction before the method is invoked and committing the transaction after the method returns, or rolling back the transaction in case of an exception.

However, when you use the @Async annotation to make a method asynchronous, the method is executed in a separate thread from the main application thread. This means that the method is no longer executed within the context of the transaction that was started by Spring. Because of this, the database operations within the @Async method will not participate in the transaction, and the database may be left in an inconsistent state in case of an exception.
```java
@Service  
public class EmailService {  
  
    @Transactional  
    public void transactionalMethod() {  
        //database operation 1  
        asyncMethod();  
        //database operation 2  
    }  
  
    @Async  
    public void asyncMethod() {  
        //database operation 3  
    }  
}
```

In this example, database operation 1 and database operation 2 are executed within the context of the transaction started by Spring. But, database operation 3 is executed in a separate thread, and is not part of the transaction.

So, if an exception occurs before database operation 3 is executed, database operation 1 and database operation 2 will be rolled back as expected, but database operation 3 will not be rolled back. This can leave the database in an inconsistent state.

Of course, there are ways around this i.e using something like a TransactionTemplate to manage the transaction as well but the out-of-the-box, you will not get this support and will end up with issues if call an async method from a transcational method.

## @Async blocking Issues

Let's suppose this is the configuration of our @Async threadpools:
```java
@Bean  
 public ThreadPoolTaskExecutor taskExecutor() {  
  ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();  
  executor.setCorePoolSize(2);  
  executor.setMaxPoolSize(2);  
  executor.setQueueCapacity(500);  
  executor.setThreadNamePrefix("MyAsyncThread-");  
  executor.setRejectedExecutionHandler((r, executor1) -> 
    log.warn("Task rejected, thread pool is full and queue is also full")
  );  
  executor.initialize();  
  return executor;  
 }
```
This means that at any particular moment in time, we will have maximum 2 @Async tasks running. If more tasks come in, they will be queued up until the queue size reaches 500.

But now suppose, one of our @Async tasks is taking too much time to execute or it is simply blocked because of an external dependency. This will mean that all other tasks would be queued and will not be executed fast enough. This might cause delays depending on the type of your application.

One way to get around this problem is to have a separate threadpool for long running tasks and a separate threadpool for tasks which are more urgent and don't take a lot of processing time. We can do that like this:
```java
@Primary  
 @Bean(name = "taskExecutorDefault")  
 public ThreadPoolTaskExecutor taskExecutorDefault() {  
  ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();  
  executor.setCorePoolSize(2);  
  executor.setMaxPoolSize(2);  
  executor.setQueueCapacity(500);  
  executor.setThreadNamePrefix("Async-1-");  
  executor.initialize();  
  return executor;  
 }  
  
 @Bean(name = "taskExecutorForHeavyTasks")  
 public ThreadPoolTaskExecutor taskExecutorRegistration() {  
  ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();  
  executor.setCorePoolSize(2);  
  executor.setMaxPoolSize(2);  
  executor.setQueueCapacity(500);  
  executor.setThreadNamePrefix("Async2-");  
  executor.initialize();  
  return executor;  
 }
```
And then to use it, simply add the name of the executor in the @Async declaration:
```java
@Service  
public class EmailService {  
    @Async("taskExecutorForHeavyTasks")  
    public void sendEmailHeavy() {  
        //method implementation  
    }  
}
```
However, note that we should not use @Async on methods that call `Thread.sleep()` or `Object.wait()` as it will block the thread and the purpose of using @Async will be defeated.

## Exceptions in @Async

Another thing to keep in mind is that @Async methods do not throw exceptions to the calling thread. This means that you need to handle exceptions properly within the @Async method, or else they will be lost.

Here's an example of what NOT to do:
```java
@Service  
public class EmailService {  
  
    @Async  
    public void sendEmail() throws Exception{  
        throw new Exception("Oops, cannot send email!");  
    }  
}  
  
@Service  
public class PurchaseService {  
      
    @Autowired  
    private EmailService emailService;  
  
    public void purchase(){  
        try{  
            emailService.sendEmail();  
        }catch (Exception e){  
            System.out.println("Caught exception: " + e.getMessage());  
        }  
    }  
}
```

In the above code, the exception is thrown in asyncMethod() but it will not be caught by the calling thread and the catch block will not be executed.

To properly handle exceptions in an @Async method, we can use a combination of Future and try-catch blocks. Here's an example:
```java
@Service  
public class EmailService {  
  
    @Async  
    public Future<String> sendEmail() throws Exception{  
        throw new Exception("Oops, cannot send email!");  
    }  
}  

  
@Service  
public class PurchaseService {  
  
    @Autowired  
    private EmailService emailService;  
  
    public void purchase(){  
        try{  
            Future<String> future = emailService.sendEmail();  
            String result = future.get();  
            System.out.println("Result: " + result);  
        }catch (Exception e){  
            System.out.println("Caught exception: " + e.getMessage());  
        }  
    }  
}
```

By returning a Future object and using a try-catch block, we can properly handle and catch exceptions thrown within an @Async method.

In conclusion, the @Async annotation in Spring Boot is a powerful tool for improving the performance and scalability of your application. But, it's important to use it with care and be aware of its limitations. By understanding these gotchas and using techniques like `CompletableFuture` and an `Executor`, you can make the most of the @Async annotation and take your application to the next level.

---
# Rate Limiting in Spring Boot. Achieve Scalability, Security

In the dynamic landscape of Spring Boot applications, managing and controlling access to resources is crucial for ensuring scalability, security, and optimal performance.

Rate limiting emerges as a powerful technique to achieve these objectives by regulating the number of requests or actions a client can make within a specified time frame. This comprehensive article aims to delve deep into the realm of rate limiting in Spring Boot, exploring its significance, implementation strategies, testing methodologies, real-world applications, and the broader implications for building high-performing and secure applications.

### Understanding Rate Limiting

Rate limiting serves as a critical mechanism for controlling the rate of incoming requests to a server or service. By imposing restrictions on the frequency of requests from clients, rate limiting prevents overloading, mitigates the risk of abuse or malicious attacks, and ensures fair resource allocation. It plays a pivotal role in maintaining system stability, reliability, and responsiveness, particularly in scenarios characterized by fluctuating traffic patterns or constrained resources

### Why Is Rate Limiting Important?

Rate limiting holds immense importance in modern web applications for several reasons:

-   **Scalability**: Rate limiting facilitates horizontal scalability by preventing individual clients from monopolizing server resources, thereby ensuring equitable access for all users.
-   **Security**: It serves as a protective barrier against denial-of-service (DoS) attacks, brute-force login attempts, and other malicious activities that seek to overwhelm the server with excessive requests.
-   **Performance Optimization**: By distributing incoming requests evenly across the system, rate limiting helps maintain optimal performance levels even during peak traffic periods, preventing service degradation or downtime.
-   **Resource Management**: Rate limiting conserves server resources by preventing unnecessary processing of excessive requests, thereby optimizing resource utilization and reducing operational costs.

### Strategies for Rate Limiting in Spring Boot

Implementing rate limiting in Spring Boot applications involves adopting various strategies tailored to the specific requirements of the system. Some common approaches include:

### 1. Token Bucket Algorithm

The token bucket algorithm is a popular rate limiting strategy that maintains a bucket of tokens, where each token represents permission to execute a request. Clients consume tokens when making requests, and the bucket replenishes tokens at a fixed rate. Requests are allowed only if sufficient tokens are available in the bucket.

### 2. Fixed Window Algorithm

In the fixed window algorithm, a predetermined time window is defined, and clients are allowed a limited number of requests within that window. Once the window elapses, the request count resets, and clients can make additional requests in the subsequent window.

### 3. Sliding Window Algorithm

The sliding window algorithm maintains a moving time window, typically spanning a predefined duration. Clients are allowed a certain quota of requests within the sliding window, and the quota replenishes over time. Requests exceeding the quota are throttled or delayed until the window resets.

### Implementing Rate Limiting in Spring Boot

Let's explore how to implement rate limiting in Spring Boot using Spring AOP and the token bucket algorithm:

### 1. Define Rate Limiting Aspect
```java
import org.aspectj.lang.annotation.Aspect;  
import org.aspectj.lang.annotation.Before;  
import org.springframework.stereotype.Component;  
import java.util.concurrent.ConcurrentHashMap;  
import java.util.concurrent.atomic.AtomicInteger;  
  
@Aspect  
@Component  
public class RateLimitingAspect {  
    private static final ConcurrentHashMap<String, AtomicInteger> 
        requestCounts = new ConcurrentHashMap<>();  
    private static final int REQUEST_LIMIT = 100;  
    private static final long TIME_LIMIT = 60000; // 1 minute  
  
    @Before("@annotation(RateLimited)")  
    public void beforeRequest() {  
        String clientId = getClientId(); // Implement method to get client ID  
        AtomicInteger count = 
            requestCounts.computeIfAbsent(clientId, k -> new AtomicInteger(0));  
        if (count.incrementAndGet() > REQUEST_LIMIT) {  
            throw new RateLimitExceededException("Rate limit exceeded");  
        }  
        if (requestCounts.size() == 1) {  
            resetRequestCounts();  
        }  
}  
  
    private void resetRequestCounts() {  
        new Thread(() -> {  
            try {  
                Thread.sleep(TIME_LIMIT);  
                requestCounts.clear();  
            } catch (InterruptedException e) {  
                e.printStackTrace();  
            }  
        }).start();  
    }  
}
```

### 2. Define Rate Limited Annotation
```java
import java.lang.annotation.ElementType;  
import java.lang.annotation.Retention;  
import java.lang.annotation.RetentionPolicy;  
import java.lang.annotation.Target;  
  
@Retention(RetentionPolicy.RUNTIME)  
@Target(ElementType.METHOD)  
public @interface RateLimited {  
}
```

### 3. Apply Rate Limiting to Controller Methods
```java
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.RestController;  
  
@RestController  
public class MyController {  
  
    @RateLimited  
    @GetMapping("/resource")  
    public String getResource() {  
        return "Resource accessed";  
    }  
}
```

### Testing Rate Limiting in Spring Boot

Testing rate limiting in Spring Boot applications is essential to ensure that the implemented rate limiting logic functions as expected under different scenarios. Some testing methodologies include:

-   **Unit Testing**: Unit tests can be written to validate the behavior of individual rate limiting components, such as interceptors, middleware, or filter components. Mocking frameworks can be used to simulate various request scenarios and verify the correctness of rate limiting rules.
-   **Integration Testing**: Integration tests aim to validate the interaction between different components of the application, including rate limiting components and the underlying business logic. Integration tests simulate real-world request patterns and verify that rate limiting rules are enforced correctly across the entire request processing pipeline.
-   **Load Testing:** Load testing involves subjecting the application to a simulated load, typically using load testing tools or frameworks. By generating a high volume of concurrent requests and observing the application's behavior, developers can assess the effectiveness and scalability of the implemented rate limiting logic under heavy traffic conditions.

### Real-World Applications of Rate Limiting

Rate limiting finds applications in various domains and scenarios, including:

-   **API Rate Limiting**: Many API providers enforce rate limiting to restrict the number of API calls made by clients, preventing abuse and ensuring fair usage of API resources.
-   **User Authentication and Authorization**: Rate limiting can be applied to user authentication and authorization mechanisms to prevent brute-force attacks on login endpoints, safeguarding user accounts from unauthorized access attempts.
-   **Content Delivery Networks (CDNs**): CDNs often employ rate limiting techniques to regulate the rate of incoming requests to origin servers, preventing overload and ensuring optimal content delivery to end-users.
-   **Microservices Communication**: In microservices architectures, rate limiting can be used to regulate the rate of requests between services, preventing cascading failures and ensuring the stability of the overall system.

### Conclusion

Rate limiting serves as a foundational mechanism for controlling access to resources, ensuring security, scalability, and optimal performance in Spring Boot applications.

By implementing rate limiting strategies tailored to the specific requirements of the system and testing them rigorously, developers can build robust, resilient, and high-performing applications capable of handling diverse workload scenarios. As organizations continue to embrace cloud-native architectures and microservices paradigms, rate limiting remains a critical tool for managing the complexities of modern distributed systems.

---

# Implementing Deflate Compression in Spring Boot

In the world of web applications, performance is a critical factor that can make or break user experience. One of the most effective ways to improve performance is by reducing the size of data transmitted between the server and the client. This is where compression techniques come into play. Spring Boot, a popular Java-based framework, provides built-in support for various compression techniques to optimize data transfer

In this post, we’ll explore Deflate Compression, why it’s important, when to use it, and how to implement it in a Spring Boot application. By the end of this guide, you’ll have a clear understanding of how to optimize your application’s performance using Deflate compression.

### What is Deflate Compression?

Deflate is a lossless data compression algorithm that combines the LZ77 algorithm and Huffman coding to reduce the size of data. It is widely used in web applications to compress HTTP responses before sending them to the client.

When a client (e.g., a browser or API consumer) requests data from a server, the server can compress the response using Deflate, reducing the size of the data transmitted over the network. The client then decompresses the data upon receiving it.

### Why Do We Need Deflate Compression?

### 1. Improve Performance

Compressed responses are smaller in size, which means:

-   Faster data transfer over the network.
-   Reduced latency, especially for users on slow or limited bandwidth connections.

### 2. Save Bandwidth

Compression reduces the amount of data sent over the network, which is especially important for applications with high traffic or large payloads (e.g., JSON or XML responses).

### 3. Enhance User Experience

Faster response times lead to better user experiences, especially for mobile users or those accessing your application from remote locations.

### When to Use Deflate Compression?

### Use Cases

1.  **APIs with Large Payloads:**

-   If your API returns large JSON or XML responses, compressing the data can significantly reduce response times.
-   Example: A product search API that returns hundreds of product details.

2. **Web Applications with Static Content:**

-   Compressing static assets like HTML, CSS, and JavaScript files can improve page load times.
-   Example: A content-heavy blog or e-commerce website.

3. **Data-Intensive Applications:**

-   Applications that send large amounts of data, such as reports or analytics dashboards, can benefit from compression.
-   Example: A financial dashboard that generates large reports.

### When Not to Use Compression

-   Small Responses: Compressing small responses (e.g., less than 1 KB) can add unnecessary overhead.
-   Already Compressed Data: Files like images, videos, and PDFs are already compressed, so applying Deflate won’t provide additional benefits.

### Step-by-Step Guide to Implementing Deflate Compression in Spring Boot

Now that we understand the importance of Deflate compression, let’s dive into the implementation.

You can find full code https://github.com/raju4789/deflate-compression.

### Step 1: Set Up Your Spring Boot Project

1.  Create a Spring Boot Project:

-   Go to [Spring Initializr](https://start.spring.io/).
-   Add the following dependencies:
-   Spring Web (for building REST APIs or web applications).
-   Generate the project and import it into your IDE (e.g., IntelliJ IDEA, Eclipse).

### Step 2: Create a Custom Deflate Compression Filter

Spring Boot does not provide built-in support for Deflate compression, so we’ll create a custom filter to handle it.

1.  Create the Filter:

-   Create a new class `DeflateCompressionFilter` in the `com.example.deflatecompression` package.

###### Code the Filter
```java
public class DeflateCompressionFilter implements Filter {  
  
    private static final int MIN_RESPONSE_SIZE = 1024; // Minimum size to compress (1 KB)  
  
    @Override  
    public void init(FilterConfig filterConfig) throws ServletException {  
        // Initialization logic if needed  
    }  
  
    @Override  
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)  
            throws IOException, ServletException {  
        HttpServletRequest httpRequest = (HttpServletRequest) request;  
        HttpServletResponse httpResponse = (HttpServletResponse) response;  
  
        // Check if the client supports Deflate compression  
        String acceptEncoding = httpRequest.getHeader("Accept-Encoding");  
        if (acceptEncoding == null || !acceptEncoding.toLowerCase()
                            .contains("deflate-compression")) {  
            // If the client does not support Deflate, proceed without compression  
            chain.doFilter(request, response);  
            return;  
        }  
  
        // Wrap the response to capture the output  
        DeflateResponseWrapper responseWrapper = 
                new DeflateResponseWrapper(httpResponse);  
  
        // Proceed with the filter chain  
        chain.doFilter(request, responseWrapper);  
  
        // Compress the response if it meets the size threshold  
        if (responseWrapper.getContentLength() > MIN_RESPONSE_SIZE) {  
            httpResponse.setHeader("Content-Encoding", "deflate");  
            try (DeflaterOutputStream deflaterOutputStream = 
                new DeflaterOutputStream(httpResponse.getOutputStream())) {  
                deflaterOutputStream.write(responseWrapper.getCapturedData());  
            }  
        } else {  
            // Write the uncompressed response  
            httpResponse.getOutputStream().write(responseWrapper.getCapturedData());  
        }  
    }  
  
    @Override  
    public void destroy() {  
        // Cleanup logic if needed  
    }  
}
```

### Step 3: Create a Response Wrapper

The filter needs to capture the response content before compressing it. We’ll create a custom `HttpServletResponseWrapper` to achieve this.

1.  Create the Wrapper:

-   Create a new class `DeflateResponseWrapper` in the `com.example.deflatecompression` package.

###### Code the Response Wrapper code
```java
package com.raju.medium.brotli_compression.filter;  
  
  
import jakarta.servlet.ServletOutputStream;  
import jakarta.servlet.WriteListener;  
import jakarta.servlet.http.HttpServletResponse;  
import jakarta.servlet.http.HttpServletResponseWrapper;  
  
import java.io.ByteArrayOutputStream;  
import java.io.IOException;  
import java.io.PrintWriter;  
  
public class DeflateResponseWrapper extends HttpServletResponseWrapper {  
  
    private final ByteArrayOutputStream capture;  
    private ServletOutputStream outputStream;  
    private PrintWriter writer;  
  
    public DeflateResponseWrapper(HttpServletResponse response) {  
        super(response);  
        capture = new ByteArrayOutputStream();  
    }  
  
    @Override  
    public ServletOutputStream getOutputStream() {  
        if (writer != null) {  
            throw new IllegalStateException("Writer already in use");  
        }  
        if (outputStream == null) {  
            outputStream = new ServletOutputStream() {  
                @Override  
                public void write(int b) throws IOException {  
                    capture.write(b);  
                }  
  
                @Override  
                public void flush() throws IOException {  
                    capture.flush();  
                }  
  
                @Override  
                public void close() throws IOException {  
                    capture.close();  
                }  
  
                @Override  
                public boolean isReady() {  
                    return true;  
                }  
  
                @Override  
                public void setWriteListener(WriteListener writeListener) {  
                    // No-op  
                }  
  
            };  
        }  
        return outputStream;  
    }  
  
    @Override  
    public PrintWriter getWriter() {  
        if (outputStream != null) {  
            throw new IllegalStateException("OutputStream already in use");  
        }  
        if (writer == null) {  
            writer = new PrintWriter(capture);  
        }  
        return writer;  
    }  
  
    public byte[] getCapturedData() {  
        return capture.toByteArray();  
    }  
  
    public int getContentLength() {  
        return capture.size();  
    }  
}
```
### Step 4: Register the Filter in Spring Boot

To make the filter active, we need to register it in the Spring Boot application.

1.  Create a Configuration Class:

-   Create a new class `AppConfig` in the `com.example.deflatecompression` package.

###### Code the Filter Registration
```java
  
@Configuration  
public class AppConfig {  
  
    @Bean  
    public FilterRegistrationBean<DeflateCompressionFilter> deflateCompressionFilter() {  
        FilterRegistrationBean<DeflateCompressionFilter> registrationBean = 
                new FilterRegistrationBean<>();  
        registrationBean.setFilter(new DeflateCompressionFilter());  
        registrationBean.addUrlPatterns("/*"); // Apply to all endpoints  
        registrationBean.setName("DeflateCompressionFilter");  
        registrationBean.setOrder(1); // Set the order of the filter  
        return registrationBean;  
    }  
}
```

### Step 5: Create a Sample REST Controller

To test the Deflate compression, create a simple REST controller that returns a large JSON response.

###### Code the Controller
```java
@RestController  
public class DeflateCompressionTestController {  
  
    @GetMapping("/data")  
    public Map<String, String> getData() {  
        Map<String, String> data = new HashMap<>();  
        for (int i = 0; i < 100000; i++) {  
            data.put("key" + i, "value" + i);  
        }  
        return data;  
    }  
}
```
### Step 6: Test the Implementation

1.  Start the Application: Run the Spring Boot application.
2.  Test Without Compression:

-   Use Postman or cURL to send a `GET` request to `http://localhost:8080/data` without the `Accept-Encoding` header.
-   The response should not be compressed.

![](https://miro.medium.com/v2/resize:fit:875/1*LJ7ji2QwzwiwoeXZWyzvvg.png)

3. Test With Compression:

-   Add the `Accept-Encoding: deflate` header to the request.
-   The response should be compressed, and the `Content-Encoding` header should be set to `deflate`.

![](https://miro.medium.com/v2/1*gVs6rO_Gtqo1RdwCTEUSzA.png)

### Conclusion

By implementing Deflate compression in Spring Boot, you can significantly improve the performance of your application, reduce bandwidth usage, and enhance the user experience. This guide provides a step-by-step approach to implementing and testing Deflate compression, making it easy to optimize your application for real-world scenarios.

---

# Java Garbage Collectors, their working and comparisons

Java garbage collectors (GCs) are automatic memory management components responsible for reclaiming memory occupied by objects that are no longer in use. They play a crucial role in managing Java’s dynamic memory allocation, allowing developers to focus on application logic without manual memory deallocation. GCs are needed to prevent memory leaks, optimize memory usage, and ensure the overall performance and stability of Java applications.

Before the advent of GCs, manual memory management was the norm in programming languages. Developers had to explicitly allocate and deallocate memory for objects, which often led to errors like memory leaks or dangling references. Such manual memory management was error-prone and time-consuming, requiring careful tracking and release of objects.

Java introduced automatic memory management through its GC mechanism, relieving developers from manual memory deallocation. GCs periodically identify and release memory occupied by objects that are no longer reachable or in use. This process involves several stages, including marking reachable objects, identifying unreachable objects, and reclaiming their memory.

In this document, we will cover the 10 most widely used GCs:

1.  Serial GC: A simple, single-threaded GC algorithm suitable for small applications or systems with low memory requirements.
2.  Parallel GC: Uses multiple threads to speed up garbage collection, making it more efficient for applications that generate a large amount of garbage.
3.  CMS (Concurrent Mark-Sweep) GC: Provides low-latency garbage collection by performing most of the collection work concurrently with the application’s execution.
4.  G1 (Garbage-First) GC: A server-style GC that divides the heap into regions and performs garbage collection on smaller subsets of the heap to minimize pauses and improve throughput.
5.  ZGC: Designed for applications requiring ultra-low pause times, ZGC performs concurrent garbage collection without significant interruption to the application.
6.  Shenandoah GC: Another concurrent GC algorithm, Shenandoah aims to reduce pause times by performing garbage collection concurrently with the application.
7.  Epsilon GC: A no-op GC algorithm useful for testing and scenarios where the application handles memory management independently.
8.  Azul C4 GC: Designed for high-performance and low-latency requirements, C4 GC utilizes pauseless, concurrent collection techniques.
9.  IBM Metronome GC: An experimental real-time GC algorithm that focuses on predictable and consistent pause times.
10.  SAP Garbage Collector: A concurrent GC algorithm optimized for large heap sizes and low-latency requirements.

### Serial GC

Serial GC is a garbage collector algorithm used in Java for automatic memory management. It is a simple and straightforward algorithm that works efficiently for small-scale applications or systems with limited memory requirements. In this document, we will explore how the Serial GC algorithm works, its benefits, and considerations for its usage.

### How Serial GC Works

The Serial GC algorithm operates in a stop-the-world manner, meaning it pauses the application’s execution during garbage collection. When the Serial GC is triggered, it performs the following steps:

1.  Initial Mark: The algorithm identifies and marks all objects directly referenced by the application’s active threads. This marking process is performed while the application is paused briefly.
2.  Marking: The algorithm traverses the object graph starting from the marked objects and identifies all reachable objects. It marks these reachable objects as live.
3.  Remark: After the initial marking, the algorithm allows the application to resume briefly and continues marking any objects that became reachable during the pause.
4.  Sweep and Compact: Once the marking is complete, the algorithm sweeps the memory regions, deallocating memory occupied by unreferenced objects. It then compacts the memory by moving live objects together, creating a contiguous free memory space.
5.  Free Memory: After compaction, the algorithm updates the free memory space pointer to indicate the new location for object allocation.

### Pros of Using Serial GC:

1.  Simplicity: The Serial GC is straightforward to implement and understand, making it an ideal choice for beginners or smaller applications.
2.  Low Overhead: The algorithm has lower CPU and memory overhead compared to more complex GC algorithms, making it suitable for resource-constrained environments.
3.  Predictable Pauses: As a stop-the-world collector, the Serial GC provides predictable pauses during garbage collection, allowing for better control over the application behavior.
4.  Single-threaded Execution: The Serial GC performs garbage collection using a single thread, ensuring determinism and avoiding potential multi-threading issues.

### Cons of Using Serial GC:

1.  Longer Pause Times: The stop-the-world nature of the Serial GC can result in longer pause times, causing interruptions in application responsiveness for larger heaps or memory-intensive applications.
2.  Limited Scalability: The single-threaded nature of the Serial GC limits its scalability on modern multi-core processors, where parallelism can significantly improve GC performance.
3.  Not Suitable for Large Applications: The Serial GC may not be the optimal choice for large-scale applications or systems with high memory requirements, as its performance may degrade due to increased garbage collection times.

### Conclusion

Serial GC is a simple and efficient garbage collector algorithm suitable for smaller applications or environments with limited memory resources. Its straightforward implementation and low overhead make it an attractive choice for resource-constrained systems. However, it is important to consider its limitations, such as longer pause times and limited scalability, when evaluating its suitability for larger or memory-intensive applications. Understanding the characteristics and trade-offs of the Serial GC algorithm can help developers make informed decisions about GC selection based on their specific application requirements.

### Parallel GC

Parallel GC is a garbage collector algorithm used in Java for automatic memory management. It is designed to take advantage of multi-core processors and provides improved garbage collection performance by parallelizing certain tasks. In this document, we will delve into the Parallel GC algorithm, and its workings in simple terms, and discuss the benefits and considerations of its usage.

### How Parallel GC Works

The Parallel GC algorithm shares similarities with the Serial GC algorithm but introduces parallelism to expedite garbage collection. It operates in a stop-the-world manner, temporarily pausing the application’s execution. The steps involved in the Parallel GC algorithm are as follows:

1.  Initial Mark: Similar to the Serial GC, the algorithm identifies and marks all objects directly referenced by the application’s active threads. This marking process occurs while the application is paused momentarily.
2.  Concurrent Marking: While the application is running, the algorithm concurrently marks reachable objects in the memory, utilizing multiple threads. This concurrent marking phase reduces the overall pause time required for garbage collection.
3.  Remark: After the concurrent marking phase, the algorithm allows the application to continue running while it performs a final marking process to account for objects that may have become reachable during the concurrent phase.
4.  Concurrent Sweep and Compaction: The Parallel GC concurrently sweeps and deallocates memory regions occupied by unreferenced objects. Simultaneously, it compacts the memory, moving live objects together to create contiguous free memory space. This concurrent sweep and compaction phase helps reduce the pause time further.
5.  Free Memory: After compaction, the algorithm updates the free memory space pointer to indicate the new location for object allocation.

### Pros of Using Parallel GC:

1.  Improved Throughput: Parallel GC leverages multiple threads to execute garbage collection tasks concurrently, leading to improved throughput by utilizing the processing power of multi-core processors.
2.  Reduced Pause Times: By parallelizing the marking, sweeping, and compaction phases, the Parallel GC minimizes the pause times required for garbage collection, resulting in improved application responsiveness.
3.  Scalability: The algorithm’s ability to utilize multiple threads makes it highly scalable, allowing it to handle larger heaps and memory-intensive applications more efficiently.
4.  Enhanced Performance: Parallel GC performs well in scenarios where the application generates a significant amount of garbage, as it can leverage parallelism to expedite garbage collection and keep up with memory demands.

### Cons of Using Parallel GC:

1.  Increased CPU Utilization: The Parallel GC algorithm utilizes multiple threads, leading to higher CPU utilization compared to single-threaded garbage collection algorithms. This increased utilization may affect the overall system performance for applications with limited CPU resources.
2.  Longer Individual Pause Times: While the overall pause time may be reduced, the individual pause times for each garbage collection cycle might be longer compared to other algorithms. This aspect may impact the responsiveness of time-sensitive applications.
3.  Not Suitable for Small Systems: The Parallel GC algorithm’s multi-threaded nature and increased resource utilization make it less suitable for small-scale systems with limited resources or single-core processors.

### Conclusion

Parallel GC is a garbage collector algorithm in Java that leverages parallelism to enhance garbage collection performance. By utilizing multiple threads, it achieves improved throughput, reduced pause times, and better scalability for memory-intensive applications. However, it is essential to consider the increased CPU utilization and potentially longer individual pause times when evaluating the suitability of Parallel GC for specific application scenarios. Understanding the characteristics and trade-offs of the Parallel GC algorithm is crucial for making informed decisions regarding garbage collector selection based on the specific requirements of the application.

![](https://miro.medium.com/v2/resize:fit:875/1*cTHuyu_4bQchvbDmPqRLkQ.png)

### CMS (Concurrent Mark-Sweep) GC

The Concurrent Mark-Sweep (CMS) Garbage Collector is a popular garbage collection algorithm used in Java to manage memory and reclaim unused objects. Unlike the stop-the-world approach of some other garbage collectors, CMS aims to minimize application pauses by running certain phases concurrently with the application threads. This document provides an in-depth overview of CMS, explaining its algorithm, benefits, and considerations for usage.

### Algorithm Overview:

The CMS algorithm consists of several concurrent and stop-the-world phases:

1.  Initial Mark: Pauses the application briefly to identify objects directly reachable from the root set.
2.  Concurrent Mark: Concurrently traverses object graphs, marking objects that are still in use.
3.  Concurrent Preclean: Continues marking objects concurrently while accounting for changes made during concurrent marking.
4.  Final Remark: Pauses the application again to identify objects modified during concurrent marking and completes marking.
5.  Concurrent Sweep: Concurrently reclaims memory by sweeping through and freeing unused objects.
6.  Concurrent Reset: Concurrently resets internal data structures and prepares for the next garbage collection cycle.

### How CMS Works

In simpler terms, CMS aims to perform garbage collection with minimal impact on application responsiveness:

1.  The initial mark and final remark phases cause short pauses as they require analyzing root objects and marking reachable objects.
2.  Concurrent marking occurs alongside application threads, identifying additional reachable objects.
3.  The concurrent preclean phase handles any object modifications during concurrent marking.
4.  Concurrent sweeping frees up memory by reclaiming unused objects while the application continues running.
5.  Concurrent reset prepares the garbage collector for the next cycle, ensuring it is ready for future garbage collection.

### Pros of Using CMS:

-   Reduced Pause Times: CMS aims to minimize pauses by performing garbage collection concurrently with the application, resulting in better application responsiveness.
-   Improved Scalability: CMS is well-suited for large applications with high thread concurrency, as it strives to run concurrently with application threads.
-   Effective for Mixed Workloads: CMS performs well in scenarios where the application generates a significant amount of short-lived objects.

### Cons and Considerations:

-   Increased CPU Utilization: Concurrent execution can lead to higher CPU usage due to the additional threads involved in garbage collection.
-   Fragmentation Concerns: CMS may suffer from memory fragmentation issues, leading to less efficient memory utilization.
-   Limited Pause Reduction: While CMS reduces pauses compared to other algorithms, it may not eliminate pauses entirely, and long-running concurrent phases can still impact application performance.
-   Deprecated in Java 9+: CMS is deprecated in Java 9 and later versions, with the intention to be removed in future releases. The introduction of the Garbage-First (G1) GC aims to provide a more efficient and scalable alternative.

### Conclusion

The Concurrent Mark-Sweep (CMS) Garbage Collector in Java offers a balance between pause reduction and application responsiveness by performing concurrent garbage collection alongside the application threads. It reduces pause times, improves scalability, and works well for mixed workloads. However, it comes with considerations such as increased CPU utilization, potential fragmentation issues, and the fact that it has been deprecated in recent Java versions. Understanding the characteristics and trade-offs of CMS is crucial for making informed decisions when selecting a garbage collector for your Java application.

![](https://miro.medium.com/v2/resize:fit:875/1*8MJmvqBH3TrfvgXRZDIl7g.png)

### G1 (Garbage-First) GC

The Garbage-First (G1) Garbage Collector is a generational garbage collection algorithm introduced in Java 7. It is designed to provide better performance and lower pause times for large heap sizes, making it suitable for modern Java applications. In this document, we will explore the workings of the G1 GC, its benefits, and considerations for its usage.

### Overview of G1 GC

The G1 GC is a parallel and concurrent garbage collector that divides the heap into multiple regions. It operates based on the concept of regions, where each region is a fixed-size block of memory. The heap is dynamically divided into Eden regions, survivor regions, and old regions. The G1 GC collects garbage in a region-based manner, allowing it to prioritize the most heavily garbage-filled regions first.

### How G1 GC Works

1.  Initial Marking: G1 GC starts by identifying the root objects directly reachable from application threads, such as static variables and reference objects.
2.  Concurrent Marking: G1 GC concurrently marks live objects in the heap while the application threads continue to run. It uses a series of marking cycles to traverse the object graph, identifying live objects and updating the mark bits accordingly.
3.  Remark: Once the concurrent marking phase is complete, G1 GC performs a stop-the-world remark phase to process any remaining objects that were modified during the concurrent marking.
4.  Cleanup: G1 GC performs a cleanup phase to reclaim memory from the garbage-collected regions. It selects regions with the most garbage and compacts live objects into fewer regions to reduce fragmentation.
5.  Evacuation: G1 GC uses the evacuation process to transfer live objects from one region to another, ensuring that regions are filled with mostly live objects and reducing the need for full garbage collections.

### Pros of Using G1 GC

-   Improved Pause Times: G1 GC aims to provide more predictable and shorter pause times, especially for applications with large heaps, by minimizing the duration of stop-the-world garbage collection pauses.
-   Adaptive Behavior: G1 GC adjusts its heap partitioning and collection strategies based on the application’s workload, allowing it to dynamically adapt to changing memory usage patterns.
-   Better Utilization of Hardware Resources: G1 GC utilizes multiple threads for parallel garbage collection, which can lead to better utilization of available CPU resources, resulting in improved application throughput.
-   Reduced Fragmentation: G1 GC’s compacting algorithm reduces memory fragmentation by reclaiming memory from regions with a high garbage-to-live object ratio.

### Cons of Using G1 GC

-   Increased Overhead: Compared to other garbage collectors, G1 GC may introduce a slightly higher CPU overhead due to its more complex heap management and concurrent marking algorithms.
-   Longer Application Warm-Up: G1 GC may exhibit longer warm-up times as it gathers statistics and adapts its behavior to optimize garbage collection performance.

### Conclusion

The G1 Garbage Collector is a powerful garbage collection algorithm introduced in Java 7, specifically designed to address the challenges of managing large heap sizes with shorter pause times. With its concurrent and region-based approach, G1 GC offers improved garbage collection performance for modern Java applications. It is recommended to evaluate the specific requirements and characteristics of your application before choosing the G1 GC, ensuring it aligns with your desired performance goals and resource utilization.

![](https://miro.medium.com/v2/resize:fit:875/1*amj_hNKxqOFJDTEEX2GpoQ.png)

### ZGC

ZGC (Z Garbage Collector) stands out as a modern, low-latency garbage collector designed to handle large heaps with minimal pauses. Introduced in JDK 11, ZGC aims to provide excellent responsiveness and scalability for applications with large memory requirements. This document provides an overview of ZGC, explaining how it works, and explores its advantages and limitations.

### What is ZGC and How is it Used?

ZGC is a garbage collector specifically designed for large heaps, typically ranging from a few gigabytes to several terabytes. It focuses on minimizing the impact of garbage collection pauses, making it suitable for latency-sensitive applications. ZGC is intended to be used in scenarios where applications require consistent response times and have stringent latency requirements.

### How Does ZGC Work?

At a high level, ZGC employs a concurrent garbage collection approach, meaning it performs garbage collection concurrently with the application’s execution. This concurrent process avoids long pauses that can disrupt application responsiveness. ZGC divides the heap into fixed-size regions and concurrently identifies and relocates live objects while the application continues to run. The key steps involved in the ZGC algorithm are as follows:

1.  Initial Marking: ZGC starts by identifying the root objects and marking them as live. This phase is performed quickly and involves minimal impact on application execution.
2.  Concurrent Marking: After the initial marking, ZGC performs a concurrent marking phase to identify additional live objects. This marking process is carried out alongside the application’s execution, ensuring minimal impact on latency.
3.  Remark: Once the concurrent marking phase is completed, ZGC performs a short stop-the-world remark phase to capture any objects that may have been modified during the concurrent marking process.
4.  Concurrent Relocation: In this phase, ZGC relocates live objects to new regions of memory to free up fragmented memory. The relocation process is done concurrently with the application, ensuring minimal impact on responsiveness.
5.  Final Marking: ZGC performs a final marking phase to identify any objects that were missed during the concurrent marking and relocation phases. This step helps ensure the consistency of the garbage collection process.
6.  Reference Processing: ZGC handles reference processing concurrently to keep track of live objects and facilitate their relocation.

### Pros of Using ZGC:

-   Low Latency: ZGC is specifically designed to minimize garbage collection pauses, resulting in low latency and consistent application responsiveness.
-   Scalability: ZGC is capable of efficiently handling large heaps, making it suitable for applications with substantial memory requirements.
-   Concurrent Execution: The concurrent garbage collection approach allows ZGC to perform collection work simultaneously with application execution, reducing the impact on throughput.

### Cons of Using ZGC:

-   Overhead: Like any garbage collector, ZGC incurs some overhead due to the concurrent marking and relocation processes. This overhead can be noticeable in certain scenarios.
-   Limited Platforms: Currently, ZGC is only supported on certain platforms, such as Linux x64 and Linux ARM64.

### Conclusion

ZGC is a cutting-edge garbage collector for Java that addresses the challenges of managing large heaps with minimal latency impact. Its concurrent approach to garbage collection allows it to provide low-pause times, making it suitable for latency-sensitive applications. While it has some limitations and platform restrictions, ZGC’s performance benefits and scalability make it a compelling choice for modern Java applications with stringent latency requirements.

![](https://miro.medium.com/v2/resize:fit:875/1*6I9qvl5PLk5DOHtZ6TzGIg.png)

### Shenandoah GC

Shenandoah GC is a garbage collector designed for a low-pause time in Java applications. It is an open-source garbage collector that aims to reduce the impact of garbage collection on application responsiveness. Shenandoah GC is available as an experimental feature in OpenJDK 8 and 11 and as a production feature starting from OpenJDK 12.

### Usage and Benefits

Shenandoah GC is primarily used in applications that require low latency and consistent pause times. It is suitable for applications with large heaps and stringent response time requirements. By minimizing pause times, Shenandoah GC enables applications to maintain high throughput and responsiveness even under high load.

### How Shenandoah GC Works

Shenandoah GC employs a unique approach called concurrent evacuation. Unlike traditional garbage collectors that halt the application to perform garbage collection, Shenandoah GC works concurrently with the application threads. It allows the application to continue running while the garbage collector performs its tasks, resulting in significantly shorter pause times.

Here’s a simplified explanation of how Shenandoah GC works:

1.  Initial Mark: Shenandoah GC starts by scanning the root objects and marking them as live. This initial marking phase is done with a pause, but it is typically very short.
2.  Concurrent Mark: While the application is running, Shenandoah GC continues marking live objects concurrently. It traces object graphs and identifies all reachable objects in the heap.
3.  Concurrent Evacuation: After marking, Shenandoah GC proceeds with the evacuation phase. It identifies regions in the heap that contain garbage and reclaims them. Meanwhile, it also copies live objects to new regions.
4.  Update References: During the evacuation phase, Shenandoah GC updates references to the newly copied objects. It ensures that the application’s references point to the correct memory locations.
5.  Final Mark: Shenandoah GC performs a final marking phase to identify any objects that have become live during the concurrent phases. This phase involves a short pause.
6.  Cleanup: Finally, Shenandoah GC cleans up the remaining garbage and frees up memory.

### Pros of using Shenandoah GC:

-   Low pause times: Shenandoah GC reduces pause times significantly, resulting in improved application responsiveness and reduced latency.
-   Scalability: It performs well with large heap sizes and can handle applications with substantial memory requirements.
-   Concurrent execution: Shenandoah GC works concurrently with the application threads, allowing the application to continue running with minimal interruptions.

### Cons of using Shenandoah GC:

-   Increased CPU overhead: Shenandoah GC may introduce additional CPU overhead compared to other garbage collectors due to its concurrent execution.
-   Young generation collection: Shenandoah GC focuses on the older generation, so it relies on a separate collector for the young generation, which may lead to some overhead.

### Conclusion:

Shenandoah GC is a valuable option for applications that require low latency and consistent pause times. By employing concurrent evacuation, it significantly reduces pause times and improves application responsiveness. However, it’s important to consider the specific characteristics of your application and evaluate the trade-offs, such as increased CPU overhead, before deciding to use Shenandoah GC. Conducting performance testing and analysis on your specific workload will help determine if Shenandoah GC is the right choice for your application.

![](https://miro.medium.com/v2/resize:fit:875/1*00lxqcYc3R11xPHPBxLs3g.png)

### Epsilon GC

Epsilon GC is a special-purpose garbage collector introduced in JDK 11. It is designed for specific use cases where garbage collection is not required or can be completely eliminated. Epsilon GC is an experimental feature that serves as a “no-op” garbage collector, meaning it does not perform any garbage collection activities. It is primarily used for performance testing, short-lived applications, or situations where the application manages memory explicitly.

### Usage and Benefits:

Epsilon GC is used in scenarios where the application has a short lifespan or does not produce significant garbage. It is particularly useful in performance testing environments to measure the baseline performance of an application without any garbage collection overhead. By eliminating garbage collection entirely, Epsilon GC can provide insights into the true performance characteristics of an application and help identify potential bottlenecks unrelated to garbage collection.

### How Epsilon GC Works:

Epsilon GC works in a straightforward manner. It is a “no-op” garbage collector, which means it does not perform any garbage collection activities. It allows objects to be allocated in memory without tracking their lifetime or performing any cleanup. As a result, memory allocations occur rapidly without any overhead associated with garbage collection.

### Pros of using Epsilon GC:

1.  Performance testing: Epsilon GC is ideal for performance testing environments where garbage collection overhead needs to be eliminated. It provides a baseline measurement of an application’s performance without any interference from garbage collection activities.
2.  Short-lived applications: Applications that have a short lifespan and produce minimal garbage can benefit from using Epsilon GC. Since no garbage collection is performed, it avoids unnecessary overhead and allows the application to run with maximum efficiency.
3.  Memory management control: Epsilon GC allows developers to have complete control over memory management. It enables explicit memory allocation and deallocation, which can be advantageous in certain specialized applications.

### Cons of using Epsilon GC:

1.  Memory leaks: Since Epsilon GC does not perform garbage collection, it does not reclaim memory allocated to objects. If an application has memory leaks or excessive memory usage, Epsilon GC will not free up memory automatically, leading to potential out-of-memory errors.
2.  Limited use cases: Epsilon GC is not suitable for long-running applications or applications that generate a significant amount of garbage. It lacks the ability to reclaim memory and can result in memory exhaustion if not used appropriately.
3.  Lack of runtime optimization: Epsilon GC does not provide any runtime optimizations or adaptive behaviors commonly found in other garbage collectors. It does not dynamically adjust its behavior based on the application’s memory usage patterns.

### Conclusion:

Epsilon GC serves as a specialized garbage collector for specific use cases where garbage collection is not required or can be completely eliminated. It is primarily used for performance testing, short-lived applications, or situations where explicit memory management is preferred. While Epsilon GC eliminates garbage collection overhead, it is important to consider the limitations and potential memory management challenges associated with its use. Careful analysis and consideration of the application’s memory requirements and usage patterns are necessary to determine if Epsilon GC is suitable for a given scenario.

![](https://miro.medium.com/v2/resize:fit:875/1*w1Q0OXyUjKWhHVxadbNKmg.png)

### Azul C4 GC

Azul C4 GC, also known as the Continuously Concurrent Compacting Collector, is a garbage collector designed for high-performance Java applications. It is developed and provided by Azul Systems, a company specializing in Java runtime technologies. Azul C4 GC aims to minimize pause times, improve throughput, and provide predictable performance for applications with large heaps and high memory requirements.

### Usage and Benefits:

Azul C4 GC is particularly useful for applications that require low latency and consistent performance. It is commonly used in latency-sensitive industries such as financial services, e-commerce, and gaming, where even small pauses in application execution can have a significant impact. The main advantages of using Azul C4 GC include reduced pause times, improved application throughput, and enhanced scalability.

### How Azul C4 GC Works:

Azul C4 GC employs a unique algorithm that enables it to perform garbage collection concurrently with the application’s execution. It works in the following steps:

1.  Initial marking: Azul C4 GC starts by identifying the live objects in the heap, marking them as live, and recording their references.
2.  Concurrent marking: While the application continues to run, Azul C4 GC concurrently traces object references and updates the marking information. This allows it to keep track of live objects without requiring a stop-the-world pause.
3.  Remark phase: Once the concurrent marking is complete, Azul C4 GC performs a remark phase to handle any changes in the object graph that may have occurred during the concurrent marking phase.
4.  Concurrent relocation: Azul C4 GC then proceeds to relocate live objects in the heap, compacting them to eliminate fragmentation and improve memory locality. This relocation process is performed concurrently with the application, minimizing pause times.
5.  Final remark: After the concurrent relocation, Azul C4 GC performs a final remark to capture any additional changes to the object graph.

### Pros of using Azul C4 GC:

1.  Low pause times: Azul C4 GC minimizes pause times by performing most of the garbage collection work concurrently with the application’s execution. This results in improved application responsiveness and reduced impact on user experience.
2.  Predictable performance: Azul C4 GC provides predictable performance characteristics, ensuring consistent application behavior even under high load and memory pressure. It aims to deliver consistent response times and throughput, crucial for latency-sensitive applications.
3.  Scalability: Azul C4 GC is designed to handle large heaps and high memory requirements efficiently. It can scale effectively to accommodate applications with substantial memory footprints, allowing them to operate smoothly without significant pauses.

### Cons of using Azul C4 GC:

1.  Third-party dependency: As Azul C4 GC is a proprietary solution provided by Azul Systems, it introduces a dependency on a specific vendor. This can limit the portability of the application and tie it to Azul Systems’ runtime environment.
2.  Potential licensing costs: Depending on the specific usage and licensing terms, there may be associated costs for using Azul C4 GC. It is important to consider the licensing implications when evaluating the feasibility of adopting this garbage collector.
3.  Configuration complexity: Configuring Azul C4 GC optimally for a specific application may require expertise and understanding of the underlying algorithms. The complexity of tuning the collector to achieve optimal performance can be a challenge for developers.

### Conclusion:

Azul C4 GC offers a compelling solution for applications that demand low latency, consistent performance, and efficient memory management. Its concurrent garbage collection algorithm minimizes pause times and provides predictable behavior, making it suitable for latency-sensitive industries. However, it is essential to consider vendor dependency, potential licensing costs, and the need for expert configuration when deciding to use Azul C4 GC in a Java application. Proper evaluation and understanding of the specific requirements.

![](https://miro.medium.com/v2/resize:fit:875/1*W3BDRNM0Wacdp8trrO_zPA.png)

### IBM Metronome GC

IBM Metronome GC is a real-time garbage collector designed for Java applications that require strict determinism and low pause times. It is developed by IBM and focuses on providing predictable execution in real-time and embedded systems. Metronome GC is suitable for applications where meeting strict timing requirements is critical, such as robotics, avionics, and industrial control systems.

### Usage and Benefits:

IBM Metronome GC is specifically designed for real-time applications that require deterministic behavior and minimal pause times. It offers several benefits, including:

1.  Deterministic execution: Metronome GC guarantees predictable execution, ensuring that an application meets its timing requirements consistently. This is crucial in real-time systems where precise timing is essential for correct functionality.
2.  Low pause times: The collector aims to minimize pause times by utilizing a concurrent and incremental garbage collection approach. It strives to keep application pauses short and predictable, allowing for smoother execution and responsiveness.
3.  Real-time system support: Metronome GC is tailored for real-time and embedded systems, providing reliable and predictable behavior in environments with strict timing constraints.

### How IBM Metronome GC Works:

Metronome GC operates on the principle of incremental and concurrent garbage collection. It follows these key steps:

1.  Initial marking: The collector starts by identifying live objects by traversing the object graph, marking them as live, and recording their references.
2.  Concurrent marking: While the application continues to execute, Metronome GC performs concurrent marking, tracing object references and updating the marking information. This process ensures the accurate identification of live objects without requiring a stop-the-world pause.
3.  Incremental relocation: Once the concurrent marking phase is complete, Metronome GC performs an incremental relocation of live objects. It relocates a portion of objects at a time during application execution to minimize pause times. This process is repeated incrementally until all live objects are relocated.
4.  Reference updates: During relocation, Metronome GC updates object references to reflect the new object locations accurately. This step ensures that the application can access relocated objects correctly.
5.  Collection completion: After all live objects are relocated, the garbage collector finalizes the relocation process and frees memory occupied by unreachable objects. This allows the application to utilize memory more efficiently.

### Pros of using IBM Metronome GC:

1.  Deterministic execution: Metronome GC guarantees predictable execution and adherence to strict timing requirements. It is well-suited for applications where consistent timing is critical for correct functioning.
2.  Low pause times: The collector aims to keep pause times minimal, ensuring that the application remains responsive and meets its real-time requirements.
3.  Real-time system support: Metronome GC is specifically designed for real-time and embedded systems, providing reliable and predictable behavior in such environments.

### Cons of using IBM Metronome GC:

1.  Specialized use case: Metronome GC is primarily intended for real-time systems with strict timing constraints. It may not be suitable or provide significant advantages for general-purpose applications that do not require deterministic behavior.
2.  Potential complexity: Configuring and fine-tuning Metronome GC for optimal performance may require specialized knowledge and expertise. Developers need to have a deep understanding of real-time systems and the collector’s intricacies.
3.  Limited ecosystem support: As a specialized garbage collector, the ecosystem and tooling support for Metronome GC may be relatively limited compared to mainstream collectors like the ones provided by OpenJDK or Oracle.

### Conclusion:

IBM Metronome GC offers deterministic execution and low pause times, making it suitable for real-time and embedded systems with strict timing requirements. It guarantees predictable behavior, ensuring consistent application performance. However, it is essential to consider the specialized nature of Metronome GC and the associated complexity in configuration and ecosystem support.

![](https://miro.medium.com/v2/resize:fit:875/1*JvP0tbnrbQb5x62Kfd2AqQ.png)

### SAP GC

SAP Garbage Collector (GC) is a custom garbage collector developed by SAP for use with the SAP JVM (Java Virtual Machine). It is designed to optimize memory management and garbage collection for SAP applications running on the SAP NetWeaver platform. SAP GC aims to improve application performance and scalability by efficiently managing memory and reducing pause times.

### Usage and Benefits:

SAP GC is specifically tailored for SAP applications, which are often large-scale enterprise systems that handle extensive data and user loads. It offers several benefits, including:

1.  Memory efficiency: SAP GC optimizes memory management by minimizing memory footprint and reducing unnecessary object allocations. This helps improve overall memory efficiency and reduces the risk of memory-related issues.
2.  Reduced pause times: The collector is designed to minimize pause times during garbage collection. By employing concurrent and incremental collection techniques, SAP GC aims to keep pauses short and predictable, enabling applications to remain responsive and maintain consistent performance.
3.  Scalability: SAP GC is optimized for scalability, allowing SAP applications to handle large data volumes and user loads effectively. It ensures efficient memory management even under high workloads, enabling applications to scale smoothly.

### How SAP GC Works:

SAP GC utilizes a combination of generational and concurrent garbage collection techniques to manage memory efficiently. Here’s an overview of its functioning in layman's terms:

1.  Generational collection: SAP GC divides the heap into generations based on the age of objects. Younger objects are allocated in the young generation, while longer-lived objects are moved to the old generation. The young generation undergoes more frequent garbage collection, while the old generation is collected less frequently.
2.  Concurrent collection: SAP GC performs concurrent garbage collection alongside the application’s execution. While the application continues to run, the collector identifies and marks live objects, ensuring that they are not mistakenly treated as garbage. This concurrent marking reduces the impact on application responsiveness.
3.  Incremental collection: To minimize pause times, SAP GC performs garbage collection incrementally. It divides the collection process into small units and interleaves garbage collection with application execution. This approach allows the collector to spread the work over multiple short pauses, ensuring that the pauses do not significantly impact application performance.
4.  Compaction: During garbage collection, SAP GC compacts the memory space by rearranging live objects, eliminating fragmentation, and improving memory locality. Compaction reduces the memory footprint and improves the efficiency of memory access.

### Pros of using SAP GC:

1.  Memory efficiency: SAP GC optimizes memory usage, reducing the memory footprint of SAP applications. This results in better overall performance and resource utilization.
2.  Reduced pause times: The concurrent and incremental collection techniques employed by SAP GC minimize pause times during garbage collection. This enables applications to maintain responsiveness and provide consistent performance.
3.  Scalability: SAP GC is designed to handle large-scale enterprise applications with high data volumes and user loads. It ensures efficient memory management, allowing applications to scale effectively.

### Cons of using SAP GC:

1.  Limited to SAP applications: SAP GC is specifically designed for SAP applications running on the SAP NetWeaver platform. It may not provide significant advantages or be applicable to general-purpose Java applications outside the SAP ecosystem.
2.  Vendor dependency: SAP GC is developed and maintained by SAP, which introduces a vendor dependency. Applications using SAP GC may need to rely on SAP’s JVM and runtime environment.
3.  Ecosystem support: The availability of tools, documentation, and community support for SAP GC may be more limited compared to mainstream garbage collectors.

### Conclusion:

SAP GC is a custom garbage collector designed for SAP applications, aiming to optimize memory management, reduce pause times, and improve scalability. It offers memory efficiency, reduced pauses, and scalability benefits specifically tailored to SAP enterprise systems. However, its usage is limited to SAP applications, and it introduces a dependency on SAP’s JVM and runtime environment. It is crucial to consider the specific requirements and compatibility with the SAP ecosystem before opting for SAP GC in a Java application.

![](https://miro.medium.com/v2/resize:fit:875/1*pejtNmOlvm5JYr25QJhKoA.png)

### Conclusion

In conclusion, we have examined several popular garbage collectors in the Java ecosystem, including Serial GC, Parallel GC, CMS GC, G1 GC, ZGC, Shenandoah GC, Epsilon GC, Azul C4 GC, IBM Metronome GC, and SAP GC. Each garbage collector has its own strengths and weaknesses, making them suitable for different scenarios and application requirements.

Here is a summary of the key points from the comparison:

-   Serial GC: Suitable for small applications with limited resources and low pause time requirements. It operates using a single thread, which can limit scalability and performance.
-   Parallel GC: Designed for multi-core systems, providing improved throughput and reduced garbage collection times. It is well-suited for applications with high computational loads.
-   CMS GC: Known for its low-latency garbage collection, making it suitable for applications that prioritize responsiveness and have large heap sizes. However, it can introduce fragmentation and may have higher overall CPU usage.
-   G1 GC: Provides a balance between throughput and latency by dividing the heap into smaller regions. It is well-suited for large applications with dynamic memory requirements and can adapt to changing workloads.
-   ZGC: Offers ultra-low pause times by performing concurrent garbage collection, making it suitable for applications with strict latency requirements. It can handle large heap sizes efficiently but may have a higher CPU overhead.
-   Shenandoah GC: Designed to minimize pause times and provide predictable latencies, making it suitable for large applications with strict latency requirements. It operates concurrently and uses region-based garbage collection.
-   Epsilon GC: Primarily used for performance testing and troubleshooting, as it does not perform any garbage collection. It is not suitable for production environments.
-   Azul C4 GC: Offers low and predictable pause times, making it suitable for applications with strict latency requirements. It utilizes a concurrent and compacting garbage collection algorithm.
-   IBM Metronome GC: A research-based garbage collector designed for real-time and deterministic applications, providing predictable and short pause times.
-   SAP GC: Tailored specifically for SAP applications, it optimizes memory usage, reduces pause times, and improves scalability within the SAP ecosystem.
---

# Mastering Java Synchronization

Hello All, In continuation to the series of my core java interview questions, today I’m sharing synchronization related questions that can help you ace your technical interviews.

I’ve made it easy for you to refer interview questions as per the topics(Core Java, Microservices, Spring Boot, Design Patterns, AWS, etc.) and prepared lists below.

[https://medium.com/@mpavani667/list/reading-list](https://medium.com/@letslearnnow/list/reading-list)

###### What happens if a thread tries to acquire a lock on an object that is already locked?

If a thread tries to acquire a lock on an object that is already locked by another thread, it **enters the blocked state** and waits until the lock is released. If it’s a **fair lock**, it will acquire the lock in FIFO order. If it’s an **unfair lock**, the OS scheduler decides.

**Example:**
```java
class SharedResource {  
    synchronized void method() {  
        System.out.println(Thread.currentThread().getName() + " is executing...");  
        try { Thread.sleep(3000); } catch (InterruptedException e) { e.printStackTrace(); }  
        System.out.println(Thread.currentThread().getName() + " has finished.");  
    }  
}  
public class SyncExample {  
    public static void main(String[] args) {  
        SharedResource obj = new SharedResource();  
        Thread t1 = new Thread(obj::method, "Thread-1");  
        Thread t2 = new Thread(obj::method, "Thread-2");  
        t1.start();  
        t2.start();  
    }  
}
```
### Output

Thread-1 is executing...  
(Thread-2 is blocked)  
Thread-1 has finished.  
Thread-2 is executing...  
Thread-2 has finished.

**Explanation:** `Thread-2` waits for `Thread-1` to release the lock.

### Can two threads execute two different synchronized methods of the same object simultaneously?

**No**, because when a method is synchronized, it locks the entire object (`this`). So even if two different synchronized methods are called, they both require the same object's lock.

**Example:**
```java
class Shared {  
    synchronized void method1() {   
        System.out.println("Method1 - " + Thread.currentThread().getName());   
        try { Thread.sleep(2000); } catch (InterruptedException ignored) {}  
    }  
synchronized void method2() {   
        System.out.println("Method2 - " + Thread.currentThread().getName());   
    }  
}  
public class SyncDemo {  
    public static void main(String[] args) {  
        Shared obj = new Shared();  
        new Thread(obj::method1, "T1").start();  
        new Thread(obj::method2, "T2").start();  
    }  
}
```
### Output:

Method1 - T1    
(T2 waits)    
Method2 - T2

**Explanation:** Both methods require the same object’s lock, so `T2` has to wait.

### Can two threads execute two synchronized methods of different objects of the same class simultaneously?

**Yes**, because each object has its own lock. Synchronization is at the **object level, not class level** unless the method is `static synchronized`.

**Example:**
```java
class Shared {  
    synchronized void method() {  
        System.out.println(Thread.currentThread().getName() + " is executing...");  
        try { Thread.sleep(2000); } catch (InterruptedException ignored) {}  
    }  
}  
public class SyncDemo {  
    public static void main(String[] args) {  
        Shared obj1 = new Shared();  
        Shared obj2 = new Shared();  
        new Thread(obj1::method, "T1").start();  
        new Thread(obj2::method, "T2").start();  
    }  
}
```

### Output:

T1 is executing...  
T2 is executing...

**Explanation:** Since `obj1` and `obj2` are different objects, they have separate locks.

### What happens if a synchronized method calls another synchronized method on the same object?

It **works without deadlock** because the thread already holds the lock, and Java allows **reentrant locks**.

**Example:**
```java
class ReentrantLockDemo {  
    synchronized void method1() {  
        System.out.println("Inside method1");  
        method2(); // Allowed, no deadlock  
    }  
synchronized void method2() {  
        System.out.println("Inside method2");  
    }  
}  
public class Main {  
    public static void main(String[] args) {  
        ReentrantLockDemo obj = new ReentrantLockDemo();  
        new Thread(obj::method1).start();  
    }  
}
```
### Output:

Inside method1    
Inside method2

**Explanation:** Since the same thread owns the lock, it can call `method2()` without waiting.

### Can we use `synchronized` with a static method?

Yes, when we synchronize a **static method**, it locks the **class-level lock**, not the object lock.

**Example:**
```java
class StaticSync {  
    static synchronized void staticMethod() {  
        System.out.println(Thread.currentThread().getName() + " is executing...");  
        try { Thread.sleep(2000); } catch (InterruptedException ignored) {}  
    }  
}  
public class Main {  
    public static void main(String[] args) {  
        new Thread(StaticSync::staticMethod, "T1").start();  
        new Thread(StaticSync::staticMethod, "T2").start();  
    }  
}
```
### Output:

T1 is executing...  
(T2 waits)  
T2 is executing...

**Explanation:** The lock is on `StaticSync.class`, so only one thread can execute at a time.

### What is the difference between using `synchronized` and using `ReentrantLock`?

![](https://miro.medium.com/v2/resize:fit:875/1*whAXmNEXsILmpitWDW3UGQ.png)

**Example Using ReentrantLock**
```java
import java.util.concurrent.locks.ReentrantLock;  
class SharedResource {  
    private final ReentrantLock lock = new ReentrantLock();  
        void method() {  
        if (lock.tryLock()) {  
            try {  
                System.out.println(Thread.currentThread().getName() + " acquired the lock.");  
                Thread.sleep(2000);  
            } catch (InterruptedException ignored) {}  
            finally { lock.unlock(); }  
        } else {  
            System.out.println(Thread.currentThread().getName() +
            " could not acquire the lock.");  
        }  
    }  
}  
public class ReentrantLockExample {  
    public static void main(String[] args) {  
        SharedResource obj = new SharedResource();  
        new Thread(obj::method, "T1").start();  
        new Thread(obj::method, "T2").start();  
    }  
}
```

### Output (Non-Deterministic)

T1 acquired the lock.  
T2 could not acquire the lock.

**Explanation:** `tryLock()` allows a thread to skip waiting if the lock is already taken.

### Can we apply `synchronized` on a constructor?

No, constructors **cannot** be synchronized because locking applies to objects, and the object is not fully constructed yet. However, we can synchronize the code inside the constructor using a different object’s lock.

**Example Workaround:**
```java
class Example {  
    private static final Object lock = new Object();  
    Example() {  
        synchronized (lock) {  
            System.out.println("Thread " +
            Thread.currentThread().getName() + " is in constructor.");  
        }  
    }  
}
```
Hope you all liked the content. Clap if you like this and follow me for more interesting content .It will be great if you show your love and encouragement.