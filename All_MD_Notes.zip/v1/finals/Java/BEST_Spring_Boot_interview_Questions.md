
### Q 1. How do you optimize the startup time of a Spring Boot application in a production environment?

Spring Boot provides various options for optimizing startup time. Key strategies include:

-   **Lazy Initialization**: Use `spring.main.lazy-initialization=true` to delay bean initialization until needed.
-   **Profile-Specific Configuration**: Separate configurations per environment to avoid unnecessary loading.
-   **Component Scanning**: Restrict the scope of component scanning using `@ComponentScan` to only include essential packages.
-   **Reduce Bean Creation**: Avoid creating unnecessary beans during startup, especially for time-intensive services.

By reducing the number of beans initialized upfront, you can significantly speed up application startup.

### Q 2. Explain the concept of Spring Boot’s `@ConfigurationProperties` with complex objects. How would you handle nested configurations?

The `@ConfigurationProperties` annotation is a powerful way to map external configuration properties into Java objects. For complex, nested configurations, Spring Boot can handle hierarchical properties through nested classes.
```java
@ConfigurationProperties(prefix = "app")  
public class AppConfig {  
    private Database database;  
    private List<Service> services;  
  
    public static class Database {  
        private String url;  
        private String username;  
        private String password;  
    }  
  
    public static class Service {  
        private String name;  
        private int timeout;  
    }  
}
```

This approach cleanly binds configuration files to Java objects, allowing for easy management of complex properties.

### Q 3. What are the main challenges with distributed tracing in Spring Boot microservices, and how do you implement it?

Distributed tracing allows tracking requests across multiple microservices. The challenges include latency, proper correlation of requests, and aggregating trace data across services.

**Solution**:

-   **Spring Cloud Sleuth**: Automatically instruments Spring Boot applications for distributed tracing.
-   **Integration with Zipkin or Jaeger**: Use Sleuth with tools like Zipkin for trace visualization and monitoring.
-   **Correlation**: Propagate `TraceId` and `SpanId` headers for cross-service correlation, ensuring traceability.

By adopting distributed tracing, you can gain deeper visibility into service communication and identify performance bottlenecks.

### Q 4. How would you implement a robust custom health check in Spring Boot for a production environment?

Spring Boot’s `Actuator` allows creating custom health checks for monitoring application health. Implementing a custom `HealthIndicator` ensures that you can check specific resources like databases, external services, or file systems.
```java
@Component  
public class MyCustomHealthIndicator extends AbstractHealthIndicator {  
    @Override  
    protected void doHealthCheck(Health.Builder builder) throws Exception {  
        boolean isHealthy = checkDatabaseConnection();  
        if (isHealthy) {  
            builder.up().withDetail("Database", "Available");  
        } else {  
            builder.down().withDetail("Database", "Not Available");  
        }  
    }  
}
```

Custom health indicators help ensure that all critical dependencies are monitored, improving the system’s reliability.

### Q 5. How do you handle service discovery in a Spring Boot microservices architecture?

Service discovery is essential for managing dynamic microservices instances. **Eureka** from Spring Cloud is widely used for service registration and discovery.

-   **Spring Cloud Eureka**: Enable `@EnableEurekaClient` to register services with Eureka, making it easy to discover and interact with microservices dynamically.
-   **Load Balancing**: Use Spring Cloud Load Balancer or Ribbon for client-side load balancing.

With service discovery in place, the system can dynamically handle changes in service availability without requiring manual configuration updates.

### Q 6. What is Spring Boot’s `@Retryable` annotation, and how do you fine-tune it for microservices reliability?

The `@Retryable` annotation in Spring Boot allows retrying a method call in case of failure. This is essential for improving the reliability of services that might experience transient failures (e.g., network timeouts or database issues).
```java
@Retryable(value = {IOException.class}, maxAttempts = 5, backoff = @Backoff(delay = 2000))  
public String fetchData() {  
    // API call that might fail  
}
```

You can fine-tune retries with exponential backoff and conditional retries, helping reduce cascading failures in a distributed system.

### Q 7. How can you implement and manage custom security policies in Spring Boot for fine-grained access control?

Spring Security provides robust mechanisms to implement fine-grained access control in your application. You can use annotations like `@PreAuthorize`, `@Secured`, and `@RolesAllowed` to secure methods at the business logic level.
```java
@PreAuthorize("hasRole('ADMIN')")  
public String performAdminTask() {  
    return "Admin Task Completed";  
}
```

For custom authentication and authorization, you can extend `AuthenticationProvider` to integrate specific security protocols or external identity providers, ensuring tight control over who can access what within the application.

### Q 8. Explain how to implement event-driven microservices with Kafka or RabbitMQ in Spring Boot.

Event-driven architecture enables asynchronous communication between microservices, often powered by message brokers like Kafka or RabbitMQ.

-   **Kafka Integration**: Spring Kafka simplifies the production and consumption of Kafka messages with `@KafkaListener` annotations.
```java
@KafkaListener(topics = "myTopic", groupId = "group_id")  
public void listen(String message) {  
    System.out.println("Received Message: " + message);  
}
```

This approach facilitates loosely coupled services, enabling scalability and resilience in your microservices.

### Q 9. How do you handle versioning in Spring Boot APIs?

API versioning is crucial for maintaining backward compatibility as your services evolve. Common strategies include:

-   **URI Versioning**: `/api/v1/resource`
-   **Parameter Versioning**: `/api/resource?version=1`
-   **Header-based Versioning**: Through custom headers like `API-Version`.

Using these methods, you can ensure that both old and new clients can work seamlessly with your APIs.

### Q 10. How do you implement multi-tenancy in Spring Boot applications?

Multi-tenancy allows a single instance of an application to serve multiple tenants, each with its own data. This can be achieved via:

-   **Database-per-Tenant**: Use dynamic routing to select the correct database based on tenant information.
-   **Schema-per-Tenant**: Use a single database but separate schemas for each tenant.

You can implement multi-tenancy by dynamically changing the data source or schema at runtime based on the tenant context, typically extracted from the HTTP request headers or authentication token.

### Q 11. How would you implement a custom Spring Boot starter module?

Custom starters allow you to bundle a set of dependencies and configuration for easy reuse. A starter is essentially a Spring Boot auto-configuration class, along with the necessary dependencies.

1.  **Create the Auto-Configuration Class**: This class will contain the configuration logic for your starter.
2.  **Create the** `**META-INF/spring.factories**` **File**: Register your auto-configuration class here.
3.  **Package the Starter**: Package your starter as a JAR and share it with other applications.

Example of auto-configuration class:
```java
@Configuration  
@ConditionalOnClass(DataSource.class)  
public class MyStarterAutoConfiguration {  
    @Bean  
    public DataSource myDataSource() {  
        return new DriverManagerDataSource();  
    }  
}
```

### Q 12. How do you manage external configurations in a Spring Boot application across multiple environments?

Spring Boot allows you to manage external configurations with:

-   **Profiles**: Use `@Profile` to define beans for specific environments (e.g., `@Profile("prod")`).
-   **application.properties or YAML**: Use `application-prod.properties` for production-specific configurations.
-   **Spring Cloud Config**: For distributed systems, use Spring Cloud Config Server to manage configurations centrally.

Example:
```java
spring.datasource.url=jdbc:mysql://localhost:3306/mydb  
spring.profiles.active=prod
```
### Q 13. What are some strategies for debugging a Spring Boot application in production?

In production, use a combination of:

-   **Spring Boot Actuator**: Provides insights into health, metrics, and environment information.
-   **Logging**: Use structured logging with `SLF4J` or `Logback` for better traceability.
-   **Remote Debugging**: Enable remote debugging via the JVM by passing `-agentlib:jdwp` parameters.
-   **Heap Dumps & Thread Dumps**: Capture heap dumps and thread dumps during application issues.

### Q 14. How would you implement Spring Boot Security with OAuth 2.0 for a microservices-based system?

OAuth 2.0 provides authorization by using access tokens. For Spring Boot, you can use Spring Security OAuth2 for managing authentication.

-   **OAuth2 Authorization Server**: Use Spring Security OAuth to configure an OAuth2 Authorization Server for issuing tokens.
-   **OAuth2 Resource Server**: Use `@EnableResourceServer` to secure resources by validating incoming OAuth2 tokens.

Example:
```java
@Configuration  
@EnableOAuth2Sso  
public class OAuth2Config {  
    // Configuration for OAuth2 login  
}
```
### Q 15. What are some common performance bottlenecks in Spring Boot applications and how do you resolve them?

-   **Database Access**: Optimize queries, use pagination, and consider connection pooling (e.g., HikariCP).
-   **Memory Leaks**: Use tools like `VisualVM` to monitor memory usage and avoid memory leaks.
-   **Thread Pooling**: Properly size thread pools for handling HTTP requests and background tasks.
-   **Caching**: Use Spring’s caching abstraction (`@Cacheable`) to reduce the load on databases.

### Q 16. How do you handle asynchronous processing in Spring Boot?

Spring Boot supports asynchronous processing using:

-   **@Async Annotation**: This is used for executing methods asynchronously.
-   **Executor**: Use `Executor` beans to control the threading model for asynchronous tasks.

Example:
```java
@Async  
public CompletableFuture<String> processAsyncTask() {  
    // Long-running task  
    return CompletableFuture.completedFuture("Task completed");  
}
```

### Q 17. How would you implement caching in a Spring Boot application?

Spring Boot provides caching support through annotations like `@Cacheable`, `@CachePut`, and `@CacheEvict`.

1.  **Enable Caching**: Annotate your configuration class with `@EnableCaching`.
2.  **Define Cache Manager**: You can use `ConcurrentMapCacheManager` or integrate with external caches like Redis or Ehcache.

Example:
```java
@Cacheable("items")  
public List<Item> getItems() {  
    return itemRepository.findAll();  
}
```

### Q 18. How do you configure and manage Spring Boot logging in production?

Spring Boot provides flexible logging support via:

-   **Logback**: Default logging framework; use `logback-spring.xml` for configuration.
-   **External Logging**: Integrate with logging solutions like ELK (Elasticsearch, Logstash, Kibana) for centralizing logs.
-   **Log Levels**: Set different log levels per environment (e.g., `INFO` for production, `DEBUG` for development).

Example in `application.properties`:
```java
logging.level.org.springframework=DEBUG
```
### Q 19. How would you implement API Gateway using Spring Cloud Gateway in a Spring Boot-based microservices architecture?

Spring Cloud Gateway is a great tool for routing requests to various microservices and handling cross-cutting concerns like authentication, rate-limiting, and logging.

-   **Configure Routes**: Define routes that match URLs and forward requests to downstream services.
-   **Filters**: Use filters for custom logic, like authentication or request modification.

Example:
```java
@Bean  
public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {  
    return builder.routes()  
        .route(r -> r.path("/myService/**")  
            .uri("lb://MY-SERVICE")  
            .id("myServiceRoute"))  
        .build();  
}
```

### Q 20. How do you handle transactions in a Spring Boot application?

Spring Boot offers support for declarative transactions using `@Transactional` to manage transactions at the method level.

-   **Propagation**: You can define how a transaction behaves with `REQUIRES_NEW`, `REQUIRES_EXISTING`, etc.
-   **Isolation**: Set transaction isolation levels like `READ_COMMITTED` or `SERIALIZABLE` based on requirements.

Example:
```java
@Transactional(isolation = Isolation.READ_COMMITTED)  
public void transferFunds() {  
    // Logic for transferring funds  
}
```

### Q 21. What are the differences between @RequestMapping, @GetMapping, @PostMapping, etc., in Spring Boot?

-   **@RequestMapping**: A general-purpose annotation used to map HTTP requests to handler methods.
-   **@GetMapping**: Shortcut for `@RequestMapping(method = RequestMethod.GET)`.
-   **@PostMapping**: Shortcut for `@RequestMapping(method = RequestMethod.POST)`.

These specific annotations are used to simplify code and make it more readable.

### Q 22. How do you implement file upload and download functionality in Spring Boot?

Spring Boot provides simple mechanisms to handle file uploads using `@RequestParam` and `MultipartFile`.

-   **File Upload**: Use `MultipartFile` to handle file uploads.
-   **File Download**: Set the correct response headers to serve the file to the user.

Example for file upload:
```java
@PostMapping("/upload")  
public String handleFileUpload(@RequestParam("file") MultipartFile file) {  
    file.transferTo(new File("uploads/" + file.getOriginalFilename()));  
    return "File uploaded successfully!";  
}
```

### Q 23. What are Spring Boot profiles, and how do you manage different configurations for various environments?

Spring Boot profiles allow you to segregate parts of your application configuration and make it available only in certain environments.

-   **Activate Profiles**: Use `spring.profiles.active` to specify which profile is active.
-   **Profile-specific Configuration**: Define separate `application-{profile}.properties` or `application-{profile}.yml` files.

Example:
```java
spring.profiles.active=dev
```

### Q 24. How do you implement JWT-based authentication in Spring Boot?

JWT (JSON Web Token) is widely used for stateless authentication in microservices.

-   **Create JWT Tokens**: Use a custom filter to generate JWT tokens after authentication.
-   **Validate Tokens**: Use Spring Security filters to validate the JWT token with every request.

Example:
```java
public String generateToken(Authentication authentication) {  
    return Jwts.builder()  
        .setSubject(authentication.getName())  
        .setIssuedAt(new Date())  
        .setExpiration(new Date(System.currentTimeMillis() + JWT_EXPIRATION))  
        .signWith(SignatureAlgorithm.HS512, JWT_SECRET)  
        .compact();  
}
```

### Q 25. How do you configure and use Spring Boot with Docker for containerization?

Docker allows you to containerize your Spring Boot application for better portability.

1.  **Dockerfile**: Create a `Dockerfile` to define the build process.
2.  **Build and Run**: Use `docker build` and `docker run` to package and deploy your application.

Example Dockerfile:
```java
FROM openjdk:11-jre-slim  
COPY target/myapp.jar /app/myapp.jar  
ENTRYPOINT ["java", "-jar", "/app/myapp.jar"]
```
### Q 26. How do you implement rate-limiting in a Spring Boot application?

To protect your APIs from overuse, you can implement rate-limiting. This can be achieved using Spring Cloud Gateway or a custom implementation.

-   **Spring Cloud Gateway**: Use `RateLimiter` filter to limit the number of requests.
-   **Custom Implementation**: Use an in-memory store or Redis to track the number of requests per user.

Example:
```java
@Bean  
public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {  
    return builder.routes()  
        .route(r -> r.path("/api/**")  
            .filters(f -> f.requestRateLimiter()  
                .rateLimiter(RateLimiter.class)  
                .config(new RequestRateLimiter.Config(10, 20)))  
            .uri("http://myservice"))  
        .build();  
}
```
### Q 27. How do you implement a custom exception handler in Spring Boot?

Spring Boot provides global exception handling via `@ControllerAdvice`. You can customize exception handling for different scenarios.
```java
@ControllerAdvice  
public class GlobalExceptionHandler {  
  
    @ExceptionHandler(ResourceNotFoundException.class)  
    public ResponseEntity<ErrorResponse> handleResourceNotFound(ResourceNotFoundException ex) {  
        ErrorResponse errorResponse = new ErrorResponse(ex.getMessage(), HttpStatus.NOT_FOUND.value());  
        return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);  
    }  
}
```
### Q 28. How do you use Spring Boot’s `@Scheduled` annotation for background tasks?

Spring Boot provides the `@Scheduled` annotation to schedule tasks like cron jobs or fixed-delay tasks.
```java
@Scheduled(fixedRate = 5000)  
public void reportCurrentTime() {  
    System.out.println("Current time: " + System.currentTimeMillis());  
}
```

### Q 29. How do you implement Spring Boot with a NoSQL database like MongoDB or Cassandra?

Spring Boot makes it easy to integrate NoSQL databases using Spring Data.

-   **MongoDB**: Use `spring-boot-starter-data-mongodb` for MongoDB integration.
-   **Cassandra**: Use `spring-boot-starter-data-cassandra` for Cassandra integration.

Example with MongoDB:
```java
@EnableMongoRepositories  
public interface UserRepository extends MongoRepository<User, String> {  
    List<User> findByUsername(String username);  
}
```

### Q 30. How would you configure and use Spring Boot with a message queue like RabbitMQ or Kafka?

-   **RabbitMQ**: Use `spring-boot-starter-amqp` to integrate RabbitMQ into Spring Boot. Configure queues, exchanges, and listeners.

Example:
```java
@RabbitListener(queues = "myQueue")  
public void receiveMessage(String message) {  
    System.out.println("Received: " + message);  
}
```

### Q1. How does Spring Boot’s autoconfiguration work internally?

Spring Boot’s **autoconfiguration** works using:

-   `**@EnableAutoConfiguration**`: Enables Spring Boot to automatically configure beans based on the dependencies on the classpath.
-   **Spring Factories (**`**META-INF/spring.factories**`**)**: Lists various autoconfiguration classes which are loaded by `SpringFactoriesLoader`.
-   `**@ConditionalOnClass**`**,** `**@ConditionalOnProperty**`**,** `**@ConditionalOnMissingBean**` annotations control whether a bean should be registered.

👉 **Example:** Spring Boot will automatically configure a `DataSource` bean if it detects `spring-boot-starter-data-jpa` in the classpath and database properties in `application.properties`.

### Q2. What is the role of `META-INF/spring.factories` in Spring Boot?

Spring Boot loads auto-configuration classes from `META-INF/spring.factories` using `SpringFactoriesLoader`.

-   This file maps `EnableAutoConfiguration` to available configuration classes.
-   Example entry in `spring.factories`:
```shell
org.springframework.boot.autoconfigure.EnableAutoConfiguration=  
org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration,  
org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration
```
Developers can define custom auto-configuration by adding their own entries.

### Q3. How does Spring Boot handle dependency injection differently from Spring Framework?

-   Spring Boot simplifies dependency injection by eliminating XML configurations and using **component scanning** with annotations like `@Component`, `@Service`, and `@Repository`.
-   It provides **constructor-based injection** by default and discourages field injection.
-   **Primary and Qualifier Annotations:** Handles multiple beans using `@Primary` and `@Qualifier`.

### Q4. Explain the difference between `@SpringBootApplication`, `@Configuration`, `@ComponentScan`, and `@EnableAutoConfiguration`.

-   `**@SpringBootApplication**` = `@Configuration` + `@EnableAutoConfiguration` + `@ComponentScan` (combines them).
-   `**@Configuration**`: Marks a class as a source of bean definitions.
-   `**@ComponentScan**`: Scans for Spring components (beans) in specified packages.
-   `**@EnableAutoConfiguration**`: Enables auto-configuration based on dependencies.

### Q5. How does the Spring Boot application lifecycle work?

1.  **Application Context Initialization**: Creates and registers beans.
2.  **Bean Post-Processing**: `@PostConstruct` and `InitializingBean` methods are executed.
3.  **Context Refreshed**: Application is ready to serve requests.
4.  **Graceful Shutdown**: Executes `@PreDestroy` and `DisposableBean` methods.

### Q6. Explain the concept of Spring Boot’s `@ConfigurationProperties` with complex objects. How would you handle nested configurations?

The `@ConfigurationProperties` annotation in Spring Boot binds external configuration properties **(from application.yml or application.properties) to Java objects**. For complex, nested configurations, Spring Boot can handle hierarchical properties through nested classes.

### Enabling `@ConfigurationProperties :`

1.  **Enable** `**@ConfigurationProperties**` **Scanning (Spring Boot 2.2+)**

-   Add the annotation at the class level.
```java
@ConfigurationProperties(prefix = "app")  
@Component  
public class AppConfig {  
    private String name;  
    private DatabaseConfig database;  
      
    // Getters & Setters  
}
```

**2. Ensure Spring Boot Scans the Configuration Class**

-   **Option 1:** Annotate with `@Component` (Auto-registered in Spring Boot 2.2+).
-   **Option 2:** Register manually in `@Configuration` class:
```java
@Configuration   
@EnableConfigurationProperties(AppConfig.class)   
public class AppConfigLoader { }
```
### 3. Handling Nested Configurations (Complex Objects) :

When your configuration contains **nested properties**, `@ConfigurationProperties` automatically binds them into Java objects.

### Example YAML Configuration :
```yaml
app:  
  name: MyApplication  
  database:  
    url: jdbc:mysql://localhost:3306/mydb  
    username: root  
    password: secret  
    pool:  
      max-size: 50  
      min-size: 5
```
### Java Model with Nested Configuration :
```java
@ConfigurationProperties(prefix = "app")  
@Component  
public class AppConfig {  
    private String name;  
    private DatabaseConfig database;  
      
    // Getters & Setters  
}  
public class DatabaseConfig {  
    private String url;  
    private String username;  
    private String password;  
    private PoolConfig pool;  
    // Getters & Setters  
}  
public class PoolConfig {  
    private int maxSize;  
    private int minSize;  
    // Getters & Setters  
}
```
✅ **Spring Boot automatically binds YAML properties into these Java objects.**

### 4. Validating Configuration Properties :

You can **validate configurations** using **JSR-303 (Jakarta Bean Validation API)** with `@Valid` and constraint annotations.

### 1️⃣ Add Validation Annotations :
```java
import jakarta.validation.constraints.Min;  
import jakarta.validation.constraints.NotBlank;  
import org.springframework.validation.annotation.Validated;  
@ConfigurationProperties(prefix = "app")  
@Component  
@Validated  
public class AppConfig {  
    @NotBlank  
    private String name;  
    @Valid  
    private DatabaseConfig database;  
    // Getters & Setters  
}  
public class DatabaseConfig {  
    @NotBlank  
    private String url;  
    @NotBlank  
    private String username;  
    @NotBlank  
    private String password;  
    @Valid  
    private PoolConfig pool;  
    // Getters & Setters  
}  
public class PoolConfig {  
    @Min(1)  
    private int maxSize;  
    @Min(1)  
    private int minSize;  
    // Getters & Setters  
}
```

✅ Spring Boot will now throw an exception if any required property is missing or invalid.

### 5. Using ConfigurationProperties with `@ConstructorBinding` (Immutability)

Spring Boot **supports immutable configuration classes** using `@ConstructorBinding`.

### Example with Constructor Binding :
```java
@ConfigurationProperties(prefix = "app")  
@ConstructorBinding  
public class AppConfig {  
    private final String name;  
    private final DatabaseConfig database;  
    public AppConfig(String name, DatabaseConfig database) {  
        this.name = name;  
        this.database = database;  
    }  
    public String getName() { return name; }  
    public DatabaseConfig getDatabase() { return database; }  
}
```

✅ Better for immutability and thread safety (Fields are `final`).

This approach cleanly binds configuration files to Java objects, allowing for easy management of complex properties.

### Q7. How do you optimize the startup time of a Spring Boot application in a production environment?

Spring Boot applications can take time to start due to **dependency scanning, autoconfiguration, classpath loading, and database initialization**. Optimizing startup time is crucial for **cloud environments, Kubernetes scaling, and microservices resilience**. Spring Boot provides various options for optimizing startup time. Key strategies include:

-   **Lazy Initialization**: Use `spring.main.lazy-initialization=true` to delay bean initialization until needed.
-   **Profile-Specific Configuration**: Separate configurations per environment to avoid unnecessary loading.
-   **Component Scanning**: Restrict the scope of component scanning using `@ComponentScan` to only include essential packages.
-   **Reduce Bean Creation**: Avoid creating unnecessary beans during startup, especially for time-intensive services.

By reducing the number of beans initialized upfront, you can significantly speed up application startup.

### Q8. What are the main challenges with distributed tracing in Spring Boot microservices, and how do you implement it?

Distributed tracing allows tracking requests across multiple microservices. The challenges include latency, proper correlation of requests, and aggregating trace data across services.

**Solution**:

-   **Spring Cloud Sleuth**: Automatically instruments Spring Boot applications for distributed tracing.
-   **Integration with Zipkin or Jaeger**: Use Sleuth with tools like Zipkin for trace visualization and monitoring.
-   **Correlation**: Propagate `TraceId` and `SpanId` headers for cross-service correlation, ensuring traceability.

By adopting distributed tracing, you can gain deeper visibility into service communication and identify performance bottlenecks.

### Q9. How would you implement a robust custom health check in Spring Boot for a production environment?

Health checks in Spring Boot are handled by **Spring Boot Actuator**, which provides built-in and custom health indicators. A **robust custom health check** ensures that your application’s dependencies (databases, external services, caches, etc.) are working correctly. Implementing a custom `HealthIndicator` ensures that you can check specific resources like databases, external services, or file systems.
```java
@Component  
public class MyCustomHealthIndicator extends AbstractHealthIndicator {  
    @Override  
    protected void doHealthCheck(Health.Builder builder) throws Exception {  
        boolean isHealthy = checkDatabaseConnection();  
        if (isHealthy) {  
            builder.up().withDetail("Database", "Available");  
        } else {  
            builder.down().withDetail("Database", "Not Available");  
        }  
    }  
}
```

Custom health indicators help ensure that all critical dependencies are monitored, improving the system’s reliability.

### Q10. How do you handle service discovery in a Spring Boot microservices architecture?

Service discovery is essential for managing dynamic microservices instances. **Eureka** from Spring Cloud is widely used for service registration and discovery.

-   **Spring Cloud Eureka**: Enable `@EnableEurekaClient` to register services with Eureka, making it easy to discover and interact with microservices dynamically.
-   **Load Balancing**: Use Spring Cloud Load Balancer or Ribbon for client-side load balancing.

With service discovery in place, the system can dynamically handle changes in service availability without requiring manual configuration updates.

### Q11. What is Spring Boot’s `@Retryable` annotation, and how do you fine-tune it for microservices reliability?

The `@Retryable` annotation in Spring Boot (provided by **Spring Retry**) allows automatic retrying of failed operations due to transient faults, such as network failures, temporary service unavailability, or database timeouts.
```java
@Retryable(value = {IOException.class}, maxAttempts = 5, backoff = @Backoff(delay = 2000))  
public String fetchData() {  
    // API call that might fail  
}
```
### How `@Retryable` Works

-   It **automatically retries** a method when a specific exception occurs.

It allows configuring:

-   **Retry count (**`maxAttempts`**)**
-   **Delay between retries (**`backoff`**)**
-   **Specific exceptions** (`value` or `include`)
-   **Exclusion of exceptions** (`exclude`)

You can fine-tune retries with exponential backoff and conditional retries, helping reduce cascading failures in a distributed system.

### Q12. How can you implement and manage custom security policies in Spring Boot for fine-grained access control?

Spring Security provides robust mechanisms to implement fine-grained access control in your application. You can use annotations like `@PreAuthorize`, `@Secured`, and `@RolesAllowed` to secure methods at the business logic level.
```java
@PreAuthorize("hasRole('ADMIN')")  
public String performAdminTask() {  
    return "Admin Task Completed";  
}
```
For custom authentication and authorization, you can extend `AuthenticationProvider` to integrate specific security protocols or external identity providers, ensuring tight control over who can access what within the application.

### Q13. Explain how to implement event-driven microservices with Kafka or RabbitMQ in Spring Boot.

Event-driven architecture enables asynchronous communication between microservices, often powered by message brokers like Kafka or RabbitMQ.

-   **Kafka Integration**: Spring Kafka simplifies the production and consumption of Kafka messages with `@KafkaListener` annotations.
```java
@KafkaListener(topics = "myTopic", groupId = "group_id")  
public void listen(String message) {  
    System.out.println("Received Message: " + message);  
}
```
This approach facilitates loosely coupled services, enabling scalability and resilience in your microservices.

### Q14. How do you handle versioning in Spring Boot APIs?

API versioning is crucial for maintaining backward compatibility as your services evolve. Common strategies include:

-   **URI Versioning**: `/api/v1/resource`
-   **Parameter Versioning**: `/api/resource?version=1`
-   **Header-based Versioning**: Through custom headers like `API-Version`.

Using these methods, you can ensure that both old and new clients can work seamlessly with your APIs.

### Q15. How do you implement multi-tenancy in Spring Boot applications?

Multi-tenancy in Spring Boot refers to designing an application that serves multiple clients (tenants) while keeping their data separate. There are two main approaches:

1.  **Database per Tenant:** Each tenant has a separate database. Use dynamic routing to select the correct database based on tenant information.
2.  **Schema per Tenant:** A single database with different schemas for each tenant.
3.  **Table per Tenant:** A shared schema with a discriminator column to identify tenant records.

You can implement multi-tenancy by dynamically changing the data source or schema at runtime based on the tenant context, typically extracted from the HTTP request headers or authentication token.

### Q16. How would you implement a custom Spring Boot starter module?

Custom starters allow you to bundle a set of dependencies and configuration for easy reuse. A starter is essentially a Spring Boot auto-configuration class, along with the necessary dependencies.

1.  **Create the Auto-Configuration Class**: This class will contain the configuration logic for your starter.
2.  **Create the** `**META-INF/spring.factories**` **File**: Register your auto-configuration class here.
3.  **Package the Starter**: Package your starter as a JAR and share it with other applications.

Example of auto-configuration class:
```java
@Configuration  
@ConditionalOnClass(DataSource.class)  
public class MyStarterAutoConfiguration {  
    @Bean  
    public DataSource myDataSource() {  
        return new DriverManagerDataSource();  
    }  
}```

### Q17. How do you manage external configurations in a Spring Boot application across multiple environments?

Spring Boot allows you to manage external configurations with:

-   **Profiles**: Use `@Profile` to define beans for specific environments (e.g., `@Profile("prod")`).
-   **application.properties or YAML**: Use `application-prod.properties` for production-specific configurations.
-   **Spring Cloud Config**: For distributed systems, use Spring Cloud Config Server to manage configurations centrally.

Example:
```java
spring.datasource.url=jdbc:mysql://localhost:3306/mydb  
spring.profiles.active=prod
```
### Q18. What are some strategies for debugging a Spring Boot application in production?

In production, use a combination of:

-   **Spring Boot Actuator**: Provides insights into health, metrics, and environment information.
-   **Logging**: Use structured logging with `SLF4J` or `Logback` for better traceability.
-   **Remote Debugging**: Enable remote debugging via the JVM by passing `-agentlib:jdwp` parameters.
-   **Heap Dumps & Thread Dumps**: Capture heap dumps and thread dumps during application issues.

### Q19. How would you implement Spring Boot Security with OAuth 2.0 for a microservices-based system?

OAuth 2.0 provides authorization by using access tokens. For Spring Boot, you can use Spring Security OAuth2 for managing authentication.

-   **OAuth2 Authorization Server**: Use Spring Security OAuth to configure an OAuth2 Authorization Server for issuing tokens.
-   **OAuth2 Resource Server**: Use `@EnableResourceServer` to secure resources by validating incoming OAuth2 tokens.

Example:
```java
@Configuration  
@EnableOAuth2Sso  
public class OAuth2Config {  
    // Configuration for OAuth2 login  
}
```

### Q20. What are some common performance bottlenecks in Spring Boot applications and how do you resolve them?

-   **Database Access**: Optimize queries, use pagination, and consider connection pooling (e.g., HikariCP).
-   **Memory Leaks**: Use tools like `VisualVM` to monitor memory usage and avoid memory leaks.
-   **Thread Pooling**: Properly size thread pools for handling HTTP requests and background tasks.
-   **Caching**: Use Spring’s caching abstraction (`@Cacheable`) to reduce the load on databases.

### Q21. How do you handle asynchronous processing in Spring Boot?

Spring Boot supports asynchronous processing using:

-   **@Async Annotation**: This is used for executing methods asynchronously.
-   **Executor**: Use `Executor` beans to control the threading model for asynchronous tasks.

Example:
```java
@Async  
public CompletableFuture<String> processAsyncTask() {  
    // Long-running task  
    return CompletableFuture.completedFuture("Task completed");  
}
```

### Q22. How would you implement caching in a Spring Boot application?

Spring Boot provides caching support through annotations like `@Cacheable`, `@CachePut`, and `@CacheEvict`.

1.  **Enable Caching**: Annotate your configuration class with `@EnableCaching`.
2.  **Define Cache Manager**: You can use `ConcurrentMapCacheManager` or integrate with external caches like Redis or Ehcache.

Example:
```java
@Cacheable("items")  
public List<Item> getItems() {  
    return itemRepository.findAll();  
}
```

### Q23. How do you configure and manage Spring Boot logging in production?

Spring Boot provides flexible logging support via:

-   **Logback**: Default logging framework; use `logback-spring.xml` for configuration.
-   **External Logging**: Integrate with logging solutions like ELK (Elasticsearch, Logstash, Kibana) for centralizing logs.
-   **Log Levels**: Set different log levels per environment (e.g., `INFO` for production, `DEBUG` for development).

Example in `application.properties`:
```java
logging.level.org.springframework=DEBUG
```
### Q24. How would you implement API Gateway using Spring Cloud Gateway in a Spring Boot-based microservices architecture?

Spring Cloud Gateway is a great tool for routing requests to various microservices and handling cross-cutting concerns like authentication, rate-limiting, and logging.

-   **Configure Routes**: Define routes that match URLs and forward requests to downstream services.
-   **Filters**: Use filters for custom logic, like authentication or request modification.

Example:
```java
@Bean  
public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {  
    return builder.routes()  
        .route(r -> r.path("/myService/**")  
            .uri("lb://MY-SERVICE")  
            .id("myServiceRoute"))  
        .build();  
}
```

### Q25. How do you handle transactions in a Spring Boot application?

Spring Boot offers support for declarative transactions using `@Transactional` to manage transactions at the method level.

-   **Propagation**: You can define how a transaction behaves with `REQUIRES_NEW`, `REQUIRES_EXISTING`, etc.
-   **Isolation**: Set transaction isolation levels like `READ_COMMITTED` or `SERIALIZABLE` based on requirements.

Example:
```java
@Transactional(isolation = Isolation.READ_COMMITTED)  
public void transferFunds() {  
    // Logic for transferring funds  
}
```

### Q26. What are the differences between @RequestMapping, @GetMapping, @PostMapping, etc., in Spring Boot?

-   **@RequestMapping**: A general-purpose annotation used to map HTTP requests to handler methods.
-   **@GetMapping**: Shortcut for `@RequestMapping(method = RequestMethod.GET)`.
-   **@PostMapping**: Shortcut for `@RequestMapping(method = RequestMethod.POST)`.

These specific annotations are used to simplify code and make it more readable.

### Q27. How do you implement file upload and download functionality in Spring Boot?

Spring Boot provides simple mechanisms to handle file uploads using `@RequestParam` and `MultipartFile`.

-   **File Upload**: Use `MultipartFile` to handle file uploads.
-   **File Download**: Set the correct response headers to serve the file to the user.

Example for file upload:
```java
@PostMapping("/upload")  
public String handleFileUpload(@RequestParam("file") MultipartFile file) {  
    file.transferTo(new File("uploads/" + file.getOriginalFilename()));  
    return "File uploaded successfully!";  
}
```

### Q28. What are Spring Boot profiles, and how do you manage different configurations for various environments?

Spring Boot profiles allow you to segregate parts of your application configuration and make it available only in certain environments.

-   **Activate Profiles**: Use `spring.profiles.active` to specify which profile is active.
-   **Profile-specific Configuration**: Define separate `application-{profile}.properties` or `application-{profile}.yml` files.

Example:
```shell
spring.profiles.active=dev
```
### Q29. How do you implement JWT-based authentication in Spring Boot?

JWT (JSON Web Token) is widely used for stateless authentication in microservices.

-   **Create JWT Tokens**: Use a custom filter to generate JWT tokens after authentication.
-   **Validate Tokens**: Use Spring Security filters to validate the JWT token with every request.

Example:
```java
public String generateToken(Authentication authentication) {  
    return Jwts.builder()  
        .setSubject(authentication.getName())  
        .setIssuedAt(new Date())  
        .setExpiration(new Date(System.currentTimeMillis() + JWT_EXPIRATION))  
        .signWith(SignatureAlgorithm.HS512, JWT_SECRET)  
        .compact();  
}
```

### Q30. How do you configure and use Spring Boot with Docker for containerization?

Docker allows you to containerize your Spring Boot application for better portability.

1.  **Dockerfile**: Create a `Dockerfile` to define the build process.
2.  **Build and Run**: Use `docker build` and `docker run` to package and deploy your application.

Example Dockerfile:
```java
FROM openjdk:11-jre-slim  
COPY target/myapp.jar /app/myapp.jar  
ENTRYPOINT ["java", "-jar", "/app/myapp.jar"]
```
### Q31. How do you implement rate-limiting in a Spring Boot application?

To protect your APIs from overuse, you can implement rate-limiting. This can be achieved using Spring Cloud Gateway or a custom implementation.

-   **Spring Cloud Gateway**: Use `RateLimiter` filter to limit the number of requests.
-   **Custom Implementation**: Use an in-memory store or Redis to track the number of requests per user.

Example:
```java
@Bean  
public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {  
    return builder.routes()  
        .route(r -> r.path("/api/**")  
            .filters(f -> f.requestRateLimiter()  
                .rateLimiter(RateLimiter.class)  
                .config(new RequestRateLimiter.Config(10, 20)))  
            .uri("http://myservice"))  
        .build();  
}
```

### Q32. How do you implement a custom exception handler in Spring Boot?

Spring Boot provides global exception handling via `@ControllerAdvice`. You can customize exception handling for different scenarios.
```java
@ControllerAdvice  
public class GlobalExceptionHandler {  
  
    @ExceptionHandler(ResourceNotFoundException.class)  
    public ResponseEntity<ErrorResponse> handleResourceNotFound(ResourceNotFoundException ex) {  
        ErrorResponse errorResponse = new ErrorResponse(ex.getMessage(), HttpStatus.NOT_FOUND.value());  
        return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);  
    }  
}
```

### Q33. How do you use Spring Boot’s `@Scheduled` annotation for background tasks?

Spring Boot provides the `@Scheduled` annotation to schedule tasks like cron jobs or fixed-delay tasks.
```java
@Scheduled(fixedRate = 5000)  
public void reportCurrentTime() {  
    System.out.println("Current time: " + System.currentTimeMillis());  
}
```

### Q34. How do you implement Spring Boot with a NoSQL database like MongoDB or Cassandra?

Spring Boot makes it easy to integrate NoSQL databases using Spring Data.

-   **MongoDB**: Use `spring-boot-starter-data-mongodb` for MongoDB integration.
-   **Cassandra**: Use `spring-boot-starter-data-cassandra` for Cassandra integration.

Example with MongoDB:
```java
@EnableMongoRepositories  
public interface UserRepository extends MongoRepository<User, String> {  
    List<User> findByUsername(String username);  
}
```

### Q35. How would you configure and use Spring Boot with a message queue like RabbitMQ or Kafka?

Message queues like **RabbitMQ** and **Apache Kafka** enable **asynchronous processing, event-driven architectures, and microservices communication**. Spring Boot provides **Spring AMQP** for RabbitMQ and **Spring Kafka** for Kafka integration.

-   **RabbitMQ**: RabbitMQ is a **lightweight message broker** that uses the **AMQP protocol** for messaging. Use `spring-boot-starter-amqp` to integrate RabbitMQ into Spring Boot. Configure queues, exchanges, and listeners.
```xml
<dependency>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-starter-amqp</artifactId>  
</dependency>
```
Example:
```java
@RabbitListener(queues = "myQueue")  
public void receiveMessage(String message) {  
    System.out.println("Received: " + message);  
}
```

### 1. “What’s the difference between @SpringBootApplication, @EnableAutoConfiguration, and @ComponentScan?”

Many developers use `@SpringBootApplication` without understanding that it's actually a composite annotation that includes three annotations:

@SpringBootConfiguration  
@EnableAutoConfiguration  
@ComponentScan

**The Standard Answer:** Most candidates will say that `@SpringBootApplication` combines all three annotations as a convenience.

**What They Should Say:** A stronger answer breaks down what each does:

-   `@SpringBootConfiguration` marks the class as a configuration class (it's a specialized form of `@Configuration`)
-   `@EnableAutoConfiguration` tells Spring Boot to guess how you want to configure Spring based on the dependencies you've added
-   `@ComponentScan` tells Spring to look for components in the current package and below

**The Expert Answer:** A true expert will also mention that you can exclude specific auto-configurations:

@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})

This is crucial when you want Spring Boot to stop automatically configuring certain beans that you want to define manually or don’t need at all.

### 2. “How would you handle custom error pages in a Spring Boot application?”

**The Standard Answer:** Most candidates mention using static HTML error pages in the `/error` directory.

**What They Should Say:** A better answer includes implementing the `ErrorController` interface:
```java
@Controller  
public class CustomErrorController implements ErrorController {  
      
    @RequestMapping("/error")  
    public String handleError(HttpServletRequest request) {  
        Object status = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);  
        if (status != null) {  
            Integer statusCode = Integer.valueOf(status.toString());  
            if (statusCode == HttpStatus.NOT_FOUND.value()) {  
                return "error-404";  
            } else if (statusCode == HttpStatus.INTERNAL_SERVER_ERROR.value()) {  
                return "error-500";  
            }  
        }  
        return "error";  
    }  
}
```

**The Expert Answer:** An expert would also mention the more elegant approach using `@ControllerAdvice`:
```java
@ControllerAdvice  
public class GlobalExceptionHandler {  
      
    @ExceptionHandler(ResourceNotFoundException.class)  
    public ResponseEntity<ErrorResponse> handleResourceNotFoundException(ResourceNotFoundException ex) {  
        ErrorResponse error = new ErrorResponse("NOT_FOUND", ex.getMessage());  
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);  
    }  
      
    @ExceptionHandler(Exception.class)  
    public ResponseEntity<ErrorResponse> handleGlobalException(Exception ex) {  
        ErrorResponse error = new ErrorResponse("INTERNAL_SERVER_ERROR", "An unexpected error occurred");  
        return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);  
    }  
}
```

They would explain that this approach allows for more fine-grained control over different exception types and formats of error responses.

### 3. “Explain Spring Boot Actuator and how you’d secure its endpoints in production”

**The Standard Answer:** Basic candidates will say Actuator provides production-ready features like health checks and metrics.

**What They Should Say:** A better answer includes specific endpoints and their purposes:

-   `/health` shows application health information
-   `/metrics` shows metrics information
-   `/info` displays arbitrary application info
-   `/env` shows environment variables

**The Expert Answer:** An expert will talk about securing these endpoints:
```java
@Configuration  
public class ActuatorSecurityConfig extends WebSecurityConfigurerAdapter {        @Override    protected void configure(HttpSecurity http) throws Exception {  
        http.requestMatcher(EndpointRequest.toAnyEndpoint())  
            .authorizeRequests()  
            .requestMatchers(EndpointRequest.to("health", "info")).permitAll()  
            .anyRequest().hasRole("ACTUATOR_ADMIN")  
            .and()  
            .httpBasic();  
    }  
}
```
They’d also mention that you can:

1.  Expose only specific endpoints: `management.endpoints.web.exposure.include=health,info`
2.  Use different port for actuator endpoints: `management.server.port=8081`
3.  Consider using Spring Security with JWT or OAuth2 for production environments

### 4. “How does Spring Boot’s auto-configuration actually work?”

**The Standard Answer:** Most candidates will say something vague about “magic” or “scanning dependencies.”

**What They Should Say:** A better answer explains that Spring Boot looks for JAR files that contain `META-INF/spring.factories` files which list auto-configuration classes.

**The Expert Answer:** A thorough answer includes:

1.  Spring Boot scans for `META-INF/spring.factories` files in all JARs
2.  These files list classes under the key `org.springframework.boot.autoconfigure.EnableAutoConfiguration`
3.  Each auto-configuration class has `@Conditional` annotations that determine when it should be applied
4.  Common conditions include:

-   `@ConditionalOnClass` - only apply if a certain class is present
-   `@ConditionalOnMissingBean` - only apply if a certain bean doesn't exist
-   `@ConditionalOnProperty` - only apply if a certain property has a specific value

They would also explain that you can see which auto-configurations were applied and which were not by setting `debug=true` in your application properties.

### 5. “How would you implement custom validation in Spring Boot?”

**The Standard Answer:** Basic candidates mention using Bean Validation annotations like `@NotNull` and `@Size`.

**What They Should Say:** A better answer includes implementing a custom validator:
```java
@Constraint(validatedBy = AdultAgeValidator.class)  
@Target({ ElementType.FIELD })  
@Retention(RetentionPolicy.RUNTIME)  
public @interface AdultAge {  
    String message() default "Must be 18 or older";  
    Class<?>[] groups() default {};  
    Class<? extends Payload>[] payload() default {};  
}

public class AdultAgeValidator implements ConstraintValidator<AdultAge, Integer> {  
    @Override  
    public boolean isValid(Integer age, ConstraintValidatorContext context) {  
        return age != null && age >= 18;  
    }  
}
```

**The Expert Answer:** An expert would add handling validation errors with `@ControllerAdvice`:
```java
@ControllerAdvice  
public class ValidationExceptionHandler {  
      
    @ResponseStatus(HttpStatus.BAD_REQUEST)  
    @ExceptionHandler(MethodArgumentNotValidException.class)  
    public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException ex) {  
        Map<String, String> errors = new HashMap<>();  
        ex.getBindingResult().getAllErrors().forEach((error) -> {  
            String fieldName = ((FieldError) error).getField();  
            String errorMessage = error.getDefaultMessage();  
            errors.put(fieldName, errorMessage);  
        });  
        return errors;  
    }  
}
```

They would also discuss group validation for different validation scenarios and mention programmatic validation using `Validator`.

### 6. “What’s the difference between @Controller and @RestController?”

**The Standard Answer:** Most candidates will say that `@RestController` combines `@Controller` and `@ResponseBody`.

**What They Should Say:** A better answer explains that:

-   `@Controller` is used in Spring MVC to return views
-   `@RestController` automatically serializes return values to JSON/XML responses
-   `@RestController` is preferred for RESTful web services

**The Expert Answer:** An expert will go deeper:
```java
// With @Controller, you need @ResponseBody for each method  
@Controller  
public class UserController {  
    @GetMapping("/users")  
    @ResponseBody  
    public List<User> getUsers() {  
        return userService.findAll();  
    }  
      
    @GetMapping("/users/view")  
    public String getUsersView() {  
        return "users-view"; // Returns a view name  
    }  
}

// With @RestController, everything is automatically treated as @ResponseBody  
@RestController  
public class UserApiController {  
    @GetMapping("/api/users")  
    public List<User> getUsers() {  
        return userService.findAll(); // Automatically serialized to JSON  
    }  
}
```
They would also mention content negotiation, explaining that the client can request different formats (JSON, XML) using the Accept header, and Spring’s message converters will handle the appropriate serialization.

### 7. “Explain Spring profiles and how you’d use them in a production environment”

**The Standard Answer:** Basic candidates will say profiles help manage different configurations for different environments.

**What They Should Say:** A better answer includes how to use profiles:
```java
@Configuration  
@Profile("development")  
public class DevelopmentConfig {  
    // Development-specific beans  
}

@Configuration  
@Profile("production")  
public class ProductionConfig {  
    // Production-specific beans  
}
```
**The Expert Answer:** An expert would discuss:

Profile-specific properties files:

-   `application-dev.properties`
-   `application-prod.properties`
-   `application-test.properties`

Activating profiles:

-   Via property: `spring.profiles.active=prod`
-   Via environment variable: `SPRING_PROFILES_ACTIVE=prod`
-   Programmatically: `SpringApplication.setAdditionalProfiles("prod")`

Profile groups (Spring Boot 2.4+):
```java
spring.profiles.group.production=prod,metrics,actuator
```
Cloud-native approaches:

-   Using Kubernetes ConfigMaps for environment-specific properties
-   Using HashiCorp Vault for secrets management across environments
-   Spring Cloud Config Server for centralized configuration

### 8. “How would you handle distributed transactions in a Spring Boot microservices architecture?”

**The Standard Answer:** Most candidates mention the challenge but don’t know specific solutions.

**What They Should Say:** A stronger answer discusses the Saga pattern and event-driven approaches.

**The Expert Answer:** An expert answer includes several options:

###### **Saga Pattern implementation:**
```java
@Service  
public class OrderSagaService {  
    @Autowired private KafkaTemplate<String, OrderEvent> kafkaTemplate;  
      
    @Transactional  
    public void createOrder(Order order) {  
        // Save order in PENDING state  
        orderRepository.save(order);  
          
        // Publish event for inventory service  
        kafkaTemplate.send("inventory-events", new OrderEvent(order.getId(), "CHECK_INVENTORY"));  
    }  
      
    @KafkaListener(topics = "inventory-responses")  
    public void handleInventoryResponse(InventoryResponse response) {  
        Order order = orderRepository.findById(response.getOrderId()).orElseThrow();  
          
        if (response.isAvailable()) {  
            order.setStatus(OrderStatus.INVENTORY_CONFIRMED);  
            orderRepository.save(order);  
            // Trigger payment step  
            kafkaTemplate.send("payment-events", new OrderEvent(order.getId(), "PROCESS_PAYMENT"));  
        } else {  
            // Compensating transaction  
            order.setStatus(OrderStatus.FAILED);  
            orderRepository.save(order);  
        }  
    }  
}
```
###### Mentioning frameworks that help with distributed transactions:

-   Spring Cloud Stream for event-driven microservices
-   Axon Framework for CQRS and Event Sourcing
-   Eventuate Tram for implementing the Saga pattern

###### Discussing the CAP theorem and the tradeoffs between consistency and availability in distributed systems

### 9. “What are the pros and cons of using Spring Data JPA vs. direct Hibernate in a Spring Boot application?”

**The Standard Answer:** Basic answers mention that Spring Data JPA provides repositories and is easier to use.

**What They Should Say:** A more complete answer includes:

**Pros of Spring Data JPA:**

-   Reduces boilerplate with built-in repository methods
-   Automatic implementation of query methods based on method names
-   Pagination and sorting support
-   Auditing capabilities

**Cons:**

-   Abstraction can hide important Hibernate details
-   Potentially complex queries may be harder to express
-   Performance tuning might require dropping down to native SQL

**The Expert Answer:** An expert would provide specific examples:
```java
// With Spring Data JPA:  
public interface UserRepository extends JpaRepository<User, Long> {  
    List<User> findByEmailContainingOrderByLastNameAsc(String email);  
      
    @Query("SELECT u FROM User u WHERE u.status = :status AND u.lastLogin > :date")  
    List<User> findActiveUsersSince(@Param("status") Status status, @Param("date") LocalDate date);  
}

// With direct Hibernate:  
@Repository  
public class UserDao {  
    @PersistenceContext  
    private EntityManager entityManager;  
      
    public List<User> findActiveUsersSince(Status status, LocalDate date) {  
        Session session = entityManager.unwrap(Session.class);  
          
        CriteriaBuilder cb = session.getCriteriaBuilder();  
        CriteriaQuery<User> query = cb.createQuery(User.class);  
        Root<User> root = query.from(User.class);  
          
        query.select(root)  
             .where(cb.and(  
                 cb.equal(root.get("status"), status),  
                 cb.greaterThan(root.get("lastLogin"), date)  
             ));  
               
        return session.createQuery(query).getResultList();  
    }  
}
```
They would also discuss:

1.  How to optimize N+1 query problems in Spring Data JPA
2.  When to use `@EntityGraph` for fetching related entities
3.  The importance of understanding the persistence context and transaction boundaries

### 10. “How would you implement rate limiting in a Spring Boot API?”

**The Standard Answer:** Most candidates mention using a third-party API gateway.

**What They Should Say:** A better answer includes implementing it within the application:
```java
@Configuration  
public class RateLimitConfig {  
    @Bean  
    public RateLimiter userRateLimiter() {  
        return RateLimiter.create(10.0); // 10 requests per second  
    }  
}

@RestController  
public class UserController {  
    @Autowired  
    private RateLimiter userRateLimiter;  
      
    @GetMapping("/api/users")  
    public ResponseEntity<List<User>> getUsers() {  
        if (!userRateLimiter.tryAcquire()) {  
            return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).build();  
        }  
        return ResponseEntity.ok(userService.findAll());  
    }  
}
```
**The Expert Answer:** An expert would implement a more sophisticated solution with a custom annotation:
```java
@Target(ElementType.METHOD)  
@Retention(RetentionPolicy.RUNTIME)  
public @interface RateLimit {  
    int value();           // requests per minute  
    String key() default "";  // rate limit key, e.g. by user, by IP  
}

@Aspect  
@Component  
public class RateLimitAspect {  
    private Map<String, Bucket> buckets = new ConcurrentHashMap<>();  
      
    @Around("@annotation(rateLimit)")  
    public Object enforceRateLimit(ProceedingJoinPoint joinPoint, RateLimit rateLimit) throws Throwable {  
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();  
          
        String key = rateLimit.key().isEmpty() ?   
            request.getRemoteAddr() : ReflectionUtils.invokeMethod(  
                ReflectionUtils.findMethod(request.getClass(), "get" + StringUtils.capitalize(rateLimit.key())),  
                request  
            ).toString();  
              
        Bucket bucket = buckets.computeIfAbsent(key,   
            k -> Bucket4j.builder().addLimit(Bandwidth.simple(rateLimit.value(), Duration.ofMinutes(1))).build());  
              
        if (bucket.tryConsume(1)) {  
            return joinPoint.proceed();  
        } else {  
            throw new TooManyRequestsException("Rate limit exceeded");  
        }  
    }  
}

@RestController  
public class ProductController {  
    @GetMapping("/api/products")  
    @RateLimit(value = 30)  // 30 requests per minute by IP  
    public List<Product> getProducts() {  
        return productService.findAll();  
    }  
      
    @GetMapping("/api/users/{userId}/orders")  
    @RateLimit(value = 10, key = "userId")  // 10 requests per minute by user ID  
    public List<Order> getUserOrders(@PathVariable String userId) {  
        return orderService.findByUserId(userId);  
    }  
}
```

### 13. What Are the Basic Annotations that Spring Boot Offers?

Spring Boot offers several annotations that simplify the development of Spring-based applications. Here are some of the basic annotations that Spring Boot provides:

**@SpringBootApplication**: This annotation is used to mark the main class of a Spring Boot application. It enables component scanning, auto-configuration, and starts the embedded web server.

**@Controller**: This annotation is used to mark a class as a Spring MVC controller. It handles HTTP requests and returns HTTP responses.

**@RestController**: This annotation is a combination of @Controller and **@ResponseBody**. It is used to mark a class as a RESTful controller. It handles HTTP requests and returns JSON/XML responses.

**@Service**: This annotation is used to mark a class as a service. It encapsulates the business logic of an application.

**@Repository**: This annotation is used to mark a class as a repository. It is used to interact with a database.

**@Component**: This annotation is the base annotation for all Spring-managed components. It is used to mark a class as a bean.

**@Autowired**: This annotation is used to inject dependencies into a Spring-managed bean.

**@Qualifier**: This annotation is used to specify which bean to inject when multiple beans of the same type are available.

**@Value**: This annotation is used to inject values from the properties file into a Spring-managed bean.

**@Configuration**: This annotation is used to mark a class as a configuration class. It provides configuration to the Spring application context.

**@Profile**: This annotation is used to activate/deactivate a bean based on the specified profile.

**@RequestMapping**: This annotation is used to map an HTTP request to a method in a controller.

**@PathVariable**: This annotation is used to extract a variable from the URL path.

These are some of the basic annotations that Spring Boot provides. There are many more annotations available that you can explore in the Spring documentation.

### 14. What is Spring Boot dependency management?

Spring Boot dependency management is used to manage dependencies and configuration automatically without you specifying the version for any of that dependencies.

### 15. Can we create a non-web application in Spring Boot?

Yes, it is possible to create a non-web application in Spring Boot. Although Spring Boot is often used to develop web applications, it can be used for non-web applications as well.

Spring Boot provides several features that are not related to web development. For example, Spring Boot provides support for data access, caching, messaging, scheduling, and batch processing. These features can be used to develop non-web applications such as command-line applications, standalone applications, background tasks, and batch jobs.

To create a non-web application in Spring Boot, you can exclude the web-related dependencies from your project. You can do this by adding the `spring-boot-starter` dependency to your `pom.xml` file and excluding the web-related dependencies using the `exclude` tag.

For example, to create a command-line application, you can add the `spring-boot-starter` dependency to your `pom.xml` file and exclude the web-related dependencies as follows:
```xml
<dependency>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-starter</artifactId>  
    <exclusions>  
        <exclusion>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-starter-web</artifactId>  
        </exclusion>  
    </exclusions>  
</dependency>
```

Once you have excluded the web-related dependencies, you can use the Spring Boot features to develop your non-web application. For example, you can use Spring Data to access a database, use Spring Batch to process large volumes of data, or use Spring Integration to integrate with other systems.

In summary, Spring Boot can be used to develop non-web applications as well, and it provides several features that are not related to web development.

### 16. Is it possible to change the port of the embedded Tomcat server in Spring Boot?

Yes, it is possible to change the port of the embedded Tomcat server in Spring Boot. By default, Spring Boot applications run on port 8080. However, you can change the port by modifying the `application.properties` or `application.yml` file.

To change the port of the embedded Tomcat server in Spring Boot, you can add the following line to your `application.properties` file:
```shell
server.port=8081
```
In the above example, the server will start on port 8081 instead of the default port 8080.

Alternatively, you can also specify the port in the `application.yml` file as follows:
```yml
server:  
  port: 8081
```
In addition to the `server.port` property, you can also specify other properties related to the Tomcat server in the `application.properties` or `application.yml` file. For example, you can set the maximum number of threads, the maximum size of the request, or the timeout for idle connections.

In summary, it is possible to change the port of the embedded Tomcat server in Spring Boot by modifying the `application.properties` or `application.yml` file. This provides flexibility and allows you to run your Spring Boot application on a different port than the default port 8080.

### 17. What is the default port of tomcat in spring boot?

The default port of the tomcat server-id 8080. It can be changed by adding **sever.port** properties in the **application.property** file.

### 18. Can we override or replace the Embedded tomcat server in Spring Boot?

Yes, we can replace the Embedded Tomcat server with any server by using the Starter dependency in the **pom.xml** file. Like you can use spring-boot-starter-jetty as a dependency for using a jetty server in your project.

### 19. Can we disable the default web server in the Spring boot application?

Yes, we can use **application.properties** to configure the web application type i.e **spring.main.web-application-type=none.**

### 20. How to disable a specific auto-configuration class?

You can use exclude attribute of @EnableAutoConfiguration if you want auto-configuration not to apply to any specific class.
```java
//use of exclude  
@EnableAutoConfiguration(exclude={className})
```
### 21. Explain @RestController annotation in Sprint boot?

It is a combination of @Controller and @ResponseBody, used for creating a restful controller. It converts the response to JSON or XML. It ensures that data returned by each method will be written straight into the response body instead of returning a template

### 22. What is the difference between @RestController and @Controller in Spring Boot?

@Controller Map of the model object to view or template and make it human readable but @RestController simply returns the object and object data is directly written in HTTP response as JSON or XML.

### 23. Describe the flow of HTTPS requests through the Spring Boot application?

When an HTTPS request is made to a Spring Boot application, the request flows through a series of components and processes. The flow of HTTPS requests through a Spring Boot application can be described as follows:

-   The client sends an HTTPS request to the Spring Boot application.
-   The request is received by the embedded Tomcat server in the Spring Boot application.
-   The SSL/TLS handshake process is initiated by the Tomcat server. The server presents its digital certificate to the client to authenticate itself.
-   If the client trusts the server’s certificate, it sends a message indicating that the handshake was successful. If the client does not trust the server’s certificate, it will reject the connection.
-   Once the SSL/TLS handshake is complete, the request is passed to the Spring MVC DispatcherServlet.
-   The DispatcherServlet analyzes the request and maps it to the appropriate controller and handler method.
-   The controller processes the request and returns a ModelAndView object to the DispatcherServlet.
-   The DispatcherServlet then resolves the view, generates the response, and sends it back to the client over the encrypted HTTPS connection.
-   If the client needs to make another request, the process repeats from step 1.

In summary, the flow of HTTPS requests through a Spring Boot application involves the SSL/TLS handshake process, the Spring MVC DispatcherServlet, and the controller and view components. This flow ensures that requests and responses are transmitted securely over an encrypted connection, protecting sensitive data from eavesdropping and tampering.

### 24. What is the difference between RequestMapping and GetMapping?

RequestMapping can be used with GET, POST, PUT, and many other request methods using the method attribute on the annotation. Whereas getMapping is only an extension of RequestMapping which helps you to improve on clarity on request.

### 25. What is the use of Profiles in spring boot?

While developing the application we deal with multiple environments such as dev, QA, Prod, and each environment requires a different configuration. For eg., we might be using an embedded H2 database for dev but for prod, we might have proprietary Oracle or DB2. Even if DBMS is the same across the environment, the URLs will be different.

To make this easy and clean, Spring has the provision of Profiles to keep the separate configuration of environments.

### 26. What is Spring Actuator? What are its advantages?

An actuator is an additional feature of Spring that helps you to monitor and manage your application when you push it to production. These actuators include auditing, health, CPU usage, HTTP hits, and metric gathering, and many more that are automatically applied to your application.

### 27. How to enable Actuator in Spring boot application?

Actuator is a set of Spring Boot modules that provides production-ready features to help you monitor and manage your application. To enable Actuator in a Spring Boot application, you can follow these steps:

1.  Add the Actuator dependency to your `pom.xml` file or `build.gradle` file. For example, if you are using Maven, add the following dependency:
```xml
<dependency>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-starter-actuator</artifactId>  
</dependency>
```
2. Once the dependency is added, Actuator endpoints will be enabled by default. You can access them by visiting the URL `http://localhost:8080/actuator` in your browser.

Note that the actual port number may be different depending on the configuration of your application.

3. You can also customize the Actuator endpoints by modifying the `application.properties` or `application.yml` file. For example, to enable the `/health` endpoint, you can add the following line to your `application.properties` file:

management.endpoints.web.exposure.include=health

This will expose the `/health` endpoint, which will provide information about the health of your application.

4. You can also add custom Actuator endpoints by creating a new class that implements the `Endpoint` interface. For example, to create a custom endpoint that provides information about the number of active sessions in your application, you can create a class like this:
```java
@Endpoint(id = "session-count")  
public class SessionCountEndpoint {  
  
    private final HttpSession httpSession;  
  
    public SessionCountEndpoint(HttpSession httpSession) {  
        this.httpSession = httpSession;  
    }  
  
    @ReadOperation  
    public int getSessionCount() {  
        return httpSession.getActiveSessions().size();  
    }  
}
```
This class creates a new endpoint with the ID `session-count` and provides information about the number of active sessions in the application. You can then access this endpoint by visiting the URL `http://localhost:8080/actuator/session-count` in your browser.

In summary, to enable Actuator in a Spring Boot application, you need to add the Actuator dependency to your project, and then you can access the Actuator endpoints at `http://localhost:8080/actuator`. You can customize the Actuator endpoints by modifying the `application.properties` or `application.yml` file, and you can also add custom endpoints by creating a new class that implements the `Endpoint` interface.

### 29. How to check the environment properties in your Spring boot application?

Spring Boot actuator “/env” returns the list of all the environment properties of running the spring boot application.

### 30. What is dependency Injection?

Dependency Injection (DI) is a design pattern used in software engineering and a fundamental concept in Spring Framework and Spring Boot. DI is a process of providing dependencies (objects) to a class, rather than the class creating its own dependencies. In other words, DI is a way of removing the hard-coded dependencies from the code and providing them externally.

The core idea behind DI is to decouple the classes in an application by removing hard-coded dependencies between them. Instead, dependencies are passed to a class via constructors, methods, or fields. This makes the code more modular, easier to test, and easier to maintain.

DI is typically implemented using an Inversion of Control (IoC) container, such as the Spring Framework. The container manages the lifecycle of objects and their dependencies, and automatically injects the necessary dependencies into objects at runtime. The dependencies are configured using a set of rules or configurations, which are typically stored in XML, Java annotations, or Java code.

In Spring Boot, DI is a key concept that is used throughout the framework. For example, when you use `@Autowired` annotation in your code, Spring Boot automatically injects the necessary dependencies into your objects, making it easier to write modular, testable, and maintainable code.

In summary, Dependency Injection is a design pattern used in software engineering to remove hard-coded dependencies between classes and to provide dependencies externally. It is a fundamental concept in Spring Framework and Spring Boot, and is typically implemented using an Inversion of Control container.


### Q.  What is Spring Framework?

The Spring Framework provides a comprehensive programming and configuration model for modern Java-based enterprise applications — on any kind of deployment platform.

A key element of Spring is infrastructural support at the application level: Spring focuses on the “plumbing” of enterprise applications so that teams can focus on application-level business logic, without unnecessary ties to specific deployment environments.

### Q.  What is Inversion of control?

In traditional programming, you would have to manually create and manage all the objects that your application needs. This can be a complex and error-prone process.

This diagram shows what IOC looks like,

![](https://miro.medium.com/v2/resize:fit:875/1*xDBx6KR7Z0ia0uG3nh0y4Q.png)

The Spring Framework’s IoC container simplifies this process by taking over the responsibility of creating and managing objects. You simply tell Spring what objects you need, and it will create them for you and provide them to your code. This is called dependency injection.

Dependency injection makes your code more modular and easier to maintain. It also reduces the risk of errors, because you no longer have to worry about creating objects correctly.

IoC is also known as dependency injection (DI). It is a process whereby objects define their dependencies (that is, the other objects they work with) only through constructor arguments, arguments to a factory method, or properties that are set on the object instance after it is constructed or returned from a factory method. The container then injects those dependencies when it creates the bean. This process is fundamentally the inverse (hence the name, Inversion of Control) of the bean itself controlling the instantiation or location of its dependencies by using direct construction of classes

### Q.  What is a Spring IOC Container?

The org. spring framework.context.ApplicationContext interface represents the Spring IoC container and is responsible for instantiating, configuring, and assembling the beans.

![](https://miro.medium.com/v2/resize:fit:875/1*NRHMbtvWRjzsk-ISjAfWBw.png)

The container gets its instructions on what objects to instantiate, configure, and assemble by reading configuration metadata. The configuration metadata is represented in XML, Java annotations, or Java code. It lets you express the objects that compose your application and the rich interdependencies between those objects.

### Q.  In How many ways we can define the configuration in spring?

We can do that in two ways:

1. **XML based config** : It can be useful to have bean definitions span multiple XML files. Often, each individual XML configuration file represents a logical layer or module in your architecture.

2. **Java-based configuration**: define beans external to your application classes by using Java rather than XML files. To use these features, see the @Configuration, @Bean, @Import, and @DependsOn annotations.

### Q.  What is Dependency injection?

**Dependency injection (DI)** is a process whereby objects define their dependencies (that is, the other objects with which they work) only through constructor arguments, arguments to a factory method, or properties that are set on the object instance after it is constructed or returned from a factory method. The container then injects those dependencies when it creates the bean. This process is fundamentally the inverse (hence the name, Inversion of Control) of the bean itself controlling the instantiation or location of its dependencies on its own by using the direct construction of classes or the Service Locator pattern.

![](https://miro.medium.com/v2/resize:fit:875/1*zodECyp6WqJKf8pqWzf9Dg.png)

Code is cleaner with the DI principle, and decoupling is more effective when objects are provided with their dependencies. The object does not look up its dependencies and does not know the location or class of the dependencies. As a result, your classes become easier to test, particularly when the dependencies are on interfaces or abstract base classes, which allow for stub or mock implementations to be used in unit tests.

DI exists in two major variants: Constructor-based dependency injection and Setter-based dependency injection. Typically, a Diagram Looks like this,

### Q.  Difference between Inversion of Control and Dependency Injection?

![](https://miro.medium.com/v2/resize:fit:875/1*Vm_4S8oaAK0DcO1T4MaMhw.png)

### Q.  What are the types of dependency injection and what benefit we are getting using that?

Dependency injection (DI) is a design pattern that allows objects to be supplied with their dependencies, rather than having to create them themselves. There are several types of dependency injection, each with its own benefits:

**Constructor injection**: In this type of injection, the dependencies are passed to the constructor of the class when it is instantiated. This ensures that the class always has the required dependencies and can be useful for enforcing class invariants.

The following example shows a class that can only be dependency-injected with constructor injection:
```java
public class SimpleMovieLister {  
// the SimpleMovieLister has a dependency on a MovieFinder  
private final MovieFinder movieFinder;  
// a constructor so that the Spring container can inject a MovieFinder  
public SimpleMovieLister(MovieFinder movieFinder) {  
this.movieFinder = movieFinder;  
}  
// business logic that actually uses the injected MovieFinder is omitted…  
}
```

**Setter injection**: In this type of injection, the dependencies are passed to the setter methods of the class after it has been instantiated. This allows the class to be reused in different contexts, as the dependencies can be changed at runtime.
```java
public class SimpleMovieLister {  
// the SimpleMovieLister has a dependency on the MovieFinder  
private MovieFinder movieFinder;  
// a setter method so that the Spring container can inject a //MovieFinder  
public void setMovieFinder(MovieFinder movieFinder) {  
this.movieFinder = movieFinder;  
}  
// business logic that actually uses the injected MovieFinder is omitted…  
}
```
### Q.  Which one is better Constructor-based or setter-based DI?

Since you can mix constructor-based and setter-based DI, it is a good rule of thumb to use constructors for mandatory dependencies and setter methods or configuration methods for optional dependencies. Note that use of the @Autowired annotation on a setter method can be used to make the property be a required dependency; however, constructor injection with programmatic validation of arguments is preferable.

**The Spring team generally advocates constructor injection, as it lets you implement application components as immutable objects and ensures that required dependencies are not null**. Furthermore, constructor-injected components are always returned to the client (calling) code in a fully initialized state.

### Q.  What is Method Injection?

**Method Injection is a design pattern commonly used in Spring and other frameworks to inject dependencies into objects**. Unlike field injection or constructor injection, which inject dependencies directly into fields or constructors, method injection injects dependencies into specific method arguments.

### Q.  How does the inversion of control work inside the container?

Inversion of Control (IoC) is a design pattern that allows control to be transferred from the application code to an external container. In the context of a Java application, this container is often referred to as an IoC container or a dependency injection (DI) container.

IoC containers are responsible for creating and managing objects, and they do this by relying on a set of configuration rules that define how objects are created and wired together.

_Here’s how IoC works inside an IoC container:_

**Configuration**: In order to use an IoC container, you need to configure it with a set of rules that define how objects should be created and wired together. This configuration is typically done using XML or Java annotations.

**Object creation**: When your application requests an object from the container, the container uses the configuration rules to create a new instance of the requested object.

**Dependency injection**: The container injects any required dependencies into the newly created object. These dependencies are typically defined in the configuration rules.

**Object lifecycle management**: The container manages the lifecycle of the objects it creates. This means that it’s responsible for creating, initializing, and destroying objects as required by the application.

**Inversion of control**: By relying on the container to create and manage objects, the application code no longer has direct control over the object creation process. Instead, the container takes on this responsibility, and the application code simply requests the objects it needs from the container.

### Q.  What are the different spring modules?

The Spring Framework is a comprehensive Java framework that consists of several modules, each providing a specific set of features and functionalities. These modules are organized into categories based on their primary purpose. Here’s an overview of the major Spring modules and their respective roles:

![](https://miro.medium.com/v2/resize:fit:875/1*d7IrkmOZ1OdX0s-SSh6QbQ.png)
spring modules

**Core Container**: The Core Container module forms the foundation of the Spring Framework, providing essential services like dependency injection, bean lifecycle management, and resource management. It’s responsible for creating, configuring, and managing objects throughout the application.

**Data Access/Integration**: The Data Access/Integration module focuses on simplifying data access and integration with various data sources, including relational databases, object-relational mapping (ORM) frameworks, and messaging systems. It provides features like JDBC abstraction, ORM integration, and message-oriented middleware (MOM) support.

**Web (MVC/Remoting)**: The Web module caters to building web applications using the Model-View-Controller (MVC) pattern and provides remoting capabilities for distributed applications. It includes support for various web technologies like Servlet, Portlet, and Struts.

**AOP (Aspect-Oriented Programming)**: The AOP module enables aspect-oriented programming, a technique for modularizing cross-cutting concerns like logging, security, and transaction management. It provides features like aspect declaration, aspect weaving, and aspect execution.

**Instrumentation**: The Instrumentation module facilitates monitoring and performance management of Spring applications. It provides features like bean lifecycle tracing, memory profiling, and performance metrics collection.

**Test**: The Test module offers tools and frameworks for testing Spring applications, including support for dependency injection in unit tests, integration tests, and web application tests.

### Q.  What are Spring MVC, Spring AOP, and Spring Core modules?

The reason to ask this question is, these three modules are very important while developing the spring-based application.

Spring MVC, Spring AOP, and Spring Core are three essential modules of the Spring Framework that play crucial roles in building robust and scalable Java applications.

**Spring MVC (Model-View-Controller)**

Spring MVC is a web framework that implements the Model-View-Controller (MVC) architecture, a popular pattern for separating application logic, user interface presentation, and data management. It provides a layered approach to handling web requests, making it easier to develop maintainable and testable web applications.

**Key features of Spring MVC include:**

**Dispatcher Servlet**: Centralizes request handling and dispatching to appropriate controllers.

**Controller classes**: Handle user requests by processing data, interacting with the model, and selecting appropriate views.

**View technologies**: Supports various templating engines like JSP, FreeMarker, Thymeleaf, and Velocity to render dynamic content.

**Spring AOP (Aspect-Oriented Programming)**

Spring AOP provides an implementation of aspect-oriented programming (AOP), a technique for modularizing cross-cutting concerns like logging, security, and transaction management. It allows developers to encapsulate these concerns as aspects and apply them to specific points within the application’s execution flow.

**Key features of Spring AOP include:**

**Aspect declaration**: Defines aspects, specifying the cross-cutting concern and the pointcuts where it should be applied.

**Aspect weaving**: Integrates aspects into the application’s execution flow, applying the aspect’s behaviour at specific join points.

**Aspect execution**: Handles the invocation of aspect advice, which defines the actions to be taken at the join points.

**Spring Core**

Spring Core is the foundation of the Spring Framework, providing essential services like dependency injection, bean lifecycle management, and resource management. It’s responsible for creating, configuring, and managing objects throughout the application.

**Key features of Spring Core include:**

**Dependency injection**: Automatically supplies objects with their dependencies, reducing code complexity and improving modularity.

**Bean lifecycle management**: Handles the creation, initialization, destruction, and scope of objects within the Spring application context.

**Resource management**: Manages resources like database connections, files, and messaging queues, simplifying resource acquisition and release.

### Q.  How Component Scanning(@ComponentScan) Works?

**Annotation Discovery**: The Spring Framework uses annotation-based configuration to identify Spring beans. It scans the specified packages and subpackages for classes annotated with @Component, @Service, @Repository, @Controller, or other stereotype annotations that indicate a bean’s role in the application.

**Bean Creation and Registration**: Upon discovering annotated classes, the Spring Framework creates instances of those classes and registers them as Spring beans in the application context. The application context maintains a registry of all managed beans, making them accessible for dependency injection.

**Bean Configuration**: The Spring Framework applies default configuration rules to the registered beans. These rules include dependency injection, bean lifecycle management, and resource management. Developers can further customize bean configuration using annotations, XML configuration files, or programmatic configuration.

Configuration Class:  
```java
@Configuration  
@ComponentScan("com.example. springapp")  
public class AppConfig {  
}
```
This configuration class defines two annotations:

· @**Configuration**: Marks this class as a source of bean definitions for Spring.

· @**ComponentScan**: Specifies the base package for component scanning. Spring will scan this package and its sub-packages for classes annotated with @Component, @Service, @Repository, or @Controller, and register them as Spring beans.

### Q.  What is ApplicationContext and how to use it inside Spring?

ApplicationContext is the core container for managing beans and providing services to Spring applications. It simplifies bean configuration, dependency injection, and resource management.

This is how we should use it.
```java
ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");  
MyService myService = context.getBean("myService", MyService.class);  
myService.doSomething();  
context.close();
```
This code shows how to create an ApplicationContext from an XML configuration file, retrieve a bean by name, invoke a method on the bean, and close the ApplicationContext.

### Q.  What is BeanFactory and how to use it inside spring?

BeanFactory is an interface that represents a basic container for managing beans in a Spring application. It provides methods for creating, retrieving, and configuring beans. While ApplicationContext is a more advanced and commonly used container, BeanFactory offers a simpler interface for basic bean management.

Here is an example,
```java
BeanFactory factory = new XmlBeanFactory("applicationContext.xml");  
MyService myService = factory.getBean("myService", MyService.class);  
myService.doSomething();
```
### Q.  What is Bean?

Bean: In Spring, a bean is a managed object within the Spring IoC container. It is an instance of a class that is created, managed, and wired together by the Spring framework. Beans are the fundamental building blocks of Spring applications and are typically configured and defined using annotations or XML configuration.

### Q.  What are Bean scopes?

In Spring Framework, a bean scope defines the lifecycle and the visibility of a bean within the Spring IoC container. Spring Framework provides several built-in bean scopes, each with a specific purpose and behaviour.

The following are the most commonly used bean scopes in Spring Framework:

**Singleton:**

(Default) Scopes a single bean definition to a single object instance for each Spring IoC container.

**Prototype**:

Scopes a single bean definition to any number of object instances.

**Request**:

Scopes a single bean definition to the lifecycle of a single HTTP request. That is, each HTTP request has its own instance of a bean created off the back of a single bean definition. Only valid in the context of a web-aware Spring ApplicationContext.

**Session**:

Scopes a single bean definition to the lifecycle of an HTTP Session. Only valid in the context of a web-aware Spring ApplicationContext.

**Application**:

Scopes a single bean definition to the lifecycle of a ServletContext. Only valid in the context of a web-aware Spring ApplicationContext.

**Websocket**:

Scopes a single bean definition to the lifecycle of a WebSocket. Only valid in the context of a web-aware Spring ApplicationContext.

### Q.  What is the Spring bean lifecycle?

In Spring Framework, a bean is an object that is managed by the Spring IoC container. The lifecycle of a bean is the set of events that occur from its creation until its destruction.

· The Spring bean lifecycle can be divided into three phases: instantiation, configuration, and destruction.

· **Instantiation**: In this phase, Spring IoC container creates the instance of the bean. Spring Framework supports several ways of instantiating a bean, such as through a constructor, a static factory method, or an instance factory method.

· **Configuration**: In this phase, Spring IoC container configures the newly created bean. This includes performing dependency injection, applying any bean post-processors, and registering any initialization and destruction call-backs.

· **Destruction**: In this phase, Spring IoC container destroys the bean instance. It is the last phase of the Spring bean lifecycle.

In addition to these three phases, Spring Framework also provides several callbacks that allow developers to specify custom initialization and destruction logic for a bean. These callbacks include:

· @**PostConstruct**: Invoked after the bean has been constructed and all dependencies have been injected

· init-method: Specifies a method to be called after the bean has been constructed and all dependencies have been injected

· destroy-method: Specifies a method to be called just before the bean is destroyed.

· @**PreDestroy**: Invoked before the bean is destroyed.

The Spring bean lifecycle is controlled by the Spring IoC container, which creates, configures, and manages the lifecycle of the beans. Developers can take advantage of the bean lifecycle callbacks to add custom initialization and destruction logic to their beans, making it easier to manage the lifecycle of their objects and ensure that resources are properly.

### Q.  What is the bean lifecycle in terms of application context?

The bean lifecycle within an application context refers to the various stages a bean goes through from its creation to its destruction. The application context is responsible for managing this lifecycle, ensuring that beans are properly initialized, used, and destroyed at the appropriate times.

**Stages of the Bean Lifecycle:**

· **Bean Creation**: The bean is instantiated, either through constructor injection, setter-based injection, or other mechanisms.

· **Bean Configuration**: The bean’s properties are set and any necessary initialization callbacks are invoked.

· **Bean Usage**: The bean is used by the application, providing its designated functionality.

· **Bean Destruction**: The bean is destroyed when it is no longer needed, releasing resources and performing any necessary cleanup tasks.

**Application Context’s Role in Bean Lifecycle:**

· The application context plays a central role in managing the bean lifecycle, providing various mechanisms to control the creation, configuration, usage, and destruction of beans.

· Bean Configuration Metadata: The application context stores configuration metadata for beans, defining how they should be created, configured, and managed.

· Bean Lifecycle Hooks: The application context provides hooks to define custom behavior at various stages of the bean lifecycle, such as initialization and destruction callbacks.

· Bean Scope Management: The application context manages the scope of beans, determining their visibility and lifetime within the application.

· Bean Lifecycle Listeners: The application context supports bean lifecycle listeners, allowing components to be notified of changes in the lifecycle of other beans.

### Q.  Difference Between BeanFactory and ApplicationContext?

![](https://miro.medium.com/v2/resize:fit:875/1*2NiOhIGAV3WMOsY2pQ1YKg.png)

### Q.  What is the default bean scope in spring?

The default bean scope in Spring is singleton. This means that only one instance of a bean will be created and managed by the Spring container, regardless of how many times it is requested. This scope is useful for beans that are stateless, meaning that they do not maintain any internal state and can be safely shared across different parts of the application.

Below diagram how one instance is created,

![](https://miro.medium.com/v2/resize:fit:875/1*G4XUw3Ju0p9Cx3uqpbsgoA.png)

### Q.  How bean is loaded inside the spring, can you tell the difference between Lazy loading and Eager loading?

**Bean Loading in Spring:**

The Spring Framework uses a process called bean instantiation to create beans and make them available to the application. This process involves the following steps:

**Scanning for beans**: The Spring Framework scans the application context for classes that are annotated with Spring annotations such as @Component, @Service, @Repository, and @Controller.

**Creating bean instances**: The Spring Framework creates an instance of each bean class that it finds.

**Configuring beans**: The Spring Framework configures each bean by setting its properties and injecting its dependencies.

**Initializing beans**: The Spring Framework initializes each bean by calling its initialization callbacks.

### Q.  Lazy Loading vs. Eager Loading? (Important Interview Question)

In Spring, beans can be either **lazy-loaded or eager-loaded**. Lazy loading means that a bean is not created until it is first requested by the application. Eager loading means that a bean is created when the application starts up.

The default behavior in Spring is to Eager-load beans. This can improve the performance of the application because it means that only the beans that are actually needed are created. However, lazy loading can also make the application more difficult to debug because it can be hard to track down which beans have been created and when.

**Eager loading can be useful for beans that are needed by the application as soon as it starts up**. For example, an application might need to connect to a database as soon as it starts up. In this case, it would make sense to eagerly load the bean that is responsible for connecting to the database.

### Q.  How to Specify Lazy Loading and Eager Loading?

You can specify whether a bean should be lazy-loaded or eagerly loaded using the @Lazy annotation. For example, the following code will create a bean that is lazy loaded:
```java
@Lazy  
@Service  
public class MyService {  
}
```
The following code will create a bean that is eagerly loaded:
```java
@Service  
public class MyEagerService {  
}
```
**when to use lazy loading and eager loading:**

-   Use lazy loading for beans that are not needed by the application as soon as it starts up.
-   Use eager loading for beans that are needed by the application as soon as it starts up.
-   Use eager loading for beans that have a high startup cost.
-   Use lazy loading for beans that are not frequently used.

### Q.  How @Autowire annotation work?

The @Autowired annotation works by using reflection to find the appropriate dependency to inject. It will first look for a bean with the same type as the dependency. If it cannot find a bean of the same type, it will look for a bean with a qualifier that matches the name of the dependency. If it still cannot find a bean to inject, it will throw an exception.

### Q.  What are the Types of Autowiring?

There are four types of autowiring that the @Autowired annotation supports:

· **byType**: This is the default type of autowiring. The Spring Framework will look for a bean with the same type as the dependency.

· **byName**: The Spring Framework will look for a bean with the same name as the dependency.

· **byConstructor**: The Spring Framework will look for a constructor that takes a single argument of the type of the dependency.

· **byQualifier**: The Spring Framework will look for a bean with a qualifier that matches the specified value.

### Q.  How to exclude a Bean from Autowiring?

Here are the methods to exclude a Bean from Autowiring in Spring:

**1. Setting autowire-candidate to false in XML configuration:**

In your XML configuration, add the autowire-candidate=”false” attribute to the <bean> element you want to exclude:
```xml
<bean id="myBean" class="com.example.MyBean" autowire-candidate="false">  
</bean>
```
**2. Using @Lazy annotation (for lazy initialization):**

If you’re using annotations for bean configuration, annotate the bean class or its @Bean method with @Lazy:
```java
@Lazy  
@Bean  
public MyBean myBean() {  
return new MyBean();  
}
```
**3. Disabling auto-configuration for a specific bean:**

In Spring Boot, **use @SpringBootApplication(exclude = {MyBeanAutoConfiguration.class})** to exclude a specific auto-configuration class.

### Q.  **Difference between @Autowire and @Inject in spring?**

The @Autowired and @Inject annotations are both used for dependency injection in Spring applications. However, there are some key differences between the two annotations.

**@Autowired(Use when developing a Spring application)**

The @Autowired annotation is a Spring-specific annotation. It is used to inject dependencies into beans that are managed by the Spring container. The @Autowired annotation can be used with all four types of autowiring: byType, byName, byConstructor, and byQualifier.

**@Inject(Use when developing a non-Spring application)**

The @Inject annotation is a standard JSR-330 annotation. It is used to inject dependencies into beans that are managed by any dependency injection container that supports JSR-330. The @Inject annotation can only be used with byType and byName autowiring.

### Q.  Is the Singleton Bean thread safe?

No, singleton beans are not thread-safe by default. This means that if two threads try to access a singleton bean at the same time, they may get conflicting results. This is because singleton beans are shared across all threads, and any changes made to a singleton bean by one thread will be visible to all other threads.

### Q.  Difference between Singleton and Prototype Bean?

![](https://miro.medium.com/v2/resize:fit:875/1*RO9oJ5OXOtEWen1g3EHXlw.png)

### Q.  What is @Bean annotation in spring?

The @Bean annotation is a Spring Framework annotation that marks a method as a bean definition. Bean definitions tell the Spring container how to create and manage beans. When a method is annotated with @Bean, the Spring container will create an instance of the bean class returned by the method and manage its lifecycle.
```java
@Configuration  
public class MyConfiguration {  

@Bean  
public MyService myService() {  
    return new MyServiceImpl();  
}  
}
```
In this example, the myService() method is annotated with @Bean. This tells the Spring container to create an instance of the MyServiceImpl class and manage its lifecycle. The bean can then be injected into other beans using the @Autowired annotation.

### Q.  What is @Configuration annotation?

The @Configuration annotation is a Spring Framework annotation that marks a class as a configuration class. Configuration classes are used to define beans in a Spring application. When a class is annotated with @Configuration, the Spring container will scan the class for methods that are annotated with @Bean and use those methods to define beans.
```java
@Configuration  
public class MyConfiguration {  

    @Bean  
    public MyService myService() {  
        return new MyServiceImpl();  
    }  
}
```

### Q.  How to configure Spring profiles?

Spring profiles provide a way to segregate parts of your application configuration and make them only available in certain environments

There are two ways to configure Spring profiles:

**1. Using the Spring Boot Properties File**

The Spring Boot properties file, typically named application.properties or application.yml, is a convenient way to configure Spring profiles. To configure a profile using the properties file, simply add the following property:

e.g.

_spring.profiles.active=profile1,profile2_

### Q.  What are @component @profile and @value annotation?

![](https://miro.medium.com/v2/resize:fit:875/1*-2eHNctwSfIzebh4XxxSEQ.png)

### Q.  What is $ and ### Q.  do inside @value annotation?

The $ symbol is used to inject property values from various sources, such as properties files, environment variables, and system properties. For example, the following code injects the value of the app.name property from the application.properties file:

e.g.

**@Value(“${app.name}”)**

**private String appName;**

The ### Q.  symbol is used to access SpEL expressions. SpEL (Spring Expression Language) is a powerful expression language that can be used to perform complex operations on property values. For example, the following code injects the value of the app.name property and converts it to uppercase:

e.g.

```java
@Value(“### Q. {‘${app.name}’.toUpperCase()}”)
private String appNameUppercase;**
```
### Q.  What is the stateless bean in spring? name it and explain it.

A stateless bean in Spring Framework is a bean that does not maintain any state between method invocations. This means that the bean does not store any information about the previous invocations, and each method call is handled independently.

Stateless beans are typically used for services that perform actions or calculations, but do not maintain any state between invocations. This can include services that perform mathematical calculations, access external resources, or perform other tasks that do not require the bean to maintain state.

Stateless beans can be implemented as singleton beans, and multiple clients can share the same instance of the bean. Since stateless beans do not maintain any state, they can be easily scaled horizontally by adding more instances of the bean to handle the increased load.

Stateless beans also have the advantage of being simpler and easier to reason about, since they do not have to worry about maintaining state between invocations. Additionally, since stateless beans do not maintain any state, they can be easily serialized and replicated for high availability and scalability.

### Q.  How is the bean injected in spring?

In Spring, a bean is injected (or wired) into another bean using the Dependency Injection (DI) pattern. DI is a design pattern that allows a class to have its dependencies provided to it, rather than creating them itself.

Spring provides several ways to inject beans into other beans, including:

**Constructor injection**: A bean can be injected into another bean by passing it as a constructor argument. Spring will automatically create an instance of the dependent bean and pass it to the constructor.
```java
public class BeanA {  
    private final BeanB beanB;

    public BeanA(BeanB beanB) {  
        this.beanB = beanB;  
    }  
}
```
**Setter injection**: A bean can be injected into another bean by passing it as a setter method argument. Spring will automatically call the setter method and pass the dependent bean.
```java
public class BeanA {  
    private BeanB beanB;  
    
    @Autowired  
    public void setBeanB(BeanB beanB) {  
        this.beanB = beanB;  
    }  
}
```

**Field injection**: A bean can be injected into another bean by annotating a field with the @Autowired annotation. Spring will automatically set the field with the dependent bean.
```java
public class BeanA {  
    @Autowired  
    private BeanB beanB;  
}
```
**Interface injection**: A bean can be injected into another bean by implementing an interface. Spring will automatically set the field with the dependent bean.
```java
public class BeanA implements BeanBUser {  
    @Autowired  
    private BeanB beanB;  
}
```
It’s important to note that, you can use any combination of the above methods, but you should choose the appropriate one depending on your use case.

Also, Spring uses a technique called Autowiring to automatically wire beans together, Autowiring can be done by type, by name, or by constructor.

By default, Spring will try to autowire beans by type, but if there are multiple beans of the same type, it will try to autowire by name using the bean’s name defined in the configuration file.

### Q.  How to handle cyclic dependency between beans?

Let’s say for example: Bean A is dependent on Bean B and Bean B is dependent on Bean A. How does the spring container handle eager & lazy loading?

A cyclic dependency between beans occurs when two or more beans have a mutual dependency on each other, which can cause issues with the creation and initialization of these beans.

There are several ways to handle cyclic dependencies between beans in Spring:

**Lazy Initialization**: By using the @Lazy annotation on one of the beans involved in the cycle, it can be initialized only when it is actually needed.

**@Lazy**

**@Autowired**

**private BeanA beanA;**

**Constructor injection**: Instead of using setter or field injection, you can use constructor injection, which will make sure that the dependencies are provided before the bean is fully initialized.
```java
public class BeanA {  
    private final BeanB beanB;  
    public BeanA(BeanB beanB) {  
        this.beanB = beanB;  
    }  
}
```

**Use a proxy**: A proxy can be used to break the cycle by delaying the initialization of one of the beans until it is actually needed. Spring AOP can be used to create a proxy for one of the beans involved in the cycle.

**Use BeanFactory**: Instead of injecting the bean directly, you can use BeanFactory to retrieve the bean when it’s actually needed.
```java
public class BeanA {

    private BeanB beanB;  
    @Autowired  
    public BeanA(BeanFactory beanFactory) {  
        this.beanB = beanFactory.getBean(BeanB.class);  
    }  
}
```

### Q.  What would you call a method before starting/loading a Spring boot application?

In Spring Boot, there are several methods that can be called before starting or loading a Spring Boot application. Some of the most commonly used methods are:

**main() method**: The main() method is typically the entry point of a Spring Boot application. It is used to start the Spring Boot application by calling the SpringApplication.run() method.

**@PostConstruct method**: The @PostConstruct annotation can be used to mark a method that should be called after the bean has been constructed and all dependencies have been injected. This can be used to perform any necessary initialization before the application starts.

**CommandLineRunner interface**: The CommandLineRunner interface can be implemented by a bean to run specific code after the Spring Application context has been loaded.

**ApplicationRunner interface**: The ApplicationRunner interface can be implemented by a bean to run specific code after the Spring Application context has been loaded and the Application arguments have been processed.

@**EventListener** : The @EventListener annotation can be used to register a method to listen to specific Application events like ApplicationStartingEvent, ApplicationReadyEvent and so on.

### Q.  How to handle exceptions in the spring framework?

There are several ways to handle exceptions in the Spring Framework:

**try-catch block**: You can use a try-catch block to catch and handle exceptions in the method where they occur. This approach is useful for handling specific exceptions that are likely to occur within a particular method.

**@ExceptionHandler annotation**: You can use the @ExceptionHandler annotation on a method in a @Controller class to handle exceptions that are thrown by other methods in the same class. This approach is useful for handling specific exceptions in a centralized way across multiple methods in a controller.

**@ControllerAdvice annotation**: You can use the @ControllerAdvice annotation on a class to define a global exception handler for multiple controllers in your application. This approach is useful for handling specific exceptions in a centralized way across multiple controllers.

**HandlerExceptionResolver interface**: You can implement the HandlerExceptionResolver interface to create a global exception handler for your entire application. This approach is useful for handling specific exceptions in a centralized way across the entire application.

**ErrorPage**: You can define an ErrorPage in your application to redirect to a specific page when a certain exception occurs. This approach is useful for displaying a user-friendly error page when an exception occurs.

**@ResponseStatus annotation**: You can use the @ResponseStatus annotation on an exception class to define the HTTP status code that should be returned when the exception is thrown.

### Q.  How filter work in spring?

In Spring, filters act as interceptors for requests and responses, processing them before and after they reach the actual application logic. They’re like “gatekeepers” that can modify, deny, or allow requests based on predefined rules.

Here’s how they work in a nutshell:

1. **Configuration:**

· You define filters as beans in your Spring configuration.

· Specify the order in which filters should be executed.

2. **Request Flow:**

· When a client sends a request, it goes through each filter in the specified order.

· Each filter can:

· Inspect the request headers, body, and other attributes.

· Modify the request content or headers.

· Decide to continue processing the request or terminate it.

3. **Response Flow:**

· Once the request reaches the application logic and receives a response, the response flows back through the filters in reverse order.

· Filters can again:

· Inspect the response headers and body.

· Modify the response content or headers.

4. **Common Use Cases:**

· Security filters: Validate user authentication, authorize access, and prevent security vulnerabilities.

· Logging filters: Log information about requests and responses for debugging and analysis.

· Compression filters: Compress responses to reduce bandwidth usage.

· Caching filters: Cache frequently accessed resources to improve performance.

Benefits:

· Intercept and modify requests and responses: Provide more control over application behavior.

· Centralize common tasks: Avoid duplicating code for security, logging, etc.

· Chain multiple filters: Achieve complex processing logic by combining multiple filters.

### Q.  What is DispatcherServlet?

DispatcherServlet acts as the central “front controller” for Spring MVC applications. It is a Servlet that receives all incoming HTTP requests and delegates them to appropriate controller classes. The DispatcherServlet is responsible for identifying the appropriate handler method for each request and invoking it, ensuring that the request is processed correctly.

The following example of the Java configuration registers and initializes the DispatcherServlet, which is auto-detected by the Servlet container.
```java
public class MyWebApplicationInitializer implements WebApplicationInitializer {  
    @Override  
    public void onStartup(ServletContext servletContext) {  
        // Load Spring web application configuration  
        AnnotationConfigWebApplicationContext context = new AnnotationConfigWebApplicationContext();  
        context.register(AppConfig.class);  
        // Create and register the DispatcherServlet  
        DispatcherServlet servlet = new DispatcherServlet(context);  
        ServletRegistration.Dynamic registration = servletContext.addServlet("app", servlet);  
        registration.setLoadOnStartup(1);  
        registration.addMapping("/app/*");  
    }  
}
```

### Q.  What is @Controller annotation in spring?

The @Controller annotation is a Spring stereotype annotation that indicates that a class serves as a web controller. It is primarily used in Spring MVC applications to mark classes as handlers for HTTP requests. When a class is annotated with @Controller, it can be scanned by the Spring container to identify its methods as potential handlers for specific HTTP requests.

Spring MVC provides an annotation-based programming model where @Controller and @RestController components use annotations to express request mappings, request input, exception handling, and more. Annotated controllers have flexible method signatures and do not have to extend base classes nor implement specific interfaces. The following example shows a controller defined by annotations:

e.g.
```java
@Controller  
public class HelloController {
    
    @GetMapping("/hello")  
    public String handle(Model model) {  
        model.addAttribute("message", "Hello World!");  
        return "index";  
    }  
}
```

### Q.  How Controller map appropriate methods to incoming requests?

You can use the @RequestMapping annotation to map requests to controller methods. It has various attributes to match by URL, HTTP method, request parameters, headers, and media types. You can use it at the class level to express shared mappings or at the method level to narrow down to a specific endpoint mapping.Request Mapping Process:

There are also HTTP method-specific shortcut variants of @RequestMapping:

@GetMapping

@PostMapping

@PutMapping

@DeleteMapping

@PatchMapping

**Request Reception**: The DispatcherServlet receives an incoming HTTP request containing the request URI, HTTP method (GET, POST, PUT, DELETE, etc.), and request parameters.

**Mapping Lookup**: The DispatcherServlet utilizes a HandlerMapping component to lookup the appropriate handler method for the received request. The HandlerMapping maintains a registry of mappings between request patterns and handler methods.

**Pattern Matching**: The HandlerMapping compares the request URI and HTTP method against the registered request patterns. It uses pattern matching rules to identify the most specific matching pattern.

**Handler Method Identification**: Once the matching pattern is identified, the HandlerMapping retrieves the corresponding handler method from its registry. This handler method is the one responsible for handling the incoming request.

**Method Invocation**: The DispatcherServlet invokes the identified handler method, passing the request object as an argument. The handler method processes the request’s logic and generates an appropriate response.

**Response Handling**: After the handler method completes its execution, the DispatcherServlet receives the generated response object. It prepares the response by setting appropriate headers and content, and sends the response back to the client.

This is the sample program,
```java
@RestController  
@RequestMapping("/persons")  
class PersonController {  
    @GetMapping("/{id}")  
    public Person getPerson(@PathVariable Long id) {  
    // …  
    }  

    @PostMapping  
    @ResponseStatus(HttpStatus.CREATED)  
    public void add(@RequestBody Person person) {  
    // …  
    }  
}
```
### Q.  What is the difference between @Controller and @RestController in Spring MVC?

**@Controller:**

Designates a class as a controller for traditional MVC applications.

Methods typically return a view name (String), which is resolved by a view resolver to render a view (e.g., an HTML page).

Can also return void, indicating that the view name is the same as the request path.

Can use @ResponseBody on individual methods to return data directly (e.g., JSON), but this isn’t the default behavior.

**@RestController:**

Specialized controller for building RESTful web services.

Implicitly applies @ResponseBody to all handler methods, so they return data directly in the response body, typically in JSON or XML format.

No need for view resolution or manual settings for returning data.

Simplifies the development of REST APIs.

When to Use Each:

Use @Controller for traditional web applications that focus on rendering views and returning HTML content.

Use @RestController for building RESTful APIs that primarily return data in formats like JSON or XML.

Example:
```java
@Controller  
public class MyController {  
    @GetMapping("/hello")  
    public String hello() {  
        return "hello"; // Returns the view name "hello"  
    }  
}  
  
@RestController  
public class MyRestController {  
    @GetMapping("/greeting")  
    public String greeting() {  
        return "Hello, World!"; // Returns "Hello, World!" as JSON or XML  
    }  
}
```
### Q.  Difference between @Requestparam and @Pathparam annotation?

**@Requestparam:**

You can use the @RequestParam annotation to bind Servlet request parameters (that is, query parameters or form data) to a method argument in a controller.

Here code example,
```java
@Controller  
@RequestMapping("/pets")  
    public class EditPetForm {  

    @GetMapping  
    public String setupForm(@RequestParam("petId") int petId, Model model) {  
        Pet pet = this.clinic.loadPet(petId);  
        model.addAttribute("pet", pet);  
        return "petForm";  
    }  
}
```

Using @RequestParam we are binding petId

By default, method parameters that use this annotation are required, but you can specify that a method parameter is optional by setting the @RequestParam annotation’s required flag to false or by declaring the argument with an java.util.Optional wrapper.

**@Pathparam**

Function:

-   It allows you to map variables from the request URI path to method parameters in your Spring controller.
-   This gives you a cleaner and more flexible way to handle dynamic data in your API.

Usage:

-   You place the @Pathparam annotation on a method parameter.
-   Inside the annotation, you specify the name of the variable in the URI path that should be bound to the parameter.

![](https://miro.medium.com/v2/resize:fit:875/1*btOPpW2VbIepZXXUbbTt_g.png)

### Q.  What is the session scope used for?

session scope is a way of managing the lifecycle of objects that are bound to a specific HTTP session. When an object is created in the session scope, it is stored in the session and is accessible to all requests that belong to the same session. This can be useful for storing user-specific information or maintaining state across multiple requests.

### Q.  Difference between @component @Service @Controller @Repository annotation in Spring?

![](https://miro.medium.com/v2/resize:fit:875/1*yV-setti8pMfvQMGmHJO8A.png)

### Q.  Spring-MVC flow in detail?

Spring MVC is a popular web framework for building Java web applications. It provides a Model-View-Controller architecture that separates the application logic into three components: the model, the view, and the controller. The Spring MVC flow involves the following steps:

![](https://miro.medium.com/v2/resize:fit:875/1*jA-1kNaSsVnUqf6wvBFtaQ.png)

**The client sends a request**: The user sends a request to the Spring MVC application through a browser or any other client application.

**DispatcherServlet receives the request**: The DispatcherServlet is a central controller in the Spring MVC architecture. It receives the request from the client and decides which controller should handle the request.

**HandlerMapping selects the appropriate controller**: The HandlerMapping component maps the request URL to the appropriate controller based on the URL pattern configured in the Spring configuration file.

**Controller processes the request**: The controller handles the request and performs the necessary processing logic. It may interact with the model component to retrieve data or update the data.

**Model updates the data**: The model component manages the data and provides an interface for the controller to retrieve or update the data.

**ViewResolver selects the appropriate view**: The ViewResolver component maps the logical view name returned by the controller to the actual view template.

**View renders the response**: The view template is rendered to generate the response. It may include data from the model component.

**DispatcherServlet sends the response**: The DispatcherServlet sends the response back to the client through the appropriate view technology, such as JSP, HTML, or JSON.

The Spring MVC flow is a cyclical process, as the client may send additional requests to the application, and the cycle repeats.

### Q.  What are the most common Spring MVC annotations?

**Controller Annotations:**

**@Controller**: Designates a class as a controller, responsible for handling HTTP requests and rendering responses.

**@RestController**: A specialized version of @Controller that implicitly adds @ResponseBody to all handler methods, indicating that they should directly write data to the response body, often in JSON or XML format.

**Request Mapping Annotations:**

@RequestMapping: Maps web requests to specific controller methods based on URL patterns, HTTP methods (GET, POST, PUT, DELETE, etc.), request parameters, and headers.

@GetMapping, @PostMapping, @PutMapping, @DeleteMapping, @PatchMapping: Convenient shortcuts for mapping specific HTTP methods.

@PathVariable: Binds a method parameter to a path segment variable in the URL.

@RequestParam: Binds a method parameter to a query parameter in the request URL.

**Data Binding Annotations:**

@ModelAttribute: Populates a model attribute with an object, making it available to the view.

@RequestParam: Binds a request parameter to a method argument.

@RequestHeader: Binds a request header to a method argument.

@RequestBody: Maps the request body to a method argument, often used for JSON or XML data.

**Response Handling Annotations:**

@ResponseBody: Indicates that the method’s return value should be written directly to the response body, bypassing view resolution.

@ResponseStatus: Sets the HTTP status code of the response.

**Exception Handling Annotations:**

@ExceptionHandler: Defines a method to handle exceptions of a specific type, providing a centralized way to manage errors.

**Other Useful Annotations:**

@SessionAttribute: Accesses a session attribute.

@ModelAttribute: Adds an attribute to the model for all handler methods in a controller.

@InitBinder: Customizes data binding and validation for a controller.

@CrossOrigin: Enables cross-origin requests for a controller or specific handler methods.

### Q.  Can singleton bean scope handle multiple parallel requests?

A singleton bean in Spring has a single instance that is shared across all requests, regardless of the number of parallel requests. This means that if two requests are processed simultaneously, they will share the same bean instance and access to the bean’s state will be shared among the requests.

However, it’s important to note that if the singleton bean is stateful, and the state is shared among requests, this could lead to race conditions and other concurrency issues. For example, if two requests are trying to modify the same piece of data at the same time, it could lead to data inconsistencies.

To avoid these issues, it’s important to make sure that any stateful singleton beans are designed to be thread-safe. One way to do this is to use synchronization or other concurrency control mechanisms such as the synchronized keyword, Lock or ReentrantLock classes, or the @Transactional annotation if the bean is performing database operations.

On the other hand, if the singleton bean is stateless, it can handle multiple parallel requests without any issues. It can be used to provide shared functionality that doesn’t depend on the state of the bean.

In conclusion, a singleton bean can handle multiple parallel requests, but it’s important to be aware of the state of the bean and to ensure that it’s designed to be thread-safe if it has a shared state.

### Q.  Tell me the Design pattern used inside the spring framework.

The Spring Framework makes use of several design patterns to provide its functionality. Some of the key design patterns used in Spring are:

· **Inversion of Control (IoC)**: This pattern is used throughout the Spring Framework to decouple the application code from the framework and its components. The IoC container is responsible for managing the lifecycle of beans and injecting dependencies between them.

· **Singleton**: A singleton pattern is used to ensure that there is only one instance of a bean created in the Spring IoC container. The singleton pattern is used to create a single instance of a class, which is shared across the entire application.

· **Factory**: The factory pattern is used in Spring to create objects of different classes based on the configuration. Spring provides a factory pattern to create beans, which is based on the factory method design pattern.

· **Template Method**: The template method pattern is used in Spring to provide a common structure for different types of operations. Spring provides several template classes such as JdbcTemplate, Hibernate Template, etc. that provide a common structure for performing database operations.

· **Decorator**: The decorator pattern is used in Spring to add additional functionality to existing beans. The Spring AOP (Aspect-Oriented Programming) module uses the decorator pattern to add additional functionality to existing beans through the use of proxies.

· **Observer**: The observer pattern is used in Spring to notify other beans of changes to the state of a bean. Spring provides the ApplicationEvent and ApplicationListener interfaces, which can be used to implement the observer pattern.

· **Command**: The command pattern is used in Spring to encapsulate the execution of a particular piece of code in a command object. This pattern is used in Spring to create reusable and testable code.

· **Façade**: The façade pattern is used in Spring to simplify the interface of a complex system. The Spring Framework uses the façade pattern to provide a simplified interface for interacting with its components.

These are just a few examples of the design patterns used in Spring, there are many more. Spring framework makes use of these patterns to provide a consistent and simple way to build applications, making it easier to manage complex systems.

### Q.  How do factory design patterns work in terms of the spring framework?

In Spring, the factory design pattern is used to create objects of different classes based on the configuration. The Spring IoC container uses the factory pattern to create beans, which is based on the factory method design pattern.

The factory method is a design pattern that provides a way to create objects of different classes based on a factory interface. In Spring, the IoC container acts as the factory, and the factory interface is represented by the BeanFactory or ApplicationContext interfaces.

The IoC container is responsible for creating and managing the lifecycle of beans. When you define a bean in the configuration, the IoC container will use the factory pattern to create an instance of the bean. The IoC container will then manage the lifecycle of the bean, including injecting dependencies, initializing the bean, and destroying the bean when it is no longer needed.

Here’s an example of how you can define a bean in Spring using the factory design pattern:
```java
@Configuration  
public class MyConfig {  
    @Bean  
    public MyService myService() {  
        return new MyService();  
    }  
}
```

In this example, the myService() method is annotated with @Bean. This tells Spring to create an instance of the MyService class when the IoC container is created. The IoC container will use the factory pattern to create the instance and manage its lifecycle.

Another way to use factory pattern in spring is to use FactoryBean interface, which allows you to create beans that are created by a factory method, it’s a factory of bean. The FactoryBean interface defines a single method, getObject(), which returns the object that should be exposed as the bean in the Spring application context.

### Q.  How the proxy design pattern is used in spring?

The proxy design pattern is used in Spring to add additional functionality to existing objects. The Spring Framework uses the proxy pattern to provide AOP (Aspect-Oriented Programming) functionality, which allows you to add cross-cutting concerns, such as logging, security, and transaction management, to your application in a modular and reusable way.

In Spring, AOP proxies are created by the IoC container, and they are used to intercept method calls made to the target bean. This allows you to add additional behaviour, such as logging or security checks, before or after the method call is made to the target bean.

AOP proxies are created using one of three proxy types: JDK dynamic proxies, CGLIB proxies, or AspectJ proxies.

JDK dynamic proxies: This is the default proxy type in Spring, and it is used to proxy interfaces.

CGLIB proxies: This proxy type is used to proxy classes, and it works by creating a subclass of the target bean.

AspectJ proxies: This proxy type uses the AspectJ library to create proxies, and it allows you to use AspectJ pointcuts and advice in your application.

Spring uses the proxy pattern to provide AOP functionality by generating a proxy object that wraps the target bean. The proxy object will intercept method calls made to the target bean, and it will invoke additional behavior, such as logging or security checks, before or after the method call is made to the target bean.

Here’s an example of how you can use Spring AOP to add logging to a bean:
```java
@Aspect  
@Component  
    public class LoggingAspect {  

    @Before("execution(* com.example.service.*.*(..))")  
    public void logBefore(JoinPoint joinPoint) {  
        log.info("Started method: " + joinPoint.getSignature().getName());  
    }  
}
```

In this example, the LoggingAspect class is annotated with @Aspect and @Component to make it a Spring bean. The @Before annotation is used to specify that the logBefore() method should be executed before the method call is made to the target bean. The logBefore() method uses the JoinPoint argument to log the name of the method that is being called.

### Q.  What if we call singleton bean from prototype or prototype bean from singleton How many objects returned?

When a singleton bean is called from a prototype bean or vice versa, the behavior depends on how the dependency is injected.

If a singleton bean is injected into a prototype bean, then each time the prototype bean is created, it will receive the same instance of the singleton bean. This is because the singleton bean is only created once during the startup of the application context, and that same instance is then injected into the prototype bean each time it is created.

On the other hand, if a prototype bean is injected into a singleton bean, then each time the singleton bean is called, a new instance of the prototype bean will be created. This is because prototype beans are not managed by the container, and a new instance is created each time a dependency is injected.

Here’s an example to illustrate this:
```java
@Component  
@Scope("singleton")  
public class SingletonBean {  
// code for singleton bean  
}  

@Component  
@Scope("prototype")  
public class PrototypeBean {  
    @Autowired  
    private SingletonBean singletonBean;  
    // code for prototype bean  
}
```

In this example, when a prototype bean is created and injected with the singleton bean, it will receive the same instance of the singleton bean each time it is created. However, if the singleton bean is created and injected with the prototype bean, it will receive a new instance of the prototype bean each time it is called.

It’s important to note that mixing singleton and prototype scopes in a single application context can lead to unexpected behavior and should be avoided unless necessary. It’s best to use one scope consistently throughout the application context.

### Q.  Spring boot vs spring why choose one over the other?

Here are some reasons to choose Spring Framework:

· You need a comprehensive set of features and capabilities for your application.

· You want to build a modular application where you can pick and choose only the components that you need.

· You need a high degree of flexibility and customization in your application.

Here are some reasons to choose Spring Boot:

· You want to quickly set up a stand-alone Spring application without needing to do a lot of configurations.

· You want to take advantage of pre-configured dependencies and sensible defaults.

· You want to easily deploy your application as a self-contained executable JAR file.

Overall, both Spring and Spring Boot are powerful frameworks that can be used to build enterprise-level applications. The choice between them depends on the specific needs of your application and the level of flexibility and customization that you require.

### Q.  What is RestTemplate in spring?

RestTemplate is a powerful tool in Spring for making HTTP requests to external REST APIs. It simplifies client-side communication by providing high-level abstractions over low-level HTTP details. Imagine it as a handy Swiss Army knife for interacting with external services.

**Key Uses:**

· Consuming data from external RESTful APIs

· Interacting with internal microservices within your application

· Testing RESTful APIs

· Building custom integrations with external systems

In a nutshell: RestTemplate takes the pain out of sending HTTP requests in Spring, offering a convenient and flexible way to connect your application to the outside world.

### Q.  What are all HTTP Clients Available in Spring and Spring Boot?

These are the various clients available

RestTemplate, WebClient, HttpClient, RestClient, OkHttp

### Q.  What is an HttpMessageConverter in Spring REST?

It’s a key interface that handles the conversion of HTTP requests and responses between Java objects and their corresponding message formats (e.g., JSON, XML).

It acts as a bridge between the controller layer and the message payload, ensuring data compatibility.

**How It Works:**

**Incoming Request Handling:**

· When a request arrives, Spring looks for a suitable HttpMessageConverter based on the Content-Type header of the request.

· If a match is found, the converter reads the request body and converts it into a Java object that the controller can process.

**Outgoing Response Handling:**

· When a controller returns an object, Spring again finds an appropriate HttpMessageConverter based on the Accept header of the request or a default converter.

· The converter serializes the object into the desired format (e.g., JSON, XML) and writes it to the response body.

**Common Converters:**

· MappingJackson2HttpMessageConverter (for JSON, using Jackson library)

· StringHttpMessageConverter (for plain text)

· FormHttpMessageConverter (for form data)

· ByteArrayHttpMessageConverter (for binary data)

· Jaxb2RootElementHttpMessageConverter (for XML, using JAXB)

### Q.  How to consume RESTful Web Service using Spring MVC?

1. **Inject RestTemplate:**

Obtain a RestTemplate instance, which is Spring’s central class for making HTTP requests.

Inject it into your controller or service class using dependency injection.

2. **Make HTTP Requests:**

Use RestTemplate methods for various HTTP operations:

getForObject(url, responseType) : Get data for GET requests.

postForObject(url, requestBody, responseType) : Send data for POST requests.

put(url, requestBody) : Update data using PUT requests.

delete(url) : Delete resources using DELETE requests.

exchange(url, method, requestEntity, responseType) : For advanced control over requests and responses.

3. **Map Response Data:**

RestTemplate automatically converts response bodies into Java objects based on the expected response type.

If the response is JSON, it uses MappingJackson2HttpMessageConverter by default.

You can customize message converters if needed.
```java
@RestController  
public class MyController {  
    @Autowired  
    private RestTemplate restTemplate;  
    @GetMapping("/fetch-data")  
    public User fetchUserData() {  
        String url = "https://api.example.com/users/123";  
        User user = restTemplate.getForObject(url, User.class);  
        return user;  
    }  
}
```