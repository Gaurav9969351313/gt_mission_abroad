# 21 Software Design Pattern Interview Questions and Answers

### **1. What is difference between Builder and Factory Pattern?**

This kind of questions are very common on Java interviews where interviewer test your understanding of patterns. While both Builder and Factory pattern are used to create objects and they are creational design pattern there is a key difference between them.

**Builder pattern expose the creation logic** and allows you to create the object as you want by supplying additional/optional properties and then calling `build()` method but **Factory pattern doesn’t expose the creation logic**, its hidden inside `getInstance()` method.

![](https://miro.medium.com/v2/resize:fit:875/0*CCZ6ImVoCIPuUbKU.png)

### 2. When will you use Factory or Builder Design pattern?

As I said, factory pattern is used when you want to create object without exposing creation logic while Builder pattern is used when constructor accept too many arguments and most of them are optional.

In other words, the Builder pattern is used when we want to create objects that require the step-by-step initialization of many attributes.

The Builder pattern provides a way to create an object by calling a series of methods that set the required attributes. It’s useful when we have a complex object with many attributes that need to be initialized in a particular order.

### **3. You are coding a class which is responsible for sending HTTP request to external clients and you know that other applications will use it? What design consideration will you make while designing/coding this class?**

This question is normally asked to experienced developer to see how much coding they have done and whether they remember best practices while coding or not. They key here is **modularity** because your code should be easy for other modules and app to be reused.

For example, when designing a class that is responsible for sending HTTP requests to external clients, there are a number of design considerations that should be taken into account for example:

1.  **Separation of Concerns**  
    The class should be designed to focus on sending HTTP requests and handling the response, while delegating other concerns (such as data validation and processing) to other classes or components.
2.  **Encapsulation**  
    The class should encapsulate the HTTP request and response logic to promote modularity and maintainability. This will allow other parts of the application to use the class without having to worry about the implementation details.
3.  **Configuration**  
    The class should be designed to allow for flexible configuration of parameters such as timeouts, retries, and connection settings. This will allow other applications to easily customize the behavior of the class to suit their needs.
4.  **Error Handling**  
    The class should be designed to handle errors and exceptions gracefully, and provide clear and informative error messages to users. This will help to ensure that other applications can easily diagnose and fix any issues that arise.
5.  **Performance**  
    The class should be designed to be efficient and performant, minimizing latency and resource usage as much as possible. This will help to ensure that other applications can make use of the class without encountering performance issues.
6.  **Security**  
    The class should be designed to ensure the security of any sensitive information that is transmitted through HTTP requests. This may involve using encryption and authentication mechanisms, as well as complying with any relevant security standards or regulations.
7.  **Testing**  
    The class should be designed to be easily testable, with appropriate unit and integration tests to ensure that it functions correctly and meets the requirements of other applications that use it.

By taking these design considerations into account, the resulting class you will create will be more robust, maintainable, and flexible, and can withstand test of time on production.

### 4. What are design patterns in software engineering and why are they important?

Design patterns are nothing but reusable solutions to commonly occurring software design problems like flexibility, scalability, performance, security etc.

They provide a structured approach to solve problems, improve code quality, and make software more maintainable, extensible, and scalable. By learning and applying design patterns, developers can write better code in less time.

### 5. What is the difference between a creational, structural, and behavioral design pattern?

GOF Patterns or object oriented patterns are divided into 3 main categories, creational, structural and behavioral. As the name suggests, Creational patterns deal with object creation mechanisms, trying to create objects in a manner suitable for the situation.

Structural patterns deal with object composition, simplifying the way objects relate to one another. Behavioral patterns deal with communication between objects, defining the way objects collaborate and interact to achieve specific tasks.

### 6. Can you explain the Singleton design pattern in Java?

The Singleton pattern is a creational pattern that ensures that a class has only one instance and provides a global point of access to it. The instance is created lazily, the first time the `getInstance()` method is called.

The best thing about this patter is that provide a clear and controlled access point to a single instance, and avoiding duplicate object creation.

On the flip side, **its now treated as anti pattern because of difficulty in testing**, potential for violating the Single Responsibility Principle, and issues with concurrent access.

![](https://miro.medium.com/v2/resize:fit:875/0*Lj6db3-jEfjaIhUy.png)

### 7. What is the Factory Method design pattern and how is it used in Java?

The Factory Method design pattern is a creational pattern that provides an interface for creating objects but allows sub-classes to decide which class to instantiate.

In Java, it is implemented using an abstract creator class that defines the factory method and a concrete subclass that implements the factory method to create the desired objects.

Advantage of this Software design pattern include encapsulating object creation and providing extensibility, while cons include complexity and a potential for creating too many sub-classes.

![](https://miro.medium.com/v2/resize:fit:875/0*5PP2Y70iFPaaT1L4.jpg)

### 8. What is difference between a Factory and Abstract Factory pattern in Java?

The Factory Method and Abstract Factory design patterns are both creational patterns that provide ways to create objects. However, they have some key differences in their approach to object creation.

The **Factory Method is a design pattern that provides an interface for creating objects in a super-class**, but allows subclasses to alter the type of objects that will be created.

This is achieved by defining a factory method in the superclass that returns an object of a specific type, and then overriding this method in sub-classes to return objects of a subclass-specific type.

The **Abstract Factory pattern, on the other hand, provides a way to create families of related or dependent objects without specifying their concrete classes.**

This is achieved by creating an abstract factory class that defines a set of methods for creating objects, and then implementing these methods in concrete factory classes.

The concrete factory classes return objects of a specific type, and clients use these objects through the abstract factory interface.

In summary, the Factory Method pattern focuses on creating objects of a single type, while the Abstract Factory pattern focuses on creating families of related objects. The choice between the two patterns depends on the specific requirements of the software system being developed.

Here is a nice diagram which also show the difference between abstract and factory design pattern:

![](https://miro.medium.com/v2/resize:fit:875/0*ttw9RL5UFkEy21I1.png)

### 9. Can you explain the Abstract Factory design pattern in detail for Java?

The Abstract Factory pattern provides an interface for creating families of related or dependent objects without specifying their concrete classes. In other words, it allows you to create objects that are related to each other or have dependencies, but without specifying the actual classes of those objects.

The main goal of the Abstract Factory pattern is to provide an interface for creating families of objects that can be used interchangeably. This can be useful when you want to create a set of related objects that can be easily swapped in and out of your application without affecting its overall behavior.

The Abstract Factory pattern is often used in situations where the client code needs to be decoupled from the object creation process.

For example, suppose you have an application that needs to generate reports. The reports can be generated in different formats, such as HTML, PDF, or CSV.

You could create a `ReportGenerator` interface that defines a method for generating reports. Then you could create three different factories that create object of different `ReportGenerator` based upon format.

### 10. Can you explain the Prototype design pattern in Java? When to use it?

The Prototype design pattern in Java allows creating new objects by cloning existing objects instead of creating new ones from scratch. It’s useful when the object creation process is expensive and time-consuming. The pattern provides an efficient way to create multiple copies of an object while reducing the cost of object creation.

### 11. What is difference between Adapter and Bridge pattern?

The Adapter and Bridge design patterns are used to decouple an abstraction from its implementation. However, there are some differences between them.

The Adapter pattern is used to convert the interface of a class into another interface that the client expects. It allows two or more incompatible interfaces to work together.

The Adapter pattern can be used when we have an existing class, and we want to use it with other classes that have a different interface. We create an adapter class that implements the target interface and uses the existing class to implement the interface methods.

The Bridge pattern is used to separate the abstraction from its implementation so that they can vary independently. It is used when we want to change the implementation of a class without affecting its interface.

The Bridge pattern consists of two layers of abstraction: the abstraction layer and the implementation layer. The abstraction layer provides the high-level interface, and the implementation layer provides the low-level implementation details.

In summary, the Adapter pattern is used when we want to make two incompatible interfaces work together, while the Bridge pattern is used when we want to separate the interface from its implementation.

### 12. What is the Composite design pattern and how is it used in Java?

The Composite pattern is a structural design pattern that allows you to treat a group of objects as a single object. In other words, it lets you create a tree structure of objects and work with the tree as if it were a single object.

In the Composite pattern**, there is a “composite” class that contains a collection of “component” objects.** The component objects can be other composites or leaf nodes (objects that have no children). Both composites and leaf nodes implement a common interface, so they can be treated the same way by client code.

The **Composite pattern** is useful when you need to represent a hierarchical structure of objects and want to be able to treat individual objects and groups of objects uniformly. It also allows you to add and remove objects from the hierarchy dynamically at runtime.

In Java, the Composite pattern can be used to represent a file system, where a directory can contain files and other directories. The composite class would be the directory, while the component classes would be the files and sub-directories.

Here’s an example of how the Composite pattern might be implemented in Java:
```java
interface FileSystemItem {  
    public String getName();  
    public void print();  
}  
  
  
public class File implements FileSystemItem {  
    private String name;  
    public File(String name) {  
        this.name = name;  
    }  
    public String getName() {  
        return name;  
    }  
    public void print() {  
        System.out.println("File: " + name);  
    }  
}  
  
public class Directory implements FileSystemItem {  
    private String name;  
    private List<FileSystemItem> items = new ArrayList<>();  
    public Directory(String name) {  
        this.name = name;  
    }  
    public String getName() {  
        return name;  
    }  
    public void add(FileSystemItem item) {  
        items.add(item);  
    }  
    public void remove(FileSystemItem item) {  
        items.remove(item);  
    }  
    public void print() {  
        System.out.println("Directory: " + name);  
        for (FileSystemItem item : items) {  
            item.print();  
        }  
    }  
}
```
In this example, the `FileSystemItem` interface is the common interface implemented by both files and directories. The `File` class is a leaf node, while the `Directory` class is a composite that can contain other `FileSystemItem` objects. The `print` method prints out the name of the file or directory, as well as the names of any child items if it's a directory.

### 13. Can you explain the Decorator design pattern in Java? When did you used Decorator pattern in your code?

The Decorator pattern is a structural design pattern that allows behavior to be added to an individual object, either statically or dynamically, without affecting the behavior of other objects from the same class.

In this pattern, a decorator class wraps the original class, and it provides additional functionality keeping class methods signature intact. This pattern is often used when we have to add functionality to an object at runtime, dynamically.

The following is an example of the Decorator pattern in Java, where we have an interface Pizza and concrete implementation of that interface `PlainPizza`. We want to add extra functionality to the `PlainPizza` like cheese or Mushroom topping using decorators, so that we can create different types of pizzas at runtime.
```java
// Pizza interface  
public interface Pizza {  
 public String getDescription();  
 public double getCost();  
}  
  
// PlainPizza class  
public class PlainPizza implements Pizza {  
 public String getDescription() {  
 return "Plain Pizza";  
 }  
  public double getCost() {  
    return 4.00;  
  }  
}  
  
  
// ToppingDecorator abstract class  
public abstract class ToppingDecorator implements Pizza {  
 protected Pizza pizza;  
public ToppingDecorator(Pizza pizza) {  
 this.pizza = pizza;  
 }  
public String getDescription() {  
 return pizza.getDescription();  
 }  
public double getCost() {  
 return pizza.getCost();  
 }  
}  
  
  
// CheeseTopping concrete decorator class  
public class CheeseTopping extends ToppingDecorator {  
 public CheeseTopping(Pizza pizza) {  
 super(pizza);  
 }  
public String getDescription() {  
 return pizza.getDescription() + ", Cheese Topping";  
 }  
public double getCost() {  
 return pizza.getCost() + 1.00;  
 }  
}  
  
  
// MushroomTopping concrete decorator class  
public class MushroomTopping extends ToppingDecorator {  
 public MushroomTopping(Pizza pizza) {  
 super(pizza);  
 }  
public String getDescription() {  
 return pizza.getDescription() + ", Mushroom Topping";  
 }  
public double getCost() {  
 return pizza.getCost() + 2.50;  
 }  
}
```
In the above code, `PlainPizza` class implements Pizza interface, which has two methods `getDescription()` and getCost(). ToppingDecorator abstract class implements the Pizza interface and provides a reference to the Pizza interface. The `CheeseTopping` and `MushroomTopping` classes are concrete decorators that extend the `ToppingDecorator` abstract class and add additional functionality.

We can create different types of pizzas with different toppings at runtime as follows:
```java
// Create a plain pizza  
Pizza pizza = new PlainPizza();  
// Add cheese topping  
pizza = new CheeseTopping(pizza);  
// Add Mushroom topping  
pizza = new MushroomTopping(pizza);  
// Print the pizza description and cost  
System.out.println(pizza.getDescription());  
System.out.println(pizza.getCost());
```
The output will be:

Plain Pizza, Cheese Topping, Mushroom Topping  
7.5

We can add more toppings dynamically by creating new concrete decorator classes. This way, we can add or remove functionalities at runtime without affecting the underlying class.

The _Decorator pattern is very useful when we have a large number of different combinations of object features_, and it allows us to create these combinations dynamically.

### 14. When should you use Facade design Pattern?

You should use the Facade design pattern when you have a complex system with many different parts, and you want to provide a simplified interface for clients to interact with the system.

The Facade pattern provides a single, high-level interface that encapsulates the complexities of the underlying system and makes it easier for clients to use.

This pattern can also help to reduce coupling between the client and the system, since the client only needs to interact with the facade, rather than directly with the various components of the system.

The **Facade pattern is especially useful when you need to refactor a large and complex code-base,** since it allows you to introduce a simplified interface without having to change the underlying implementation.

![](https://miro.medium.com/v2/resize:fit:755/0*eXGwwImzxQP-AusW.png)

### 15. Can you explain the Flyweight design pattern in Java? When did you used it?

The Flyweight design pattern is used to reduce memory usage by sharing data across objects. It involves separating intrinsic and extrinsic object data, and using shared objects to represent the intrinsic data. I have not personally used it, but it can be used in scenarios where a large number of objects need to be created and memory usage needs to be optimized.

### 16. What is the Proxy design pattern and how is it used in Java?

The Proxy design pattern provides a surrogate or placeholder for another object to control access to it.

In Jav_a, this pattern is used to provide a layer of indirection to an object_, so that clients interact with the proxy instead of the real object. **This can be used to implement access control, logging, or remote communication, among other things.**

![](https://miro.medium.com/v2/resize:fit:875/0*PmGQLPi4dTyegUla.gif)

### 17. Can you explain the Chain of Responsibility design pattern in Java?

The Chain of Responsibility design pattern is a behavioral pattern that allows a request to be passed through a chain of handlers until one of them handles the request. _Each handler in the chain has the opportunity to handle the request or pass it on to the next handler._ It helps to achieve loose coupling between sender and receiver.

### 18. What is the Command design pattern and how is it used in Java?

The Command design pattern encapsulates a request as an object, thereby allowing you to parameterize clients with different requests, queue or log requests, and **support un-doable operations**.

In Java, the command pattern is used for event handling, multi-level undo-redo, thread pools, and more.

It also **promotes loose coupling between request sender and receiver**, and allows for extensibility of commands.

![](https://miro.medium.com/v2/resize:fit:875/0*5Xc6T9AuPWTTE7zx.png)

### 19. Can you explain the Interpreter design pattern in Java? When to use it? What are its pros and cons?

The Interpreter design pattern provides a way to define the syntax of a language and interpret sentences or expressions in that language. It is useful for implementing compilers or for processing expressions in domain-specific languages.

The pros of this pattern are its extensibility, ease of use, and modular design. However, it can be difficult to implement and may not perform well for complex or deeply nested expressions.

### 20. What is the Iterator design pattern and how is it used in Java? When did you use it? What are its pros and cons?

The Iterator design pattern provides a way to traverse a collection of objects in a standardized way without exposing the underlying implementation.

In Java, the Iterator interface is used to implement this pattern. It allows the client to access elements of a collection sequentially without knowing the internal structure of the collection.

I have not used the Iterator pattern personally but it can be used to implement a custom pagination logic for a web application**.**

**The pros of using this** **pattern include separation of concerns, flexibility, and abstraction**. The cons include added complexity and potential performance overhead due to the additional abstraction layer.

![](https://miro.medium.com/v2/resize:fit:625/0*lXY260osXNpZgMfv.png)

### 21. When to use the Mediator design pattern in Java?

The Mediator design pattern is useful when you have a set of objects that interact with each other in complex ways, and you want to avoid tight coupling between those objects. This pattern promotes loose coupling by allowing objects to communicate through a central mediator, rather than directly with each other.

Here are some common scenarios where you might want to use the _Mediator design pattern i_n Java:

1.  When you have a set of objects that need to interact with each other in complex ways, and you want to avoid tight coupling between those objects.
2.  When you have a large number of objects that need to communicate with each other, and you want to simplify the communication process.
3.  When you want to provide a central point of control for your application’s behavior, and you don’t want individual objects to have too much control over the system.
4.  When you want to be able to modify the behavior of your application at runtime, by swapping out the mediator with a different implementation.

An example of th**e Mediator design pattern in action might be a chat room application**, where multiple users need to communicate with each other. Rather than having each user communicate directly with every other user in the chat room, the application might provide a central mediator that manages all of the communication between users.

The mediator might handle tasks like routing messages, enforcing rules for participation, and maintaining a list of active users. By using the Mediator pattern, the chat room application can be more flexible and easier to maintain, since each user doesn’t need to be aware of all the other users in the room.

### 22. What is the Observer design pattern and how is it used in Java?

The Observer pattern is a behavioral design pattern that defines a one-to-many dependency between objects so that when one object changes state, all its dependents are notified and updated automatically.

In Java, the Observer pattern is implemented using the built-in interfaces `Observer` and `Observable`. The `Observable` class represents the object being observed, while the `Observer` interface represents the objects that are observing the `Observable`.

To use the Observer pattern, you first define an `Observable` object and its corresponding `Observer` objects. The `Observable` object maintains a list of its observers, and when its state changes, it calls the `notifyObservers()` method to notify all its observers of the change. The `Observer` objects implement the `update()` method, which is called by the `Observable` object to update the observer with the new state.

For example, suppose you have a `Stock` class that represents a stock in a stock market. You could define an `Observable` subclass called `StockMarket` that maintains a list of `Stock` objects and notifies its observers when the prices of these stocks change.

You could then define an `Observer` interface called `StockObserver` that defines the `update()` method, which is called by the `StockMarket` object to update the observer with the new stock prices. Finally, you could define a `Trader` class that implements the `StockObserver` interface and receives notifications from the `StockMarket` object when the prices of the stocks it is interested in change.

![](https://miro.medium.com/v2/resize:fit:839/0*9O4yKDsXTxqp8pva.jpg)

---
# 21 Essential System Design Building Blocks for Software Engineers

## 1. Content Delivery Network (CDN)

A **CDN** improves the performance of websites by delivering content from edge servers closer to the user. This minimizes latency, ensures faster load times, and enhances user experience.

**Example:** Cloudflare, Akamai

![](https://miro.medium.com/v2/resize:fit:875/1*kj9kgMgiVB_NHQ9ceBUDGQ.jpeg)

## 2 Databases

Databases are core components of nearly every system, enabling persistent storage and efficient retrieval of structured or unstructured data.

From relational databases like PostgreSQL and MySQL to NoSQL options like MongoDB and Cassandra, different databases are chosen based on scalability, consistency, latency, and data modeling needs.

They support features such as indexing, transactions, and replication, which are critical for performance, reliability, and fault tolerance.

Designing systems with the right database ensures optimal query performance, data integrity, and system scalability.

![](https://miro.medium.com/v2/resize:fit:875/1*sJ8Ma5fvqRsP8ro0pj_xJw.png)

## 3. Rate Limiter

A Rate Limiter is a control mechanism used to regulate the number of requests a client can make to a service within a given time window.

It’s essential in protecting systems from abuse, ensuring fair usage, and managing traffic spikes. Techniques like token bucket, leaky bucket, and fixed window counters help enforce rate limits effectively.

Rate limiters are often deployed in API gateways, authentication services, and distributed systems to maintain system stability and avoid overloading backend resources.

**Here is how Rate Limiter works:**

![](https://miro.medium.com/v2/resize:fit:875/1*G1VoKFbU2R8Tiuu4_cbQBQ.png)

## 4. Key Value Store

A Key-Value Store is a high-performance database that stores data as a collection of key-value pairs, allowing for constant-time complexity (O(1)) in most read/write operations.

It’s widely used in caching, session management, and real-time analytics due to its speed and simplicity. Systems like Redis, DynamoDB, and RocksDB are popular choices in modern architectures.

Because of their scalability and ease of distribution, key-value stores are a crucial component in building highly responsive, distributed systems.

**Here is how a key-value store looks like:**

![](https://miro.medium.com/v2/resize:fit:875/1*uRg9Qf0YrshClFd4NvTWCw.png)

## 5. Domain Name System (DNS)

The **DNS** is often referred to as the phonebook of the internet. It translates domain names like `example.com` into IP addresses. Without DNS, users would need to remember long strings of numbers to access websites.

**Example:** AWS Route 53, Google DNS

![](https://miro.medium.com/v2/resize:fit:875/1*CkjcuKdVylPYgb69jUEhnw.png)

## 6. Load Balancing

Load balancers distribute incoming network traffic across multiple servers to ensure reliability and scalability. They prevent a single server from being overwhelmed.

**Example:** Nginx, HAProxy, AWS Elastic Load Balancing

Here is a nice diagram from [Educative.io](https://bit.ly/3Mnh6UR) which shows a Load Balancer distributing incoming web traffic among multiple web servers to ensure no single server is overwhelmed.

![](https://miro.medium.com/v2/resize:fit:875/1*qsiTUseuQBZx1_u1FcvBUw.png)

## 7. Load Balancing Algorithms

Different algorithms determine how load balancers distribute traffic:

-   **Round Robin:** Sequentially distributes traffic
-   **Least Connections:** Routes traffic to the server with the fewest active connections
-   **IP Hash:** Maps traffic to servers based on the client’s IP

Here is a nice list of all load balancing algorithms from [DesignGurus.io](https://bit.ly/3pMiO8g)

![](https://miro.medium.com/v2/resize:fit:875/1*cfywEuiZcXwhYslYpfPO_A.png)

## 8. Caching

Caching temporarily stores copies of data to speed up access. It’s widely used to reduce latency and minimize database queries.

**Example:** Redis, Memcached

Here is also a quick guide of different types of caches in a system from [DesignGurus.io](https://bit.ly/3pMiO8g), one of my favorite place when it comes to System design preparation.

![](https://miro.medium.com/v2/resize:fit:875/1*mWwpPisQ35iVkTnfrOSOMA.png)

## 9. Caching Strategies

Strategies for caching include:

-   **Write-Through:** Updates the cache and the database simultaneously
-   **Write-Back:** Writes data to the cache and updates the database asynchronously
-   **Read-Through:** Reads from the cache, and if data is absent, it fetches from the database

And, here is a nice diagram from [ByteByteGo](https://bit.ly/3P3eqMN) which shows the top 5 caching strategies:

![](https://miro.medium.com/v2/resize:fit:875/1*d3stiDHHUXQ6yrhYPXmVAQ.jpeg)

## 10. Cache Eviction Policies

When caches run out of space, eviction policies determine which data to remove:

-   **Least Recently Used (LRU)**
-   **First In, First Out (FIFO)**
-   **Least Frequently Used (LFU)**

Here is another great diagram from [ByteByteGo](https://bit.ly/3P3eqMN) on 8 essential cache Eviction Strategies:

![](https://miro.medium.com/v2/resize:fit:875/1*098RWxK4WPhBm4ZC9Dne9g.jpeg)

## 11. Distributed Caching

Distributed caching enables systems to share cached data across multiple servers, ensuring scalability and reducing bottlenecks in high-traffic applications.

**Example:** Amazon ElastiCache

![](https://miro.medium.com/v2/resize:fit:875/1*A9VOn-gGqH9I5tMnf567bg.jpeg)

## 11. Heartbeats

Heartbeat signals are periodic messages sent between distributed systems to ensure components are alive and healthy. They’re crucial for failure detection and maintaining system integrity.

Here is a nice diagram which shows how Heartbeats works:

![](https://miro.medium.com/v2/resize:fit:875/1*ayHrORM4VIAlxlXHiPYDFQ.png)

## 12. Message Queues

Message queues decouple services by enabling asynchronous communication. They ensure reliable delivery of messages between components.

**Example:** RabbitMQ, Kafka, Amazon SQS

You can [learn more about message queues here.](https://javarevisited.substack.com/p/system-design-basics-master-message)

![](https://miro.medium.com/v2/resize:fit:875/1*8zWzqhkCz0rVraxliM_D8Q.jpeg)

## 13. WebSockets

WebSockets provide full-duplex communication channels over a single TCP connection, enabling real-time updates like chat apps and live feeds.

**Example:** Socket.IO

Here is an example of how WebSockets can be used in System Design

![](https://miro.medium.com/v2/resize:fit:875/1*j0fZNyIJzxTF-TJ7SpGTHQ.png)

## 14. Bloom Filters

A **Bloom filter** is a space-efficient probabilistic data structure used to test whether an element is part of a set. It’s fast but can return false positives.

**Example:** Preventing duplicate entries in databases

Here is how Bloom Filter works

![](https://miro.medium.com/v2/resize:fit:875/1*sQyYYRjDmXlvJeHkAJzeeg.png)

## 15. API Gateway

An API Gateway acts as a single entry point for API calls, managing authentication, rate limiting, and data aggregation.

**Example:** AWS API Gateway

![](https://miro.medium.com/v2/resize:fit:875/1*OIfbEpt88h_DAB2I3eejpg.jpeg)

## 16. API Design

Good API design involves:

-   **RESTful APIs:** Follow standard HTTP methods and conventions
-   **GraphQL:** Enables clients to query only the data they need
-   **gRPC:** Ensures high performance in communication between services

If you want to learn more about API Design, you can also checkout [**Grokking the API Design Interview**](https://www.educative.io/courses/grokking-the-api-design-interview?affiliate_id=5073518643380224) course on Educative.io, its one of the best course on this topic.

![](https://miro.medium.com/v2/resize:fit:875/1*ThArWvg1GRIE_aahlRdHhw.png)

## 17. Idempotency

Idempotency ensures that multiple identical requests have the same effect as a single request. This is critical in payment processing and state updates.

## 18. Checksum

A checksum is a value used to verify data integrity. By comparing checksums, systems can detect data corruption during storage or transmission.

**Example:** MD5, SHA-256

## 19. Distributed Locking

Distributed locks prevent race conditions in distributed systems. They ensure that only one process can access a critical resource at a time.

**Example:** Redlock algorithm using Redis

Here is an example of how Distributed Locking works in Kubernetes:

![](https://miro.medium.com/v2/resize:fit:658/1*cOpRb50446Yf2YYAgdBPTw.png)

## 20. Monitoring and Observability

Monitoring tools and observability practices are essential for identifying issues and ensuring system health. They provide insights into metrics, logs, and traces.

**Example:** Prometheus, Grafana, Datadog

Here are all the tools you can use for monitoring your system.

![](https://miro.medium.com/v2/resize:fit:875/1*9Ki4utq40U7RGV2L5vg0Tg.png)

## 21. Blob Store

A Blob Store (Binary Large Object Store) is a storage system optimized for handling large volumes of unstructured data such as images, videos, audio files, and backups.

Unlike traditional databases, blob stores are designed to store massive files efficiently and provide high availability and durability.

Common implementations like Amazon S3, Google Cloud Storage, and Azure Blob Storage allow developers to access and manage blobs using simple APIs.

Blob stores are essential for scalable applications that need to manage static assets or media content at a large scale.

## 22. Circuit Breaker

A **circuit breaker** prevents cascading failures by stopping requests to a failing service until it recovers. It protects the overall system from downtime.

**Example:** Netflix’s Hystrix

## 23. Proxy vs Reverse Proxy

-   **Proxy:** Acts on behalf of the client to communicate with a server.
-   **Reverse Proxy:** Acts on behalf of the server, handling requests from clients.  
    **Example:** Nginx, Apache HTTP Server

![](https://miro.medium.com/v2/resize:fit:875/1*_WqINFuUczCXYytNgUTb_w.png)

## How these System Design Building Blocks Used in a Real-World Application: E-Commerce Platform?

Imagine designing an e-commerce platform like **Amazon,** how are you going to use these system design building blocks?

**Well you can use:**

-   **DNS and Load Balancers** handle high traffic during sales events.
-   **Caching** stores product details and inventory to reduce database load.
-   **Message Queues** ensure asynchronous processing of order placements.
-   **Distributed Locks** prevent duplicate inventory deductions.
-   **Circuit Breakers** stop cascading failures when payment gateways are unavailable.
-   **API Gateway** simplifies frontend-backend communication for mobile, web, and desktop apps.
---

# Singleton Design Pattern: A Comprehensive Guide

# What is the Singleton Design Pattern?

The Singleton Design Pattern is a creational design pattern that **_ensures a class has only one instance and provides a global point of access to that instance._** This pattern is particularly useful when exactly one object is needed to coordinate actions across the system.

![](https://miro.medium.com/v2/resize:fit:538/0*w7vGPrRewl1PM7Tl)
Source: Refactoring Guru

Key characteristics of the Singleton pattern include:

-   **Single Instance**: Only one instance of the class is created.
-   **Global Access**: The single instance can be accessed globally.
-   **Lazy Initialization**: The instance is created only when required (if needed).

### Where Can You Use the Singleton Design Pattern?

## Real-World Scenarios

1.  **Configuration Management**:

-   Centralising configuration properties to avoid multiple instances managing the same data.
-   Example: A properties file loader.

1.  **Logging**:

-   Ensuring a single log file is used across the application.
-   Example: Logger classes like `java.util.logging.Logger`.

**2. Database Connections**:

-   Managing a single point of access to database connections.
-   Example: Database connection pools.

**3. Caching**:

-   Implementing caching mechanisms to reduce redundant operations.
-   Example: An in-memory cache like Redis.

**4. Thread Pools**:

-   Ensuring only one thread pool is active.

**5. Resource Management**:

-   Managing shared resources like network sockets or printers.

# When to Use and Avoid Singleton Design Pattern

## When to Use

-   Centralised control is needed for resource management.
-   Frequent creation and destruction of instances is expensive.
-   A single instance ensures consistency (e.g. global configuration).

## When to Avoid

**Reflection Breaking Singleton**:

-   Reflection can bypass private constructors, creating multiple instances.
-   To prevent this, throw an exception if the constructor is invoked more than once:
```java
private Singleton() {       
  if (instance != null) {           
    throw new IllegalStateException("Instance already created");       
  }   
}
```

**Serialization Breaking Singleton**:

-   During deserialization, a new instance can be created.
-   To fix this, implement the `readResolve` method in your singleton class.
-   The `readResolve` method is a mechanism provided by Java to ensure that during deserialization, the singleton property of a class is preserved. Without this method, deserialization could lead to the creation of a new instance of the Singleton class, breaking its contract of having only one instance.

## How `readResolve` Works

The `readResolve` method is part of Java's serialization mechanism. When an object is deserialized, if the class implements the `readResolve` method, this method is invoked to determine the instance that should replace the deserialized object.
```java
private Object readResolve() throws ObjectStreamException {       
  return instance;   
}
```

**Testing and Dependency Injection**:

-   _Singletons can make unit testing difficult due to their global state_.
-   **_Use Dependency Injection to avoid tightly coupling code_** to the Singleton.

**Distributed Systems**:

-   _Singletons are not ideal for distributed systems as they can lead to multiple instances in a cluster_.
-   Consider **_distributed locking or other patterns_**.

# Distributed Locking and Dependency Injection

## Distributed Locking

Distributed locking ensures that in a distributed system, only one instance of the Singleton is active at a time across all nodes. Popular tools for implementing distributed locking include:

1.  **Redis**:

-   Using `SETNX` (set if not exists) and an expiration time to create a lock.
```java
if (redis.setnx("lock_key", "value") == 1) {   
  // Acquired lock, proceed with Singleton logic   
}
```
**2. ZooKeeper**:

-   Leverages ephemeral nodes to ensure only one client holds the lock.

## Dependency Injection (DI)

**Description**:

-   Instead of hard-coding Singleton instances, provide them as dependencies to classes that need them.

**Implementation**:
```java
public class Service {       
  private final Singleton singleton;   
       
  public Service(Singleton singleton) {           
    this.singleton = singleton;       
  }   
}  

Singleton singleton = Singleton.getInstance();   
Service service = new Service(singleton);
```

**When to Use**:

-   When you need to decouple classes for better testability and maintainability.

# How to Implement Singleton in Java

## Basic Implementation
```java
public class BasicSingleton {  
    private static BasicSingleton instance;  
  
     private BasicSingleton() {  
        // private constructor to restrict instantiation  
     }  
  
     public static BasicSingleton getInstance() {  
        if (instance == null) {  
            instance = new BasicSingleton();  
        }  
        return instance;  
    }  
}
```

## Thread-Safe Implementation
```java
public class ThreadSafeSingleton {  
    private static ThreadSafeSingleton instance;  
  
    private ThreadSafeSingleton() {}  
  
    public static synchronized ThreadSafeSingleton getInstance() {  
        if (instance == null) {  
            instance = new ThreadSafeSingleton();  
        }  
        return instance;  
    }  
}
```
## Double-Checked Locking
```java
public class DoubleCheckedSingleton {  
    private static volatile DoubleCheckedSingleton instance;  
  
    private DoubleCheckedSingleton() {}  
  
    public static DoubleCheckedSingleton getInstance() {  
        if (instance == null) { // FIRST LOCK  
            synchronized (DoubleCheckedSingleton.class) {  
                if (instance == null) { // SECOND LOCK  
                    instance = new DoubleCheckedSingleton();  
                }  
            }  
        }  
        return instance;  
    }  
}
```
> **_Key Points:_**
> 
> **Volatile**: _The_ `_volatile_` _keyword ensures that the instance is always read from the main memory and_ **prevents thread caching issues**.
> 
> **First Check**: _The first check avoids locking if the instance is already initialized, improving performance in multi-threaded scenarios._
> 
> **Second Check**: _The second check ensures that only one thread initializes the resource, even if multiple threads enter the synchronized block simultaneously._
> 
> _This pattern is commonly used in Singleton design to ensure thread safety while avoiding the performance cost of synchronization once the resource is initialized._

## Enum-Based Singleton
```java
public enum EnumSingleton {  
    INSTANCE;  
  
public void performAction() {  
        // action implementation  
    }  
}
```
## Which Implementation to Use and When

1.  **Basic Singleton**:
-   Use in simple applications where thread safety is not a concern.

**2. Thread-Safe Singleton**:
-   Use in multi-threaded environments to ensure only one instance is created.
-   Drawback: Synchronized methods can be slow.

**3. Double-Checked Locking**:
-   Optimal for performance in multi-threaded applications.
-   Ensures thread safety while avoiding the overhead of synchronizing every call.

**4. Enum-Based Singleton**:
-   Recommended for most use cases due to simplicity, thread safety, and protection from reflection and serialization issues.
-   Use when you need a straightforward and robust Singleton implementation.

# Class vs Enum for Singleton

## Class-Based Approach

**When to Use**:
-   Need fine-grained control over instantiation.
-   More flexibility for extensions or testing.

**When Not to Use**:
-   Increased risk of multiple instances if not implemented correctly.

## Enum-Based Approach

**When to Use**:
-   Simplifies implementation.
-   Ensures thread safety and protection from reflection/serialization.

**When Not to Use**:
-   Limited extensibility.

# Ensuring Thread Safety

-   Use **_synchronized methods_** for instance creation.
-   **_Employ double-checked locking with_** `**_volatile_**` **_keyword._**
-   Enum-based singletons are inherently thread-safe.

# Things to Keep in Mind

-   **_Ensure the constructor is private to prevent external instantiation_**.
-   Consider thread safety for multi-threaded applications.
-   **_Use lazy initialization only when necessary to optimise resource usage_**.
-   Avoid reflection and serialization breaking the Singleton property by implementing the above safeguards.

# Pros and Cons

## Pros

-   Ensures a single instance.
-   Provides a global point of access.
-   Reduces memory usage in resource-heavy applications.

## Cons

-   Can lead to tightly coupled code.
-   Difficult to test and mock.
-   May introduce performance bottlenecks.

# Final Working Code with Class-Based Approach
```java
public class SingletonExample {  
    private static volatile SingletonExample instance;  
  
    private SingletonExample() {}  
    public static SingletonExample getInstance() {  
        if (instance == null) {  
            synchronized (SingletonExample.class) {  
                if (instance == null) {  
                    instance = new SingletonExample();  
                }  
            }  
        }  
        return instance;  
    }  
    public void showMessage() {  
        System.out.println("Singleton Instance Invoked!");  
    }  
    public static void main(String[] args) {  
        SingletonExample singleton = SingletonExample.getInstance();  
        singleton.showMessage();  
    }  
}
```
# Final Working Code with Enum-Based Approach
```java
public enum SingletonEnum {  
    INSTANCE;  
  
    // Example of a method that can be invoked on the singleton instance  
    public void showMessage() {  
        System.out.println("Singleton Instance Invoked via Enum!");  
    }  
}  
  
class EnumSingletonDemo {  
    public static void main(String[] args) {  
        // Accessing the Singleton instance  
        SingletonEnum singleton = SingletonEnum.INSTANCE;  
  
        // Calling the method on the singleton instance  
        singleton.showMessage();  
    }  
}
```
How Enum works behind the scene — refer [**_How Enum works with Singleton Design Pattern in Java!_**](/how-enum-works-with-singleton-design-pattern-in-java-c7766a77592b)

---

### Java: Why Singleton Design Pattern is Important 
### Problems in the absence of Singleton

Imagine a theoretical situation where you have to access a configuration file and, in different sections of your program, this file is being read multiple times. How would you typically code this?
```java
public class ConfigurationManager {  
    private String configValue;  
  
    public ConfigurationManager() {  
        // Let's say reading this value is an expensive operation.  
        this.configValue = readFromConfigFile();  
    }  
  
    private String readFromConfigFile() {  
        // ... read the value from a file  
        return "SomeConfigValue";  
    }  
  
    public String getConfigValue() {  
        return configValue;  
    }  
}  
  
// Using ConfigurationManager  
ConfigurationManager manager1 = new ConfigurationManager();  
ConfigurationManager manager2 = new ConfigurationManager();
```
In the above case:

1.  **Wastage of Resources**: The config file is read multiple times, which is unnecessary and wasteful.
2.  **Inconsistency**: If the config file can change, then manager1 and manager2 might have different config values if they are initialized at different times, leading to inconsistent behavior.

### Using Singleton:
```java
public class ConfigurationManager {  
    private String configValue;  
    private static ConfigurationManager instance;  
  
    private ConfigurationManager() {  
        this.configValue = readFromConfigFile();  
    }  
  
    public static ConfigurationManager getInstance() {  
        if (instance == null) {  
            instance = new ConfigurationManager();  
        }  
        return instance;  
    }  
  
    private String readFromConfigFile() {  
        // ... read the value from a file  
        return "SomeConfigValue";  
    }  
  
    public String getConfigValue() {  
        return configValue;  
    }  
}  
  
// Using ConfigurationManager  
ConfigurationManager manager1 = ConfigurationManager.getInstance();  
ConfigurationManager manager2 = ConfigurationManager.getInstance();
```
Now, with Singleton:

1.  The config file is read only once.
2.  There’s a guarantee that manager1 and manager2 have the same config value, ensuring consistency.

### Why use Singleton?

1.  **Controlled Access**: It provides controlled access to its only instance.
2.  **Lazy Initialization**: Object is only created when it is needed.
3.  **Saves Memory**: It can be more efficient because it avoids the overhead of creating a new object every time one is needed.

### How to Implement Singleton?

1.  Make the constructor `private` to prevent any new instance.
2.  Provide a `public` method to get the only instance.
```java
public class Singleton {  
    // Static member holds only instance of the Singleton class  
    private static Singleton instance;  
      
    // Singleton's constructor should be private to prevent instantiation from outside  
    private Singleton() {}  
  
    // Global point of access. Uses lazy initialization.  
    public static Singleton getInstance() {  
        if (instance == null) {  
            instance = new Singleton();  
        }  
        return instance;  
    }  
}
```
The singleton pattern ensures that a class has only one instance and provides a global point of access to it. This can be crucial in scenarios where creating multiple instances is costly or can lead to inconsistencies.

### Real-world examples

### **Use of singleton pattern in** `**java.lang.Runtime**`

The singleton pattern can be found in the Java Standard Library itself. Let’s take a look at a commonly used example: `java.lang.Runtime`.

The `Runtime` class allows the application to interface with the environment in which the application is running. The current runtime can be obtained from the `getRuntime` method.

Let’s see how it’s implemented (this is a simplification):
```java
public class Runtime {  
    private static Runtime currentRuntime = new Runtime();  
  
    /**  
     * Returns the runtime object associated with the current Java application.  
     * @return  the {@code Runtime} object associated with the current Java application.  
     */  
    public static Runtime getRuntime() {  
        return currentRuntime;  
    }  
  
    /** Don't let anyone else instantiate this class */  
    private Runtime() {}  
}
```
When you call `Runtime.getRuntime()`, you always get the same `Runtime` instance, making it a Singleton.

**The beauty of this design:**

Imagine if the `Runtime` class wasn't a Singleton. Different parts of your program might end up with different `Runtime` objects interfacing with your system. This would:

-   Waste resources, as each instance might need to set up and tear down its connections with the underlying system.
-   Lead to potential inconsistencies or conflicts as different `Runtime` objects try to interact with the system simultaneously.

By ensuring that the entire JVM uses a single `Runtime` instance, Java provides a consistent, efficient, and safe way for your application to interact with its environment.

### Database Connections:

-   Database connection pools often implement Singletons to manage a set of database connections. Establishing a new connection every time an application needs to communicate with a database is inefficient. Instead, a Singleton connection pool manages a set of connections.
-   **Real-World Example**: Apache Commons DBCP (Database Connection Pooling) can be set up as a Singleton to efficiently handle database connections.

### Logger Classes:

-   Applications often require logging mechanisms to log messages, errors, or other information. A Singleton logger ensures that the same logging strategy and storage is used throughout the application.
-   **Real-World Example**: Log4j or SLF4J can be set up to ensure there’s a consistent logging strategy across an application.

### Configuration Management:

-   Reading configurations every time they’re needed is inefficient. Instead, a Singleton configuration manager can read configurations once and provide them throughout the application.
-   **Real-World Example**: In large enterprise systems, a centralized configuration manager, often implemented as a Singleton, ensures consistent configuration across various components.

### Cache Management:

-   Caching systems ensure that frequently accessed and unchanging data is quickly retrievable. A Singleton cache manager ensures consistent cache storage and retrieval mechanisms.
-   **Real-World Example**: EhCache, a widely-used Java caching solution, can be set up as a Singleton to manage cache efficiently across an application.

### Operating System Interface:

-   Programs might need to interface with the operating system for tasks like memory management, process control, etc. A Singleton pattern ensures a consistent point of interaction with the OS.
-   **Real-World Example**: The previously discussed `java.lang.Runtime` class in the Java Standard Library.

### Service Proxies:

-   When your application communicates with external services or systems (e.g., a third-party API), a proxy can manage this communication. Using a Singleton proxy ensures consistent communication strategy and might reuse established connections.
-   **Real-World Example**: Proxies set up for RESTful services in enterprise systems.

### Hardware Interface Access:

-   For applications interfacing with specific hardware devices, like printers or graphics cards, a Singleton can manage and coordinate access to the device.
-   **Real-World Example**: Print spoolers in systems where multiple applications might need to send documents to a single printer.

### Load Balancer:

-   In distributed systems, a load balancer distributes incoming requests to multiple servers. A Singleton load balancer ensures a consistent strategy and state in balancing loads.
-   **Real-World Example**: An application-level load balancer that routes requests based on custom application logic.

It’s worth noting that while the Singleton pattern can be powerful and useful in many scenarios, it’s not without criticism. Some developers argue it’s essentially a “global state” (which can lead to undesirable couplings and make testing harder).

Like any tool or pattern, it’s essential to use it judiciously and where it genuinely adds value.

---

# Bridge Design Pattern

# Introduction

The **Bridge Design Pattern** is a structural design pattern that decouples an abstraction from its implementation so that both can evolve independently. This is particularly useful when we need to extend a system with multiple dimensions of variations without causing a combinatorial explosion of subclasses.

In this article, we will explore the **Bridge Design Pattern** in depth, understand its components, when and where to use it, compare it with the **Strategy Pattern**, and implement it with a real-world example.

# What is the Bridge Design Pattern?

The **Bridge Pattern** is used to separate abstraction and implementation into different classes so that changes in one do not affect the other. This separation allows easier maintenance and scalability.

# Key Idea

Instead of tightly coupling the abstraction (interface) with a specific implementation, the **Bridge Pattern** introduces an intermediary bridge, facilitating flexibility and extensibility.

# Components of the Bridge Pattern

![](https://miro.medium.com/v2/resize:fit:700/0*tzEtDzKLdWLqILHZ)
Source: Refactoring Guru

## 1. Abstraction

-   The high-level interface that clients interact with.
-   Contains a reference to the **implementation**.

## 2. Refined Abstraction

-   Extends the **Abstraction** with additional functionalities.

## 3. Implementor (Interface or Abstract Class)

-   Declares an interface for implementation classes.

## 4. Concrete Implementor

-   Provides a concrete implementation for the **Implementor**.

# Block Diagram

            +-------------------+          +-------------------+  
            |   Abstraction     |          |  Implementor      |  
            |-------------------|          |-------------------|  
            |  Implementor impl |<>------->| operation()       |  
            +-------------------+          +-------------------+  
                     |                                 |  
            +-------------------+          +-------------------+  
            | RefinedAbstraction|          |ConcreteImplementor|  
            +-------------------+          +-------------------+

# When to Use the Bridge Design Pattern

-   When a **class has multiple dimensions of variability** that need to be managed independently.
-   When we want to **avoid subclass explosion** due to combinations of features.
-   When we need **runtime flexibility**, allowing different implementations to be switched dynamically.
-   When we want to **decouple high-level logic from platform-specific implementations**.

# Real-Life Examples of the Bridge Design Pattern

## 1. Remote Control System

-   We have a **Remote Control (Abstraction)** that works with different **devices (Implementations)** like **TV, AC, Fan**.
-   Instead of creating `TVRemoteControl`, `ACRemoteControl`, `FanRemoteControl`, we separate **Remote** from **Device**, allowing independent variations.

## 2. Cross-Platform UI Frameworks

-   Abstracting the **UI elements** from their **platform-specific rendering** (Windows, Mac, Linux).

## 3. Database Drivers

-   Different **databases (MySQL, PostgreSQL, MongoDB)** have their own implementations, but the abstraction remains the same.

# Implementation Without the Bridge Pattern (Tightly Coupled)

Let’s design a **Messaging System** where messages can be sent via **SMS, Email, and WhatsApp**.
```java
// Without Bridge Pattern  
interface Message {  
    void sendMessage(String message);  
}  
  
class SMSMessage implements Message {  
    public void sendMessage(String message) {  
        System.out.println("Sending SMS: " + message);  
    }  
}  
class EmailMessage implements Message {  
    public void sendMessage(String message) {  
        System.out.println("Sending Email: " + message);  
    }  
}  
class WhatsAppMessage implements Message {  
    public void sendMessage(String message) {  
        System.out.println("Sending WhatsApp: " + message);  
    }  
}
```
# Problems

-   If we introduce **Message Types** like `AlertMessage`, `NotificationMessage`, etc., the number of subclasses grows exponentially.
-   Changes in messaging platforms require modifying all message types.

# Implementing the Bridge Pattern

Now, let’s refactor using the **Bridge Pattern**:
```java
// Implementor Interface  
interface MessageSender {  
    void send(String message);  
}  
  
// Concrete Implementors  
class SMSSender implements MessageSender {  
    public void send(String message) {  
        System.out.println("Sending SMS: " + message);  
    }  
}  
class EmailSender implements MessageSender {  
    public void send(String message) {  
        System.out.println("Sending Email: " + message);  
    }  
}  
class WhatsAppSender implements MessageSender {  
    public void send(String message) {  
        System.out.println("Sending WhatsApp: " + message);  
    }  
}  
// Abstraction  
abstract class Message {  
    protected MessageSender sender;  
    protected Message(MessageSender sender) {  
        this.sender = sender;  
    }  
    abstract void sendMessage(String message);  
}  
// Refined Abstraction  
class NotificationMessage extends Message {  
    public NotificationMessage(MessageSender sender) {  
        super(sender);  
    }  
    public void sendMessage(String message) {  
        System.out.print("Notification - ");  
        sender.send(message);  
    }  
}  
class AlertMessage extends Message {  
    public AlertMessage(MessageSender sender) {  
        super(sender);  
    }  
    public void sendMessage(String message) {  
        System.out.print("Alert - ");  
        sender.send(message);  
    }  
}  
// Client Code  
public class BridgePatternDemo {  
    public static void main(String[] args) {  
        Message alert = new AlertMessage(new EmailSender());  
        alert.sendMessage("Server Down!");  
        Message notification = new NotificationMessage(new WhatsAppSender());  
        notification.sendMessage("Meeting at 5 PM");  
    }  
}
```
# Benefits of the Bridge Pattern

-   **Improved Scalability**: Easily add new `MessageSender` implementations or `Message` types independently.
-   **Decoupling**: Implementation changes don’t affect high-level abstractions.
-   **Runtime Flexibility**: Change implementations dynamically.

# Bridge Pattern vs Strategy Pattern

![](https://miro.medium.com/v2/resize:fit:875/1*gTQJoznHZEqKs3_UH_rkAQ.png)

# Pros and Cons of the Bridge Pattern

## Pros

-   Reduces subclass explosion
-   Improves maintainability
-   Enhances flexibility
-   Enables independent extension of abstraction and implementation

## Cons

-   Slightly increases code complexity
-   More indirections may introduce performance overhead

### Conclusion

The **Bridge Pattern** is a powerful structural pattern that promotes better software design by allowing abstractions and implementations to evolve independently. It’s particularly useful in scenarios where multiple dimensions of variations exist. By implementing it, we ensure **scalability, flexibility, and maintainability** while avoiding tightly coupled designs.

---

### Builder Design Pattern

### What is the Builder Design Pattern?

The **_Builder Design Pattern_** is a **_creational pattern_** that **a_llows for the step-by-step construction of complex objects_**. Unlike other creational patterns, the Builder pattern does not require that all products be built in a single,. monolithic constructor. Instead, it provides a way to construct a complex object by specifying its type and content, step by step.

### NOTE:

1.  If we don't use Builder Design pattern, we might end up working with a big constructor or multiple number of tiny constructor or multiple optional parameters.
2.  Builder design pattern helps to solve problems that are stated in point 1.

### Components of the Builder Design Pattern:

![](https://miro.medium.com/v2/resize:fit:575/0*VKhNVV_1WFVLXYeq)
Source: Refactoring Guru

### Purpose of Each Component:

-   **Builder**: Provides an abstract interface for creating parts of a Product object.
-   **ConcreteBuilder**: Implements the Builder interface to construct and assemble parts of the product.
-   **Product**: Represents the complex object that is being built.
-   **Director**: Directs the construction process using the Builder interface.

### Focus on Dynamic Behavior and Reusability

The Builder Design Pattern enhances dynamic behavior and reusability by:

-   Allowing **_different representations_** of the object.
-   Enabling the **_reuse of the same construction process_** for different products.
-   Facilitating the **_creation of complex objects with varying configurations_**_._

### When and Where to Use the Builder Design Pattern

The Builder Design Pattern is particularly useful when:

-   The **_construction process of an object is complex_**.
-   The **_object needs to be created in multiple steps_**.
-   The **_object can have different representations_**.
-   You **_want to avoid a “telescoping constructor” anti-pattern_**.

### Real-Life Use Cases

### Examples:

-   **StringBuilder in Java**: Used to construct a string incrementally.
-   **Document Generation**: Creating complex documents with various sections.
-   **UI Components**: Building complex UI components with various configurations.

### Best Practices for Implementing the Builder Design Pattern

-   **Immutability**: Ensure that the built object is immutable.
-   **Fluent Interface**: Use a fluent interface to make the builder easy to use.
-   **Validation**: Include validation logic within the builder to ensure the object is in a valid state.
-   **Separation of Concerns**: Keep the builder and the product separate to maintain a clear separation of concerns.

### Without Builder Design Pattern
```java
public class Car {  
    private String engine;  
    private String body;  
    private int seats;  
  
public Car(String engine, String body, int seats) {  
        this.engine = engine;  
        this.body = body;  
        this.seats = seats;  
    }  
    // Getters and toString() method  
}  
// Usage  
Car car = new Car("V8", "SUV", 5);
```

### Disadvantages:

-   Hard to read and maintain.
-   Difficult to add new parameters.
-   Prone to errors with many parameters.

### With Builder Design Pattern
```java
public class Car {  
    // Immutability: All fields are final to ensure the object is immutable  
    private final String engine;  
    private final String body;  
    private final int seats;  
  
    // Private constructor to enforce object creation through the builder  
    private Car(CarBuilder builder) {  
        this.engine = builder.engine;  
        this.body = builder.body;  
        this.seats = builder.seats;  
    }  
  
    // Static nested Builder class  
    public static class CarBuilder {  
        private String engine;  
        private String body;  
        private int seats;  
  
        // Fluent Interface: Each setter method returns the builder itself  
        public CarBuilder setEngine(String engine) {  
            // Validation: Ensure the engine is not null or empty  
            if (engine == null || engine.isEmpty()) {  
                throw new IllegalArgumentException("Engine cannot be null or empty");  
            }  
            this.engine = engine;  
            return this;  
        }  
  
        public CarBuilder setBody(String body) {  
            // Validation: Ensure the body is not null or empty  
            if (body == null || body.isEmpty()) {  
                throw new IllegalArgumentException("Body cannot be null or empty");  
            }  
            this.body = body;  
            return this;  
        }  
  
        public CarBuilder setSeats(int seats) {  
            // Validation: Ensure the number of seats is greater than zero  
            if (seats <= 0) {  
                throw new IllegalArgumentException("Seats must be greater than zero");  
            }  
            this.seats = seats;  
            return this;  
        }  
  
        // Build method to create the Car object  
        public Car build() {  
            return new Car(this);  
        }  
    }  
  
    // Getters only, no setters to maintain immutability  
    public String getEngine() {  
        return engine;  
    }  
  
    public String getBody() {  
        return body;  
    }  
  
    public int getSeats() {  
        return seats;  
    }  
}  
  
// Usage  
public class Main {  
    public static void main(String[] args) {  
        // Using the builder to create a Car object  
        Car car = new Car.CarBuilder()  
                .setEngine("V8")  
                .setBody("SUV")  
                .setSeats(5)  
                .build();  
  
        System.out.println(car);  
    }  
}
```
#### Explanation of Best Practices:

1.  **Immutability:**

-   All fields in the `Car` class are declared as `final` to ensure that once the object is created, its state cannot be changed.

2. **Fluent Interface:**

-   Each setter method in the `CarBuilder` class returns `this`, allowing for method chaining and making the builder easy to use.

3. **Validation:**

-   Each setter method includes validation logic to ensure that the provided values are valid. For example, the `setEngine` method checks if the engine string is not null or empty.

4. **Separation of Concerns:**

-   The `Car` class and the `CarBuilder` class are kept separate. The `Car` class is responsible for representing the product, while the `CarBuilder` class handles the construction process.

### Advantages:

-   Improved readability and maintainability.
-   Easy to add new parameters.
-   Reduced risk of errors.

### Pros and Cons of Using the Builder Design Pattern

### Pros

1.  **Improved Readability and Maintainability:**

-   The Builder pattern makes the code more readable and maintainable by clearly separating the construction process from the representation of the object.

2. **Avoids Telescoping Constructor Anti-Pattern:**

-   It helps avoid the telescoping constructor anti-pattern, where constructors with many parameters become hard to read and use.

3. **Flexibility in Object Construction:**

-   It provides flexibility in constructing complex objects by allowing optional parameters and different configurations.

4. **Immutability:**

-   The pattern promotes immutability by ensuring that the constructed object is immutable once built.

5. **Fluent Interface:**

-   The fluent interface provided by the Builder pattern makes the code more intuitive and easier to use.

6. **Validation:**

-   It allows for validation of parameters before constructing the object, ensuring that the object is always in a valid state.

7. **Reusability:**

-   The same Builder can be reused to create different representations of the object, enhancing reusability.

### Cons

1.  **Increased Complexity:**

-   The Builder pattern can introduce additional complexity to the codebase, especially for simple objects where a builder might be overkill.

2. **More Boilerplate Code:**

-   It can lead to more boilerplate code, as you need to create separate Builder classes and methods for each parameter.

3. **Learning Curve:**

-   There might be a learning curve for developers who are not familiar with the pattern, making it harder to understand and implement initially.

4. **Overhead for Simple Objects:**

-   For simple objects with only a few parameters, using the Builder pattern might be unnecessary and add unnecessary overhead.

5. **Potential for Misuse:**

-   If not used correctly, the Builder pattern can be misused, leading to code that is harder to read and maintain.

Overall, the Builder Design Pattern is a powerful tool for constructing complex objects in a flexible and maintainable way. However, it’s important to weigh the pros and cons and consider whether it’s the right fit for your specific use case

### Conclusion

The Builder Design Pattern is a powerful tool for constructing complex objects in a step-by-step manner. By following best practices and understanding its components, you can create flexible and maintainable code that is easy to read and extend.

---

# The Command Design Pattern

### Introduction

The **Command Design Pattern** helps break down actions into separate objects, making it easier to manage tasks like undo, redo, and logging. It’s great for situations where you want to **decouple** the request (what needs to be done) from how it’s actually executed.

![](https://miro.medium.com/v2/resize:fit:800/0*ZjLn3UIq-B4VFD78)
Source: Refactoring guru

In this article, we’ll cover:

-   **What is the Command Pattern?**
-   **How does it work?**
-   **When should you use it?**
-   **Real-life examples**
-   **How to implement it with and without the pattern**
-   **Best practices, pros, and cons**
-   **How to add an Undo feature**

By the end, you’ll have a solid understanding of how this pattern can improve your code.

### What is the Command Pattern?

The **Command Pattern** is a way to wrap actions (or requests) inside objects. This means that instead of calling methods directly, you create command objects that **store details of the action**, such as which method to call, which object it should act on, and any needed parameters.

### Key Parts of the Command Pattern

1.  **Command Interface**: Defines what every command should have.
2.  **Concrete Commands**: These actually do the work.
3.  **Receiver**: The object that performs the action.
4.  **Invoker**: The one that calls commands.
5.  **Client**: The main program that sets up everything.

Here’s a **simple diagram** to visualize how it works:

![](https://miro.medium.com/v2/resize:fit:750/0*Vs9pVn_zqEj4cBiT.gif)
Source: oodesign.com

### When Should You Use It?

Use the **Command Pattern** when you need:

-   **Undo/Redo functionality** (e.g., text editors, design tools)
-   **Macro recording** (e.g., game automation, software shortcuts)
-   **Logging requests** (e.g., tracking user actions)
-   **GUI buttons & menu actions** (e.g., clicking buttons in an app)
-   **Job Queues & Scheduling** (e.g., background tasks)

### Real-Life Examples

-   **Remote Control**: Pressing a button triggers different commands (e.g., turn on/off TV, increase volume).
-   **ATM Transactions**: Withdrawing or depositing money acts as a command.
-   **Shopping Cart**: Adding or removing items can be executed as commands, allowing rollback.

### Implementation Without the Command Pattern

Let’s say we have a **remote control that turns a light on and off**. Without using the **Command Pattern**, it looks like this:
```java
class Light {  
    public void turnOn() {  
        System.out.println("Light is ON");  
    }  
    public void turnOff() {  
        System.out.println("Light is OFF");  
    }  
}  
  
class RemoteControl {  
    private Light light;  
    public RemoteControl(Light light) {  
        this.light = light;  
    }  
    public void pressOnButton() {  
        light.turnOn();  
    }  
    public void pressOffButton() {  
        light.turnOff();  
    }  
}  
public class Main {  
    public static void main(String[] args) {  
        Light light = new Light();  
        RemoteControl remote = new RemoteControl(light);  
        remote.pressOnButton();  // Light is ON  
        remote.pressOffButton(); // Light is OFF  
    }  
}
```
### Problems with This Approach:

1.  The remote control **directly depends** on the `Light` class.
2.  **No Undo feature** (If we want to undo an action, we have to add more logic).
3.  **Difficult to extend** (If we want to control other devices, we must modify `RemoteControl`).

### Using the Command Pattern (Better Approach)

Now, let’s **improve** our design using the **Command Pattern**.
```java
// Step 1: Command Interface  
interface Command {  
    void execute();  
    void undo();  
}  
  
class LightOnCommand implements Command {  
    private Light light;  
      
    public LightOnCommand(Light light) {  
        this.light = light;  
    }  
    public void execute() {  
        light.turnOn();  
    }  
      
    public void undo() {  
        light.turnOff();  
    }  
}  
// Step 3: Concrete Command for Turning Light OFF  
class LightOffCommand implements Command {  
    private Light light;  
      
    public LightOffCommand(Light light) {  
        this.light = light;  
    }  
      
    public void execute() {  
        light.turnOff();  
    }  
      
    public void undo() {  
        light.turnOn();  
    }  
}  
// Step 4: Remote Control (Invoker)  
class RemoteControl {  
    private Command command;  
      
    public void setCommand(Command command) {  
        this.command = command;  
    }  
      
    public void pressButton() {  
        command.execute();  
    }  
      
    public void pressUndo() {  
        command.undo();  
    }  
}  
// Step 5: Client Code  
public class Main {  
    public static void main(String[] args) {  
        Light light = new Light();  
        Command lightOn = new LightOnCommand(light);  
        Command lightOff = new LightOffCommand(light);  
          
        RemoteControl remote = new RemoteControl();  
          
        remote.setCommand(lightOn);  
        remote.pressButton();  // Light is ON  
        remote.pressUndo();    // Light is OFF  
        remote.setCommand(lightOff);  
        remote.pressButton();  // Light is OFF  
        remote.pressUndo();    // Light is ON  
    }  
}
```

### Pros & Cons of the Command Pattern

#### Pros:

1.  Decouples sender and receiver.
2.  Easier to add new commands.
3.  Supports undo/redo functionality.
4.  Can store commands for later execution

#### Cons:

1.  **More classes and objects** (Adds complexity if the problem is simple)
2.  **Might be overkill** for basic applications

### Conclusion

The **Command Pattern** is a powerful way to make your code more flexible and scalable. While it does add a bit of complexity, it’s incredibly useful in scenarios where **undo, logging, or decoupling of commands** is needed. If used wisely, it can lead to **cleaner, more maintainable code**!

---

### Decorator Design Pattern

### Introduction

In software development, the **Decorator Design Pattern** is a structural pattern that allows us to dynamically add functionalities to objects without altering their code. Unlike other design patterns, the decorator pattern provides a flexible and scalable way to enhance an object’s behavior at runtime.

In this article, we will explore the **what, why, when, and how** of the decorator pattern with real-life use cases and code examples.

![](https://miro.medium.com/v2/resize:fit:800/0*fyNys6JxLP98KEeD)
Source: Refactoring Guru

### What is the Decorator Design Pattern?

The **Decorator Design Pattern** enables behavior extension by wrapping objects inside special decorator classes. These decorators modify or extend the object’s functionality without modifying the original class.

![](https://miro.medium.com/v2/resize:fit:600/0*u1DNuJAAI9A_jH7T)
Source: Refactoring Guru

### How is it Different from Other Patterns?

-   Unlike **inheritance**, which extends functionality at compile-time, decorators allow modifications at runtime.
-   Unlike **the Strategy pattern**, which replaces entire behaviors, the decorator enhances existing behavior incrementally.
-   Unlike **the Proxy pattern**, which controls access to an object, decorators modify the behavior of the object itself.

### When and Where to Use the Decorator Pattern?

### When to Use?

Use the **Decorator Pattern** when:

-   You need to **extend functionalities dynamically** without modifying the base class.
-   You want to **avoid subclass explosion** caused by multiple variations of a class.
-   You need a **flexible and reusable** way to modify object behavior.

### Where to Use?

-   GUI components (e.g., adding scrollbars, borders, shadows to UI elements).
-   Logging and monitoring (e.g., adding logging functionality to a service without modifying it).
-   Security (e.g., adding encryption/decryption to data streams).
-   Data transformation (e.g., compressing or encrypting files dynamically).

### Why Use the Decorator Pattern?

-   **Adheres to Open-Closed Principle**: Enhancements are added without modifying the existing code.
-   **Avoids Complex Inheritance Trees**: Prevents the need for multiple subclasses.
-   **Runtime Flexibility**: Behaviors can be added or removed dynamically.
-   **Enhances Maintainability**: Code remains cleaner and more modular.

### Real-Life Use Cases

### 1. File I/O in Java

Java’s I/O system uses decorators to add functionalities like buffering, compression, and encryption:
```java
InputStream fileStream = new FileInputStream("data.txt");  
InputStream bufferedStream = new BufferedInputStream(fileStream);  
InputStream compressedStream = new GZIPInputStream(bufferedStream);
```

### 2. Adding Extra Features to a Coffee Order System

Imagine an application where users can add extra toppings to their coffee dynamically.

### Without Using the Decorator Pattern (Problem Statement)

Let’s implement a coffee ordering system without the **Decorator Pattern**.
```java
class Coffee {  
    public int cost() {  
        return 50; // Base price  
    }  
}  
  
class CoffeeWithMilk extends Coffee {  
    @Override  
    public int cost() {  
        return super.cost() + 20;  
    }  
}  
class CoffeeWithSugar extends Coffee {  
    @Override  
    public int cost() {  
        return super.cost() + 10;  
    }  
}  
class CoffeeWithMilkAndSugar extends CoffeeWithMilk {  
    @Override  
    public int cost() {  
        return super.cost() + 10;  
    }  
}
```
### Disadvantages of this Approach

**Class Explosion**: Every combination requires a new subclass.  
**Rigid Design**: Adding new toppings requires modifying existing classes. **Code Duplication**: Repeated logic in multiple classes.

### Implementing the Decorator Pattern (Best Practice Solution)

Now, let’s solve the same problem using the **Decorator Pattern**:

![](https://miro.medium.com/v2/resize:fit:875/0*yOdqubuCVWi5YKpx.jpg)
Source: GeeksForGeeks
```java
// Step 1: Create the base interface  
interface Coffee {  
    int cost();  
}  
  
// Step 2: Implement the base class  
class BasicCoffee implements Coffee {  
    public int cost() {  
        return 50; // Base price  
    }  
}  
  
// Step 3: Create the Decorator class  
abstract class CoffeeDecorator implements Coffee {  
    protected Coffee coffee;  
      
    public CoffeeDecorator(Coffee coffee) {  
        this.coffee = coffee;  
    }  
      
    public int cost() {  
        return coffee.cost();  
    }  
}  
  
// Step 4: Implement specific decorators  
class MilkDecorator extends CoffeeDecorator {  
    public MilkDecorator(Coffee coffee) {  
        super(coffee);  
    }  
      
    public int cost() {  
        return super.cost() + 20;  
    }  
}  
  
class SugarDecorator extends CoffeeDecorator {  
    public SugarDecorator(Coffee coffee) {  
        super(coffee);  
    }  
      
    public int cost() {  
        return super.cost() + 10;  
    }  
}  
  
// Step 5: Use decorators dynamically  
public class DecoratorPatternExample {  
    public static void main(String[] args) {  
        Coffee coffee = new BasicCoffee();  
        System.out.println("Plain Coffee Cost: " + coffee.cost());  
          
        coffee = new MilkDecorator(coffee);  
        System.out.println("Coffee with Milk Cost: " + coffee.cost());  
          
        coffee = new SugarDecorator(coffee);  
        System.out.println("Coffee with Milk & Sugar Cost: " + coffee.cost());  
    }  
}
```
### Advantages of Using the Decorator Pattern

**Scalability**: No need to create multiple subclasses for each combination.  
**Flexibility**: Enhancements can be added dynamically at runtime.  
**Single Responsibility Principle (SRP)**: Each decorator has a specific role. ✔ **Improved Maintainability**: Code is modular and easy to extend.

### Comparison: Builder vs. Decorator Pattern

![](https://miro.medium.com/v2/resize:fit:875/1*sgh96VXJzeFKhbsA51fRiA.png)

### Conclusion

The **Decorator Pattern** is a powerful tool for extending object functionalities dynamically while keeping code clean and maintainable. Understanding and applying it effectively can significantly improve software design.

---

### Implementing the Strategy Design pattern in Spring Boot

### The Problem

Let’s say you are working on a feature called File Parser. You need to write an API where you can upload a file and our system should be able to extract the data from it and persist them in the database. Currently we are asked to support _CSV_, _JSON_ and _XML_ files. Our immediate solution would look something like below.
```java
@Service  
public class FileParserService {  
    
  public void parse(File file, String fileType) {  
    if (Objects.equals(fileType, "CSV")) {  
      // TODO : a huge implementation to parse CSV file and persist data in db  
    } else if (Objects.equals(fileType, "JSON")) {  
      // TODO : a huge implementation to parse JSON file and persist data in db  
    } else if (Objects.equals(fileType, "XML")) {  
      // TODO : a huge implementation to parse XML file and persist data in db  
    } else {  
      throw new IllegalArgumentException("Unsupported file type");  
    }  
  }  
    
}
```
Everything looks good now from the business perspective but things will start getting uglier when we want to support more file types in the future. We start adding multiple else if blocks and the size of the class will quickly grow which will eventually become too hard to maintain. Any change to one of the implementations of the file parser will affect the whole class thereby increasing the chance of introducing a bug in an already working functionality.

Not only that, but there is another problem. Let’s say now we need to additionally support _sqlite_ and _parquet_ file types. Two developers will step in and they will start working on the same huge class. It is highly likely that they will get merge conflicts which is not only irritating for any developer but also time consuming to resolve them. Most importantly, even after the conflict resolution, there would be decreased confidence in terms of the feature working as a whole.

### The Solution

This is where the Strategy Design pattern steps in to our rescue. We will move all the file parser implementations to separate classes called _strategies._ In the current class, we shall dynamically fetch the appropriate implementation based on file type and execute the strategy.

Here’s a UML diagram to provide a high-level overview of the design pattern that we are about to implement.

![](https://miro.medium.com/v2/resize:fit:875/1*u0uGWJQWChBd3qNI7Dk7lA.png)

Now, let’s just dive into the code.

We will need a class to maintain different file types supported. Later we will use this to create spring beans (_i.e. strategies_) with custom names.
```java
public class FileType {  
  public static final String CSV = "CSV";  
  public static final String XML = "XML";  
  public static final String JSON = "JSON";  
}
```
Create an interface for our File Parser
```java
public interface FileParser {  
  void parse(File file);  
}
```
Now that we have created an interface, let’s create different implementations for different file types _i.e. strategies_
```java
@Service(FileType.CSV)  
public class CsvFileParser implements FileParser {  
    
  @Override  
  public void parse(File file) {  
    // TODO : impl to parse csv file  
  }  
    
}

@Service(FileType.JSON)  
public class JsonFileParser implements FileParser {  
    
  @Override  
  public void parse(File file) {  
    // TODO : impl to parse json file  
  }  
    
}

@Service(FileType.XML)  
public class XmlFileParser implements FileParser {  
    
  @Override  
  public void parse(File file) {  
    // TODO : impl to parse xml file  
  }  
    
}
```

Notice that we have given custom names for the above beans which will help us inject all these three beans to our required class.

Now we need to find a way to choose one of the above implementations based on file type during runtime.

Let’s create a _FileParserFactory_ class. This class is responsible in deciding which implementation to choose given a file type. We will leverage spring boot’s awesome dependency injection feature to fetch the appropriate strategy during runtime. (_Refer the comments in the below code block for more details_ or [[2]](https://docs.spring.io/spring-framework/docs/current/javadoc-api/org/springframework/beans/factory/annotation/Autowired.html))
```java
@Component  
@RequiredArgsConstructor  
public class FileParserFactory {  
  
  /**  
   * Spring boot's dependency injection feature will construct this map for us  
   * and include all implementations available in the map with the key as the bean name  
   * Logically, the map will look something like below  
   * {  
   *   "CSV": CsvFileParser,  
   *   "XML": XmlFileParser,  
   *   "JSON": JsonFileParser  
   * }  
   */  
  private final Map<String, FileParser> fileParsers;  
  
  /**  
   * Return's the appropriate FileParser impl given a file type  
   * @param fileType one of the file types mentioned in class FileType  
   * @return FileParser  
   */  
  public FileParser get(String fileType) {  
    FileParser fileParser = fileParsers.get(fileType);  
    if (Objects.isNull(fileParser)) {  
      throw new IllegalArgumentException("Unsupported file type");  
    }  
    return fileParser;  
  }  
  
}
```
Now, let’s make changes to our _FileParserService_. We will use our _FileParserFactory_ to fetch the appropriate _FileParser_ based on the _fileType_ and call the _parse_ method.
```java
@Service  
@RequiredArgsConstructor  
public class FileParserService {  
    
  private final FileParserFactory fileParserFactory;  
    
  public void parse(File file, String fileType) {  
    FileParser fileParser = fileParserFactory.get(fileType);  
    fileParser.parse(file);  
  }  
    
}
```

# The Proxy Design Pattern

### Introduction

The **Proxy Design Pattern** is a **structural design pattern** that **_provides an intermediary to control access to an object._** This pattern acts as a placeholder or surrogate for another object, enabling additional functionality such as **lazy initialization, access control, logging, caching, and security**.

In this article, we will cover **everything** about the Proxy Pattern, including its **components, real-world use cases, best practices, and an in-depth implementation of API rate-limiting using proxies**.

### Understanding the Proxy Pattern

_A_ **_Proxy_** _is an object that controls access to another object_. The primary reasons for using a proxy include:

-   **Security**: Restricting access to certain functionalities.
-   **Performance Optimization**: Caching results and reducing computation.
-   **Lazy Instantiation**: Deferring the creation of resource-heavy objects.
-   **Logging and Monitoring**: Keeping track of access and modifications.
-   **Rate Limiting**: Restricting excessive API requests.

### Components of Proxy Pattern

![](https://miro.medium.com/v2/resize:fit:463/0*WJIrw-U7CTbhWs6Z)
Source: Refactoring Guru

1.  **Subject (Interface)**: Defines the common interface for RealSubject and Proxy.
2.  **RealSubject (Service)**: The actual object that performs the real functionality.
3.  **Proxy**: Controls access to the RealSubject and may add extra functionalities.

### Block Diagram

+------------+        +------------+        +--------------+  
|  Client    | -----> |   Proxy    | -----> | RealSubject  |  
+------------+        +------------+        +--------------+  
         Request       Controls Access       Actual Execution

### When and Where to Use the Proxy Pattern?

-   **Virtual Proxy**: Delays object creation (e.g., loading images in an image viewer only when required).
-   **Remote Proxy**: Represents an object in a different address space (e.g., RMI in Java).
-   **Protection Proxy**: Controls access based on user permissions (e.g., restricting access to admin functionalities).
-   **Smart Proxy**: Adds extra logic (e.g., reference counting, caching, logging).
-   **Rate-Limiting Proxy**: Restricts excessive API calls (e.g., API gateways throttling requests).

### Real-Life Examples

-   **Cloud Service Authentication**: AWS or Google Cloud APIs use API Gateway proxies for authentication and rate-limiting.
-   **Internet Proxy Servers**: Acting as intermediaries between users and websites for security and caching.
-   **Database Connection Pools**: Managing expensive database connections efficiently.
-   **Lazy-Loading in Web Applications**: Loading heavy resources only when necessary.

### Proxy Pattern in Action: API Rate Limiting

### Without Using Proxy Pattern

Let’s first implement an API rate limiter **without** a proxy.
```java
class APIService {  
    public void request(String userId) {  
        System.out.println("API request processed for user " + userId);  
    }  
}  
  
public class Main {  
    public static void main(String[] args) {  
        APIService service = new APIService();  
        service.request("user_123");  
        service.request("user_123");  
        service.request("user_123"); // No rate limiting here  
    }  
}
```
### Issues Without Proxy

-   **No access control**: Any number of requests can be made.
-   **Performance issues**: No control over request spamming.
-   **No logging and monitoring**.

### Implementing Proxy for Rate Limiting

Now, let’s use the **Proxy Pattern** to introduce rate-limiting.
```java
import java.util.Deque;  
import java.util.HashMap;  
import java.util.LinkedList;  
  
interface Service {  
    void request(String userId);  
}  
class APIService implements Service {  
    public void request(String userId) {  
        System.out.println("API request processed for user " + userId);  
    }  
}  
class RateLimitingProxy implements Service {  
    private final APIService realService;  
    private final int maxRequests;  
    private final long timeWindow;  
    private final HashMap<String, Deque<Long>> requestLog;  
    public RateLimitingProxy(APIService realService, int maxRequests, long timeWindow) {  
        this.realService = realService;  
        this.maxRequests = maxRequests;  
        this.timeWindow = timeWindow;  
        this.requestLog = new HashMap<>();  
    }  
    public void request(String userId) {  
        long currentTime = System.currentTimeMillis();  
        requestLog.putIfAbsent(userId, new LinkedList<>());  
        Deque<Long> requestTimes = requestLog.get(userId);  
          
        while (!requestTimes.isEmpty() && currentTime - requestTimes.peekFirst() > timeWindow) {  
            requestTimes.pollFirst();  
        }  
          
        if (requestTimes.size() < maxRequests) {  
            requestTimes.addLast(currentTime);  
            realService.request(userId);  
        } else {  
            System.out.println("Rate limit exceeded for user " + userId + ". Try again later.");  
        }  
    }  
}  
public class Main {  
    public static void main(String[] args) throws InterruptedException {  
        APIService realService = new APIService();  
        Service proxy = new RateLimitingProxy(realService, 2, 10000);  
        proxy.request("user_123");  
        proxy.request("user_123");  
        proxy.request("user_123"); // This request will be blocked  
    }  
}
```

### Advantages of Using Proxy

-   **Controlled Access**: Prevents spamming.
-   **Better Performance**: Avoids unnecessary loads on the service.
-   **Security & Monitoring**: Logs access and ensures fair use.

### Best Practices for Implementing Proxy Pattern

1.  **Use Proxies for Performance and Security**: Implement only when needed, such as caching or access control.
2.  **Keep Proxy Lightweight**: Avoid making the proxy more complex than the real object.
3.  **Decouple Proxy and RealSubject**: Use interfaces for better abstraction.
4.  **Log and Monitor Usage**: Especially for access control and performance enhancement.
5.  **Use Dependency Injection**: Inject real objects into the proxy instead of hardcoding them.

### Pros and Cons of Proxy Pattern

### Pros:

-   Improves performance with caching and lazy-loading.
-   Enhances security by controlling access.
-   Adds flexibility with logging and monitoring.
-   Supports remote objects in distributed systems.

### Cons:

-   Adds complexity to the codebase.
-   Can introduce latency if not optimized well.
-   Requires careful maintenance to avoid bottlenecks.

### Conclusion

The **Proxy Design Pattern** is a powerful tool for managing object access while adding functionalities like **security, logging, and performance optimizations**. We explored its detailed implementation for **API rate-limiting**, demonstrating how proxies efficiently regulate request handling.

By following **best practices**, we can effectively utilize the Proxy Pattern in various real-world scenarios, ensuring scalable and maintainable software architectures.
---

### Mastering the Adapter Design Pattern

### Introduction

Have you ever faced a situation where two systems or components don’t communicate with each other because they speak different ‘languages’? Just like a power plug adapter allows you to use your charger in a foreign country, _the_ **_Adapter Design Pattern_** _acts as a bridge between incompatible interfaces in software development._

In this article, we’ll dive deep into the **Adapter Design Pattern**, covering its features, use cases, real-world applications, best practices, step-by-step implementation, and a comparison with similar patterns.

### What is the Adapter Design Pattern?

The **Adapter Pattern** is a **structural design pattern** that allows objects with incompatible interfaces to work together. It acts as a middle layer that translates one interface into another, making it easier to integrate different parts of a system.

![](https://miro.medium.com/v2/resize:fit:725/0*kBgBtTIsCnK2DwZo.png)
Source: Refactoring Guru

### Key Features:

-   Converts one interface into another without modifying existing code.
-   Helps achieve reusability and flexibility in system design.
-   Can be implemented using **class-based** (inheritance) or **object-based** (composition) approaches.
-   Useful when integrating third-party libraries or legacy code.

### Why Do We Need the Adapter Pattern?

Modern software systems often involve integrating multiple components, APIs, or third-party services that were not designed to work together. This is where the **Adapter Pattern** comes in handy.

### When and Where to Use It?

-   **Legacy Code Integration**: When you need to use old classes in a new system but their interfaces don’t match.
-   **Third-Party Libraries**: When a library provides an interface that differs from what your system expects.
-   **Incompatible APIs**: When you need to unify the interaction between different APIs.
-   **Different Data Formats**: When data structures are inconsistent across different parts of a system.

### Real-World Applications of the Adapter Pattern

Let’s take some relatable examples to understand its significance.

### Example 1: Power Adapter (Everyday Life)

Imagine you travel to Europe with your laptop charger, but the power socket shape is different. A **power plug adapter** helps convert the socket format, making your charger compatible with the European power supply.

### Example 2: Payment Gateway Integration

Many e-commerce platforms integrate different payment gateways (PayPal, Stripe, Razorpay, etc.). Since each gateway has a different API format, an **adapter class** is used to standardize their interfaces, ensuring smooth payment processing.

### Example 3: Database Driver Adapters

JDBC (Java Database Connectivity) acts as an adapter between Java applications and multiple databases (MySQL, PostgreSQL, etc.). The application interacts with JDBC in a unified way, even though the underlying database drivers have different implementations.

### Components of Adapter Design Pattern

![](https://miro.medium.com/v2/resize:fit:725/0*4TDIErsNM6Y4I6vz.png)
Source: Refactoring Guru

1.  The **Client** is a class that contains the existing business logic of the program.
2.  The **Client Interface** describes a protocol that other classes must follow to be able to collaborate with the client code.
3.  The **Service** is some useful class (usually 3rd-party or legacy). The client can’t use this class directly because it has an incompatible interface.
4.  The **Adapter** is a class that’s able to work with both the client and the service: it implements the client interface, while wrapping the service object. The adapter receives calls from the client via the client interface and translates them into calls to the wrapped service object in a format it can understand.

The client code doesn’t get coupled to the concrete adapter class as long as it works with the adapter via the client interface. Thanks to this, you can introduce new types of adapters into the program without breaking the existing client code. This can be useful when the interface of the service class gets changed or replaced: you can just create a new adapter class without changing the client code.

### Class Adapter

This implementation uses inheritance: the adapter inherits interfaces from both objects at the same time.

![](https://miro.medium.com/v2/resize:fit:688/0*5dGaYL4ITjayTYE8.png)
Source: Refactoring Guru

The **Class Adapter** doesn’t need to wrap any objects because it inherits behaviors from both the client and the service. The adaptation happens within the overridden methods. The resulting adapter can be used in place of an existing client class.

**Note** that this approach can only be implemented in programming languages that support multiple inheritance, such as C++.

Since Java **does not support multiple inheritance**, we typically implement the **Adapter Pattern** using either **composition** or **interface implementation**.

### Adapter vs Other Structural Patterns

### Adapter vs Bridge

-   **Adapter** translates an existing interface to match what a client expects.
-   **Bridge** separates abstraction from implementation to allow independent modifications.

### Adapter vs Decorator

-   **Adapter** changes the interface of an object.
-   **Decorator** adds new functionality without altering the interface.

### Adapter vs Proxy

-   **Adapter** changes the interface.
-   **Proxy** controls access to an object (e.g., lazy initialization, access control).

### Best Practices for Implementing the Adapter Pattern

-   **Use Composition Over Inheritance**: Prefer object-based adapters to avoid tight coupling.
-   **Follow the Single Responsibility Principle**: The adapter should only handle interface conversion.
-   **Ensure Performance Efficiency**: Avoid excessive conversion logic that may slow down performance.
-   **Make It Reusable**: Design adapters that work across multiple use cases rather than being tightly bound to one implementation.

### Step-by-Step Implementation

### Example: Adapting a Legacy Logger in Java

**Scenario:** Suppose we have an old `LegacyLogger` class that only logs messages to a file, but our new system expects a logger with a `logToConsole` method.

### Step 1: Define the Incompatible Legacy Class
```java
class LegacyLogger {  
    public void logToFile(String message) {  
        System.out.println("Logging to a file: " + message);  
    }  
}
```

### Step 2: Define the Target Interface
```java
interface ModernLogger {  
    void logToConsole(String message);  
}
```
### Step 3: Create an Adapter Class
```java
class LoggerAdapter implements ModernLogger {  
    private LegacyLogger legacyLogger;  
  
    public LoggerAdapter(LegacyLogger legacyLogger) {  
        this.legacyLogger = legacyLogger;  
    }  
  
    @Override  
    public void logToConsole(String message) {  
        legacyLogger.logToFile(message); // Adapting old behavior  
    }  
}
```
### Step 4: Use the Adapter
```java
public class AdapterPatternDemo {  
    public static void main(String[] args) {  
        LegacyLogger legacyLogger = new LegacyLogger();  
        ModernLogger logger = new LoggerAdapter(legacyLogger);  
          
        logger.logToConsole("This is an adapted log message.");  
    }  
}
```
### Output:

Logging to a file: This is an adapted log message.

Here, `LoggerAdapter` bridges the gap between the legacy logger and the new system requirements.

### Pros and Cons of the Adapter Pattern

### ✅ Pros

1.  **Enables Reusability**: Allows integration of existing, incompatible classes without modification.
2.  **Enhances Flexibility**: Simplifies interactions between different systems.
3.  **Improves Maintainability**: Separates interface conversion logic into a dedicated class.

### ❌ Cons

1.  **Adds Complexity**: Introduces extra layers, which may be unnecessary for simple cases.
2.  **Performance Overhead**: If not implemented efficiently, frequent interface conversions can slow down performance.
3.  **Can Be Misused**: Overuse can lead to excessive abstraction, making the code harder to follow.

### Conclusion

The **Adapter Design Pattern** is a powerful tool when dealing with incompatible interfaces in software systems. Whether integrating legacy systems, third-party libraries, or different APIs, adapters help achieve seamless communication without modifying existing code. However, like any design pattern, it should be used judiciously to avoid unnecessary complexity.

By understanding its use cases, best practices, and implementation steps, you can leverage the **Adapter Pattern** effectively in your projects. Hope this guide helps you grasp the concept and apply it efficiently!
---


### Simplifying Complexity: The Facade Design Pattern
Imagine you walk into a five-star hotel. You don’t need to interact with the kitchen, housekeeping, or security separately. Instead, you go to the reception, and they handle everything for you. That’s exactly what the **Facade Design Pattern** does in software development — it provides a simple interface to interact with a complex system.

### What is the Facade Design Pattern?

The **Facade Design Pattern** is a structural pattern that provides a simplified interface to a complex system. It acts as a wrapper around multiple subsystems, making it easier for clients to use them without worrying about their internal complexities.

### How is it different from other patterns?

-   **Adapter Pattern**: Focuses on making incompatible interfaces work together.
-   **Proxy Pattern**: Controls access to an object.
-   **Facade Pattern**: Simplifies access to a complex system by providing a unified interface.

Think of the facade as a “shortcut” that helps you interact with a system without dealing with all the underlying components.

### When and Where to Use the Facade Design Pattern

### When should you use it?

-   When dealing with a system that has multiple interdependent subsystems.
-   When you want to decouple the client from complex implementation details.
-   When you need to provide a unified API for a group of related functionalities.

### Where is it commonly used?

-   **Home Automation Systems**: One button to turn off all lights, AC, and lock doors.
-   **E-commerce Platforms**: Handling payments, inventory updates, and order shipments through a single interface.
-   **Banking Applications**: Interfacing with multiple subsystems like loan processing, fraud detection, and account management.

### Why Use the Facade Design Pattern?

-   **Simplicity**: Reduces the number of direct interactions with complex subsystems.
-   **Loose Coupling**: Decouples client code from subsystems, making maintenance easier.
-   **Improved Readability**: Code becomes cleaner, easier to understand, and less error-prone.
-   **Better Scalability**: You can add more functionality behind the facade without affecting clients.

![](https://miro.medium.com/v2/resize:fit:875/0*6A8D78D_y7PvUFcz)

### Real-World Use Cases

Let’s take an example of an **Online Order Processing System**.

**Without Facade:** Each client directly interacts with multiple classes, making the code tightly coupled and difficult to manage.
```java
class PaymentProcessor {  
    public void processPayment() {  
        System.out.println("Processing payment...");  
    }  
}  
  
class InventorySystem {  
    public void updateInventory() {  
        System.out.println("Updating inventory...");  
    }  
}  
class ShippingService {  
    public void shipOrder() {  
        System.out.println("Shipping order...");  
    }  
}  
public class OrderSystem {  
    public static void main(String[] args) {  
        PaymentProcessor payment = new PaymentProcessor();  
        InventorySystem inventory = new InventorySystem();  
        ShippingService shipping = new ShippingService();  
          
        payment.processPayment();  
        inventory.updateInventory();  
        shipping.shipOrder();  
    }  
}
```
### Problems in the above approach:

-   **Tightly Coupled Code**: Clients need to manage multiple components.
-   **Complexity**: The client must know the exact sequence of method calls.
-   **Difficult Maintenance**: Any change in subsystems affects all client code.

### Solving This with the Facade Pattern

Instead of exposing multiple subsystems to the client, let’s introduce a **Facade**.
```java
class PaymentProcessor {  
    public void processPayment() {  
        System.out.println("Processing payment...");  
    }  
}  
  
class InventorySystem {  
    public void updateInventory() {  
        System.out.println("Updating inventory...");  
    }  
}  
class ShippingService {  
    public void shipOrder() {  
        System.out.println("Shipping order...");  
    }  
}  
// Facade Class  
class OrderFacade {  
    private PaymentProcessor paymentProcessor;  
    private InventorySystem inventorySystem;  
    private ShippingService shippingService;  
    public OrderFacade() {  
        this.paymentProcessor = new PaymentProcessor();  
        this.inventorySystem = new InventorySystem();  
        this.shippingService = new ShippingService();  
    }  
    public void placeOrder() {  
        paymentProcessor.processPayment();  
        inventorySystem.updateInventory();  
        shippingService.shipOrder();  
    }  
}  
// Client Code  
public class Client {  
    public static void main(String[] args) {  
        OrderFacade orderFacade = new OrderFacade();  
        orderFacade.placeOrder();  
    }  
}
```
### Benefits of Using the Facade Pattern

-   **Cleaner Client Code**: The client only interacts with `OrderFacade`.
-   **Loose Coupling**: Subsystems can change without affecting client code.
-   **Easier Maintenance**: Only the facade needs modification when subsystems change.

### Pros and Cons of the Facade Design Pattern

### Pros

-   **Simplifies Complex Systems**: Reduces the number of dependencies.
-   **Encapsulation of Subsystems**: Clients don’t need to know the details.
-   **Enhances Maintainability**: Changes in subsystems don’t impact client code.

### Cons

-   **Extra Abstraction Layer**: May introduce overhead.
-   **Overuse Can Be Harmful**: If used unnecessarily, it might add unwanted complexity.
-   **Less Flexibility**: If the client needs advanced functionality, the facade might limit its capabilities.

---

### Spring Project: Eliminating Inelegant ‘if-else’ and Code Coupling with This Design Pattern(Service Locator Pattern)
### Preface

I wonder if everyone has encountered such a scenario in projects where different implementation classes or service processing logics of an interface are called according to different incoming types.

For example, different messages are sent according to different alarm levels. For serious-level alarms, an email will be sent to remind developers. For disaster-level alarms, developers will be directly reminded by phone.

![](https://miro.medium.com/v2/resize:fit:875/1*FpFTiSt92CPrlb4X-93WkA.png)

Or different parsers are needed to process different file types. For example, XML files are processed by an XML parser, and JSON files are processed by a JSON parser.

![](https://miro.medium.com/v2/resize:fit:875/1*QGkdLIv69B1_OCqfOF8mog.png)

In the past, for such scenarios, we usually used `if-else` statements in the calling client. For example, if the type is equal to JSON, we use a JSON parser. If a new type of parser is added, does the calling client still need to be modified? This is obviously very inconvenient.

This article introduces a method using the Service Locator Pattern. Its core idea is interface-oriented programming, helping us eliminate tightly coupled implementations and relieve the client’s dependence on specific implementation classes.

### 1. Define an enumeration
```java
public enum ContentType {  
      JSON,  
      XML  
}
```

### 2. Define a parsing interface
```java
public interface Parser {  
      Map parse(Reader r);  
}
```

### 3. Different implementation classes for different file types
```java
@Component  
public class XMLParser implements Parser {   
      @Override  
      public Map parse(Reader r) {   
          //...  
      }  
}  
  
@Component  
public class JSONParser implements Parser {  
      @Override  
      public Map parse(Reader r) {   
          //...  
      }  
}
```

### 4. The client calls different implementations according to different types through `switch-case`
```java
@Service  
public class Client {  
      private Parser xmlParser, jsonParser;  
        
      @Autowired  
      public Client(Parser xmlParser, Parser jsonParser) {  
            this.xmlParser = xmlParser;  
            this.jsonParser = jsonParser;  
      }  
      public Map getAll(ContentType contentType) {  
            //...  
            switch (contentType) {  
                  case XML:  
                    return xmlParser.parse(reader);  
                  case JSON:  
                    return jsonParser.parse(reader);  
                   //...  
             }  
      }  
}
```

**Most people probably implement it in the way shown above and it can run normally. But think deeply, what problems exist?**

If the product manager requests support for CSV files, the client code needs to be modified by adding a new case in the `switch-case`.

This violates the open-closed principle in design patterns. Regression testing is advisable as the client is overly coupled with different parsers.

### Applying the Service Locator Pattern

Yes, that is to use the `Service Locator Pattern` we just mentioned. Now let's gradually implement the latest code.

### 1. Modify the enumeration and add CSV
```java
public enum ContentType {  
      JSON,  
      XML,  
      CSV  
}
```

### 2. Define the service locator interface `ParserFactory`

It has a method `getParser` that takes a content type as a parameter and returns the `Parser` interface.
```java
public interface ParserFactory {  
      Parser getParser(ContentType contentType);  
}
```
### 3. Configure ServiceLocatorFactoryBean

In the second step, we configure ServiceLocatorFactoryBean to use ParserFactory as the service locator interface. The interface ParserFactory does not need an implementation class.
```java
@Configuration  
public class ParserConfig {  
      
  @Bean("parserFactory")  
  public FactoryBean serviceLocatorFactoryBean() {  
        ServiceLocatorFactoryBean factoryBean = new ServiceLocatorFactoryBean();  
        // Set up the service locator interface.     
        factoryBean.setServiceLocatorInterface(ParserFactory.class);  
        return factoryBean;  
  }  
}
```
### 4. Set the bean name of the parser to be the same as the type name for service location

Set the name of the bean to be consistent with the type.
```java
@Component("CSV")  
public class CSVParser implements Parser {   
    //...   
}  
  
@Component("JSON")  
public class JSONParser implements Parser {   
    //...   
}  
  
@Component("XML")  
public class XMLParser implements Parser {   
    //...   
}
```
### 5. The client references ParserFactory and eliminates the dependence on specific Parsers

Now the client does not need to reference the specific implementation class of Parser. It can directly obtain the `Parser` interface with the corresponding function according to the type and call the corresponding parsing method, without `switch-case`.
```java
@Service  
public class Client {  
      private ParserFactory parserFactory;  
      @Autowired  
      public Client(ParserFactory parserFactory) {  
        this.parserFactory = parserFactory;  
      }  
      public Map getAll(ContentType contentType) {  
        // ...  
        // The key logic is to directly obtain the corresponding item according to the type.  
        Parser parser = parserFactory.getParser(contentType);  
        parser.parse(reader);  
      }  
}
```
By the way, if you think using the type directly as the bean name is not very elegant, you can further optimize it in the following way, mainly by expanding the ContentType enumeration.
```java
public enum ContentType {  
      JSON(TypeConstants.JSON_PARSER),  
      XML(TypeConstants.XML_PARSER),  
      CSV(TypeConstants.CSV_PARSER),  
      ;  
      private final String parserName;  
      
      ContentType(String parserName) {  
        this.parserName = parserName;  
      }  
  
      @Override  
      public String toString() {  
        return this.parserName;  
      }  
      
      public interface TypeConstants {  
          String CSV_PARSER = "csvParser";  
          String JSON_PARSER = "jsonParser";  
          String XML_PARSER = "xmlParser";   
      }  
}  
  
@Component(TypeConstants.CSV_PARSER)  
public class CSVParser implements Parser {   
    //...   
}  
  
@Component(TypeConstants.JSON_PARSER)  
public class JSONParser implements Parser {   
    //...   
}  
  
@Component(TypeConstants.XML_PARSER)  
public class XMLParser implements Parser {   
    //...   
}
```

### Analyzing the Principle of Service Locator Pattern

Through the previous case, presumably everyone basically knows how to use the service locator pattern. Now let’s deeply analyze its principle.

The service locator pattern eliminates the client’s dependence on specific implementations. The following quote from Martin Fowler’s article summarizes the core idea: “The basic idea behind a service locator is to have an object that knows how to obtain all the services that an application might need.

Therefore, the service locator of this application will have a method that returns a’service’ when needed.”

![](https://miro.medium.com/v2/resize:fit:875/1*KDT-YPnVX7s0g5IgA1j_TA.png)

The `ServiceLocatorFactoryBean` of the Spring framework implements the `FactoryBean` interface and creates a `Service Factory` bean.

### Summary

With the help of the service locator pattern, we have successfully implemented an excellent way to extend Spring’s inversion of control. This pattern helps us solve use cases where dependency injection does not provide the best solution.

However, it should be clear that dependency injection is still the first choice. In most cases, if the requirements do not change much, the service locator should not be used to replace dependency injection.

---
### Why Senior Java Developers Love the Strategy Pattern

In real-world Java applications, you often need to handle different behaviors based on a certain condition. This could be:

-   Calculating shipping costs using different providers
-   Applying discounts for different user types
-   Processing payments with different methods

The **Strategy Pattern** is one of the most practical design patterns to handle such cases. It allows you to **define a family of algorithms**, encapsulate each one, and make them interchangeable — without cluttering your code with `if-else` or `switch` statements.

![](https://miro.medium.com/v2/resize:fit:1250/1*6oTu-xrX2XNQ29MY5r4KUA.png)

In this article, we’ll walk through:

-   What the Strategy Pattern is
-   What problem it solves
-   A real-world Java example
-   A Spring Boot use case
-   When and why to use it

Let’s get started.

### The Problem: Too Many Conditionals

Suppose you’re building an e-commerce application that applies discounts to orders. The logic depends on the user type:

-   Guest: no discount
-   Member: 10% discount
-   Premium Member: 20% discount

You might be tempted to write:
```java
if (user.getType().equals("GUEST")) {  
    return amount;  
} else if (user.getType().equals("MEMBER")) {  
    return amount * 0.9;  
} else if (user.getType().equals("PREMIUM")) {  
    return amount * 0.8;  
}
```

This seems simple. But as rules grow, so do the conditionals. The method becomes harder to read, test, and maintain.

> _❌ Violates Open/Closed Principle  
> ❌ Hard to test individual logic  
> ❌ Not reusable_

### ✅ The Strategy Pattern Fix

The **Strategy Pattern** lets you encapsulate each algorithm (in this case, discount logic) into its own class. Then, the main code doesn’t care which strategy is used — it just uses the one that’s provided.

### Step-by-Step Java Example: Discount Calculation

Let’s implement the Strategy Pattern for the above discount scenario.

### Step 1: Define the Strategy Interface
```java
public interface DiscountStrategy {  
    double applyDiscount(double amount);  
}
```
### Step 2: Create Concrete Strategies
```java
public class GuestDiscount implements DiscountStrategy {  
    public double applyDiscount(double amount) {  
        return amount; // no discount  
    }  
}  
  
public class MemberDiscount implements DiscountStrategy {  
    public double applyDiscount(double amount) {  
        return amount * 0.9; // 10% off  
    }  
}  
  
public class PremiumDiscount implements DiscountStrategy {  
    public double applyDiscount(double amount) {  
        return amount * 0.8; // 20% off  
    }  
}
```
### Step 3: Context Class to Use Strategy
```java
public class DiscountService {  
    private final DiscountStrategy strategy;  
  
    public DiscountService(DiscountStrategy strategy) {  
        this.strategy = strategy;  
    }  
  
    public double calculate(double amount) {  
        return strategy.applyDiscount(amount);  
    }  
}
```
### Step 4: Using the Strategy
```java
public class Main {  
    public static void main(String[] args) {  
        DiscountService guestService = new DiscountService(new GuestDiscount());  
        System.out.println("Guest pays: " + guestService.calculate(100));  
  
        DiscountService memberService = new DiscountService(new MemberDiscount());  
        System.out.println("Member pays: " + memberService.calculate(100));  
  
        DiscountService premiumService = new DiscountService(new PremiumDiscount());  
        System.out.println("Premium pays: " + premiumService.calculate(100));  
    }  
}
```
**Output:**

Guest pays: 100.0    
Member pays: 90.0    
Premium pays: 80.0

> _✅ Cleaner logic  
> ✅ Easy to add new strategies  
> ✅ Easy to unit test and debug_

### Real-World Scenario: Payment Processing

Let’s say you need to support different payment methods: **Credit Card**, **PayPal**, and **UPI**. Each has its own way of processing payments.

### Step 1: Strategy Interface
```java
public interface PaymentStrategy {  
    void pay(double amount);  
}
```
### Step 2: Concrete Implementations
```java
public class CreditCardPayment implements PaymentStrategy {  
    public void pay(double amount) {  
        System.out.println("Paid $" + amount + " using Credit Card.");  
    }  
}  

public class PaypalPayment implements PaymentStrategy {  
    public void pay(double amount) {  
        System.out.println("Paid $" + amount + " using PayPal.");  
    }  
}  
  
public class UpiPayment implements PaymentStrategy {  
    public void pay(double amount) {  
        System.out.println("Paid $" + amount + " using UPI.");  
    }  
}
```
### Step 3: Context Class
```java
public class PaymentProcessor {  
    private final PaymentStrategy strategy;  
  
    public PaymentProcessor(PaymentStrategy strategy) {  
        this.strategy = strategy;  
    }  
  
    public void process(double amount) {  
        strategy.pay(amount);  
    }  
}
```
### Step 4: Using the Strategy
```java
public class Main {  
    public static void main(String[] args) {  
        PaymentProcessor processor = new PaymentProcessor(new PaypalPayment());  
        processor.process(250.0);  
  
        processor = new PaymentProcessor(new CreditCardPayment());  
        processor.process(150.0);  
  
        processor = new PaymentProcessor(new UpiPayment());  
        processor.process(50.0);  
    }  
}
```
### ✅ Benefits of Strategy Pattern

![](https://miro.medium.com/v2/resize:fit:875/1*fICtg7b5nQZ-xYbDvfE8qQ.png)

### Spring Boot Use Case: Dynamic Tax Calculation

You’re building an invoicing system in Spring Boot that supports different tax strategies based on customer location:

-   India: GST
-   USA: Sales Tax
-   UAE: No tax

Instead of putting all tax logic in one service, we’ll use Strategy Pattern.

### Step 1: Define Tax Strategy
```java
public interface TaxStrategy {  
    double calculateTax(double amount);  
}
```

### Step 2: Implement Each Strategy
```java
@Component("indiaTax")  
public class IndiaTax implements TaxStrategy {  
    public double calculateTax(double amount) {  
        return amount * 0.18;  
    }  
}  
  
@Component("usaTax")  
public class USATax implements TaxStrategy {  
    public double calculateTax(double amount) {  
        return amount * 0.07;  
    }  
}  
  
@Component("uaeTax")  
public class UAETax implements TaxStrategy {  
    public double calculateTax(double amount) {  
        return 0;  
    }  
}
```
### Step 3: Tax Service Using Strategy
```java
@Service  
public class TaxService {  
  
    private final Map<String, TaxStrategy> strategyMap;  
  
    public TaxService(List<TaxStrategy> strategies) {  
        this.strategyMap = Map.of(  
            "IN", strategies.stream().filter(s -> s instanceof IndiaTax).findFirst().orElseThrow(),  
            "US", strategies.stream().filter(s -> s instanceof USATax).findFirst().orElseThrow(),  
            "AE", strategies.stream().filter(s -> s instanceof UAETax).findFirst().orElseThrow()  
        );  
    }  
  
    public double getTax(String countryCode, double amount) {  
        TaxStrategy strategy = strategyMap.get(countryCode);  
        if (strategy == null) throw new IllegalArgumentException("Unsupported country");  
        return strategy.calculateTax(amount);  
    }  
}
```

### Step 4: REST Controller
```java
@RestController  
@RequestMapping("/invoice")  
public class InvoiceController {  
  
    private final TaxService taxService;  
  
    public InvoiceController(TaxService taxService) {  
        this.taxService = taxService;  
    }  
  
    @GetMapping("/tax")  
    public ResponseEntity<String> getTax(  
        @RequestParam String country,  
        @RequestParam double amount  
    ) {  
        double tax = taxService.getTax(country, amount);  
        return ResponseEntity.ok("Tax: " + tax);  
    }  
}
```
### Example Request

GET /invoice/tax?country=IN&amount=1000

**Output:**

Tax: 180.0

> _This structure allows you to_ **_plug in new tax rules_** _without modifying your service or controller._

### Strategy + Lambdas (Java 8+ Bonus)

You can also use lambdas to simplify the pattern when strategy logic is small.
```java
Map<String, Function<Double, Double>> strategies = new HashMap<>();  
strategies.put("IN", amount -> amount * 0.18);  
strategies.put("US", amount -> amount * 0.07);  
strategies.put("AE", amount -> 0.0);  
  
double tax = strategies.get("IN").apply(1000.0); // 180.0
```
> _This is useful for simple strategies and can reduce boilerplate code._

### ✅ When to Use Strategy Pattern

-   You have multiple ways to perform the same task
-   Business rules change by condition or type
-   You want to eliminate `if-else` chains
-   You want each logic to be tested independently
-   You expect new behaviors to be added later

### 🚫 When Not to Use It

-   You have a single, simple condition
-   Strategies won’t change or grow
-   Logic is trivial and doesn’t require reuse
-   You don’t need polymorphism or flexibility

# Strategy Pattern

### Implementing the Strategy Design pattern in Spring Boot

### The Problem

Let’s say you are working on a feature called File Parser. You need to write an API where you can upload a file and our system should be able to extract the data from it and persist them in the database. Currently we are asked to support _CSV_, _JSON_ and _XML_ files. Our immediate solution would look something like below.
```java
@Service  
public class FileParserService {  
    
  public void parse(File file, String fileType) {  
    if (Objects.equals(fileType, "CSV")) {  
      // TODO : a huge implementation to parse CSV file and persist data in db  
    } else if (Objects.equals(fileType, "JSON")) {  
      // TODO : a huge implementation to parse JSON file and persist data in db  
    } else if (Objects.equals(fileType, "XML")) {  
      // TODO : a huge implementation to parse XML file and persist data in db  
    } else {  
      throw new IllegalArgumentException("Unsupported file type");  
    }  
  }  
    
}
```
Everything looks good now from the business perspective but things will start getting uglier when we want to support more file types in the future. We start adding multiple else if blocks and the size of the class will quickly grow which will eventually become too hard to maintain. Any change to one of the implementations of the file parser will affect the whole class thereby increasing the chance of introducing a bug in an already working functionality.

Not only that, but there is another problem. Let’s say now we need to additionally support _sqlite_ and _parquet_ file types. Two developers will step in and they will start working on the same huge class. It is highly likely that they will get merge conflicts which is not only irritating for any developer but also time consuming to resolve them. Most importantly, even after the conflict resolution, there would be decreased confidence in terms of the feature working as a whole.

### The Solution

This is where the Strategy Design pattern steps in to our rescue. We will move all the file parser implementations to separate classes called _strategies._ In the current class, we shall dynamically fetch the appropriate implementation based on file type and execute the strategy.

Here’s a UML diagram to provide a high-level overview of the design pattern that we are about to implement.

![](https://miro.medium.com/v2/resize:fit:875/1*u0uGWJQWChBd3qNI7Dk7lA.png)

Now, let’s just dive into the code.

We will need a class to maintain different file types supported. Later we will use this to create spring beans (_i.e. strategies_) with custom names.
```java
public class FileType {  
  public static final String CSV = "CSV";  
  public static final String XML = "XML";  
  public static final String JSON = "JSON";  
}
```
Create an interface for our File Parser
```java
public interface FileParser {  
  void parse(File file);  
}
```
Now that we have created an interface, let’s create different implementations for different file types _i.e. strategies_
```java
@Service(FileType.CSV)  
public class CsvFileParser implements FileParser {  
    
  @Override  
  public void parse(File file) {  
    // TODO : impl to parse csv file  
  }  
    
}

@Service(FileType.JSON)  
public class JsonFileParser implements FileParser {  
    
  @Override  
  public void parse(File file) {  
    // TODO : impl to parse json file  
  }  
    
}

@Service(FileType.XML)  
public class XmlFileParser implements FileParser {  
    
  @Override  
  public void parse(File file) {  
    // TODO : impl to parse xml file  
  }  
    
}
```

Notice that we have given custom names for the above beans which will help us inject all these three beans to our required class.

Now we need to find a way to choose one of the above implementations based on file type during runtime.

Let’s create a _FileParserFactory_ class. This class is responsible in deciding which implementation to choose given a file type. We will leverage spring boot’s awesome dependency injection feature to fetch the appropriate strategy during runtime. (_Refer the comments in the below code block for more details_ or [[2]](https://docs.spring.io/spring-framework/docs/current/javadoc-api/org/springframework/beans/factory/annotation/Autowired.html))
```java
@Component  
@RequiredArgsConstructor  
public class FileParserFactory {  
  
  /**  
   * Spring boot's dependency injection feature will construct this map for us  
   * and include all implementations available in the map with the key as the bean name  
   * Logically, the map will look something like below  
   * {  
   *   "CSV": CsvFileParser,  
   *   "XML": XmlFileParser,  
   *   "JSON": JsonFileParser  
   * }  
   */  
  private final Map<String, FileParser> fileParsers;  
  
  /**  
   * Return's the appropriate FileParser impl given a file type  
   * @param fileType one of the file types mentioned in class FileType  
   * @return FileParser  
   */  
  public FileParser get(String fileType) {  
    FileParser fileParser = fileParsers.get(fileType);  
    if (Objects.isNull(fileParser)) {  
      throw new IllegalArgumentException("Unsupported file type");  
    }  
    return fileParser;  
  }  
  
}
```
Now, let’s make changes to our _FileParserService_. We will use our _FileParserFactory_ to fetch the appropriate _FileParser_ based on the _fileType_ and call the _parse_ method.
```java
@Service  
@RequiredArgsConstructor  
public class FileParserService {  
    
  private final FileParserFactory fileParserFactory;  
    
  public void parse(File file, String fileType) {  
    FileParser fileParser = fileParserFactory.get(fileType);  
    fileParser.parse(file);  
  }  
    
}
```

# Observer Design Pattern

### Why Use the Observer Pattern?

The Observer Pattern helps with:

**Decoupling**: It decouples the subject from its observers, meaning the subject doesn’t need to know who or how many observers there are.
**Event handling**: Whenever the state of the subject changes, all dependent observers are notified automatically.
**Dynamic relationships**: New observers can be added or removed at runtime without affecting the subject.

### How Does It Work?

There are three main components:

1.  **Subject**: The object that holds the state and notifies the observers.
2.  **Observer**: Objects that listen for state changes in the subject.
3.  **ConcreteSubject**: The class that implements the Subject interface.
4.  **ConcreteObserver**: The class that implements the Observer interface and responds to changes in the subject.

### Real-World Example

Imagine you’re working on a **weather application**. The weather station (Subject) collects data such as temperature and humidity. You have multiple displays (Observers) that should automatically update whenever the weather data changes. Instead of having the displays continually check for new data, they can simply be notified by the weather station when there’s a change.

### UML Diagram Representation:

![](https://miro.medium.com/v2/resize:fit:760/1*CobU1-8Wzk2AM3JGxKLEZA.png)

### Implementing the Observer Pattern in Java

Let’s go step by step to implement this pattern in Java.

###### Step 1: Create the Subject Interface

The Subject will have methods to register, remove, and notify observers.
```java
import java.util.ArrayList;  
import java.util.List;interface Subject {  
    void addObserver(Observer o);  
    void removeObserver(Observer o);  
    void notifyObservers();  
}
```
### Step 2: Create the Observer Interface

The Observer defines an `update()` method that will be called by the Subject whenever there is a change.
```java
interface Observer {  
    void update(float temperature, float humidity);  
}
```

###### Step 3: Create the Concrete Subject (WeatherStation)

This class implements the Subject interface and holds the current state (temperature and humidity). It notifies all registered observers when the state changes.
```java
class WeatherStation implements Subject {  
    private List<Observer> observers;  
    private float temperature;  
    private float humidity;  
public WeatherStation() {  
        this.observers = new ArrayList<>();  
    }  
    @Override  
    public void addObserver(Observer o) {  
        observers.add(o);  
    }  
    @Override  
    public void removeObserver(Observer o) {  
        observers.remove(o);  
    }  
    @Override  
    public void notifyObservers() {  
        for (Observer observer : observers) {  
            observer.update(temperature, humidity);  
        }  
    }  
    public void setMeasurements(float temperature, float humidity) {  
        this.temperature = temperature;  
        this.humidity = humidity;  
        notifyObservers(); // notify all observers of the change  
    }  
}
```
### Step 4: Create the Concrete Observer (Display)

This class implements the Observer interface. It updates itself whenever the WeatherStation notifies it of a change.
```java
class WeatherDisplay implements Observer {  
    private float temperature;  
    private float humidity;     
    @Override  
    public void update(float temperature, float humidity) {  
        this.temperature = temperature;  
        this.humidity = humidity;  
        display();  
    }  
    public void display() {  
        System.out.println("Current conditions: " + temperature + "C degrees and " + humidity + "% humidity");  
    }  
}
```
### Step 5: Test the Implementation

Now, let’s put everything together. We will create a weather station, attach two displays to it, and simulate changes in the weather.
```java
public class ObserverPatternDemo {  
    public static void main(String[] args) {  
        WeatherStation weatherStation = new WeatherStation();  
          
        // Create two displays and register them as observers  
        WeatherDisplay display1 = new WeatherDisplay();  
        WeatherDisplay display2 = new WeatherDisplay();  
          
        weatherStation.addObserver(display1);  
        weatherStation.addObserver(display2);// Simulate changes in weather data  
        weatherStation.setMeasurements(25.5f, 65.0f);  
        weatherStation.setMeasurements(27.3f, 70.0f);  
    }  
}
```
### Output:

Current conditions: 25.5C degrees and 65.0% humidity  
Current conditions: 25.5C degrees and 65.0% humidity  
Current conditions: 27.3C degrees and 70.0% humidity  
Current conditions: 27.3C degrees and 70.0% humidity

### Advantages of the Observer Pattern

1.  **Loose coupling**: The subject does not need to know who its observers are, only that they implement the Observer interface.
2.  **Open/Closed Principle**: You can add or remove observers without modifying the subject’s code.
3.  **Scalability**: Many observers can subscribe to a single subject, allowing scalable event handling.

### Disadvantages of the Observer Pattern

1.  **Memory leaks**: If observers are not properly removed, memory leaks can occur, as the subject holds references to them.
2.  **Overhead**: If there are many observers, notifying all of them can introduce performance overhead.
3.  **Unpredictable updates**: Observers may update in an unpredictable order, which can cause issues if the order of updates is important.

### When to Use the Observer Pattern

When an object needs to notify other objects about changes in its state.

In scenarios like:

**Event listeners** in GUI applications.

**Real-time data feeds**, like stock tickers or live scores.

**Messaging systems**, such as RabbitMQ or Kafka.

### Conclusion

The Observer Pattern is essential for building systems that need to handle events or real-time updates. Its decoupled nature allows easy scalability and flexibility in adding new components. However, it should be used judiciously, keeping in mind the potential for memory management issues and performance concerns when managing a large number of observers.

By mastering the Observer Design Pattern, you can build more dynamic and adaptable systems, capable of efficiently handling real-time changes.

---

# Throttling Design Pattern to Handle an Extreme Load 

Controlling the consumption of resources used by an app or service allows the system to continue to function and meet SLA, even if there is an extreme load on resources. The load on an application typically varies over time based on the number of active users or the type of activities they’re performing.

If the processing requirements of the system exceed the capacity of the resources that are available, it’ll suffer from poor performance and can even fail. There are many strategies available for handling varying load in the cloud. One strategy is to use autoscaling to match the provisioned resources to the user needs at any given time. This has the potential to consistently meet user demand, while optimizing running costs.

However, while autoscaling can trigger the provisioning of more resources, this provisioning isn’t immediate. If demand grows quickly, there can be a window of time where there’s a resource deficit.

### The Solution

An alternative strategy to autoscaling is to allow applications to use resources only up to a limit, and then throttle them when this limit is reached. The system should monitor how it’s using resources so that, when usage exceeds the threshold, it can throttle requests from one or more users.

**Throttling strategies**

-   Rejecting requests from an individual user who’s already accessed system APIs more than n times per second over a given period of time.
-   Disabling or degrading the functionality of selected nonessential services so that essential services can run unimpeded with sufficient resources. For example, if the application is streaming video output, it could switch to a lower resolution.
-   Using load leveling to smooth the volume of activity. If the system must support a mix of tenants with different SLAs, the work for high-value tenants might be performed immediately. Requests for other tenants can be held back, and handled when the backlog has eased. The [Priority Queue pattern](https://learn.microsoft.com/en-us/azure/architecture/patterns/priority-queue) could be used to help implement this approach.
-   You should be careful when integrating with some 3rd-party services that might become unavailable or return errors. Reduce the number of concurrent requests being processed so that the logs do not unnecessarily fill up with errors. You also avoid the costs that are associated with needlessly retrying the processing of requests that would fail because of that 3rd-party service. Then, when requests are processed successfully, go back to regular unthrottled request processing.

The autoscaling and throttling approaches can also be combined to help keep the applications responsive and within SLAs. If the demand is expected to remain high, throttling provides a temporary solution while the system scales out. At this point, the full functionality of the system can be restored.

### Issues and considerations

-   Throttling an application, and the strategy to use, is an architectural decision that impacts the entire design of a system. Throttling should be considered early in the application design process because it isn’t easy to add once a system has been implemented.
-   Throttling must be performed quickly. The system must be capable of detecting an increase in activity and react accordingly. The system must also be able to revert to its original state quickly after the load has eased. This requires that the appropriate performance data is continually captured and monitored.
-   If a service needs to deny a user request temporarily, it should return a specific error code like 429 (“Too many requests”) and 503 (“Server Too Busy”) so the client application can understand that the reason for the refusal to serve a request is due to throttling.
-   If throttling is being used as a temporary measure while a system autoscales, and if resource demands grow very quickly, the system might not be able to continue functioning — even when operating in a throttled mode. If this isn’t acceptable, consider maintaining larger capacity reserves and configuring more aggressive autoscaling.

### When to use this pattern

-   To ensure that a system continues to meet service level agreements.
-   To prevent a single tenant from monopolizing the resources provided by an application.
-   To handle bursts in activity.
-   To help cost-optimize a system by limiting the maximum resource levels needed to keep it functioning.

---

# Compensating Transaction Design Pattern

### Overview

If one or more steps fail, you can use the Compensating Transaction pattern to undo the work that the steps performed. Typically, you find operations that follow the eventual consistency model in cloud-hosted applications that implement complex business processes and workflows.

Applications that run in the cloud frequently modify data. This data is sometimes spread across various data sources in different geographic locations. To avoid contention and improve performance in a distributed environment, an application shouldn’t try to provide strong transactional consistency. Rather, the application should implement eventual consistency.

In the eventual consistency model, a typical business operation consists of a series of separate steps. While the operation performs these steps, the overall view of the system state might be inconsistent. But when the operation finishes and all the steps have run, the system should become consistent again.

### The Problem

A challenge in the eventual consistency model is how to handle a step that fails. After a failure, you might need to undo all the work that previous steps in the operation completed. However, you can’t always roll back the data, because other concurrent instances of the application might have changed it. Even in cases where concurrent instances haven’t changed the data, undoing a step might be more complex than restoring the original state.

If an operation that implements eventual consistency spans several heterogeneous data stores, undoing the steps in the operation requires visiting each data store in turn. **To prevent the system from remaining inconsistent, you must reliably undo the work that you performed in every data store.**

### Solution

The solution is to implement a compensating transaction. The steps in a compensating transaction undo the effects of the steps in the original operation. An intuitive approach is to replace the current state with the state the system was in at the start of the operation. But a compensating transaction can’t always take that approach, because it might overwrite changes that other concurrent instances of an application have made. Instead, a compensating transaction must be an intelligent process that takes into account any work that concurrent instances do. This process is usually application-specific.

A common approach is to use a workflow to implement an eventually consistent operation that requires compensation. As the original operation proceeds, the system records information about each step, including how to undo the work that the step performs. If the operation fails at any point, the workflow rewinds back through the steps it has completed. At each step, the workflow performs the work that reverses that step.

Two important points are:

-   A compensating transaction might not have to undo the work in the exact reverse order of the original operation.
-   It might be possible to perform some of the undo steps in parallel.

A compensating transaction is an eventually consistent operation itself, so it can also fail. The system should be able to resume the compensating transaction at the point of failure and continue. It might be necessary to repeat a step that fails, so you should define the steps in a compensating transaction as [idempotent commands](https://learn.microsoft.com/en-us/azure/architecture/reference-architectures/containers/aks-mission-critical/mission-critical-data-platform###idempotent-message-processing).

In some cases, manual intervention might be the only way to recover from a step that has failed. In these situations, the system should raise an alert and provide as much information as possible about the reason for the failure.

Use this pattern only for operations that must be undone if they fail. If possible, design solutions to avoid the complexity of requiring compensating transactions. As with any design decision, consider any tradeoffs against the goals of the other pillars that might be introduced with this pattern.

### Example

Customers use a travel website to book itineraries. A single itinerary might consist of a series of flights and hotels. A customer who travels from Seattle to London and then on to Paris might perform the following steps when creating an itinerary:

1.  Book a seat on flight F1 from Seattle to London.
2.  Book a seat on flight F2 from London to Paris.
3.  Book a seat on flight F3 from Paris to Seattle.
4.  Reserve a room at hotel H1 in London.
5.  Reserve a room at hotel H2 in Paris.

These steps constitute an eventually consistent operation, although each step is a separate action. Besides performing these steps, the system must also record the counter operations for undoing each step. This information is needed in case the customer cancels the itinerary. The steps that are necessary to perform the counter operations can then run as a compensating transaction.

The steps in the compensating transaction might not be the exact opposite of the original steps. Also, the logic in each step in the compensating transaction must take business-specific rules into account. For example, canceling a flight reservation might not entitle the customer to a complete refund.

The following figure shows the steps in a long-running transaction for booking a travel itinerary. You can also see the compensating transaction steps that undo the transaction.

---

# Materialized View Design Pattern for Efficient Data Querying
When storing data, the priority for developers and data administrators is often focused on how the data is stored, as opposed to how it’s read. The chosen storage format is usually closely related to the format of the data, requirements for managing data size and data integrity, and the kind of store in use. For example, when using NoSQL document store, the data is often represented as a series of aggregates, each containing all of the information for that entity.

However, this can have a negative effect on queries. When a query only needs a subset of the data from some entities, such as a summary of orders for several customers without all of the order details, it must extract all of the data for the relevant entities in order to obtain the required information.

### Solution

To support efficient querying, a common solution is to generate, in advance, a view that materializes the data in a format suited to the required results set. The Materialized View pattern describes generating prepopulated views of data in environments where the source data isn’t in a suitable format for querying, where generating a suitable query is difficult, or where query performance is poor due to the nature of the data or the data store.

These materialized views, which only contain data required by a query, allow applications to quickly obtain the information they need. A key point is that a materialized view and the data it contains is completely disposable because it can be entirely rebuilt from the source data stores. A materialized view is never updated directly by an application, and so it’s a specialized cache.

When the source data for the view changes, the view must be updated to include the new information. You can schedule this to happen automatically, or when the system detects a change to the original data. In some cases it might be necessary to regenerate the view manually. The figure shows an example of how the Materialized View pattern might be used.

![](https://miro.medium.com/v2/resize:fit:875/0*fSVLeE2GUIeE8BF2.png)

Consider the following points when deciding how to implement this pattern:

-   How and when the view will be updated
-   In some systems, such as when using the Event Sourcing pattern to maintain a store of only the events that modified the data, materialized views are necessary.
-   If you’re not using Event Sourcing, you need to consider whether a materialized view is helpful or not.
-   Materialized views tend to be specifically tailored to one, or a small number of queries. If many queries are used, materialized views can result in unacceptable storage capacity requirements and storage cost.
-   Consider the impact on data consistency when generating the view, and when updating the view if this occurs on a schedule.
-   Consider where you’ll store the view. The view doesn’t have to be located in the same store or partition as the original data. It can be a subset from a few different partitions combined.
-   A view can be rebuilt if lost. Because of that, if the view is transient and is only used to improve query performance by reflecting the current state of the data, or to improve scalability, it can be stored in a cache or in a less reliable location.
-   When defining a materialized view, maximize its value by adding data items or columns to it based on computation or transformation of existing data items, on values passed in the query, or on combinations of these values when appropriate.
-   Where the storage mechanism supports it, consider indexing the materialized view to further increase performance.

### When to use this pattern

-   Creating materialized views over data that’s difficult to query directly, or where queries must be very complex to extract data that’s stored in a normalized, semi-structured, or unstructured way.
-   Creating temporary views that can dramatically improve query performance or can act directly as source views or data transfer objects for the UI, for reporting, or for display.
-   Supporting occasionally connected or disconnected scenarios where connection to the data store isn’t always available. The view can be cached locally in this case.
-   Simplifying queries and exposing data for experimentation in a way that doesn’t require knowledge of the source data format.
-   Providing access to specific subsets of the source data that, for security or privacy reasons, shouldn’t be generally accessible, open to modification, or fully exposed to users.
-   Bridging different data stores, to take advantage of their individual capabilities.
-   When using microservices, you are recommended to keep them loosely coupled, including their data storage. Therefore, materialized views can help you consolidate data from your services.

This pattern isn’t useful in the following situations:

-   The source data is simple and easy to query.
-   The source data changes very quickly, or can be accessed without using a view. In these cases, you should avoid the processing overhead of creating views.
-   Consistency is a high priority. The views might not always be fully consistent with the original data.

For more information and a specific example checkout the full article on Microsoft Learn platform.

Source: [Materialized View pattern — Azure Architecture Center | Microsoft Learn](https://learn.microsoft.com/en-us/azure/architecture/patterns/materialized-view)

---

### Designing Self-Healing Applications for Failure Resilience
### Overview

In a distributed system, failures must be expected to happen. Hardware can fail. The network can have transient failures. Resiliency and recovery should be addressed early in your workload design.

Designing for self-healing requires a three-pronged approach:

-   Detect failures.
-   Respond to failures gracefully.
-   Log and monitor failures to give operational insight.

Also, don’t just consider big events like regional outages, which are generally rare. You should focus as much, if not more, on handling local, short-lived failures, such as network connectivity failures or failed database connections.

### Recommendations

-   **Use decoupled components that communicate asynchronously**. Components should ideally use events to communicate with each other. This helps to minimize the chance of cascading failures.
-   **Retry failed operations**. Transient failures might occur due to momentary loss of network connectivity, a dropped database connection, or a timeout when a service is busy. Build retry logic into your application to handle transient failures.
-   **Protect failing remote services (Circuit Breaker)**. It’s good to retry after a transient failure, but if the failure persists, you can end up with too many callers hammering a failing service. This can lead to cascading failures as requests back up. Use the Circuit Breaker pattern to fail fast (without making the remote call) when an operation is likely to fail.
-   **Isolate critical resources (Bulkhead)**. Failures in one subsystem can sometimes cascade. This can happen if a failure causes some resources, such as threads or sockets, not to be freed in a timely manner, leading to resource exhaustion. To avoid this, use the Bulkhead pattern to partition a system into isolated groups so that a failure in one partition does not bring down the entire system.
-   **Perform load leveling**. Applications might experience sudden spikes in traffic that can overwhelm services on the backend. To avoid this, use the Queue-Based Load Leveling pattern to queue work items to run asynchronously. The queue acts as a buffer that smooths out peaks in the load.
-   **Fail over**. If an instance can’t be reached, fail over to another instance. For things that are stateless, like a web server, put several instances behind a load balancer or traffic manager. For things that store state, like a database, use replicas and fail over. Depending on the data store and how it replicates, the application might have to deal with eventual consistency.
-   **Compensate failed transactions**. In general, avoid distributed transactions, as they require coordination across services and resources. Instead, compose an operation from smaller individual transactions. If the operation fails midway through, use Compensating Transactions to undo any step that already completed.
-   **Checkpoint long-running transactions**. Checkpoints can provide resiliency if a long-running operation fails. When the operation restarts (for example, it is picked up by another VM), it can be resumed from the last checkpoint. Consider implementing a mechanism that records state information about the task at regular intervals, and save this state in durable storage that can be accessed by any instance of the process running the task. In this way, if the process is shut down, the work that it was performing can be resumed from the last checkpoint by using another instance.
-   **Degrade gracefully and stay responsive during failure**. Sometimes you can’t work around a problem, but you can provide reduced functionality that is still useful. Consider an application that shows a catalog of books. If the application can’t retrieve the thumbnail image for the cover, it might show a placeholder image. Entire subsystems might be noncritical for the application. For example, on an e-commerce site, showing product recommendations is probably less critical than processing orders.
-   **Throttle clients**. Sometimes a small number of users create excessive load, which can reduce your application’s availability for other users. In this situation, throttle the client for a certain period of time.
-   **Block bad actors**. Just because you throttle a client, it doesn’t mean client was acting maliciously. It just means the client exceeded their service quota. But if a client consistently exceeds their quota or otherwise behaves badly, you might block them. Define an out-of-band process for user to request getting unblocked.
-   **Use leader election**. When you need to coordinate a task, use Leader Election to select a coordinator. That way, the coordinator is not a single point of failure. If the coordinator fails, a new one is selected. Rather than implement a leader election algorithm from scratch, consider an off-the-shelf solution such as Zookeeper.
-   **Test with fault injection**. All too often, the success path is well tested but not the failure path. A system could run in production for a long time before a failure path is exercised. Use fault injection to test the resiliency of the system to failures, either by triggering actual failures or by simulating them.
-   **Embrace chaos engineering**. Chaos engineering extends the notion of fault injection by randomly injecting failures or abnormal conditions into production instances.
-   **Use availability zones**. Cloud regions provide availability zones, which are isolated sets of data centers within the region. Some services can be deployed _zonally_, which ensures they are placed in a specific zone and can help reduce latency in communicating between components in the same workload. Alternatively, some services can be deployed with _zone redundancy_, which means that cloud automatically replicates the resource across zones for high availability. Consider which approach provides the best set of tradeoffs for your solution.

---

# Network Secure Ingress design pattern
![](https://miro.medium.com/v2/resize:fit:798/0*btDBWkSJBcG0Jj1v.png)
Network secure ingress pattern implementation with Azure Front Door Premium tier — Azure Architecture Center | Microsoft Learn

Network secure ingress encapsulates several design patterns, including the patterns for global routing, global offloading, and health endpoint monitoring. Network secure ingress focuses on: **global routing**, **low-latency failover**, and **mitigating attacks at the edge**.

Above is the diagram containing 3 requirements.

-   The network secure ingress pattern encapsulates the global routing pattern. As such, the implementation can route requests to workloads in different regions.
-   The implementation must be able to identify healthy and unhealthy workloads and adjust the routing accordingly in a time-sensitive way. The latency should be able to support adjusting the routing in a matter of minutes.
-   Mitigating attacks at the edge necessitates the “network secure” part of the implementation. The workloads or platform as a service (PaaS) services shouldn’t be accessible via the internet. Internet traffic should only be able to route through the gateway. The gateway should have the ability to mitigate exploits.

Hers is the implementation example with the Azure Cloud services.

![](https://miro.medium.com/v2/resize:fit:600/0*Nh1Mq7igBKTH6Y6d.png)
Network secure ingress pattern implementation with Azure Front Door Premium tier — Azure Architecture Center | Microsoft Learn

### Request flow

![](https://miro.medium.com/v2/resize:fit:641/0*RMBMDwRkxn5eJFWc.png)
Network secure ingress pattern implementation with Azure Front Door Premium tier — Azure Architecture Center | Microsoft Learn

1.  The user issues an HTTP or HTTPS request to an Azure Front Door endpoint.
2.  The WAF rules are evaluated. Rules that match are always logged. If the Azure Front Door WAF policy mode is set to _prevention_ and the matching rule has an action set to _block on anomaly_, the request is blocked. Otherwise, the request continues or is redirected, or the subsequent rules are evaluated.
3.  The route configured in Azure Front Door is matched and the correct origin group is selected. In this example, the path was to the static content in the website.
4.  The origin is selected from the origin group.
5.  a. In this example, the health probes deemed the website unhealthy, so it’s eliminated from the possible origins.  
    b. This website is selected.
6.  The request is routed to the Azure storage account via Private Link over the Microsoft backbone network.

### **Key benefits**

Here are the key benefits when implementing Network Secure Ingress pattern

-   Global routing with low latency, through the use of health probes, enables reliability by insulating the application against regional outages.
-   Provides centralized protection for HTTP and HTTPS requests.
-   Eliminates the need to expose your internal or PaaS services over the internet.
-   Global routing enables horizontal scaling through the deployment of more resources in the same region or different regions.

**Sources**

Here are more information regarding the mentioned 3 patterns

-   [Gateway routing pattern](https://learn.microsoft.com/en-us/azure/architecture/patterns/gateway-routing): Route requests to multiple services or service instances that can reside in different regions.
-   [Gateway offloading pattern](https://learn.microsoft.com/en-us/azure/architecture/patterns/gateway-offloading): Offload functionality, such as mitigating attacks, to a gateway proxy.
-   [Health endpoint monitoring pattern](https://learn.microsoft.com/en-us/azure/architecture/patterns/health-endpoint-monitoring): Expose endpoints that validate the health of the workload.

---
# When to Use Event Sourcing. Event sourcing can be awesome

### What Is Event Sourcing?

Most web applications store the _state_ of a system in the database.

Suppose you’re asked to design the database of a webshop. Most likely, a traditional sequel database design will have a `users`, `products`, and `orders` table — representing the _state_ of the system.

Let’s assume you start coding away and eventually launch the webshop. After a few weeks, the product owner would like to know how many times users update their email address, on average.

In this traditional database design, when a user updates their email address, a query looking something like this is executed:

UPDATE users SET email='newemail@mail.com' WHERE id=1

The problem is that there is no event log storing this change in a traditional sequel database.

You could build an extra column `event_log` and add a “user changed email” every time a user updates their email address. However, there are a few issues with that:

-   It requires extra work to build the feature.
-   It makes the database design more complex.
-   You will only generate these events from the moment you implement this feature, there is no way to generate these events retroactively.

This is a perfect example of where event sourcing is awesome!

With an event sourcing design, you don’t store the _state_ of the system. Instead, you store the _events_.

For example, when a user signs up, a `UserCreated` event is stored. Then, when a user updates their email address, a `UserChangedEmail` event is stored.

![](https://miro.medium.com/v2/resize:fit:875/1*viG1yP8F41QjrM8V2qPvMg.png)
Example events in an Event Sourcing system

### Why Use Event Sourcing

### Represents how we think

In the real world, people think in events. When somebody asks you how your day was, you will most likely tell them the interesting events that occurred. And you probably won’t describe the exact state of the world at time X.

Similarly, a domain expert will probably talk about a series of events when describing a process. When you use event sourcing, it becomes easier to model this in your system.

### Generating reports becomes easy

Want to know how many times a user changed their email address? With event sourcing, you already store all this data.

Want to know how many times an item is removed from a user's cart? Simply count the `EventRemovedFromCart` events.

With event sourcing, you have way more insights into your data, and you can generate reports retroactively.

### You have a reliable audit log

You can generate an audit log that shows exactly how a system got into a state.

Think of your bank account, for example. Event sourcing generates a log of transaction events that makes it crystal clear why I’m broke at the end of every month.

### Why Not Use Event Sourcing

Sounds great, but what’s the catch?

My personal experience with event sourcing is that it adds extra complexity to your system. More complexity means that it is harder to introduce new developers, takes longer to add new features, and is harder to maintain.

If you’re building a relatively small-scale system that does not need a secure audit log, implementing this is probably more hassle than it’s worth.

If you want to learn more about event sourcing, I recommend [this presentation](https://www.youtube.com/watch?v=JHGkaShoyNs) by Greg Young.

# Choosing a CQRS Architecture That Works for You

![](https://miro.medium.com/v2/resize:fit:875/1*EdmSB_QfUPbpqXkQ2oBGuw.png)
Image by author

Command Query Responsibility Segregation (CQRS) is a vast ocean of deep topics within The World of Software Architecture. It is often stigmatised with huge complexity, and many engineers are reluctant to dip their toes in the water.

Some great articles talk through complex, eventually consistent, distributed CQRS system architectures that can handle massive scale. If you are just getting started with CQRS, then this can be a little daunting. In reality, there are also much simpler options that work well for most problems.

### Command Query Responsibility Segregation (CQRS)

CQRS splits data access into Commands and Queries.

-   Commands: Write data – Create/Update/Delete
-   Queries: Read data

![](https://miro.medium.com/v2/resize:fit:875/1*jOxWK74xpu5v9DqG9TG3AQ.png)
CQRS Components

Each Command and Query class has a corresponding `Handler` class. Generally, Commands and Queries are dispatched to their `Handler` using a synchronous in-process Mediator. Sometimes asynchronous methods, such as a Message Bus, are used for handling Commands when there are high-scale requirements.

Splitting Write and Read operations means we can optimise each side independently. This might mean different Write and Read models. It might even mean completely different databases. That choice depends on the non-functional requirements of your app.

Let’s talk through some of the options and when they can be used.

### Single Read/Write Model, Single Database

This is the simplest flavour of CQRS, where our Commands and Queries use the same Model/Entity classes. For most small-to-medium-sized apps, this is generally fine!

![](https://miro.medium.com/v2/resize:fit:875/1*bWNMBj6xI22edP0aC3sNoA.png)
Single Read/Write Model, Single Database

-   Consistency: Strong
-   Complexity: Low
-   Performance/Scalability: Low

This is a great option if you are new to using CQRS; it still provides one of the biggest benefits that CQRS brings: clean code and separation of concerns. Splitting our code into granular Commands/Queries/Handlers ensures that the Single Responsibility Principle (SRP) is adhered to, which makes our solutions flexible for change and easy to test.

### Different Read/Write Models, Single Database

Using different Read and Write Models allows us to optimise each side slightly differently, generally for performance. Our options on either side are fairly limited since we use the same database for Commands and Queries.

![](https://miro.medium.com/v2/resize:fit:875/1*RpJkc8psrgEakZu1ufyTyQ.png)
Different Read/Write Models, Single Database

-   Consistency: Strong
-   Complexity: Low/Medium
-   Performance/Scalability: Medium

We have a few options on each side now. We could use a heavier ORM for writing data and something lightweight for querying data. Here, we use different classes to represent our Write/Read sides, and we could even use completely different database tables or views if we like.

Generally, something more involved, like Domain-Driven Design, would be used on the Write side, and much simpler DTOs with no business logic would be used on the Read side. The Read models should be optimised for faster serialization and querying, so there should be little or no mapping being performed.

Since we still use a single database, we can commit Write and Read model changes in a single atomic transaction to ensure consistency. This style still keeps things simple but lets us optimise our Queries slightly better.

### Different Read/Write Databases

This is where things get really interesting, and a lot more complicated! This setup is also what people generally think of when they talk about CQRS.

Using different databases for Read and Write means we can use a Polyglot Architecture, where we pick a database that perfectly fits the problem on each side. The choice of databases will completely depend on your team and app requirements.

You might want to use something simple and cheap like S3 Buckets for the Write side and something with better query support on the Read side, such as Elastic Search. A relational SQL database may fit better on one side and a NoSQL database on the other. Depending on data access patterns, we can also scale each side completely independently.

![](https://miro.medium.com/v2/resize:fit:875/1*cJ_-yFBtZwic6DuiGIlvZA.png)
Different Read/Write Databases

-   Consistency: Eventual Consistency
-   Complexity: High
-   Performance/Scalability: High

Whilst this may seem like The Holy Grail of Architectures, the price we pay is huge complexity and weak consistency. Since different databases are being used, we cannot commit changes to our Write and Read models in a single atomic transaction. Generally, changes to the Write models are propagated to the Read Models using asynchronous messaging/events, providing Eventual Consistency.

We must contend with problems like: What happens if events propagate out of order? What if we lose events? What if our Read Models become out of sync? What if saving the Read Model fails? How does the UI know when Read Models have been updated after a write so they can be queried?

This style of CQRS is compelling but extremely complex to build and manage. Battling with the CAP Theorem and managing distributed transactions is one of the hardest problems in software engineering! This option should only be chosen if the non-functional requirements of your app require it.

### Event Sourcing — Different Read/Write Databases

It can be challenging to keep everything in sync when using separate Read/Write databases and Eventual Consistency. The order of events published from the Write to the Read side becomes really important.

_Imagine that the same Write Model instance is updated twice in close succession. If the first update event is delivered after the second event, our Read model may be updated with stale data._

Unfortunately, most asynchronous Message Buses are built to be highly available and performant — this means they do not guarantee that messages will be delivered in the same order they are published. Event Sourcing can help us with this problem by taking a completely different approach to storing our Write Models.

![](https://miro.medium.com/v2/resize:fit:875/1*1WtK4G_fEh6n73v9Tb1CvQ.png)
Event Sourcing — Different Read/Write Databases

-   Consistency: Eventual Consistency
-   Complexity: High
-   Performance/Scalability: High

Instead of storing the current state of a model, append-only event stores are used to record the full series of actions taken on a model. When a new Command occurs, the current state of the Model/Entity is ‘rehydrated’ by replaying all of the events that have ever happened for that instance.

Each model instance on the Write side is stored as its own independent ‘Event Stream.’ The stream of events can be replayed at any time to materialise different views of the data. If the Read side gets out of sync, we can query all of the events from the Write side and rebuild our models.

As well as helping manage the consistency problem, Event Sourcing also provides some other benefits. We don’t need to implement complex audit processes anymore since our Event Streams already contain everything that has ever happened to each Model/Entity instance. If we decide that additional Read Models are needed in the future, we can replay the events to generate them.

Event Sourcing provides a really powerful and flexible way to model your data, but it is, again, even more complex to take on. If you have never used CQRS, Event Sourcing, or distributed architectures, then starting here is very ambitious.

### Event Sourcing — Single Database

If you want to leverage the benefits of CQRS and Event Sourcing but don’t have huge scale requirements, then this can be a great place to start! Using the same database to store your Event Streams and materialised Read Models means we can eliminate all our consistency woes by committing both in a single transaction.

![](https://miro.medium.com/v2/resize:fit:875/1*tmaB1RaBAZ7hRa43s-BbBw.png)
Event Sourcing — Single Database

-   Consistency: Strong
-   Complexity: Medium
-   Performance/Scalability: Medium

If you are using a schemaless NoSQL database, then storing the Event Streams and Read Models is easy. If you are using a relational database, you can store your Event Streams as text in a JSON format.

No matter what type of problem you are solving, there is a flavour of CQRS that can work well for you. The non-functional requirements of your system should drive the decision on which to use. Start simple and change if your scale requires it. As with most software problems, it is best not to optimise too early.

---
# 4 Kubernetes Deployment Strategies

Let’s cover some important topics before diving into the deployment strategies.

**ReplicaSet**

A _ReplicaSet_ is a Kubernetes API resource that controls multiple, identical instances of a Pod running the application, so-called replicas. It has the capability of scaling the number of replicas up or down on demand. Moreover, it knows how to roll out a new version of the application across all replicas.

**Deployment**

A _Deployment_ abstracts the functionality of ReplicaSet and manages it internally. In practice, this means you do not have to create, modify, or delete ReplicaSet objects yourself. The Deployment keeps a history of application versions and can roll back to an older version to counteract a blocking or potentially costly production issue. Furthermore, it offers the capability of scaling the number of replicas.

![](https://miro.medium.com/v2/resize:fit:875/0*tWq_A6BSoMOfoI5J.png)

The Deployment passes this information to the ReplicaSet, which uses it to manage the replicas. The mapping between the Deployment and the replicas it controls happens through label selection. For label selection to work properly, the assignment of **spec.selector.matchLabels** and **spec.template.metadata** needs to match.

![](https://miro.medium.com/v2/resize:fit:875/1*BPvYWVU8PzR9zqLk_zPkpQ.png)
Deployment label selection

### Deployment Strategies

A deployment is the process of making a software change available to end users or programs. You need to consider two aspects: the procedure of how to deploy a change and the routing of network traffic to the application. Select an appropriate deployment strategy based on use case, application type, and trade-offs.

**Rolling Deployment Strategy**

The Deployment primitive employs rolling deployment as the default deployment strategy, also referred to as ramped deployment. It’s called “ramped” because the Deployment gradually transitions replicas from the old version to a new version in batches. The Deployment automatically creates a new ReplicaSet for the desired change after the user updates the Pod template.

![](https://miro.medium.com/v2/resize:fit:875/1*Ycsm7whOc2IbFTpl0diccw.png)

In this scenario, the user initiated an update of the application version from 1.0.0 to 2.0.0. As a result, the Deployment creates a new ReplicaSet and starts up Pods running the new application version while at the same time scaling down the old version. The Service routes network traffic to either the old or new version of the application. It’s recommended to define a readiness probe for the Pod template to ensure that a replica is ready to handle incoming requests.

The rolling deployment is a fitting deployment strategy for rolling out a new application version with zero downtime. It’s important to mention that this deployment strategy comes with a potential risk. Old and new versions of the application run in parallel. Breaking changes introduced with the new version can lead to unexpected and hard-to-debug errors for consumers if they haven’t adapted their client software to the latest changes. It’s a good idea to roll out a new application version in a backward-compatible fashion.

**Fixed Deployment Strategy**

The fixed deployment strategy will terminate replicas with the old application version at once before creating another ReplicaSet that controls replicas running the new application version.

![](https://miro.medium.com/v2/resize:fit:875/1*rraLM6sa2nm_zdWdEmsV_A.png)

All replicas of the old ReplicaSet are shut down simultaneously. Then, the replicas controlled by the new ReplicaSet are started. During this process, the Service may not be able to reach any of the replicas, which can lead to unnecessary downtime for consumers.

Assigning a readiness probe to containers defined by the Pod template isn’t strictly necessary because all replicas with the old application version will be shut down at once. Nevertheless, it still makes sense to verify that the application is up and running by defining a readiness probe before incoming traffic can reach the container.

The fixed deployment strategy is suitable for situations where application downtime is acceptable. For production environments, this deployment strategy may work if you announce an outage time window to customers.

**Blue-Green Deployment Strategy**

The blue-green deployment strategy figuratively uses blue as a representation of the old application version and green as a representation of the new application version. Both application versions will be operated at the same time with an equal number of replicas.

Kubernetes routes traffic to the blue deployment, while the development or test team rolls out and tests the green deployment. Traffic is switched over to the green deployment as soon as it is considered production-ready. At that point, the team managing the application can decommission the blue deployment.

![](https://miro.medium.com/v2/resize:fit:875/1*NLmshwoHbKY9ytegaIBLaA.png)

Blue-green deployment is not a built-in strategy you can configure within the Deployment resource. You will have to create a Deployment object for both application versions. The Service routes traffic to replicas managed by either the blue or the green Deployment.

The blue-green deployment strategy is suitable for deployment scenarios where complex upgrades need to be performed without downtime to consumers. This situation may arise if a rollout requires a data migration or if multiple, dependent software components need to be changed at once. Should a rollback to the old application version be required, a simple change of the label selection in the Service will do.

On the downside, it’s worth mentioning that you will need more hardware resources than for other deployment strategies. If you need five replicas to run the old application version, then you will need the same amount of resources for the new application version, assuming the resource requirements won’t differ.

**Canary Deployment Strategy**

The canary deployment strategy is similar to the blue-green deployment; however, you’d make the new application version available to only a subset of consumers. With this approach, you can implement A/B testing of new features or if you need to gather metrics about consumer behavior. Based on the defined set of success criteria, traffic to the new application version can be increased gradually. The goal is to shut down the old application version completely.

![](https://miro.medium.com/v2/resize:fit:875/1*TD1hlaGjyKAEyGI1hKmffQ.png)

In a Kubernetes cluster, you represent each application version with the help of a Deployment object. You want to roll out the new application version with fewer replicas than the current application version by assigning a smaller value to the attribute **spec.replicas.**

Organizations typically use the canary deployment strategy to roll out experimental features or changes with potential impact on system performance. You can evaluate your success criteria while making the new feature available to only a subset of consumers. Implementing a canary deployment usually requires fewer hardware resources than the blue-green deployment as the number of replicas with the new application version is much lower



