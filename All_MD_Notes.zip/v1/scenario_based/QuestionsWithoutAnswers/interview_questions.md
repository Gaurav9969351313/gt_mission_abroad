# Frontend Interview Experience in Flipkart (UI 2) 
## Round 1: Machine Coding (Vanilla JS — Live Coding)

This round was conducted on a live video call with around 30 candidates. All the candidates were given the same problem statement to build a eCommerce platform within 2 hours. Requirement consisted of making Category and Products List, Cards, Render Tabs, multiple wish list along with proper CSS.

## Round 2 : Machine Coding Review + Technical Concepts

This round started with code review of the complete code in previous round. I was asked to explain each line of code and there were a lot of questions about how I approached a certain part of the code. Talked about Functional and Class Based approach. Discussed Performance Optimisations based on structure, logic and DOM manipulations. Asked to create a function for debounce. Discussed Pagination and Infinite Scrolling as well as Virtualisation. Also discussed on CSR vs SSR, React vs Next and in depth discussion on React Hooks, Diffing Algorithms working.

## Round 3 : UI Technical Concepts

1.  An API is given which is unstable which either resolves 10ms or 1sec. Need to create a Circuit Breaker which will wait for 300ms and if API is resolved within the timeframe we return the data otherwise we throw an error or retry.
2.  Polyfill for Reduce Method.
3.  Discussion on CSRF Token and other Security Vulnerabilities
4.  Discussion on Cookies and Auth Tokens
5.  Garbage Collection and Weak Map in JavaScript.
6.  Hoisting & Closures in depth discussion.
7.  Discussion on Performance -> Web Vitals, RequestIdleCallback, Prefetch, Preconnect, Preload, Tree Shaking, Dynamic Chunking, Breaking Long Tasks.

## Round 4 : Data Structures and Algorithms

Question 1 : Merge Intervals Variation  
Question 2 : Character Array Compression (aabb -> a2b2)

## Round 5 : Hiring Manager Round

This was a deep introspection round focusing on soft skills, leadership, product thinking, and long-term vision.

1.  UI Library -> Why I built it, use cases, where I hosted it, public vs private npm packages, handle secrets / credentials in public packages.
2.  Design a reusable and scalable input field.
3.  Metrics to track for a good UI Library.
4.  How will you create a Login System -> Complete Journey from Product Requirement to Production. How will the discussion begin, how will architecture be decided, how will I handle changes, make sure its scalable. How will API's flow across the system.
5.  Server-side event storm handling: Short Polling, WebSockets, Throttling
6.  Web Vitals Discussion -> CLS, LCP, INP, TBT
7.  How will you handle Error Logging, what metrics to look for.
8.  Personal goals: Why Flipkart, my 5-year plan, and daily agile routines, 2 things you like/dislike about current organisation.

## Round 6 : Debugging and Problem Solving in React

Was given a component fetching a list from an API with bugs. Had to identify and resolve those bugs. Then on the fly requirements were given and I was also expected to move forward with requirements in a Product Sense.

1.  Added Pagination and made it scalable for filtering and sorting.
2.  Implemented Virtualisation
3.  Added Debounce
4.  Added useMemo and useCallbacks
5.  Added Abort Controllers
6.  Added Filtering and reduced re-renders
7.  Discussed on Infinite Scrolling and Virtualisation
8.  Added Timeouts and Intervals with Pause and Resume functionality for API, also added debounce on API.
9.  How does the Web Works from DNS hit to Rendering. This was expected to be an extremely in depth discussion.
10.  How Diffing Algorithm internally works.
11.  Async | Defer and how different script types affect script load order.
12.  Multiple scripts with different timings and async defer flags were given. I was expected to tell the order of execution of those scripts.

**_Verdict: Selected_**

## Final Thoughts

The process was extremely rigorous, challenging, and rewarding. Flipkart's interview journey truly tests every facet of Frontend Engineering — from deep JavaScript fundamentals and web security to authentication flows, real-world feature building, and thinking about architecture in a reusable, scalable way. It's not just about writing code — it's about building for scale, performance, and great user experience.
