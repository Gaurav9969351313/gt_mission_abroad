# 31 Microservices Interview Questions For SDE II |

1.  Monolith Architecture
2.  Microservice Architecture
3.  Event Driven Architecture
4.  Client Server Architecture
5.  Service Oriented Architecture

Out of these above mentioned architectures in interviews most commonly asked architecture is **Microservices Architecture.** Because now most of the companies like **Netflix**, **Uber**, **Amazon** they all are following this architecture. Microservices is kind of a **Distributed System**.

If you are looking for a senior role then it is must to have understanding of Microservices and different concepts around that.

In this post I am sharing most commonly asked Microservices interview questions which I have faced while cleared the interview rounds of PayTm, PineLabs, HaloDoc , InfoEdge, Cisco.

1.  What is Microservice Architecture and why it is used?
2.  Difference between Microservice vs Monolith Architecture? Advantages and disadvantages of both?
3.  In which scenario we should use Microservice or monolith architecture?
4.  What is loose coupling?
5.  Difference between Microservice vs Service Oriented Architecture?
6.  What is workFlow orchestration?
7.  Basic understanding of Docker and K8s.
8.  Distributed Systems Design Patterns?
9.  What is 12- Factor Approach for Microservices?
10.  Difference between different Databases like mongo vs cassandra, mysql vs cassandra?
11.  What is CAP Theorem?
12.  Study about Microservices Best Practicses.
13.  How load Balancers and Servers works and How they handle concurrent requests?
14.  What is Idempotency problem?
15.  What is eventual Consistency?
16.  What is Distributed transaction?
17.  What is 2Phase and 3 phase Commit?
18.  How Saga is better than 2 PC Commit?
19.  What is Service registry and service discovery?
20.  How to scale Application? What is scale Cube?
21.  What is API gateway? what are benefits of api gateway?
22.  Difference between http vs gRPC?
23.  How to make synchronous vs asynchronous calls? Difference between them?
24.  What is Circuit Breaker pattern?
25.  What is Distributed Tracing?
26.  What is availability , performance and reliability?
27.  What is Service Mesh?
28.  What is Proxy Pattern?
29.  What is Chaos Testing?
30.  Understand about messaging and caching, how we can use them in microservices?
31.  Understand about different libraries like Eureka server, Hystrix, Ribbon, Feign, RestTemplate, Spring Cloud.
