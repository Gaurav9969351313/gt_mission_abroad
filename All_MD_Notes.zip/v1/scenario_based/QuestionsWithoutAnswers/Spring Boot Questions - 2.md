# Building a Microservice with Spring Boot and REST API 

# 🎯 Problem Statement:

Design a scalable and maintainable **Product Catalog Service** as part of a modular e-commerce platform. The service must expose REST APIs to manage products (CRUD) and be deployable independently.

# Architectural Principles

PrincipleJustification**Domain-Driven Design**Product Catalog is a core domain; encapsulate its logic and data.**Loose Coupling**Each microservice operates independently to minimize blast radius.**Single Responsibility**This service should do one thing well: manage product data.**Statelessness**REST APIs and Spring Boot services are naturally stateless — good for scaling.

# 🧱 HLD Components Breakdown

## System Context:

-   **Clients**: Web frontend, Mobile apps, Internal tools.
-   **API Gateway**: Routes requests to services (e.g., Zuul or Spring Cloud Gateway).
-   **Product Catalog Service**: Exposes REST APIs, stores product data, validates inputs.
-   **Database**: PostgreSQL (normalized schema for transactional consistency).
-   **Discovery Service**: Eureka for dynamic service registration.
-   **Monitoring Stack**: Prometheus, Grafana, ELK for logs and metrics.

## Microservice Architecture Diagram (Textual)

           +-------------------+  
           |     API Gateway   |  
           +--------+----------+  
                      |  
            -----------------------  
            |         |           |  
  +----------------+  |     +------------------+  
 | Product Service| <--->   | Inventory Service |  
  +----------------+  |     +------------------+  
                      |  
             +-------------------+  
             | Product DB (Postgres) |  
             +-------------------+

# LOW-LEVEL DESIGN (LLD): API, ENTITY, AND BEHAVIORAL DESIGN

# Real-World Use Case: E-commerce Product Catalog

The Product Catalog Service forms the backbone of a typical e-commerce system:

-   Used by **shoppers** to browse product details.
-   Consumed by **inventory, recommendation, and pricing services**.
-   Edited by **merchant dashboards** for listing updates.

## Typical workflows include:

-   Batch product creation during vendor onboarding.
-   Real-time price updates during promotions.
-   Metadata updates for SEO or categorization.

# 1. Entity Modeling
```java
Product {  
  UUID id;  
  String name;  
  String description;  
  BigDecimal price;  
  List<String> tags;  
  LocalDateTime createdAt;  
}
```
-   Use `UUID` for globally unique identification across distributed systems.
-   Timestamps (`createdAt`, `updatedAt`) must be **audited and stored in UTC**.
-   Use **JPA/Hibernate annotations** for ORM mapping in Spring Boot.

# 2. 🌐 API Design: REST Endpoint Blueprint

EndpointMethodDescription`/api/productsGET`List all products`/api/products/{id}GET`Get product by ID`/api/productsPOST`Create new product`/api/products/{id}PUT`Update product`/api/products/{id}DELETE`Delete product

## Request Design — POST Product
```json
{  
  "name": "Sony WH-1000XM5",  
  "description": "Noise-canceling headphones",  
  "price": 349.99,  
  "tags": ["audio", "headphones", "sony"]  
}
```
## Response Design — POST Product
```json
{  
  "id": "b71e9c90-4c9e-4bd4-ae0d-b1f70a528192",  
  "createdAt": "2025-05-04T18:21:00Z"  
}
```
# 3. Idempotency Handling

-   **POST** requests should use an **Idempotency-Key** header to prevent duplicate creations in case of retries.
-   Maintain an **idempotency token store** (e.g., Redis or DB table) to track processed requests.
-   For **PUT/DELETE**, idempotency is natural if request is re-applied with same payload.

## Example Header:
```shell
Idempotency-Key: 9f80e2a1-b9dc-4661-94b0-c1f849d4c5a0
```
If the same key is reused, the service returns the original response.

# 4. Security Considerations

-   Implement **JWT-based stateless authentication**.
-   Restrict `POST`, `PUT`, `DELETE` to authenticated users with `ADMIN` role.
-   Apply **rate limiting** at the API Gateway (e.g., 50 requests per minute).

# 5. Validation & Error Handling (LLD Best Practices)

**Field Validation with Annotations:**

-   `@NotNull`, `@Size(min=1)`, `@DecimalMin("0.01")`

**Standardized Error Schema:**
```json
{  
  "timestamp": "2025-05-04T18:30:10Z",  
  "status": 400,  
  "error": "Bad Request",  
  "message": "Price must be greater than 0",  
  "path": "/api/products"  
}
```
Use `@ControllerAdvice` + `@ExceptionHandler` in Spring Boot for consistent error responses.

# 6. Testing Strategy (LLD)

LayerToolingUnit TestsJUnit 5, MockitoIntegrationSpring Boot Test + TestcontainersContract TestingSpring Cloud ContractAPI SimulationWireMock/Postman Collections

# ↺ CI/CD, Observability & Integration Stack (Tooling Layer)

# DevOps Pipeline (CI/CD)

PhaseToolBuildMaven / GradleCIGitHub Actions / JenkinsDockerizeDockerfile, JibDeployHelm on KubernetesConfig MgmtSpring Cloud Config / Vault

# Monitoring & Observability

-   **Spring Boot Actuator**: Exposes `/actuator/health`, `/metrics`, `/env`.
-   **Prometheus + Grafana**: Monitor CPU, memory, custom business KPIs.
-   **ELK Stack**: Centralized logging for debugging distributed flows.

# ↺ Inter-Service Communication Options

Use CaseProtocol / ToolREST API (sync)Spring REST ControllersAsync events (inventory sync)Apache Kafka or RabbitMQService DiscoveryNetflix EurekaLoad Balancing & RoutingSpring Cloud Gateway

# 🚫 Anti-Patterns to Avoid

Anti-PatternWhy It’s a ProblemFat controllersLogic should live in service classes, not REST layer.Tight coupling to frontendDon’t hardcode view-specific logic in the API.Skipping monitoring”Works on my machine” doesn’t scale.Ignoring versioningBreaks clients when schema changes

# Think Like a Systems Designer

By combining the rigor of **HLD (modular architecture, interfaces, scaling patterns)** and **LLD (request structure, annotations, validation, tooling)**, we create a production-ready microservice that’s robust, testable, and scalable.

-   Spring Boot accelerates delivery with out-of-the-box REST, JPA, and configuration support.
-   REST APIs require more than endpoints — they demand thoughtful **contracts**, **resilience**, and **integration discipline**.
-   A successful microservice is not just “working code” — it’s **observable, secure, versioned, and governed** by strong boundaries.

# 🔷 System Design & HLD Questions

1.  **Explain the microservices architecture pattern. Why is it preferred over monolithic architecture in modern applications?**
2.  **How would you design an e-commerce system using microservices? List possible services and their responsibilities.**
3.  **What is service discovery? How does Spring Cloud Eureka help in dynamic routing?**
4.  **Explain the role of API Gateway. How does it help in microservice-based applications?**
5.  **How do you ensure fault tolerance and resilience between microservices?**
6.  **What are the challenges of database design in microservices? How would you handle data consistency across services?**
7.  **What is eventual consistency? Give a real-world example of where it applies in microservices.**
8.  **How would you handle scaling a product catalog microservice independently of other services?**
9.  **How do you implement observability in microservices architecture? Which tools would you recommend?**
10.  **What are circuit breakers, and how do you implement them in Spring Boot?**

# 🔶 Implementation & LLD Questions

1.  **What annotations are used in Spring Boot to expose REST APIs?**
2.  **Explain the use of** `**@RestController**` **vs** `**@Controller**`**.**
3.  **How do you handle request validation in Spring Boot REST APIs?**
4.  **What is the use of** `**@RequestMapping**`**, and how does it differ from** `**@GetMapping**` **or** `**@PostMapping**`**?**
5.  **How would you design an idempotent POST API in a product catalog?**
6.  **How do you prevent duplicate product creation if a request is retried by the client?**
7.  **Explain how** `**@ControllerAdvice**` **and** `**@ExceptionHandler**` **are used for global error handling.**
8.  **What are some common error response standards you follow? Why is that important in API design?**
9.  **What is the role of DTOs (Data Transfer Objects) in Spring Boot microservices?**
10.  **How do you secure REST APIs using JWT in Spring Boot? What filters or configurations are needed?**

# ⚙️ Tooling, DevOps, and Integration

1.  **How do you build and package a Spring Boot microservice using Maven or Gradle?**
2.  **What is Spring Boot Actuator? How do you use it to expose operational metrics?**
3.  **How would you containerize a Spring Boot application?**
4.  **What is the role of Spring Cloud Config in externalizing configuration?**
5.  **How do you test your REST APIs at different layers (unit, integration, contract)?**
6.  **What are Testcontainers and how do they help in integration testing with real databases like PostgreSQL?**
7.  **Have you used Kafka or RabbitMQ for asynchronous communication? What’s the use case?**
8.  **How would you design a retry mechanism with backoff strategy in Spring Boot?**
