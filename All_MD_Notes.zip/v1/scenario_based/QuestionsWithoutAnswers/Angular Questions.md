# Top 100 Questions You Must Prepare For To Ace Your Next Angular Interview (10–20)

# 11. Why we use pipe operators in RXJS. What is the use of it?

pipe method help to combine multiple operators together and transform them into a single item.

Example:
```javascript
of(17,27,32).pipe(  
 map(x => x + 1),  
 filter(x => x > 18)  
);
```
**_Let's check out practical code to understand this concept better._**

[https://stackblitz.com/edit/rxjs-pipe](https://stackblitz.com/edit/rxjs-pipe)

# 12. What is the difference between using the Async pipe vs the subscribe function in the Angular application?

If you are using modern techniques, you mostly deal with Async pipe which does have certain benefits such as unsubscribe by itself or OnPush support.

**Let's check the difference between Async and Subscribe operator.**

![](https://miro.medium.com/v2/resize:fit:810/1*Gpuy3HhvmHtdQWMxzIw9VQ.png)

**_Let's check out practical code to understand this concept better._**

[https://stackblitz.com/edit/component-vs-async-pipe-subscriptions-angular](https://stackblitz.com/edit/component-vs-async-pipe-subscriptions-angular)

# 13. What is the difference between promise and observable?

It looks the same right because if you come JavaScript background you mostly use promises. Which one is best from the promise and observable?

**Let's check out the difference between promise and observable.**

![](https://miro.medium.com/v2/resize:fit:788/1*V61reuRUWe4B6WGt6TlM_A.png)

**_Let's check out practical code to understand this concept better._**

[https://stackblitz.com/edit/observable-vs-promises](https://stackblitz.com/edit/observable-vs-promises)

# 14. What is the difference between Event Emitter and Subjects?

If I get this question I mostly go with event emitter is used while communicating child to parent component but why it is preferred over the subject?

**Let's check out the difference between them.**

![](https://miro.medium.com/v2/resize:fit:785/1*vuS8lDyY5FFfDLCasz5YlQ.png)

**_Let's check out practical code to understand this concept better._**

[https://stackblitz.com/edit/angular-subject-vs-event-emitter](https://stackblitz.com/edit/angular-subject-vs-event-emitter)

# 15. What is the difference between Observable and Subject?

**Alert! Hot favorite question from the interviewer to check out your knowledge about the observables.**

**_Let's understand the difference between Observable and Subject._**

![](https://miro.medium.com/v2/resize:fit:784/1*Jbq_DDPeago5UQSW3_z4fQ.png)

**_Let's check out practical code to understand this concept better._**

[https://stackblitz.com/edit/observables-and-subjects](https://stackblitz.com/edit/observables-and-subjects)

# 16. What is the difference between Activated Route vs Activated route Snapshot?

The major difference between Activated Route vs Activated Route Snapshot is with Activated Route we can subscribe to Observable while Activated Route Snapshot only emits one value.

**_Let's check out practical code to understand this concept better._**

[https://stackblitz.com/edit/angular-router-snapshot-and-params-yakov](https://stackblitz.com/edit/angular-router-snapshot-and-params-yakov)

# 17. Discuss a different kind of loading strategies used in your Angular application

This kind of question asked to check how deep you have used angular. Most of the times we answer lazy loading and eager loading but there is one more in the list which we should consider….

## Eager Loading

The components under eager loading get loaded before the application starts.

[https://stackblitz.com/edit/ang-eager-loading-example](https://stackblitz.com/edit/ang-eager-loading-example)

## Lazy Loading

The components under lazy loading will be loaded only when needed. It helps to improve the performance and helps to start the application faster.

[https://stackblitz.com/edit/angular6-lazy-loading](https://stackblitz.com/edit/angular6-lazy-loading)

## Pre-Loading

The components get loaded after the application starts.

[https://stackblitz.com/edit/angular-custom-preloading-strategy](https://stackblitz.com/edit/angular-custom-preloading-strategy)

To know about how to use please follow the below link

[

## Eager Loading, Lazy Loading, and Pre-Loading in Angular 2+: What, When, and How?

### Angular 2+ has been a very popular front-end platform for modern web applications since 2016. It introduced a…

medium.com



](https://medium.com/@lifei.8886196/eager-loading-lazy-loading-and-pre-loading-in-angular-2-what-when-and-how-798bd107090c?source=post_page-----c3f5ab854be---------------------------------------)

# 18. What is Metadata?

Seems new word for me in Angular. No, you use it daily but never know the exact name. Let's check this out…

> _“It is used to decorate the class to get the different behaviour from the class._

Below are the examples of metadata used in Angular.

1.  **_Class Decorator_** — @component
2.  **_Property Decorator_** — @Input
3.  **_Method Decorator_** — @HostListner
4.  **_Parameter Decorator_** — @Inject

# 19. What is routerlinkActive use for?

Are you using navbar in your angular application? If so this one is one of the common directives to show the activated item.

It checks to activate Router Link based on the current RouterState.

**_Let's check out practical code to understand this concept better._**

[https://stackblitz.com/edit/angular-routerlinkactive](https://stackblitz.com/edit/angular-routerlinkactive)

# 20. Where we use generics in Angular?

This is one of the latest interview questions in Angular. Interviewers want to check how well you are writing clean by typecasting objects or specific Observable or Events.

There are different places where we commonly use generics.

1.  **_While defining emitters_**

Output() click : EventEmitter<string> = new EventEmitter<string>()

2. **_While capturing the response from observable_**
```javascript
data: Observable<IResponse>
```
3. **_Defining Interfaces_**
```javascript
interface Item {  
    info:string,  
}  
Input public items: Item[]
```

# The rest of the questions are as follows, I will provide answers for them in the next articles….

1.  What is the difference between constructor and ngOnInit?
2.  What is the difference between components and directives?
3.  What is the difference between ElementRef, TemplateRef, and viewContainerRef?
4.  What is the difference between ng-content,ng-template, and ng-container?
5.  What is the difference between view-child and content-child?
6.  What is the difference between component view, host view, and embedded view?
7.  What is the difference between debounce time and throttle time?
8.  What is the difference between forEach and map?
9.  What is the difference between ng-content and ng-templateoutlet?
10.  What is the difference between forchild vs forroot?
11.  Why we use pipe operators in RXJS. What is the use of it?
12.  What is the difference between using the Async pipe vs the subscribe function in the Angular application?
13.  What is the difference between promise and observable?
14.  What is the difference between Event Emitter and Subjects?
15.  What is the difference between Observable and Subject?
16.  What is the difference between Activated Route vs Activated route Snapshot?
17.  Discuss different kinds of loading strategies used in your Angular application.
18.  What is Metadata?
19.  What is routerlinkActive use for?
20.  Where we use generics in Angular?
21.  What is the wild card route?
22.  What is the difference between ngIf and hidden?
23.  What is a router outlet?
24.  What is the Router state?
25.  What is an Active route?
26.  Explain different injections in angular.
27.  What is the best way to implement translations in angular?
28.  Explain different routing params in Angular.
29.  What is a virtual scroll in Angular?
30.  What is the difference between route param vs query param?
31.  Explain different guards supported in Angular.
32.  Which RXJS operators used for transforming or manipulating data?
33.  What is the best way to lazy load the component?
34.  What is the way we can display the app version in Angular?
35.  What are the generators in ES6?
36.  Explain the Error mechanism in your application.
37.  What is bootstrapping in angular?
38.  What are Angular elements? why we use it?
39.  What is the difference between the arrow function and regular functions?
40.  What is the difference between Functional vs Object Oriented Programming language? Which one you prefer and why?
41.  What is the difference between JavaScript and TypeScript?
42.  What do you know about Closures?
43.  What is the difference between Template Driven forms and Reactive Forms?
44.  What are different Kinds of Bindings possible in Angular?
45.  Which RXJS Operators you use mostly to handle HTTP services?
46.  What is the difference between mergemap/switchmap/concatmap and exhaustmap and where we can use them?
47.  Discuss different decorators in Angular.
48.  Explain different lifecycle methods in Angular.
49.  Explain the hierarchy of the Angular Life cycle hooks.
50.  What is renderer 2?
51.  What is the difference between renderer and ElementRef?
52.  What is Zone.js?
53.  What is Race Condition in Angular?
54.  What is a callback, Promises and Async/Await in Angular?
55.  What is Host binding and Host Listener in Angular?
56.  What is dependency injection in Angular?
57.  Explain the digest cycle/Change detection Cycle in Angular.
58.  What is the difference between markForCheck and detectchanges?
59.  What are the ways to clone the object?
60.  Explain how Angular application loads/Initialize.
61.  How to detect non-primitive type data when an [@Input](http://twitter.com/Input)() value changes in Angular?
62.  What are the different Encapsulation strategies in Angular?
63.  What is Shadow DOM in Angular?
64.  Explain different types of directives in Angular.
65.  What is the best way to unsubscribe from the observable?
66.  What is an Angular language service?
67.  Difference between Angular's canLoad and canActivate?
68.  How to check if route changes in Angular?
69.  Explain different router events in Angular.
70.  What are the manual ways to trigger change detection in Angular?
71.  Discuss different pipes in Angular.
72.  What are the best security practices you follow in Angular.
73.  What is the best way to improve angular performance.
74.  Have you handled the expression that has changed after it was checked error?
75.  What is the way to handle if one module is already loaded?
76.  Have you created a custom library in Angular?
77.  What are the ways you analyze the memory in Application?
78.  Explain different router events in Angular?
79.  What are the data types in Angular?
80.  What is the best way to optimize Async Validators?
81.  What is Enums in Angular?
82.  What is the difference between find and filter in JavaScript?
83.  Prevent Multiple Service Calls on Button Click in Angular.
84.  How to pass data between components in Angular?
85.  What is the difference between (change) vs (ngModelChange)?
86.  What is the difference between declarations, providers, and imports?
87.  How to Override CSS in Angular Component Libraries (such as Angular Material)?
88.  How to do dynamically bind string from component to HTML?
89.  How to set ngFor and ngIf on the same element?
90.  Can you give an example of built-in validators?
91.  What is an entry component?
92.  What is observable and observer in Angular?
93.  What are service workers in Angular?
94.  How to update all libraries with the latest version in Angular?
95.  What is an interceptor? How you configured your application/
96.  Explain the architecture of your Angular Application.
97.  Explain some methods you mostly use to test the Angular Components.
98.  What are the different SCSS functions you used in your application.
99.  What is the difference between OnPush and default change detection?
100.  How can you bind data to templates?
101.  What is the difference between takeWhile and takeUntil RXJS Operator?
102.  What is the difference between BehaviourSubject/Subject/ReplaySubject and Async Subject?
103.  Explain practical usage of the ng-temple,ng-content,ng-container, and ng-templateOutlet.
104.  Why we use the forchild and forroot method in route? What is its usage?
105.  How to update all angular libraries to the latest versions?
106.  What is a content projection in Angular and How it works?
107.  What is the APP_INITILIZER in Angular and What it is used for?
108.  Explain route reuse strategies in Angular Application.
109.  How does Server-Side rendering work in Angular?
110.  What are service workers in Angular? How to use them?
