# The Issue With Data In a Microservice Architecture 

# What is the issue, doctor?

To properly understand the issue, we need an example of a microservice architecture with a real-life example. At my current company, we create videos for products. So, we have a video management service and a product management service. Those two services have separate databases.

![](https://miro.medium.com/v2/resize:fit:411/1*aXy0Fw_NCVW87Dy2SfMDaQ.png)

A video is linked to a product with an N-to-1 (video to product) relationship, so we store the product ID in the video table.

![](https://miro.medium.com/v2/resize:fit:301/1*eZWeo0LynyHRHc8_nR6aKQ.png)

_I'm sorry for my database schema expert readers; I'm far from being one._

Now, let's say my lovely product team asked me to create a page for my back office where they want to see the list of videos with the video's title and product name next to each other. They also want to be able to sort videos by product name.

Since both services are separate, you can't join tables to retrieve data from videos and products in a single query. The only way to do it in the current architecture is to get all the videos first, then retrieve all the product information, and finally show the page.

A junior developer might think: I can retrieve a list of 20 videos first. Then, send the 20 product IDs in a single HTTP call to the product service to retrieve the product information, and finally, regrouping video and product information in the front end is okay. It’s only two HTTP calls, _right?_

![](https://miro.medium.com/v2/resize:fit:875/1*wQRv1eYViOGiVmmaXk0Rog.jpeg)

Yes, it's only two calls to show the data, but how would you handle sorting on the product name? You can't sort in the front end because you don't know the product name linked to the video before limiting it to the first twenty videos.

If you have thousands of videos for thousands of products, sorting on the product name can only be done at the database level, and that's what this article issue is all about. You can't sort videos on product names at the database level because it's split into multiple microservices.

This sorting issue is just one of the many issues you can face with data sharing in microservices. Fun fact: with this exact problem, my thought that microservices were perfect was broken a few years back. That's why I chose it for this article — _like, did you know Santa Claus is not real? This kind of revelation._

# What's the treatment?

There are a couple of solutions for this issue; it depends on how often your data is updated or how fresh you need it to be.

You might not want to hear it, but one of the solutions is to **duplicate the data** you need from the product service in the video database.

![](https://miro.medium.com/v2/resize:fit:353/1*T0u7ooJt6exEj_Qcd2fghw.png)

Adding the product name to the video table allows you to sort by product name without issues.

Now, the question is how you keep that data fresh. If I update the product name directly in the product service, how is that replicated in all the videos using that product?

## Is being late okay for you?

Is it okay if the data stored in the video table is inconsistent with the new data in the product table for some time? That's what we call "[Eventual consistency](https://www.scylladb.com/glossary/eventual-consistency/)". We agree that the data will be consistent at some point in a short time, just not perfectly at the exact moment.

If yes, you can use an event-driven architecture setup with a queue system, like Kafka or RabbitMQ, to communicate events between services.

![](https://miro.medium.com/v2/resize:fit:850/1*7NbpZxuTIAjUClUw9yxPTA.png)

Every time the product service receives an update, it sends a message in a queue dedicated to product updates with the new information.

Any service can subscribe to the product update queue and update its own data when a new message is received.

Alright… This is in a perfect world where the [fallacies of distributed computing](https://en.wikipedia.org/wiki/Fallacies_of_distributed_computing) are universal laws. But in the real world, it's clearly not that easy.

What happens if the update on the video service fails? Do you want to roll back the update in the product service? What if you have other services that use this data? Do you want to roll them back as well?

![](https://miro.medium.com/v2/resize:fit:875/0*4Ub5qMfVdQng_2O_)
Photo by Nik on Unsplash

There could be a failure at any moment in the system; one of the services using the product data could fail its update, and then you would be stuck with inconsistent data.

There are documented patterns you may want to follow when dealing with transaction management, like the [SAGA pattern](https://microservices.io/patterns/data/saga.html), which explains in-depth how to implement multi-service transactions.

That's where things get really complicated. The network is unreliable, so a good idea is to implement [exponential backoff retries](https://learn.microsoft.com/en-us/dotnet/architecture/microservices/implement-resilient-applications/implement-retries-exponential-backoff) if anything fails. This means that any failed attempt is repeated with more and more wait times between retries to ensure there is a real problem, not just a network or any temporary failure.

If it fails completely, you must prepare for a transaction rollback orchestration. Those rollback actions are called [Compensating transactions](https://en.wikipedia.org/wiki/Compensating_transaction).

The rollback orchestration for us means a separate queue for failed product updates. The failing service sends a message in the queue with the previous state of the product, and every service polls the message from it to roll back their data —_then you start thinking, what if this fails as well? It just never ends…_

We decided to accept that some small number of updates will fail and the "contact customer service" button will be of great use—_it should be there anyway, but please don't use this as your only solution._

As we said before, the issue with this architecture is:

-   It adds a lot of development overhead and complexity
-   Data is inconsistent, which could be an issue based on your use case.
-   On rollback, the user will think his update worked but will find the previous data without understanding why.

But there are many benefits:

-   It's highly available with low latency
-   Separation of concerns
-   Can add an infinite number of services without impacting users.

For example, product names rarely change once added to the site. And even if they do, it's perfectly okay if the value in the video list is incorrect or if the sort is not using the correct value for some time.

![](https://miro.medium.com/v2/resize:fit:875/0*u6P8fsmXflhwQ81c)
Photo by 13on on Unsplash

## Being late is just impossible.

You exit your grooming session happy with your eventual consistency solution. Still, your product team goes mad, and it's unthinkable that the wrong product name in the video list is not the correct one, even for a few seconds! Are you out of your mind? What would our clients think? — _does this look like a real scenario to you, too? Okay, maybe I'm exaggerating._

The video/product is a wrong example. A better example would be a payment system, but I'll roll with it for this article anyway.

Okay, so the data cannot be inconsistent, so every time an update happens on the product service, it has to be replicated on the video service synchronously.

You have the beginner-friendly implementation; I'll call it **One-Phase commit (1PC)**. _You'll see why later._

![](https://miro.medium.com/v2/resize:fit:875/1*21v93Tg_b_TuWxWFgBKMqg.png)

The coordinator there could be a separate service or the product service itself. For us, it's a separate service: a GraphQL gateway.

The user will not get a validation that the product update worked until all the transactions to every service using product data are successful.

This means that the more services need the product information, the longer the wait time for the user will be.

What if any error occurs while updating the data in every service?

![](https://miro.medium.com/v2/resize:fit:875/1*ZzqhzeB8OjhAOMfPWQ5INA.png)

Every product information updated before needs to be rolled back synchronously. So, each updated service needs to revert to the previous state.

A more complicated and secure pattern is [**Two-Phase Commit (2 PC)**](https://medium.com/javarevisited/distributed-transaction-management-in-microservices-part-1-bb7dc1fbee9f)**. Prepare** and **commit** phase**.** Instead of directly doing the updates like I showed you, the orchestrator will:

-   First, the coordinator asks all impacted services if running the update without updating anything is okay. That's the "prepare" phase.
-   If any service answers with an error, it aborts the update and warns the user. We, of course, implement retries before validating the failure.
-   If all the service answers are yes, it proceeds with the update. That's the commit phase.

![](https://miro.medium.com/v2/resize:fit:875/1*iCwBLhOmaUq2IoSq1EB6ug.png)

This brings another level of security before running the upgrade. It can still fail during the commit phase, and you need to prepare to roll back updated data.

There's also a [**Three-Phase commit**](https://medium.com/javarevisited/distributed-transaction-management-in-microservices-part-1-bb7dc1fbee9f) **(3PC)** if you're interested.

The main advantage of this architecture is that data is always consistent everywhere.

However, the disadvantages are that updates take much longer and services are more coupled.

This is nightmare-inducing; I'm primarily working with non-sensitive data in my day-to-day job, so while we try to have a good microservice architecture, it's not a life-or-death situation if some data are inconsistent and need human correction.

The solutions I talked about are not one-size-fits-all. As I said in the article, issues still exist that applications dealing with sensitive data can't accept as okay to fail. I haven't had the luck — _or bad luck_ — to work on one of those applications yet, so I still have much to learn.

Microservices are great for many reasons: scaling, separation of concerns, deployment speed, etc. But before creating those services, consider how your application will interact with them. If it's too late, you might want to merge services; that's a route we are considering.
