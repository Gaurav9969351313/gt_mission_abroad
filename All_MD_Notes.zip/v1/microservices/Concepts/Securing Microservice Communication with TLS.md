# HTTPS 101: Securing Microservice Communication with TLS 1.2 

# Introduction

Let’s be honest — HTTPS is one of those things most developers “use,” but few deeply understand. For many backend engineers (my past self included), it’s just something that magically “makes your API secure.”

But what really happens when your service hits an HTTPS endpoint?

What is **TLS 1.2** doing under the hood?

And how do you set it up properly in Java — without running into scary SSL errors?

In this article, we break down HTTPS and TLS 1.2 from a backend engineer’s point of view.

We’ll walk step-by-step through the TLS handshake, explain how to generate and configure certificates using OpenSSL, and implement a working mutual TLS (mTLS) setup in Java (Spring Boot) — using a real-world example.

You’ll see how an **OmniChannelClientService** (OMNI) makes a secure call to a **TransactionProcessorGatewayService** (TPGS) over HTTPS, exchanging a JSON request and response — just like real services do in production.

Here’s the setup we’ll build, step by step:

![](https://miro.medium.com/v2/resize:fit:875/1*TjipL7pVJmlXq40tEgtWHQ.jpeg)

# What Is HTTPS and TLS?

# HTTPS:

HTTPS stands for HyperText Transfer Protocol Secure.

It’s just HTTP (the protocol used by web services to send/receive data) wrapped in a layer of encryption using TLS.

The “S” in HTTPS means that everything transmitted between client and server is encrypted and authenticated — no one in the middle can snoop or tamper with it.

# TLS:

TLS (Transport Layer Security) is the protocol that does the actual encryption behind HTTPS.

When someone says “HTTPS,” what they really mean is “HTTP over TLS.”

TLS ensures:

1.  **Authentication:** Are you really talking to the server you think you are
2.  **Confidentiality:** Can anyone read your data in transit? (Answer: nope.)
3.  **Integrity:** Has the data been modified or corrupted? (Also nope.)

**NOTE:**

TLS Does **NOT** Handle **Authorization:**

TLS ensures that communication is secure and authenticated, but it doesn’t decide what you’re allowed to do once the connection is established.

That’s handled at the **application level** — typically using tokens, sessions, roles, or other access control mechanisms.

# Where SSL Comes In

You might still hear about **SSL (Secure Sockets Layer)** — that’s the **older** version of TLS.

SSL is **deprecated** and no longer secure.

Today, we use **TLS 1.2 or TLS 1.3** (depending on the system).

Despite this, people (and even error logs) often still say “SSL” when they mean “TLS.”

# How HTTPS Works (Simplified Flow with Mutual TLS)

Here’s a breakdown of what happens under the hood when the **client (OmniChannelClientService)** connects securely to the **server (TransactionProcessorGatewayService)** using HTTPS with TLS 1.2 and mutual authentication.

## Here is a simple setup: From start to secure:

![](https://miro.medium.com/v2/resize:fit:875/1*svO8fiuBYIHF-zReFbtKhw.jpeg)

## Step 1: TLS Handshake Begins: ClientHello

The handshake starts when the **client (OmniChannelClientService)** sends a **ClientHello** message to the server.

This message includes:

-   The TLS version(s) it supports (e.g., TLS 1.2, TLS 1.3)
-   A list of preferred cipher suites (encryption algorithms)
-   A random number (used later in session key generation)

This message sets the stage for negotiation — the server will choose the best mutually supported options from this list.

> **Client → Server:** “Hi, I’d like to establish a secure connection. Here’s what I support.”

## Step 2: Server Responds — ServerHello + Certificate

After receiving the ClientHello, the **server (TransactionProcessorGatewayService)** replies with a **ServerHello** message, indicating how it wants to proceed.

This response includes:

-   The TLS version it has selected (e.g., TLS 1.2)
-   The chosen cipher suite for encryption
-   Its X.509 certificate, which contains:

— The server’s public key

— The server’s identity (e.g., CN=[transaction-gateway.com](http://transaction-gateway.com/))

— Details about the Certificate Authority (CA) that issued the certificate

This is the server’s way of saying: “I’m ready to talk securely — here’s proof of who I am.”

> **Server → Client:** “Let’s use TLS 1.2 with this cipher suite. Here’s my certificate so you can verify who I am.”

## Step 3: Client Verifies the Server’s Certificate

Once the server responds, the client (OmniChannelClientService) needs to decide whether it can trust the server’s identity.

It does this by performing several checks using its truststore:

-   **Is the certificate valid?** _Not expired, properly formatted, and within its valid date range_
-   **Is the certificate signed by a trusted Certificate Authority (CA)?** _The client uses its truststore to check if the issuing CA is trusted_
-   **Does the domain name match?** _If the client is calling_ [_https://transaction-gateway.com_](https://transaction-gateway.company.com/)_, the certificate must be issued to_ [_transaction-gateway.com_](http://transaction-gateway.com/) _domain (via the Common Name (CN) or Subject Alternative Name (SAN) fields)_

This domain check helps **protect** against **man-in-the-middle attack**s by ensuring the client is talking to the intended server.

If any of these checks fail, the handshake is immediately aborted, and the connection is rejected.

> **Client → (internally):** “Can I trust this server? Is this really who they claim to be?”

## Step 4: Client Sends Its Own Certificate (Mutual TLS)

In a mutual TLS setup, both parties must authenticate each other — so now it’s the client’s turn to prove its identity.

The client presents its certificate, which is retrieved from its keystore, and contains:

-   The client’s identity (e.g., CN=[omnichannel-client.com](http://omnichannel-client.com/))
-   The client’s public key
-   A digital signature from a trusted Certificate Authority (CA) — this could be an internal enterprise CA or an external one.

This step only happens in mutual TLS (mTLS). In regular HTTPS, the client doesn’t send a certificate — only the server does.

> **Client → Server:** “Here’s my certificate. You can verify me now.”

## Step 5: Server Verifies Client’s Certificate

In a mutual TLS setup, the server is responsible for validating the client’s identity.

To do this, it uses its truststore to:

-   Check if the client certificate is trusted (i.e., signed by a known Certificate Authority)
-   Validate the certificate chain (ensures intermediate and root certs are in place)
-   Confirm the certificate is valid (not expired or not yet valid)

If all checks pass, the client is considered authenticated, and the handshake continues.

If any check fails, the server terminates the connection and the handshake is aborted.

> This step ensures that only authorized clients (presenting valid, trusted certificates) can establish a secure connection to the server.

## Step 6: Key Exchange and Session Key Generation

Once both parties have verified each other’s certificates, they move on to generating a shared secret that will be used to encrypt the actual data.

The client and server use asymmetric cryptography (typically ECDHE or RSA) during the handshake phase.

They negotiate a shared session key — this is the key both sides will use for encryption and decryption.

After the session key is established, the communication switches to symmetric encryption, which is much faster and efficient for transmitting data.

> **Think of it this way:** public/private key cryptography is used just to agree on a secret. The secret itself (session key) is then used to secure the conversation.

## Step 7: Secure Tunnel Established — HTTPS Communication Begins

At this point, both the client and server have:

-   Successfully verified each other’s identities
-   Agreed on a shared session key
-   Switched to symmetric encryption

Now, the TLS handshake is complete and a secure communication channel is established.

This is where the “S” in HTTPS finally kicks in — ensuring your sensitive data travels through a trusted, encrypted tunnel.

From here on:

-   JSON (am using json in this example) requests and responses are transmitted securely
-   No one can read or tamper with the data in transit (even if intercepted)
-   Session integrity and confidentiality are fully enforced by TLS

> All traffic between Client (OmniChannelClientService) and Server (TransactionProcessorGatewayService) is now encrypted.

# Understanding Keystore vs Truststore

Before diving into java implementation of HTTPS, Let us first understand what is a keystore and a truststore.

When working with HTTPS and TLS in Java, two terms keep popping up: keystore and truststore. They might sound similar (and even use the same file formats), but they play very different roles in securing communication between systems.

Let’s break it down clearly.

# Keystore – Your Identity and Private Keys

A keystore is a secure file (typically .jks or .p12) that holds your application's credentials — specifically:

-   Your private key (used to prove who you are)
-   Your public certificate (shared with others to verify your identity)
-   Optionally, the certificate chain (intermediate and root certs)

In HTTPS:

-   The server uses a keystore to present its identity to clients.
-   If you’re using mutual TLS (mTLS), the client will also have its own keystore.

> Think of the keystore as your digital passport — it proves you are who you say you are.

# Truststore – Who You Trust

A truststore is also a secure file, but it plays the opposite role of a keystore.

It contains public certificates of other systems you trust, such as:

-   Certificate Authorities (CAs)
-   External services you call
-   Client certificates (in case of mTLS)

In HTTPS:

-   The client uses a truststore to verify the server’s certificate.
-   The server (in mutual TLS) uses a truststore to verify the client’s certificate.

> Think of the truststore as your trusted contacts list — you only communicate securely with people you’ve added here.

# In the Java World

Both keystores and truststores are essential when building secure Spring Boot applications. Java expects them in standard formats like:

-   .jks – Java KeyStore (default)
-   .p12 or .pfx – PKCS#12 (modern, widely used)

These are plugged into your application via configuration to enable HTTPS, TLS, and mutual TLS connections.

# Backend Implementation Using Java (Real Use Case)

Now that we’ve walked through the TLS handshake conceptually, and learned the difference between keystore and truststore, let’s implement it in a Java Spring Boot backend setup using OpenSSL and Java-compatible formats.

We’re securing communication between two microservices:

-   OmniChannelClientService → initiates the HTTPS call
-   TransactionProcessorGatewayService → receives the call over HTTPS using TLS 1.2

We’ll use OpenSSL to generate certificates and keys in a proper, scalable way, then convert them into a .p12 keystore that Spring Boot understands (.p12 or .jks) using openssl pkcs12 and keytool.

# Setup Overview

What You Need:

-   A private key and certificate for each service
-   A keystore (containing private key + certificate) for the server (and client in mTLS)
-   A truststore (containing trusted certs/CA) for both parties

# Certificate Creation with OpenSSL (Server Side)

## Step 1: CSR Generation (with metadata)

First, generate a **private key** and **create a Certificate Signing Request** (CSR) with meaningful subject information:
```shell
openssl req -newkey rsa:2048 -nodes   
  -keyout server.key   
  -out server.csr   
  -subj "/C=KE/ST=Nairobi/L=Nairobi/O=Transaction Gateway Limited/OU=TPGS/CN=transaction-gateway.com/emailAddress=info@tpgs.com"
```
-   **server.key** → your server’s private key
-   **server.csr** → certificate request to be self-signed or sent to a CA

## Step 2: Self-sign the CSR (10-year validity)

We’ll self-sign the CSR to generate a certificate valid for 10 years, otherwise send the CSR to a valid CA for signing:
```shell
openssl x509 -req   
  -in server.csr   
  -signkey server.key   
  -out server.pem   
  -days 3650
```
-   **server.pem** → self-signed certificate containing the public key and metadata

## Step 3: Convert to a PKCS#12 Keystore (.p12)

Java doesn’t use .**pem** and **.key** files directly — it expects them in PKCS#12 format:
```shell
openssl pkcs12 -export   
  -in server.pem   
  -inkey server.key   
  -out server.p12   
  -name server   
  -password pass:changeit
```
-   **server.p12** now contains both the private key and the certificate, ready to be used as a Spring Boot keystore

## Step 4: Truststore for the Client (OmniChannelClientService)

To allow the OmniChannelClientService to trust the secure server (TransactionProcessorGatewayService), we need to import the server’s certificate into the client’s Java truststore.

The server certificate can be optained in either of below options:

## Option A: Server Shares the Certificate (Preferred)

If the server provides the **.crt** or **.pem** file (usually named something like **server.crt** or **server.pem**), you can directly import it into a truststore using keytool.

## Option B: Extract the Certificate Yourself Using OpenSSL

If the certificate isn’t shared, you can extract it from the running HTTPS server:
```shell
openssl s_client -connect transaction-gateway.com:9443 -showcerts
```
Copy the certificate content from:

-----BEGIN CERTIFICATE-----  
...  
-----END CERTIFICATE-----

Paste and save it as **server.crt** or **server.pem**

## Import the Server Certificate into a Truststore (.jks format)
```shell
keytool -importcert   
  -alias transaction-gateway-cert   
  -file server.pem   
  -keystore client-truststore.jks   
  -storepass changeit   
  -noprompt
```
> This creates a truststore file (.jks) that tells the client: “I trust any server using the certificate identified by this alias.”

## Convert the Truststore from .jks to .p12 (optional but recommended)

Many Spring Boot apps now prefer or require PKCS#12 (.p12) format instead of the legacy .jks.

Convert the .jks to .p12 using the following command:
```shell
keytool -importkeystore   
  -srckeystore client-truststore.jks   
  -destkeystore client-truststore.p12   
  -srcstoretype JKS   
  -deststoretype PKCS12   
  -srcstorepass changeit   
  -deststorepass changeit
```
> **client-truststore.p12** can now be used directly in your Spring Boot configuration.

# Certificate Creation with OpenSSL (Client Side)

If you want mutual TLS, repeat the same steps for the client:

-   Generate client.csr with metadata
-   Self sign the csr or send it to a valid CA for signing
-   Export to client-keystore.p12
-   Create server-truststore.jks
-   Convert the jks to p12 file

# Secure Communication with Mutual TLS in Java (Client → Server)

Once certificates are generated and stored in external keystores and truststores, the next step is wiring everything up in code.

In this section, we’ll configure the OmniChannelClientService to:

-   Trust the server’s certificate
-   Present its own certificate for mutual authentication
-   Make a secure HTTPS call to [https://localhost:9443/api/v1/post-request](https://localhost:9443/api/v1/post-request)

# CLIENT SIDE: OmniChannelClientService

## Step 1: application.yml
```yml
server:  
  port: 8443  
  ssl:  
    enabled: true  
    key-store: /opt/config/certs/client/client.p12  
    key-store-password: changeit  
    key-store-type: PKCS12  
    key-alias: client  
    trust-store: /opt/config/certs/client/server-truststore.p12  
    trust-store-password: changeit  
    trust-store-type: PKCS12
```
## Step 2: Configuratin class — HttpConfigs Class
```java
@Configuration  
public class HttpConfigs {  
    private static final Logger log = LoggerFactory.getLogger(HttpConfigs.class);  
    // Determines the timeout in milliseconds until a connection is established.  
    private static final int CONNECT_TIMEOUT = 15000; // 15 seconds  
    // The timeout in milliseconds for requesting a connection from the connection manager.  
    private static final int REQUEST_TIMEOUT = 15000; // 15 seconds  
    // The timeout in milliseconds for waiting for data from the server.  
    private static final int SOCKET_TIMEOUT = 30000; // 30 seconds  
    // The maximum number of total open connections managed by the connection manager.  
    private static final int MAX_TOTAL_CONNECTIONS = 200;  
    // The maximum number of concurrent connections per route (destination host).  
    private static final int DEFAULT_MAX_PER_ROUTE = 50;  
    // The default keep-alive time in milliseconds for persistent connections.  
    private static final int DEFAULT_KEEP_ALIVE_TIME_MILLIS = 30000; // 30 seconds  
     
   // Environment variables  
    private final String keystoreLocation;  
    private final String keystorePassword;  
    private final String keystoreType;  
    private final String truststoreLocation;  
    private final String truststorePassword;  
    private final String truststoreType;  
  
    // Optional flag to disable hostname verification (e.g., when using IP in UAT)  
    private final boolean skipHostnameVerification;  
    @Autowired  
    public HttpConfigs(@Value("${server.ssl.key-store}") String keystoreLocation,  
                       @Value("${server.ssl.key-store-password}") String keystorePassword,  
                       @Value("${server.ssl.key-store-type}") String keystoreType,  
                       @Value("${server.ssl.trust-store}") String truststoreLocation,  
                       @Value("${server.ssl.trust-store-password}") String truststorePassword,  
                       @Value("${server.ssl.trust-store-type}") String truststoreType,  
                       @Value("${http.ssl.skip-hostname-verification:false}") boolean skipHostnameVerification) {  
        this.keystoreLocation = keystoreLocation;  
        this.keystorePassword = keystorePassword;  
        this.keystoreType = keystoreType;  
        this.truststoreLocation = truststoreLocation;  
        this.truststorePassword = truststorePassword;  
        this.truststoreType = truststoreType;  
        this.skipHostnameVerification = skipHostnameVerification;  
    }  
    @Bean  
    public PoolingHttpClientConnectionManager poolingConnectionManager() {  
        FileInputStream truststoreFis = null;  
        FileInputStream keystoreFis = null;  
        try {  
            // 1. Load TRUSTSTORE (server side cert)  
            KeyStore trustStore = KeyStore.getInstance(truststoreType);  
            truststoreFis = new FileInputStream(truststoreLocation);  
            trustStore.load(truststoreFis, truststorePassword.toCharArray());  
              
            // 2. Load KEYSTORE (client side cert, which is stored in the keystore)  
            KeyStore keyStore = KeyStore.getInstance(keystoreType);  
            keystoreFis = new FileInputStream(keystoreLocation);  
            keyStore.load(keystoreFis, keystorePassword.toCharArray());  
              
            // 3. Configure SSLContext with BOTH keystore and truststore - Mutual-SSL  
            SSLContext sslContext = SSLContexts.custom()  
                    .loadKeyMaterial(keyStore, keystorePassword.toCharArray()) // My cert  
                    .loadTrustMaterial(trustStore, null) // server side cert  
                    .build();  
  
            // Only when truststore needed - Not Mutual-SSL  
//            SSLContext sslContext = SSLContexts.custom()  
//                    .loadTrustMaterial(trustStore, null)  
//                    .build();  
  
            // 4. Configure hostname verification policy  
            SSLConnectionSocketFactory sslConnectionFactory;  
            if (!skipHostnameVerification) {  
                // Enforce domain validation in production  
                sslConnectionFactory = new SSLConnectionSocketFactory(  
                        sslContext,  
                        new String[]{"TLSv1.2"}, // Enforce TLS version 1.2  
                        null,  
                        new DefaultHostnameVerifier()  
                );  
                log.info("Hostname verification is ENABLED (recommended for production).");  
            } else {  
                // Optional: Disable only in UAT when using IP instead of DNS  
                sslConnectionFactory = new SSLConnectionSocketFactory(  
                        sslContext, NoopHostnameVerifier.INSTANCE);  
                log.warn("Hostname verification is DISABLED (use only in UAT/IP scenarios).");  
            }  
  
            // 5. Register HTTP/HTTPS socket factories  
            Registry<ConnectionSocketFactory> registry = RegistryBuilder  
                    .<ConnectionSocketFactory>create()  
                    .register("https", sslConnectionFactory)  
                    .register("http", PlainConnectionSocketFactory.INSTANCE)  
                    .build();  
  
            // 6. Configure connection pooling  
            PoolingHttpClientConnectionManager poolingConnectionManager =  
                    new PoolingHttpClientConnectionManager(registry);  
            poolingConnectionManager.setMaxTotal(MAX_TOTAL_CONNECTIONS);  
            poolingConnectionManager.setDefaultMaxPerRoute(DEFAULT_MAX_PER_ROUTE);  
            return poolingConnectionManager;  
        } catch (Exception e) {  
            log.error("Error initializing SSL context", e);  
            return new PoolingHttpClientConnectionManager(); // Fallback  
        } finally {  
            if (truststoreFis != null) {  
                try {  
                    truststoreFis.close();  
                } catch (IOException e) {  
                    log.error("Error closing truststore stream: {}", e.getMessage());  
                }  
            }  
            if (keystoreFis != null) {  
                try {  
                    keystoreFis.close();  
                } catch (IOException e) {  
                    log.error("Error closing keystore stream: {}", e.getMessage());  
                }  
            }  
        }  
    }  
    @Bean  
    public ConnectionKeepAliveStrategy connectionKeepAliveStrategy() {  
        // Configures and returns a strategy for managing the keep-alive duration of HTTP connections,  
        // ensuring connections are kept alive for a specified period.  
        return (HttpResponse response, HttpContext context) -> {  
            HeaderElementIterator it = new BasicHeaderElementIterator(response.headerIterator(HTTP.CONN_KEEP_ALIVE));  
            while (it.hasNext()) {  
                HeaderElement he = it.nextElement();  
                String param = he.getName();  
                String value = he.getValue();  
                if (value != null && param.equalsIgnoreCase("timeout")) {  
                    return Long.parseLong(value) * 1000;  
                }  
            }  
            return DEFAULT_KEEP_ALIVE_TIME_MILLIS;  
        };  
    }  
    @Bean("closeableHttpClient1")  
    public CloseableHttpClient closeableHttpClient() {  
        RequestConfig requestConfig = RequestConfig  
                .custom()  
                .setConnectionRequestTimeout(REQUEST_TIMEOUT)  
                .setConnectTimeout(CONNECT_TIMEOUT)  
                .setSocketTimeout(SOCKET_TIMEOUT)  
                .build();  
        return HttpClients  
                .custom()  
                .setDefaultRequestConfig(requestConfig)  
                .setConnectionManager(poolingConnectionManager())  
                .setKeepAliveStrategy(connectionKeepAliveStrategy())  
                .build();  
    }  
}
```
## Step 3: Send Secure HTTPS Call — HttpServiceImpl Class
```java
@Service  
public class HttpServiceImpl {  
      
    @Autowired  
    @Qualifier("closeableHttpClient")  
    private CloseableHttpClient httpClient;  
  
    public String sendRequest(RequestObject requestObject) {  
        String url = "https://localhost:9443/api/v1/post-request";  
        CloseableHttpResponse response = null;  
        try {  
            HttpPost post = new HttpPost(url);  
            post.setHeader("Content-Type", "application/json");  
  
            ObjectMapper objectMapper = new ObjectMapper();  
            String jsonPayload = objectMapper.writeValueAsString(requestObject);  
             
            post.setEntity(new StringEntity(jsonPayload));  
            response = httpClient.execute(post);  
            return EntityUtils.toString(response.getEntity());  
        } catch (Exception e) {  
            return "{"status":"error","message":"" + e.getMessage() + ""}";  
        } finally {  
            try {  
                if (response != null) response.close();  
                httpClient.close();  
            } catch (IOException e) {  
                // ignore  
            }  
        }  
    }  
}
```
## Step 4: Web Controller — ClientController Class
```java
@RestController  
@RequestMapping("/api/v1")  
public class ClientController {  
      @Autowired  
      private HttpServiceImpl httpService;  
  
      @PostMapping("/send")  
      public ResponseEntity<?> send(@RequestBody RequestObject requestObject) {  
          Map<String, Object> response = new HashMap<>();  
          try {  
              String serverResponse = httpService.sendRequest(requestObject);  
              response.put("status", "success");  
              response.put("server_response", new ObjectMapper().readValue(serverResponse, Map.class));  
          } catch (Exception e) {  
              response.put("status", "error");  
              response.put("message", e.getMessage());  
          } finally {  
              response.put("timestamp", Instant.now().toString());  
          }  
          return ResponseEntity.ok(response);  
      }  
}
```
# Server Side — TransactionProcessorGatewayService

## Step 1: application.yml
```yaml
server:  
  port: 9443  
  ssl:  
    enabled: true  
    key-store: /opt/config/certs/server/server.p12  
    key-store-password: changeit  
    key-store-type: PKCS12  
    key-alias: server  
    trust-store: /opt/config/certs/server/client-truststore.p12  
    trust-store-password: changeit  
    trust-store-type: PKCS12
```
## Step 2: Web Controller — RequestReceiverController
```java
@RestController  
@RequestMapping("/api/v1")  
public class RequestReceiverController {  
  
    @PostMapping("/post-request")  
    public ResponseEntity<?> receiveRequest(@RequestBody RequestObject requestObject) {  
        Map<String, Object> response = new HashMap<>();  
        try {  
            response.put("status", "received");  
            response.put("received_data", requestObject);  
        } catch (Exception e) {  
            response.put("status", "error");  
            response.put("message", e.getMessage());  
        } finally {  
            response.put("processed_at", Instant.now().toString());  
        }  
        return ResponseEntity.ok(response);  
    }  
}
```
# Conclusion

And there you have it — a fully working mutual TLS setup in Java using Spring Boot.

We didn’t just wire things blindly. We explored what HTTPS and TLS 1.2 actually do, how certificates work, and how to use OpenSSL and keytool to generate and configure your keystores and truststores. Most importantly, we built a secure, production-grade connection between two services — authenticated and encrypted end-to-end.

# What’s Next?

In the next article, we’ll cover how to deal with common issues that arise when setting up mutual TLS, Including:

-   Certificate validation failures
-   Hostname mismatches (especially when using IPs in UAT)
-   TLS version incompatibilities
-   And how to test mTLS endpoints using curl, Postman, and OpenSSL