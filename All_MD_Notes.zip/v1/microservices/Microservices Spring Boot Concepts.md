# Advanced Spring Boot Concepts that Every Java Developer Should Know

## 1. Understanding Spring Boot Starters

Starters are pre-configured dependencies that make it easy to add a specific feature to your project. For example, if you want to work with a database, you just add the `spring-boot-starter-data-jpa` starter, and all the required libraries are included automatically.

They save you from manually finding and adding individual dependencies, which can be time-consuming and error-prone.

#### Example:

Here’s how you add a starter for web development in your `pom.xml`:
```xml
<dependency>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-starter-web</artifactId>  
</dependency>
```
With just this dependency, you get a complete setup for building REST APIs, including libraries like Spring MVC and Tomcat.

## 2. Working with Profiles

Profiles allow you to define different configurations for different environments, such as development, testing, and production. This way, you don’t have to hard-code environment-specific values.

Profiles make it easy to switch between environments without changing your code.

#### Example:

**application-dev.properties**
```shell
spring.datasource.url=jdbc:h2:mem:dev-db  
spring.datasource.username=dev  
spring.datasource.password=devpass
```
**application-prod.properties**
```shell
spring.datasource.url=jdbc:mysql://prod-db:3306/mydb  
spring.datasource.username=prod  
spring.datasource.password=securepass
```
You can activate a profile by setting the `spring.profiles.active` property:
```shell
spring.profiles.active=prod
```
## 3. Using Actuator for Monitoring

Actuator adds endpoints to your application that provide details about its health, metrics, and environment. It’s like a dashboard for your app, but you access it through URLs.

Actuator helps you monitor and troubleshoot your application easily, especially in production.

#### Example:

Add the Actuator dependency to your `pom.xml`:
```xml
<dependency>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-starter-actuator</artifactId>  
</dependency>
```
Then access endpoints like these:

-   `/actuator/health`: Shows if the app is up and running.
-   `/actuator/metrics`: Displays metrics like memory usage and active threads.

To secure these endpoints, add basic authentication in your `application.properties`:
```shell
management.endpoints.web.exposure.include=health,metrics  
management.endpoint.health.probes.enabled=true
```
## 4. Customizing the Error Pages

Default error pages can be confusing for users. Customizing them improves the user experience.

#### Example:

Create an `error.html` file in the `src/main/resources/templates` folder:
```html
<!DOCTYPE html>  
<html>  
<head>  
    <title>Error</title>  
</head>  
<body>  
    <h1>Oops! Something went wrong.</h1>  
    <p>Please try again later.</p>  
</body>  
</html>
```
Spring Boot will automatically use this page for errors.

## 5. Using Custom Annotations

Custom annotations can simplify your code by removing repetitive tasks. You can group multiple annotations into one and use it across your project.

#### Example:

Here’s how to create a custom annotation:
```java
@Target({ElementType.TYPE})  
@Retention(RetentionPolicy.RUNTIME)  
@Documented  
@RestController  
@RequestMapping("/api")  
public @interface ApiController {  
}
```
Now you can use `@ApiController` instead of adding `@RestController` and `@RequestMapping("/api")` every time.

## 6. Implementing Caching

Caching improves performance by storing frequently accessed data so you don’t have to fetch it repeatedly from the database.

#### Example:

Add the caching dependency:
```xml
<dependency>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-starter-cache</artifactId>  
</dependency>
```
Enable caching in your application:
```java
@SpringBootApplication  
@EnableCaching  
public class Application {  
}
```
Use `@Cacheable` to cache a method’s result:
```java
@Cacheable("products")  
public Product getProductById(Long id) {  
    return productRepository.findById(id).orElseThrow();  
}
```

## 7. Securing Your Application

Security is crucial for any application. Spring Security makes it easy to add authentication and authorization to your app.

#### Example:

Add Spring Security to your project:
```xml
<dependency>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-starter-security</artifactId>  
</dependency>
```
Secure an endpoint using annotations:
```java
@GetMapping("/admin")  
@PreAuthorize("hasRole('ADMIN')")  
public String adminAccess() {  
    return "Welcome Admin!";  
}
```
Use `application.properties` to define a simple username and password:
```shell
spring.security.user.name=admin  
spring.security.user.password=secret
```
## 8. Understanding Async Programming

Sometimes, you need to run tasks in the background without blocking the main thread. Spring Boot makes this easy with asynchronous programming.

#### Example:

Enable async support in your app:
```java
@EnableAsync  
@SpringBootApplication  
public class Application {  
}
```
Annotate methods with `@Async`:
```java
@Async  
public void sendEmail(String email) {  
    // Simulate email sending  
    System.out.println("Sending email to: " + email);  
}
```
## 9. Managing Microservices Communication

If you’re working with microservices, you need a way for them to talk to each other. Spring Boot provides tools for REST and message-based communication.

#### Example:

Use `WebClient` for REST communication instead of `RestTemplate` (deprecated):
```java
@Autowired  
private WebClient.Builder webClientBuilder;  
  
public String getUserInfo(String userId) {  
    return webClientBuilder.build()  
            .get()  
            .uri("http://user-service/users/" + userId)  
            .retrieve()  
            .bodyToMono(String.class)  
            .block();  
}
```
You can also use the Open Feign module for REST API communication.

Use RabbitMQ or Kafka for messaging between services.

## 10. Testing with Spring Boot

Testing ensures your application works as expected. Spring Boot provides great tools to make testing easy.

#### Example:

Use `@SpringBootTest` for integration testing:
```java
@SpringBootTest  
public class ProductServiceTest {  
  
    @Autowired  
    private ProductService productService;  
  
    @Test  
    void testGetProductById() {  
        Product product = productService.getProductById(1L);  
        assertNotNull(product);  
    }  
}
```
## 11. Service Discovery with Eureka

In microservices, you need a way to dynamically discover and connect services without hardcoding their locations.

#### Example:

Add the Eureka Server dependency:
```xml
<dependency>  
    <groupId>org.springframework.cloud</groupId>  
    <artifactId>spring-cloud-starter-netflix-eureka-server</artifactId>  
</dependency>
```
Set up a Eureka server in the main application:
```java
@EnableEurekaServer  
@SpringBootApplication  
public class EurekaServerApplication {  
    public static void main(String[] args) {  
        SpringApplication.run(EurekaServerApplication.class, args);  
    }  
}
```
## 12. Load Balancing with Spring Cloud LoadBalancer

With Ribbon being deprecated, Spring Cloud LoadBalancer is the recommended way to implement client-side load balancing. It helps distribute traffic evenly among your microservices to avoid overloading any single instance.

#### Example:

Add Spring Cloud LoadBalancer to your project:
```xml
<dependency>  
    <groupId>org.springframework.cloud</groupId>  
    <artifactId>spring-cloud-starter-loadbalancer</artifactId>  
</dependency>
```
Configure LoadBalancer in your application properties:

spring.cloud.loadbalancer.hint.user-service.instances=localhost:8081,localhost:8082

Use it in your code with `WebClient`:
```java
@Bean  
public WebClient.Builder webClientBuilder() {  
    return WebClient.builder();  
}  
  
public String getUserInfo(String userId) {  
    return webClientBuilder.build()  
            .get()  
            .uri("http://user-service/users/" + userId)  
            .retrieve()  
            .bodyToMono(String.class)  
            .block();  
}
```
Spring Cloud LoadBalancer integrates seamlessly with other Spring Cloud components and provides more flexibility compared to Ribbon.

## 13. API Gateway with Spring Cloud Gateway

An API Gateway acts as a single entry point for client requests, making it easier to manage microservices.

#### Example:

Add Spring Cloud Gateway:
```xml
<dependency>  
    <groupId>org.springframework.cloud</groupId>  
    <artifactId>spring-cloud-starter-gateway</artifactId>  
</dependency>
```
Set up routing:
```yaml
spring:  
  cloud:  
    gateway:  
      routes:  
        - id: user-service  
          uri: http://localhost:8081  
          predicates:  
            - Path=/users/**
```
## 14. Distributed Tracing with Sleuth

When debugging microservices, it’s important to trace requests as they flow through multiple services.

#### Example:

Add Sleuth to your project:
```xml
<dependency>  
    <groupId>org.springframework.cloud</groupId>  
    <artifactId>spring-cloud-starter-sleuth</artifactId>  
</dependency>
```
Sleuth automatically adds trace IDs to logs for easy debugging.

## 15. Centralized Configuration with Spring Cloud Config

Managing configuration across multiple microservices can be messy. Spring Cloud Config centralizes configurations in one place.

#### Example:

Add the Config Server dependency:
```xml
<dependency>  
    <groupId>org.springframework.cloud</groupId>  
    <artifactId>spring-cloud-config-server</artifactId>  
</dependency>
```
Enable the Config Server:
```java
@EnableConfigServer  
@SpringBootApplication  
public class ConfigServerApplication {  
    public static void main(String[] args) {  
        SpringApplication.run(ConfigServerApplication.class, args);  
    }  
}
```
