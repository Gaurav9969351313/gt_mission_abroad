# Scaling Databases Like a Pro: Indexing, Sharding and Partitioning Explained with Real-World Scenarios 

An **index** is a data structure that improves the speed of data retrieval operations by creating a sorted reference to specific columns in a table.

## Use Cases

-   Faster lookups and queries.
-   Optimized `WHERE`, `JOIN`, and `ORDER BY` clauses.
-   Reducing full table scans.

## Example

Creating an index on a `users` table for fast email lookups:
```sql
CREATE INDEX idx_users_email ON users(email);
```
Now, this query will be faster:
```sql
SELECT * FROM users WHERE email = 'test@example.com';
```
## Scenario:

**_Your application has a table with millions of records. Searching by_** `**_email_**` **_is slow. How can you optimize it?_**  
Add an **index** on the `email` column to avoid full table scans.

## Sharding

![](https://miro.medium.com/v2/resize:fit:784/1*fIxG_BpbS-3x9aMA-0VZLg.png)

## Definition

**Sharding** is a **horizontal scaling** technique where data is distributed across multiple database instances (shards), reducing the load on a single database.

## Use Cases

-   Large-scale applications with massive data.
-   Handling high **write throughput**.
-   Improving availability and resilience.

## Example

You have **100 million users**, and querying them in one database is slow. You split users into multiple shards:

-   **Shard 1:** User IDs 1–50M
-   **Shard 2:** User IDs 50M-100M

When querying, you direct requests based on user ID:
```sql
SELECT * FROM users WHERE id = 12345; -- Route to Shard 1  
SELECT * FROM users WHERE id = 98765432; -- Route to Shard 2
```
## Scenario:

**_Your e-commerce application has 1 billion users. How would you scale your database to handle user data efficiently?_**

Implement **sharding** by splitting users across multiple databases, using **range-based** or **hash-based** distribution.

## Partitioning

![](https://miro.medium.com/v2/resize:fit:875/1*e219SFP5G-1ckS41O2bAfQ.png)

## Definition

Partitioning is a **logical division** of a single database table into multiple smaller pieces (partitions), making queries and management more efficient.

![](https://miro.medium.com/v2/resize:fit:840/1*lXdUeX5SmpZzkvKFN7gWmQ.png)

## Types of Partitioning

-   **Range Partitioning:** Based on value ranges (e.g., dates).
-   **List Partitioning:** Based on discrete values (e.g., region).
-   **Hash Partitioning:** Distributes rows evenly (e.g., using `MOD(user_id, 4)`).
-   **Composite Partitioning:** Combines multiple strategies.

## Example

Partitioning a sales table by year:
```sql
CREATE TABLE sales (  
    id INT,  
    amount DECIMAL(10,2),  
    sale_date DATE  
)  
PARTITION BY RANGE (YEAR(sale_date)) (  
    PARTITION p2023 VALUES LESS THAN (2024),  
    PARTITION p2024 VALUES LESS THAN (2025)  
);
```
Now, a query like:
```sql
SELECT * FROM sales WHERE sale_date BETWEEN '2023-01-01' AND '2023-12-31';
```
will **only scan partition** `**p2023**`, improving performance.

## Scenario:

**_Your analytics team queries only last year’s sales data, but queries are slow. What can you do?_**  
Use **range partitioning** by year, ensuring queries only scan relevant partitions.

## Scenario:

**_Your application supports 500M users, and searches for users by_** `**_email_**` **_are slow. What would you do?_**

1.  **First**, create an **index** on `email` for faster lookups.
2.  **If still slow**, consider **partitioning** the table by `region` or `user creation date`.
3.  **If traffic is too high**, implement **sharding** across multiple databases.

-   **Indexing** speeds up queries within a table.
-   **Sharding** scales the database horizontally.
-   **Partitioning** organizes data logically within a table.

## Real-World Scenario for Indexing

You have an **e-commerce platform** where users frequently search for products by **name** and **category**. The `products` table has **10 million+ records**, and searches are slowing down.

## Initial Table Structure
```sql
CREATE TABLE products (  
    id BIGINT PRIMARY KEY AUTO_INCREMENT,  
    name VARCHAR(255),  
    category VARCHAR(100),  
    price DECIMAL(10,2),  
    stock INT,  
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP  
);
```
## Query Before Indexing (Slow)
```sql
SELECT * FROM products WHERE name LIKE '%laptop%';
```
This results in a **full table scan**, which is inefficient for large datasets.

## Adding Indexes

**Single-Column Index (For Exact Match)**
```sql
CREATE INDEX idx_products_name ON products(name);
```
🔹 Speeds up queries like:
```sql
SELECT * FROM products WHERE name = 'MacBook Air';
```
**Full-Text Index (For Partial Matches)**
```sql
CREATE FULLTEXT INDEX ft_idx_products_name ON products(name);
```
🔹 Optimizes:
```sql
SELECT * FROM products WHERE MATCH(name) AGAINST('laptop');
```
**Composite Index (For Multiple Columns)**
```sql
CREATE INDEX idx_products_name_category ON products(name, category);
```
🔹 Helps when filtering by both:
```sql
SELECT * FROM products WHERE name = 'MacBook' AND category = 'Electronics';
```
## Scenario:

**_After adding an index, inserts and updates in the_** `**_products_**` **_table have slowed down. Why?_**  
✅ **A:** Indexes speed up reads but **slow down writes** because every insert/update must update the index.  
✅ **Fix:** Use indexes **only on frequently searched columns**.

## Real-World Scenario for Sharding

**A social media app has 500M+ users, and storing all users in a single database causes slowdowns. You need a scalable solution.**

## Shard Users Table

## Sharding Strategy

🔹 **Range-Based Sharding** (e.g., Based on `user_id`)

-   **Shard 1:** `user_id` **1 to 100M** → `users_shard_1`
-   **Shard 2:** `user_id` **100M to 200M** → `users_shard_2`
-   **Shard 3:** `user_id` **200M to 300M** → `users_shard_3`

🔹 **Query Routing Based on User ID**
```python
def get_shard(user_id):  
    if user_id <= 100000000:  
        return "users_shard_1"  
    elif user_id <= 200000000:  
        return "users_shard_2"  
    else:  
        return "users_shard_3"

shard = get_shard(150000000)  
query = f"SELECT * FROM {shard} WHERE user_id = 150000000;"
```
🔹 **Shard Implementation in SQL**
```sql
CREATE TABLE users_shard_1 (  
    user_id BIGINT PRIMARY KEY,  
    name VARCHAR(255),  
    email VARCHAR(255) UNIQUE  
);

CREATE TABLE users_shard_2 (  
    user_id BIGINT PRIMARY KEY,  
    name VARCHAR(255),  
    email VARCHAR(255) UNIQUE  
);
```

## Scenario:

**_What are the challenges of sharding?_**

1.  **Cross-shard queries are slow.** You can’t easily `JOIN` across shards.
2.  **Resharding is complex.** If one shard fills up, moving data is costly.
3.  **Query routing logic is required.**

✅ **Fix:**

-   **Use an application-level query router.**
-   **Pre-aggregate data to reduce joins.**
-   **Use consistent hashing for even shard distribution.**

## Real-World Scenario for Partitioning

A **banking system** stores transaction history for **millions of customers**. Queries for a customer’s transactions over the last **3 months** are slow because the `transactions` table contains **billions of records**.

## Partition by Date (Range-Based Partitioning)

## Create a Partitioned Table
```sql
CREATE TABLE transactions (  
    id BIGINT PRIMARY KEY AUTO_INCREMENT,  
    customer_id BIGINT,  
    amount DECIMAL(10,2),  
    transaction_date DATE  
)  
PARTITION BY RANGE (YEAR(transaction_date)) (  
    PARTITION p2022 VALUES LESS THAN (2023),  
    PARTITION p2023 VALUES LESS THAN (2024),  
    PARTITION p2024 VALUES LESS THAN (2025)  
);
```
🔹 **Benefit:**

-   Queries for **recent transactions** will only scan the relevant partition.

## Query Optimization
```sql
SELECT * FROM transactions WHERE transaction_date BETWEEN '2024-01-01' AND '2024-01-31';
```
This **only scans** `**p2024**`, making it **much faster**.

## Scenario:

**_What if a transaction query needs data from multiple partitions?_**  
The query will scan **only necessary partitions**, making it faster than a full table scan.  
**Fix:** Use **composite partitioning** (e.g., `customer_id` + `year`).

# Real-World Case Study

## Building a Video Streaming Service (Like Netflix)

Your service has:

-   **50M+ users**
-   **10M+ videos**
-   Each video has **millions of views, comments, and likes**

## How to Optimize

✔ **Indexing:**

-   Index `video_id` in `views` table for fast lookup.

CREATE INDEX idx_views_video ON video_views(video_id);

-   Composite index on `user_id` and `video_id` for recommendations.

✔ **Sharding:**

-   **Users Table** → Sharded by `region` (e.g., `users_us`, `users_eu`).
-   **Videos Table** → Sharded by `category` (e.g., `movies_shard`, `sports_shard`).

✔ **Partitioning:**

-   `video_views` partitioned by `year` to optimize analytics.
```sql
PARTITION BY RANGE (YEAR(view_date));
```
# Scenario:

**_A query that fetches the top 10 most viewed videos in the last month is slow. What optimizations would you apply?_**  
  
**Use an index on** `**view_date**` to speed up recent lookups.  
**Partition** `**video_views**` **by month** to scan only relevant data.  
**Pre-aggregate top views daily** and store in a separate table.

# Tips

-   **Use indexing first** for search speed.
-   **Use sharding when scaling is needed.**
-   **Use partitioning for large tables with time-based queries.**
