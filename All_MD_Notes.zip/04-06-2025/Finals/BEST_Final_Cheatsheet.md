# Cheatsheet AWS for Backend Engineers: Everything You Need to Know

### 🔥 Why Every Backend Engineer Needs AWS?

Let’s be honest: if you’re building anything serious — SaaS, APIs, distributed systems — you’re probably deploying it on **AWS**. And yet, AWS is like a giant Lego set where the pieces are **expensive**, **complex**, and often **confusing**.

This cheatsheet is your tactical guide to navigating AWS with backend-engineering clarity. Let’s break it down.

### ☁️ 1. Compute Services (Where Your Code Lives)

![](https://miro.medium.com/v2/resize:fit:875/1*kuHSrAPB9RmGAYHlbtFDMA.png)

🧠 **Tip**: Start with **Lambda** for simple APIs and **ECS Fargate** for containers without managing infra.

### 🗄️ 2. Storage & Databases

![](https://miro.medium.com/v2/resize:fit:875/1*Rqsu8ehTeBvdia4uKO7fA.png)

🧠 **Tip**: Use **DynamoDB** for high-throughput, schema-less data; use **RDS** if you need transactions & joins.

### 🧪 3. Monitoring & Observability

![](https://miro.medium.com/v2/resize:fit:875/1*meRIcdVC5XQaLt-KFmZ4mw.png)

🧠 **Tip**: Pipe logs from Lambda/EC2 into **CloudWatch**. Set up basic **alarms** for error spikes and CPU usage.

### 🔐 4. IAM & Security

![](https://miro.medium.com/v2/resize:fit:875/1*csKsobq3MbCRT0YfegXXw.png)

🧠 **Tip**: Never give wide `*` permissions. Use **least privilege**. Rotate access keys. Use **IAM roles** for services.

### 🌐 5. Networking & Traffic

![](https://miro.medium.com/v2/resize:fit:875/1*KG4p9vfZoOoTZf53ZvYstw.png)

🧠 **Tip**: Use **API Gateway + Lambda** for cheap, scalable APIs. Use **CloudFront** to serve S3-hosted web apps.

### 🧱 6. DevOps & Automation

![](https://miro.medium.com/v2/resize:fit:875/1*b-MbPIltNIolvHLFDZhmA.png)

🧠 **Tip**: Use **CDK** if you like code over YAML. Create reproducible infra from your IDE.

### 📦7. Messaging & Eventing

![](https://miro.medium.com/v2/resize:fit:875/1*M7EEbUc8upJBfGj3sPnLyg.png)

🧠 **Tip**: Use **SQS** to buffer load, **SNS** for fan-out messaging, and **EventBridge** for loosely coupled event-driven systems.

### 🧪 Example: Building a Simple Web App on AWS

Here’s a minimal AWS tech stack for a backend project:

-   🖥️ **Frontend**: React served from **S3 + CloudFront**
-   ⚙️ **Backend API**: **Lambda + API Gateway**
-   🗄️ **Database**: **DynamoDB**
-   🧠 **Authentication**: **Cognito**
-   🚨 **Logs & Alerts**: **CloudWatch**

> This stack is cheap, scalable, and fully serverless — perfect for startups and weekend hacks.

### 🚨 AWS Gotchas to Avoid

-   💸 Forgetting to turn off unused EC2 or RDS = surprise bill.
-   🚪 Public S3 buckets = security risk.
-   🔐 Hardcoded AWS keys = breach waiting to happen.
-   🧹 No lifecycle rules = S3 cost spiral.
-   😵‍💫 Too many services too fast = cognitive overload.

### 📬 Cheatsheet Summary

> 🧠 Understand the **big 10 services**: EC2, Lambda, S3, RDS, DynamoDB, VPC, IAM, CloudWatch, API Gateway, SQS.
> 
> 🔐 Follow the **security trinity**: IAM, encryption, secrets management.
> 
> ⚙️ Automate everything: CDK, CloudFormation, CI/CD.
> 
> 📈 Watch everything: logs, metrics, tracing.
> 
> 🚀 Start serverless and scale into complexity.
---
# Cheatsheet Design Patterns : 10 Java Patterns You’ll Actually Use (With Real-World Examples) 

### 🎯 Why This Cheatsheet?

Java has over **two dozen design patterns**. But let’s be honest:

> You’ll only use a handful of them regularly — and those are the ones you should **master deeply**.

This isn’t an academic list. It’s a **practical guide** to the patterns that:

-   Show up in **real-world projects.**
-   Get you **bonus points in interviews.**
-   Make your codebase **cleaner, more scalable, and maintainable**

Here are the **top 10 Java patterns you’ll actually use**, with **when to use them**, real-world analogies, and code snippets.

### 1. Singleton Pattern

💡 **Purpose**: Ensure a class has only one instance, and provide a global access point.

📦 **Where it shows up**: Logger, ConfigLoader, Database Connection Pool
```java
public class Config {  
    private static final Config instance = new Config();  
    private Config() {}  
    public static Config getInstance() {  
        return instance;  
    }  
}
```
⚠️ Use with caution in multithreaded environments — prefer `enum`-based singletons in modern Java.

### 2. Factory Pattern

💡 **Purpose**: Create objects without exposing the creation logic to the client.

📦 **Where it shows up**: Spring Beans, JDBC Drivers, Document/Report generation
```java
public class ShapeFactory {  
    public Shape getShape(String type) {  
        return switch (type) {  
            case "circle" -> new Circle();  
            case "square" -> new Square();  
            default -> throw new IllegalArgumentException();  
        };  
    }  
}
```
### 3. Builder Pattern

💡 **Purpose**: Construct complex objects step-by-step with a clean, fluent interface.

📦 **Where it shows up**: Creating HTTP requests, POJOs with many fields
```java
User user = new User.Builder()  
    .name("Alice")  
    .email("alice@example.com")  
    .age(30)  
    .build();
```
✅ Use when a constructor gets ugly with too many params.

### 4. Strategy Pattern

💡 **Purpose**: Define a family of interchangeable algorithms at runtime.

📦 **Where it shows up**: Sorting strategies, payment processing, authentication flows
```java
public interface CompressionStrategy {  
    void compress(String file);  
}  
public class ZipCompression implements CompressionStrategy { ... }  
public class RarCompression implements CompressionStrategy { ... }
```
Inject different strategies at runtime without touching business logic.

### 5. Observer Pattern

💡 **Purpose**: Notify dependent objects automatically when a subject changes state.

📦 **Where it shows up**: Event-driven systems, UI frameworks, pub-sub architecture
```java
subject.attach(observer);  
subject.setState("UPDATED");
```
Perfect for decoupled notification systems — think `EventBus`, `Listeners`, `WebSocket updates`.

### 6. Decorator Pattern

💡 **Purpose**: Add new responsibilities to objects dynamically.

📦 **Where it shows up**: Java I/O streams (`BufferedReader`, `InputStreamReader`)
```java
Reader reader = new BufferedReader(new InputStreamReader(System.in));
```
Stack behaviors like logging, authentication, caching — **without subclassing**.

### 7. Adapter Pattern

💡 **Purpose**: Bridge two incompatible interfaces.

📦 **Where it shows up**: Legacy code integration, third-party APIs, DTO converters.
```java
public class LegacyUserAdapter implements ModernUser {  
    private final LegacyUser legacyUser;  
    // Translate old methods to new interface  
}
```
Great for **writing glue code** between evolving systems.

### 8. Command Pattern

💡 **Purpose**: Encapsulate a request as an object.

📦 **Where it shows up**: Queues, undo/redo operations, job schedulers.
```java
interface Command {  
    void execute();  
}  
  
class PrintJob implements Command {  
    public void execute() {  
        System.out.println("Printing document...");  
    }  
}
```
Use it when you want to **queue**, **log**, or **retry** operations.

### 9. Proxy Pattern

💡 **Purpose**: Provide a placeholder to control access to another object.

📦 **Where it shows up**: Spring AOP, security layers, lazy loading, rate limiting.
```java
public class SecureServiceProxy implements Service {  
    private Service realService = new RealService();  
    public void perform() {  
        if (user.isAuthorized()) realService.perform();  
    }  
}
```
✅ Think access control, logging, caching.

### 10. Template Method Pattern

💡 **Purpose**: Define the skeleton of an algorithm, deferring steps to subclasses.

📦 **Where it shows up**: Frameworks, test setup, algorithm design
```java
abstract class DataProcessor {  
    public final void process() {  
        read();  
        transform();  
        write();  
    }  
    abstract void read();  
    abstract void transform();  
    abstract void write();  
}
```
Keeps common logic in the parent, custom logic in children.

### 🏋🏼‍♂️ Grouped By Category

> 🧱 **Core Creational**: Singleton, Factory, Builder
> 
> 🧠 **Behavioral**: Strategy, Observer, Command, Template Method
> 
> 🧩 **Structural**: Decorator, Adapter, Proxy

### 🏋🏼‍♂️ How to Actually Use These in Projects

-   Use patterns to **remove duplication**, **increase flexibility**, and **improve clarity**.
-   Know the **problem** before reaching for a pattern.
-   Don’t overengineer. Patterns should solve pain, not create it.

### 🙅🏽 Final Thoughts

Design patterns aren’t magic — they’re just **repeatable solutions to common problems**. The goal isn’t to use them everywhere. It’s to **recognize when a problem already has a name**, and solve it with confidence.

> Learn these 10 patterns. Use them well. And your code will start looking like it was written by experienced developer !!!

---
# ☁️Cheatsheet Google Cloud for Backend Engineers

![](https://miro.medium.com/v2/resize:fit:1250/1*m2lPOw84JRyqoCOku77g.png)

If you’re a backend engineer in 2025, Google Cloud Platform (GCP) isn’t just an option — it’s one of the fastest, most dev-friendly platforms out there. Whether you’re building REST APIs, streaming data, or powering AI microservices, this is your **no-fluff, punchy cheatsheet** for working like a GCP-native backend pro.

### 🔧 What GCP Does Better Than Most

-   Auto-scaling containers with zero ops.
-   Native support for LLMs & embeddings via Vertex AI.
-   Seamless CI/CD via Cloud Build.
-   Serious networking + observability tooling.
-   Tight IAM controls for secure service design.

### 🧠 Conclusion— Core GCP Services Backend Engineers Should Know

![](https://miro.medium.com/v2/resize:fit:875/1*6lCCOHmbpIvJv7zrw1L2w.png)

### 🚀 Deploy a Backend App with Zero Drama

###### ✅ Cloud Run (Serverless Docker FTW)

gcloud builds submit --tag gcr.io/YOURPROJECT/app  
gcloud run deploy backend-api   
  --image gcr.io/YOURPROJECT/app   
  --platform managed   
  --region us-central1   
  --allow-unauthenticated

Why Cloud Run?

-   🌀 Auto-scales down to 0.
-   💥 Cold starts are fast in 2025.
-   ☁️ Works great with REST APIs, workers, and LLM services.

### 🔐 IAM & Security — Do It Right or Get Burned

GCP uses **IAM (Identity and Access Management)** for fine-grained control.

![](https://miro.medium.com/v2/resize:fit:875/1*MTkSTux4AVpsDEQWXmWsfg.png)

Pro Tip: Assign **least-privilege** access and rotate keys with automation.

### 🔄 Cloud SQL for Relational DBs

-   Use **Cloud SQL** for PostgreSQL or MySQL.
-   Automatically handles backups, replicas, failover.
-   Works natively with Spring Boot, Hibernate, Prisma, Sequelize, etc.

Connect securely:

gcloud sql connect your-db --user=postgres

Or use **Cloud SQL Auth Proxy** in dev environments for local testing.

### 📦 Cloud Storage (Not Just for Images)

Think S3, but Google. Use for:

-   User-uploaded files.
-   Data archives.
-   Logs, backups, assets.

Upload from CLI:

gsutil cp ./report.csv gs://your-bucket/

Download in code (Java example):

Storage storage = StorageOptions.getDefaultInstance().getService();  
Blob blob = storage.get("your-bucket", "file.csv");  
byte[] content = blob.getContent();

### 🧪 CI/CD with Cloud Build

Forget Jenkins. Use `cloudbuild.yaml` to:

1.  Build your app.
2.  Dockerize it.
3.  Push to Artifact Registry.
4.  Deploy to Cloud Run or GKE.

steps:  
  - name: 'gcr.io/cloud-builders/docker'  
    args: ['build', '-t', 'gcr.io/$PROJECTID/backend', '.']  
  - name: 'gcr.io/cloud-builders/docker'  
    args: ['push', 'gcr.io/$PROJECTID/backend']  
  - name: 'gcr.io/google.com/cloudsdktool/cloud-sdk'  
    args: ['gcloud', 'run', 'deploy', 'backend', '--image=gcr.io/$PROJECTID/backend']

💡 **Bonus:** Integrate with GitHub → auto-deploy on push to `main`

### 🔭 Monitoring, Logs & Debugging

Use:

-   **Cloud Logging** for structured logs.
-   **Cloud Monitoring** for uptime alerts, CPU/RAM.
-   **Error Reporting** to catch exceptions from your services.

Set up alert policies like:

> “Email me if CPU > 80% for 5 mins”  
> “Slack alert if /api/login errors spike”

### 🧠 AI Features for Backend Devs

###### Vertex AI (Your ML+LLM Playground)

![](https://miro.medium.com/v2/resize:fit:875/1*mkCczvnBLv0pe2TD-ovg.png)

Example: Build a GPT-like experience over your support docs.

### 🔒 Secrets Management FTW

Replace `.env` files with:

gcloud secrets create DBPASSWORD --replication-policy="automatic"  
gcloud secrets versions add DBPASSWORD --data-file=password.txt

Access in code via SDK or environment injection.

### 🛠 Dev Workflow: Your Daily GCP Flow as a Backend Dev

### 1. Set project & auth  
gcloud config set project your-project-id  
gcloud auth login  
  
### 2. Build Docker & deploy  
gcloud builds submit --tag gcr.io/project/backend  
gcloud run deploy backend --image=gcr.io/project/backend  
### 3. View logs  
gcloud logging read "resource.type=cloudrunrevision"  
### 4. Manage DB  
gcloud sql connect my-db --user=postgres

### 🧵 Conclusion: GCP Cheatsheet for Backend Developers

![](https://miro.medium.com/v2/resize:fit:875/1*EaOFsD2JfeOngNN0fhMGA.png)

### 🧠 Final Tips for Backend Devs on GCP

> 🔐 Avoid over-permissioned service accounts.
> 
> 🧪 Use `staging` and `prod` projects separately.
> 
> 🧰 Learn `gcloud` CLI — it’s your best friend.
> 
> 🏷 Use consistent labels/tags for resource tracking.
> 
> 📉 Monitor before it breaks, not after.

### ✅ Final Thoughts: Why GCP Deserves a Spot in Your Stack

Google Cloud isn’t just “the other cloud provider” anymore, it’s the **developer-first**, **AI-native**, and **lean-stack friendly** platform that actually helps you ship faster.

Whether you’re building an LLM-powered chatbot, a scalable microservice backend, or a clean CI/CD pipeline, **GCP gives you the tools** without **drowning you in ops drama**. With services like **Cloud Run**, **Vertex AI** and **GKE**, you can move like a startup but scale like Google.

-   Use **GCP for speed**
-   Use **GCP for AI**
-   Use **GCP because Dev Experience finally matters**

Now go deploy that service. And don’t forget to turn off your unused Cloud SQL instances. 💸

---
# System Design CheatSheet for Interview

Dear Readers, I am summarizing the commonly asked concepts in system design interviews.  
These questions are asked in almost all the system design interview rounds.

I am big fan o**f** [**ByteByteGo**](https://bit.ly/3P3eqMN) **a**nd Alex Xu, author of [**System Design Interview — An insider’s guide Volume 1**](https://amzn.to/3nU2Mbp) and [**2**](https://amzn.to/3FAG29r) and because of the knowledge they share.  
They emphases on diagrams and in depth understanding of the system design concepts.

If someone is in a hurry and want to quickly revise all the concepts. Then here is the summary/[**cheat sheet**](/javarevisited/top-3-system-design-cheat-sheets-templates-and-roadmap-for-software-engineering-interviews-53012952db28) of all those concepts to glance before your interview.

![](https://miro.medium.com/v2/resize:fit:875/0*dPriGa93i2wWM-X)

![](https://miro.medium.com/v2/resize:fit:875/0*ja7geFsMkjBshysh)

![](https://miro.medium.com/v2/resize:fit:1028/0*dhkrsgeKpW5nGZ5)

![](https://miro.medium.com/v2/resize:fit:1010/0*Bt1OfbMdicCL0QcH)

> **REST API**

![](https://miro.medium.com/v2/resize:fit:875/0*25y62JfBi6PA2HY)
credit — ByteByteGo

![](https://miro.medium.com/v2/resize:fit:960/0*MIkuJXAf-8ag0pz)

![](https://miro.medium.com/v2/resize:fit:995/0*xtwEAYE05GcDP0Z)

![](https://miro.medium.com/v2/resize:fit:1338/0*jpjNrJoR3WCdLaNX)

![](https://miro.medium.com/v2/resize:fit:1075/0*fM93SyNLQ-ounsy)

![](https://miro.medium.com/v2/resize:fit:1150/0*x836j9C4zV-7SLTt)

![](https://miro.medium.com/v2/resize:fit:995/0*C9x9GqlWF2KcY5au)

![](https://miro.medium.com/v2/resize:fit:1138/0*qUMteJADgZvsqiLt)

![](https://miro.medium.com/v2/resize:fit:1228/0*rPaWAVqbghmW9AN1)

![](https://miro.medium.com/v2/resize:fit:1190/0*noIjQGhPoarTOWPS)

![](https://miro.medium.com/v2/resize:fit:1235/0*fJ28s9mpdaEcD-Fu)

![](https://miro.medium.com/v2/resize:fit:875/0*02tJWCEAJFcM2xFu)

![](https://miro.medium.com/v2/resize:fit:1090/0*L-canaNpzECMS89N)

![](https://miro.medium.com/v2/resize:fit:1170/0*d484qzxC31uy07t7)

![](https://miro.medium.com/v2/resize:fit:875/0*LaHaGk8t2G0J4Jmg)

> **Network**

![](https://miro.medium.com/v2/resize:fit:1145/0*6tfhacqKWq54hKd)

![](https://miro.medium.com/v2/resize:fit:2000/0*uAL4WnGODGFTD4je)

> S**erver**

![](https://miro.medium.com/v2/resize:fit:875/0*2FJTGq6XK8dlRYPQ)

> **AWS Networking cheatsheet**

![AWS Networking Sheet](https://miro.medium.com/v2/resize:fit:478/1*an1DkSMXKk5FZBzFqYDoJQ.png)
AWS Networking Sheet

> **OAuth & JWT**

![](https://miro.medium.com/v2/resize:fit:1298/0*OSGJ2w9-d9MSXTK)

![](https://miro.medium.com/v2/resize:fit:1490/0*zMjEjlLzYemovXDJ)

![](https://miro.medium.com/v2/resize:fit:875/0*1tQUQXsFD7J089Bs)

> **Session vs Cookies**

![](https://miro.medium.com/v2/resize:fit:970/0*55EBOP9FTYnbVy)

![](https://miro.medium.com/v2/resize:fit:950/0*QJwza0g8y5a8k0Qe)

Cookies and sessions are both used to carry user information over HTTP requests, including user login status, user permissions, etc.

● Cookies  
Cookies typically have size limits (4KB). They carry small pieces of information and are stored on the users’ devices. Cookies are sent with each subsequent user request. Users can choose to ban cookies in their browsers.

● Sessions  
Unlike cookies, sessions are created and stored on the server side. There is usually a unique session ID generated on the server, which is attached to a specific user session. This session ID is returned to the client side in a cookie. Sessions can hold larger amounts of data. Since the session data is not directly accessed by the client, the session offers more security.

![](https://miro.medium.com/v2/resize:fit:875/0*8LdICMD9jatGf4H0)

> **CI/CD WorkFlow**

![](https://miro.medium.com/v2/resize:fit:985/0*eey6nIYbjVw06V25)

![](https://miro.medium.com/v2/resize:fit:1008/0*ExMMKaktJ8t6maMI)

> K**afka Internal working & Usecase**

![](https://miro.medium.com/v2/resize:fit:1303/0*R7iGQNgj3LjFcxVg)

![](https://miro.medium.com/v2/resize:fit:895/0*9KOaohT2u1o00BLQ)

> **Database**

![](https://miro.medium.com/v2/resize:fit:1298/0*VxznkO4iwhHFhyN6)

![](https://miro.medium.com/v2/resize:fit:1278/0*x4s3fpddilgLKtXW)

![](https://miro.medium.com/v2/resize:fit:875/0*ERLTnY6u11odMQHs)

![](https://miro.medium.com/v2/resize:fit:1163/0*05aggYPIGWesit3z)

![](https://miro.medium.com/v2/resize:fit:1003/0*LU5uolLJa05IOZTT)

![](https://miro.medium.com/v2/resize:fit:938/0*x2ypaIsJ5f4fJ-fU)

![](https://miro.medium.com/v2/resize:fit:920/0*hSjhjguq-jaap6JD)

![](https://miro.medium.com/v2/resize:fit:1153/0*-FB32yhhTXgfqpqh)

![](https://miro.medium.com/v2/resize:fit:1235/0*3FiacztZuaCBwj3k)

> S**oftware Architecture**

![](https://miro.medium.com/v2/resize:fit:1318/0*8az3zbbGkpUqSRqq)

![](https://miro.medium.com/v2/resize:fit:1093/0*8m-HRYQyinh90oYY)

> **System design Acronyms**

![](https://miro.medium.com/v2/resize:fit:875/0*fG-c1WNGXuLgQqAS)

> **Data Pipeline Overview**

![](https://miro.medium.com/v2/resize:fit:875/0*LeBHUU5lMLIdUVN)

> **System Testing**

![](https://miro.medium.com/v2/resize:fit:875/0*kbLhlwWHTfHmXY7)

> **Git Working**

![](https://miro.medium.com/v2/resize:fit:985/0*fQuf3KPpoviRhSZ)

![](https://miro.medium.com/v2/resize:fit:1210/0*bXSXBi3fialODN)

To begin with, it’s essential to identify where our code is stored. The common assumption is that there are only two locations — one on a remote server like Github and the other on our local machine. However, this isn’t entirely accurate. Git maintains three local storages on our machine, which means that our code can be found in four places:

Working directory: where we edit files  
Staging area: a temporary location where files are kept for the next commit  
Local repository: contains the code that has been committed  
Remote repository: the remote server that stores the code

![](https://miro.medium.com/v2/resize:fit:875/0*qdPdr-BStRiwl6cW)

![](https://miro.medium.com/v2/resize:fit:875/0*g9c4PSkjx7AWbxfJ)

> **Code Review and Ship to Production**

![](https://miro.medium.com/v2/resize:fit:1223/0*xfT19lEHzQvrDtWS)

![](https://miro.medium.com/v2/resize:fit:1030/0*ukQVDdD-WNO3N0C)

> **Docker , Kubernetes**

![](https://miro.medium.com/v2/resize:fit:1005/0*LpNmUWY4hWCdL0X)

![](https://miro.medium.com/v2/resize:fit:1235/0*1Z7qM8zIJ1OmkM6n)

![](https://miro.medium.com/v2/resize:fit:915/0*gCDcULFs58yMQCH6)

![](https://miro.medium.com/v2/resize:fit:903/0*3HrRvV8FE7VcvIz7)

![](https://miro.medium.com/v2/resize:fit:875/0*93VRPJUwaJ0HubI)

![](https://miro.medium.com/v2/resize:fit:875/0*Ir7-oS-Lh2nmf3n1)

![](https://miro.medium.com/v2/resize:fit:835/0*nTx57gmZXmXakWN)

In a traditional software development, code, build, test, release and monitoring are siloed functions. Each stage works independently and hands over to the next stage.

DevOps, on the other hand, encourages continuous development and collaboration between developers and operations. This shortens the overall life cycle and provides continuous software delivery.

NoOps is a newer concept with the development of serverless computing. Since we can architect the system using FaaS (Function-as-a-Service) and BaaS (Backend-as-a-Service), the cloud service providers can take care of most operations tasks. The developers can focus on feature development and automate operations tasks.

NoOps is a pragmatic and effective methodology for startups or smaller-scale applications, which moves shortens the SDLC even more than DevOps.

> **Https Working**

![](https://miro.medium.com/v2/resize:fit:875/0*kuHsS37HAJe93Xyd)

> **API Gateway**

![](https://miro.medium.com/v2/resize:fit:875/0*uvHqBSFDAG1Omizx)

> **Microservices**

![](https://miro.medium.com/v2/resize:fit:1095/0*18mZRfMonA3bl-mC)

![](https://miro.medium.com/v2/resize:fit:1163/0*ARDJdTB2fsTXD9Dt)

![](https://miro.medium.com/v2/resize:fit:875/0*6WpyLztRNCdcXKi4)

> **URL vs URI vs URN**

![](https://miro.medium.com/v2/resize:fit:875/0*QwvKM5NL3HyRzG8X)

![](https://miro.medium.com/v2/resize:fit:875/0*vi8c06oXlIUseOcv)

> **Design Patterns**

![](https://miro.medium.com/v2/resize:fit:875/0*JeuFVA2LUmb07gi)

> **Logging and Tracing**

![](https://miro.medium.com/v2/resize:fit:875/0*7fX2JVSQffe9UIhw)

> **Routing policies**

![](https://miro.medium.com/v2/resize:fit:870/0*u7gla6QY-lzl-j11)

> **Load Balancing**

![](https://miro.medium.com/v2/resize:fit:875/0*-E8UMVChZczMOn17)

**Static Algorithms**

**Round robin**  
The client requests are sent to different service instances in sequential order. The services are usually required to be stateless.  
**Sticky round-robin**  
This is an improvement of the round-robin algorithm. If Alice’s first request goes to service A, the following requests go to service A as well.  
**Weighted round-robin**  
The admin can specify the weight for each service. The ones with a higher weight handle more requests than others.

**Hash**  
This algorithm applies a hash function on the incoming requests’ IP or URL. The requests are routed to relevant instances based on the hash function result.

**Dynamic Algorithms**

**Least connections**  
A new request is sent to the service instance with the least concurrent connections.  
**Least response time**  
A new request is sent to the service instance with the fastest response time.

> E**ncryption**

![](https://miro.medium.com/v2/resize:fit:875/0*tDSPVJJJKJ-zXGpq)

> M**essage Queue**

![](https://miro.medium.com/v2/resize:fit:1268/0*dPMc-vAgk8rki5RD)

![](https://miro.medium.com/v2/resize:fit:903/0*LuBucpmoHUt9T3ok)

![](https://miro.medium.com/v2/resize:fit:875/0*Xg52Ol5Xk9tKYtmd)

> **Object Storage**

![](https://miro.medium.com/v2/resize:fit:875/0*k8Bky3hcvlVkfrYr)

> **API vs SDK**

![](https://miro.medium.com/v2/resize:fit:875/0*iZ0aB4-9vruD4RJS)

> **Forward vs Reverse Proxy**

![](https://miro.medium.com/v2/resize:fit:875/0*CoGG7vkd--Kz3wtK)

> **Caching**

![](https://miro.medium.com/v2/resize:fit:943/0*2UhvKqGm5wfQHeNc)

![](https://miro.medium.com/v2/resize:fit:1093/0*14k4gIufDXsCWjv-)

> **Cloud Native**

![](https://miro.medium.com/v2/resize:fit:1205/0*ompgM99IO8m3gbIA)

![](https://miro.medium.com/v2/resize:fit:998/0*CRC5WORScQbzUViD)

![](https://miro.medium.com/v2/resize:fit:875/0*Do9d4d2RedbhiFrn)

> **Event Sourcing**

![](https://miro.medium.com/v2/resize:fit:843/0*jXyTl5CCLWU-TM59)

> **Firewall**

![](https://miro.medium.com/v2/resize:fit:875/0*PG11ShRjRd-taRvA)

> **Distributed system**

![](https://miro.medium.com/v2/resize:fit:875/0*cz0SBJcn4KQd7IB)

> **Batch vs Stream Processing**

![](https://miro.medium.com/v2/resize:fit:875/0*bFNDRsuDeuzM6OR1)

> **CDN — Content Delivery Network**

![](https://miro.medium.com/v2/resize:fit:875/0*cQfhYMh-MoZI9osb)

-   Thank you for reading this article. Please provide your valuable suggestions/ feedback. If you want, you can further read [**System Design Interview — An insider’s guide by Alex Xu**](https://amzn.to/3nU2Mbp) **or** [**join ByteByteGo**](https://bit.ly/3P3eqMN)
-   Clap and Share if you liked the content.
-   📰 Read more content on my [Medium](/@veenaraofr) (on Java Developer interview questions)
-   🔔 Follow me on : [LinkedIn](https://www.linkedin.com/in/veena-rao-57410a69/)

Please find my other useful articles on Java Developer interview questions

[**System design Top Interview Questions — Part1**](/javarevisited/system-design-top-interview-questions-part1-4b972e8c28e7)

[**Following are some of the famously asked Java8 Interview Questions**](/@veenaraofr/java8-interview-questions-1be1668b74e3)

[**Frequently asked Java Programs**](/@veenaraofr/frequently-asked-java-programs-2e807a689d07)

[**Dear Readers, these are the commonly asked java programs to check your ability on writing the logic**](/@veenaraofr/frequently-asked-java-programs-2e807a689d07)

[**SpringBoot Interview Questions | Medium**](/@veenaraofr/springboot-interview-questions-1b5dba537fb3)

[**Rest and Microservices Interview Questions| Medium**](/@veenaraofr/rest-and-microservices-interview-questions-10b420ac07ef)

**References:**

[https://blog.bytebytego.com/p/free-system-design-pdf-158-pages](https://blog.bytebytego.com/p/free-system-design-pdf-158-pages)



<iframe height="0" width="0" src="https://www.googletagmanager.com/static/serviceworker/55j0/swiframe.html?origin=https%3A%2F%2Fmedium.com" style="display: none; visibility: hidden;"></iframe>

---
