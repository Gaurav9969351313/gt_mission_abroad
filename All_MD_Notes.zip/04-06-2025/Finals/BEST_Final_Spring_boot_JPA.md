### JPA Entity Lifecycle Callback Annotations

JPA provides callback annotations that allow you to hook into various stages of an entity’s lifecycle. These annotations mark methods that get executed automatically when certain events occur in the entity’s lifecycle.

### Lifecycle Callback Annotations Overview

Here’s a complete guide with example programs demonstrating each annotation:

### 1. @PrePersist and @PostPersist
```java
@Entity  
public class Customer {  
    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    private Long id;  
    private String name;  
    private LocalDateTime createdAt;  
    private LocalDateTime lastModifiedAt;  
      
    @PrePersist  
    public void prePersist() {  
        System.out.println("PrePersist callback - before inserting new entity");  
        this.createdAt = LocalDateTime.now();  
        this.lastModifiedAt = LocalDateTime.now();  
    }  
      
    @PostPersist  
    public void postPersist() {  
        System.out.println("PostPersist callback - after inserting new entity. ID: " + id);  
        // Could send notification or log audit trail  
    }  
      
    // getters and setters  
}
```va
Usage:
```java
Customer customer = new Customer();  
customer.setName("John Doe");  
entityManager.persist(customer); // Triggers @PrePersist and @PostPersist
```
### 2. @PreUpdate and @PostUpdate
```java
@Entity  
public class Product {  
    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    private Long id;  
    private String name;  
    private BigDecimal price;  
    private LocalDateTime lastUpdated;  
      
    @PreUpdate  
    public void preUpdate() {  
        System.out.println("PreUpdate callback - before updating entity");  
        this.lastUpdated = LocalDateTime.now();  
    }  
      
    @PostUpdate  
    public void postUpdate() {  
        System.out.println("PostUpdate callback - after updating entity");  
        // Could send update notification  
    }  
      
    // getters and setters  
}
```
Usage:
```java
Product product = entityManager.find(Product.class, 1L);  
product.setPrice(new BigDecimal("29.99"));  
entityManager.merge(product); // Triggers @PreUpdate and @PostUpdate
```
### 3. @PreRemove and @PostRemove
```java
@Entity  
public class Order {  
    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    private Long id;  
    private String orderNumber;  
      
    @PreRemove  
    public void preRemove() {  
        System.out.println("PreRemove callback - before deleting order: " + orderNumber);  
        // Could archive or log before deletion  
    }  
      
    @PostRemove  
    public void postRemove() {  
        System.out.println("PostRemove callback - order deleted");  
        // Could send deletion notification  
    }  
      
    // getters and setters  
}
```

Usage:
```java
Order order = entityManager.find(Order.class, 1L);  
entityManager.remove(order); // Triggers @PreRemove and @PostRemove
```
### 4. @PostLoad
```java
@Entity  
public class Employee {  
    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    private Long id;  
    private String firstName;  
    private String lastName;  
      
    @Transient // Not persisted  
    private String fullName;  
      
    @PostLoad  
    public void postLoad() {  
        System.out.println("PostLoad callback - after loading entity");  
        this.fullName = firstName + " " + lastName;  
    }  
      
    // getters and setters  
}
```
Usage:
```java
Employee employee = entityManager.find(Employee.class, 1L);  
// fullName will be available after loading  
System.out.println(employee.getFullName()); // Prints "John Doe" if firstName=John, lastName=Doe
```

### Using Separate Listener Classes

You can also define these callbacks in separate listener classes:
```java
@Entity  
@EntityListeners(AuditListener.class)  
public class Account {  
    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    private Long id;  
    private String accountNumber;  
    private LocalDateTime createdAt;  
    private LocalDateTime updatedAt;  
      
    // getters and setters  
}  
  
public class AuditListener {  
    @PrePersist  
    public void prePersist(Object entity) {  
        if (entity instanceof Account) {  
            Account account = (Account) entity;  
            account.setCreatedAt(LocalDateTime.now());  
            account.setUpdatedAt(LocalDateTime.now());  
        }  
    }  
      
    @PreUpdate  
    public void preUpdate(Object entity) {  
        if (entity instanceof Account) {  
            Account account = (Account) entity;  
            account.setUpdatedAt(LocalDateTime.now());  
        }  
    }  
}
```
### Important Notes

1.  Callback methods should have void return type and no parameters (except for listener classes which can take Object)
2.  Methods can have any visibility (public, protected, private)
3.  Methods can’t be static or final
4.  For @PostLoad, the method is invoked after loading and also after refresh operations
5.  Callbacks are invoked in the same transaction context as the entity operation

These lifecycle callbacks are powerful tools for implementing cross-cutting concerns like auditing, logging, validation, and maintaining derived fields.

---
# How to Spring Data JPA Implement Auditing 

Auditing is essential for tracking **who** created or modified an entity and **when** it happened. Spring Data JPA provides built-in auditing support via annotations, making it easy to maintain audit logs without manual effort.

### 1. Core Auditing Annotations in Spring Data JPA

![](https://miro.medium.com/v2/resize:fit:875/1*HmHd84VEUrMsasoKDLO0fw.png)

### 2. Step-by-Step Implementation

### Step 1: Enable JPA Auditing in Spring Boot

Add `@EnableJpaAuditing` to your configuration class.
```java
import org.springframework.context.annotation.Bean;  
import org.springframework.context.annotation.Configuration;  
import org.springframework.data.domain.AuditorAware;  
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;  
import java.util.Optional;  
  
@Configuration  
@EnableJpaAuditing(auditorAwareRef = "auditorProvider") // Enables JPA Auditing  
public class JpaAuditingConfig {  
  
    @Bean  
    public AuditorAware<String> auditorProvider() {  
        // This fetches the current logged-in user (Spring Security)  
        return () -> Optional.ofNullable(  
            SecurityContextHolder.getContext()  
                .getAuthentication()  
                .getName()  
        );  
    }  
}
```
### Step 2: Create a Base Auditable Entity

Instead of repeating auditing fields in every entity, create an abstract base class.
```java
import jakarta.persistence.*;  
import lombok.Getter;  
import lombok.Setter;  
import org.springframework.data.annotation.*;  
import org.springframework.data.jpa.domain.support.AuditingEntityListener;  
import java.time.LocalDateTime;  
  
@MappedSuperclass  
@EntityListeners(AuditingEntityListener.class) // Required for auto-population  
@Getter @Setter  
public abstract class Auditable {  
  
    @CreatedDate  
    @Column(name = "createdat", updatable = false)  
    private LocalDateTime createdAt;  
  
    @LastModifiedDate  
    @Column(name = "updatedat")  
    private LocalDateTime updatedAt;  
  
    @CreatedBy  
    @Column(name = "createdby", updatable = false)  
    private String createdBy;  
  
    @LastModifiedBy  
    @Column(name = "updatedby")  
    private String updatedBy;  
}
```

### Step 3: Extend Auditable in Your Entity

Now, any entity can inherit auditing fields.
```java
import jakarta.persistence.*;  
import lombok.*;  
  
@Entity  
@Getter @Setter  
@NoArgsConstructor  
public class Product extends Auditable { // Inherits auditing fields  
  
    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    private Long id;  
  
    private String name;  
    private Double price;  
}
```
### Step 4: Test Auditing in a Service

When saving an entity, auditing fields are auto-filled.
```java
@Service  
@RequiredArgsConstructor  
public class ProductService {  
  
    private final ProductRepository productRepo;  
  
    public Product createProduct(String name, Double price) {  
        Product product = new Product();  
        product.setName(name);  
        product.setPrice(price);  
        return productRepo.save(product); // Auto-sets createdAt, createdBy, etc.  
    }  
}
```

### 3. How Each Annotation Works (Deep Dive)

### 1. `@CreatedDate`

-   **Trigger:** Only set when the entity is **first saved**.
-   **Best Practice:** Mark as `updatable = false` to prevent modifications.
-   **Database Column:** `TIMESTAMP` or `DATETIME`.

### 2. `@LastModifiedDate`

-   **Trigger:** Updates **every time** the entity is modified.
-   **Use Case:** Useful for tracking last activity.
-   **Example:** `updatedat` in orders, user profiles.

### 3. `@CreatedBy` & `@LastModifiedBy

-   **Requirement:** Requires an `AuditorAware` bean to fetch the current user.
-   **Spring Security Integration:**
```java
@Bean  
public AuditorAware<String> auditorProvider() {  
    return () -> Optional.ofNullable(  
        SecurityContextHolder.getContext()  
            .getAuthentication()  
            .getName()  
    );  
}
```
-   **Custom User Resolution:**
```java
// If using a custom User entity  
@Bean  
public AuditorAware<User> auditorProvider() {  
    return () -> Optional.ofNullable(  
        SecurityContextHolder.getContext()  
            .getAuthentication()  
            .getPrincipal()  
    ).map(principal -> (User) principal);  
}
```

### 4. Advanced Auditing Scenarios

### A. Custom Date Format (e.g., `Instant` instead of `LocalDateTime`)
```java
@CreatedDate  
private Instant createdAt; // Stored as UTC timestamp  
  
@LastModifiedDate  
private Instant updatedAt;
```
### B. Auditing Without Spring Security

If not using Spring Security, manually set the auditor:
```java
@Bean  
public AuditorAware<String> auditorProvider() {  
    return () -> Optional.of("system"); // Default auditor  
}
```

### C. Disable Auditing for Specific Fields
```java
@Transient // Excludes from persistence  
private String temporaryField;
```
### D. Auditing in MongoDB (Spring Data MongoDB)

Same annotations work with `@Document` instead of `@Entity`.

### 5. Common Issues & Fixes

![](https://miro.medium.com/v2/resize:fit:794/1*skunApOyL0ccaje-E42dQ.png)

### 6. Best Practices for Production

✅ **Use** `**@MappedSuperclass**` – Avoid repeating fields.  
✅ **Immutable** `**@CreatedDate**` – Set `updatable = false`.  
✅ **Leverage** `**java.time**` – Prefer `LocalDateTime`/`Instant` over `java.util.Date`.  
✅ **Test AuditorAware** – Ensure it works with mocked users.  
✅ **Index Audit Columns** – Improve query performance on `createdat`, `updatedat`.

### Final Thoughts

Spring Data JPA auditing simplifies tracking entity changes with minimal code. By using `@CreatedDate`, `@LastModifiedDate`, `@CreatedBy`, and `@LastModifiedBy`, you can automatically log who did what and when—crucial for compliance, debugging, and analytics.

---
# Optimize Spring Data JPA: Fix These 4 Performance Anti-Patterns 

> **🎉** Article Published: 215
> 
> if you are not a medium member then [Click here](/@gaddamnaveen192/optimize-spring-data-jpa-fix-these-4-performance-anti-patterns-4a072624f2fd?sk=8fded7ce4233d440d513b8070595e972) to read free

### 1. Ignoring Transactions in Write Operations

-   Anti-pattern: Performing `save()`, `delete()`, or `update` operations without `@Transactional`.
-   Issue: Leads to inconsistent data and unintended side effects.
-   Fix: Always use `@Transactional` for write operations

### Understanding the Anti-pattern

When you perform database write operations (save, update, delete) without proper transaction management, you risk data inconsistency and partial updates that can corrupt your database state.

### Why Transactions Matter

Transactions provide ACID properties:

-   Atomicity: All operations succeed or fail together
-   Consistency: Database moves from one valid state to another
-   Isolation: Concurrent transactions don’t interfere
-   Durability: Committed changes survive system failures

### Bad Example: No Transaction
```java
@Service  
public class BankAccountService {  
      
    private final BankAccountRepository accountRepository;  
      
    public BankAccountService(BankAccountRepository accountRepository) {  
        this.accountRepository = accountRepository;  
    }  
      
    public void transferMoney(Long fromAccountId, Long toAccountId, BigDecimal amount) {  
        // Fetch accounts  
        BankAccount fromAccount = accountRepository.findById(fromAccountId)  
            .orElseThrow(() -> new AccountNotFoundException(fromAccountId));  
        BankAccount toAccount = accountRepository.findById(toAccountId)  
            .orElseThrow(() -> new AccountNotFoundException(toAccountId));  
          
        // Withdraw from source  
        fromAccount.withdraw(amount);  
        accountRepository.save(fromAccount);  
          
        // Simulate failure after first save but before second  
        if (amount.compareTo(new BigDecimal("1000")) > 0) {  
            throw new RuntimeException("Simulated system failure!");  
        }  
          
        // Deposit to target  
        toAccount.deposit(amount);  
        accountRepository.save(toAccount);  
    }  
}
```

### Problems with this approach:

1.  Partial updates: If the system fails after withdrawing but before depositing, money disappears
2.  Inconsistent state: The database is left in an invalid state
3.  No rollback: The withdrawal isn’t undone when the exception occurs
4.  Concurrency issues: Other transactions might see intermediate states

### Good Example: Proper Transaction Usage
```java
@Service  
public class BankAccountService {  
      
    private final BankAccountRepository accountRepository;  
      
    public BankAccountService(BankAccountRepository accountRepository) {  
        this.accountRepository = accountRepository;  
    }  
      
    @Transactional  
    public void transferMoney(Long fromAccountId, Long toAccountId, BigDecimal amount) {  
        // Fetch accounts with pessimistic lock to prevent concurrent modifications  
        BankAccount fromAccount = accountRepository.findByIdWithLock(fromAccountId)  
            .orElseThrow(() -> new AccountNotFoundException(fromAccountId));  
        BankAccount toAccount = accountRepository.findByIdWithLock(toAccountId)  
            .orElseThrow(() -> new AccountNotFoundException(toAccountId));  
          
        // Perform transfer  
        fromAccount.withdraw(amount);  
        toAccount.deposit(amount);  
          
        // Save both accounts  
        accountRepository.save(fromAccount);  
        accountRepository.save(toAccount);  
          
        // Even if failure occurs here, changes will be rolled back  
        if (amount.compareTo(new BigDecimal("1000")) > 0) {  
            throw new RuntimeException("Simulated system failure - but it's OK now!");  
        }  
    }  
}
```

### Key Improvements:

1.  Atomic operation: Both updates succeed or fail together
2.  Automatic rollback: If an exception occurs, all changes are undone
3.  Consistent state: Database never shows money being “in flight”
4.  Isolation: Proper locking prevents concurrent modifications

### Advanced Considerations

### Transaction Propagation
```java
@Transactional(propagation = Propagation.REQUIRED) // Default  
public void serviceMethod() {  
    // Joins existing transaction or creates new one  
}  
  
@Transactional(propagation = Propagation.REQUIRESNEW)  
public void auditLogOperation() {  
    // Always creates new transaction regardless of existing one  
    // Useful for audit logs that should persist even if main transaction fails  
}

@Transactional(propagation = Propagation.REQUIRED) // Default  
public void serviceMethod() {  
    // Joins existing transaction or creates new one  
}  
  
@Transactional(propagation = Propagation.REQUIRESNEW)  
public void auditLogOperation() {  
    // Always creates new transaction regardless of existing one  
    // Useful for audit logs that should persist even if main transaction fails  
}
```
### solation Levels
```java
@Transactional(isolation = Isolation.SERIALIZABLE) // Most strict  
public void highConsistencyOperation() {  
    // Prevents all concurrency anomalies but reduces performance  
}  
  
@Transactional(isolation = Isolation.READCOMMITTED) // Common default  
public void balanceOperation() {  
    // Good balance between consistency and performance  
}
```
### Timeouts and Read-only
```java
@Transactional(timeout = 5) // Seconds  
public void timeSensitiveOperation() {  
    // Fails if not completed in 5 seconds  
}  
  
@Transactional(readOnly = true)  
public BigDecimal calculateTotalBalance() {  
    // Optimized for read operations  
    // Throws exception if attempting writes  
}
```

### Real-world Impact

A financial services company I worked with had a bug where account balance updates sometimes “lost” money during transfers. They were using Hibernate without proper `@Transactional` annotations. After adding proper transaction management:

1.  Customer complaints about missing money dropped to zero
2.  Audit logs showed complete transaction histories
3.  System became more resilient to failures during peak loads

### Best Practices

1.  Always use `@Transactional` for write operations
2.  Be explicit about propagation and isolation when needed
3.  Keep transactions as short as possible (avoid business logic in transactions)
4.  Consider optimistic/pessimistic locking for high-contention data
5.  Test transaction behavior (especially rollback scenarios)

### 2. Overusing `@Query` for Simple Queries

-   Anti-pattern: Writing custom JPQL or native queries for operations that could use built-in methods (`findBy...`).
-   Issue: Unnecessary complexity and maintenance overhead.
-   Fix: Leverage derived query methods when possible.

### Deep Dive: Overusing @Query for Simple Queries

### Understanding the Anti-pattern

Many developers unnecessarily write custom `@Query` annotations for operations that could be easily expressed using Spring Data's derived query methods. This creates several problems:

1.  Increased complexity: Custom queries are harder to read and maintain
2.  Reduced portability: Native SQL queries tie you to a specific database
3.  More boilerplate: Requires writing and maintaining more code
4.  Less type safety: Query strings aren’t checked at compile time

### Bad Example: Unnecessary @Query
```java
public interface UserRepository extends JpaRepository<User, Long> {  
  
    // Unnecessarily complex query for a simple filter  
    @Query("SELECT u FROM User u WHERE u.email = ?1")  
    Optional<User> findByEmail(String email);  
  
    // Overly verbose query for a simple exists check  
    @Query("SELECT COUNT(u) > 0 FROM User u WHERE u.username = ?1")  
    boolean existsByUsername(String username);  
  
    // Native SQL when JPQL would suffice  
    @Query(value = "SELECT * FROM users WHERE active = true", nativeQuery = true)  
    List<User> findAllActiveUsers();  
}
```
### Problems with this approach:

1.  Verbose syntax: Simple operations become complex
2.  Maintenance burden: Changes require modifying query strings
3.  Error-prone: Query strings can have typos only caught at runtime
4.  Limited IDE support: No code completion for query strings

### Good Example: Leveraging Derived Queries
```java
public interface UserRepository extends JpaRepository<User, Long> {  
  
    // Simple derived query  
    Optional<User> findByEmail(String email);  
  
    // Built-in exists check  
    boolean existsByUsername(String username);  
  
    // Derived query with condition  
    List<User> findByActiveTrue();  
  
    // More complex derived queries are possible  
    List<User> findByDepartmentNameAndHireDateAfter(String departmentName, LocalDate hireDate);  
  
    // Pagination support out of the box  
    Page<User> findByLastName(String lastName, Pageable pageable);  
}
```

### Key Improvements:

1.  Concise syntax: Methods express intent clearly
2.  Type-safe: Compiler checks method signatures
3.  IDE support: Code completion works perfectly
4.  Consistent style: Follows Spring Data conventions
5.  Less maintenance: No query strings to update

### When to Actually Use @Query

There are valid cases for `@Query`
```java
public interface OrderRepository extends JpaRepository<Order, Long> {  
  
    // Complex joins that can't be expressed with derived queries  
    @Query("SELECT o FROM Order o JOIN FETCH o.items WHERE o.customer.id = :customerId")  
    List<Order> findOrdersWithItemsByCustomer(@Param("customerId") Long customerId);  
  
    // Update queries that modify data  
    @Modifying  
    @Query("UPDATE Order o SET o.status = :status WHERE o.id = :orderId")  
    void updateOrderStatus(@Param("orderId") Long orderId, @Param("status") OrderStatus status);  
  
    // Aggregation queries  
    @Query("SELECT new com.example.OrderStats(COUNT(o), SUM(o.total)) FROM Order o WHERE o.date BETWEEN :start AND :end")  
    OrderStats getOrderStatsBetweenDates(@Param("start") LocalDate start, @Param("end") LocalDate end);  
}
```

### Advanced Derived Query Features

Spring Data supports surprisingly complex queries through method names:
```java
public interface ProductRepository extends JpaRepository<Product, Long> {  
  
    // Boolean combinations  
    List<Product> findByDiscontinuedFalseAndCategoryInAndPriceBetween(        Collection<Category> categories,   
        BigDecimal minPrice,   
        BigDecimal maxPrice    );  
  
    // Nested properties  
    List<Product> findByManufacturerAddressCountry(String country);  
  
    // Sorting options  
    List<Product> findTop10ByOrderBySalesVolumeDesc();  
  
    // Null checks  
    List<Product> findByDescriptionNotNull();  
  
    // String operations  
    List<Product> findByNameContainingIgnoreCase(String namePart);  
}
```

### Performance Considerations

While derived queries are convenient, be aware of:

1.  N+1 problem: Derived queries with relationships might trigger multiple queries

// This might execute N+1 queries if not careful  
List<Order> findByCustomerId(Long customerId);

1.  Solution: Use entity graphs or `@Query` with JOIN FETCH
2.  Complex queries: Very long method names can become unwieldy

-   At some point, `@Query` becomes more readable

1.  Database-specific features: Some optimizations require native queries

### Real-world Impact

An e-commerce platform reduced their repository code by 40% by:

1.  Replacing simple `@Query` annotations with derived methods
2.  Keeping complex queries only where necessary
3.  Standardizing on derived query patterns

Results:

-   Improved onboarding for new developers
-   Fewer query-related bugs
-   Easier refactoring (method renames vs query string updates)

### Best Practices

1.  Prefer derived queries for simple CRUD operations
2.  Use @Query for:

-   Complex joins
-   Update/delete operations
-   Database-specific features
-   Performance-critical operations

1.  Keep method names readable — if they get too long, consider @Query
2.  Combine approaches when needed
```java
// Derived query for basic filtering  
Page<User> findByDepartment(String department, Pageable pageable);  
  
// Custom query for complex case  
@Query("SELECT u FROM User u JOIN u.roles r WHERE u.department = :dept AND r.level > :minLevel")  
Page<User> findSeniorStaffInDepartment(@Param("dept") String department,   
                                     @Param("minLevel") int minLevel,  
                                     Pageable pageable);
```
### 3. Fetching Entire Entities When Only Projections Are Needed

-   Anti-pattern: Retrieving full entities (`SELECT *`) when only a few fields are required.
-   Issue: Wastes memory and database resources.
-   Fix: Use DTO projections (`interface`-based or `class`-based projections)

### Deep Dive: Fetching Entire Entities When Only Projections Are Needed

### Understanding the Anti-pattern

A common performance anti-pattern is retrieving complete entity objects with all their fields when the business logic only needs a subset of the data. This happens most frequently with JPA/Hibernate applications where developers automatically use entity repositories without considering the actual data requirements.

### Why This Is Problematic:

1.  Memory waste: Loading all fields consumes more heap space
2.  Database overhead: Transferring unnecessary columns wastes bandwidth
3.  Performance impact: Larger result sets take longer to transfer and process
4.  Potential lazy loading: Unneeded relationships might trigger additional queries

### Bad Example: Fetching Full Entities
```java
@Service  
public class ReportService {  
      
    private final UserRepository userRepository;  
      
    public ReportService(UserRepository userRepository) {  
        this.userRepository = userRepository;  
    }  
      
    public List<UserEmailReport> generateEmailReport() {  
        // Fetches ALL user fields when we only need email and name  
        List<User> users = userRepository.findAll();  
          
        return users.stream()  
            .map(user -> new UserEmailReport(  
                user.getEmail(),  
                user.getFirstName() + " " + user.getLastName()  
            ))  
            .collect(Collectors.toList());  
    }  
}  
  
@Entity  
public class User {  
    @Id  
    private Long id;  
    private String email;  
    private String firstName;  
    private String lastName;  
    private String encryptedPassword;  
    private String address;  
    private String phoneNumber;  
    // ... 20 more fields  
}
```

### Problems with this approach:

1.  Transfers all 25+ User fields from database
2.  Wastes memory storing unused fields in Java heap
3.  May initialize lazy-loaded relationships unnecessarily
4.  Slower query execution due to larger data transfer

### 4. N+1 Query Problem with Lazy Loading

-   Anti-pattern: Fetching entities with lazy-loaded relationships without `JOIN FETCH` or `@EntityGraph`.
-   Issue: Causes multiple queries, degrading performance.
-   Fix: Use `@EntityGraph` or `JOIN FETCH` in `@Query`

### Deep Dive: N+1 Query Problem with Lazy Loading

### Understanding the Anti-pattern

The N+1 query problem occurs when an application makes one query to retrieve the primary entities (1), and then N additional queries to fetch related entities for each result (N). This is a common performance pitfall in ORM frameworks like Hibernate when lazy loading is used without proper fetching strategies.

### Why This Is Problematic:

1.  Performance killer: Executes many small queries instead of one optimized query
2.  Network overhead: Each query requires round-trip to database
3.  Scaling issues: Problem magnifies with larger datasets
4.  Hidden problem: Often not apparent during development with small test data

### Bad Example: Triggering N+1 Queries
```java
@Entity  
public class Order {  
    @Id  
    private Long id;  
      
    @OneToMany(mappedBy = "order", fetch = FetchType.LAZY)  
    private List<OrderItem> items;  
      
    // other fields  
}  
  
@Service  
public class OrderReportService {  
      
    private final OrderRepository orderRepository;  
      
    public OrderReportService(OrderRepository orderRepository) {  
        this.orderRepository = orderRepository;  
    }  
      
    public void generateOrderReport() {  
        // 1 query to get all orders  
        List<Order> orders = orderRepository.findAll();  
          
        // N queries to get items for each order  
        for (Order order : orders) {  
            processOrder(order.getId(), order.getItems().size()); // Triggers lazy load  
        }  
    }  
}
```
### What Happens in Database:

1.  `SELECT * FROM order` (1 query)
2.  For each order: `SELECT * FROM orderitem WHERE orderid = ?` (N queries)

For 100 orders, this executes 101 queries instead of 1!

### Solution Strategies

### 1. Using @EntityGraph
```java
public interface OrderRepository extends JpaRepository<Order, Long> {  
      
    @EntityGraph(attributePaths = {"items"})  
    List<Order> findAllWithItems();  
}  
  
// Usage - fetches orders and items in single query  
List<Order> orders = orderRepository.findAllWithItems();
```
### 2. JOIN FETCH in @Query
```java
public interface OrderRepository extends JpaRepository<Order, Long> {  
      
    @Query("SELECT o FROM Order o JOIN FETCH o.items")  
    List<Order> findAllWithItems();  
}
```
### 3. Dynamic Entity Graphs
```java
public interface OrderRepository extends JpaRepository<Order, Long> {  
      
    @EntityGraph(attributePaths = {"items", "customer"})  
    List<Order> findByStatus(OrderStatus status);  
      
    @EntityGraph(attributePaths = {"items"})  
    List<Order> findByCustomerId(Long customerId);  
}
```
### Advanced Solutions

### Multiple Level Fetching
```java
// Fetch order -> items -> product in one query  
@EntityGraph(attributePaths = {"items.product"})  
List<Order> findAllWithItemsAndProducts();
```
### Pagination with Fetching
```java
@EntityGraph(attributePaths = {"items"})  
Page<Order> findByCustomerId(Long customerId, Pageable pageable);
```
### Conditional Fetching
```java
public interface OrderRepository extends JpaRepository<Order, Long> {  
      
    @Query("SELECT o FROM Order o " +  
           "LEFT JOIN FETCH o.items i " +  
           "WHERE (:includeItems = false OR i IS NOT NULL)")  
    List<Order> findOrders(@Param("includeItems") boolean includeItems);  
}
```

### When to Use Different Approaches

1.  @EntityGraph: Best for simple relationship fetching
2.  JOIN FETCH: More control over join conditions
3.  @BatchSize: Good for multiple levels of relationships
```java
@OneToMany(mappedBy = "order", fetch = FetchType.LAZY)  
@BatchSize(size = 20)  
private List<OrderItem> items;
```
### Real-world Impact

An e-commerce platform fixed their order history page that was taking 8+ seconds to load:

1.  Identified N+1 problem (1 order query + 10 item queries per order)
2.  Implemented `JOIN FETCH` with pagination
3.  Reduced queries from 101 to 1 for typical page
4.  Improved load time to under 800ms

### Best Practices

1.  Always check SQL logs for unexpected queries
2.  Use @EntityGraph by default for common relationships
3.  Consider DTO projections when you don’t need full entities
4.  Test with production-like data volumes
5.  Beware of cartesian products with multiple joins
6.  Use pagination with fetched relationships
```java
// Good practice example combining several techniques  
@EntityGraph(attributePaths = {"items.product"})  
Page<OrderSummaryProjection> findByCustomerId(Long customerId, Pageable pageable);
```
---
# Boost Performance in Spring Data JPA with Query Hints
### 👋 Hey developers,

If you’ve ever worked on a Spring Boot project using JPA and thought:

> “My queries work fine — but could they be faster?”

The answer is probably yes.

> You might be missing out on **Query Hints** — a powerful but underused feature in Spring Data JPA that lets you **fine-tune performance, caching, and execution behavior**.

### What Are Query Hints?

Query hints are optional instructions you give to the JPA provider (typically Hibernate) to **change how a query is executed**.

They don’t change what data is retrieved — only how it is retrieved or processed.

Think of them as query-level optimizations that tell Hibernate things like:

-   “Don’t track changes — I won’t modify this data.”
-   “Load this into cache — I’ll probably need it again.”
-   “Stop this query if it runs too long.”
-   “Use a fetch plan I’ve defined to avoid lazy loading surprises.”

These small adjustments can lead to major improvements in performance, memory usage, and reliability.

Spring Data JPA supports this through the `@QueryHints` annotation. By using `@QueryHints` you can reduce response times and lower database load, ensuring faster and more responsive application performance.

### Why Use Query Hints?

Let’s say you have a read-heavy API that returns product listings. These products rarely change, and each response sends hundreds of records.

Without tuning, Hibernate:

-   Loads the full entity
-   Tracks every field for changes
-   May hit the database repeatedly due to lazy loading
-   Fails to reuse data if second-level cache is disabled

Now imagine if:

-   You marked the query as read-only ✅
-   You hinted Hibernate to cache the result ✅
-   You configured a fetch size for efficient JDBC paging ✅

Suddenly, you’ve shaved hundreds of milliseconds off your API — and the best part? **You didn’t rewrite a single SQL query.**

### Commonly Used Query Hints in Spring Data JPA

Here are the most useful hints you can use today:

![](https://miro.medium.com/v2/resize:fit:875/1*CvvyM10sD81uX94Y505Jg.png)

Let’s use all of these in a real-world example.

### Full Real-World Example: Optimizing Product Catalog API

### Scenario:

You’re building a product API (`/api/products/category/{category}`) that:

-   Returns 1000s of product records
-   Doesn’t modify the returned data
-   Should benefit from caching
-   Must return in under 2 seconds

### Step 1: Project Setup

In your Maven `pom.xml`:
```xml
<dependencies>  
    <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-data-jpa</artifactId>  
    </dependency>  
    <dependency>  
        <groupId>com.h2database</groupId>  
        <artifactId>h2</artifactId>  
        <scope>runtime</scope>  
    </dependency>  
</dependencies>
```
### Step 2: Define Your Entity
```java
@Entity  
@Table(name = "products")  
@Cacheable // Enables JPA second-level caching  
public class Product {  
  
    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    private Long id;  
  
    private String name;  
    private String category;  
    private double price;  
    private boolean available;  
  
    // Getters & Setters  
}
```

Use `@Cacheable` to indicate that this entity is eligible for second-level caching.

### Step 3: Repository with Full Query Hints
```java
@Repository  
public interface ProductRepository extends JpaRepository<Product, Long> {  
  
    @Query("SELECT p FROM Product p WHERE p.category = :category AND p.available = true")  
    @QueryHints({  
        @QueryHint(name = "org.hibernate.readOnly", value = "true"),  
        @QueryHint(name = "org.hibernate.fetchSize", value = "50"),  
        @QueryHint(name = "org.hibernate.cacheable", value = "true"),  
        @QueryHint(name = "jakarta.persistence.cache.retrieveMode", value = "USE"),  
        @QueryHint(name = "jakarta.persistence.cache.storeMode", value = "USE"),  
        @QueryHint(name = "jakarta.persistence.query.timeout", value = "2000")  
    })  
    List<Product> findOptimizedByCategory(@Param("category") String category);  
}
```

### 🔍 Explanation:

-   `readOnly=true`: Hibernate skips dirty-checking, improving memory usage.
-   `fetchSize=50`: Suggests fetching 50 rows at a time for large datasets.
-   `cacheable=true`: Enables 2nd-level cache for repeated queries.
-   `retrieveMode=USE`, `storeMode=USE`: Controls cache behavior.
-   `timeout=2000`: Cancels queries that run beyond 2 seconds.

### Step 4: Enable Second-Level Caching (H2 Example)

Add to `application.properties`:
```shell
spring.jpa.properties.hibernate.cache.usesecondlevelcache=true  
spring.jpa.properties.hibernate.cache.region.factoryclass=org.hibernate.cache.jcache.JCacheRegionFactory  
spring.jpa.properties.javax.persistence.sharedCache.mode=ENABLESELECTIVE  
spring.datasource.url=jdbc:h2:mem:testdb  
spring.h2.console.enabled=true  
spring.jpa.show-sql=true
```
Use a JCache provider like EhCache in real-world apps.

### Step 5: Service & Controller

### Service:
```java
@Service  
public class ProductService {  
    private final ProductRepository repository;  
  
    public ProductService(ProductRepository repository) {  
        this.repository = repository;  
    }  
  
    public List<Product> getOptimizedProducts(String category) {  
        return repository.findOptimizedByCategory(category);  
    }  
}
```
### Controller:
```java
@RestController  
@RequestMapping("/api/products")  
public class ProductController {  
    private final ProductService service;  
  
    public ProductController(ProductService service) {  
        this.service = service;  
    }  
  
    @GetMapping("/category/{category}")  
    public ResponseEntity<List<Product>> getByCategory(@PathVariable String category) {  
        return ResponseEntity.ok(service.getOptimizedProducts(category));  
    }  
}
```
### Benchmark: Before vs After Query Hints

Let’s say the `/api/products/category/electronics` endpoint returns 3000 products.

![](https://miro.medium.com/v2/resize:fit:875/1*ivz5isqQm0ceuxUU-9otZw.png)

### Combine with DTO Projections

Instead of returning full entities, return only the data you need:

public record ProductSummary(String name, double price) {}  
  ```java
@Query("SELECT new com.example.ProductSummary(p.name, p.price) FROM Product p WHERE p.category = :category")  
@QueryHints({  
    @QueryHint(name = "org.hibernate.readOnly", value = "true"),  
    @QueryHint(name = "jakarta.persistence.query.timeout", value = "1000")  
})  
List<ProductSummary> findSummariesByCategory(String category);
```
✅ Reduces serialization cost and speeds up REST APIs.

### Summary

![](https://miro.medium.com/v2/resize:fit:875/1*qCT0oz4QccYj-7b6SPVztw.png)

Query Hints in Spring Data JPA are the secret sauce for:

-   Faster reads
-   Lower memory usage
-   Smarter caching
-   Cleaner API response times

And the best part? You don’t have to touch your SQL or refactor your domain logic.
---
# Spring Boot JPA Read Replica Setup

Creating a read replica for your application isn’t just about adding a secondary database. It involves wiring up the application to route read operations to a replica without touching writes, all while keeping the experience smooth and invisible to the business logic. This kind of setup is great for reducing load on your primary database, improving read performance, and scaling up under traffic without major architectural changes. In Spring Boot, combining JPA with a custom routing data source is one of the cleanest ways to make this work.

I publish free articles like this daily, if you want to support my work and get access to exclusive content and weekly recaps, consider subscribing to my [Substack](https://alexanderobregon.substack.com/).

### Wiring Read Queries to a Replica Using RoutingDataSource

Spring lets you route database operations to different sources depending on what you’re doing. For read-replica setups, the usual idea is to keep all writes pointed at the main database and send read traffic to a replica. This split helps with performance, reduces contention, and offloads reporting or high-frequency reads. You don’t need extra libraries for this, a custom `RoutingDataSource` and some context tracking are enough.

### Setting Up the Primary and Replica Datasources

Start by defining two separate `DataSource` beans. The first one connects to the primary database, which handles all inserts, updates, and deletes. The second one points to a read-only replica. Both use the standard JDBC URL, username, and password properties. You can store the credentials and URLs in your `application.yml` or wherever you usually keep configuration.
```yml
spring:  
  datasource:  
    url: jdbc:postgresql://primary-db:5432/app  
    username: appuser  
    password: secret  
  
replica:  
  datasource:  
    url: jdbc:postgresql://replica-db:5432/app  
    username: appuser  
    password: secret
```
After that’s set, create the individual beans in a configuration class. It’s important to keep these separate and avoid accidentally marking both as `@Primary`.
```java
@Configuration  
public class DataSourceConfig {  
  
    @Bean  
    public DataSource writeDataSource() {  
        return DataSourceBuilder.create()  
                .url("jdbc:postgresql://primary-db:5432/app")  
                .username("appuser")  
                .password("secret")  
                .build();  
    }  
  
    @Bean  
    public DataSource readDataSource() {  
        return DataSourceBuilder.create()  
                .url("jdbc:postgresql://replica-db:5432/app")  
                .username("appuser")  
                .password("secret")  
                .build();  
    }  
}
```
The next step is to combine both of those into a single `DataSource` that Spring uses behind the scenes. You wrap them with a custom router that decides which one to use for each operation. This router acts as the main `DataSource` bean.
```java
@Bean  
@Primary  
public DataSource routingDataSource(  
        @Qualifier("writeDataSource") DataSource writeDataSource,  
        @Qualifier("readDataSource") DataSource readDataSource) {  
  
    Map<Object, Object> dataSources = new HashMap<>();  
    dataSources.put("WRITE", writeDataSource);  
    dataSources.put("READ", readDataSource);  
  
    RoutingDataSource routingDataSource = new RoutingDataSource();  
    routingDataSource.setTargetDataSources(dataSources);  
    routingDataSource.setDefaultTargetDataSource(writeDataSource);  
  
    return routingDataSource;  
}
```
Spring will use this composite `DataSource` as the one true source, and all read and write behavior gets routed from here.

### Creating the Routing Logic

The core idea is to tell the app which database to hit based on whether it’s a read or write operation. That decision happens inside a class that extends `AbstractRoutingDataSource`. Spring calls the `determineCurrentLookupKey` method each time a new connection is needed. You use this hook to read from a context and return either "READ" or "WRITE".

The context holder is just a simple `ThreadLocal`. It stores the current mode for that request and is cleared afterward. This keeps it safe from spilling over between threads.
```java
public class DataSourceContextHolder {  
  
    private static final ThreadLocal<String> context = new ThreadLocal<>();  
  
    public static void setMode(String mode) {  
        context.set(mode);  
    }  
  
    public static String getCurrentMode() {  
        return context.get();  
    }  
  
    public static void clear() {  
        context.remove();  
    }  
}
```
Then you wire that context into your custom router.
```java
public class RoutingDataSource extends AbstractRoutingDataSource {  
  
    @Override  
    protected Object determineCurrentLookupKey() {  
        return DataSourceContextHolder.getCurrentMode();  
    }  
}
```
When Spring tries to get a connection, it runs that method and switches to the right target datasource. If nothing is set, it falls back to the default, which is usually the primary database. This logic is hidden from the rest of the app. You don’t need to rewrite repositories or switch between datasources manually.

### Setting the Mode with AOP

Now that the wiring is ready, you need a way to set the context value at the right time. This is where method-level annotations help. You can create a custom annotation to mark read-only service methods and intercept those with an aspect.

Here’s the annotation:
```java
@Target({ElementType.METHOD})  
@Retention(RetentionPolicy.RUNTIME)  
public @interface ReadOnly {}
```
And here’s the aspect that reads that annotation and switches modes.
```java
@Aspect  
@Component  
public class DataSourceRoutingAspect {  
  
    @Before("@annotation(ReadOnly)")  
    public void markReadOnly() {  
        DataSourceContextHolder.setMode("READ");  
    }  
  
    @Before("@annotation(tx)")  
    public void markTx(Transactional tx) {  
        if (tx.readOnly()) {  
            DataSourceContextHolder.setMode("READ");  
        } else {  
            DataSourceContextHolder.setMode("WRITE");  
        }  
    }  
  
    @After("@annotation(ReadOnly) || @annotation(Transactional)")  
    public void clearContext() {  
        DataSourceContextHolder.clear();  
    }  
}
```
This means that every method marked with `@ReadOnly` routes to the replica. Transactional methods that aren’t read-only route to the write database. You can control the exact point of routing by placing the annotation on the service method that triggers the repository call.

Here’s what a service might look like with both read and write calls:
```java
@Service  
public class ProductService {  
  
    private final ProductRepository repository;  
  
    public ProductService(ProductRepository repository) {  
        this.repository = repository;  
    }  
  
    @ReadOnly  
    public List<Product> getProducts() {  
        return repository.findAll();  
    }  
  
    @Transactional  
    public void createProduct(Product product) {  
        repository.save(product);  
    }  
}
```
Spring processes the annotations before entering the method and routes the connection accordingly. Then it resets the context after the method runs, making the behavior thread-safe and predictable. This gives you automatic read-routing with almost no changes to your repository code. You still write normal JPA queries, and the routing layer figures out the rest behind the scenes.

### Using a Read-Only EntityManager as an Alternative

Not everyone wants to use AOP or dynamic routing for splitting reads and writes. Some teams prefer to work with separate `EntityManager` instances directly. It’s more hands-on, but it gives you full visibility into which database you're touching. You get one manager for write operations that points to the primary database, and another manager for read operations that points to the replica. This method is more explicit, which can be helpful in cases where you want tighter control or don’t need the abstraction.

### Configuring Multiple EntityManagers

Spring Boot defaults to setting up just one `EntityManager`, usually backed by the main datasource. But it doesn’t stop you from creating more. Each one just needs its own `LocalContainerEntityManagerFactoryBean` along with a separate datasource and a unique persistence unit name.

Here’s how that looks with one write manager and one read manager.
```java
@Configuration  
public class EntityManagerConfig {  
  
    @Bean  
    @Primary  
    public LocalContainerEntityManagerFactoryBean writeEntityManager(  
            @Qualifier("writeDataSource") DataSource dataSource,  
            EntityManagerFactoryBuilder builder) {  
  
        return builder  
                .dataSource(dataSource)  
                .packages("com.example.model")  
                .persistenceUnit("write")  
                .build();  
    }  
  
    @Bean  
    public LocalContainerEntityManagerFactoryBean readEntityManager(  
            @Qualifier("readDataSource") DataSource dataSource,  
            EntityManagerFactoryBuilder builder) {  
  
        return builder  
                .dataSource(dataSource)  
                .packages("com.example.model")  
                .persistenceUnit("read")  
                .build();  
    }  
}
```

Every bean here creates a separate JPA context. Both use the same model classes, but each one is backed by a different datasource.

You’ll also want a separate transaction manager for each one. That way, any transaction started with the read manager won’t accidentally escalate to a write.
```java
@Bean  
@Primary  
public PlatformTransactionManager writeTransactionManager(  
        @Qualifier("writeEntityManager") EntityManagerFactory factory) {  
    return new JpaTransactionManager(factory);  
}  
  
@Bean  
public PlatformTransactionManager readTransactionManager(  
        @Qualifier("readEntityManager") EntityManagerFactory factory) {  
    return new JpaTransactionManager(factory);  
}
```
Spring will default to using the write transaction manager unless you explicitly choose the other one. This avoids any chance of accidental writes going to the wrong place.

### Injecting the Right EntityManager

Now that you have two entity managers defined, you can choose which one to inject depending on the method. You do this using the `@PersistenceContext` annotation with the `unitName` property. The value matches the `persistenceUnit` name from earlier.

Here’s what that looks like in practice.
```java
@Service  
public class OrderService {  
  
    @PersistenceContext(unitName = "read")  
    private EntityManager readOnlyEntityManager;  
  
    @PersistenceContext(unitName = "write")  
    private EntityManager writeEntityManager;  
  
    @Transactional(readOnly = true, transactionManager = "readTransactionManager")  
    public List<Order> getAllOrders() {  
        return readOnlyEntityManager  
                .createQuery("SELECT o FROM Order o", Order.class)  
                .getResultList();  
    }  
  
    @Transactional  
    public void saveOrder(Order order) {  
        writeEntityManager.persist(order);  
    }  
}
```

All reads go through the `readOnlyEntityManager`, which hits the replica. Any new order or update goes through the `writeEntityManager`, which connects to the primary.

That works without any context switching or proxies. You just write your queries as usual, and the injected entity manager does the rest. It’s clearer what each method does, and you avoid having to rely on any external annotation or AOP behavior to decide which database gets hit. It’s also worth noting that this setup can be helpful for tests. You can mock each manager separately, which gives you better control over what part of the system is doing reads and what part is doing writes.

### Conclusion

Read replication in Spring Boot with JPA isn’t something you plug in and forget. You’re building logic that reacts to the type of query being run and picks the right database to handle it. With `RoutingDataSource`, you let Spring route read and write traffic by tracking the current context through a simple thread-local check. With dual `EntityManager`s, you take that routing into your own hands by picking the right one in your service layer. Either way, the mechanics depend on how and when the application asks for a connection, and what you give it when it does. Everything else flows from that.
---

# 🔒 Spring Boot Optimistic and Pessimistic Locking : A Practical Guide with examples🚀 

Concurrency control is a critical aspect of building robust applications, especially when multiple users or processes access shared data simultaneously. In Spring Boot, two common strategies for managing concurrency are **optimistic locking** and **pessimistic locking**. In this article, we’ll explore both approaches, their use cases, and how to implement them in Spring Boot with clear examples. Let’s dive in! 🌟

### 🧠 What is Concurrency Control?

Concurrency control ensures that multiple transactions can execute simultaneously without leading to inconsistent or corrupted data. Imagine two users trying to update the same product’s stock in an e-commerce app at the same time — without proper control, you could end up with incorrect stock levels! 😱

Spring Boot, combined with JPA (Java Persistence API), provides two powerful mechanisms to handle this: **optimistic locking** and **pessimistic locking**. Let’s break them down.

### 🔄 Optimistic Locking: Trust, but Verify ✅

### What is Optimistic Locking?

Optimistic locking assumes that conflicts are rare. Instead of locking the data, it allows multiple transactions to proceed concurrently and checks for conflicts only when saving changes. If a conflict is detected (e.g., someone else modified the data), the transaction fails, and the application handles the conflict.

Think of it like editing a Google Doc: everyone can edit, but if someone else saves changes before you, you’ll need to resolve the conflict before saving. ✍️

### How Does It Work?

Optimistic locking uses a **version** field (or timestamp) in the database to track changes. When an entity is updated, the version is checked to ensure it hasn’t changed since the entity was read. If the versions don’t match, an `OptimisticLockException` is thrown.

### When to Use Optimistic Locking?

-   ✅ High concurrency scenarios where conflicts are unlikely.
-   ✅ Read-heavy applications (e.g., e-commerce product views).
-   ✅ When you want to avoid the overhead of database locks.

### Example: Implementing Optimistic Locking in Spring Boot

Let’s create a simple `Product` entity with optimistic locking.

1.  **Entity Class** 🛠️
```java
import jakarta.persistence.Entity;  
import jakarta.persistence.Id;  
import jakarta.persistence.Version;  
  
@Entity  
public class Product {  
    @Id  
    private Long id;  
    private String name;  
    private int stock;  
    @Version  
    private Long version; // Tracks changes  
    // Getters and setters  
}
```
The `@Version` annotation tells JPA to use this field for optimistic locking.

1.  **Repository** 📚
```java
import org.springframework.data.jpa.repository.JpaRepository;  
  
public interface ProductRepository extends JpaRepository<Product, Long> {  
}
```
1.  **Service Logic** ⚙️
```java
import org.springframework.stereotype.Service;  
import org.springframework.transaction.annotation.Transactional;  
  
@Service  
public class ProductService {  
    private final ProductRepository productRepository;  
    public ProductService(ProductRepository productRepository) {  
        this.productRepository = productRepository;  
    }  
    @Transactional  
    public void updateStock(Long productId, int newStock) {  
        Product product = productRepository.findById(productId)  
                .orElseThrow(() -> new RuntimeException("Product not found"));  
        product.setStock(newStock);  
        productRepository.save(product); // JPA checks version automatically  
    }  
}
```
1.  **What Happens?** 🤔

If two users try to update the same product simultaneously:

-   User A reads the product (version = 1, stock = 10).
-   User B reads the same product (version = 1, stock = 10).
-   User A updates the stock to 8 and saves (version increments to 2).
-   User B tries to update the stock to 7 but fails because the version is now 2, throwing an `OptimisticLockException`.

1.  **Handling the Exception** 🛑
```java
@Transactional  
public void updateStockWithRetry(Long productId, int newStock) {  
    int maxRetries = 3;  
    for (int attempt = 1; attempt <= maxRetries; attempt++) {  
        try {  
            Product product = productRepository.findById(productId)  
                    .orElseThrow(() -> new RuntimeException("Product not found"));  
            product.setStock(newStock);  
            productRepository.save(product);  
            return;  
        } catch (OptimisticLockException e) {  
            if (attempt == maxRetries) {  
                throw new RuntimeException("Failed to update stock after " + maxRetries + " attempts", e);  
            }  
            // Retry after a short delay  
            try {  
                Thread.sleep(100);  
            } catch (InterruptedException ie) {  
                Thread.currentThread().interrupt();  
            }  
        }  
    }  
}
```
This code retries the operation up to three times if an `OptimisticLockException` occurs.

### Pros and Cons of Optimistic Locking

✅ **Pros**:

-   High scalability for read-heavy applications.
-   No database locks, reducing contention.
-   Simple to implement with JPA.

❌ **Cons**:

-   Requires conflict resolution logic (e.g., retries).
-   Not suitable for high-conflict scenarios.

### 🔐 Pessimistic Locking: Lock It Down! ⛔

### What is Pessimistic Locking?

Pessimistic locking assumes conflicts are likely and locks the data at the database level to prevent other transactions from modifying it until the current transaction is complete. It’s like reserving a meeting room — only one person can use it at a time. 🗝️

### How Does It Work?

When a transaction reads an entity with pessimistic locking, it acquires a lock (e.g., `SELECT ... FOR UPDATE`). Other transactions trying to access the same data are blocked until the lock is released.

### When to Use Pessimistic Locking?

-   ✅ High-conflict scenarios (e.g., booking a unique resource like a concert ticket).
-   ✅ Write-heavy operations where data integrity is critical.
-   ✅ When you want to avoid retries and ensure exclusive access.

### Example: Implementing Pessimistic Locking in Spring Boot

Let’s modify the `Product` example to use pessimistic locking.

1.  **Repository with Lock** 🔍
```java
import org.springframework.data.jpa.repository.JpaRepository;  
import org.springframework.data.jpa.repository.Lock;  
import org.springframework.data.jpa.repository.Query;  
  
import jakarta.persistence.LockModeType;  
public interface ProductRepository extends JpaRepository<Product, Long> {  
    @Lock(LockModeType.PESSIMISTICWRITE)  
    @Query("SELECT p FROM Product p WHERE p.id = :id")  
    Product findByIdWithPessimisticLock(Long id);  
}
```
The `@Lock(LockModeType.PESSIMISTICWRITE)` ensures the entity is locked for writing.

1.  **Service Logic** ⚙️
```java
@Service  
public class ProductService {  
    private final ProductRepository productRepository;  
  
    public ProductService(ProductRepository productRepository) {  
        this.productRepository = productRepository;  
    }  
  
    @Transactional  
    public void updateStockWithPessimisticLock(Long productId, int newStock) {  
        Product product = productRepository.findByIdWithPessimisticLock(productId);  
        if (product == null) {  
            throw new RuntimeException("Product not found");  
        }  
        product.setStock(newStock);  
        productRepository.save(product); // Lock is held until transaction commits  
    }  
}
```

1.  **What Happens?** 🤔

-   User A calls `updateStockWithPessimisticLock`, locking the product row in the database.
-   User B tries to access the same product but is blocked until User A’s transaction commits or rolls back.
-   Once User A’s transaction is complete, User B can proceed.

### Types of Pessimistic Locks

-   `PESSIMISTICREAD`: Allows other transactions to read but not write.
-   `PESSIMISTICWRITE`: Prevents other transactions from reading or writing (exclusive lock).
-   `PESSIMISTICFORCEINCREMENT`: Forces an increment of the version field (used with optimistic locking).

### Pros and Cons of Pessimistic Locking

✅ **Pros**:

-   Ensures data integrity in high-conflict scenarios.
-   No need for retry logic.
-   Ideal for critical operations like financial transactions.

❌ **Cons**:

-   Can lead to deadlocks if not managed properly.
-   Reduced scalability due to database locks.
-   Increased latency for blocked transactions.

### ⚖️ Optimistic vs. Pessimistic Locking: Which to Choose?

Feature Optimistic Locking Pessimistic Locking **Conflict Assumption** Rare conflicts Frequent conflicts **Locking Mechanism** Version checking Database locks **Scalability** High Lower **Use Case** Read-heavy apps Write-heavy apps **Overhead** Low High **Error Handling** Retries needed No retries

### Quick Tips for Choosing 🧭

-   Use **optimistic locking** for applications with many reads and few writes, like blogs or product catalogs.
-   Use **pessimistic locking** for operations where conflicts are common, like booking systems or inventory management.
-   Combine both in complex apps: optimistic locking for general operations and pessimistic locking for critical updates.

### 🛠️ Best Practices for Locking in Spring Boot

1.  **Keep Transactions Short** ⏱️  
    Long transactions increase the risk of contention and deadlocks, especially with pessimistic locking.
2.  **Handle OptimisticLockException** 🛡️  
    Implement retry logic or inform users about conflicts to improve user experience.
3.  **Test Concurrency Scenarios** 🧪  
    Simulate multiple users accessing the same data to ensure your locking strategy works as expected.
4.  **Monitor Database Performance** 📊  
    Pessimistic locking can impact performance, so monitor lock contention and optimize queries.
5.  **Use Proper Isolation Levels** 🔧  
    Adjust transaction isolation levels (e.g., `READCOMMITTED`, `SERIALIZABLE`) based on your needs.

### 🎉 Conclusion

Optimistic and pessimistic locking are powerful tools in Spring Boot for managing concurrency. By understanding their strengths and weaknesses, you can choose the right strategy for your application’s needs. Whether you’re building a high-traffic e-commerce platform or a critical booking system, Spring Boot’s JPA support makes implementing these mechanisms a breeze. 🚀

So, go ahead and lock in your data safely — your users will thank you! 😊

**Happy coding!** 💻

Thank you for your patience in reading this article! If you found this article helpful, please give it a clap 👏, bookmark it ⭐, and share it with friends in need and **follow** me for more Spring Boot insights. Your support is my biggest motivation to continue to output technical insights!

---
