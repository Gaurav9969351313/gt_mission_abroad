# Spring Boot Redis Integration

### Introduction

Redis (Remote Dictionary Server) is an open-source, in-memory data structure store widely used as a database, cache, and message broker. Known for its exceptional speed, Redis can serve millions of requests per second, making it popular for high-performance applications. It’s built to handle various data types like strings, hashes, lists, sets, and sorted sets, which makes it versatile for a range of use cases. Since it stores data in memory, Redis enables incredibly low latency, making it ideal for real-time applications where response speed is critical.

### Why use Redis

Redis shines in scenarios that require fast, reliable access to data. By storing data in memory, Redis provides rapid read and write capabilities, which makes it suitable for applications needing high throughput and minimal latency. It’s also incredibly flexible, serving as both a simple key-value store and a more complex data structure server. Additionally, Redis supports persistence through snapshots and logs, so data can be stored on disk and restored on restart, balancing the need for speed with durability. This makes Redis valuable for a range of use cases, from caching and session management to real-time analytics and message queuing.

### Use cases

### Caching

One of the most common uses for Redis is as a caching layer to reduce database load and improve application performance. By caching frequently accessed data in Redis, applications can retrieve data in milliseconds instead of querying a slower database. This is particularly beneficial for high-traffic applications and reduces the overall response time for end-users.

### Session Storage

Redis is widely used to store user sessions, especially in web applications where fast access to session data is essential. Since Redis is in-memory and offers automatic data expiration, it’s ideal for session management, ensuring quick access to user-specific information while freeing up memory once sessions expire.

### Message Queueing

Redis can also function as a lightweight message broker. By using lists and the pub/sub (publish/subscribe) messaging pattern, Redis enables applications to communicate asynchronously and process jobs in the background. This is valuable for applications that require scalable task management, like sending notifications or processing media uploads.

### SpringBoot configuration & implementation

Here is the basic docker-compose redis configuration
```yml
services:  
    redis:  
    image: redis:latest  
    restart: always  
    ports:  
      - "6379:6379"  
    environment:  
      - REDISPASSWORD=my-password  
      - REDISPORT=6379  
      - REDISDATABASES=16
```
### Maven dependency
```xml
<dependency>  
 <groupId>org.springframework.boot</groupId>  
 <artifactId>spring-boot-starter-data-redis</artifactId>  
</dependency>
```
In application yml file, cache type and redis host, port informations are defined.
```yml
spring:  
  cache:  
    type: redis  
    redis:  
      host: localhost  
      port: 6379  
  
cache:  
  config:  
    entryTtl: 60  
    jwtToken:  
      entryTtl: 30
```
Redis config class
```java
@Configuration  
@EnableCaching  
@Slf4j  
public class RedisConfig {  
  
    @Value("${spring.cache.redis.host}")  
    private String redisHost;  
  
    @Value("${spring.cache.redis.port}")  
    private int redisPort;  
  
    @Bean  
    public LettuceConnectionFactory redisConnectionFactory() {  
        RedisStandaloneConfiguration configuration = new RedisStandaloneConfiguration(redisHost, redisPort);  
        configuration.setPassword("my-password");  
        log.info("Connected to : {} {}", redisHost, redisPort);  
  
        return new LettuceConnectionFactory(configuration);  
    }  
  
    @Bean  
    public RedisCacheManager cacheManager(RedisConnectionFactory connectionFactory) {  
        return RedisCacheManager.create(connectionFactory);  
    }  
      
    @Bean  
    public RedisTemplate<String, Object> redisTemplate(){  
        final RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();  
        redisTemplate.setKeySerializer(new StringRedisSerializer());  
        redisTemplate.setHashKeySerializer(new GenericToStringSerializer<Object>(Object.class));  
        redisTemplate.setHashValueSerializer(new JdkSerializationRedisSerializer());  
        redisTemplate.setValueSerializer(new StringRedisSerializer());  
        redisTemplate.setConnectionFactory(redisConnectionFactory());  
        return redisTemplate;  
    }  
}
```
To enable caching in your application, you can use the `@EnableCaching` annotation and then annotate methods that should be cached with `@Cacheable`, `@CachePut`, and `@CacheEvict`.
```java
@GetMapping("/product/{id}")    
@Cacheable(value = "product", key = "###id")  
public Product getProductById(@PathVariable long id) {...}
```
1. **@Cacheable** is employed to fetch data from the database, storing it in the cache. Upon future invocations, the method retrieves the cached value directly, eliminating the need to execute the method again.

The `value` attribute establishes a cache with a specific name, while the `key` attribute permits the use of Spring Expression Language to compute the key dynamically. Consequently, the method result is stored in the 'product' cache, where respective 'productid' serves as the unique key. This approach optimizes caching by associating each result with a distinct key.

**2.** `**@CachePut**` is used to update data in the cache when there is any update in the source database.
```java
@PutMapping("/product/{id}")  
@CachePut(cacheNames = "product", key = "###id")  
public Product editProduct(@PathVariable long id, @RequestBody Product product) {...}
```
The `cacheNames` attribute is an alias for `value`, and can be used in a similar manner.

**3.** `**@CacheEvict**` is used for removing stale or unused data from the cache.

We use cacheName and key to remove specific data from the cache. The `beforeInvocation` attribute allows us to control the eviction process, enabling us to choose whether the eviction should occur before or after the method execution.
```java
@DeleteMapping("/product/{id}")  
@CacheEvict(cacheNames = "product", key = "###id", beforeInvocation = true)  
public String removeProductById(@PathVariable long id) {...}
```
Alternatively, all the data can also be removed for a given cache by using the `allEntries` attribute as true. The annotation allows us to clear data for multiple caches as well by providing multiple values as cacheName.

**4.** `**@Caching**`is used for multiple nested caching on the same method.
```java
@PutMapping("/{id}")  
@Caching(  
     evict = {@CacheEvict(value = "productList", allEntries = true)},  
     put = {@CachePut(value = "product", key = "###id")}  
)  
public Product editProduct(@PathVariable long id, @RequestBody Product product) {...}
```
As Java doesn’t allow multiple annotations of the same type to be declared for a method, doing so will generate a compilation error. We can group different annotations into Caching, as shown.

**5.** `**@CacheConfig**`is used for centralized configuration.
```java
@CacheConfig(cacheNames = "product")  
public class ProductController {...}
```
### Working with RedisTemplate

You can use the `RedisTemplate` to interact with Redis. For example, to save data in Redis:
```java
@Autowired  
private RedisTemplate<String, Object> redisTemplate;  
  
public void saveData(String key, Object data) {  
    redisTemplate.opsForValue().set(key, data);  
}
```
Retrive data from Redis:
```java
public Object getData(String key) {  
    return redisTemplate.opsForValue().get(key);  
}
```
Example service class with redis template

```java
@Service  
public class CacheTokenService {  
  
    private final StringRedisTemplate stringRedisTemplate;  
    private final RedisTemplate<String, Object> redisTemplate;  
  
    public CacheTokenService(StringRedisTemplate stringRedisTemplate, RedisTemplate<String, Object> redisTemplate) {  
        this.stringRedisTemplate = stringRedisTemplate;  
        this.redisTemplate = redisTemplate;  
    }  
  
    public void saveData(String key, Object data) {  
        redisTemplate.opsForValue().set(key, data);  
    }  
  
    public Object getData(String key) {  
        return redisTemplate.opsForValue().get(key);  
    }  
  
    public void cacheToken(String username, String token) {  
        stringRedisTemplate  
        .opsForValue()  
        .set("token:" + username, token, Duration.ofMinutes(60));  
    }  
  
    public String getCachedToken(String username) {  
        // Retrieve the token from Redis cache  
        return stringRedisTemplate  
        .opsForValue()  
        .get("token:" + username);  
    }  
  
}
```
### PUB/SUB Messaging

Adding configurations like:
```java
    @Bean  
    public ChannelTopic channelTopic(){  
        return new ChannelTopic("channeltopic");  
    }  
  
    @Bean  
    public RedisMessageListenerContainer redisMessageListenerContainer(){  
        RedisMessageListenerContainer container = new RedisMessageListenerContainer();  
        container.setConnectionFactory(redisConnectionFactory());  
        container.addMessageListener(messageListener(), channelTopic());  
        return container;  
    }  
  
    @Bean  
    public MessageListenerAdapter messageListener( ) {  
        return new MessageListenerAdapter(redisMessageHandler);  
    }
```
Last seen of config class:
```java
@Configuration  
@EnableCaching  
@Slf4j  
public class RedisConfig {  
  
    @Value("${spring.cache.redis.host}")  
    private String redisHost;  
  
    @Value("${spring.cache.redis.port}")  
    private int redisPort;  
  
  
    private final RedisMessageHandler redisMessageHandler;  
  
    public RedisConfig(RedisMessageHandler redisMessageHandler) {  
        this.redisMessageHandler = redisMessageHandler;  
    }  
  
    @Bean  
    public LettuceConnectionFactory redisConnectionFactory() {  
        RedisStandaloneConfiguration configuration = new RedisStandaloneConfiguration(redisHost, redisPort);  
        configuration.setPassword("my-password");  
        log.info("Connected to : {} {}", redisHost, redisPort);  
  
  
        return new LettuceConnectionFactory(configuration);  
    }  
  
    @Bean  
    public RedisCacheManager cacheManager(RedisConnectionFactory connectionFactory) {  
        return RedisCacheManager.create(connectionFactory);  
    }  
    @Bean  
    public RedisTemplate<String, Object> redisTemplate(){  
        final RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();  
        redisTemplate.setKeySerializer(new StringRedisSerializer());  
        redisTemplate.setHashKeySerializer(new GenericToStringSerializer<Object>(Object.class));  
        redisTemplate.setHashValueSerializer(new JdkSerializationRedisSerializer());  
        redisTemplate.setValueSerializer(new StringRedisSerializer());  
        redisTemplate.setConnectionFactory(redisConnectionFactory());  
        return redisTemplate;  
    }  
  
    @Bean  
    public ChannelTopic channelTopic(){  
        return new ChannelTopic("channeltopic");  
    }  
  
    @Bean  
    public RedisMessageListenerContainer redisMessageListenerContainer(){  
        RedisMessageListenerContainer container = new RedisMessageListenerContainer();  
        container.setConnectionFactory(redisConnectionFactory());  
        container.addMessageListener(messageListener(), channelTopic());  
        return container;  
    }  
  
    @Bean  
    public MessageListenerAdapter messageListener( ) {  
        return new MessageListenerAdapter(redisMessageHandler);  
    }  
}
```
Publisher interface:
```java
public interface MessagePublisher {  
    void publish(String message);  
}
```
Publisher service class:
```java
import org.springframework.data.redis.core.RedisTemplate;  
import org.springframework.data.redis.listener.ChannelTopic;  
import org.springframework.stereotype.Service;  
  
@Service  
@Slf4j  
public class RedisMessagePublisher implements MessagePublisher{  
  
    private final RedisTemplate<String, Object> redisTemplate;  
    private final ChannelTopic topic;  
  
    public RedisMessagePublisher(RedisTemplate<String, Object> redisTemplate, ChannelTopic topic) {  
        this.redisTemplate = redisTemplate;  
        this.topic = topic;  
    }  
  
    @Override  
    public void publish(String message) {  
        redisTemplate.convertAndSend(topic.getTopic(), message);  
        log.info("Published : {}", topic.getTopic());  
    }  
  
}
```
RedisMessageHandler class is the listener class and shown belove:
```java
@Service  
@Slf4j  
public class RedisMessageHandler implements MessageListener {  
  
    @Override  
    public void onMessage(Message message, byte[] pattern) {  
        log.info("Message : {}, from channel : {}", message, message.getChannel());  
        // message handle logic  
    }  
      
}
```
**Usage**: after injecting `redisMessagePublisher` messages can be published
```java
redisMessagePublisher.publish("test-message");
```
### Redis GUI : RedisInsight

![](https://miro.medium.com/v2/resize:fit:875/0*YoI96mTffUi89eSG)

Download link : [https://redis.io/insight/](https://redis.io/insight/)

Originally published at [https://musticode.gitbook.io](https://musticode.gitbook.io/springboot-configurations) on May 5, 2024.
---


# Spring boot Redis Dynamic TTL with @Cacheable  

I was working on project to migrate from using Hazelcast to Redis Cache system in our application. There was an interesting feature available in **Hazelcast** where I could use **wildcard** names for the cache to define the TTL of the entries.

After exploring multiple articles (references below), I could finally make it work with custom code which I would explain below

### Objective:

Find a solution to auto-configure TTL in Redis based on the wild card cache names.

For example, I could mention in config, **10m*** expires 10 min and **20m*** — 20 min and using @Cacheable annotations, if I would write
```java
@Cacheable(value = "10m-name",key = "'somename'".......  
   public String getDataTTL() {  
   ................

   @Cacheable(value = "20m-tokens",key = "'sometoken'".......  
   public String getDataTTL() {  
   ................
```
Automatically, It should add entries to **10m-name with 10 minutes TTL and 20m-tokens with 20 minutes as TTL.** This should completely dynamic i.e I do not need to pre-define the full names of the cache and their corresponding TTLs.

### Tech Stack:

-   Java 17
-   Maven
-   Spring boot 3.X
-   Redis (Docker must pre-installed)
-   RedisInsight for GUI ([here](https://github.com/RedisInsight/RedisInsight)) (any GUI for Redis is good)
-   TestContainer Redis
-   Junit 5

### Redis

Redis docker is used for this demo, but for live system it could be Redis cluster or a Redis standalone.
```shell
docker run -p 6378:6379 --restart=no -d redis:6-alpine
```
![](https://miro.medium.com/v2/resize:fit:875/1*n17UebAXoh3K7kXf7HTkPQ.png)

Connect using Localhost and port 6378 to connect to your local Redis container.

### **Project Setup**

You can import the project from the [github](https://github.com/prabhushan/spring-boot-redis-custom-ttl.git) link here. Once imported into your local IDE, you should see the following files

![](https://miro.medium.com/v2/resize:fit:875/1*Ed2DisZdOW83FOD9p4OIA.png)

### Explaination

Configuration of Redis URL / ports
```yaml
server:  
  port: 4040   
  
cache:
   host: 127.0.0.1  
   port: 6378
```
**RedisConfig.java** is used to create a **@bean** of the RedisCacheManager. We could also specify the default TTL (optional) if no TTL specified for a cache. You could add any redis configuration as per your requirements.

### Solution

In Spring, the `CacheResolver` is an interface used for resolving caches at runtime. It allows you to dynamically determine which cache(s) to use for a specific method invocation. More on below


### 35. Cache Abstraction

### Since version 3.1, Spring Framework provides support for transparently adding caching into an existing Spring…
https://docs.spring.io/spring-framework/docs/4.2.x/spring-framework-reference/html/cache.html?source=postpage-----79898300d779---------------------------------------###cache-annotations-cacheable-default-cache-resolver

For our use case, we need to create our own implementation of the `CacheResolver` interface as shown below

> **CustomCacheResolver.java** is the key component class which would help us to use wildcard cache names to TTL.

The **init()** method is called on initializaiton and it contains the **prefix** of the cachename and desired TTL —

> The below code indicates, if there is a cachename starting with **10m-,** then TTL for the object is 10 min. Similar 20 minutes for cache names starting with **20m-**

You could read these values from property files too.
```java
...  
public void init() {  
//TTL-CacheName config  
    mapNameConfig.put("10m-", "10");  
    mapNameConfig.put("20m-", "20");  
}  

@Override  
public Collection<? extends Cache> resolveCaches(CacheOperationInvocationContext<?> context) {  
  log.warn("CustomCacheResolver resolveCaches");  
  if (context != null && context.getOperation() != null && (context.getOperation().getCacheNames() != null  
    && !context.getOperation().getCacheNames().isEmpty())) {  
   Collection<CustomCache> caches = new HashSet<>();  
  
   Set<String> cacheNames = context.getOperation().getCacheNames().stream().collect(Collectors.toSet());  
  
   cacheNames.forEach(cacheName -> {  
  
    Cache cache = cacheManager.getCache(cacheName);  
    CustomCache customCache = cacheWithCustomTTL(cacheName, cache);  
    caches.add(customCache);  
   });  
   return caches;  
  
  }  
  // this should not reach here  
  log.warn("CustomCacheResolver context is empty");  
  return Collections.emptyList();  
}  
  
private CustomCache cacheWithCustomTTL(String cacheName, Cache cache) {  
  int ttl = namePartOfPrefix(cacheName);  
  
  RedisCache redisCache = (RedisCache) cache;  
  
  RedisCacheWriter cacheWriter = redisCache.getNativeCache();  
  RedisCacheConfiguration cacheConfig = RedisCacheConfiguration.defaultCacheConfig()  
    .entryTtl(Duration.ofMinutes(ttl));  
  CustomCache customCache = new CustomCache(cacheName, cacheWriter, cacheConfig);  
  return customCache;  
}  
  
private int namePartOfPrefix(String name) {  
  
  for (Map.Entry<String, String> entry : cachePrefixWithTTL.entrySet()) {  
   if (name.startsWith(entry.getKey())) {  
    return Integer.parseInt(entry.getValue());  
   }  
  }  
  return DEFAULTTTL;  
}  
```

The **resolveCaches** method is the key component to set TTL based on wild card configurations and returns list of Cache Object.

### Challenges

The few blockers I faced are -

1.  There is no way to update TTL for existing RedisCache Object. TTL is set only when creating the RedisCache object.
2.  The constructor for RedisCache class is **protected**. Hence the only way to overcome this challenge is to create **CustomCache** class extending from **RedisCache** class.

The **cacheWithCustomTTL** method returns an object of CustomCache with TTL based on the TTL-CacheName config

### Verification

In order to verify the functionality, I have a simple controller and service layer shown below.
```java
package com.neospark.controller;  
  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.RestController;  
  
import com.neospark.service.CacheService;  
  
@RestController  
public class Controller {  
   
 @Autowired  
 CacheService redisCacheService;  
  
 @GetMapping("/get/data")  
 public String getData() {  
  return redisCacheService.getData();  
 }  
   
 @GetMapping("/get/datattl/10")  
 public String getData10TTL() {  
  return redisCacheService.get10MinTTL();  
 }  
   
 @GetMapping("/get/datattl/20")  
 public String getData20TTL() {  
  return redisCacheService.get20MinTTL();  
 }  
  
}
```
When we add @Cacheable annotation, we must mention the **CacheResolver** value as shown below.
```java
package com.neospark.service;  
  
import org.springframework.cache.annotation.Cacheable;  
import org.springframework.stereotype.Service;  
  
import lombok.extern.slf4j.Slf4j;  
  
@Service  
@Slf4j  
public class CacheService {  
   
   
//cacheResolver - must point to our customCacheResolver component    
    @Cacheable(value = "10m-cache-ttl",key = "'somename'", cacheResolver = "customCacheResolver")  
    public String get10MinTTL() {  
        try {  
         log.warn("Thread sleeping for 5 seconds");  
   Thread.sleep(5000);  
  } catch (InterruptedException e) {  
   log.warn("Thread sleep interrupted");  
  }  
        return "Hello World from 10m";  
    }  
      
//cacheResolver - must point to our customCacheResolver component  
    @Cacheable(value = "20m-cache-ttl",key = "'somename'", cacheResolver = "customCacheResolver")  
    public String get20MinTTL() {  
        try {  
         log.warn("Thread sleeping for 5 seconds");  
   Thread.sleep(5000);  
  } catch (InterruptedException e) {  
   log.warn("Thread sleep interrupted");  
  }  
        return "Hello World from 20m";  
    }  
  
    @Cacheable("default-cache")  
    public String getData() {  
        try {  
         log.warn("Thread sleeping for 5 seconds");  
   Thread.sleep(5000);  
  } catch (InterruptedException e) {  
   log.warn("Thread sleep interrupted");  
  }  
        return "Hello World";  
    }  
}
```
After starting the application, run the following GET URLs

curl http://localhost:4040/get/datattl/10  
curl http://localhost:4040/get/datattl/20  
curl http://localhost:4040/get/data

The above statements would add cache objects into the Redis and automatically adds the TTL based on the configuration names.

![](https://miro.medium.com/v2/resize:fit:875/1*ZNKBNHJ8aNkEBIac7gzJ1w.png)
It shows a minute less as few seconds had passed before taking the screenshot.

https://github.com/prabhushan/spring-boot-redis-custom-ttl.git
---

# Spring Boot Redis TTL callback for Expired keys

Time to live is a concept where data get expired after specified time. This is useful to invalidate cache, session management, token. This can be implemented in redis, Couchbase, Elasticsearch.

Redis provides various event for comment event type like setting, deleting, epiry of keys. Application server can receive these events using pub sub of redis.

In redis, event corresponding to pattern **keyevent@***:expired can be used to listen the expired key event and apply business logic.

Let’s take a example of real world scenario. In a e commerce platform, discount offer get expires at a particular time say 12 pm on some particular day and after that price of product will change. In this case, we can set a ttl key with some value that will expired at 12pm. After this time, we can reset the price after listening the key expired event.

Let’s look into sample code in spring boot application. Firstly set up local redis. docker installation is a easy way to quickly start.
```shell
docker run -d --name redis-stack-server -p 6379:6379 redis/redis-stack-server:latest
```
In spring boot application, We need a expired key listener class.
```java
@Component  
@Slf4j  
public class KeyListener implements MessageListener {  
    @Override  
    public void onMessage(Message message, byte[] pattern) {  
        String expiredKey = message.toString();  
        log.info("expired key {}", expiredKey);  
    }  
}
```
In redis configuration we need to register this bean to listen all the expired event keys. We have to do all this during application start.
```java
@Configuration  
@EnableRedisRepositories(enableKeyspaceEvents = RedisKeyValueAdapter.EnableKeyspaceEvents.ONSTARTUP)  
public class RedisConfig {  
  
    @Bean  
    RedisMessageListenerContainer container(RedisConnectionFactory connectionFactory,  
                                            MessageListenerAdapter listenerAdapter) {  
        RedisMessageListenerContainer container = new RedisMessageListenerContainer();  
        container.setConnectionFactory(connectionFactory);  
        container.addMessageListener(listenerAdapter, new PatternTopic("keyevent@*:expired"));  
        return container;  
    }  
  
    @Bean  
    MessageListenerAdapter listenerAdapter(MessageListener listener) {  
        return new MessageListenerAdapter(listener);  
    }  
  
    @Bean  
    public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory connectionFactory) {  
        RedisTemplate<String, Object> template = new RedisTemplate<>();  
        template.setConnectionFactory(connectionFactory);  
  
        RedisSerializer<String> stringSerializer = new StringRedisSerializer();  
        RedisSerializer<Object> jsonSerializer = new GenericJackson2JsonRedisSerializer();  
  
        template.setKeySerializer(stringSerializer);  
        template.setValueSerializer(jsonSerializer);  
        template.setHashKeySerializer(stringSerializer);  
        template.setHashValueSerializer(jsonSerializer);  
  
        template.afterPropertiesSet();  
        return template;  
    }  
}
```
You can find full code in my [github page](https://github.com/keshav-repo/spring-boot-concepts/tree/master/TTLCallback). After running redis and application you can enter into redis terminal and set some ttl key value.

### enter into redis   
```shell
redis-cli -h 127.0.0.1 -p 6379  
### set key value for 60 second  
SET key1 value1 EX 30  
SET key2 value2 EX 60
```
Screenshot of expired keys logged in spring boot application.

![](https://miro.medium.com/v2/resize:fit:875/1*PY47ipQ0keosJtBEJ2iw.png)
---

# [Springboot — Redis] How to improve Spring boot Performance using Caching
![](https://miro.medium.com/v2/resize:fit:875/1*ScFigAm6v3Iggb2bkslMg.png)

In this step-by-step guide, we’ll delve into optimizing Spring Boot performance through caching. By strategically caching frequently accessed data, we can significantly enhance response times and overall efficiency. Whether you’re new to caching or seeking advanced techniques, this article will provide practical insights to elevate your Spring Boot application’s performance.

You can get the app [here](https://github.com/joseMarciano/spring-redis-cache).

### Redis Connection

Once you’ve cloned the repository from the [provided link](https://github.com/joseMarciano/spring-redis-cache), our journey begins with an exploration of the `RedisConfig`.

The `RedisConfig` class serves as the backbone for seamlessly integrating Redis caching into our Spring Boot application. Let's break down its key components.

Firstly, the `lettuceConnectionFactory` method configures the connection to the Redis server. It utilizes the Lettuce client to establish a connection based on the provided Redis host.
```java
@Bean  
RedisConnectionFactory lettuceConnectionFactory(@Value("${redis.host}") final String host) {  
    final var redisUri = RedisURI.create(host);  
    redisUri.setVerifyPeer(false);  
  
    final var redisConfig = new RedisStandaloneConfiguration(redisUri.getHost(), redisUri.getPort());  
    return new LettuceConnectionFactory(redisConfig);  
}
```
Next, we define two methods for configuring Redis cache settings. The `customRedisKeyCacheConfig` method sets up custom cache configurations for specific keys, such as 'product', with a defined time-to-live (TTL) duration and disables caching of null values.
```java
@Bean  
public Map<String, RedisCacheConfiguration> customRedisKeyCacheConfig() {  
    final var map = new HashMap<String, RedisCacheConfiguration>();  
    map.put("product", RedisCacheConfiguration.defaultCacheConfig()  
            .entryTtl(Duration.ofSeconds(10000))  
            .disableCachingNullValues());  
  
    return map;  
}
```
Meanwhile, the `defaultRedisCacheConfiguration` method establishes default cache settings, including a TTL of 3 minutes.
```java
@Bean  
public RedisCacheConfiguration defaultRedisCacheConfiguration() {  
    return RedisCacheConfiguration.defaultCacheConfig()  
            .entryTtl(Duration.ofMinutes(3))  
            .disableCachingNullValues();  
}
```
The `redisCacheManager` method creates a `RedisCacheManager` instance, utilizing the previously configured Redis connection factory and cache configurations. It allows for both default and custom cache configurations.
```java
@Bean  
public RedisCacheManager redisCacheManager(final RedisConnectionFactory redisConnectionFactory,  
                                           final RedisCacheConfiguration defaultRedisCacheConfiguration,  
                                           final Map<String, RedisCacheConfiguration> customRedisKeyCacheConfig) {  
    final var builder = RedisCacheManager.builder(redisConnectionFactory);  
    builder.cacheDefaults(defaultRedisCacheConfiguration);  
    customRedisKeyCacheConfig.forEach(builder::withCacheConfiguration);  
    return builder.build();  
}
```
Lastly, the `cacheResolver` method defines a cache resolver, enabling Spring's caching annotations to interact with Redis cache. This resolver utilizes the `RedisCacheManager` to resolve cache operations effectively.
```java
@Bean  
public CacheResolver cacheResolver(final RedisCacheManager redisCacheManager) {  
    return new SimpleCacheResolver(redisCacheManager);  
}
```
### CacheTestingController

The `CacheTestingController` class exemplifies the practical application of caching within our Spring Boot application. Let's delve into its functionality

Each endpoint corresponds to a specific caching operation:

The `productById` method, annotated with `@GetMapping` and `@Cacheable(value = "product")`, retrieves product information by ID. This method is cached with the key "product", ensuring that subsequent requests for the same product ID are served from the cache, avoiding repeated database queries.
```java
@GetMapping("/product/cacheable/{id}")  
@Cacheable(value = "product")  
public ProductExampleOutput productById() throws InterruptedException {  
    System.out.println("Finding product in database");  
    Thread.sleep(1000L);  
    return new ProductExampleOutput("123", "productExample", 10.5, LocalDateTime.now());  
}
```
After you call this endpoint you can check inside the redis the key stores and the TTL configured.

![](https://miro.medium.com/v2/resize:fit:875/1*Y6k8vuind0RL0iWhNMOp7A.png)

Similarly, the `customerById` method retrieves customer information by ID, with caching enabled using the key `customer`.
```java
@GetMapping("/customer/cacheable/{id}")  
@Cacheable(value = "customer")  
public CustumerExampleOutput customerById() throws InterruptedException {  
    System.out.println("Finding customer in database");  
    Thread.sleep(500L);  
    return new CustumerExampleOutput("John", new Random().nextInt(), LocalDateTime.now());  
}
```

The `customerCreate` method, annotated with `@PostMapping` and `@CacheEvict(value = "customer", allEntries = true)`, simulates the creation of a new customer and evicts the corresponding cache entry for the `customer` cache, ensuring that the cache is updated upon new customer creation.
```java
@PostMapping("/customer/evict/{id}")  
@CacheEvict(value = "customer", allEntries = true)  
public CustumerExampleOutput customerCreate() throws InterruptedException {  
    System.out.println("Creating customer in database");  
    Thread.sleep(1000L);  
    return new CustumerExampleOutput("John", 45, LocalDateTime.now());  
}
```
Lastly, the `carById` method, annotated with `@GetMapping` and `@CachePut(value = "car")`, retrieves car information by ID. Unlike `@Cacheable`, `@CachePut` always invokes the method and updates the cache with the returned value, making it suitable for scenarios where the method's result needs to be cached regardless of previous caching.
```java
@GetMapping("/car/put/{id}")  
@CachePut(value = "car")  
public CarExampleOutput carById() throws InterruptedException {  
    System.out.println("Finding car in database");  
    Thread.sleep(3500L);  
    return new CarExampleOutput("Hi lux", "978", LocalDateTime.now());  
}
```
> Each method simulates database retrieval by printing a message and pausing execution for a specified duration using `Thread.sleep`.

Additionally, three record classes (`ProductExampleOutput`, `CustomerExampleOutput`, and `CarExampleOutput`) encapsulate the data returned by their respective endpoints, enhancing readability and maintainability.
```java
public record ProductExampleOutput(String id, String name, double price,  
                                   LocalDateTime dateTime) implements Serializable {  
}  
  
public record CustumerExampleOutput(String name, int age, LocalDateTime dateTime) implements Serializable {  
}  
  
public record CarExampleOutput(String name, String model, LocalDateTime dateTime) implements Serializable {  
}
```
### Conclusion

In summary, our journey through Spring Redis Cache has revealed powerful tools for boosting Spring Boot application performance. Leveraging caching annotations and configurations optimizes response times and reduces database load.
---
# Build a Real-Time GitHub Event Tracker using Spring Boot 3, Redis Streams & Elasticsearch

If you’re looking to level up your backend skills by learning how to build real-time RESTful APIs with Spring Boot, while also exploring Redis Streams for pub/sub and Elasticsearch for search and analytics, you’ve landed at the right place.

In this article, we’ll build a GitHub Webhook Listener and explore:

-   Receives GitHub push events via a REST API
-   Publish the event data to Redis Streams
-   Process and store the events in Elasticsearch
-   Expose search endpoints for querying recent events

## Technologies Used

-   **Spring Boot 3.x** — For building the RESTful API and service layers
-   **Redis Streams** — For real-time event messaging
-   **Elasticsearch 8.x** — For indexing and searching GitHub push data
-   **Maven** — For project build and dependency management
-   Lombok, Log4j2, Web, Data Redis, Spring Data Elasticsearch — Key dependencies

![](https://miro.medium.com/v2/resize:fit:875/1*Z0B75q8Ry0ookPsCZFJRhw.png)

## Why Elasticsearch?

Elasticsearch is a high-performance search engine that excels at:

-   Full-text search and search across push events instantly
-   For high-performance indexing and search
-   Fast retrieval over large volumes of logs/events
-   Real-time indexing and querying

In this article, every GitHub push event becomes part of a structured index that we can:

-   Search by pusher
-   Filter by timestamp
-   Analyze by repository activity

Let’s focus on the project setup and implementation step by step.

## Project Structure

github-event-tracker/  
│  
├── controller/  
│   └── GitHubWebhookController.java  
│  
├── model/  
│   └── GitHubPushEvent.java  
│  
├── service/  
│   └── GitHubEventService.java  
│   └── RedisStreamConsumer.java  
│  
├── repository/  
│   └── GitHubEventRepository.java  
│  
├── config/  
│   └── RedisConfig.java  
│  
└── GithubEventTrackerApplication.java

## Step-by-Step Implementation

Let’s start by defining the Maven `pom.xml` With the essential dependencies.
```xml
<properties>  
    <java.version>17</java.version>  
    <spring-boot.version>3.2.4</spring-boot.version>  
    <elasticsearch.version>8.11.1</elasticsearch.version>  
    <spring-data-redis.version>3.2.4</spring-data-redis.version>  
    <lombok.version>1.18.24</lombok.version>  
</properties>  
  
<dependencies>  
    <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-web</artifactId>  
        <version>${spring-boot.version}</version>  
    </dependency>  
    <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-log4j2</artifactId>  
        <version>${spring-boot.version}</version>  
    </dependency>  
    <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-data-redis</artifactId>  
        <version>${spring-data-redis.version}</version>  
    </dependency>  
    <dependency>  
        <groupId>org.springframework.data</groupId>  
        <artifactId>spring-data-elasticsearch</artifactId>  
        <version>${elasticsearch.version}</version>  
    </dependency>  
    <dependency>  
        <groupId>org.projectlombok</groupId>  
        <artifactId>lombok</artifactId>  
        <optional>true</optional>  
    </dependency>  
    <dependency>  
        <groupId>com.fasterxml.jackson.core</groupId>  
        <artifactId>jackson-databind</artifactId>  
    </dependency>  
    <dependency>  
        <groupId>org.projectlombok</groupId>  
        <artifactId>lombok</artifactId>  
        <version>${lombok.version}</version>  
    </dependency>  
</dependencies>
```
## Step 1: Model GitHub Push Event
```java
@Document(indexName = "github-push-events")  
@Data  
@AllArgsConstructor  
@NoArgsConstructor  
public class GitHubPushEvent {  
    @Id  
    private String id;  
    private String repository;  
    private String pusher;  
    private String commitMessage;  
    private LocalDateTime timestamp;  
}
```
## Step 2: REST Controller for GitHub Webhook
```java
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.http.ResponseEntity;  
import org.springframework.web.bind.annotation.*;  
  
import java.util.Map;  
  
@RestController  
@RequestMapping("/api/webhook")  
public class GitHubWebhookController {  
  
    private final GitHubEventService eventService;  
  
    @Autowired  
    public GitHubWebhookController(GitHubEventService eventService) {  
        this.eventService = eventService;  
    }  
  
    @PostMapping("/github")  
    public ResponseEntity<String> handlePushEvent(@RequestBody Map<String, Object> payload) {  
        try {  
            if (payload == null || payload.isEmpty()) {  
                return ResponseEntity.badRequest().body("Invalid payload");  
            }  
            eventService.handleGitHubEvent(payload);  
            return ResponseEntity.ok("Received");  
        } catch (Exception e) {  
            return ResponseEntity.status(500).body("Error processing the event: " + e.getMessage());  
        }  
    }  
}
```
## Step 3: Redis Publisher (Producer)
```java
import com.fasterxml.jackson.core.JsonProcessingException;  
import com.fasterxml.jackson.databind.ObjectMapper;  
import org.springframework.beans.factory.annotation.Value;  
import org.springframework.data.redis.core.RedisTemplate;  
import org.springframework.stereotype.Service;  
import org.apache.logging.log4j.LogManager;  
import org.apache.logging.log4j.Logger;  
  
import java.util.Map;  
  
@Service  
public class GitHubEventService {  
  
    private static final Logger log = LogManager.getLogger(GitHubEventService.class);  
  
    private final RedisTemplate<String, Object> redisTemplate;  
    private final ObjectMapper mapper;  
    private final String redisStreamName;  
  
    public GitHubEventService(RedisTemplate<String, Object> redisTemplate,  
                              ObjectMapper objectMapper,  
                              @Value("${redis.stream.name:github-stream}") String redisStreamName) {  
        this.redisTemplate = redisTemplate;  
        this.mapper = objectMapper;  
        this.redisStreamName = redisStreamName;  
    }  
  
    public void handleGitHubEvent(Map<String, Object> payload) {  
        if (redisTemplate == null) {  
            throw new IllegalStateException("RedisTemplate is not initialized");  
        }  
        try {  
            String json = mapper.writeValueAsString(payload);  
            redisTemplate.opsForStream().add(redisStreamName, Map.of("event", json));  
        } catch (JsonProcessingException e) {  
            log.error("error: {}", e);  
            throw new RuntimeException("Failed to serialize payload or publish to Redis stream: " + e.getMessage(), e);  
        }  
    }  
}
```
## Step 4: Redis Stream (Consumer): Elasticsearch Indexer
```java
import com.fasterxml.jackson.core.JsonProcessingException;  
import com.fasterxml.jackson.databind.ObjectMapper;  
import org.springframework.data.redis.connection.stream.MapRecord;  
import org.springframework.data.redis.connection.stream.StreamReadOptions;  
import org.springframework.data.redis.connection.stream.StreamOffset;  
import org.springframework.data.redis.core.RedisTemplate;  
import org.springframework.stereotype.Service;  
import java.util.concurrent.Executors;  
import java.util.concurrent.ExecutorService;  
import org.apache.logging.log4j.LogManager;  
import org.apache.logging.log4j.Logger;  
  
import java.util.*;  
  
@Service  
public class RedisStreamConsumer {  
  
    private static final Logger log = LogManager.getLogger(RedisStreamConsumer.class);  
  
    private final GitHubEventRepository repository;  
    private final RedisTemplate<String, Object> redisTemplate;  
    private final ObjectMapper mapper = new ObjectMapper();  
    private volatile boolean running = true;  
  
    public RedisStreamConsumer(GitHubEventRepository repository, RedisTemplate<String, Object> redisTemplate) {  
        this.repository = repository;  
        this.redisTemplate = redisTemplate;  
    }  
  
    @PostConstruct  
    public void listenToStream() {  
        Executors.newSingleThreadExecutor().submit(() -> {  
            while (running) {  
                try {  
                    List<MapRecord<String, Object, Object>> messages =  
                        redisTemplate.opsForStream()  
                            .read(StreamReadOptions.empty().count(10).block(Duration.ofMillis(500)),  
                                StreamOffset.create("github-stream", ReadOffset.lastConsumed()));  
  
                    if (messages != null) {  
                        for (MapRecord<String, Object, Object> message : messages) {  
                            processMessage(message);  
                        }  
                    }  
                } catch (Exception e) {  
                    log.error("Error while reading Redis stream: {}", e.getMessage());  
                }  
            }  
        });  
    }  
  
    private void processMessage(MapRecord<String, Object, Object> message) {  
        try {  
            Object eventObject = message.getValue().get("event");  
            if (eventObject instanceof String) {  
                String json = (String) eventObject;  
                JsonNode node = mapper.readTree(json);  
  
                GitHubPushEvent event = new GitHubPushEvent();  
                event.setId(UUID.randomUUID().toString());  
                event.setRepository(node.path("repository").path("name").asText(null));  
                event.setPusher(node.path("pusher").path("name").asText(null));  
                event.setCommitMessage(node.path("headcommit").path("message").asText(null));  
                event.setTimestamp(LocalDateTime.now());  
  
                repository.save(event);  
            } else {  
                log.error("Invalid event format: {}", eventObject);  
            }  
        } catch (Exception e) {  
            log.error("Error while processing message: {}", e.getMessage());  
        }  
    }  
  
    @PreDestroy  
    public void cleanUp() {  
        running = false;  
    }  
}
```
## Step 5: Elasticsearch Repository
```java
import org.springframework.data.domain.Pageable;  
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;  
  
import java.util.List;  
  
public interface GitHubEventRepository extends ElasticsearchRepository<GitHubPushEvent, String> {  
    List<GitHubPushEvent> findByPusher(String pusher, Pageable pageable);  
}
```

## Step 6: Search API (Not Shown in the Project Structure)

You need to implement the Search API for searching.
```java
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.PathVariable;  
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RestController;  
import java.util.List;  
  
import com.example.repository.GitHubEventRepository;  
import com.example.model.GitHubPushEvent;  
  
@RestController  
@RequestMapping("/api/events")  
public class EventSearchController {  
  
    private final GitHubEventRepository repository;  
  
    public EventSearchController(GitHubEventRepository repository) {  
        this.repository = repository;  
    }  
  
    @GetMapping("/by-pusher/{name}")  
    public List<GitHubPushEvent> findByPusher(@PathVariable String name) {  
        return repository.findByPusher(name);  
    }  
}
```
## Step 7: application.yml Configuration (Own)

You need to check the application.yml for your setup. It may cause some issues initially. You may need to troubleshoot.
```yml
spring:  
  data:  
    elasticsearch: localhost:9200  
  redis:  
    host: localhost  
    port: 6379
```

## Step 8: Redis Stream Setup
```java
import org.springframework.beans.factory.annotation.Value;  
import org.springframework.context.annotation.Bean;  
import org.springframework.context.annotation.Configuration;  
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;  
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;  
import org.springframework.data.redis.core.RedisTemplate;  
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;  
import org.springframework.data.redis.serializer.StringRedisSerializer;  
  
@Configuration  
public class RedisConfig {  
  
    @Value("${spring.redis.host:localhost}")  
    private String redisHost;  
  
    @Value("${spring.redis.port:6379}")  
    private int redisPort;  
  
    @Value("${spring.redis.database:0}")  
    private int redisDatabase;  
  
    @Bean  
    public LettuceConnectionFactory lettuceConnectionFactory() {  
        RedisStandaloneConfiguration config = new RedisStandaloneConfiguration();  
        config.setHostName(redisHost);  
        config.setPort(redisPort);  
        config.setDatabase(redisDatabase);  
        return new LettuceConnectionFactory(config);  
    }  
  
    @Bean  
    public RedisTemplate<String, Object> redisTemplate(LettuceConnectionFactory connectionFactory) {  
        RedisTemplate<String, Object> template = new RedisTemplate<>();  
        template.setConnectionFactory(connectionFactory);  
  
        template.setKeySerializer(new StringRedisSerializer());  
        template.setHashKeySerializer(new StringRedisSerializer());  
  
        template.setValueSerializer(new GenericJackson2JsonRedisSerializer());  
        template.setHashValueSerializer(new GenericJackson2JsonRedisSerializer());  
  
        return template;  
    }  
}
```

## Step 9: Main Class Setup
```java
import org.springframework.boot.SpringApplication;  
import org.springframework.boot.autoconfigure.SpringBootApplication;  
  
@SpringBootApplication  
public class GithubEventTrackerApplication {  
    public static void main(String[] args) {  
        SpringApplication.run(GithubEventTrackerApplication.class, args);  
    }  
}
```

You are ready to proceed. Just a few configurations, imports, and setting up the Elasticsearch/Redis system port correctly, along with adjustments to the Maven dependencies for your setup or specific requirements, and then you can run the application😊

## Testing the Endpoints

Now let’s test the endpoint and pusher search event.

-   **Simulate a GitHub webhook event**
```shell
curl -X POST http://localhost:8080/api/webhook/github   
-H "Content-Type: application/json"   
-d '{  
  "repository": { "name": "sample-repo" },  
  "pusher": { "name": "raihan-dev" },  
  "headcommit": { "message": "Initial commit with README" }  
}'
```

-   **Search Events**
```shell
curl http://localhost:8080/api/events/by-pusher/raihan-dev
```
## Conclusion: What You’ve Learned

By following this hands-on guide, you have built a powerful full-stack application that mirrors how modern real-time systems operate in the industry today. Here’s a recap of the skills and concepts you’ve gained.

**Backend**

-   Backend (Spring Boot 3.x): How to receive GitHub Webhook events through a REST API.
-   How to publish and consume events using Redis Streams, a lightweight yet powerful messaging system.
-   How to transform and persist data into Elasticsearch, enabling full-text search and blazing-fast queries.
-   How to structure a clean microservice-style Spring Boot project, applying separation of concerns across controllers, services, configs, and repositories.
-   How to configure Redis and Elasticsearch clients using Spring Boot 3.x conventions.
-   Test the REST API

**Elasticsearch (Search)**

-   How to design indexable models, use Spring Data Elasticsearch, and expose searchable REST endpoints.
-   How to query data efficiently and prepare it for front-end consumption.

**End-to-End Architecture**

-   How to design a real-time data pipeline from GitHub → Redis → Elasticsearch.
-   How to glue multiple technologies together into one seamless whole.

Thanks for reading — now build something extraordinary! 🔥  
If you found this helpful, don’t forget to 👏 and follow for more cutting-edge tech deep-dives.
---

### Spring boot Redis difference between LettuceConnectionFactory and JedisConnectionFactory

Both `LettuceConnectionFactory` and `JedisConnectionFactory` are implementations of the `ConnectionFactory` interface in Spring Data Redis, providing the means to create connections to a Redis server. Let's explore the differences between the two with examples:

### 1. Underlying Redis Clients:

### **LettuceConnectionFactory:**

-   Uses Lettuce as the underlying Redis client.
-   Lettuce is a scalable, thread-safe Redis client for Java.
-   It provides a reactive, non-blocking API, making it suitable for reactive and asynchronous applications.
-   Supports connection pooling, which can improve performance and scalability in multi-threaded environments.

1. Maven Dependency:
```xml
<dependency>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-starter-data-redis</artifactId>  
</dependency>  
<dependency>  
    <groupId>io.lettuce.core</groupId>  
    <artifactId>lettuce-core</artifactId>  
</dependency>
```
2. Java Configuration:
```java
import org.springframework.context.annotation.Bean;  
import org.springframework.context.annotation.Configuration;  
import org.springframework.data.redis.connection.RedisConnectionFactory;  
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;  
  
@Configuration  
public class RedisConfig {  
  
    @Bean  
    public RedisConnectionFactory redisConnectionFactory() {  
        return new LettuceConnectionFactory("localhost", 6379);  
    }  
}

import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.data.redis.core.RedisTemplate;  
import org.springframework.stereotype.Service;  
  
@Service  
public class LettuceExampleService {  
  
    private final RedisTemplate<String, String> redisTemplate;  
  
    @Autowired  
    public LettuceExampleService(RedisTemplate<String, String> redisTemplate) {  
        this.redisTemplate = redisTemplate;  
    }  
  
    public void setValue(String key, String value) {  
        redisTemplate.opsForValue().set(key, value);  
    }  
  
    public String getValue(String key) {  
        return redisTemplate.opsForValue().get(key);  
    }  
}
```
### **JedisConnectionFactory:**

-   Uses Jedis as the underlying Redis client.
-   Jedis is a simple, single-threaded Redis client for Java.
-   It provides a blocking API, meaning each request blocks until a response is received.
-   Does not natively support connection pooling. However, it is possible to use Jedis with connection pooling libraries like Apache Commons Pool.

1.  **Maven Dependency:**
```xml
<dependency>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-starter-data-redis</artifactId>  
</dependency>  
<dependency>  
    <groupId>redis.clients</groupId>  
    <artifactId>jedis</artifactId>  
</dependency>
```
**2. Java Configuration:**
```java
import org.springframework.context.annotation.Bean;  
import org.springframework.context.annotation.Configuration;  
import org.springframework.data.redis.connection.RedisConnectionFactory;  
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;  
  
@Configuration  
public class RedisConfig {  
  
    @Bean  
    public RedisConnectionFactory redisConnectionFactory() {  
        return new JedisConnectionFactory();  
    }  
}

import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.data.redis.core.RedisTemplate;  
import org.springframework.stereotype.Service;  
  
@Service  
public class JedisExampleService {  
  
    private final RedisTemplate<String, String> redisTemplate;  
  
    @Autowired  
    public JedisExampleService(RedisTemplate<String, String> redisTemplate) {  
        this.redisTemplate = redisTemplate;  
    }  
  
    public void setValue(String key, String value) {  
        redisTemplate.opsForValue().set(key, value);  
    }  
  
    public String getValue(String key) {  
        return redisTemplate.opsForValue().get(key);  
    }  
}
```

### 2. Performance and Scalability:

### **LettuceConnectionFactory:**

-   Generally considered to be more performant and scalable compared to Jedis, especially in multi-threaded environments.
-   Supports asynchronous and reactive programming models, which can improve performance in high-concurrency scenarios.
-   Provides built-in connection pooling, reducing the overhead of establishing and closing connections.

### **JedisConnectionFactory:**

-   May have limitations in terms of performance and scalability compared to Lettuce, especially in multi-threaded scenarios.
-   Since Jedis is single-threaded, it may not fully utilize available CPU resources in multi-core environments.

### 3. Configuration Options:

### **LettuceConnectionFactory:**

-   Provides various configuration options for tuning connection pooling, timeout settings, SSL/TLS support, etc.
-   Supports reactive programming and integration with Spring’s reactive stack (e.g., WebFlux).

### **JedisConnectionFactory:**

-   Provides configuration options similar to LettuceConnectionFactory but may have fewer advanced features.
-   Does not natively support reactive programming but can be used with reactive libraries through compatibility layers.

### 4. Dependencies and Compatibility:

### **LettuceConnectionFactory:**

-   May require additional dependencies related to reactive programming (e.g., Reactor) if used in a reactive application.
-   Suitable for modern Spring applications, especially those utilizing reactive programming.

### **JedisConnectionFactory:**

-   Typically has fewer dependencies and may be simpler to integrate into existing Spring applications.
-   May be preferred for legacy applications or those not requiring advanced features like reactive programming.

### Summary:

### **Use LettuceConnectionFactory when:**

-   Building modern, high-performance, and scalable Spring applications.
-   Working with reactive programming and asynchronous APIs.
-   Needing advanced features like connection pooling and SSL/TLS support.

### **Use JedisConnectionFactory when:**

-   Working with legacy or simple Spring applications.
-   Preferring simplicity and ease of integration over advanced features.
-   Not requiring reactive programming or asynchronous APIs.

---
# Building High-Performance Applications with Spring Boot - Redis Caching and Distributed Locking 

![](https://miro.medium.com/v2/resize:fit:875/1*Uc6rmG1INmd5A7IoEPaDA.jpeg)
Building High-Performance Applications with Redis Caching and Distributed Locking

Caching and distributed locking are key to building scalable and high-performance systems. Redis, a powerful in-memory data store, combined with Spring Boot and Spring Data Redis, provides an excellent foundation for achieving high availability and performance.

In this post, we’ll cover **how to implement caching** for improved application performance and **distributed locking** to maintain data consistency in a high-availability setup. We’ll include detailed examples and best practices throughout.

### Why Redis for Caching and Distributed Locking?

Redis is known for:

-   **High performance:** Sub-millisecond latency for read/write operations.
-   **Rich data structures:** Support for strings, hashes, lists, and more.
-   **Built-in support for distributed locking:** Using commands like `SET` with NX and EX options.
-   **Persistence options:** These are for recovery in case of system crashes.
-   **Clustered architecture:** To ensure high availability and horizontal scaling.

### Setting Up Redis with Spring Boot

### 1. Add Dependencies

Include the following dependencies in your `pom.xml` for Spring Data Redis and caching support:
```xml
<dependencies>  
    <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-data-redis</artifactId>  
    </dependency>  
    <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-cache</artifactId>  
    </dependency>  
    <dependency>  
        <groupId>io.lettuce.core</groupId>  
        <artifactId>lettuce-core</artifactId>  
    </dependency>  
</dependencies>
```
### 2. Configure Redis Connection

In `application.yml`, configure the Redis server details:
```yml
spring:  
  redis:  
    host: localhost  
    port: 6379  
    password: yourpassword ### Optional if Redis is password protected
```
### Implementing Caching with Redis

### Enable Caching in Spring Boot

Annotate your main application class with `@EnableCaching`:
```java
@SpringBootApplication  
@EnableCaching  
public class RedisCachingApplication {  
    public static void main(String[] args) {  
        SpringApplication.run(RedisCachingApplication.class, args);  
    }  
}
```
### Create a Service with Cacheable Methods

Use the `@Cacheable` annotation to cache method results:
```java
@Service  
public class ProductService {  
  
@Cacheable(value = "products", key = "###productId")  
    public Product getProductById(Long productId) {  
        simulateSlowService();  
        return new Product(productId, "Product " + productId);  
    }  
    private void simulateSlowService() {  
        try {  
            Thread.sleep(3000); // Simulating a slow database call  
        } catch (InterruptedException e) {  
            Thread.currentThread().interrupt();  
        }  
    }  
}
```
### Verify Cached Results
```java
@RestController  
@RequestMapping("/products")  
public class ProductController {  
  
@Autowired  
    private ProductService productService;  
    @GetMapping("/{id}")  
    public Product getProduct(@PathVariable Long id) {  
        return productService.getProductById(id);  
    }  
}
```
Access the endpoint twice; the first call takes time, while subsequent calls fetch data from the cache.

### Implementing Distributed Locking

Distributed locking ensures that multiple instances of your application don’t simultaneously modify critical shared resources.

### Using Redis for Distributed Locks

Redis supports atomic operations that can be used for locking. Here’s a utility class:
```java
@Component  
public class RedisLock {  
  
@Autowired  
    private StringRedisTemplate redisTemplate;  
    public boolean acquireLock(String lockKey, String lockValue, long expireTime) {  
        return Boolean.TRUE.equals(redisTemplate.opsForValue()  
                .setIfAbsent(lockKey, lockValue, Duration.ofMillis(expireTime)));  
    }  
    public void releaseLock(String lockKey, String lockValue) {  
        String currentValue = redisTemplate.opsForValue().get(lockKey);  
        if (lockValue.equals(currentValue)) {  
            redisTemplate.delete(lockKey);  
        }  
    }  
}
```
### Usage Example: Preventing Duplicate Order Processing
```java
@Service  
public class OrderService {  
  
@Autowired  
    private RedisLock redisLock;  
    public String processOrder(String orderId) {  
        String lockKey = "order:" + orderId;  
        String lockValue = UUID.randomUUID().toString();  
        long expireTime = 5000; // 5 seconds  
        if (redisLock.acquireLock(lockKey, lockValue, expireTime)) {  
            try {  
                // Process the order  
                return "Order " + orderId + " processed successfully.";  
            } finally {  
                redisLock.releaseLock(lockKey, lockValue);  
            }  
        } else {  
            return "Order " + orderId + " is already being processed.";  
        }  
    }  
}
```
### High Availability with Redis Clustering

For high availability:

-   Deploy Redis in a clustered mode or use Redis Sentinel for failover.
-   Configure Spring Data Redis to connect to the cluster.

Update `application.yml`:
```yml
spring:  
  redis:  
    cluster:  
      nodes:  
        - redis-node1:6379  
        - redis-node2:6379  
        - redis-node3:6379
```
### Best Practices

1.  **Set appropriate TTLs for cache entries:** Avoid stale data.
2.  **Use meaningful keys:** Include identifiers and categories in cache/lock keys.
3.  **Monitor Redis:** Use tools like RedisInsight or Prometheus with Grafana.
4.  **Ensure lock release:** Always release locks in a `finally` block.
5.  **Test high availability:** Simulate node failures in the Redis cluster.

Redis is a cornerstone for building modern, high-performance, distributed applications. Combining caching and distributed locking in Spring Boot enables you to scale seamlessly while maintaining consistency and reliability. Start integrating Redis today and unlock the full potential of your applications!

Would you like to dive deeper into specific aspects like advanced Redis commands or more use cases? Let me know in the comments! 🚀

### Caching Example Output

### 1. First Request (Cache Miss)

When you call the `GET /products/{id}` endpoint for the first time, the application simulates a slow database call (3 seconds delay), and the output looks like this:

**Request:**
```shell
curl http://localhost:8080/products/1
```
**Output (after 3 seconds):**
```json
{  
  "productId": 1,  
  "productName": "Product 1"  
}
```
**Logs:**

Simulating slow service call...  
Returning Product 1

### 2. Subsequent Requests (Cache Hit)

When you make the same request again, the result is returned instantly from the Redis cache:

**Request:**
```shell
curl http://localhost:8080/products/1
```
**Output (instant response):**
```json
{  
  "productId": 1,  
  "productName": "Product 1"  
}
```
**Logs:**

Returning cached data for Product 1

Redis stores the cached value with the key `products::1`.

### Distributed Locking Example Output

Let’s simulate processing an order with distributed locking:

### 1. First Request (Lock Acquired)

When the service processes an order, it acquires a lock:

**Request:**

curl http://localhost:8080/orders/process/12345

**Output:**

Order 12345 processed successfully.

**Logs:**

Lock acquired: order:12345  
Processing order: 12345  
Lock released: order:12345

### 2. Concurrent Request (Lock Denied)

If another instance or request tries to process the same order while the lock is active, it will fail:

**Concurrent Request:**

curl http://localhost:8080/orders/process/12345

**Output:**

Order 12345 is already being processed.

**Logs:**

Failed to acquire lock: order:12345

### Redis Keys Observations

You can monitor the keys in Redis using the `redis-cli` command:

redis-cli KEYS *

**Output:**

1) "products::1"  
2) "order:12345"

### Redis Value Observation

To inspect cached or lock values:

redis-cli GET "products::1"

**Output:**

"{"productId":1,"productName":"Product 1"}"

For the distributed lock key:

redis-cli GET "order:12345"

**Output (UUID of lock):**

"f9a0c2bc-453e-42a2-9d4c-b60c71e1c3b4"

These outputs demonstrate how caching boosts performance and how distributed locking prevents race conditions in critical operations.
--- 
### Spring Boot Redis Cache — @Cacheable Complete Guide

### 🚀 Introduction

Caching is a crucial technique for optimizing application performance by reducing the number of redundant database queries. Spring Boot provides a seamless caching mechanism using the `@Cacheable` annotation, and Redis is one of the most powerful cache providers for handling high-performance caching in distributed applications.

This guide will walk you through implementing **Spring Boot Redis Cache using** `**@Cacheable**`, covering step-by-step setup, integration, and testing.

Imagine you run an **e-commerce application**, and every time a user visits a product page, the system **fetches product details from the database**. If thousands of users request the same product, **database queries skyrocket**, slowing down performance.

**Solution?** ✅ **Spring Boot’s** `**@Cacheable**` **annotation**!

Caching stores frequently accessed data in **memory**, reducing database calls and **boosting performance**. In this guide, we’ll cover how to:

✔ Use `@Cacheable` to store method results  
✔ Configure **Spring Boot caching**  
✔ Implement caching in a **real-world application**

### 1️⃣ What is @Cacheable in Spring Boot?

The `@Cacheable` annotation stores method results in a cache. When the same method is called again with the same parameters, the system returns the cached data instead of executing the method.

✔ **Reduces database calls** by storing frequently accessed data  
✔ **Improves response time** by serving data from memory  
✔ **Works with multiple cache providers** (Redis, Ehcache, Caffeine, etc.)

### 2️⃣ Redis Cache vs In-Memory Cache

![](https://miro.medium.com/v2/resize:fit:875/1*7nso3N6APyST1almkzy4w.png)
Redis Cache vs In-Memory Cache

Redis is the preferred choice for microservices and cloud-based applications due to its **distributed caching capabilities**.

### Real-World Use Case — Caching Product Details in an E-Commerce App

### Scenario:

🔹 A user requests product details from `/api/products/{id}`.  
🔹 The first request fetches data from the **database** and caches it.  
🔹 The next time the same product is requested, the system **returns cached data** instead of querying the database.

### Solution:

-   Use **Spring Boot + Redis Cache** to **cache product details**.
-   Fetch product data from the database **only if it’s not in the cache**.

### 3️⃣ Adding Dependencies for Redis Cache in Spring Boot

To enable Redis caching, add the following dependencies to `pom.xml`:
```xml
<dependency>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-starter-data-redis</artifactId>  
</dependency>  
<dependency>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-starter-cache</artifactId>  
</dependency>
```
These dependencies will allow Spring Boot to integrate with Redis and enable caching functionalities.

### 4️⃣ Enabling Caching in Spring Boot

Spring Boot provides built-in support for caching, which can be enabled using the `@EnableCaching` annotation in the main application class.
```java
@SpringBootApplication  
@EnableCaching  
public class ProductServiceApplication {  
    public static void main(String[] args) {  
        SpringApplication.run(ProductServiceApplication.class, args);  
    }  
}
```

With this setup, Spring Boot will automatically manage caching throughout the application.

### 5️⃣ Configuring Redis Cache in Spring Boot

In `src/main/resources/application.properties`, configure Redis as the cache provider:
```shell
spring.cache.type=redis  
spring.redis.host=localhost  
spring.redis.port=6379  
spring.cache.redis.time-to-live=600000  ### Cache expiration time (10 minutes)
```
Make sure Redis is running locally. If not, you can start a Redis instance using Docker:
```shell
docker run --name redis -d -p 6379:6379 redis
```
### 6️⃣ Implementing @Cacheable in Spring Boot with Redis

### Step 1: Create the Product Entity
```java
@Entity  
public class Product {  
    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    private Long id;  
    private String name;  
    private String description;  
    private double price;  
  
    protected Product() {}  
  
    public Product(Long id, String name, String description, double price) {  
        this.id = id;  
        this.name = name;  
        this.description = description;  
        this.price = price;  
    }  
  
    public Long getId() { return id; }  
    public String getName() { return name; }  
    public String getDescription() { return description; }  
    public double getPrice() { return price; }  
}
```
### Step 2: Create the Product Repository
```java
public interface ProductRepository extends JpaRepository<Product, Long> {  
}
```
### Step 3: Implement Caching in Product Service
```java
@Service  
public class ProductService {  
  
    private final ProductRepository productRepository;  
  
    public ProductService(ProductRepository productRepository) {  
        this.productRepository = productRepository;  
    }  
  
    @Cacheable(value = "products", key = "###id")  
    public Product getProductById(Long id) {  
        System.out.println("Fetching product from DB for ID: " + id);  
        return productRepository.findById(id)  
                .orElseThrow(() -> new RuntimeException("Product not found"));  
    }  
}
```

**How It Works:**

-   The **first request** retrieves the product from the **database** and caches it.
-   Subsequent requests for the **same product ID** return **cached data** instead of hitting the database.

### Step 4: Create REST Controller to Test Caching
```java
@RestController  
@RequestMapping("/api/products")  
public class ProductController {  
  
    private final ProductService productService;  
  
    public ProductController(ProductService productService) {  
        this.productService = productService;  
    }  
  
    @GetMapping("/{id}")  
    public Product getProduct(@PathVariable Long id) {  
        return productService.getProductById(id);  
    }  
}
```
### 7️⃣ Testing Redis Cache with Postman or Curl

### 1️⃣ First Request (No Cache — Fetches from DB)
```shell
curl http://localhost:8080/api/products/1
```
**Console Output:**

Fetching product from DB for ID: 1

### 2️⃣ Second Request (Returns Cached Data — No DB Hit)
```shell
curl http://localhost:8080/api/products/1
```
**Console Output:**

(No DB query - fetched from cache)

### 8️⃣ Handling Cache Eviction When Data Changes

When a product is updated, we need to **clear the cache** to ensure the next request fetches fresh data.
```java
@CacheEvict(value = "products", key = "###id")  
public Product updateProduct(Long id, Product updatedProduct) {  
    Product existingProduct = productRepository.findById(id)  
            .orElseThrow(() -> new RuntimeException("Product not found"));  
    Product newProduct = new Product(id, updatedProduct.getName(), updatedProduct.getDescription(), updatedProduct.getPrice());  
    return productRepository.save(newProduct);  
}
```
**How It Works:**

-   `@CacheEvict` **removes the product from cache** when updated.
-   The next request **fetches fresh data from the database** and caches it again.

### 9️⃣ Additional Caching Annotations

![](https://miro.medium.com/v2/resize:fit:875/1*uHJFsGW6ttYvhxQI3z3ow.png)
Caching Annotations

### 🔟 Conclusion

Spring Boot Redis Cache with `@Cacheable` provides a **powerful caching mechanism** that significantly improves application performance by **reducing database calls**.

✔ **Faster API responses**  
✔ **Lower database load**  
✔ **Easier scalability**

By implementing caching properly, applications can handle **high traffic efficiently** while ensuring **data consistency** with cache eviction strategies.

### ❓ FAQs — Frequently Asked Questions

### 1. What happens if the cache expires?

If a cache entry expires, the next request fetches fresh data from the database and caches it again.

### 2. Can I use @Cacheable without Redis?

Yes, Spring Boot supports other cache providers like **Ehcache, Caffeine, Hazelcast**, or **in-memory caching**.

### 3. When should I use @CacheEvict?

Use `@CacheEvict` when **data is updated** to ensure that stale data is not returned from the cache.
---
# Spring Boot + Redis + Docker: Ultimate Guide to Caching in Java

With Redis, your Spring Boot app can become faster and handle more traffic without breaking a sweat.

This article will show you how to set it up step by step. However, before diving deep into Redis, we need to understand the concept of **caching**.

### What is Cache?

Cache is a fast, small, temporary storage frequently used by the computer or application to store and access important data.

It stores data in a key-value format. By leveraging cache memory, we can minimize database calls, improving application performance since database queries are typically resource-intensive.

**The main objective of a cache is to speed up the retrieval of data by making a copy of the data in a location that can be accessed faster than the source or database.**

**A cache is a small and fast, and efficient memory space that an application frequently uses to store or access important data.**

![](https://miro.medium.com/v2/resize:fit:875/0*yohDE7qOkeX0vRi0.png)

### Why Caching?

The main objective of a cache is to speed up the retrieval of data by making a copy of the data in a location that can be accessed faster than the source or database.

In our application, whenever multiple requests access static data (data that is not changed frequently), we fetch the data from the database every time.

Therefore, the number of database calls increases, which affects the performance of our application because database calls are always costly.

However, the static data can be stored in a cache, and whenever a request is made to access the data, it is fetched from the cache. As a result, the number of database calls is reduced, and the application’s performance is improved.

### How does a Cache work?

In the diagram above, multiple requests made to access the data in the application will first check the cache to determine whether the data is present.

If the data is found, it is returned from the cache, a concept known as a Cache Hit. If the data is not found, it is retrieved from the database, which is referred to as a Cache Miss.

### Cache Hit

**Data is found in the cache, so it has to be fetched from a faster source.**

We can understand the cache hit like this: imagine you have a notebook where you write down answers to questions you frequently ask. You ask a question, and the answer is already written in your notebook. You quickly find it without searching elsewhere.

### Cache Miss

**Data is not found in the cache, so it has to be fetched from a slower source.**

Similarly, you asked a question, but it’s not in your notebook. You have to search in a big textbook (which takes more time) and then write the answer in your notebook for future use.

### Redis

Redis (Remote Dictionary Server) is an open-source, in-memory key-value data store that supports various data structures, including strings, lists, sets, and hashes.

Its in-memory architecture ensures high performance, making it an ideal choice for caching and session management in modern applications.

The **spring-boot-starter-redis** is a Spring Boot starter that simplifies integrating Redis into Spring applications. It includes all the necessary dependencies to connect, configure, and operate with Redis.
```xml
<dependency>  
      <groupId>org.springframework.boot</groupId>  
      <artifactId>spring-boot-starter-data-redis</artifactId>  
</dependency>
```
Spring Boot provides the `spring-boot-starter-redis` starter, enabling seamless communication with the Redis server. It includes various components that facilitate efficient interaction with Redis.

-   **JedisConnectionFactory**: Manages and establishes the connection between the Spring Boot application and the Redis server.
-   **RedisTemplate**: It provides methods to perform operations like saving, retrieving, and deleting data in Redis.
-   **StringRedisTemplate**: A specialized version of `RedisTemplate` that simplifies operations for String-based keys and values.
-   **OpsForValue**: Supports operations on simple key-value pairs in Redis.
-   **OpsForHash**: It provides methods to perform operations based on the Hash Data structure.
-   **OpsForList**: Provides methods to interact with Redis Lists.
-   **OpsForSet**: Facilitates operations on Redis Sets.

### Spring Boot with Redis Integration

Spring Boot provides seamless integration with Redis, an in-memory data store, through the `spring-boot-starter-redis` starter.

It simplifies configuration and enables developers to use Redis for caching, messaging, and data persistence.

**Prerequisites for Running the Spring Boot Redis Integration Project**

-   Redis Server (Local or Cloud-based; here we use Docker)
-   Java Development Kit (JDK 17 or above)
-   Maven (Build tool)
-   IDE (e.g., IntelliJ IDEA, Eclipse, or Spring Tool Suite)
-   Postman (Optional, for testing REST APIs)
-   Project Build Using Maven

### Docker Redis Setup

In this article, we install Redis using Docker. We can also manually download it from the Redis website, but here, we download the [latest Redis image from Docker Hub](https://hub.docker.com//redis/tags) (ensure Docker is already installed on your machine).

We have a sample Spring Boot application that you can [clone from GitHub](https://github.com/ayushstwt/product-api) for initial setup.

The initial code is available in the main branch, so please check out the main or Redis integration branch.

I also added the Postman collection to the root directory of the project so you can test all the API before integration.

### Steps to Integrate Redis with Spring Boot
```xml
<dependency>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-starter-redis</artifactId>  
</dependency>  
  
<dependency>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-docker-compose</artifactId>  
    <scope>runtime</scope>  
</dependency>
```
2. Configure Redis Connection or database connection (we’re using H2 as database). Add the Redis server configuration to `application.properties` or `application.yml`
```shell
spring.application.name=spring-boot-redis-cache  
  
spring.datasource.url=jdbc:h2:mem:testdb  
spring.datasource.driverClassName=org.h2.Driver  
spring.datasource.username=sa  
spring.datasource.password=password  
spring.jpa.database-platform=org.hibernate.dialect.H2Dialect  
  
spring.jpa.show-sql=true  
spring.jpa.properties.hibernate.formatsql=true  
  
spring.cache.type=redis  
spring.data.redis.host=localhost  
spring.data.redis.port=6379  
  
### if we are using local redis or cloud but here we use docker so there is no need of username or password  
spring.data.redis.username=  
spring.data.redis.password=
```
3. Create the `docker-compose.yml` file in the root folder with the same naming convention we follow for docker-redis configurations.
```yml
services:  
  redis:  
    image: redis:7.4.2  
    ports:  
      - 6379:6379
```
4. Mark the Spring Boot application class as `@EnableCaching` to enable caching in our Spring Boot application.

To enable caching in our Spring Boot application, add the `@EnableCaching` annotation to one of our configuration classes. This annotation triggers a post-processor that inspects each Spring bean for caching annotations.
```java
package com.ayshriv.springbootrediscache;  
  
import org.springframework.boot.SpringApplication;  
import org.springframework.boot.autoconfigure.SpringBootApplication;  
import org.springframework.cache.annotation.EnableCaching;  
  
@SpringBootApplication  
@EnableCaching  
public class SpringBootRedisCacheApplication {  
  
    public static void main(String[] args) {  
        SpringApplication.run(SpringBootRedisCacheApplication.class, args);  
    }  
  
}
```
5. Create the class `RedisConfig.class` inside the config package
```java
package com.ayshriv.springbootrediscache.config;  
  
import com.techie.springbootrediscache.dto.ProductDto;  
import org.springframework.context.annotation.Bean;  
import org.springframework.context.annotation.Configuration;  
import org.springframework.data.redis.cache.RedisCacheConfiguration;  
import org.springframework.data.redis.cache.RedisCacheManager;  
import org.springframework.data.redis.connection.RedisConnectionFactory;  
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;  
import org.springframework.data.redis.serializer.RedisSerializationContext;  
  
import java.time.Duration;  
  
@Configuration  // Marks this class as a Spring configuration class  
public class RedisConfig {  
  
    @Bean  // Defines a Spring bean for RedisCacheManager  
    public RedisCacheManager redisCacheManager(RedisConnectionFactory redisConnectionFactory) {  
        // Define cache configuration  
        RedisCacheConfiguration cacheConfig = RedisCacheConfiguration.defaultCacheConfig()  
                .entryTtl(Duration.ofMinutes(10)) // Set time-to-live (TTL) for cache entries to 10 minutes  
                .disableCachingNullValues() // Prevent caching of null values  
                .serializeValuesWith(RedisSerializationContext.SerializationPair  
                        .fromSerializer(new Jackson2JsonRedisSerializer<>(ProductDto.class))); // Serialize values using Jackson JSON serializer  
  
        // Create and return a RedisCacheManager with the specified configuration  
        return RedisCacheManager.builder(redisConnectionFactory)  
                .cacheDefaults(cacheConfig) // Apply default cache configuration  
                .build();  
    }  
}
```
This class configures Redis caching in a Spring Boot application. The `@Configuration` annotation marks it as a configuration class, and the `@Bean` annotation defines a `RedisCacheManager` bean.

The cache configuration includes a time-to-live (TTL) of 10 minutes`(Duration.ofMinutes(10))`, which ensures that cached data expires automatically after this period.

It also disables the caching of `null` values `(disableCachingNullValues())` to optimize memory usage.

For serialization, the `Jackson2JsonRedisSerializer` is used, which converts Java objects `(ProductDto)` to JSON before storing them in Redis. This ensures that cached data remains structured and readable.

The `RedisCacheManager.builder(redisConnectionFactory).cacheDefaults(cacheConfig).build()` the method initializes the cache manager with the given configuration and connects it to the Redis database using `RedisConnectionFactory`.

6. After doing all the configurations, we implement the caching on the business class (service class).
```java
package com.ayshriv.springbootrediscache.service;  
  
import com.techie.springbootrediscache.dto.ProductDto;  
import com.techie.springbootrediscache.entity.Product;  
import com.techie.springbootrediscache.repository.ProductRepository;  
import org.springframework.cache.annotation.CacheEvict;  
import org.springframework.cache.annotation.CachePut;  
import org.springframework.cache.annotation.Cacheable;  
import org.springframework.stereotype.Service;  
  
@Service  
public class ProductService {  
  
    private final ProductRepository productRepository;  
  
    public ProductService(ProductRepository productRepository) {  
        this.productRepository = productRepository;  
    }  
  
    @CachePut(value="PRODUCTCACHE", key="###result.id")  
    public ProductDto createProduct(ProductDto productDto) {  
        var product = new Product();  
        product.setName(productDto.name());  
        product.setPrice(productDto.price());  
  
        Product savedProduct = productRepository.save(product);  
        return new ProductDto(savedProduct.getId(), savedProduct.getName(),  
                savedProduct.getPrice());  
    }  
  
    @Cacheable(value="PRODUCTCACHE", key="###productId")  
    public ProductDto getProduct(Long productId) {  
        Product product = productRepository.findById(productId)  
                .orElseThrow(() -> new IllegalArgumentException("Cannot find product with id " + productId));  
        return new ProductDto(product.getId(), product.getName(),  
                product.getPrice());  
    }  
  
    @CachePut(value="PRODUCTCACHE", key="###result.id")  
    public ProductDto updateProduct(ProductDto productDto) {  
        Long productId = productDto.id();  
        Product product = productRepository.findById(productId)  
                .orElseThrow(() -> new IllegalArgumentException("Cannot find product with id " + productId));  
  
        product.setName(productDto.name());  
        product.setPrice(productDto.price());  
  
        Product updatedProduct = productRepository.save(product);  
        return new ProductDto(updatedProduct.getId(), updatedProduct.getName(),  
                updatedProduct.getPrice());  
    }  
  
    @CacheEvict(value="PRODUCTCACHE", key="###productId")  
    public void deleteProduct(Long productId) {  
        productRepository.deleteById(productId);  
    }  
}
```

When we mark the `createProduct()` method with this `@CachePut(value = "PRODUCTCACHE", key = "###result.id")`annotation, this ensures that the object returned by this method is stored or updated in the cache named `PRODUCTCACHE`, and the key part specifies that the cache key should be the ID of the returned `ProductDto` object.

This is useful in scenarios where a new product is created or an existing product is updated, as it ensures that the latest product details are stored in the cache.

By using this annotation, subsequent requests for the same product can be served quickly from the cache, **reducing database queries and improving application performance** while keeping the cache up to date.

Next, when we mark the `getProductById()` method with this `@Cacheable(value = "PRODUCTCACHE", key = "###productId")`annotation.

This ensures that the returned object by this method is **stored in the cache** named `"PRODUCTCACHE"`, and the `key` The part specifies that the cache key should be the `productId` parameter passed to the method.

If the requested `productId` is already present in the cache, the method **skips execution** and directly returns the cached value, avoiding a database call.

However, if the `productId` is not found in the cache, the method executes, retrieves the product from the database, **stores the result in the cache**, and then returns it.

When we mark the `deleteProduct()` method with this `@CacheEvict(value = "PRODUCTCACHE", key = "###productId")`annotation, this ensures that the **cache entry associated with the given** `productId` **is removed** from the cache named `"PRODUCTCACHE"`.

The `key` part specifies that the cache key to be evicted is the `productId` parameter passed to the method.

This means that after deleting a product from the database, its cached entry will also be removed, ensuring that **stale data is not served from the cache** in future requests.

If the deleted product is requested again, it will be fetched from the database and re-cached if applicable.

Here, we do all the things with the help of the annotation-based approach, but we can also do the same things with the help of `CacheManager`

The `CacheManager` It is a **Spring framework interface** responsible for managing different cache implementations. It acts as a central mechanism to store, retrieve, and manage cached data efficiently.
```java
private final CacheManager cacheManager;  
  
public ProductDto createProduct(ProductDto productDto) {  
        var product = new Product();  
        product.setName(productDto.name());  
        product.setPrice(productDto.price());  
  
        Product savedProduct = productRepository.save(product);  
        Cache productCache = cacheManager.getCache("PRODUCTCACHE");  
        productCache.put(savedProduct.getId(), savedProduct);  
          
        return new ProductDto(savedProduct.getId(), savedProduct.getName(),  
                savedProduct.getPrice());  
    }
```
### Test the application

1. ADD-PRODUCT: [http://localhost:8080/api/product](http://localhost:8080/api/product)

![](https://miro.medium.com/v2/resize:fit:875/0*UCtnpC420IQrLQQm.png)

2. GET-PRODUCT: [http://localhost:8080/api/product/3](http://localhost:8080/api/product/3)

![](https://miro.medium.com/v2/resize:fit:875/0*viuT-N6ao3pefTib.png)

3. UPDATE PRODUCT: [http://localhost:8080/api/product](http://localhost:8080/api/product)

![](https://miro.medium.com/v2/resize:fit:875/0*odEkiHChgtKZo-JE.png)

4. DELETE PRODUCT: [http://localhost:8080/api/product/2](http://localhost:8080/api/product/2)

![](https://miro.medium.com/v2/resize:fit:875/0*vIXvXXWW8Fxclbd.png)

### Conclusion

Redis with Spring Boot makes apps faster by caching data and reducing database calls. Using `@Cacheable`, `@CachePut`, and `@CacheEvict,` We can easily store, update, and delete cached data. This improves speed, reduces server load, and helps the app handle more users smoothly.

When we are performing the create operation, the response of this operation is stored in the cache, so whenever we perform operations like the `getProduct()` It checks the product in the cache first; if the product is present inside the cache, it returns that; if not, then it will return from the database.

Similarly, when we perform the delete operation, it first deletes the data from the database and then deletes it from the cache as well. All these types of operations reduce the number of DB calls, so the performance of the application is increased.

---
# Spring Boot 3,Redis Sentinel,Lettuce client and Docker Compose for High availability
### What is Redis?

[Redis](https://redis.io/) (“REmote DIctionary Service”) is an open-source key-value database server.

The most accurate description of Redis is that it’s a data structure server. This specific nature of Redis has led to much of its popularity and adoption amongst developers.

### Redis Sentinel

### What is Redis Sentinel?

Redis Sentinel is the high-availability solution for open-source Redis server. It provides monitoring of all Redis nodes and automatic failover should the master node become unavailable. This guide provides a sample configuration for a three-node Redis cluster. For additional details, see the official documentation [here](https://redis.io/topics/sentinel).

-   [**Monitoring**](https://cloudinfrastructureservices.co.uk/best-open-source-monitoring-tools/)**:** This is basically when sentinel checks if the master and slave instances are working as expected.
-   **Notification:** This is when the sentinel notifies other programs or other system administrators via an API when there is something wrong with the monitoring instances.
-   **Automatic Failover:** On a master failure, the sentinel promotes one of the slaves to become the new master and then makes the other additional slaves use the new master.

![](https://miro.medium.com/v2/resize:fit:661/1*DPZQk6jLmaMvcKNnjifFaw.png)

### Configuration

We will run 1 master,1 slave and 3 sentinel instance.

### What is Quorum ?

-   The quorum is the number of Sentinels that need to agree about the fact the master is not reachable, in order to really mark the master as failing, and eventually start a failover procedure if possible.
-   However the quorum is only used to detect the failure. In order to actually perform a failover, one of the Sentinels need to be elected leader for the failover and be authorized to proceed. This only happens with the vote of the majority of the Sentinel processes.
-   `REDISSENTINELQUORUM`: Number of Sentinels that need to agree about the fact the master is not reachable. Default: 2.

Here is docker-compose file
```yml
version: '3.8'  
services:  
  redis-master:  
    containername: redis-master  
    image: 'bitnami/redis:latest'  
    environment:  
      - REDISREPLICATIONMODE=master  
      - REDISPASSWORD=redispassword  
    ports:  
      - "6379:6379"  
  redis-slave:  
    containername: slave-redis  
    image: 'bitnami/redis:latest'  
    environment:  
      - REDISREPLICATIONMODE=slave  
      - REDISMASTERHOST=redis-master  
      - REDISMASTERPASSWORD=redispassword  
      - REDISPASSWORD=redispassword  
    ports:  
      - "7000:6379"  
    dependson:  
      - redis-master  
  redis-sentinel-1:  
    image: 'bitnami/redis-sentinel:latest'  
    containername: sentinel-1  
    environment:  
      - REDISMASTERSET=mymaster  
      - REDISMASTERHOST=127.0.0.1  
      - REDISMASTERPASSWORD=redispassword  
      - REDISSENTINELDOWNAFTERMILLISECONDS=10000  
    dependson:  
      - redis-master  
      - redis-slave  
    ports:   
       - "26379:26379"  
  redis-sentinel-2:  
    image: 'bitnami/redis-sentinel:latest'  
    containername: sentinel-2  
    environment:  
      - REDISMASTERSET=mymaster  
      - REDISMASTERHOST=127.0.0.1  
      - REDISMASTERPASSWORD=redispassword  
      - REDISSENTINELDOWNAFTERMILLISECONDS=10000  
    dependson:  
      - redis-master  
      - redis-slave  
    ports:   
      - "26380:26379"  
  redis-sentinel-3:  
    image: 'bitnami/redis-sentinel:latest'  
    containername: sentinel-3  
    environment:  
      - REDISMASTERSET=mymaster  
      - REDISMASTERHOST=127.0.0.1  
      - REDISMASTERPASSWORD=redispassword  
      - REDISSENTINELDOWNAFTERMILLISECONDS=10000  
    dependson:  
      - redis-master  
      - redis-slave  
    ports:   
      - "26381:26379"
```
Just use the script for run
```shell
 `docker-compose up -d`
```
### Lettuce Client and Spring Boot

Lettuce is a scalable thread-safe Redis client for synchronous, asynchronous and reactive usage. Multiple threads may share one connection if they avoid blocking and transactional operations such as `BLPOP` and `MULTI`/`EXEC`. Lettuce is built with [netty](https://github.com/netty/netty). Supports advanced Redis features such as Sentinel, Cluster, Pipelining, Auto-Reconnect and Redis data models.

### Configuration

Firstly,add the maven dependency of Spring Data Redis to my pom.
```xml
<dependency>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-starter-data-redis</artifactId>  
</dependency>
```
Then, continue with the YAML file and I add my connection information that I will use for configuration.

**Before the spring boot 3** : @ConfigurationProperties(prefix = “spring.redis”)

**After the spring boot 3**: @ConfigurationProperties(prefix = “spring.data.redis”)
```yml
server:  
  port: 2000  
    
spring:  
  application:  
    name: spring-redis-sentinel  
  data:  
    redis:  
      password: redispassword  
      sentinel:  
        master: mymaster  
        nodes:  
          - 127.0.0.1:26379  
          - 127.0.0.1:26380  
          - 127.0.0.1:26381  
      lettuce:  
        shutdown-timeout: 200ms
```
Create a connection configuration `RedisConfig.java` using `LettuceConnectionFactory`

### ReadFrom

MASTER: Setting to read from the upstream only.

MASTERPREFERRED: Setting to read preferred from the upstream and fall back to a replica if the master is not available.

UPSTREAM: Setting to read from the upstream only.

UPSTREAMPREFERRED: Setting to read preferred from the upstream and fall back to a replica if the upstream is not available.

REPLICAPREFERRED: Setting to read preferred from replicas and fall back to upstream if no replica is available.

REPLICA: Setting to read from the replica only.

ANY: Setting to read from any node.

**We are using REPLICAPREFERRED in here but this configuration can be important in production!**

RedisUtil Configuration

### Conclusion

Thank you for reading :)

https://github.com/tugayesilyurt/spring-boot-3-redis-sentinel-with-lettuce.git

```java
@RequiredArgsConstructor
@Configuration
public class RedisConfig {

    private final RedisProperties redisProperties;

    @Bean
    protected LettuceConnectionFactory redisConnectionFactory() {

      LettuceClientConfiguration clientConfig = LettuceClientConfiguration.builder()
              .readFrom(ReadFrom.REPLICAPREFERRED)
              .build();

      RedisSentinelConfiguration sentinelConfig = new RedisSentinelConfiguration()
                .master(redisProperties.getSentinel().getMaster());

      redisProperties.getSentinel().getNodes().forEach(s -> 
              sentinelConfig.sentinel(s.split(":")[0],Integer.valueOf(s.split(":")[1])));

      sentinelConfig.setPassword(RedisPassword.of(redisProperties.getPassword()));
      return new LettuceConnectionFactory(sentinelConfig, clientConfig);
  }

  @Bean
  public RedisTemplate<String, Object> redisTemplate() {
      final RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
      redisTemplate.setKeySerializer(new StringRedisSerializer());
      redisTemplate.setHashKeySerializer(new GenericToStringSerializer<>(Object.class));
      redisTemplate.setHashValueSerializer(new JdkSerializationRedisSerializer());
      redisTemplate.setValueSerializer(new StringRedisSerializer());
      redisTemplate.setConnectionFactory(redisConnectionFactory());
      return redisTemplate;
  }
}
```
[view raw](https://gist.github.com/tugayesilyurt/7186defbb3143455325b996e45da20ca/raw/66ece233871d7bbaa58f9778fbf6156ba9d4aff5/RedisConfig) [RedisConfig](https://gist.github.com/tugayesilyurt/7186defbb3143455325b996e45da20ca###file-redisconfig) hosted with ❤ by [GitHub](https://github.com)
```java
@Component
public class RedisUtil<T> {

  private RedisTemplate<String, T> redisTemplate;
  private ValueOperations<String, T> valueOperations;

  @Autowired
  public RedisUtil(RedisTemplate<String, T> redisTemplate) {
      this.redisTemplate = redisTemplate;
      this.valueOperations = redisTemplate.opsForValue();
  }

  public void putValue(String key, T value) {
      valueOperations.set(key, value);
  }

  public T getValue(String key) {
      return valueOperations.get(key);
  }

  public void setExpire(String key, long timeout, TimeUnit unit) {
    redisTemplate.expire(key, timeout, unit);
  }
}
```
[view raw](https://gist.github.com/tugayesilyurt/a26dec067cdce3b884f9d98e9e0c9f41/raw/85f8dde0dc0ac799f31ade4539b3a05bf4ca402a/RedisUtil.class) [RedisUtil.class](https://gist.github.com/tugayesilyurt/a26dec067cdce3b884f9d98e9e0c9f41###file-redisutil-class) hosted with ❤ by [GitHub](https://github.com)
---
# Distributed lock with Redisson RLock and Spring Boot — Redis pub/sub 

### What is Redis pub/sub ?

Redis Pub/Sub implements the messaging system where the senders (in redis terminology called publishers) sends the messages while the receivers (subscribers) receive them. The link by which the messages are transferred is called **channel**.

In Redis, a client can subscribe any number of channels.

You can find more information about redis pub/sub in [here](https://redis.io/docs/manual/pubsub/).

![](https://miro.medium.com/v2/resize:fit:875/1*CwnsXZyuSKH3i52GUXZpw.jpeg)

### What is Distributed Lock ?

Distributed locking is a technique to manage many applications that try to access the same resource. The main purpose is to allow only one of many applications to access the same resource at the same time. Otherwise, accessing the same object from various applications may corrupt the value of the resources.

Distributed locks are useful in any situation in which multiple systems may operate on the same state concurrently. Concurrent modifications may corrupt the state, so one needs a mechanism to ensure that only one system can modify the state at the same time.

**Let’s talk about a scenario**

You have update stock microservice and two different client want to use same resource at the same time.You have only 1 available stock but two different client want to buy the same product ?

We will solve this race condition with Redisson RLock.

![](https://miro.medium.com/v2/resize:fit:723/1*Q0plV-bWzrxBjg3eUN2ZWQ.png)

**Start the coding example**

Just use the script for run

-   `docker-compose up -d`
```yml
version: '3.8'  
services:  
  
  redis-master:  
    containername: redis-master  
    image: 'bitnami/redis:latest'  
    environment:  
      - REDISAOFENABLED=yes  
      - ALLOWEMPTYPASSWORD=yes  
    ports:  
      - "6379:6379"  
    volumes:  
      - ./redis/data:/bitnami/redis/data  
  
  mysql-database:  
    image: mysql:latest  
    containername: mysql-test  
    ports:  
      - "3306:3306"  
    restart: always  
    environment:  
      MYSQLDATABASE: lock  
      MYSQLUSER: admin  
      MYSQLPASSWORD: 123456  
      MYSQLROOTPASSWORD: 123456     
    command: --character-set-server=utf8 --collation-server=utf8generalci  
    volumes:  
      - mysql-data:/var/lib/mysql  
    networks:   
      - test-network   
        
volumes:  
  mysql-data:  
      driver: local  
        
networks:   
  test-network:  
    driver: bridge
```
We will use Redisson client for distributed lock.So fistly add to pom.xml redisson client.
```xml
  <!-- https://mvnrepository.com/artifact/org.redisson/redisson -->  
<dependency>  
   <groupId>org.redisson</groupId>  
   <artifactId>redisson</artifactId>  
   <version>3.17.6</version>  
</dependency>
```
You can find more information about [Redisson](https://redisson.org/glossary/java-distributed-lock.html)

Here is a basic configuration Redisson client:

RedisListenerConfig for subscriber :

We will send a message to channel and consume with two different subscriber at the same time.

**Publisher :**

**Subscriber :**

One of the subscribers will lock the key.  
Only this subscriber can update the stock. Other one will try after 2 seconds.
```java
RLock lock = redisson.getLock("update-stock-lock");  
lock.lock(4, TimeUnit.SECONDS);  
lock.unlock();
```

**TTL :** Time-to-live (TTL) is a value for the period of time that a packet, or data, should exist on a computer or network before being discarded.

**isHeldByCurrentThread :** Checks if this lock is held by the current thread

**isLocked :** Checks if this lock locked by any thread

**DON’T FORGET THE USE TTL !!**

The key can be locked forever if we don’t use TTL.That’s so important !!

We handled race condition and to ensure the data consistency !!

Commonly used storage for distributed locks are ( you can also use another one ) :

-   Redis
-   MySQL
-   ZooKeeper
-   ETCD

### Conclusion

Thank you for reading :)

You can find the full source code of this demo project on my [github](https://github.com/tugayesilyurt/spring-redis-pubsub-distributed-lock)

Happy Coding!


```java
@RequiredArgsConstructor
@Configuration
public class RedissonConfig {

@Bean
public RedissonClient redissionClient() {
  Config config = new Config();
  config.useSingleServer().setAddress("redis://127.0.0.1:6379");
  return Redisson.create(config);
}

@Bean
public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory redisConnectionFactory) {
    RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
    redisTemplate.setConnectionFactory(redisConnectionFactory);
    redisTemplate.setKeySerializer(new StringRedisSerializer());
    redisTemplate.setHashKeySerializer(new StringRedisSerializer());
    redisTemplate.setHashKeySerializer(new JdkSerializationRedisSerializer());
    redisTemplate.setValueSerializer(new JdkSerializationRedisSerializer());
    redisTemplate.setEnableTransactionSupport(true);
    redisTemplate.afterPropertiesSet();
    return redisTemplate;
}

}
```
[view raw](https://gist.github.com/tugayesilyurt/db7d24963d85bd4a5651943fc0047989/raw/b82460a942efb2bc5af6b955eb279b4438fbf0e4/RedissonConfig) [RedissonConfig](https://gist.github.com/tugayesilyurt/db7d24963d85bd4a5651943fc0047989###file-redissonconfig) hosted with ❤ by [GitHub](https://github.com)

---
```java
@RequiredArgsConstructor
@Configuration
public class RedisListenerConfig {
private final RedisMessageSubscriber redisMessageSubscriber;

  @Bean
  MessageListenerAdapter messageListener() {
      return new MessageListenerAdapter(redisMessageSubscriber);
  }

  @Bean
  public RedisMessageListenerContainer redisMessageListenerContainer(RedisConnectionFactory redisConnectionFactory) {
        RedisMessageListenerContainer mlc = new RedisMessageListenerContainer();
        mlc.setConnectionFactory(redisConnectionFactory);
        mlc.addMessageListener(new MessageListenerAdapter(redisMessageSubscriber), new ChannelTopic("update-stock"));
        return mlc;
    }
}
```
[view raw](https://gist.github.com/tugayesilyurt/3b04c88ff35d2f08015afffa09a3a34a/raw/bafc300b390707bb805150fd3456f62e07737096/RedisListenerConfig) [RedisListenerConfig](https://gist.github.com/tugayesilyurt/3b04c88ff35d2f08015afffa09a3a34a###file-redislistenerconfig) hosted with ❤ by [GitHub](https://github.com)

---
```java
@Scheduled(fixedRate = 30000)
public void publish() throws JsonProcessingException {
    ProductRequest product = ProductRequest.builder().productName("lock-product").build();
    String json = mapper.writeValueAsString(product);
    this.redisTemplateString.convertAndSend("update-stock", json);
    this.redisTemplateString.opsForValue().set("update-stock", json);
    log.info("Message Send : " + product.getProductName());
}
```
[view raw](https://gist.github.com/tugayesilyurt/3829ae4677dea6c41e5ef0b55d3de355/raw/02c55b286ba79c6b58d1f388c002102848e1962f/Publisher) [Publisher](https://gist.github.com/tugayesilyurt/3829ae4677dea6c41e5ef0b55d3de355###file-publisher) hosted with ❤ by [GitHub](https://github.com)

---
```java
@Service
@Slf4j
@RequiredArgsConstructor
public class ProductService {
private final RedissonClient redisson;
private final ProductRepository productRepository;
private ObjectMapper mapper = new ObjectMapper();
//USE RETRY IF THE CURRENT THREAD DIDN'T GET THE LOCK
@Retryable(value = org.redisson.client.RedisTimeoutException.class, maxAttempts = 2, backoff = @Backoff(delay = 2000))
public void updateStock(final Message message) {

    //GET LOCK WITH THE KEY
    RLock lock = redisson.getLock("update-stock-lock");
    try {
        //USE TTL
        lock.lock(4, TimeUnit.SECONDS);
        log.info("RedissonClient Lock By : Subscriber ONE");
        String body = new String(message.getBody(), StandardCharsets.UTF8);
        ProductRequest requestProduct=null;
    try {
        requestProduct = mapper.readValue(body, ProductRequest.class);
    } catch (JsonProcessingException e) {
        e.printStackTrace();
    }

    Optional<Product> product = productRepository.findByProductName(requestProduct.getProductName());

      if (product.isPresent()) {
          product.get().setStock(product.get().getStock() > 1 ? product.get().getStock() - 1 : 0);
          product.get().setLastUpdateBy("SUBSCRIBER ONE");
          productRepository.save(product.get());
      }
    } finally {

        //isHeldByCurrentThread - Checks if this lock is held by the current thread
        if (lock != null && lock.isLocked() && lock.isHeldByCurrentThread()) {
            lock.unlock();
            log.info("lock released by ONE");
        }
      }
    }
}
```
[view raw](https://gist.github.com/tugayesilyurt/b816374b92b721f74d20bf31008a9b42/raw/b6a21c29cb2b0fa23addbe19930b03a48c4b3c1d/Subscriber) [Subscriber](https://gist.github.com/tugayesilyurt/b816374b92b721f74d20bf31008a9b42###file-subscriber) hosted with ❤ by [GitHub](https://github.com)

---
# Redis Search with Spring Boot and Redis OM (@Searchable, @Indexed, TTL) +
In this article, I will discuss Full Text Search and caching with Redis OM.

### What is Redis OM?

[Redis Object Model (Redis OM) is a powerful tool for managing data in Redis. It gives developers access to a high-level, object-oriented API for working with Redis data and makes it simple for them to carry out challenging data operations.](https://www.analyticsvidhya.com/blog/2023/01/introduction-to-redis-om-in-python/###:~:text=Redis%20Object%20Model%20(Redis%20OM,carry%20out%20challenging%20data%20operations.)

### Annotations

`**@Indexed**`[In the index schema, a search field will be added for each @Indexed annotated property.](https://redis.io/docs/connect/clients/om-clients/stack-spring/###indexed-and-searchable:~:text=In%20the%20index%20schema%2C%20a%20search%20field%20will%20be%20added%20for%20each%20%40Indexed%20annotated%20property.)

`**@Searchable**`This annotation provide Full-Text search.

### **Docker Compose**
```yml
version: '3'  
services:  
  
  redis:  
    image: redis/redis-stack  
    containername: redis  
    ports:  
      - 6379:6379  
  
  redis-insight:  
    image: redislabs/redisinsight  
    containername: redis-insight  
    ports:  
      - 8001:8001
```
Run following **command**:
```shell
docker-compose up -d
```
### Redis Insight

[RedisInsight is a powerful tool for visualizing and optimizing data in Redis or Redis Stack, making real-time application development easier and more fun than ever before. RedisInsight lets you do both GUI- and CLI-based interactions in a fully-featured desktop GUI client.](https://redis.io/docs/connect/insight/###:~:text=RedisInsight%20is%20a%20powerful%20tool,fully-featured%20desktop%20GUI%20client.)

> Visit: [http://localhost:8001](http://37.247.101.96:8001)

1.  Click the `**“I already have a database”**` button

![](https://miro.medium.com/v2/resize:fit:875/1*7wJmKLbbMScq4yblCbEwow.png)

2. Click the `**“Connect to a Redis Database”**` **button**

![](https://miro.medium.com/v2/resize:fit:875/1*KDREkiAS43wz98d4QLSOw.png)

3. Fill the form.

![](https://miro.medium.com/v2/resize:fit:875/1*35RYOkfjn-6t4IgbkoVR2Q.png)

-   `**redis**` : Docker Compose service name.
-   `**6379**` : Redis Stack docker port.

4. Click the `**redis-db**`box.

![](https://miro.medium.com/v2/resize:fit:875/1*xtSLUWZ78fB9d6uyyl2gA.png)

4. Click the `**“Browser”**` tab.

![](https://miro.medium.com/v2/resize:fit:875/1*2bcg8UMWOtYQUcHEzGydg.png)

### Spring Boot Application

### Dependencies

`**Spring Version**`: 3.1.2  
`**Java Version**`: 17

. pom.xml
```xml
  <properties>  
    <java.version>17</java.version>  
  </properties>  
  <dependencies>  
  
    <dependency>  
      <groupId>org.springframework.boot</groupId>  
      <artifactId>spring-boot-starter-web</artifactId>  
    </dependency>  
  
    <dependency>  
      <groupId>org.projectlombok</groupId>  
      <artifactId>lombok</artifactId>  
      <optional>true</optional>  
      <version>1.18.30</version>  
    </dependency>  
  
    <dependency>  
      <groupId>com.redis.om</groupId>  
      <artifactId>redis-om-spring</artifactId>  
      <version>0.8.6</version>  
    </dependency>  
  
    <dependency>  
      <groupId>org.springframework.boot</groupId>  
      <artifactId>spring-boot-starter-test</artifactId>  
      <scope>test</scope>  
    </dependency>  
  
  </dependencies>  
  
  <build>  
    <plugins>  
      <plugin>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-maven-plugin</artifactId>  
        <configuration>  
          <excludes>  
            <exclude>  
              <groupId>org.projectlombok</groupId>  
              <artifactId>lombok</artifactId>  
            </exclude>  
          </excludes>  
        </configuration>  
      </plugin>  
    </plugins>  
  </build>
```
### PostRepository
```java
@Repository  
public interface PostRepository extends RedisDocumentRepository<Post, String> {  
  
    Iterable<Post> findByClapCountBetween(int minClap, int maxClap);  
  
    Iterable<Post> findByAuthorNameAndAndAuthorLastName(String name, String lastName);  
  
    // Full text search  
    Iterable<Post> searchByContent(String text);  
  
    Iterable<Post> findByCommentsContent(String content);  
  
}
```
### Models

-   **Post**
```java
@Document  
@Builder  
@Data  
@NoArgsConstructor  
@AllArgsConstructor  
public class Post {  
  
    @Id  
    private String id;  
  
    @Indexed  
    private String title;  
  
    @Searchable  
    private String content;  
  
    @Indexed  
    private int clapCount;  
  
    @Indexed  
    private Author author;  
  
    @Indexed  
    private Set<Comment> comments;  
  
    @Indexed  
    private Date createdDate;  
  
    @TimeToLive  
    private long ttl;  
}
```
-   **Comment**
```java
@Builder  
@Data  
@NoArgsConstructor  
@AllArgsConstructor  
public class Comment {  
  
    @Searchable(nostem = true)  
    private String content;  
}
```

`**nostem = true:**` [Determines whether to use stemming, in other words adding the stem of the word to the index, setting to true will stop the Redis from indexing the stems of words.](https://developer.redis.com/develop/dotnet/redis-om-dotnet/searching/creating-an-index/###:~:text=Determines%20whether%20to%20use%20stemming%2C%20in%20other%20words%20adding%20the%20stem%20of%20the%20word%20to%20the%20index%2C%20setting%20to%20true%20will%20stop%20the%20Redis%20from%20indexing%20the%20stems%20of%20words)

-   **Author**
```java
@Builder  
@Data  
@NoArgsConstructor  
@AllArgsConstructor  
public class Author {  
  
    @Indexed  
    private String name;  
  
    @Indexed  
    private String lastName;  
}
```
### PostController
```java
@RestController  
@RequestMapping("/api/v1/posts")  
public class PostController {  
  
    private final PostRepository postRepository;  
  
    public PostController(PostRepository postRepository) {  
        this.postRepository = postRepository;  
    }  
  
    @GetMapping(path = "")  
    public Iterable<Post> searchPostByContent(@RequestParam String text) {  
        return postRepository.searchByContent(text);  
    }  
}
```
### SpringRedisOm Application Main Class
```java
@SpringBootApplication  
@EnableRedisDocumentRepositories(basePackages = "com.example.redisom*")  
public class SpringRedisOm {  
    Logger logger = LoggerFactory.getLogger(SpringRedisOm.class);  
  
    public static void main(String[] args) {  
        SpringApplication.run(SpringRedisOm.class, args);  
    }  
  
    @Bean  
    CommandLineRunner runner(PostRepository repo) {  
        return args -> {  
  
            repo.deleteAll();  
  
            var now = new Date();  
  
            var author1 = Author.builder().name("mert").lastName("cakmak").build();  
            var author2 = Author.builder().name("admin").lastName("admin").build();  
  
            String content1 = "Redis OM Spring provides powerful repository and custom object-mapping abstractions built on top of the Spring Data Redis (SDR) framework.";  
            var post1 = Post.builder().clapCount(50).title("What is Redis OM?").content(content1).comments(Set.of(Comment.builder().content("nice content").build())).createdDate(now).author(author1).ttl(100L).build();  
            repo.save(post1);  
  
            String content2 = "Java Spring Framework (Spring Framework) is a popular, open source, enterprise-level framework for creating standalone, production-grade applications that run on the Java Virtual Machine (JVM).";  
            var post2 = Post.builder().clapCount(60).title("What is Spring Boot?").content(content2).comments(Set.of(Comment.builder().content("so cool").build(), Comment.builder().content("good post").build())).createdDate(now).author(author2).ttl(100L).build();  
            repo.save(post2);  
  
            logger.info("Save operations are successfully.");  
  
            var postsByClapCount = repo.findByClapCountBetween(45, 55);  
            logger.info("postsByClapCount: {}", postsByClapCount.toString());  
  
            var postsByAuthor = repo.findByAuthorNameAndAndAuthorLastName(author2.getName(), author2.getLastName());  
            logger.info("postsByAuthor: {}", postsByAuthor.toString());  
  
            var postsSeachByContent = repo.searchByContent("open source");  
            logger.info("postsSeachByContent: {}", postsSeachByContent.toString());  
  
            var postsByCommentContent = repo.findByCommentsContent("so cool");  
            logger.info("postsByCommentContent: {}", postsByCommentContent.toString());  
  
        };  
    }  
  
}
```
`**@EnableRedisDocumentRepositories:**` Scan for `@Document` annotated Spring models.

### Run the Application

-   **Console Logs**

![](https://miro.medium.com/v2/resize:fit:875/1*dsKxYp7xQXR6BQ3OeANJg.png)

    .  
    .  
    .  
2023-11-29T17:32:55.232+03:00  INFO 25308 --- [           main] com.example.redisom.SpringRedisOm        : Save operations are successfully.  
2023-11-29T17:32:55.268+03:00  INFO 25308 --- [           main] com.example.redisom.SpringRedisOm        : postsByClapCount: [Post(id=01HGDQYHAMP22DABAMSDF6X5ZK, title=What is Redis OM?, content=Redis OM Spring provides powerful repository and custom object-mapping abstractions built on top of the Spring Data Redis (SDR) framework., clapCount=50, author=Author(name=mert, lastName=cakmak), comments=[Comment(content=nice content)], createdDate=Wed Nov 29 17:32:54 TRT 2023, ttl=100)]  
2023-11-29T17:32:55.302+03:00  INFO 25308 --- [           main] com.example.redisom.SpringRedisOm        : postsByAuthor: [Post(id=01HGDQYHJEBR70MPBRBC0KZP92, title=What is Spring Boot?, content=Java Spring Framework (Spring Framework) is a popular, open source, enterprise-level framework for creating standalone, production-grade applications that run on the Java Virtual Machine (JVM)., clapCount=60, author=Author(name=admin, lastName=admin), comments=[Comment(content=so cool), Comment(content=good post)], createdDate=Wed Nov 29 17:32:54 TRT 2023, ttl=100)]  
2023-11-29T17:32:55.334+03:00  INFO 25308 --- [           main] com.example.redisom.SpringRedisOm        : postsSeachByContent: [Post(id=01HGDQYHJEBR70MPBRBC0KZP92, title=What is Spring Boot?, content=Java Spring Framework (Spring Framework) is a popular, open source, enterprise-level framework for creating standalone, production-grade applications that run on the Java Virtual Machine (JVM)., clapCount=60, author=Author(name=admin, lastName=admin), comments=[Comment(content=so cool), Comment(content=good post)], createdDate=Wed Nov 29 17:32:54 TRT 2023, ttl=100)]  
2023-11-29T17:32:55.355+03:00  INFO 25308 --- [           main] com.example.redisom.SpringRedisOm        : postsByCommentContent: [Post(id=01HGDQYHJEBR70MPBRBC0KZP92, title=What is Spring Boot?, content=Java Spring Framework (Spring Framework) is a popular, open source, enterprise-level framework for creating standalone, production-grade applications that run on the Java Virtual Machine (JVM)., clapCount=60, author=Author(name=admin, lastName=admin), comments=[Comment(content=so cool), Comment(content=good post)], createdDate=Wed Nov 29 17:32:54 TRT 2023, ttl=100)]  
2023-11-29T17:33:04.225+03:00  INFO 25308 --- [nio-8080-exec-1] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring DispatcherServlet 'dispatcherServlet'  
2023-11-29T17:33:04.225+03:00  INFO 25308 --- [nio-8080-exec-1] o.s.web.servlet.DispatcherServlet        : Initializing Servlet 'dispatcherServlet'  
2023-11-29T17:33:04.226+03:00  INFO 25308 --- [nio-8080-exec-1] o.s.web.servlet.DispatcherServlet        : Completed initialization in 1 ms

-   **Redis Insight**

![](https://miro.medium.com/v2/resize:fit:875/1*iYdF6G5XvuXVN0GOzK8qQ.png)

### Send HTTP Request

> [GET]
> 
> [http://localhost:8080/api/v1/posts?content=open%20source](http://127.0.0.1:8080/api/v1/posts?text=open+source)
```json
[  
  {  
    "id": "01HGDQYHJEBR70MPBRBC0KZP92",  
    "title": "What is Spring Boot?",  
    "content": "Java Spring Framework (Spring Framework) is a popular, open source, enterprise-level framework for creating standalone, production-grade applications that run on the Java Virtual Machine (JVM).",  
    "clapCount": 60,  
    "author": {  
      "name": "admin",  
      "lastName": "admin"  
    },  
    "comments": [  
      {  
        "content": "so cool"  
      },  
      {  
        "content": "good post"  
      }  
    ],  
    "createdDate": "2023-11-29T14:32:54.853+00:00",  
    "ttl": 100  
  }  
]
```
### GitHub Repository:

[https://github.com/mertcakmak2/Medium-Stories-Projects/tree/master/spring-redis-om](https://github.com/mertcakmak2/Medium-Stories-Projects/tree/master/spring-redis-om)

### References:

[https://github.com/redis/redis-om-spring](https://github.com/redis/redis-om-spring)

[https://redis.io/docs/connect/clients/om-clients/stack-spring/](https://redis.io/docs/connect/clients/om-clients/stack-spring/)

[https://developer.redis.com/develop/java/spring/redis-om/redis-om-spring-hash/](https://developer.redis.com/develop/java/spring/redis-om/redis-om-spring-hash/)

[https://developer.redis.com/develop/java/redis-and-spring-course/lesson4/](https://developer.redis.com/develop/java/redis-and-spring-course/lesson4/)

[https://refactorfirst.com/spring-boot-with-redis-stack-and-redis-insight](https://refactorfirst.com/spring-boot-with-redis-stack-and-redis-insight)

[https://stackoverflow.com/questions/53121627/unable-to-get-result-from-the-redis-using-crud-repository-in-spring-boot](https://stackoverflow.com/questions/53121627/unable-to-get-result-from-the-redis-using-crud-repository-in-spring-boot)

[https://github.com/redis-developer/redis-om-spring-skeleton-app](https://github.com/redis-developer/redis-om-spring-skeleton-app)

[https://stackoverflow.com/questions/42577222/spring-data-redis-global-ttl-for-all-entities](https://stackoverflow.com/questions/42577222/spring-data-redis-global-ttl-for-all-entities)

[https://stackoverflow.com/questions/77171270/compilation-error-after-upgrading-to-jdk-21-nosuchfielderror-jcimport-does-n](https://stackoverflow.com/questions/77171270/compilation-error-after-upgrading-to-jdk-21-nosuchfielderror-jcimport-does-n)

[https://developer.redis.com/develop/dotnet/redis-om-dotnet/searching/creating-an-index/](https://developer.redis.com/develop/dotnet/redis-om-dotnet/searching/creating-an-index/)
---

# Spring Boot integrated Redis Search quick start demo 

### 1. What is [Redis](http://www.liuhaihua.cn/archives/711433.html###) Search?

RedisSearch is a search engine module based on Redis, which provides [full-text search](http://www.liuhaihua.cn/archives/711433.html###) , indexing, and aggregation capabilities. With RedisSearch, you can create indexes for data in Redis, perform complex search queries, and implement advanced features such as auto-completion, faceted search, and sorting. Taking advantage of the high performance of Redis, RedisSearch can achieve efficient search and real-time analysis. For microservice architecture, RedisSearch can be used as part of the search service to provide fast and efficient search capabilities, which is of great significance for improving user experience and performance.

### 2. Environment Construction

**Docker Compose**
```yml
version:  '3'   
services:  
redis:   
    image:  redis/redis-stack   
    containername:  redis   
    ports:   
      -  6379 :6379  
  redis-insight:   
    image:  redislabs/redisinsight   
    containername:  redis-insight   
    ports:   
      -  8001 :8001
```
Run following **command** :
```shell
docker-compose up -d
```
![](https://miro.medium.com/v2/resize:fit:875/0*zDK9FKy8TS5lS-H.png)

### 3. Code Engineering

### Purpose

> Using redis search to implement text search function

### pom.xml
```xml
<?xml version="1.0" encoding="UTF-8"?>  
<project xmlns="http://maven.apache.org/POM/4.0.0"  
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">  
    <parent>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-parent</artifactId>  
        <version>3.2.1</version>  
    </parent>  
    <modelVersion>4.0.0</modelVersion>  
    <artifactId>RedisSearch</artifactId>  
    <properties>  
        <maven.compiler.source>17</maven.compiler.source>  
        <maven.compiler.target>17</maven.compiler.target>  
    </properties>  
    <dependencies>  
  
        <dependency>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-starter-web</artifactId>  
        </dependency>  
        <dependency>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-autoconfigure</artifactId>  
        </dependency>  
        <dependency>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-starter-test</artifactId>  
            <scope>test</scope>  
        </dependency>  
        <dependency>  
            <groupId>com.redis.om</groupId>  
            <artifactId>redis-om-spring</artifactId>  
            <version>0.8.2</version>  
        </dependency>  
        <dependency>  
            <groupId>org.springframework.data</groupId>  
            <artifactId>spring-data-redis</artifactId>  
        </dependency>  
        <dependency>  
            <groupId>org.projectlombok</groupId>  
            <artifactId>lombok</artifactId>  
        </dependency>  
  
    </dependencies>  
</project>
```
### controller
```java
package com.et.controller;  
import com.et.redis.document.Student;  
import com.et.redis.document.StudentRepository;  
import com.et.redis.hash.Person;  
import com.et.redis.hash.PersonRepository;  
import jakarta.websocket.server.PathParam;  
import org.springframework.http.HttpStatus;  
import org.springframework.http.ResponseEntity;  
import org.springframework.web.bind.annotation.*;  
  
@RestController  
public class WebController {  
    private PersonRepository personRepository;  
    private StudentRepository studentRepository;  
    public WebController(PersonRepository personRepository, StudentRepository studentRepository) {  
        this.personRepository = personRepository;  
        this.studentRepository = studentRepository;  
    }  
    @PostMapping("/person")  
    public Person save(@RequestBody Person person) {  
        return personRepository.save(person);  
    }  
    @GetMapping("/person")  
    public Person get(@PathParam("name") String name, @PathParam("searchLastName") String searchLastName) {  
        if (name != null)  
            return this.personRepository.findByName(name)  
                    .orElseThrow(() -> new RuntimeException("person not found"));  
        if (searchLastName != null)  
            return this.personRepository.searchByLastName(searchLastName)  
                    .orElseThrow(() -> new RuntimeException("person not found"));  
        return null;  
    }  
// ---- Student Endpoints  
    @PostMapping("/student")  
    public Student saveStudent(@RequestBody Student student) {  
        return studentRepository.save(student);  
    }  
    @GetMapping("/student")  
    public Student getStudent(@PathParam("name") String name, @PathParam("searchLastName") String searchLastName) {  
        if (name != null)  
            return this.studentRepository.findByName(name)  
                    .orElseThrow(() -> new RuntimeException("Student not found"));  
        if (searchLastName != null)  
            return this.studentRepository.searchByLastName(searchLastName)  
                    .orElseThrow(() -> new RuntimeException("Student not found"));  
        return null;  
    }  
    @ExceptionHandler(value = RuntimeException.class)  
    public ResponseEntity handleError(RuntimeException e) {  
        return ResponseEntity  
                .status(HttpStatus.NOTFOUND)  
                .body(e.getMessage());  
    }  
  
}  
```
### @ [Redis](http://www.liuhaihua.cn/archives/711433.html###) Hash method
```java
package com.et.redis.hash;  
import com.redis.om.spring.annotations.Indexed;  
import com.redis.om.spring.annotations.Searchable;  
import org.springframework.data.annotation.Id;  
import org.springframework.data.redis.core.RedisHash;  
@RedisHash  
public class Person {  
    @Id  
    private String id;  
    @Indexed  
    private String name;  
    @Searchable  
    private String lastName;  
    public String getId() {  
        return id;  
    }  
    public void setId(String id) {  
        this.id = id;  
    }  
    public String getName() {  
        return name;  
    }  
    public void setName(String name) {  
        this.name = name;  
    }  
    public String getLastName() {  
        return lastName;  
    }  
    public void setLastName(String lastName) {  
        this.lastName = lastName;  
    }  
}

package com.et.redis.hash;  
import org.springframework.data.repository.CrudRepository;  
import org.springframework.stereotype.Repository;  
import java.util.Optional;  
@Repository  
public interface PersonRepository extends CrudRepository<Person, String> {  
    Optional<Person> findByName(String name);  
    Optional<Person> searchByLastName(String name);  
}
```

### @Document method
```java
package com.et.redis.document;  
import com.redis.om.spring.annotations.Document;  
import com.redis.om.spring.annotations.Indexed;  
import com.redis.om.spring.annotations.Searchable;  
import org.springframework.data.annotation.Id;  
@Document  
public class Student {  
    @Id  
    private String id;  
    @Indexed  
    private String name;  
    @Searchable  
    private String lastName;  
    public String getId() {  
        return id;  
    }  
    public void setId(String id) {  
        this.id = id;  
    }  
    public String getName() {  
        return name;  
    }  
    public void setName(String name) {  
        this.name = name;  
    }  
    public String getLastName() {  
        return lastName;  
    }  
    public void setLastName(String lastName) {  
        this.lastName = lastName;  
    }  
}

package com.et.redis.document;  
import org.springframework.data.repository.CrudRepository;  
import org.springframework.stereotype.Repository;  
import java.util.Optional;  
@Repository  
public interface StudentRepository extends CrudRepository<Student, String> {  
    Optional<Student> findByName(String name);  
    Optional<Student> searchByLastName(String name);  
}
```
### DemoApplication
```java
package com.et;  
import com.redis.om.spring.annotations.EnableRedisDocumentRepositories;  
import com.redis.om.spring.annotations.EnableRedisEnhancedRepositories;  
import org.springframework.boot.SpringApplication;  
import org.springframework.boot.autoconfigure.SpringBootApplication;  
@EnableRedisDocumentRepositories(basePackages = "com.et.redis.document")  
@EnableRedisEnhancedRepositories(basePackages = "com.et.redis.hash")  
@SpringBootApplication  
public class DemoApplication {  
   public static void main(String[] args) {  
      SpringApplication.run(DemoApplication.class, args);  
   }  
}
```

### [application](http://www.liuhaihua.cn/archives/711433.html###) .yaml
```yml
server:  
  port: 8088  
spring:  
  redis:  
    host: localhost  
    port: 6379
```
Just some key codes, please see the following code repository for all codes

### Code repository

https://github.com/Harries/springboot-demo

### 4. Testing

Start the Spring Boot application

### Test hash method

Insert an entity

![](https://miro.medium.com/v2/resize:fit:685/0*0Ksl6b8gcFTgHlus.png)

Query

![](https://miro.medium.com/v2/resize:fit:633/0*hV-i5Tr3wyEg7pRF.png)

Fuzzy query redis data (*rab*)

![](https://miro.medium.com/v2/resize:fit:784/0*h5y4Wdk4ilrzuC1K.png)

View redis database data

![](https://miro.medium.com/v2/resize:fit:875/0*z9GWmW2wWhyjKHXJ.png)

redis database fuzzy query

![](https://miro.medium.com/v2/resize:fit:875/0*1Ov2IpstpEGeGej7.png)

### Testing json document method

Insert the json document in the same way, and then view it in your redis database

![](https://miro.medium.com/v2/resize:fit:875/0*XwcB2hsghIBnnNaY.png)

### 5. References

-   [https://blog.devgenius.io/redis-search-with-spring-boot-and-redis-om-searchable-indexed-ttl-ccf2fb027d96](https://blog.devgenius.io/redis-search-with-spring-boot-and-redis-om-searchable-indexed-ttl-ccf2fb027d96)
-   [https://refactorfirst.com/spring-boot-with-redis-stack-and-redis-insight](https://refactorfirst.com/spring-boot-with-redis-stack-and-redis-insight)
-   [http://www.liuhaihua.cn/archives/711433.html](http://www.liuhaihua.cn/archives/711433.html)

---
# Java Spring boot Redis configuration with Redis Server hosted on GCP having SSL and Password

To connect your Springboot 3 application with Redis server on GCP,You need to download the certificate file from GCP console.

![](https://miro.medium.com/v2/resize:fit:875/1*uvMeOj1SGrSoYEoVXHhdg.png)

Also you will get the redis sever password from the GCP console:

![](https://miro.medium.com/v2/resize:fit:875/1*0cVkq-xS4pqIiGCCNlVboQ.png)

Lets assume you have kept the certificate file name as server-ca-redis.pem

Now in springboot application.properties, we need to do following entries :

> CACHEREDISHOST=actualhostipofredisserver
> 
> CACHEREDISPORT=actualportofredisserver
> 
> CACHEREDISPASSWORD=actualpasswordofredisserver
> 
> COMMONDSREDISTLSENABLED=true
> 
> COMMONDSREDISCACERT=/tmp/redis/server-ca-redis.pem

maven dependency to add in pom.xml
```xml
  <dependency>  
     <groupId>org.springframework.boot</groupId>  
     <artifactId>spring-boot-starter-data-redis</artifactId>  
  </dependency>
```
Now We need to create one file inside config package of application:
```java
package com.demo.config;  
  
  
import java.io.IOException;  
  
import org.springframework.beans.factory.annotation.Value;  
import org.springframework.context.annotation.Bean;  
import org.springframework.context.annotation.Configuration;  
import org.springframework.core.io.ResourceLoader;  
import org.springframework.data.redis.connection.RedisConnectionFactory;  
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;  
import org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration;  
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;  
  
import io.lettuce.core.ClientOptions;  
import io.lettuce.core.SslOptions;  
import io.lettuce.core.protocol.ProtocolVersion;  
import lombok.RequiredArgsConstructor;  
  
@Configuration  
@RequiredArgsConstructor  
public class RedisSSLConfiguration {  
  
  @Value("${CACHEREDISHOST}")  
  private String host;  
  
  @Value("${CACHEREDISPORT}")  
  private int port;  
  
  @Value("${CACHEREDISPASSWORD}")  
  private String password;  
  
  @Value("${REDISTLSENABLED}")  
  private boolean sslEnabled;  
    
  @Value("${REDISCACERT}")  
  private String certFileLocation;  
  
  private final ResourceLoader resourceLoader;  
  
  @Bean  
  RedisConnectionFactory redisConnectionFactory() throws IOException {  
    RedisStandaloneConfiguration redisStandaloneConfiguration = new RedisStandaloneConfiguration();  
    redisStandaloneConfiguration.setHostName(host);  
    redisStandaloneConfiguration.setPort(port);  
    redisStandaloneConfiguration.setPassword(password);  
  
    LettuceClientConfiguration.LettuceClientConfigurationBuilder lettuceClientConfigurationBuilder =  
        LettuceClientConfiguration.builder();  
  
    if (sslEnabled){  
      SslOptions sslOptions = SslOptions.builder()  
          .trustManager(resourceLoader.getResource("file:" + certFileLocation).getFile())  
          .build();  
  
      ClientOptions clientOptions = ClientOptions  
          .builder()  
          .sslOptions(sslOptions)  
          .protocolVersion(ProtocolVersion.RESP3)  
          .build();  
  
      lettuceClientConfigurationBuilder  
          .clientOptions(clientOptions)  
          .useSsl().disablePeerVerification();  
    }  
  
    LettuceClientConfiguration lettuceClientConfiguration = lettuceClientConfigurationBuilder.build();  
  
    return new LettuceConnectionFactory(redisStandaloneConfiguration, lettuceClientConfiguration);  
  }  
  
}
```
Create one more RedisConfig.java file as below
```java
package com.demo.config;  
  
  
import java.time.Duration;  
  
import org.springframework.boot.autoconfigure.cache.RedisCacheManagerBuilderCustomizer;  
import org.springframework.context.annotation.Bean;  
import org.springframework.context.annotation.Configuration;  
import org.springframework.data.redis.cache.RedisCacheConfiguration;  
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;  
import org.springframework.data.redis.serializer.RedisSerializationContext.SerializationPair;  
  
@Configuration  
public class RedisConfig {  
  
 @Bean  
  RedisCacheConfiguration cacheConfiguration() {  
     return RedisCacheConfiguration.defaultCacheConfig()  
       .entryTtl(Duration.ofMinutes(60))  
       .disableCachingNullValues()  
       .serializeValuesWith(SerializationPair.fromSerializer(new GenericJackson2JsonRedisSerializer()));  
 }  
   
 @Bean  
 RedisCacheManagerBuilderCustomizer redisCacheManagerBuilderCustomizer() {  
     return (builder) -> builder  
       .withCacheConfiguration("commonDetails",  
         RedisCacheConfiguration.defaultCacheConfig().entryTtl(Duration.ofMinutes(5)));  
 }  
}
```
Create one more config file as below :
```java
package com.demo.config;  
  
  
import org.springframework.context.annotation.Bean;  
import org.springframework.context.annotation.Configuration;  
import org.springframework.data.redis.cache.RedisCacheConfiguration;  
import org.springframework.data.redis.cache.RedisCacheManager;  
import org.springframework.data.redis.connection.RedisConnectionFactory;  
  
@Configuration  
public class CacheManagerConfig {  
  
    @Bean  
     RedisCacheManager cacheManager(RedisConnectionFactory redisConnectionFactory,  
                                         RedisCacheConfiguration redisCacheConfiguration) {  
  
        return RedisCacheManager.builder(redisConnectionFactory)  
                .cacheDefaults(redisCacheConfiguration)  
                .transactionAware()  
                .build();  
    }  
}  
```  

After all this is done , apply @EnableCaching annotation on Application.java file .

Now you are all set to use @Cachable on any method you want to cache.
```java
@Cacheable(value = "commonDetails")  
 public CommonDetailsDto getCommonDetails(String token, List<String> keys)  {  
     // your DB or API call should be here  
 }
```
# Building a Resilient, Priority-Driven Queue System for Rate-Limited APIs using Spring Boot, Redis and MySQL 

Imagine you have a project that relies on an external service, but the service provider enforces a strict rate limit, allowing only 1 requests per 10 second. Meanwhile, your customers are expecting real-time responses, creating a potential bottleneck. At [**Lidy**](https://www.lidy.co), we faced a similar challenge with some of our external services. Today, we’ll walk you through our approach to this situation and demonstrate how we successfully implemented a resilient solution to overcome this limitation.

Most of the time, an event-driven architecture with Kafka can effectively address this type of problem. However, this approach operates asynchronously. In our case, we needed a request-driven, synchronous solution to meet customer expectations in real time.

We could also address this issue by implementing a retry mechanism for every HTTP 429 (Too Many Requests) response. However, this approach carries the risk of the external service provider blocking us due to excessive request retries.

So, we needed to solve this problem with an internal solution called the QueueWorker. :)

![](https://miro.medium.com/v2/resize:fit:875/1*W8l5s5KsqVvh7UDxHITaCA.png)

## Before we dive into the code, you can find the source code [here](https://github.com/tugayesilyurt/rate-limit-handler-with-priority-queue).

Let’s begin by running Redis using a Docker command
```shell
docker run -d   
  --name redis-container   
  -p 6379:6379   
  --restart unless-stopped   
  redis:latest
```
Next, proceed with running MySQL using a Docker command.
```shell
docker run -d   
  --name mysql-container   
  -p 3306:3306   
  -e MYSQLROOTPASSWORD=rootpassword   
  -e MYSQLDATABASE=queue   
  -e MYSQLUSER=queue   
  -e MYSQLPASSWORD=123456   
  --restart unless-stopped   
  mysql:latest
```
We have a RateLimitController class that restricts requests to 1 every 10 seconds. This limit can be easily configured through the `application.yml` file.
```java
@RestController  
@RequestMapping("/v1/rate-limit")  
public class RateLimitController {  
  
    private final StringRedisTemplate redisTemplate;  
  
    @Value("${rate.limit.max-requests:1}")  
    private int maxRequests;  
  
    @Value("${rate.limit.time-window-seconds:10}")  
    private int timeWindowSeconds;  
  
    public RateLimitController(StringRedisTemplate redisTemplate) {  
        this.redisTemplate = redisTemplate;  
    }  
  
    @GetMapping("/external-service")  
    public ResponseEntity<String> callExternalService() {  
  
        String key = "rate-limit:external-service";  
        boolean isAllowed = acquireRateLimitSlot(key);  
  
        if (isAllowed) {  
            // Simulate service call  
            return ResponseEntity.ok("External service successfully called.");  
        } else {  
            return ResponseEntity.status(HttpStatus.TOOMANYREQUESTS)  
                    .body("Rate limit exceeded. Please try again later.");  
        }  
    }  
  
    private boolean acquireRateLimitSlot(String key) {  
        // Increment request count for the given key  
        Long currentCount = redisTemplate.opsForValue().increment(key);  
  
        if (currentCount == 1) {  
            // Set expiry if this is the first request  
            redisTemplate.expire(key, Duration.ofSeconds(timeWindowSeconds));  
        }  
  
        // Check if the request count exceeds the maximum allowed  
        return currentCount <= maxRequests;  
    }  
}
```
Our other controller class is QueueWorker, which demonstrates how we effectively handle the rate limit problem.
```java
@RestController  
@RequestMapping("/v1/queue/worker")  
@RequiredArgsConstructor  
public class QueueWorkerController {  
  
    private final QueueWorkerService queueWorkerService;  
  
    @PostMapping  
    public ResponseEntity<?> queueWorker() {  
  
        return new ResponseEntity<String>(queueWorkerService.queueWorker(), HttpStatus.OK);  
    }  
}
```
The QueueWorker first checks whether there is an available slot for the external service using the code below. If a slot is available, the external service is called. Otherwise, the request is added to the queue for later processing
```java
@Service  
@RequiredArgsConstructor  
@Slf4j  
public class QueueWorkerService {  
  
    private final RestTemplate restTemplate;  
    private final StringRedisTemplate redisTemplate;  
    private final RequestQueue requestQueue;  
    private final QueueRepository queueRepository;  
    private static final String RATELIMITTTLKEY = "try/rate-limit-ttl";  
    private static final String RATELIMITSIZEKEY = "try/rate-limit-size";  
  
    @Value("${external.for-which-service}")  
    private String forWhichService;  
  
    @Value("${external.ws-url}")  
    private String wsUrl;  
  
    @SneakyThrows  
    public String queueWorker() {  
  
        ResponseEntity<String> response;  
  
        if (acquireRateLimitSlot(forWhichService)) {  
            response = restTemplate.getForEntity(wsUrl, String.class);  
        } else {  
  
            LocalDateTime now = LocalDateTime.now(ZoneId.of("Europe/Istanbul"));  
            Timestamp timestamp = Timestamp.valueOf(now);  
            Queue queue = queueRepository.save(Queue.builder().whichExternalService(forWhichService).successStatus(Boolean.FALSE).build());  
  
            CompletableFuture<ResponseEntity<String>> responseTryRateLimit = new CompletableFuture<>();  
            Request requestQueueData = new Request(responseTryRateLimit, forWhichService, timestamp.getTime(), queue.getId());  
            requestQueue.add(requestQueueData);  
            log.info(forWhichService + " acquireRateLimitSlot is full. We have to wait for entity id : " + queue.getId());  
            response = responseTryRateLimit.get();  
        }  
  
        return response.getBody();  
  
    }  
  
    private boolean acquireRateLimitSlot(String method) {  
        // Generate a Redis key to track the rate limit for the given method  
        String key = method + "-rate-limit";  
  
        // Retrieve the configured time-to-live (TTL) and maximum queue size from Redis  
        int ttlOfQueue = Integer.valueOf(redisTemplate.opsForValue().get(RATELIMITTTLKEY));  
        int sizeOfQueue = Integer.valueOf(redisTemplate.opsForValue().get(RATELIMITSIZEKEY));  
  
        // Get the current count of requests from Redis  
        String currentCountStr = redisTemplate.opsForValue().get(key);  
        Long currentCount = (currentCountStr != null) ? Long.parseLong(currentCountStr) : 0L;  
  
        // If the current count has reached the maximum allowed size, return false (no slot available)  
        if (currentCount >= sizeOfQueue)  
            return false;  
  
        // Increment the current count atomically in Redis  
        Long currentCountLast = redisTemplate.opsForValue().increment(key);  
  
        // If this is the first request in the current time window, set the expiration time (TTL) on the key  
        if (currentCountLast == 1) {  
            redisTemplate.expire(key, Duration.ofSeconds(ttlOfQueue));  
        }  
  
        // Return true if the incremented count is within the allowed limit, false otherwise  
        return currentCountLast <= sizeOfQueue;  
    }  
  
}
```
I will now demonstrate how our queue mechanism works

We have a scheduler that runs every second and checks if the queue contains any data. If the queue is not empty, we will attempt to acquire a slot and process the request again
```java
@Service  
@RequiredArgsConstructor  
@Getter  
@Setter  
@Slf4j  
public class QueueWorker {  
  
    private final RequestQueue requestQueue;  
    private final RedisTemplate<String, String> redisTemplate;  
    private final RestTemplate restTemplate;  
    private final QueueRepository queueRepository;  
    private static final String RATELIMITTTLKEY = "try/rate-limit-ttl";  
    private static final String RATELIMITSIZEKEY = "try/rate-limit-size";  
  
    @Value("${external.for-which-service}")  
    private String forWhichService;  
  
    @Value("${external.ws-url}")  
    private String wsUrl;  
  
    @Scheduled(fixedRate = 1000)  
    public void processQueue() {  
        while (!requestQueue.isEmpty()) {  
            Request request = requestQueue.poll();  
            if (request == null) {  
                return;  
            }  
            try {  
                if (acquireRateLimitSlot(request.getMethod())) {  
  
                    ResponseEntity<String> response = restTemplate.getForEntity(wsUrl, String.class);  
                    Optional<Queue> queue = queueRepository.findById(request.getEntityId());  
                    if(queue.isPresent()){  
                        queue.get().setSuccessStatus(Boolean.TRUE);  
                        queue.get().setUpdatedDate(LocalDateTime.now());  
                        queueRepository.save(queue.get());  
                    }  
                    log.info("QueueWorker worked " +  response.getBody());  
                    request.getResponse().complete(response);  
                } else {  
                    log.info("acquireRateLimitSlot full : " + request.getEntityId());  
                    requestQueue.add(request);  
                }  
            } catch (Exception e) {  
               log.error("QueueWorker processQueue error " + e.getMessage());  
            }  
        }  
    }  
  
    private boolean acquireRateLimitSlot(String method) {  
        // Generate a Redis key to track the rate limit for the given method  
        String key = method + "-rate-limit";  
  
        // Retrieve the configured time-to-live (TTL) and maximum queue size from Redis  
        int ttlOfQueue = Integer.valueOf(redisTemplate.opsForValue().get(RATELIMITTTLKEY));  
        int sizeOfQueue = Integer.valueOf(redisTemplate.opsForValue().get(RATELIMITSIZEKEY));  
  
        // Get the current count of requests from Redis  
        String currentCountStr = redisTemplate.opsForValue().get(key);  
        Long currentCount = (currentCountStr != null) ? Long.parseLong(currentCountStr) : 0L;  
  
        // If the current count has reached the maximum allowed size, return false (no slot available)  
        if (currentCount >= sizeOfQueue)  
            return false;  
  
        // Increment the current count atomically in Redis  
        Long currentCountLast = redisTemplate.opsForValue().increment(key);  
  
        // If this is the first request in the current time window, set the expiration time (TTL) on the key  
        if (currentCountLast == 1) {  
            redisTemplate.expire(key, Duration.ofSeconds(ttlOfQueue));  
        }  
  
        // Return true if the incremented count is within the allowed limit, false otherwise  
        return currentCountLast <= sizeOfQueue;  
    }  
  
}
```
But we encountered a problem: we need to prioritize the earliest requests since they have been waiting the longest for a slot. To solve this, we use a `PriorityQueue` with timestamps to ensure requests are processed in the correct order.
```java
@Component  
public class RequestQueue {  
    private final PriorityBlockingQueue<Request> requestQueue =   
             new PriorityBlockingQueue<>();  
  
    public void add(Request request) {  
        requestQueue.offer(request);  
    }  
  
    public Request poll() {  
        return requestQueue.poll();  
    }  
  
    public boolean isEmpty() {  
        return requestQueue.isEmpty();  
    }  
}  
  
@Getter  
public class Request implements Comparable<Request> {  
  
    private final CompletableFuture<ResponseEntity<String>> response;  
    private final String method;  
    private final long timestamp;  
    private final long entityId;  
  
    public Request(CompletableFuture<ResponseEntity<String>> response, String method, long timestamp,long entityId) {  
        this.response = response;  
        this.method = method;  
        this.timestamp = timestamp;  
        this.entityId = entityId;  
    }  
  
    @Override  
    public int compareTo(Request other) {  
        // Oldest requests first  
        return Long.compare(this.timestamp, other.timestamp);   
    }  
}
```
With this queue-based solution, we successfully resolved the external rate-limited service problem. :)

# Conclusion

In this article, we explored how to handle rate-limited external services efficiently using a queue-driven approach with Spring Boot and Redis. By implementing a `QueueWorker` that prioritizes requests with timestamps and checks for available rate-limit slots, we ensured that no request is lost or delayed unnecessarily. This approach allowed us to balance between respecting the external API's rate limits and providing a smooth experience for end-users.

Additionally, the flexibility of Redis made it easy to manage dynamic rate limits and time-to-live (TTL) configurations, while the `PriorityQueue` ensured that the earliest requests were prioritized. This architecture not only improves system reliability but also provides room for future scalability, such as adding dynamic configurations or more advanced retry mechanisms.

By adopting this solution, you can prevent bottlenecks caused by rate-limited APIs and maintain consistent, responsive service for your users. Whether your project involves APIs with strict quotas or intermittent service availability, this design pattern can be a valuable addition to your system toolkit.

https://github.com/tugayesilyurt/rate-limit-handler-with-priority-queue
---
