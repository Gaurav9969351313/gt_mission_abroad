# Comparison: JMS Message Queue vs. Apache Kafka

Comparing JMS-based message queue (MQ) infrastructures and Apache Kafka-based data streaming is a widespread topic. Unfortunately, the battle is an apple-to-orange comparison that often includes misinformation and FUD from vendors. This blog post explores the **differences, trade-offs, and architectures of JMS message brokers and Kafka deployments**. Learn how to choose between JMS brokers like IBM MQ or RabbitMQ and open-source Kafka or serverless cloud services like Confluent Cloud.

(Originally posted on Kai Waehner’s blog: “[Comparison: JMS Message Queue vs. Apache Kafka](https://www.kai-waehner.de/blog/2022/05/12/comparison-jms-api-message-broker-mq-vs-apache-kafka/)”… Stay informed about new blog posts by [subscribing to my newsletter](https://www.kai-waehner.de/newsletter))

### Motivation: The battle of apples vs. oranges

I have to discuss the **differences and trade-offs between JMS message brokers and Apache Kafka** every week in customer meetings. What annoys me most is the **common** **misunderstandings and (sometimes) intentional FUD** in various blogs, articles, and presentations about this discussion.

I recently discussed this topic with Clement Escoffier from Red Hat in the “Coding over Cocktails” Podcast: [JMS vs. Kafka: Technology Smackdown](https://www.torocloud.com/podcast/jms-vs-kafka-clement-escoffier-kai-waehner). A great conversation with more agreement than you might expect from such an episode where I picked the “Kafka proponent” while Clement took over the role of the “JMS proponent”.

These aspects motivated me to write a **blog series about “JMS, Message Queues, and Apache Kafka”**:

-   THIS POST — **10 Comparison Criteria** for JMS Message Broker vs. Apache Kafka Data Streaming
-   [Alternatives for a **Dead Letter Queue (DQL) in Apache Kafka**](https://www.kai-waehner.de/blog/2022/05/30/error-handling-via-dead-letter-queue-in-apache-kafka/)
-   Implementing the [**Request-Reply Pattern with Apache Kafka**](https://www.kai-waehner.de/blog/2022/06/03/apache-kafka-request-response-vs-cqrs-event-sourcing/)
-   UPCOMING — A **Decision Tree for Choosing the Right Messaging System** (JMS vs. Apache Kafka)
-   UPCOMING — From JMS Message Broker to Apache Kafka: **Integration, Migration, and/or Replacement**

I will link the other posts here as soon as they are available. Please [follow my newsletter to get updated in real-time about new posts](https://www.kai-waehner.de/newsletter). (no spam or ads)

Special thanks to my colleague and long-term messaging and data streaming expert [Heinz Schaffner](https://www.linkedin.com/in/heinz-schaffner-920a53b/) for technical feedback and review of this blog series. He has worked for TIBCO, Solace, and Confluent for 25 years.

### 10 comparison criteria: JMS vs. Apache Kafka

This blog post explores ten comparison criteria. The goal is to **explain the differences** between message queues and data streaming, **clarify some misunderstandings** about what an API or implementation is, and give some **technical background** to do your evaluation to find the right tool for the job.

The list of products and cloud services is long for JMS implementations and Kafka offerings. A few examples:

-   **JMS implementations of the JMS API** (open source and commercial offerings): Apache ActiveMQ, Apache Qpid (using AMQP), IBM MQ (formerly MQSeries, then WebSphere MQ), JBoss HornetQ, Oracle AQ, RabbitMQ, TIBCO EMS, TIBCO Cloud Messaging, Solace, etc.
-   **Apache Kafka products, cloud services, and rewrites** (beyond the valid option of using just open-source Kafka): Confluent, Cloudera, Amazon MSK, Red Hat, Redpanda, Azure Event Hubs, etc.

Here are the criteria for comparing JMS message brokers vs. Apache Kafka and its related products/cloud services:

1.  Message broker vs. data streaming platform
2.  API Specification vs. open-source protocol implementation
3.  Transactional vs. analytical workloads
4.  Push vs. pull message consumption
5.  Simple vs. powerful and complex API
6.  Storage for durability vs. true decoupling
7.  Server-side data-processing vs. decoupled continuous stream processing
8.  Complex operations vs. serverless cloud
9.  Java/JVM vs. any programming language
10.  Single deployment vs. multi-region (including hybrid and multi-cloud) replication

Let’s now explore the ten comparison criteria.

### 1. Message broker vs. data streaming platform

**TL;DR: JMS message brokers provide messaging capabilities to produce and consume messages. Apache Kafka is a data streaming platform that combines messaging, storage, data integration, and stream processing capabilities.**

The most important aspect first: **The comparison of JMS and Apache Kafka is an apple to orange comparison for several reasons**. I would even further say that not both can be fruit, as they are so different from each other.

### JMS API (and implementations like IBM MQ, RabbitMQ, et al)

**JMS (Java Message Service)** is a Java application programming interface (API) that provides generic messaging models. The API handles the producer-consumer problem, which can facilitate the **sending and receiving of messages between software systems**.

Therefore, the central capability of **JMS message brokers** (that implement the JMS API) is to **send messages from a source application to another destination in real-time**. That’s it. And if that’s what you need, then JMS is the right choice for you! But keep in mind that projects must use additional tools for data integration and advanced data processing tasks.

### Apache Kafka (open source and vendors like Confluent, Cloudera, Red Hat, Amazon, et al)

**Apache Kafka is an open-source protocol implementation for data streaming**. It includes:

-   **Apache Kafka** is the core for distributed messaging and storage. High throughput, low latency, high availability, secure.
-   **Kafka Connect** is an integration framework for connecting external sources/destinations to Kafka.
-   **Kafka Streams** is a simple Java library that enables streaming application development within the Kafka framework.

This combination of capabilities enables the building of **end-to-end data pipelines and applications**. That’s much more than what you can do with a message queue.

### 2. JMS API specification vs. Apache Kafka open-source protocol implementation

**TL;DR: JMS is a specification that vendors implement and extend in their opinionated way. Apache Kafka is the open-source implementation of the underlying specified Kafka protocol.**

It is crucial to clarify the terms first before you evaluate JMS and Kafka:

-   **Standard API**: Specified by industry consortiums or other industry-neutral (often global) groups or organizations specify standard APIs. Requires compliance tests for all features and complete certifications to become standard-compliant. Example: **OPC-UA**.
-   **De facto standard API**: Originates from an existing successful solution (an open-source framework, a commercial product, or a cloud service). Examples: **Amazon S3** (proprietary from a single vendor). **Apache Kafka** (open source from the vibrant community).
-   **API Specification**: A specification document to define how vendors can implement a related product. There are no complete compliance tests or complete certifications for the implementation of all features. The consequence is a “standard API” but no portability between implementations. Example: **JMS.** Specifically for JMS, note that in order to be able to use the compliance suite for JMS, a commercial vendor has to sign up to very onerous reporting requirements towards Oracle.

The alternative kinds of standards have trade-offs. If you want to learn more, check out how [Apache Kafka became the de facto standard for data streaming in the last few years](https://www.kai-waehner.de/blog/2021/05/09/kafka-api-de-facto-standard-event-streaming-like-amazon-s3-object-storage/).

**Portability and migrations became much more relevant in hybrid and multi-cloud environments** than in the past decades where you had your workloads in a single data center.

### JMS is a specification for message-oriented middleware

**JMS is a specification** currently maintained under the Java Community Process as JSR 343. The latest (not yet released) version JMS 3.0 is under early development as part of Jakarta EE and rebranded to Jakarta Messaging API. Today, **JMS 2.0 is the specification used in prevalent message broker implementations**. Nobody knows where JMS 3.0 will go at all. Hence, this post focuses on the JMS 2.0 specification to solve real-world problems today.

I often use the term “JMS message broker” in the following sections as JMS (i.e., the API) does not specify or implement many features you know in your favorite JMS implementation. Usually, **when people talk about JMS, they mean JMS message broker implementations, not the JMS API specification**.

### JMS message brokers and the JMS portability myth

The JMS specification was developed to provide a common Java library to access different messaging vendor’s brokers. It was intended to act as a wrapper to the messaging vendor’s proprietary APIs in the same way JDBC provided similar functionality for database APIs.

Unfortunately, this simple integration turned out not to be the case. The **migration of the JMS code from one vendor’s broker to another is quite complex for several reasons**:

-   Not all JMS features are mandatory (security, topic/queue labeling, clustering, routing, compression, etc.)
-   There is no JMS specification for transport
-   No specification to define how persistence is implemented
-   No specification to define how fault tolerance or high availability is implemented
-   Different interpretations of the JMS specification by different vendors result in potentially other behaviors for the same JMS functions
-   No specification for security
-   There is no specification for value-added features in the brokers (such as topic to queue bridging, inter-broker routing, access control lists, etc.)

Therefore, **simple source code migration and interoperability between JMS vendors is a myth!** This sounds crazy, doesn’t it?

Vendors provide a great deal of unique functionality within the broker (such as topic-to-queue mapping, broker routing, etc.) that provide architectural functionality to the application but are part of the broker functionality and not the application or part of the JMS specification.

### Apache Kafka is an open-source protocol implementation for data streaming

**Apache Kafka is an implementation** to do reliable and scalable data streaming in real-time. The project is **open-source and available under Apache 2.0 license,** and is driven by a vast community.

**Apache Kafka is NOT a standard like OPC-UA or a specification like JMS**. However, Kafka at least provides the source code reference implementation, protocol and API definitions, etc.

Kafka established itself as the de facto standard for data streaming. Today, over 100,000 organizations use Apache Kafka. The **Kafka API became the de facto standard for event-driven architectures and event streaming**. **Use cases across all industries and infrastructure**. Including various kinds of transactional and analytic workloads. [Edge, hybrid, multi-cloud](https://www.kai-waehner.de/blog/2020/01/29/deployment-patterns-distributed-hybrid-edge-global-multi-data-center-kafka-architecture/). I collected a few [examples across verticals that use Apache Kafka](https://www.kai-waehner.de/blog/2020/10/20/apache-kafka-event-streaming-use-cases-architectures-examples-real-world-across-industries/) to show the prevalence across markets.

Now, hold on. I used the term Kafka API in the above section. Let’s clarify this: As discussed, **Apache Kafka is an implementation** of a distributed data streaming platform including the server-side and client-side and various APIs for producing and consuming events, configuration, security, operations, etc. **The Kafka API is relevant, too, as Kafka rewrites** like Azure Event Hubs and Redpanda **use it**.

### Portability of Apache Kafka — yet another myth?

If you use Apache Kafka as an open-source project, this is the complete Kafka implementation. Some vendors use the full Apache Kafka implementation and build a more advanced product around it.

Here, the **migration is super straightforward, as Kafka is not just a specification that each vendor implements differently**. Instead, it is the same code, libraries, and packages.

For instance, I have seen several **successful migrations from Cloudera to Confluent deployments or from self-managed Apache Kafka open-source infrastructure to serverless Confluent Cloud**.

### The Kafka API — Kafka rewrites like Azure Event Hubs, Redpanda, Apache Pulsar

With the global success of Kafka, **some vendors and cloud services** did not build a product on top of the Apache Kafka implementation. Instead, they **made their implementation on top of the Kafka API**. The underlying implementation is proprietary (like in Azure’s cloud service Event Hubs) or open-source (like Apache Pulsar’s Kafka bridge or Redpanda’s rewrite in C++).

Be careful and analyze if vendors integrate the whole Apache Kafka project or rewrote the complete API. **Contrary to the battle-tested Apache Kafka project, a Kafka rewrite using the Kafka API is a completely new implementation!**

**Many vendors even exclude some components or APIs** (like Kafka Connect for data integration or Kafka Streams for stream processing) **completely** or **exclude critical features** like exactly-once semantics or long-term storage in their support terms and conditions.

It is up to you to evaluate the different Kafka offerings and their limitations. Recently, I [compared Kafka vendors such as Confluent, Cloudera, Red Hat, or Amazon MSK and related technologies like Azure Event Hubs, AWS Kinesis, Redpanda, or Apache Pulsar](https://www.kai-waehner.de/blog/2021/04/20/comparison-open-source-apache-kafka-vs-confluent-cloudera-red-hat-amazon-msk-cloud/).

Just battle-test the requirements by yourself. If you find a Kafka-to-XYZ bridge with less than a hundred lines of code, or if you find a .exe Windows Kafka server download from a middleware vendor. Be skeptical! :-)

**All that glitters is not gold. Some frameworks or vendors sound too good to be true.** Just saying you support the Kafka API, you provide a fully managed serverless Kafka offering, or you scale much better is not trustworthy if you are constantly forced to provide [fear, uncertainty, and doubt (FUD)](https://en.wikipedia.org/wiki/Fear,uncertainty,anddoubt) on Kafka and that you are much better. For instance, I was annoyed by **Pulsar always trying to be better than Kafka by creating a lot of FUDs and myths in the open-source community.** I responded in my [Apache Pulsar vs. Kafka comparison](https://www.kai-waehner.de/blog/2020/06/09/apache-kafka-versus-apache-pulsar-event-streaming-comparison-features-myths-explored/) two years ago. FUD is the wrong strategy for any vendor. It does not work. For that reason, Kafka’s adoption still grows like crazy while Pulsar grows much slower percentage-wise (even though the download numbers are on a much lower level anyway).

### 3. Transactional vs. analytical workloads

**TL;DR: A JMS message broker provides transactional capabilities for low volumes of messages. Apache Kafka supports low and high volumes of messages supporting transactional and analytical workloads.**

### JMS — Session and two-phase commit (XA) transactions

**Most JMS message brokers have good support for transactional workloads.**

A **transacted session supports a single series of transactions**. Each transaction groups a set of produced messages and a set of consumed messages into an atomic unit of work.

Two-phase commit transactions (XA transactions) **work on a limited scale**. They are used to integrate with other systems like Mainframe CICS / DB2 or Oracle database. But it is **hard to operate and not possible to scale** beyond a few transactions per second.

It is important to note that **support for XA transactions is not mandatory with the JMS 2.0 specification**. This differs from the session transaction.

### Kafka — Exactly-once semantics and transaction API

Kafka is a **distributed, fault-tolerant system that is resilient by nature** (if you deploy and operate it correctly). **No downtime and no data loss can be guaranteed,** like in your favorite database, mainframe, or other core platforms.

And even better: **Kafka’s Transaction API, i.e.,** [**Exactly-Once Semantics (EOS)**](https://www.confluent.io/de-de/blog/exactly-once-semantics-are-possible-heres-how-apache-kafka-does-it/), has been available since Kafka 0.11 (GA’ed many years ago). EOS makes building transactional workloads even easier as you don’t need to handle duplicates anymore.

Kafka supports **atomic writes across multiple partitions through the transactions API**. This allows a producer to send a batch of messages to multiple partitions. Either all messages in the batch are eventually visible to any consumer, or none are ever visible to consumers.

**Kafka transactions work very differently than JMS transactions.** But the goal is the same: Each consumer receives the produced event exactly once. Find more details in the blog post “[Analytics vs. Transactions in Data Streaming with Apache Kafka](https://www.kai-waehner.de/blog/2022/03/09/analytics-vs-transactions-api-data-streaming-with-apache-kafka/)”.

### 4. Push vs. pull message consumption

**TL;DR: JMS message brokers push messages to consumer applications. Kafka consumers pull messages providing true decoupling and backpressure handling for independent consumer applications.**

Pushing messages seems to be the obvious choice for a real-time messaging system like JMS-based message brokers. However, **push-based messaging has various drawbacks regarding decoupling and scalability**.

JMS expects the broker to provide back pressure and implement a “pre-fetch” capability, but this is not mandatory. If used, the broker controls the backpressure, which you cannot control.

**With Kafka, the consumer controls the backpressure. Each Kafka consumer consumes events in real-time, batch, or only on demand** — in the way the particular consumer supports and can handle the data stream. This is an enormous advantage for many inflexible and non-elastic environments.

So while JMS has some kind of backpressure, the producer stops if the queue is full. In Kafka, you control the backpressure on the consumer. There is no way to scale a producer with JMS (as there are no partitions in a JMS queue or topic).

JMS consumers can be scaled, but then you lose guaranteed ordering. **Guaranteed ordering in JMS message brokers only works via a single producer, single consumer, and transaction**.

### 5. Simple JMS API vs. powerful and complex Kafka API

**TL;DR: The JMS API provides simple operations to produce and consume messages. Apache Kafka has a more granular API that brings additional power and complexity.**

JMS vendors hide all the cool stuff in the implementation under the spec. You only get the 5% (no control, built by the vendor). You need to make the rest by yourself. On the other side, Kafka exposes everything. Most developers only need 5%.

In summary, be aware that **JMS message brokers are built to send messages** from a data source to one or more data sinks. **Kafka is a data streaming platform that provides many more capabilities, features, event patterns, and processing options; and a much larger scale**. With that in mind, it is no surprise that the APIs are very different and have different complexity.

If your use case requires just sending a few messages per second from A to B, the JMS is the right choice and simple to use! If you need a streaming data hub at any scale, including data integration and data processing, that’s only Kafka.

### Asynchronous request-reply vs. data in motion

One of the most common wishes of JMS developers is to use are **request-response function in Kafka**. Note that this design pattern is different in messaging systems from an RPC (remote procedure call) as you know it from legacy tools like Corba or web service standards like SOAP/WSDL or HTTP. **Request-reply in messaging brokers is an asynchronous communication that leverages a correlation ID**.

Asynchronous messaging to get events from a producer (say a mobile app) to a consumer (say a database) is a very traditional workflow. No matter if you do fire-and-forget or request-reply. You put data at rest for further processing. **JMS supports request-reply out-of-the-box**. The API is very simple.

Data in motion with event streaming continuously processes data. The Kafka log is durable. The Kafka application maintains and queries the state in real-time or in batch. Data streaming is a paradigm shift for most developers and architects. The design patterns are very different. **Don’t try to reimplement your JMS application within Kafka using the same pattern and API.** That is likely to fail! That is an anti-pattern.

**Request-reply is inefficient and can suffer a lot of latency depending on the use case**. HTTP or better gRPC is suitable for some use cases. Request-reply **is replaced by the CQRS (Command and Query Responsibility Segregation) pattern with Kafka for streaming data**. CQRS is not possible with JMS API, since JMS provides no state capabilities and lacks event sourcing capability.

### A Kafka example for the request-response pattern

CQRS is the better design pattern for many Kafka use cases. Nevertheless, **the request-reply pattern can be implemented with Kafka, too.** But differently. Trying to do it like in a JMS message broker (with temporary queues etc.) will ultimately kill the Kafka cluster (because it works differently).

The Spring project shows how you can do better. The [Kafka Spring Boot Kafka Template](https://docs.spring.io/spring-kafka/reference/html/) libraries have a great example of the request-reply pattern built with Kafka.

Check out “[org.springframework.kafka.requestreply.ReplyingKafkaTemplate](https://docs.spring.io/spring-kafka/api/org/springframework/kafka/requestreply/ReplyingKafkaTemplate.html)”. It creates request/reply applications using the Kafka API easily. The example is interesting since it implements the asynchronous request/reply, which is more complicated to write if you are using, for example, JMS API). Another nice DZone article talks about [synchronous request/reply using Spring Kafka](https://dzone.com/articles/synchronous-kafka-using-spring-request-reply-1) templates.

The Spring documentation for Kafka Templates has a lot of details about the Request/Reply pattern for Kafka. **So if you are using Spring, the request/reply pattern is pretty simple to implement with Kafka.** If you are not using Spring, you can learn how to do request-reply with Kafka in your framework.

### 6. Storage for durability vs. true decoupling

**TL;DR: JMS message brokers use a storage system to provide high availability. The storage system of Kafka is much more advanced to enable long-term storage, back-pressure handling and replayability of historical events.**

### Kafka storage is more than just the persistence feature you know from JMS

When I explain the Kafka storage system to experienced JMS developers, I almost always get the same response: “Our JMS message broker XYZ also has storage under the hood. I don’t see the benefit of using Kafka!”

**JMS uses an ephemeral storage system, where messages are only persisted until they are processed.** Long-term storage and replayability of messages are not a concept JMS was designed for.

**The core Kafka principles of append-only logs, offsets, guaranteed ordering, retention time, compacted topics, and so on provide many additional benefits beyond the durability guarantees of a JMS.** Backpressure handling, true decoupling between consumers, the replayability of historical events, and more are huge differentiators between JMS and Kafka.

Check the Kafka docs for a deep dive into the Kafka storage system. I don’t want to touch on how **Tiered Storage for Kafka** is changing the game even more by providing even better scalability and cost-efficient long-term storage within the Kafka log.

### 7. Server-side data-processing with JMS vs. decoupled continuous stream processing with Kafka

**TL;DR: JMS message brokers provide simple server-side event processing, like filtering or routing based on the message content. Kafka brokers are dumb. Its data processing is executed in decoupled applications/microservices.**

### Server-side JMS filtering and routing

Most JMS message brokers provide some features for server-side event processing. These features are handy for some workloads!

Just be careful that server-side processing usually comes with a cost. For instance:

-   **JMS Pre-filtering scalability issues**: The broker has to handle so many things. This can kill the broker in a hidden fashion
-   **JMS Selectors (= routing) performance issues**: It kills 40–50% of performance

Again, sometimes, the drawbacks are acceptable. Then this is a great functionality.

### Kafka — Dumb pipes and smart endpoints

**Kafka intentionally does not provide server-side processing**. The brokers are dumb. The processing happens at the smart endpoints. This is a very well-known design pattern: [Dumb pipes and smart endpoints](https://martinfowler.com/articles/microservices.html###SmartEndpointsAndDumbPipes).

The **drawback** is that you need **separate applications/microservices/data products to implement the logic**. This is not a big issue in serverless environments (like using a ksqlDB process running in Confluent Cloud for data processing). It gets more complex in self-managed environments.

However, the **massive benefit** of this architecture is the **true decoupling** between applications/technologies/programming languages, **separation of concerns** between business units for building business logic and operations of infrastructure, and the **much better scalability and elasticity**.

Would I like to see a few server-side processing capabilities in Kafka, too? Yes, absolutely. Especially for small workloads, the performance and scalability impact should be acceptable! Though, the risk is that people misuse the features then. The future will show if Kafka will get there or not.

### 8. Complex operations vs. serverless cloud

**TL;DR: Self-managed operations of scalable JMS message brokers or Kafka clusters are complex. Serverless offerings (should) take over the operations burden.**

### Operating a cluster is complex — no matter if JMS or Kafka

A **basic JMS message broker is relatively easy to operate** (including active/passive setups). However, this **limits scalability and availability**. The JMS API was designed to talk to a single broker or active/passive for high availability. This concept covers the **application domain**.

More than that (= **clustering**) is **very complex with JMS message brokers**. More advanced message broker clusters from commercial vendors are more powerful but much harder to operate.

**Kafka** is a **powerful, distributed system**. Therefore, **operating a Kafka cluster is not easy by nature**. Cloud-native tools like an operator for Kubernetes take over some burdens like rolling upgrades or handling fail-over.

Both JMS message brokers and Kafka clusters are the more challenging, the more scale and reliability your SLAs demand. **The JMS API is not specified for a central data hub** (using a cluster). Kafka **is intentionally built for the strategic enterprise architecture**, not just for a single business application.

### Fully managed serverless cloud for the rescue

As the **JMS API was designed to talk to a single broker, it is hard to build a serverless cloud offering that provides scalability**. Hence, in JMS cloud services, the consumer has to set up the routing and role-based access control to the specific brokers. **Such a cloud offering is not serverless but cloud-washing**! But there is no other option as the JMS API is not like Kafka with one big distributed cluster.

In Kafka, the situation is different. **As Kafka is a scalable distributed system, cloud providers can build cloud-native serverless offerings**. Building such a fully managed infrastructure is still super hard. Hence, evaluate the product, not just the marketing slogans!

**Every Kafka cloud service is marketed as “fully managed” or “serverless” but most are NOT**. Instead, most vendors just provision the infrastructure and let you operate the cluster and take over the support risk. On the other side, some fully managed Kafka offerings are super limited in functionality (like allowing a very limited number of partitions).

**Some cloud vendors even exclude Kafka support from their Kafka cloud offerings**. Insane, but true. Check the terms and conditions as part of your evaluation.

### 9. Java/JVM vs. any programming language

**TL;DR: JMS focuses on the Java ecosystem for JVM programming languages. Kafka is independent of programming languages.**

As the name **JMS (=Java Message Service)** says: JMS was written only for Java officially. Some broker vendors support their own APIs and clients. These are proprietary to that vendor. Almost all severe JMS projects I have seen in the past use Java code.

**Apache Kafka** also only provides a **Java client**. But **vendors and the community provide other language bindings for almost every programming language, plus a REST API for HTTP communication for producing/consuming events to/from Kafka**. For instance, check out the blog post “[12 Programming Languages Walk into a Kafka Cluster](https://www.confluent.io/de-de/blog/12-programming-languages-walk-into-a-kafka-cluster/)” to see code examples in Java, Python, Go, .NET, Ruby, node.js, Groovy, etc.

The **true decoupling of the Kafka backend enables very different client applications to speak with each other, no matter what programming languages one uses**. This flexibility allows for building a proper [domain-driven design (DDD) with a microservices architecture leveraging Kafka as the central nervous system](https://www.confluent.io/blog/microservices-apache-kafka-domain-driven-design/).

### 10. Single JMS deployment vs. multi-region (including hybrid and multi-cloud) Kafka replication

**TL;DR: The JMS API is a client specification for communication between the application and the broker. Kafka is a distributed system that enables various architectures for hybrid and multi-cloud use cases.**

JMS is a client specification, while multi-data center replication is a broker function. I won’t go deep here and put it simply: **JMS message brokers are not built for replication scenarios across regions, continents, or hybrid/multi-cloud environments**.

Multi-cluster and cross-data center deployments of Apache Kafka have become the norm rather than an exception. Various **scenarios require multi-cluster Kafka solutions**. Specific requirements and trade-offs need to be looked at.

Kafka technologies like MirrorMaker (open source) or Confluent Cluster Linking (commercial) enable [use cases such as disaster recovery, aggregation for analytics, cloud migration, mission-critical stretched deployments and global Kafka deployments](https://www.kai-waehner.de/blog/2020/01/29/deployment-patterns-distributed-hybrid-edge-global-multi-data-center-kafka-architecture/).

I covered hybrid cloud architectures in various other blog posts. “[Low Latency Data Streaming with Apache Kafka and Cloud-Native 5G Infrastructure](https://www.kai-waehner.de/blog/2021/05/23/apache-kafka-cloud-native-telco-infrastructure-low-latency-data-streaming-5g-aws-wavelength/)” is a great example.

### JMS and Kafka solve distinct problems!

The ten comparison criteria show that **JMS and Kafka are very different things**. While both overlap (e.g., messaging, real-time, mission-critical), they use different technical capabilities, features, and architectures to support additional use cases.

In short, **use a JMS broker for simple and low-volume messaging from A to B**. **Kafka is usually a real-time data hub between many data sources and data sinks**. Many people call it the central real-time nervous system of the enterprise architecture.

**The data integration and data processing capabilities of Kafka at any scale with true decoupling and event replayability are the major differences from JMS-based MQ systems.**

However, especially **in the serverless cloud, don’t fear Kafka being too powerful (and complex)**. Serverless Kafka projects often start very cheaply at a very low volume, with **no operations burden**. Then it can scale with your growing business without the need to re-architect the application.

Understand the technical differences between a JMS-based message broker and data streaming powered by Apache Kafka. **Evaluate both options to find the right tool for the problem**. Within messaging or data streaming, do further detailed evaluations. Every message broker is different even though they all are JMS compliant. In the same way, all Kafka products and cloud services are different regarding features, support, and cost.

Do you use JMS-compliant message brokers? What are the use cases and limitations? When did you or do you plan to use Apache Kafka instead? Let’s [connect on LinkedIn](https://www.linkedin.com/in/kaiwaehner/) and discuss it! Stay informed about new blog posts by [subscribing to my newsletter](https://www.kai-waehner.de/newsletter/).

---
# Apache Kafka vs. Message Broker: Trade-Offs, Integration, Migration 

A Message broker has very different characteristics and use cases than a data streaming platform like Apache Kafka. A business process requires more than just sending data in real-time from a data source to a data sink. Data integration, processing, governance, and security must be reliable and scalable end-to-end across the business process. This blog post explores the capabilities of message brokers, the relation to the JMS standard, trade-offs compared to data streaming with Apache Kafka, and typical integration and migration scenarios. A case study explores the migration from IBM MQ to Apache Kafka. The last section contains a complete slide deck that covers all these aspects in more detail.

(Originally posted on Kai Waehner’s blog: “[Message Broker and Apache Kafka: Trade-Offs, Integration, Migration](https://www.kai-waehner.de/blog/2023/03/02/message-broker-and-apache-kafka-trade-offs-integration-migration/)”… Join the data streaming community and stay informed about new blog posts by [subscribing to my newsletter](https://www.kai-waehner.de/blog/2023/03/02/message-broker-and-apache-kafka-trade-offs-integration-migration/))

### Message Broker vs. Apache Kafka -> Apples and Oranges

TL;DR: Message brokers send data from a data source to one or more data sinks in real time. Data streaming provides the same capability but adds long-term storage, integration, and processing capabilities.

Most **message brokers implement the JMS (Java Message Service) standard**. Most commercial messaging solutions **add additional proprietary features**. Data streaming has no standard. But the [de facto standard is Apache Kafka](https://www.kai-waehner.de/blog/2021/05/09/kafka-api-de-facto-standard-event-streaming-like-amazon-s3-object-storage/).

I already did a detailed [comparison of (JMS-based) message brokers and Apache Kafka](https://www.kai-waehner.de/blog/2022/05/12/comparison-jms-api-message-broker-mq-vs-apache-kafka/) based on the following characteristics:

1.  Message broker vs. data streaming platform
2.  API Specification vs. open-source protocol implementation
3.  Transactional vs. analytical workloads
4.  Storage for durability vs. true decoupling
5.  Push vs. pull message consumption
6.  Simple vs. powerful and complex API
7.  Server-side vs. client-side data-processing
8.  Complex operations vs. serverless cloud
9.  Java/JVM vs. any programming language
10.  Single deployment vs. multi-region

I will not explore the trade-offs again. Just check out the other [blog post](https://www.kai-waehner.de/blog/2022/05/12/comparison-jms-api-message-broker-mq-vs-apache-kafka/). I also already covered implementing event-driven design patterns from messaging solutions with data streaming and Apache Kafka. Check out how to use a [dead letter queue (DLQ) with data streaming](https://www.kai-waehner.de/blog/2022/05/30/error-handling-via-dead-letter-queue-in-apache-kafka/) or the [request-response concept with Kafka](https://www.kai-waehner.de/blog/2022/06/03/apache-kafka-request-response-vs-cqrs-event-sourcing/) (and understand when and why NOT to use it).

The below slide deck covers all these topics in much more detail. Before that, I want to highlight related themes in its sections:

-   **Case study**: How the retailer Advance Auto Parts modernized its enterprise architecture
-   **Integration** between a message broker (like IBM MQ) and Apache Kafka
-   **Mainframe** deployment options for data streaming
-   **Migration** from a message broker to data streaming

### Case Study: IT Modernisation from IBM MQ and Mainframe to Kafka and Confluent Cloud

Advance Auto Parts is **North America’s largest automotive aftermarket parts provider**. The retailer ensures the right parts from its 30,000 vendors are in stock for professional installers and do-it-yourself customers across all of its 5,200 stores.

[Advance Auto Parts implement data streaming and stream processing use cases](https://www.confluent.io/online-talks/Real-Time-Data-at-Advance-Auto-Parts/) that deliver immediate **business value**, including:

-   **Real-time invoicing** for a large commercial supplier
-   **Dynamic pricing** updates by store and location
-   **Modernization** of the company’s business-critical merchandising system

Here are a few details about Advance Auto Parts’ success story:

-   Started small with Confluent Cloud and scaled as needed while minimizing administrative overhead with a fully managed, cloud-native Kafka service
-   Integrated data from more than a dozen different sources, including IBM Mainframe and IBM MQ through Kafka to the company’s ERP supply chain platform
-   Used stream processing and ksqlDB to filter events for specific customers and to enrich product data
-   Linked Kafka topics with Amazon S3 and Snowflake using Confluent Cloud sink connectors
-   Set the stage for continued improvements in operational efficiency and customer experience for years to come

### Integration Architecture BEFORE and AFTER at Advance Auto Parts

BEFORE — **Legacy infrastructure and architecture,** including IBM MQ and IBM AS/400 Mainframe, did not meet real-time performance requirements:

![](https://miro.medium.com/v2/resize:fit:875/0*zSg-JdpYQrrXSMvE.png)

AFTER — **Future-proof data architecture**, including Kafka-powered Confluent Cloud, for real-time invoicing and dynamic pricing:

![](https://miro.medium.com/v2/resize:fit:875/0*aOS_3Op2yllb2ha3.png)

### Integration between a message broker and Apache Kafka

The **most common scenario for message brokers and data streaming is a combination of both**. These two technologies are built for very different purposes.

**Point-to-point application integration (at a limited scale) is easy to build with a message broker**. Systems are tightly coupled and combine messaging with web services and databases. This is how most spaghetti architectures originated.

**A data streaming platform usually has various data sources (including message brokers) and independent downstream consumers**. Hence, data streaming is a much more strategic platform in enterprise architecture. It enables a clean separation of concerns and decentralized decoupling between domains and business units.

Integrating messaging solutions like IBM MQ, TIBCO EMS, RabbitMQ, ActiveMQ, or Solace and data streaming platforms around Apache Kafka leverage **Kafka Connect as integration middleware**. Connectors come from data streaming vendors like Confluent. Or from the messaging provider. For instance, IBM also provides Kafka connectors for IBM MQ.

The integration is straightforward and enables uni- or bi-directional communication. An enormous benefit of using [Kafka Connect instead of another ETL tool or ESB](https://www.kai-waehner.de/blog/2019/03/07/apache-kafka-middleware-mq-etl-esb-comparison/) is that you **don’t need another middleware for the integration**. If you need to understand the fundamental differences between MQ, ETL, ESB, iPaaS, and Data Streaming, check out this [comparison of traditional middleware and Apache Kafka](https://www.kai-waehner.de/blog/2021/11/03/apache-kafka-cloud-native-ipaas-versus-mq-etl-esb-middleware/).

### Mainframe integration with IBM MQ and Kafka Connect

The **mainframe is a unique infrastructure using the IBM MQ message broker**. Cost, connectivity, and security look different from other traditional enterprise components.

The most common approaches for the [integration between mainframe and data streaming](https://www.kai-waehner.de/blog/2020/04/24/mainframe-offloading-replacement-apache-kafka-connect-ibm-db2-mq-cdc-cobol/) are Change Data Capture (CDC) from the IBM DB2 database (e.g., via IBM IIDR), direct VSAM file integration (e.g., via Precisely), or connectivity via IBM MQ.

Publishing messages from IBM MQ to Kafka improves data reliability, accessibility, and offloading to cloud services. This **integration requires no changes to the existing mainframe applications**. But it dramatically **reduces MQ-related MIPS** to move data off the Mainframe.

However, it raises an interesting question: Where should Kafka Connect be deployed? On the mainframe or in the traditional IT environment? At Confluent, we support **deploying Kafka Connect and the IBM MQ connectors on the mainframe**, specifically on zLinux / the System z Integrated Information Processor (zIIP).

![](https://miro.medium.com/v2/resize:fit:875/0*t-KiZ1PszO8vEGLv.png)

This shows vast benefits for the customer, like **10x better performance and MQ MIPS cost reductions of up to 90%**.

### Migration from a message broker to data streaming because of cost or scalability issues

Migration can mean two things:

-   **Completely migrating away** from the existing messaging infrastructure, including client and server-side
-   **Replacing message brokers** (like TIBCO EMS or IBM MQ) because of licensing or scalability issues **but keeping the JMS-based messaging applications running**

The first option is a big bang, which often includes a lot of effort and risk. If the main points are license costs or scalability problems, another alternative is viable with the [Confluent Accelerator](https://www.confluent.io/confluent-accelerators/) **“JMS Bridge” to migrate from JMS to Kafka on the server side**:

![](https://miro.medium.com/v2/resize:fit:875/0*iIqpHPk2rM_ewvSJ.png)

**The Confluent JMS Bridge enables the migration from JMS brokers to Apache Kafka (while keeping the JMS applications).** Key features include:

-   The JMS Bridge is built around a modified open-source JMS engine
-   **Supports full JMS 2.0 spec as well as Confluent/Kafka**
-   Publish and subscribe anywhere data is intended for end users
-   JMS-specific message formats can be supported via Schema Registry (Avro)
-   Existing JMS applications replace current JMS implementation jars with Confluent jars that embed an open-source JMS implementation and wrap it to the Kafka API

### Slide Deck and Video: Message Broker vs. Apache Kafka

The following slide deck explores the trade-offs, integration options, and migration scenarios for JMS-based message brokers and data streaming with Apache Kafka. Even if you use a message broker that is not JMS-based (like RabbitMQ), most of the aspects are still valid for a comparison:

[pvfw-embed viewer_id=”5253" width=”100%” height=”800"]

And here is the on-demand video recording for the above slide deck:

[https://www.youtube.com/watch?v=VA3NR5s-AQQ](https://www.youtube.com/watch?v=VA3NR5s-AQQ)

### Data streaming is much more than messaging!

This blog post explored when to use a message broker or a data streaming platform, how to integrate both, and how to migrate from JMS-based messaging solutions to Apache Kafka. Advance Auto Parts is a great success story from the retail industry that solves the spaghetti architecture with a decentralized, fully managed data streaming platform.

**TL;DR: Use a JMS broker for simple, low-volume messaging from A to B.**

**Apache Kafka is usually a data hub between many data sources and data sinks, enabling real-time data sharing for transactional and high-volume analytical workloads. Kafka is also used to build applications; it is more than just a producer and consumer API.**

The data integration and data processing capabilities of Kafka at any scale with true decoupling and event replayability are significant differences from JMS-based MQ systems.

What message brokers do you use in your architecture? What is the mid-term strategy? Integration, migration, or just keeping the status quo? Let’s [connect on LinkedIn](https://www.linkedin.com/in/kaiwaehner/) and discuss it! Stay informed about new blog posts by [subscribing to my newsletter](https://www.kai-waehner.de/newsletter/).

---
# Integrate Apache Camel JMS, IBM MQ and Spring-Boot

Apache Camel is an Open Source integration framework that empowers you to quickly and easily integrate various systems consuming or producing data. In this article I will give an example how to integrate IBM MQ with Apache Camel and Spring-Boot

### Environment

I will use the latest tech stack in this demo(2023 Feb)

-   JDK 17
-   Apache Camel 4.0.0-M1
-   Spring-Boot 3.0.2 (Since 3.0 it requires JDK 17)
-   IBM MQ 9.3.1.1
-   Kotlin 1.7.22

### IBM MQ container

`docker-compose.yaml`
```yaml
version: "3.2"  
volumes:  
  mqData:  
networks:  
  backend:  
  
services:  
  ibmmq:  
    image: icr.io/ibm-messaging/mq:latest  
    container_name: ibmmq  
    ports:  
      - 9443:9443  
      - 1414:1414  
    volumes:  
      - mqData:/mnt/mqm  
    environment:  
      LICENSE: accept  
      MQ_QMGR_NAME: QM1  
      MQ_APP_PASSWORD: passw0rd   
    networks:  
      - backend%                    
```
The image tag is `ibm-mqadvanced-server-dev:9.3.1.1-r1.20230111091233.bcdd76c-amd64`

### JDK17 and javax

All the J2EE related namespace `javax` have been moved to `Jakarta` , such as JMS, Servlet. refer to:

### Javax to Jakarta Namespace Ecosystem Progress | The Eclipse Foundation

### On Sept 10th, 2019, the Eclipse Foundation announced the release of the Jakarta EE 8 Full Platform and Web Profile…


Spring announce requirements for spring framework 6(spring-boot 3.0): [https://spring.io/blog/2021/09/02/a-java-17-and-jakarta-ee-9-baseline-for-spring-framework-6](https://spring.io/blog/2021/09/02/a-java-17-and-jakarta-ee-9-baseline-for-spring-framework-6)

> As announced at SpringOne yesterday, Spring Framework 6 and Spring Boot 3 are planned towards a high-end baseline for their general availability in Q4 2022:  
> **Java 17+** (from Java 8–17 in the Spring Framework 5.3.x line)  
> **Jakarta EE 9+** (from Java EE 7–8 in the Spring Framework 5.3.x line)

I will recommend use `sdkman` to manage JDK version. refer to [https://sdkman.io/install](https://sdkman.io/install)

e.g.

sdk list java  
sdk install java 17.0.6-zulu  
sdk use java 17.0.6-zulu 

### build.gradle
```java
import org.jetbrains.kotlin.gradle.tasks.KotlinCompile  
buildscript {  
 ext {  
  camelVersion = "4.0.0-M1"  
  mqJmsVersion = "3.0.2"  // for JDK17  
  jakartaVersion = "10.0.0"  
 }  
}  
plugins {  
 id 'org.springframework.boot' version '3.0.2'  
 id 'io.spring.dependency-management' version '1.1.0'  
 id 'org.jetbrains.kotlin.jvm' version '1.7.22'  
 id 'org.jetbrains.kotlin.plugin.spring' version '1.7.22'  
}  
  
group = 'com.example'  
version = '0.0.1-SNAPSHOT'  
sourceCompatibility = '17'  
  
repositories {  
 mavenCentral()  
}  
  
dependencyManagement {  
 imports {  
  mavenBom "org.apache.camel.springboot:camel-spring-boot-bom:$camelVersion"  
 }  
}  
dependencies {  
 implementation(  
   'org.apache.camel.springboot:camel-spring-boot-starter',  
   'org.jetbrains.kotlin:kotlin-reflect',  
   'org.jetbrains.kotlin:kotlin-stdlib-jdk8',  
   "com.ibm.mq:mq-jms-spring-boot-starter:$mqJmsVersion",  
   "org.apache.camel:camel-jms:$camelVersion",  
   // prefer jms-api only, jakartaee brings too much libs  
   "javax.jms:javax.jms-api:2.0.1",  
   // "jakarta.platform:jakarta.jakartaee-api:$jakartaVersion",  
   // here use spring-web to keep camel context alive, otherwise we need to explicitly start camel context  
   "org.springframework.boot:spring-boot-starter-web",  
 )  
  
 testImplementation 'org.springframework.boot:spring-boot-starter-test'  
}  
  
tasks.withType(KotlinCompile) {  
 kotlinOptions {  
  freeCompilerArgs = ['-Xjsr305=strict']  
  jvmTarget = '17'  
 }  
}  
  
tasks.named('test') {  
 useJUnitPlatform()  
}
```
### EIPs (Enterprise Integration Patterns)

Camel supports most of the [Enterprise Integration Patterns](http://www.eaipatterns.com/toc.html) from the excellent book by Gregor Hohpe and Bobby Woolf. refer to [https://camel.apache.org/components/3.20.x/eips/enterprise-integration-patterns.html](https://camel.apache.org/components/3.20.x/eips/enterprise-integration-patterns.html)

In this article, I implemented a very simple pattern.

The application is listening to MQ `DEV.QUEUE.1` , add some texts at the beginning of the message, then convert all characters to uppercase, then send to `DEV.QUEUE.2`

![](https://miro.medium.com/v2/resize:fit:875/1*6GpXx4SgNo7ne2KUVSBUXQ.png)

### Route definition
```java
@Component  
class JMSRouteBuilder : RouteBuilder() {  
    @Throws(Exception::class)  
    override fun configure() {  
        log.info("configure JMSRouteBuilder")  
        from("jmsComponent:queue:DEV.QUEUE.1")  
            .process { exchange -> println(exchange.getIn().body) }  
            .process(JmsMessageProcessor())  
            .transform()  
            .method("jmstransformer", "doTransform")  
            .to("jmsComponent:queue:DEV.QUEUE.2")  
    }  
}
```
### Processor

```java
class JmsMessageProcessor : Processor {  
    private val log: Logger = LoggerFactory.getLogger(this.javaClass)  
    @Throws(Exception::class)  
    override fun process(exchange: Exchange) {  
        val input = exchange.getIn().getBody(String::class.java)  
        val output = "JmsMessageProcessor:$input"  
        log.info("JmsMessageProcessor complete: $input")  
        exchange.getIn().body = output  
    }  
}
```
### Transformer

use bean, actually it is samething as processor
```java
@Component("jmstransformer")  
class JmsTransformerBean {  
    private val log: Logger = LoggerFactory.getLogger(this.javaClass)  
    fun doTransform(input: String): String {  
        log.info("doTransform $input")  
        return input.uppercase(Locale.getDefault())  
    }  
}
```
### Test

-   start the spring application (bootRun in intellij)
-   start MQ container
```shell
docker-compose up  
open https://localhost:9443, login with admin/passw0rd
```
![](https://miro.medium.com/v2/resize:fit:875/1*6vrrXSti9EkV-M9WBwsQbQ.png)

-   Click `DEV.QUEUE.1` and create a message on `DEV.QUEUE.1`

![](https://miro.medium.com/v2/resize:fit:875/1*bhxXOaPqSRuR3K6W74rHjw.png)

The Spring application console displays:

2023-02-12T19:18:17.684+08:00  INFO 8195 --- [           main] o.a.c.impl.engine.AbstractCamelContext   : Apache Camel 4.0.0-M1 (camel-1) is starting  
2023-02-12T19:18:17.708+08:00  INFO 8195 --- [           main] o.a.c.impl.engine.AbstractCamelContext   : Routes startup (started:1)  
2023-02-12T19:18:17.708+08:00  INFO 8195 --- [           main] o.a.c.impl.engine.AbstractCamelContext   :     Started route1 (jmsComponent://queue:DEV.QUEUE.1)  
2023-02-12T19:18:17.708+08:00  INFO 8195 --- [           main] o.a.c.impl.engine.AbstractCamelContext   : Apache Camel 4.0.0-M1 (camel-1) started in 345ms (build:60ms init:263ms start:22ms)  
2023-02-12T19:18:17.713+08:00  INFO 8195 --- [           main] com.example.demo.DemoApplicationKt       : Started DemoApplicationKt in 4.79 seconds (process running for 5.688)  
test1  
2023-02-12T21:59:33.457+08:00  INFO 8195 --- [er[DEV.QUEUE.1]] c.e.demo.service.JmsMessageProcessor     : JmsMessageProcessor complete: test1  
2023-02-12T21:59:33.538+08:00  INFO 8195 --- [er[DEV.QUEUE.1]] c.e.demo.service.JmsTransformerBean      : doTransform JmsMessageProcessor:test1

and the message is moved to `DEV.QUEUE.2`

![](https://miro.medium.com/v2/resize:fit:875/1*tbnXbTjddhsFG5EejSGA8g.png)

https://github.com/softarts/camel-spring-demo

---
# IBM MQ Communication in Docker. Sometimes during migration projects

Sometimes during migration projects, we face situations where we need to use older technologies in combination with modern tools. Today, I would like to show you how to write a very simple application for communicating with an IBM MQ Queue. I will also demonstrate how you can start an IBM MQ Manager locally using Docke.

### IBM Messaging

We start the IBM messaging container in Docker. For this we have to download the corresponding image. It

1) Pull the image from IBM Registry

 docker pull icr.io/ibm-messaging/mq:latest

Of course, you can also check if the image was really downloaded

docker image ls

and you have to see at leas this images (maybe more)

![images after pull image from ibm registry](https://miro.medium.com/v2/resize:fit:875/1*wvGqzBxlUSFSgJWduaT4Q.png)

2) Create the persistens storage

You have to create some volume, because thanks volume, we can avoid the situation, that we mustcreate the queue after each rebuild.
```shell
 docker volume create qm1data

 docker run  --env LICENSE=accept  --env MQQMGRNAME=QM1  --volume qm1data:/mnt/mqm  --publish 1414:1414  --publish 9443:9443  --detach  --env MQAPPPASSWORD=passw0rd  --name QM1  icr.io/ibm-messaging/mq:latest
```
At the end, you can also check if the container is really running with the command for listening of all running containers.
```shell
docker ps
```
I hope so, that you see something as on the picture.

![](https://miro.medium.com/v2/resize:fit:1250/1*O2EO2kSMBQ3UUi3BTIoY7g.png)

Congratulations 🥳🥳 you are started the IBM Messaging in Docker.

### Set up the IBM messaging

1) Open the console

Go to [url](https://localhost:9443/ibmmq/console/) ([https://localhost:9443/ibmmq/console/](https://localhost:9443/ibmmq/console/)) and it will he open the loging screen for IBM messaging.

![](https://miro.medium.com/v2/resize:fit:875/1*PjbpTwIO5RMx3151Uwh7Zg.png)

2) Log in as admin

If you don’t make any chages in run command for IBM container. You can log in wiht admin user and tha passwort. Passwort was set up during the start of container.

User = **admin**  
Password = **passw0rd**

3) Create queue for reading and saving the string

On the left side of navigation menu, please

![](https://miro.medium.com/v2/resize:fit:306/1*h6Gjk1pboqKkTfSNp7frmQ.png)

After this you can see all queues, which are avaliable in your IBM MQ Server. You can see something as this:

![](https://miro.medium.com/v2/resize:fit:875/1*WP5IU545AtcJHHiq4kwKCw.png)

If you want to create new queue, you have to click on the button create:

![](https://miro.medium.com/v2/resize:fit:875/1*WkMxlZICFcgBWRwkUYnPPg.png)

On the next page it is neccessary to choose the local variant.

![](https://miro.medium.com/v2/resize:fit:875/1*JtyDSUBFnMMW6ndg9I-yDg.png)

And choose the right name of queue. It is commen to use dot-syntax. That is mean, for communication from development to Q1 it is the best name:

DEV.TO.Q1

The best solution is, if you create one more queue for reading the message from IBM Managare. According to name convetion it is:

Q1.TO.DEV

### Java (Client) part

1) Spring Boot application

You can create your application from basis, but I recommend to generatethe application using [Spring Initializr](https://start.spring.io/).

I recommendet to set up the projec as the show followed picture. Lombok framewokr it is not neccessary but it make us the life easier.

![](https://miro.medium.com/v2/resize:fit:875/1*nXHsaUkDQtVSoUSNoliRzw.png)

2) Dependecy for MQ communication

For the communication with IBM messaging you can use the spring boot starter:

mq-jms-spring-boot-starter

As it is usually by Maven you must add this dependency in maven file. Therefore please open POM.xml and paste the following dependency (check the version, maybe it is some new version).
```xml
  <!-- https://mvnrepository.com/artifact/com.ibm.mq/mq-jms-spring-boot-starter -->  
  <dependency>  
     <artifactId>mq-jms-spring-boot-starter</artifactId>  
     <groupId>com.ibm.mq</groupId>  
     <version>3.1.0</version>  
  </dependency>
```
3) Set up applications.properties

Because you are using spring boot and mq-jms starter you can set up the propertie only via applications.properties. That is mean we are responsible only for filling up the correct value.

In the next code block it is describe what is it the meaning of every singe parameter.
```shell
ibm.mq.queueManager= ###name of queue manager  
ibm.mq.channel= ### channel of queue manager  
ibm.mq.connName= ### url or ip address with port in parenthesis  
ibm.mq.user= ### user name  
ibm.mq.password= ### password for user  
  
### the next two properties we define for calling the right queue  
ibm.mq.sendingQueueName=   
ibm.mq.receivingQueueName=

In our case we can fill up the properties in this way:

### MQ Communication properties  
ibm.mq.queueManager=QM1  
ibm.mq.channel=DEV.ADMIN.SVRCONN  
ibm.mq.connName=127.0.0.1(1414)  
ibm.mq.user=admin  
ibm.mq.password=passw0rd  
ibm.mq.sendingQueueName=Q1.TO.DEV  
ibm.mq.receivingQueueName=DEV.TO.Q1
```
4) Service for communication with IBM MQ

Now we have prepared everthing indispensably for successfully start of spring boot application. Lets to implement the class for the communication. You must create the class MQCommunication and supply this class with some annotation. Whole code you can find in the following code block:
```java
@Service  
@Log4j2  
@RequiredArgsConstructor  
public class MQCommunication {  
  
  private final  ApplicationContext applicationContext  
  
}
```
5) Reading and sending name of queue

Do you remember, that we define two user-defined properties. It is the right time to use it. You call the value of this properties from file. For this purpose we can use in Spring Boot the annotation @Value. This code must be copied in MQCommunication.class.
```java
  @Value("${ibm.mq.sendingQueueName:Q1.TO.DEV}")  
  String nameOfSendingQueue;  
  
  @Value("${ibm.mq.receivingQueueName:DEV.TO.Q1}")  
  String nameOfReceivingQueue;
```
6) Read string from MQ

In this step you can start implement the method for reading the value from IBM Manager. The core of this function is JmsTemplate and function receive().
```java
  public String readMessageFromMq() throws JMSException {  
    JmsTemplate jmsTemplate = getApplicationContext().getBean(JmsTemplate.class);  
    TextMessage textMessage = (TextMessage) jmsTemplate.receive(nameOfReceivingQueue);  
    assert textMessage != null;  
    String stringFromQueue;  
    try {  
      stringFromQueue = textMessage.getText();  
    } catch (JMSException e) {  
      log.error(e.getMessage());  
      throw e;  
    }  
    return stringFromQueue;  
  }
```
7) Save string to MQ

It is one more methode, which are missing to implement. You muss have the possibility to save some string in IBM Management. As before (method for reading) you are using JmsTemplate from SpringBoot.
```java
  public void sendMessageToMQ(String mqString) throws JmsException {  
    JmsTemplate jmsTemplate = getApplicationContext().getBean(JmsTemplate.class);  
    try {  
      jmsTemplate.convertAndSend(nameOfSendingQueue, mqString);  
    } catch (JmsException e) {  
      log.error(e.getMessage());  
      throw e;  
    }  
  }
```
7) Rest controller

Now it is only about cherry on the cake. You can write the RestController for easy testing of your code.
```java
@RestController  
@RequestMapping("api/v1")  
@RequiredArgsConstructor  
public class MqCommunicationController {  
  
  private final MQCommunication mqCommunication;  
  
  @GetMapping("save")  
  public void saveStringInMq(@RequestBody String stringToSaveInMq){  
    mqCommunication.sendMessageToMQ(stringToSaveInMq);  
  }  
  
  @GetMapping("read")  
  public String readStringFromMQ() throws JMSException {  
    return mqCommunication.readMessageFromMq();  
  }  
}
```
If you don’t want to write the code yourselfe, you can checkout whole code source in my [Github]

https://github.com/maravondra/mqcommunication

Congratulations 🥳🥳 Last step is start the application and call the endpoints.

---
# IBM MQ Explorer Tool. IBM MQ Explorer is a powerful tool


IBM MQ Explorer is a powerful tool designed to facilitate the management, monitoring, and administration of IBM MQ (Message Queue) components.

So What is a Message queue?

> A message queue is a communication mechanism that enables asynchronous communication between different processes, components, or systems.

It serves as an intermediary buffer for messages, allowing one part of a system to send a message to another part without requiring the sender and receiver to be actively engaged at the same time. Message queues are commonly used in distributed computing, inter-process communication, and microservices architectures. With features like guaranteed delivery and message persistence, various technologies such as IBM MQ, RabbitMQ, and Apache Kafka implement message queues, catering to diverse communication needs in modern distributed computing environments.

In this blog post, we’ll delve into the features and functionalities of MQ Explorer, exploring how it plays a crucial role in simplifying the complexities associated with message-oriented middleware.

Before delving into MQ Explorer, let’s briefly touch upon IBM MQ itself.

> IBM MQ is a messaging middleware that enables communication and data exchange between disparate systems and applications. It ensures reliable, secure, and scalable message delivery across various platforms, making it an integral part of enterprise integration.

What is MQ Explorer?

> MQ Explorer is a graphical user interface (GUI) tool provided by IBM to manage and administer IBM MQ resources.

![](https://miro.medium.com/v2/resize:fit:875/0*uonMzstjkX9IPwtI.png)

> The official Java library for IBM MQ is part of the IBM MQ client installation. It includes the MQI(Message Queue Interface), allowing Java applications to connect to and interact with MQ resources. Java applications can use the JMS (Java Message Service) API for a higher-level messaging abstraction.

Key Features of MQ Explorer:

1.  Resource Management: MQ Explorer allows users to create, modify, and manage MQ resources such as queues, topics, channels, and listeners. This intuitive interface simplifies the configuration and deployment of messaging components.
2.  Monitoring and Statistics: Real-time monitoring of message queues and associated components is a crucial aspect of maintaining a robust messaging infrastructure. MQ Explorer provides a visual representation of message flows, queue depths, and other performance metrics, aiding administrators in identifying bottlenecks and optimizing system performance.
3.  Security Configuration: Security is paramount in enterprise messaging systems. MQ Explorer enables administrators to configure and manage access control lists (ACLs), authentication mechanisms, and authorization policies, ensuring that only authorized users and applications can interact with MQ resources.
4.  Channel Configuration: IBM MQ relies on communication channels for transmitting messages between queue managers. MQ Explorer simplifies the configuration of channels, allowing users to define properties such as channel types, transmission protocols, and SSL/TLS settings.
5.  Queue Browsing and Message Inspection: Users can browse through queues and inspect messages within MQ Explorer. This feature is particularly useful for troubleshooting and understanding message content, helping administrators identify issues and ensure the smooth flow of messages within the system.
6.  Connection and Queue Manager Management: MQ Explorer provides a centralized interface for managing multiple queue managers. Administrators can establish connections to different queue managers, view their status, and perform various administrative tasks without the need for command-line interactions.
7.  Integration with Other IBM Tools: MQ Explorer seamlessly integrates with other IBM tools and solutions, enhancing its capabilities. For example, it can be used in conjunction with IBM Integration Bus (IIB) for end-to-end integration solutions.

In conclusion, IBM MQ Explorer is a cross-platform tool designed for the management and administration of IBM MQ resources. Built on the Eclipse framework, it offers a user-friendly interface for configuring queues, channels, and other messaging components.

The tool supports remote administration, and scripting for automation, and provides visual topology views for a comprehensive understanding of the messaging architecture. Additional features include message tracing, health monitoring, role-based access control, and SSL/TLS configuration for secure communication. IBM MQ Explorer is a versatile solution for efficiently managing and monitoring IBM MQ environments.

---
# IBM MQ — Spring Boot mTLS. This article describe how to establish

This article describe how to establish connection between two parts, Client and Server using mutual TLS (mTLS). Client side is where JAVA Spring Boot service is deployed and Server side is an infrastructure where IBM MQ is. Below, I outline the necessary steps to configure an mTLS connection, with a primary focus on the client side.

### Client-Side Prerequisites

The client must have its own keystore and truststore. The server’s certificate, used in the SSL handshake, should be imported into the client’s truststore (see the “Testing mTLS” section, step 2).

**Regarding the client’s keystore:**

-   Generate an RSA keypair with a specific length.
-   Use this keypair to generate a CSR (Certificate Signing Request). Ensure the provided information is correct, as it will be used to generate the certificate. For example:

CN = example.com  
OU = ACME Dep  
O = ACME  
L = California  
S = San Francisco  
C = US

-   Request a public or organizational Certificate Authority (CA) to sign your certificate.
-   Based on the CSR, the CA will issue the certificate along with any root or intermediate certificates.
-   Attach the signed certificate to the client’s keypair by running the following command:
```shell
keytool -importcert -keystore your_client_keystore.jks -alias your_keypair_alias -file signed_certificate.cer
```
Ensure the alias matches the RSA keypair alias.

Once successful, you should see the message:

Certificate reply was installed in keystore

Alternatively, you can use KeyStore Explorer to import the CA reply by clicking on the keypair and selecting “Import CA Reply,” then choosing the certificate file.

### Changes in Source Code

Dependencies for Spring Boot:
```xml
    <dependency>  
      <groupId>com.ibm.mq</groupId>  
      <artifactId>mq-jms-spring-boot-starter</artifactId>  
      <version>correct_version</version>  
    </dependency>
```
Cipher mapping for non-IBM Java SDK users:

If you’re not using the IBM Java SDK, add this Java option:
```shell
1 -Dcom.ibm.mq.cfg.useIBMCipherMappings=false
```
### Service configuration

You can override built-in parameters to configure a standard IBM MQ TLS connection:
```yaml
ibm.mq:  
  queueManager: queueManager_name  
  channel: channel_name  
  connName: connName(50060), connName(50060)  
  user: John  
  password: pass

Other parameters were custom implementation needed to mTLS

 sslContextType: TLSv1.3 ### it depends on server side requirements  
 trustStorePassword: passwordToTrustStore  
 trustStoreType: jks  
 trustStoreLocation: /dir/truststore.jks  
 keyStorePassword: passwordToKeyStore  
 keyStoreType: jks  
 keyStoreLocation: /dir/keystore.jks  
 transportType: 1  
 sslFipsRequired: false  
 property:  
 XMSC_WMQ_SSL_CIPHER_SPEC: "<put here CipherSpec>" ### The name of the CipherSpec to be used on a TLS connection to a queue manager. The protocol used in negotiating the secure connection depends on the specified CipherSpec. It is important to ask server side about which algorithm was used.  
 ### available options: https://www.ibm.com/docs/en/ibm-mq/9.4?topic=cipherspecs-cipherspec-order-in-tls-handshake
```
For further CipherSpec options, refer to [IBM documentation](https://www.ibm.com/docs/en/ibm-mq/9.4?topic=cipherspecs-cipherspec-order-in-tls-handshake).

**Note:** Full code implementation is not provided here. You will need to implement the `JmsListenerContainerFactory<DefaultMessageListenerContainer>` and `ConnectionFactory` beans. In the latter, manually initialize the SSL context to specify which keystore and truststore should be loaded.

### Server-Side Prerequisites

The server side must have certificate in their truststore which will be used to authenticate the client _(your service)._ We need to send Root CA, intermediate certificate or different client certificate to server side. **That certificate should be also present in client keystore, attached to client RSA keypair.**

### mTLS Modes

Mutual TLS in IBM MQ can be set to **enforce** mode. In this mode each client will need to connect to server via mTLS to establish connection.

Or we can ask to set it to **optional.** During the integration, we may ask server side to temporarily switch the mTLS mode to **optional,** so that you can run UAT tests and additionally works on the mTLS connection.

### Testing mTLS

To verify that mTLS is working, enable SSL debugging by adding the following Java option:

-Djavax.net.debug=ssl,handshake

After restarting the service, you will see the full mTLS handshake process:

1.  Client connects to server
2.  Server presents its TLS certificate
3.  Client verifies the server’s certificate
4.  Client presents its TLS certificate
5.  Server verifies the client’s certificate
6.  Server grants access
7.  Client and server exchange information over encrypted TLS connection

Note to 1) If credentials and addresses are correct, the client should pass the first step.

Note to 3) If the truststore is correctly configured, the client will pass this step.

Ad 4) The client will pass this step if:

a) The certificate is successfully attached to the keypair (in the keystore). The log should display:

 Produced client Certificate handshake message (  
 "Certificates": [  
   "certificate" : {  
  "version"            : "v3",  
...

If the certificate is missing, you’ll see an empty list:

Produced client Certificate handshake message (  
 "Certificates": <empty list>  
 )  
...

b) The server’s truststore contains the client’s certificate or root CA.

If no exceptions appear in the logs, the integration should be ready. You can ask the server to enforce mTLS mode or manually initiate a connection to IBM MQ to verify.
---
# How to Connect Multiple IBM MQ in Spring Boot Application 

Maven Dependicies:

Properties:

Config:


Service:

Controller:
```xml
<iframe src="https://selcukc.medium.com/media/c18108d0233fd032f12f3145651d77a6" allowfullscreen="" frameborder="0" height="799" width="680" title="Spring Mq Controller" class="ei o fd qj bh" scrolling="no"></iframe>

    <dependency>
        <groupId>com.fasterxml.jackson.core</groupId>
        <artifactId>jackson-databind</artifactId>
    </dependency>

    <dependency>
        <groupId>com.ibm.mq</groupId>
        <artifactId>mq-jms-spring-boot-starter</artifactId>
        <version>3.0.6</version>
    </dependency>
    
    <dependency>
        <groupId>com.fasterxml.jackson.dataformat</groupId>
        <artifactId>jackson-dataformat-xml</artifactId>
        <version>2.15.0</version>
        </dependency>
    <dependency>

    <groupId>javax.xml.bind</groupId>
        <artifactId>jaxb-api</artifactId>
        <version>2.3.1</version>
    </dependency>

    <dependency>
        <groupId>com.fasterxml.woodstox</groupId>
        <artifactId>woodstox-core</artifactId>
        <version>6.5.0</version>
    </dependency>
```

[view raw](https://gist.github.com/selcukc34/2f8be853fab83195b978161375a7bd75/raw/1899b6c05b28f4910baa869484b53a78da9f02e5/spring_mq_dependecies.xml) [spring_mq_dependecies.xml](https://gist.github.com/selcukc34/2f8be853fab83195b978161375a7bd75#file-spring_mq_dependecies-xml) hosted with ❤ by [GitHub](https://github.com)

---
```shell
my.mq.queueManager=#{my.mq.queueManager}#
my.mq.channel=#{my.mq.channel}#
my.mq.host=#{my.mq.host}#
my.mq.port=#{my.mq.port}#
my.mq.user=#{my.mq.user}#
my.mq.password=#{my.mq.password}#
my.mq.queue=#{my.mq.queue}#
```
[view raw](https://gist.github.com/selcukc34/95d770c256d6cd15918a00d02c7d0477/raw/27791fc8be2f600709fcbd1c0609728722b753a7/spring_mq_properties.properties) [spring_mq_properties.properties](https://gist.github.com/selcukc34/95d770c256d6cd15918a00d02c7d0477#file-spring_mq_properties-properties) hosted with ❤ by [GitHub](https://github.com)

---
```java
package nl.mq.config;

import com.ibm.mq.jakarta.jms.MQQueueConnectionFactory;
import com.ibm.msg.client.jakarta.wmq.WMQConstants;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;
import org.springframework.jms.core.JmsOperations;
import org.springframework.jms.core.JmsTemplate;

@Configuration
public class MqConfig {

    @Value("${my.mq.queueManager}")
    private String queueManager;

    @Value("${my.mq.channel}")
    private String channel;

    @Value("${my.mq.host}")
    private String host;

    @Value("${my.mq.port}")
    private String port;

    @Value("${my.mq.user}")
    private String user;

    @Value("${my.mq.password}")
    private String password;

    @Value("${my.mq.mqcsp}")
    private String mqcsp;

    @Bean(name = "mqQueueConnectionFactorymy")
    public MQQueueConnectionFactory mqQueueConnectionFactorymy() {
        MQQueueConnectionFactory mqQueueConnectionFactory = new MQQueueConnectionFactory();
        mqQueueConnectionFactory.setHostName(host);

        try {
            mqQueueConnectionFactory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
            mqQueueConnectionFactory.setCCSID(1208);
            mqQueueConnectionFactory.setChannel(this.channel);
            mqQueueConnectionFactory.setPort(Integer.parseInt(this.port));
            mqQueueConnectionFactory.setQueueManager(this.queueManager);
            mqQueueConnectionFactory.put(WMQConstants.USER_AUTHENTICATION_MQCSP,Boolean.valueOf(this.mqcsp));

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return mqQueueConnectionFactory;
    }

    @Bean(name = "userCredentialsConnectionFactoryAdaptermy")
    UserCredentialsConnectionFactoryAdapter userCredentialsConnectionFactoryAdaptermy(@Qualifier("mqQueueConnectionFactorymy") MQQueueConnectionFactory mqQueueConnectionFactory) {
        UserCredentialsConnectionFactoryAdapter userCredentialsConnectionFactoryAdapter = new UserCredentialsConnectionFactoryAdapter();
        userCredentialsConnectionFactoryAdapter.setUsername(this.user);
        userCredentialsConnectionFactoryAdapter.setPassword(this.password);
        userCredentialsConnectionFactoryAdapter.setTargetConnectionFactory(mqQueueConnectionFactory);
        return userCredentialsConnectionFactoryAdapter;
    }

    @Bean(name = "jmsOperationsmy")
        public JmsOperations jmsOperationsmy(@Qualifier("userCredentialsConnectionFactoryAdaptermy") UserCredentialsConnectionFactoryAdapter userCredentialsConnectionFactoryAdapter) {
        JmsTemplate jmsTemplate = new JmsTemplate(userCredentialsConnectionFactoryAdapter);
        return jmsTemplate;
    }
}
```

[view raw](https://gist.github.com/selcukc34/d38cd5337ca17691159c499555d20aa7/raw/1cd70612eaeb6644fbe6de750e59a3d720de6b99/spring_mq_config.java) [spring_mq_config.java](https://gist.github.com/selcukc34/d38cd5337ca17691159c499555d20aa7#file-spring_mq_config-java) hosted with ❤ by [GitHub](https://github.com)

---
```java
package nl.mq.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsOperations;
import org.springframework.stereotype.Service;

@Service
public class MqService {
    @Value("${my.mq.queue}")
    private String queue;
    
    @Autowired
    @Qualifier("jmsOperationsmy")
    private JmsOperations jmsOperations;
    
    public String send(MqMessage mqMessage){
    String xml = "";
        try{
            XmlMapper xmlMapper = new XmlMapper();
            xmlMapper.configure( ToXmlGenerator.Feature.WRITE_XML_DECLARATION, true );
            xml = xmlMapper.writeValueAsString(mqMessage);
            jmsOperations.convertAndSend(this.queue, xml);
            return xml;
        }catch(JmsException | JsonProcessingException ex){
            throw new RuntimeException(ex);
        }
    }
}
```
[view raw](https://gist.github.com/selcukc34/717f086e5db2413dfa01dc8b8a45d364/raw/452a10f1b89388218b07a790f4e0e1e380915412/spring_mq_service.java) [spring_mq_service.java](https://gist.github.com/selcukc34/717f086e5db2413dfa01dc8b8a45d364#file-spring_mq_service-java) hosted with ❤ by [GitHub](https://github.com)

---
```java

package nl.mq.controller;

import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@SecurityRequirement(name = "BasicAuth")
@RequestMapping("/api/v1/mq/")
@EnableJms
public class MqController {

    private MqService mqService;
    public MqController(MqService mqService){
        this.mqService = mqService;
    }

    @PostMapping("/send")
    @ApiResponse(responseCode = "200", content = { @Content(schema = @Schema(implementation = MqMessage.class), mediaType = "application/json") })
    @ApiResponse(responseCode = "404", content = { @Content(schema = @Schema(implementation = CustomExceptionResponse.class), mediaType = "application/json") })
        public ResponseEntity<String> send(@Valid @RequestBody MqMessage message){
            return new ResponseEntity<>(mqService.send(message), HttpStatus.OK);
        }

    }
```
github.com/selcukc34

[view raw](https://gist.github.com/selcukc34/eb55a4ee0081ae5a662e57255b15ac9c/raw/bb7cbe4cbeb181040e1dab0397b353a895294db1/spring_mq_controller.java) [spring_mq_controller.java](https://gist.github.com/selcukc34/eb55a4ee0081ae5a662e57255b15ac9c#file-spring_mq_controller-java) hosted with ❤ by [GitHub](https://github.com)

---
### Apache Camel 4.x + Spring Boot 3.x + RabbitMq + IbmMq

> **What is Aapche Camel?**  
> “ Camel is an Open Source integration framework that empowers you to quickly and easily integrate various systems consuming or producing data.”

In this article, we are going to read data from IbmMq(producer) and send it to rabbitMq (consumer). I am going to run RabbitMq and IbmMq locally using Docker desktop. I will also share the docker command as well to run RabbitMq and IbmMq containers.

**Pre-requisites**:  
1. JDK — 17+  
2. Docker Desktop

Let’s start by executing the docker command assuming you have a docker desktop running on your local machine.

1.  IbmMq docker command

docker run - env LICENSE=accept - env MQQMGRNAME=QM1 - publish 1414:1414 - publish 9443:9443 - detach ibmcom/mq

Console url : [https://localhost:9443/ibmmq/console](https://localhost:9443/ibmmq/console)  
UserId/Password : admin/passw0rd

2. RabbitMq docker command

docker run -it -p 5672:5672 --hostname my-rabbit --name some-rabbit rabbitmq:3

Console Url : [http://localhost:15672](http://localhost:15672)  
UserId/Password : guest/guest

### Spring Boot Application

Let’s create a Spring Boot Application

You can create Spring Boot Application from [spring initializr](https://start.spring.io/).

![](https://miro.medium.com/v2/resize:fit:875/1*Wlaz8v4w4VpftRZTFOrdWQ.png)

Make sure you select maven, Spring Boot version 3.2.0 and click on **Generate**.

Once the project is downloaded you can open the project in any IDE of your choice. In my case, I am using Intellij.  
Up until now, we have not added any dependency in pom.xml.  
Let’s start by adding spring boot dependency in the dependencies section in pom.xml.
```xml
        <dependency>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-starter</artifactId>  
        </dependency>  
        <dependency>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-starter-web</artifactId>  
            <version>3.2.0</version>  
        </dependency>
```
**Apache Camel Dependency**
```xml
         <dependency>  
            <groupId>org.apache.camel.springboot</groupId>  
            <artifactId>camel-spring-boot-starter</artifactId>  
            <version>4.2.0</version>  
        </dependency>  
        <dependency>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-starter-integration</artifactId>  
            <version>3.1.3</version>  
        </dependency>
```
**RabbitMq Dependency**
```xml
        <dependency>  
            <groupId>org.apache.camel.springboot</groupId>  
            <artifactId>camel-spring-rabbitmq-starter</artifactId>  
            <version>4.2.0</version>  
        </dependency>
```l
**IbmMq Dependency**
```xml
        <dependency>  
            <groupId>com.ibm.mq</groupId>  
            <artifactId>mq-jms-spring-boot-starter</artifactId>  
            <version>3.1.5</version>  
        </dependency>  
        <dependency>  
            <groupId>org.apache.camel</groupId>  
            <artifactId>camel-jms</artifactId>  
            <version>4.2.0</version>  
        </dependency>
```
All the required dependencies added, let’s add rabbitmq and ibmmq configuration in the application.properties file.
```shell
camel.springboot.main-run-controller=true  
camel.springboot.name = MyCamel  
### RabbitMQ Configuration  
spring.rabbitmq.host=localhost  
spring.rabbitmq.port=5672  
spring.rabbitmq.username=guest  
spring.rabbitmq.password=guest  
spring.rabbitmq.template.exchange=myqueue  
spring.rabbitmq.template.routing-key=mykey  
  
### IBM-MQ Configuration  
ibm.mq.queueManager=QM1  
ibm.mq.channel=DEV.ADMIN.SVRCONN  
ibm.mq.connName=localhost(1414)  
ibm.mq.queue=DEV.QUEUE.1  
ibm.mq.user=admin  
ibm.mq.password=passw0rd
```
Almost at the last step, create a class which extends RouterBuilder. Override method configure and add routes.
```java
import org.apache.camel.builder.RouteBuilder;  
import org.springframework.stereotype.Component;  
  
@Component  
public class RouteService extends RouteBuilder {  
    @Override  
    public void configure() throws Exception {  
  
        // first route  
        from("timer:mytimer?period=5000")  
                .transform(simple("Random number ${random(0,100)}"))  
                .to("jms:DEV.QUEUE.1");  
  
        // second route  
        from("jms:queue:DEV.QUEUE.1")  
                .log("Message Posted in RabbitMq")  
                .to("spring-rabbitmq:librayQueue.exchange?queues=librayQueue");  
  
        // third route  
        from("spring-rabbitmq:librayQueue.exchange?queues=librayQueue")  
                .log("Data from rabbitmq: ${body}");  
    }  
}
```

In the above code, we have added the first route which triggers every 5 seconds and generates a random number between 0 to 100 and inserts that data in IBM MQ.

In the second route, we are reading data from ibmmq which was pushed in route1 and adding that data as it is in rabbitmq.

To verify if data was being posted successfully in rabbitmq we have introduced a third route, which reads data from rabbitmq and logs it.

You can also verify by logging into the rabbitmq console.

### Validate:

Run spring boot application using IDE or using maven command mvn spring-boot:run and monitor logs.

https://gitlab.com/taskar.sushil/apache-camel

Thank you for your attention! Happy Learning!
---
# Set up multi-instance High Availability MQ Server on Docker containers


### Table of Contents

1.  [Introduction](###2abc)
2.  [Prerequisites](###cabf)
3.  [What am I simulating here?](###ea36)
4.  [How to run it](###04e1)
5.  [Testing High Availability scenarios](###2e5a)  
    5.1 [Switchover to QM1-standby node](###a3d4)  
    5.2 [Switchover to QM1-active node](###9fdb)  
    5.3 [Stopping QM1-active container](###f8f7)  
    5.4 [Starting QM1-active container](###c1a3)  
    5.5 [Killing QM1-standby container](###883b)
6.  [Individual code snippets explained](###bfdf)  
    6.1 [./mq/mq-setup.sh](###f022)  
    6.2 [./mq/mq-start.sh](###e873)  
    6.3 [./update.sh](###efbc)
7.  [Conclusion](###f27a)

### 1. Introduction

This topic is something I have been postponing for some time. And the main reason for it was that I couldn’t mount NFS drive in Docker compose. So if anyone figures how to do it in Docker compose, I’ll be very grateful.

A few months ago, we were migrating RHEL servers from v7 to v8. For some reason, unknown to me, it was decided that this migration will be done by completely reinstalling the MQ environment. To be honest, I don’t like installing software directly on bare metal, especially when it’s something like MQ. The MQ was installed 5 years ago, there were a lot of configuration changes that nobody bother to document, the installation script was outdated, and it required root privileges which have been revoked on these new VMs. Seeing many potential problems with installation, I was pushing for MQ in containers. This idea was dismissed, as there is no official IBM documentation on how to install MQ in Docker containers with High Availability. Due to this, it was decided that it’s safer to install it again on bare metal.

The main issue in regard to High Availability is that at the first look, MQ and containers are somewhat incompatible. The containers are [ephemeral](https://www.dictionary.com/browse/ephemeral) (temporary) in nature, and assigning them persistent storage is bad practice. If the container dies or stops working or responding for some reason, just stop, kill and recreate it again. This makes the High Availability mode impossible, because you are losing all data that was in the memory at that specific time. On the other hand, MQ is heavily dependent on persistent storage. Storing persistent messages for later processing or performing failover from one node to the other with data intact.

So, we have bad practice on one side (using persistent storage with containers) and bad practice on the other (MQ should be a stable and long-running process, not something that you kill or stop at will).

As I am a very curious and somewhat stubborn person, I couldn’t lay it to rest. If it’s working in OpenShift, why shouldn’t it work with normal containers as well. Apparently, my stubbornness and curiosity bore some fruit, which I’m now sharing with you.

### 2. Prerequisites

-   Docker
-   MQ installation file or URL
-   Read an IBM overview on multi-instance Queue Managers [here](https://www.ibm.com/docs/en/ibm-mq/9.2?topic=configurations-multi-instance-queue-managers).
-   Read IBM documentation how to create multi-instance Queue Managers and restrictions [here](https://www.ibm.com/docs/en/ibm-mq/9.3?topic=managers-create-multi-instance-queue-manager).

### 3. What am I simulating here?

I took a liberty to prepare an example based on architecture that we have on the project I’m currently at.

The setup is following, we have two VM’s called QM1-active and QM1-standby. On both of these VM’s there is MQ Server installed. These machines have mounted network file system (/MQHA) which resides on the third VM which is our NFS server. By default, MQ Server on QM1-active VM is always in status Running, while MQ Server on QM1-standby VM is always in Running as Standby.

![](https://miro.medium.com/v2/resize:fit:538/1*VHXB-yk4rPAkJBu4mO449w.png)

By using Docker containers, I’ll be simulating this High Availability architecture, and it’s behaviour when specific events occur.

### 4. How to run it

Let’s first run the example, after that I’ll explain parts of scripts.

Go to my github and clone the 
https://github.com/ibm-ace-medium/ibm-mq-multi-instance-queue-manager
. Once you have the repository cloned, you need to update a variable NFS_STORAGE_PATH in the file update.sh. This is the path which you want that NFS Server uses as storage.

NFS_STORAGE_PATH="update me"

###### Once you have updated this path, all you need to do is execute update.sh and wait for download and installation to finish.

Your output should look similar to this:

nfs-volume  
3c2d0bf3fe41d84ba61c1ef2b59ba1c160ce4aa8ad75b2249b55f0567b745020  
Please wait until configured........  
d362e06c9c46c31c8b4760e33e4c30930257658ecc5a207ad2c1b108ef75911a  
All started.

Check that containers are running with command:
```shell
docker ps
```
The output:

![](https://miro.medium.com/v2/resize:fit:1250/1*rceEfbfWOcuvs10ujovaPQ.png)

Check that MQ Servers are in corrects status and order.
```shell
docker exec QM1-standby dspmq  
docker exec QM1-active dspmq
```
The output:

![](https://miro.medium.com/v2/resize:fit:875/1*ix02yW9PvOiHNgmXaKxCHw.png)

### 5. Testing High Availability scenarios

When executing commands, please give a couple of seconds in between each command. This is necessary as sometimes switchover and container restart can take some time.

### 5.1 Switchover to QM1-standby node

![](https://miro.medium.com/v2/resize:fit:469/1*jHHes_D7MD_ayiAjFDs9MQ.png)

In order to perform switchover we use commands:
```shell
docker exec QM1-active endmqm -s QMgr01  
docker exec QM1-standby dspmq  
docker exec QM1-active dspmq
```
![](https://miro.medium.com/v2/resize:fit:875/1*iaG_EuWX0T1tz6q6hnhuWA.png)

Here you see that QM1-standby became active and QM1-active became standby.

### 5.2 Switchover to QM1-active node

![](https://miro.medium.com/v2/resize:fit:538/1*VHXB-yk4rPAkJBu4mO449w.png)
```shell
docker exec QM1-standby endmqm -s QMgr01  
docker exec QM1-active dspmq  
docker exec QM1-standby dspmq
```
![](https://miro.medium.com/v2/resize:fit:875/1*H-JmAIkGn6R6L8QQj9_Ozw.png)

Here you see that we have returned QM1-active as active and QM1-standby as standby.

### 5.3 Stopping QM1-active container

![](https://miro.medium.com/v2/resize:fit:579/1*jCgzp-ebWOQXpt-WeYNrsw.png)
```shell
docker container stop QM1-active  
docker exec QM1-standby dspmq 
```
![](https://miro.medium.com/v2/resize:fit:875/1*6bgcN3iXVNx4lkO282qJqw.png)

After we have stopped QM1-active container the QM1-standby node took over.

### 5.4 Starting QM1-active container

![](https://miro.medium.com/v2/resize:fit:469/1*jHHes_D7MD_ayiAjFDs9MQ.png)
```shell
docker container start QM1-active  
docker exec QM1-active dspmq
```
![](https://miro.medium.com/v2/resize:fit:875/1*0WrhGx3V6x_4E92KKxu9hA.png)

Here, after successful container start, QM1-active node is started in standby.

### 5.5 Killing QM1-standby container

![](https://miro.medium.com/v2/resize:fit:498/1*eukQDagOdrBDFLVacPJ7vw.png)
```shell
docker container kill -s 9 QM1-standby  
docker exec QM1-active dspmq
```
![](https://miro.medium.com/v2/resize:fit:875/1*DD3RxeORe5NHZCDUahkhNA.png)

Here after we killed QM1-standby container, which was previously active node, the QM1-active container took over and became active MQ node.

I’ll finish my testing of High Availability here, if you have some other possible tests scenario, feel free to try them out and share your finding with me.

### 6. Individual code snippets explained

There are three main bash scripts that make this magic happen.

### 6.1 ./mq/mq-setup.sh

This script is responsible for creating Queue Manager. Two important lines are 16 and 19.

![](https://miro.medium.com/v2/resize:fit:875/1*I_jp4-682carvVh125aPqg.png)

On line 16, we are creating a Queue Manager and passing paths to directories that are shared between active and standby node.

On line 19, we are passing option -x to strmqm command in order to start Queue Manager as multi-instance Queue Manager. This is a necessary step before we can connect standby node to it.

### 6.2 ./mq/mq-start.sh

This is the script that is called when the container is started. As High Availability can be set up only when Queue Manager is running, unfortunately it was impossible to completely decouple configuration code from start up code.

**Configuration — isMQConfigured()**

This function checks whether Queue Manager has already been configured. If true, then it simply appends log about it and terminates. If false, then it checks whether a script is being run on a ACTIVE or STANDBY container and then calls the appropriate configuration function.
```shell
isMQConfigured() {  
  if dspmqinf ${QUEUE_MANAGER_NAME_ENV}; then  
      echo "${QUEUE_MANAGER_NAME_ENV} is configured" >> /MQHA/qmgrs/container.log  
  else  
      if [[ "${IS_ACTIVE_NODE}" == 1 ]]; then  
        configureActiveNode  
      else  
        configureStandByNode  
      fi  
  fi  
}
```
**Configuration — configureActiveNode()**

This function calls mq-setup.sh script on active Queue Manager node and sets up and start Queue Manager.
```shell
configureActiveNode() {  
  echo "Configuring active node..."  
  /home/mqm/mq-setup.sh ${QUEUE_MANAGER_NAME_ENV} ${QUEUE_MANAGER_PORT_ENV} ${MQ_ADMINS_GROUP_ENV} ${LOG_FILES_DIR_ENV} ${DATA_FILES_DIR_ENV}  
}
```
**Configuration — configureStandByNode()**

In this function, we are connecting a standby node to the active node and starting it into standby mode.
```shell
configureStandByNode() {  
  echo "Configuring standby node..."  
  addmqinf -s QueueManager -v Name=${QUEUE_MANAGER_NAME_ENV} -v Directory=${QUEUE_MANAGER_NAME_ENV} -v Prefix=/var/mqm -v DataPath=${DATA_FILES_DIR_ENV}/${QUEUE_MANAGER_NAME_ENV} >> /MQHA/qmgrs/container.log  
  strmqm -x ${QUEUE_MANAGER_NAME_ENV} >> /MQHA/qmgrs/container.log  
}
```
**Running — isRunningQM()**

This function is responsible for maintaining container running as long as Queue Manager is in Running or Running as standby mode. It checks and logs heartbeat every 15s. You can change this by modifying the variable SLEEP_FOR_SECONDS in update.sh file.
```shell
isRunningQM() {  
  local qmgrName=$1  
  
  ### Get current status of Queue Manager  
  local qmgrStatus="$(dspmq | grep ${qmgrName})"  
  
  ### Keep container live while Queue Manager is Running or in Standby  
  while [[ "${qmgrStatus}" == *"${RUNNING}"* ]] || [[ "${qmgrStatus}" == *"${RUNNING_AS_STANDBY}"* ]]; do  
    sleep $SLEEP_FOR_SECONDS_ENV  
    echo "Heartbeat..."  
    qmgrStatus="$(dspmq | grep ${qmgrName})"  
  done  
}
```
### 6.3 ./update.sh

This is the main script that binds everything together, builds and starts containers.

There are five variables that you can/should modify:
```shell
NFS_STORAGE_PATH="update me" ### A path where the NFS Server should write shared files  
QUEUE_MANAGER_NAME="QMgr01"  
QUEUE_MANAGER_PORT="1414"  
MQ_ADMINS_GROUP="mqadmins"  
SLEEP_FOR_SECONDS=15
```
**clean()**

A function responsible for cleanup. It’s used so that you can run ./update.sh script every time on clean slate.

**buildImages()**

A function that builds the necessary Docker images.

**createNetwork()**

A function that creates custom network with name my-network.

**startNfsServerAndCreateNfsVolume()**

This function start NFS Server container, adds it to the my-network network and finally create a Docker volume called **nfs-volume** which is then mounted onto MQ Server container.

A note about creating NFS volume. In IBM [documentation](https://www.ibm.com/docs/en/ibm-mq/9.3?topic=managers-create-multi-instance-queue-manager), it states:

![](https://miro.medium.com/v2/resize:fit:875/1*qAzibyaCbhAzD-0GgG7Hpg.png)

For this reason, when creating NFS volume the configuration is as follows:

![](https://miro.medium.com/v2/resize:fit:771/1*ZYv6fiOh1VcvI-_n37UZ3A.png)

**runActiveMqContainer() and runStandbyMqContainer()**

These two functions are almost similar. The only difference is that when running QM1-active container, we are setting the environment variable IS_ACTIVE_NODE=1, in order to determine which container should be active by default.

![](https://miro.medium.com/v2/resize:fit:715/1*iC9NCsZQHhWub_Rrj91TXQ.png)

In addition, what is important to mention here, is that both containers are run with option **--restart unless-stopped.** What this option does is, it restarts the container every time in case the queue manager status is not **Running** or **Running as standby**.

So for example, when we perform switchover with command **endmqm -s QMgr01**, the Queue Manager changes its status into **Running elsewhere**. This is not the correct status for Queue Manager in HA, therefore the container is stopped by exiting function **isRunningQM()** in script **mq-start.sh**. As a consequence, the container is started again automatically, this time however, in status **Running in standby**, which is correct status in High Availability set up.

**waitUntilConfigurationIsFinished()**

For some reason, on my local machine, it takes some time to create Queue Manager. I’m suspecting some kind of timeout, unfortunately I don’t see any problem from logs nor errors. For this reason, I have created this function with sleep and simple progress bar.

**setupHA()**

The main function that ties it all together.

I haven’t entered into every detail of each function, but I believe that certain lines are self-explanatory, however if there is something that you think requires detailed explanation feel free to send me a comment.

### 7. Conclusion

In this article, you learned how to create multi-instance High Availability MQ server based on Docker containers. There are several others High Availability configurations for which I’ll prepare articles in the future.

Thank you for reading.