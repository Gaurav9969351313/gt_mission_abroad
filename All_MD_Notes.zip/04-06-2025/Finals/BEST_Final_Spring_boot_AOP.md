**# Mastering Spring AOP: Understanding Advice Order and Practical Examples with Spring Boot 🌟

### Introduction 📖

Aspect-Oriented Programming (AOP) in Spring is a powerful tool for handling cross-cutting concerns like logging, transaction management, and security, keeping your codebase clean and modular. 🚀 Spring AOP uses aspects to apply advice (additional behavior) to specific join points (e.g., method executions) in your application. A key aspect of mastering Spring AOP is understanding the **order of advice execution** and how to leverage it effectively in real-world scenarios. This article dives into the execution order of Spring AOP advice types and provides practical Spring Boot examples for common use cases. 🛠️

### Understanding Spring AOP Advice Types and Execution Order 🧠

Spring AOP provides five types of advice, each with a specific role and execution point relative to the target method. The order in which they execute depends on their type and declaration. Here’s a detailed breakdown:

### Advice Types and Their Execution Order 📋

1.  **Before Advice (**`**@Before**`**)** ⏮️

-   **Purpose**: Executes before the target method is called.
-   **Execution Order**: Runs first, before any other advice or the target method.
-   **Use Case**: Logging method entry, validating inputs, or checking permissions.

**2. Around Advice (**`**@Around**`**)** 🔄

-   **Purpose**: Wraps the target method, allowing custom logic before and after execution, and even controlling whether the method is called.
-   **Execution Order**: Executes before `@Before` advice (for its pre-method logic), surrounds the target method, and continues after the method (post-method logic). If `proceed()` is not called, the target method and subsequent advice are skipped.
-   **Use Case**: Performance monitoring, caching, or transaction management.

**3. After Returning Advice (**`**@AfterReturning**`**)** ✅

-   **Purpose**: Executes after the target method completes successfully (no exceptions).
-   **Execution Order**: Runs after the target method and the post-method logic of `@Around`, but only if no exception is thrown.
-   **Use Case**: Logging successful method outcomes or modifying return values.

**4. After Throwing Advice (**`**@AfterThrowing**`**)** 🚨

-   **Purpose**: Executes if the target method throws an exception.
-   **Execution Order**: Runs after the target method if an exception occurs, following `@Around`’s pre-method logic but before `@After`.
-   **Use Case**: Logging exceptions or triggering fallback mechanisms.

**5. After Advice (**`**@After**`**)** 🏁

-   **Purpose**: Executes after the target method, regardless of success or failure (like a `finally` block).
-   **Execution Order**: Runs last, after all other advice, whether the method succeeds or throws an exception.
-   **Use Case**: Resource cleanup or final logging.

### Summary of Execution Order 📊

###### **Normal Execution (No Exception)**:

1.  `@Before`
2.  `@Around` (pre-method logic)
3.  Target method
4.  `@Around` (post-method logic)
5.  `@AfterReturning`
6.  `@After`

###### **Exception Thrown**:

1.  `@Before`
2.  `@Around` (pre-method logic)
3.  Target method (throws exception)
4.  `@AfterThrowing`
5.  `@After`

###### **Note**:

-   `@Around` is the most flexible, as it can skip the target method by not calling `proceed()`. If `proceed()` is skipped, subsequent advice (`@AfterReturning`, `@AfterThrowing`) won’t execute. ⚠️
-   Advice order within the same type (e.g., multiple `@Before` advice) is determined by declaration order or explicit `@Order` annotations.

### Spring Boot Example: Demonstrating Advice Order 🖥️

Let’s create a Spring Boot application to demonstrate the execution order of AOP advice. We’ll define an aspect that applies all advice types to a service method.

### Project Setup 🛠️

1.  Create a Spring Boot project with the following dependencies in `pom.xml`:
```xml
<dependencies>  
    <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-web</artifactId>  
    </dependency>  
    <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-aop</artifactId>  
    </dependency>  
</dependencies>
```
1.  Enable AOP in your main application class:
```java
package com.example.demo;  
import org.springframework.boot.SpringApplication;  
import org.springframework.boot.autoconfigure.SpringBootApplication;  
import org.springframework.context.annotation.EnableAspectJAutoProxy;  
  
@SpringBootApplication  
@EnableAspectJAutoProxy  
public class DemoApplication {  
    public static void main(String[] args) {  
        SpringApplication.run(DemoApplication.class, args);  
    }  
}
```
### Service Class 📦

Create a simple service with a method that we’ll apply advice to:
```java
package com.example.demo.service;  
import org.springframework.stereotype.Service;  
  
@Service  
public class DemoService {  
    public String processData(String input) {  
        System.out.println("Processing data: " + input);  
        if (input.equals("error")) {  
            throw new RuntimeException("Simulated error");  
        }  
        return "Processed: " + input;  
    }  
}
```
### Aspect Class 🔍

Define an aspect with all advice types:
```java
package com.example.demo.aspect;  
import org.aspectj.lang.JoinPoint;  
import org.aspectj.lang.ProceedingJoinPoint;  
import org.aspectj.lang.annotation.*;  
import org.springframework.stereotype.Component;  
@Aspect  
@Component  
public class DemoAspect {  
    @Before("execution(* com.example.demo.service.*.*(..))")  
    public void beforeAdvice(JoinPoint joinPoint) {  
        System.out.println("🔹 Before Advice: Preparing to execute " 
            + joinPoint.getSignature().getName());  
    }  
    @Around("execution(* com.example.demo.service.*.*(..))")  
    public Object aroundAdvice(ProceedingJoinPoint joinPoint) throws Throwable {  
        System.out.println("🔄 Around Advice: Before method execution");  
        Object result = joinPoint.proceed();  
        System.out.println("🔄 Around Advice: After method execution");  
        return result;  
    }  
    @AfterReturning(pointcut = "execution(* com.example.demo.service.*.*(..))",
         returning = "result")  
    public void afterReturningAdvice(JoinPoint joinPoint, Object result) {  
        System.out.println("✅ AfterReturning Advice: Method " 
            + joinPoint.getSignature().getName() + " returned " + result);  
    }  
    @AfterThrowing(pointcut = "execution(* com.example.demo.service.*.*(..))",
         throwing = "error")  
    public void afterThrowingAdvice(JoinPoint joinPoint, Throwable error) {  
        System.out.println("🚨 AfterThrowing Advice: Method " 
            + joinPoint.getSignature().getName() + " threw " + error.getMessage());  
    }  
    @After("execution(* com.example.demo.service.*.*(..))")  
    public void afterAdvice(JoinPoint joinPoint) {  
        System.out.println("🏁 After Advice: Method "
             + joinPoint.getSignature().getName() + " completed");  
    }  
}
```
### Controller to Trigger the Service 🌐

Create a REST controller to test the service:
```java
package com.example.demo.controller;  
  
import com.example.demo.service.DemoService;  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.RequestParam;  
import org.springframework.web.bind.annotation.RestController;  
  
@RestController  
public class DemoController {  
    @Autowired  
    private DemoService demoService;  
    @GetMapping("/process")  
    public String process(@RequestParam String input) {  
        return demoService.processData(input);  
    }  
}
```
### Testing the Application 🚀

1.  Run the Spring Boot application.
2.  Test with a successful case: `http://localhost:8080/process?input=hello`  
    **Output**:

🔹 Before Advice: Preparing to execute processData  
🔄 Around Advice: Before method execution  
Processing data: hello  
🔄 Around Advice: After method execution  
✅ AfterReturning Advice: Method processData returned Processed: hello  
🏁 After Advice: Method processData completed

3. Test with an error case: `http://localhost:8080/process?input=error`  
**Output**:

🔹 Before Advice: Preparing to execute processData  
🔄 Around Advice: Before method execution  
Processing data: error  
🚨 AfterThrowing Advice: Method processData threw Simulated error  
🏁 After Advice: Method processData completed

This demonstrates the advice execution order, with `@Before` first, `@Around` wrapping the method, and `@AfterReturning` or `@AfterThrowing` followed by `@After` depending on the outcome.

### Practical Spring Boot AOP Use Cases with Examples 🛠️

AOP shines in handling cross-cutting concerns. Below are common scenarios with Spring Boot implementations.

### 1. Logging 📝

**Purpose**: Record method execution details for debugging or auditing.

**Example**: Log method entry and exit.
```java
package com.example.demo.aspect;  
  
import org.aspectj.lang.JoinPoint;  
import org.aspectj.lang.annotation.After;  
import org.aspectj.lang.annotation.Aspect;  
import org.aspectj.lang.annotation.Before;  
import org.springframework.stereotype.Component;  
@Aspect  
@Component  
public class LoggingAspect {  
    @Before("execution(* com.example.demo.service.*.*(..))")  
    public void logBefore(JoinPoint joinPoint) {  
        System.out.println("📝 Logging: Method " + joinPoint.getSignature().getName() + 
            " started with args: " + java.util.Arrays.toString(joinPoint.getArgs()));  
    }  
    @After("execution(* com.example.demo.service.*.*(..))")  
    public void logAfter(JoinPoint joinPoint) {  
        System.out.println("📝 Logging: Method " 
            + joinPoint.getSignature().getName() + " completed");  
    }  
}
```
### 2. Transaction Management 💾

**Purpose**: Automatically manage database transactions.

**Example**: Use Spring’s `@Transactional` (which leverages AOP internally).
```java
package com.example.demo.service;  
  
import org.springframework.stereotype.Service;  
import org.springframework.transaction.annotation.Transactional;  
@Service  
public class OrderService {  
    @Transactional  
    public void placeOrder(String orderDetails) {  
        System.out.println("💾 Saving order: " + orderDetails);  
        // Simulate database operation  
        if (orderDetails.equals("invalid")) {  
            throw new RuntimeException("Invalid order");  
        }  
    }  
}
```
Spring’s AOP-based transaction management starts a transaction before the method, commits on success, or rolls back on exceptions.

### 3. Permission Control 🔒

**Purpose**: Restrict method access based on user roles.

**Example**: Check user permissions before method execution.
```java
package com.example.demo.aspect;  
  
import org.aspectj.lang.JoinPoint;  
import org.aspectj.lang.annotation.Before;  
import org.aspectj.lang.annotation.Aspect;  
import org.springframework.stereotype.Component;  
@Aspect  
@Component  
public class SecurityAspect {  
    @Before("execution(* com.example.demo.service.*.*(..))")  
    public void checkPermissions(JoinPoint joinPoint) {  
        // Simulate permission check  
        boolean hasPermission = Math.random() > 0.2; // Mock permission logic  
        if (!hasPermission) {  
            throw new SecurityException("🔒 Access denied: Insufficient permissions");  
        }  
        System.out.println("🔒 Permission granted for " + joinPoint.getSignature().getName());  
    }  
}
```
### 4. Performance Monitoring ⏱️

**Purpose**: Measure method execution time.

**Example**: Log execution time using `@Around`.
```java
package com.example.demo.aspect;  
  
import org.aspectj.lang.ProceedingJoinPoint;  
import org.aspectj.lang.annotation.Around;  
import org.aspectj.lang.annotation.Aspect;  
import org.springframework.stereotype.Component;  
@Aspect  
@Component  
public class PerformanceMonitoringAspect {  
    @Around("execution(* com.example.demo.service.*.*(..))")  
    public Object measureExecutionTime(ProceedingJoinPoint joinPoint) throws Throwable {  
        long startTime = System.currentTimeMillis();  
        Object result = joinPoint.proceed();  
        long endTime = System.currentTimeMillis();  
        System.out.println("⏱️ Method " + joinPoint.getSignature().getName() 
            + " took " + (endTime - startTime) + " ms");  
        return result;  
    }  
}
```
### 5. Exception Handling 🚨

**Purpose**: Centralize exception handling.

**Example**: Log and handle exceptions uniformly.
```java
package com.example.demo.aspect;  
  
import org.aspectj.lang.ProceedingJoinPoint;  
import org.aspectj.lang.annotation.Around;  
import org.aspectj.lang.annotation.Aspect;  
import org.springframework.stereotype.Component;  
@Aspect  
@Component  
public class ExceptionHandlingAspect {  
    @Around("execution(* com.example.demo.service.*.*(..))")  
    public Object handleExceptions(ProceedingJoinPoint joinPoint) {  
        try {  
            return joinPoint.proceed();  
        } catch (Throwable e) {  
            System.out.println("🚨 Exception in " 
                + joinPoint.getSignature().getName() + ": " + e.getMessage());  
            return "Error occurred"; // Fallback response  
        }  
    }  
}
```

### 6. Cache Processing 🗃️

**Purpose**: Cache method results to improve performance.

**Example**: Implement a simple in-memory cache.
```java
package com.example.demo.aspect;  
  
import org.aspectj.lang.ProceedingJoinPoint;  
import org.aspectj.lang.annotation.Around;  
import org.aspectj.lang.annotation.Aspect;  
import org.springframework.stereotype.Component;  
import java.util.HashMap;  
import java.util.Map;  
@Aspect  
@Component  
public class CachingAspect {  
    private Map<String, Object> cache = new HashMap<>();  
    @Around("execution(* com.example.demo.service.*.get*(..))")  
    public Object handleCaching(ProceedingJoinPoint joinPoint) throws Throwable {  
        String cacheKey = joinPoint.getSignature().getName() + "-" 
            + java.util.Arrays.toString(joinPoint.getArgs());  
        Object cachedData = cache.get(cacheKey);  
        if (cachedData != null) {  
            System.out.println("🗃️ Cache hit for " + cacheKey);  
            return cachedData;  
        }  
        System.out.println("🗃️ Cache miss for " + cacheKey);  
        Object result = joinPoint.proceed();  
        cache.put(cacheKey, result);  
        return result;  
    }  
}
```
### Best Practices for Spring AOP in Spring Boot ✅

-   **Use Specific Pointcuts** 🎯: Narrow pointcuts (e.g., `execution(* com.example.service.*.*(..))`) to avoid applying advice to unintended methods.
-   **Minimize** `**@Around**` **Usage** ⚖️: Use `@Around` only when necessary, as it’s more complex and can impact performance.
-   **Leverage** `**@Order**` 📑: Use `@Order` annotations to control the execution order of multiple aspects (lower values execute first).
-   **Test Thoroughly** 🧪: Test AOP behavior under various scenarios, including exceptions and edge cases.
-   **Monitor Performance** ⏱️: Profile AOP-enabled applications to ensure advice doesn’t introduce significant overhead.
-   **Use Spring’s Built-in AOP Features** 🛠️: Leverage `@Transactional`, `@Cacheable`, or Spring Security’s AOP-based annotations for common tasks.

### Conclusion 🎯

Spring AOP is a game-changer for managing cross-cutting concerns in Spring Boot applications. By understanding the execution order of advice types — `@Before`, `@Around`, `@AfterReturning`, `@AfterThrowing`, and `@After`—you can design robust aspects that enhance modularity and maintainability. The practical examples provided, from logging to caching, demonstrate how to apply AOP effectively in real-world scenarios. With careful pointcut design and performance considerations, Spring AOP can streamline your codebase and boost application reliability. Start experimenting with AOP in your Spring Boot projects today! 🚀

# Spring Boot AOP Part 1

### **Introduction:**

The programming in the world is changing every day and the projects are bigger in the last few days. so we need to change the programming approach for the better always.

Today I will explain AOP (Aspect-oriented programming).  
the common use of AOP with logs and exceptions inside any project, we can use it with any framework because it is a programming approach like (OOP) object-oriented programming.

> **when using the AOP in the project, we can split the business logic from Logger and exception. which is the common use for it.**

### The Aspect core concept and Aspect concept in spring:

AOP is a technique for building common, reusable routines that can be applied applicationwide. During development, this facilitates the separation of core application logic and common, repeatable tasks (input validation, logging, error handling, etc.

**The Aspect concept in spring:**

Spring AOP takes out the direct dependency of crosscutting tasks from classes that we can’t achieve through a normal object-oriented programming model. For example, we can have a separate class for logging but again the functional classes will have to call these methods to achieve logging across the application.

**The Aspect component:**

To apply AOP in spring-boot you can use AspectJ dependency from Maven or Gradle, or if you use spring you must configure aspect inside spring.xml

> **In this article I am using AspectJ dependency.**

-   **Aspect:** An aspect is a class that implements enterprise application concerns that cut across multiple classes, you can define it by `@Aspect`the annotation above the aspect class.
-   **Pointcut:** It is an expression to catch an event when happened, such as method executing.
-   **Advice:**  
    The advice in aspect is very important because each process aspect needs advice. Advice will take the action when the pointcut happed  
    **Advice example: before method X executes I need to log String X or logs some arguments from method X.**

> We have more than advice type and will see it when writing the code and will explain that.

-   **JoinPoint:** A join point is a specific point in the application such as method execution, exception handling, changing object variable values, etc. In Spring AOP a join point is always the execution of a method.
-   **Object Target**: It is an Object from the original method to know what the method executes now, or if we need to change something we can do it by this object, actually, we can take the Object target from **JoinPoint** of the advice method.  
    The Object target will be created at runtime from the AOP Proxy.
-   **AOP proxy**: Spring AOP implementation uses JDK dynamic proxy to create the Proxy classes with target classes and advice invocations, these are called AOP proxy classes. We can also use **CGLIB** proxy by adding it as the dependency in the Spring AOP project.
-   **Weaving**: It is the process of linking aspects with other objects to create the advised proxy objects. This can be done at compile time, load time, or at runtime. Spring AOP performs weaving at the runtime.

### **Aspect Advice Type:**

Actually, we have more types of Advice and you can use anything of them in your project, each Advice has its own job. We use the advice to take action at a specific time at run time for the methods inside our project.

-   **Before:** The before advice will execute before entering the inside join point method. we can use it to log any statements at runtime in the application.  
    To apply the **before** Advice in the spring boot application we need to use the `@Before` the annotation above Before methods.
-   **After:** The after advice will execute after finishing from the join point method.  
    To apply the **after** Advice in the spring boot application we need to use the `@After` annotation above After methods.
-   **After Returning:** sometimes we need to log anything but after the return value not after finish finally, in this case, we need to use **after returning advice**.  
    To apply the **after Returning** Advice in the spring boot application we need to use the `@AfterReturning` the annotation above **after Returning** methods.
-   **After throwing:** always need a log exception inside the projects. The AspectJ support this feature when using **After Throwing** annotation.  
    To apply the **After Throwing** Advice in the spring boot application we need to use the `@AfterThrowing` the annotation above After Throwing methods.
-   **Around:** By Around Advice we can execute the **JoinPoint** from the **Around advice method**, or we can do not execute it from the aspect class and run normally.  
    From the Around method, we can execute some advice inside it before or after executing **Joinpoint**. But you must be careful when using the **Around** Advice. because the Around Advice can change the running way for your **joinpoint**.  
    To apply the Around Advice in the spring boot application we need to use the `@Around` the annotation above Around methods.

**Conclusion:**

Now we know AOP (Aspect-oriented programming) concept and we know when we need to use it. Actually, that is not enough because we don’t apply coding about the Aspect until now. But the second Article will be about aspect coding by spring boot.


### Spring AOP Example Tutorial - Aspect, Advice, Pointcut, JoinPoint, Annotations, XML Configuration …

### Spring Framework is developed on two core concepts - Dependency Injection and Aspect Oriented Programming ( Spring…

www.journaldev.com



](https://www.journaldev.com/2583/spring-aop-example-tutorial-aspect-advice-pointcut-joinpoint-annotations?source=postpage-----4544a58d6a4c---------------------------------------)

---
# Spring boot AOP Example (Part Tow)
### Introduction:

In the previous article, we talked about Aspect and if you read the previous article you should know the aspect core concept and spring boot concept with aspect. In this article, I will write aspect code using java inside the spring boot project.

https://github.com/abdalrhmanAlkraien/Aspect-example

### Aspect configuration:

To apply aspect programming inside any spring-boot application, you need to make an aspect configuration. In the current step we need to go to two locations: For the first one, we need to update the pom.xml file and put Aspect dependency.

We can use the aspect dependency provided in spring, but in this article, I will use the AspectJ dependency.

`**Pom.xml**` **file:**
```xml
<!-- enable aspect -->  
<dependency>  
    <groupId>org.springframework</groupId>  
    <artifactId>spring-aop</artifactId>  
    <version>5.3.18</version>  
</dependency>  
  
<dependency>  
    <groupId>org.aspectj</groupId>  
    <artifactId>aspectjrt</artifactId>  
    <version>1.9.9.1</version>  
</dependency>  
  
<dependency>  
    <groupId>org.aspectj</groupId>  
    <artifactId>aspectjweaver</artifactId>  
    <version>1.9.9.1</version>  
</dependency>
```
Now I will create a java file called `**AspectConfig.java**` and then I will add `@EnableAspectJAutoProxy` . From the last article, you can know why I need to enable proxy when using **Aspect.**

`AspectConfig.java` file
```java
@EnableAspectJAutoProxy(exposeProxy = true)  
public class AspectConfig {  
}
```
[http://localhost:8080/swagger-ui.html](http://localhost:8080/swagger-ui.html)

Now I have a Controller package and Service Package, I will write business logic inside them.

### Business logic:

In this section just we need to define some Api to take some action for Aspect.

**controller.TaskController.java**
```java
@RestController  
@RequestMapping("/api/tasks")  
public class TaskController {  
  
    private final TaskService taskService;  
    public TaskController(TaskServiceImp taskService){  
        this.taskService=taskService;  
    }  
  
    @GetMapping  
    @ApiOperation(value = "Get all tasks")  
    public void getTask(){  
        taskService.getTask();  
    }  
  
    @PostMapping  
    @ApiOperation(value = "save new task")  
    public String saveTask(){  
        return taskService.saveTask();  
    }  
  
    @GetMapping("/{id}")  
    @ApiOperation(value = "get one task by id")  
    public String getTaskById(@ApiParam(value = "1",required = true, example = "123") @PathVariable("id") Long id){  
        return taskService.getTaskById(id);  
    }  
  
    @PutMapping  
    @ApiOperation(value = "update any task")  
    public String updateTask(){  
        return taskService.updateTask();  
    }  
  
    @DeleteMapping("/{id}")  
    @ApiOperation(value = "delete task by id")  
    public String deleteTaskById(@ApiParam(value = "1",required = true, example = "123") @PathVariable("id") Long id){  
        return taskService.deleteTaskById(id);  
    }  
}
```
**service.TaskService.java**
```java
public interface TaskService {  
  
    String getTask();  
    String saveTask();  
    String getTaskById(Long id);  
    String updateTask();  
    String deleteTaskById(Long id);  
  
}
```
**service.Impl.TaskServiceImpl.Java**
```java
@Service  
public class TaskServiceImp implements TaskService {  
  
    public  TaskServiceImp(){  
  
    }  
  
    @Override  
    public String getTask() {  
        return "execute getTask";  
    }  
  
    @Override  
    public String saveTask() {  
        return "execute saveTask";  
  
    }  
  
    @Override  
    @Loggable  
    public String getTaskById(Long id) throws Exception {  
        if(id<1){  
            throw new Exception("the id less than 1");  
        }  
        return "execute getTaskById ".concat(id.toString());  
    }  
  
    @Override  
    public String updateTask() {  
        return "execute updateTask";  
  
    }  
  
    @Override  
    @Loggable  
    public String deleteTaskById(Long id) throws Exception {  
        if(id<1){  
            throw new Exception("the id less than 1");  
        }  
        return "execute deleteTaskById ".concat(id.toString());  
    }  
  
}
```
> Now All the Services and Api are Done.

### Aspect Task:

In this session, I will create an aspect class to define our Pointcut and Advice to log all API executed and logs exceptions.

**What the aspect will do?**

**the aspect will log different things:**

-   We need log info when entering inside the API methods.
-   We need log info when exiting from the API.
-   We need logs info what the returning value from the service methods using annotations called **Loggable**.
-   We need logs info on the exceptions that happened in the project.

`**aspect.AspectTask.java**` **file:**

In the current session, I will split the explain each method and after finishing, I will put all the class methods in one block.

In the first step, I defined some variables to use as a Pointcut like the following code.

private final String apiPointcut="execution(* com.example.logger.springlogger.controller.*.*(..))";private final String exceptionPointcut ="execution(* com.example.logger.springlogger.*.*.*(..))";

Actually, We can use this way to define point cut or another way you see it with other methods in this article.

**pointcut as a method**

We can use `@Pointcut` to define your pointcut but in this way, you must use a method to define it. Like the following code.
```java
@Pointcut(apiPointcut)  
public void APIPointCut(){}
```
Now we have our Pointcut but we need to use Advice to handle this Pointcut.

**Advice in aspect**

When using the Aspect, you must use advice with it, because we need to log any things when a specific event happens.

To use any advice, we need to Pointcut for the advice. we can define the pointcut inside any advice using this way `@Advice(Pointcut)` .

> You can see this link to know the Advice type in Aspect.
```java
@Before("APIPointCut()")  
public void logEnteringAPI(JoinPoint joinPoint){  
    log.info("The API method will executing {}",joinPoint.getSignature().getName());  
    if(joinPoint.getArgs().length>0){  
        Object[] args=joinPoint.getArgs();  
        log.info("the Api argument is ".concat(args[0].toString()));  
    }  
}
```
`JoinPoint` : Joinpoint is a reference from the original method, we can know what the method name and args from this method from `JoinPoint` Interface.

The above advice `logEnteringAPI(JoinPoint joinPoint)`will be executed before calling the method inside the `pointCut`, and then will execute the implementation inside it, and after that will execute the original method and forward with a happy scenario.

I used `Args` object instance from JoinPoint, for logs the argument in the original methods.

Now we need to write the implementation for logs when exiting from the API method.

We will use the same pointCut called `APIPointCut()` method because we need logs in the same package. We used it with `@Before` advice.
```java
@After("APIPointCut()")  
public void logExitingAPI(JoinPoint joinPoint){  
    log.info("The API method finished execute {}",joinPoint.getSignature().getName());  
}
```
with the above advice will be executed after calling the method inside the `Pointcut` .

I created a new annotation for log specific methods called `Loggable`
```java
public @interface Loggable {  
}
```
and I am using it above two methods inside the `TaskServiceImp` called `getTaskById` and `deleteTaskById`

like the following snippet code:
```java
@Override  
@Loggable  
public String getTaskById(Long id)
```
and
```java
@Override  
@Loggable  
public String deleteTaskById(Long id)
```
And the advice method must have a new pointcut for pointing on the annotation.
```java
@AfterReturning(value = "@annotation(com.example.logger.springlogger.aspect.TaskServiceAspect.Loggable)"  
,returning = "returnValue")  
public void logEachReturningValue(JoinPoint joinPoint  
,Object returnValue){    log.info("the value from method:"  
.concat(joinPoint.getSignature().getName())  
.concat(returnValue.toString()));}
```

The above code for handling any method have `[@Loggable](http://twitter.com/Loggable)` inside the project. And will log the return value.

Now we need a log of any exception and which method has this exception.

We use the variable as `Pointcut` in this case called `exceptionPointcut` , and will use the variable with `AfterThrowing` advice to catch any exception in the project.

The `exceptionPointcut` will scan all the methods in the project, you can see the value of it from the follwoing line of code.

`exceptionPointcut= ”execution(* com.example.logger.springlogger.*.*.*(..))”`
```java
@AfterThrowing(value = exceptionPointcut ,throwing = "exception")  
public void logsExceptionsFromAnyLocations(JoinPoint joinPoint,Throwable exception) throws Throwable {  
    log.error("We have error in this method {}",joinPoint.getSignature().getName());  
    log.error("The exception message: ".concat(exception.getMessage()));  
}
```
The above advice will execute when any exception throwing in the application and will log which the method name has this exception and the exception message.

`**aspect.AspcetTask.java**` **file:**
```java
@Aspect  
@Log4j2  
@Component  
public class TaskServiceAspect {  
  
    private final String apiPointcut="execution(* com.example.logger.springlogger.controller.*.*(..))";  
    private final String exceptionPointcut ="execution(* com.example.logger.springlogger.*.*.*(..))";  
  
    @Pointcut(apiPointcut)  
    public void APIPointCut(){}  
  
  
    @Before("APIPointCut()")  
    public void logEnteringAPI(JoinPoint joinPoint){  
        log.info("The API method will executing {}",joinPoint.getSignature().getName());  
        if(joinPoint.getArgs().length>0){  
            Object[] args=joinPoint.getArgs();  
            log.info("the Api argument is ".concat(args[0].toString()));  
        }  
    }  
  
    @After("APIPointCut()")  
    public void logExitingAPI(JoinPoint joinPoint){  
        log.info("The API method finished execute {}",joinPoint.getSignature().getName());  
    }  
  
    @AfterThrowing(value = exceptionPointcut ,throwing = "exception")  
    public void logsExceptionsFromAnyLocations(JoinPoint joinPoint, 
            Throwable exception) throws Throwable {  
        log.error("We have error in this method {}",joinPoint.getSignature().getName());  
        log.error("The exception message: ".concat(exception.getMessage()));  
    }  
  
    @AfterReturning(value = "@annotation(com.example.logger.springlogger.aspect.TaskServiceAspect.Loggable)"
        ,returning = "returnValue")  
    public void logEachReturningValue(JoinPoint joinPoint,Object returnValue){  
        log.info("the value from method: "
            .concat(joinPoint.getSignature().getName())
            .concat(returnValue.toString()));  
    }  
  
    public @interface Loggable {  
    }  
}
```

### Log after running the application

After running the application and calling any API you can see something like this.

![](https://miro.medium.com/v2/resize:fit:875/1*0Zk359QjZ43kvIwvAN2dw.png)

### Conclusion

From this Article we learned and practiced how we can use aspect with spring boot, and how we can use our own annotations with aspect. If we have been confused by the previous article, I think cleaned your think about the aspect with this article. You can use this [link](https://github.com/abdalrhmanAlkraien/Aspect-example) to access this project on GitHub, you can see it to learn, clone, and practice it.
---


# Spring Boot AOP Logging 
In any web application we need logging request and response, We can do it using Log4j in java, but in this technique, we will write the logging in the business roles, it is good but we have better behavior.

In this article, we will use the spring boot Restful API and Aspect programming approach for logging the requests.

We will see how we can do it. and why we need to write the Aspect approach to do it.

To see an overview of aspect object programming in java and spring boot you can click on the following links.

1. [Aspect object programming with Spring boot (Part One)](/codex/aspect-object-programming-with-spring-boot-part-one-4544a58d6a4c)

2. [Aspect Object Programing with Spring boot Example (Part Tow)](/codex/aspect-object-programing-with-spring-boot-example-a2d0bf8f1578)

### Aspect configuration:

In the first step after creating a new spring boot project, we need to put our configuration inside the **pom.xml** file.

We have a simple dependency for running the spring boot application.
```xml
<?xml version="1.0" encoding="UTF-8"?>  
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">  
    <modelVersion>4.0.0</modelVersion>  
    <parent>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-parent</artifactId>  
        <version>2.7.0</version>  
        <relativePath/> <!-- lookup parent from repository -->  
    </parent>  
    <groupId>com.logging.aspect</groupId>  
    <artifactId>logging-spring-RestApi-using-aspect-object-programming</artifactId>  
    <version>0.0.1-SNAPSHOT</version>  
    <name>logging-spring-RestApi-using-aspect-object-programming</name>  
    <description>logging-spring-RestApi-using-aspect-object-programming</description>  
    <properties>  
        <java.version>11</java.version>  
    </properties>  
    <dependencies>  
        <dependency>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-starter-web</artifactId>  
        </dependency>  
  
        <dependency>  
            <groupId>org.projectlombok</groupId>  
            <artifactId>lombok</artifactId>  
            <optional>true</optional>  
        </dependency>  
        <dependency>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-starter-test</artifactId>  
            <scope>test</scope>  
        </dependency>  
    </dependencies>  
  
    <build>  
        <plugins>  
            <plugin>  
                <groupId>org.springframework.boot</groupId>  
                <artifactId>spring-boot-maven-plugin</artifactId>  
                <configuration>  
                    <excludes>  
                        <exclude>  
                            <groupId>org.projectlombok</groupId>  
                            <artifactId>lombok</artifactId>  
                        </exclude>  
                    </excludes>  
                </configuration>  
            </plugin>  
        </plugins>  
    </build>  
  
</project>
```
And now I will add aspect dependency to active Aspect in this project.
```xml
<!-- enable aspect -->  
<dependency>  
    <groupId>org.springframework</groupId>  
    <artifactId>spring-aop</artifactId>  
    <version>5.3.18</version>  
</dependency>  
  
<dependency>  
    <groupId>org.aspectj</groupId>  
    <artifactId>aspectjrt</artifactId>  
    <version>1.9.9.1</version>  
</dependency>  
  
<dependency>  
    <groupId>org.aspectj</groupId>  
    <artifactId>aspectjweaver</artifactId>  
    <version>1.9.9.1</version>  
</dependency>
```
The above dependencies are important dependencies to activate AOP inside any maven project.

### Writing our business logic for the application

**What do we need in this project?**

Actually, in this project, we need some features just to complete your vision on AOP.

1.  Simple controller: we need it to handle requests from client-side
2.  Simple service: we need it to cross the request from the controller to DTO
3.  Simple DTO: we need to log in using the AOP package inside our terminal
4.  Simple enum: we need to create an enum to know what is the data we need to log **REQUEST, RESPONSE**

**Let`s go to do it.**

1.  Create controller:

Our controller is called UserController, we will create it inside a package called Controller to arrange our code.
```java
package com.logging.aspect.loggingspringrestapiusingaspectobjectprogramming.controller;  
  
import com.logging.aspect.loggingspringrestapiusingaspectobjectprogramming.model.UserDto;  
import com.logging.aspect.loggingspringrestapiusingaspectobjectprogramming.service.UserService;  
import org.springframework.http.ResponseEntity;  
import org.springframework.web.bind.annotation.PostMapping;  
import org.springframework.web.bind.annotation.RequestBody;  
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RestController;  
  
import java.net.URI;  
  
@RestController  
@RequestMapping("user")  
public class UserController {  
    private UserService userService;  
  
    public UserController(UserService userService){  
        this.userService=userService;  
    }  
  
    @PostMapping("/login")  
    public ResponseEntity<UserDto> loginUser(@RequestBody UserDto userDto) throws Exception {  
        return ResponseEntity.ok().body(userService.login(userDto));  
    }  
}
```
you can see DataType enum in the git hub by [UserController](https://github.com/abdalrhmanAlkraien/logging-spring-RestApi-using-aspect-object-programming/blob/main/src/main/java/com/logging/aspect/loggingspringrestapiusingaspectobjectprogramming/controller/UserController.java)

2. Create service:

Our service is called UserService, we will create it inside a package called Service to arrange our code.
```java
package com.logging.aspect.loggingspringrestapiusingaspectobjectprogramming.service;  
  
import com.logging.aspect.loggingspringrestapiusingaspectobjectprogramming.model.UserDto;  
import org.springframework.stereotype.Service;  
  
@Service  
public class UserService {  
  
    public UserDto login(UserDto userDto) throws Exception {  
        if(userDto.getUserName().equals(userDto.getPassword())){  
            throw new Exception();  
        }  
        return userDto;  
    }  
}
```
You can see DataType enum in the git hub by [UserService](https://github.com/abdalrhmanAlkraien/logging-spring-RestApi-using-aspect-object-programming/blob/main/src/main/java/com/logging/aspect/loggingspringrestapiusingaspectobjectprogramming/service/UserService.java)

3. Create UserDto:

Our UserDto is called **UserDto**, we will create it inside a package called model to arrange our code.
```java
package com.logging.aspect.loggingspringrestapiusingaspectobjectprogramming.model;  

import lombok.Data;  
  
@Data  
public class UserDto {  
  private String userName;  
  private String password;  
}
```
You can see DataType enum in the git hub by [UserDto](https://github.com/abdalrhmanAlkraien/logging-spring-RestApi-using-aspect-object-programming/blob/main/src/main/java/com/logging/aspect/loggingspringrestapiusingaspectobjectprogramming/model/UserDto.java)

4. enum DataType: in this enum, we have two types **REQUEST** and **RESPONSE,** I will create a **utile** package to arrange our project.
```java
package com.logging.aspect.loggingspringrestapiusingaspectobjectprogramming.utile;  
  
public enum DataType {  
    REQUEST,RESPONSE  
}
```
You can see DataType enum in the git hub by [DataType](https://github.com/abdalrhmanAlkraien/logging-spring-RestApi-using-aspect-object-programming/blob/main/src/main/java/com/logging/aspect/loggingspringrestapiusingaspectobjectprogramming/utile/DataType.java)

Now, After finishing with business logic, we need to track the request and response by the AOP approach.

### **Aspect-object programming (AOP)**

In the first step, we need to create a new package called **aspect,** this package will have aspect classes. the first class in this package is called **UserAOP.**

In this class, we will write a code to do the following processes.

1.  we need to catch-all requests and log them.
2.  we need to catch-all responses and log them.
3.  we need to catch any exceptions and log the error and where is it.

**Let`s go to do it.**

I will explain the important code inside the following block of code.

In the first step in the class, we need to define and run without any problem. you can see the following code, and read the comment lines for a good understanding.
```java
package com.logging.aspect.loggingspringrestapiusingaspectobjectprogramming.aspect;  
  
import com.logging.aspect.loggingspringrestapiusingaspectobjectprogramming.utile.DataType;  
import lombok.extern.log4j.Log4j2;  
import org.aspectj.lang.JoinPoint;  
import org.aspectj.lang.annotation.Aspect;  
import org.aspectj.lang.annotation.Before;  
import org.aspectj.lang.annotation.Pointcut;  
import org.springframework.stereotype.Component;  
  
import java.util.Arrays;  
  
/**  
 Component: The aspect class must be Component Bean inside the spring context.  
 Aspect: We need to write @Aspect above the class to interrupt each advice inside it.  
 Log4j2: from Lombok for logger any message and debug the code  
 **/  
  
@Component  
@Aspect  
@Log4j2  
public class UserAOP {// our logic here }
```

**Logging all of the Requests receive to the Controller**

And now we need to create a new method to catch all requests will receive by the controller.

The following code has the explanation for each step in the comments lines

/**  
 * the following code will represent api Point cut value to set and reuse it inside any point cut method  
 * log controller is a point cut method  
 **/
 ```java  
private final String apiPointCut="execution(* com.logging.aspect.
    loggingspringrestapiusingaspectobjectprogramming.controller.*.*(..))";  
  
@Pointcut(apiPointCut)  
public void logController(){}  
```
/**  
 *  
 * **@param** joinPoint we can find inside it all the details of the method called inside the join point  
 *  
 * the AOP will execute this method before execute controller method  
 */  
```java 
@Before("logController()")  
public void logRequest(JoinPoint joinPoint){  
    // for log the controller name  
    log.info(joinPoint.getSignature().getName());  
    // for log the request attributes form client side  
    log.info(createJoinPointForLogs(joinPoint,DataType.REQUEST));  
}  
```  
  
/**  
 *  
 * **@param** joinPoint we need to use it to see attributes in the original method  
 * **@return** will return String after building all the attributes  
 */
```java  
private String createJoinPointForLogs(JoinPoint joinPoint, DataType dataType) {  
    /**  
     * the joinPoint has arguments from the controller,  
     * but we can see the args will receive here as an Array we need to check the length of it before making any Operations.  
     */    if (joinPoint.getArgs().length < 1) {  
        return joinPoint.getSignature().getName()  
                .concat(" method don`t have parameters");  
    }  
    Object[] obj = joinPoint.getArgs();  
    StringBuilder requestValue = new StringBuilder();  
    if(dataType.equals(DataType.REQUEST)){  
        requestValue.append("rn========== The request values ==========");  
    }  
    else {  
        requestValue.append("rn========== The response values ==========");  
    }  
    Arrays.stream(obj).forEach(x -> {  
        requestValue.append("rn");  
        requestValue.append(x.toString());  
    });  
    requestValue  
            .append("rn============= ======="  
                    + "====== =============");  
    return requestValue.toString();  
}
```
**Logging all of the Responses will come from the Controller:**

In this section, we need to implement code that will catch any Response from the controller.

The following code has the explanation for each step in the comments lines.
```java
@AfterReturning("logController()")  
public void logsResponse(JoinPoint joinPoint){  
    // for log the controller name  
    log.info(joinPoint.getSignature().getName());  
    log.info(createJoinPointForLogs(joinPoint,DataType.RESPONSE));  
}
```
Actually, we added Just one method for logs After the Response

**Logging all of the exceptions inside the project:**

In this section, we need to implement code that will catch any exceptions that will happen inside the project.

The following implementation will catch and logs any exception inside the project and from the logs will we know where is the Error.

For Imaplention it, we need a new variable and new method.

The following code has the explanation for each step in the comments lines.

/**  
 * the following point cut will scan all the project and catch any errors inside the project files  
 */  
private final String exceptionPointcut ="execution(* com.logging.aspect.loggingspringrestapiusingaspectobjectprogramming.*.*.*(..))";/**  
 * This method will print  
 * **@param** joinPoint we can find inside it all the details of the method called inside the join point  
 * **@param** exception from here we can know more details about the exception like exception type and exception message  
 */  
```java
@AfterThrowing(value = exceptionPointcut ,throwing = "exception")  
public void logsErrors(JoinPoint joinPoint, Throwable exception){  
    log.info("========================== We have Error here ==========================");  
    // for log the controller name  
    log.info(joinPoint.getSignature().getName());  
    // for know what the exception message  
    log.info(exception.getMessage());  
    log.info("==========================================================================");  
}
```
You can find the project on the git hub using the following link.

https://github.com/abdalrhmanAlkraien/logging-spring-RestApi-using-aspect-object-programming

### Conclusion:

With the aspect approach, you can log many things without needing to write logs code inside each class. you can save your code from **redundancy.**

And with the Aspect approach, your business logs have their own side, and your logs and tracking the code have another side. That means your code keeps order and without any randomness in the future.

Aspect object programming with spring-boot provides the developer with many features to improve code quality. For example, use annotations to log specific methods and many other features.

You can see the project code on the git hub using the follwoing.

https://github.com/abdalrhmanAlkraien/logging-spring-RestApi-using-aspect-object-programming
**