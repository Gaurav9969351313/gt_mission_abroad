# 9 Kafka Concepts That’ll Make You Regret Not Knowing Sooner

Lets suppose it’s 2 a.m., your production system is struggling, and you’re watching the Kafka consumer lag increase faster than the pile of emails in your inbox after a vacation. You’re completely baffled by the message duplications and the fact that half your consumers are idle. If only you had understood these nine key Kafka concepts sooner, you’d be resting instead of troubleshooting. I’ve experienced this, and I’m here to help you avoid the same situation. Let’s explore the fundamental Kafka concepts that every Java or Spring Boot developer should know — complete with code examples, benchmarks, and diagrams you can draw on a napkin.

### 1. Topics and Partitions: The Secret to Kafka’s Scalability

Kafka is more than just a message queue; it functions as a distributed log, with topics serving as its channels. Each topic divides into partitions — consider them as lanes on a highway. The more lanes there are, the more vehicles (or consumers) can travel simultaneously. However, there’s a downside: excessive partitions can lead to decreased performance in Kafka due to added overhead.

**Hand-Drawn Diagram**:

Topic: "orders"  
  |-- Partition 0: [msg1, msg2, ...]  
  |-- Partition 1: [msg3, msg4, ...]  
  |-- Partition 2: [msg5, msg6, ...]

**Code Example**:
```java
import org.apache.kafka.clients.admin.AdminClient;  
import org.apache.kafka.clients.admin.NewTopic;  
import java.util.Collections;  
import java.util.Properties;  
  
@Slf4j  
public class KafkaTopicCreator {  
    public static void main(String[] args) {  
        Properties props = new Properties();  
        props.put("bootstrap.servers", "localhost:9092");  
        try (AdminClient adminClient = AdminClient.create(props)) {  
            NewTopic topic = new NewTopic("orders", 3, (short) 1); // 3 partitions, 1 replica  
            admin.createTopics(Collections.singletonList(topic)).all().get();  
            System.out.println("Topic 'orders' created with 3 partitions.");  
        } catch (Exception e) {  
            System.err.println("Failed to create topic: " + e.getMessage());  
        }  
    }  
}
```
Why It’s Important: In a comparison with 10 partitions against just 1, the throughput increased from 1,000 to 8,000 messages per second. Understanding this will enable you to scale effectively.

### 2. Producers and Consumers: The Data Dance

Producers send messages to topics, while consumers retrieve them. It’s straightforward, but not entirely so. Producers have the ability to direct messages to particular partitions using keys, and consumers must manage the distribution of the load. If this is not handled correctly, one consumer might get overwhelmed, while others may remain inactive.

**Benchmark**:With 5 consumers and 10 partitions, I observed a 4.8x increase in throughput compared to a single consumer configuration — actual figures from a Spring Boot application handling 50,000 messages.

### 3. Consumer Groups: Teamwork Makes the Dream Work

Consumer groups allow various consumers to share the workload across partitions. Each partition is assigned a single consumer from the group, optimizing parallel processing. However, if you increase the number of consumers beyond the number of partitions, the extra ones will simply remain idle.

**Code Example**:
```java
import org.apache.kafka.clients.consumer.ConsumerRecords;  
import org.apache.kafka.clients.consumer.KafkaConsumer;  
import java.time.Duration;  
import java.util.Collections;  
import java.util.Properties;  
  
public class KafkaConsumerGroup {  
    public static void main(String[] args) {  
        Properties props = new Properties();  
        props.put("bootstrap.servers", "localhost:9092");  
        props.put("group.id", "order-processors");  
        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");  
        props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");  
        KafkaConsumer<String, String> kafkaconsumer = new KafkaConsumer<>(props);  
        kafkaconsumer.subscribe(Collections.singletonList("orders"));  
        while (true) {  
            ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(100));  
            records.forEach(record -> System.out.println("Consumed: " + record.value()));  
        }  
    }  
}
```

### 4. Offsets and Commit Logs: Your Safety Net

Each message is assigned an offset, which serves as a unique identifier within its partition. Consumers monitor these offsets to continue from their last point after a failure. Committing too soon may lead to duplicates, while delaying the commit could result in reprocessing outdated messages.

**Hand-Drawn Diagram**:

Partition 0:  
  Offset 0: "Order ###1"  
  Offset 1: "Order ###2"  
  Offset 2: "Order ###3"  
Consumer A: Last committed offset = 1

**Why It Matters**: If you lose sight of offsets, your payment system could end up charging customers twice. I’ve witnessed that occur.

### 5. Replication and Fault Tolerance: Kafka’s Superpower

Kafka distributes partitions among multiple brokers. With a replication factor of 3, there are three duplicates of your data — if you lose two brokers, your data remains safe. However, an increase in replicas can lead to reduced write speeds.

**Benchmark**: Increasing the replication factor from 1 to 3 raised the write latency from 5ms to 6.2ms during a test with 10,000 messages. It’s a trade-off that is important to consider.

### 6. Compaction and Tombstones: Cleaning House

Kafka’s log compaction retains the most recent value for each key, discarding the older ones. Tombstones, which are null-value messages, indicate records that should be deleted. Without this mechanism, your storage can expand significantly.

**Code Example**:
```java
import org.apache.kafka.clients.producer.KafkaProducer;  
import org.apache.kafka.clients.producer.ProducerRecord;  
import java.util.Properties;  
  
public class KafkaTombstoneProducer {  
    public static void main(String[] args) {  
        Properties props = new Properties();  
        props.put("bootstrap.servers", "localhost:9092");  
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");  
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");  
        KafkaProducer<String, String> producer = new KafkaProducer<>(props);  
        ProducerRecord<String, String> tombstone = new ProducerRecord<>("users", "user123", null);  
        producer.send(tombstone, (metadata, exception) -> {  
            if (exception == null) {  
                System.out.println("Tombstone sent to partition " + metadata.partition());  
            } else {  
                System.err.println("Error sending tombstone: " + exception.getMessage());  
            }  
        });  
        producer.close();  
    }  
}
```

### 7. Schema Registry: Taming Data Chaos

Transmitting JSON blobs? Be prepared for challenges if the structure alters. A schema registry ensures proper data formats and compatibility, protecting you from the headaches of parsing.

**Hand-Drawn Diagram**:

Producer ----> Kafka Topic ----> Consumer  
                               /  
        --> Schema Registry <--/

### 8. Exactly-Once Semantics: No More Duplicates

Duplicates in financial applications can lead to significant issues. Kafka’s transactional producers and consumers guarantee that every message is processed just one time. This isn’t sorcery — it’s all about coordination.

**Code Example**:
```java
import org.apache.kafka.clients.producer.KafkaProducer;  
import org.apache.kafka.clients.producer.ProducerRecord;  
import java.util.Properties;  
  
public class KafkaTransactionalProducer {  
    public static void main(String[] args) {  
        Properties props = new Properties();  
        props.put("bootstrap.servers", "localhost:9092");  
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");  
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");  
        props.put("transactional.id", "txn-producer-1");  
        KafkaProducer<String, String> kafkaProducer = new KafkaProducer<>(props);  
        kafkaProducer.initTransactions();  
        try {  
            kafkaProducer.beginTransaction();  
            kafkaProducer.send(new ProducerRecord<>("payments", "txn123", "500"));  
            kafkaProducer.commitTransaction();  
            System.out.println("Transaction committed successfully.");  
        } catch (Exception e) {  
            kafkaProducer.abortTransaction();  
            System.err.println("Transaction failed: " + e.getMessage());  
        } finally {  
            kafkaProducer.close();  
        }  
    }  
}
```

### 9. Kafka Streams: Real-Time Magic

Kafka Streams transforms your topics into dynamic data pipelines. In real-time, you can filter, aggregate, or join streams. It resembles SQL but is designed for the movement of data.

**Code Example**:
```java
import org.apache.kafka.streams.KafkaStreams;  
import org.apache.kafka.streams.StreamsBuilder;  
import org.apache.kafka.streams.kstream.KStream;  
import java.util.Properties;  
  
public class KafkaStreamsExample {  
    public static void main(String[] args) {  
        Properties props = new Properties();  
        props.put("application.id", "fraud-detection");  
        props.put("bootstrap.servers", "localhost:9092");  
        StreamsBuilder builderString = new StreamsBuilder();  
        KStream<String, String> transactions = builderString.stream("transactions");  
        transactions.filter((key, value) -> value.contains("suspicious"))  
                    .to("fraud-alerts");  
        KafkaStreams streams = new KafkaStreams(builderString.build(), props);  
        streams.start();  
        Runtime.getRuntime().addShutdownHook(new Thread(streams::close));  
    }  
}

```

### Wrap-Up: Don’t Wait Another Year

These nine concepts aren’t mere fun facts — they represent what separates a successful Kafka deployment from a chaotic disaster at midnight. From partitions to streams, each one has caused me trouble in the past, and I bear the marks to show for it. Get a handle on them now, and you’ll become the champion of your upcoming project. Believe me, your future self is already rooting for you.
# Kafka Troubleshooting: How to Handle Tough Real-World Scenarios Like a Pro

# Handle out-of-order message processing

# Your application reads from a Kafka topic and processes user orders. Some messages arrive out of order. How do you ensure **order preservation**?


Kafka guarantees **message ordering within a partition**. To maintain order:

**Use the same partition key for related messages**

Example: **User ID** for orders so all orders of a user go to the same partition.
```java
ProducerRecord<String, String> record = new ProducerRecord<>("orders", userId, orderData);
```
**Use a single consumer per partition**

-   If multiple consumers read from the same partition, order is **not guaranteed**.

**Batch processing with transactional writes**

-   If processing and writing to another system, use transactions (`commitTransaction()` after each batch).

### Handle duplicate messages

### Your Kafka producer or consumer occasionally processes duplicate messages, leading to **duplicate database entries**. How do you prevent this?

**Use Idempotent Producers**

-   Set `enable.idempotence=true` to avoid duplicate messages.

**Use Unique Message Keys**

-   Ensure each event has a **unique key** (e.g., order ID, user ID).

**Deduplicate on Consumer Side**

-   Maintain a **deduplication store** (Redis, database) and check for duplicates before processing.
```java
if (!cache.containsKey(eventId)) {     
    processMessage(record);     
    cache.put(eventId, true); 
}
```
**Use Kafka Streams with Exactly-Once Processing**
```java
streamBuilder.stream("input-topic").groupByKey()
        .reduce((agg, newVal) -> newVal)     
        .to("deduplicated-topic");
```

**Best Practice:** Use **idempotent writes in your database** (e.g., **UPSERT** instead of INSERT).

### Exactly-once message processing

### Your microservice consumes messages from Kafka and processes financial transactions. Duplicates can cause incorrect transactions. How do you ensure **exactly-once processing**?

Kafka provides **Exactly-Once Semantics (EOS)** using **idempotent producers** and **transactional processing**. The key steps:

**Enable Idempotence**

-   Set `enable.idempotence=true` in the producer config.
-   Kafka assigns a **Producer ID (PID)** to avoid duplicate messages.

**Use Kafka Transactions**

-   Enable `transactional.id` in producer properties.
-   Use `producer.initTransactions()`, `beginTransaction()`, `commitTransaction()`, and `abortTransaction()` properly.

**Atomic Consumption and Production** (Kafka Streams or Manual Approach)

-   If reading from one topic and writing to another, use **Kafka Streams** or `consumer.commitSync()` inside a transaction.

### Example Code (Transactional Producer in Java)
```java
Properties props = new Properties();  
props.put("bootstrap.servers", "localhost:9092");  
props.put("transactional.id", "txn-123"); // Unique for each producer  
props.put("enable.idempotence", "true");  
KafkaProducer<String, String> producer = new KafkaProducer<>(props);  
producer.initTransactions();  
try {  
    producer.beginTransaction();  
    producer.send(new ProducerRecord<>("output-topic", "key", "value"));  
    producer.commitTransaction();  
} catch (Exception e) {  
    producer.abortTransaction();  
}
```
### Key Notes:

If a transaction fails, Kafka ensures messages are not committed.  
Consumer uses `read_committed` isolation level to avoid reading uncommitted messages.  
Works best when combined with **idempotent consumers** (using a unique key per event).

### Avoid consumer rebalancing issues when scaling consumers

### You added new consumers to a Kafka consumer group, but this **triggers frequent rebalancing**, slowing down processing. How do you handle this?

**Use** `**StickyAssignor**` **instead of** `**RangeAssignor**`

-   Default partition assignment causes excessive movement when new consumers join. Use **StickyAssignor**:

partition.assignment.strategy=org.apache.kafka.clients.consumer.StickyAssignor

**Increase** `**session.timeout.ms**` **and** `**max.poll.interval.ms**`

-   If consumers take too long to process messages, Kafka might **remove them** from the group.

**Use Static Group Membership** (Avoid rebalance on restart)

-   Assign a unique **static member ID** to each consumer so Kafka does not reassign partitions unnecessarily.
```shell
group.instance.id=my-consumer-1
```
**Best Practice:** **Minimize consumer scaling** during peak load to avoid unnecessary rebalancing.

### Handle stuck messages (when consumer lag keeps increasing)

### Your Kafka topic has a high number of messages, but consumer lag keeps **increasing**. The consumer is unable to catch up. How do you fix this?

### **Check Consumer Processing Time**

-   If consumers are slow, process messages **in parallel** using worker threads.
```java
ExecutorService executor = Executors.newFixedThreadPool(10);   
records.forEach(record -> executor.submit(() -> processMessage(record)));
```
**Increase Number of Partitions & Consumers**

-   More partitions allow more consumers to read in parallel.
```java
kafka-topics.sh --alter --topic my_topic --partitions 10 --bootstrap-server localhost:9092
```
**Use** `**fetch.min.bytes**` **and** `**fetch.max.wait.ms**`

-   Fetch more messages per poll to increase efficiency.
```shell
fetch.min.bytes=1024  ### Fetch at least 1KB per poll  
fetch.max.wait.ms=500  ### Wait for more data before returning
```
**Best Practice:** Monitor **lag with Kafka Consumer Group Lag Monitoring Tools** like **Burrow** or **Confluent Control Center**.

### Handle large messages

### You have a Kafka topic where each message can be **several MBs** (e.g., images, logs, JSON blobs). However, Kafka’s default max message size is **1MB**, and some messages are getting rejected. How do you handle this?

**Increase** `**max.message.bytes**` **in broker and producer**

-   Kafka has a **default limit of 1MB** per message. Increase it in broker and producer configs:
```shell
### On the broker side  
message.max.bytes=5242880  ### 5MB     
### On the producer side  
max.request.size=5242880  ### 5MB
```
**Use Chunking (Split large messages into smaller ones)**

-   Split messages at the producer and reassemble them at the consumer.
```java
byte[][] chunks = splitMessage(largeMessage, CHUNK_SIZE);   
for (byte[] chunk : chunks) {      
    producer.send(new ProducerRecord<>("large-messages", key, chunk));  
}
```

**Use External Storage (Store large payloads outside Kafka)**

-   Store large files in **S3, HDFS, or a database**, and send only the reference (URL or ID) in Kafka.

**Best Practice:** **Kafka is optimized for small messages** (~1KB-100KB). If messages are frequently above 1MB, consider external storage.

### What happens when a Kafka broker goes down

### One of your Kafka brokers crashes. What happens to the messages, and how do you ensure high availability?

**Message Availability Depends on Replication Factor**

-   If the topic has **replication factor ≥2**, messages are safe in replicas.
-   If replication is **1**, messages on the failed broker **are lost**.

**Partition Re-election Happens Automatically**

-   Kafka will promote an ISR (In-Sync Replica) to become the new leader.

**Consumer Impact**

-   Consumers connected to the failed broker will experience temporary failures until they reconnect to a new leader.

**Set a replication factor of at least 3**  
**Enable** `**unclean.leader.election=false**` to avoid data loss  
**Monitor broker health with Kafka’s CLI**
```shell
kafka-topics.sh --describe --topic my_topic --bootstrap-server localhost:9092
```
### Handle producer retries and failures

### Your Kafka producer sometimes fails due to **network timeouts** or **leader not available** errors. How do you ensure messages are not lost?

**Enable Retries & Increase Timeouts**
```shell
retries=5    
retry.backoff.ms=500  ### Wait before retrying    
request.timeout.ms=30000  ### Wait longer for broker response
```
**Use Acknowledgements (**`**acks=all**`**)**

-   Ensures messages are **persisted to all replicas** before being acknowledged.

acks=all

**Use an Asynchronous Retry Mechanism**

-   Catch errors and retry failed messages later.
```java
producer.send(record, (metadata, exception) -> {    
   if (exception != null) {         
        retryLater(record);  
  // Retry mechanism     
  } 
});
```
**Best Practice:** Combine retries with **idempotent producers** (`enable.idempotence=true`) to avoid duplicates.

Hope you all liked the content. Clap if you like this and follow me for more interesting content .It will be great if you show your love and encouragement :)

Meet you all with my next article soon.

Meanwhile, keep reading my other articles too :)  
[https://medium.com/@letslearnnow/list/reading-list](/@letslearnnow/list/reading-list)

### Consume the Same Event with Different Consumer Groups in Kafka (Spring Boot) 


In this article, I will discuss `**consumer group**` in Kafka. We will produce the Kafka event, and **consume the same Kafka event with different consumer groups.**

https://medium.com/@mertcakmak2/apache-kafka-retry-policy-in-spring-boot-edaa8048da60

### Tech Stack

-   Spring Boot(2.7.5)
-   Apache Kafka
-   Zookeeper
-   Docker

### Architecture

![](https://miro.medium.com/v2/resize:fit:875/1*6IjTWthkyOhsQthMQg9YQ.png)

### Dependencies

`**Spring Version**`: 2.7.5  
`**Java Version**`: 11
```xml
 <dependencies>  
  
        <dependency>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-starter-web</artifactId>  
        </dependency>  
  
        <dependency>  
            <groupId>org.springframework.kafka</groupId>  
            <artifactId>spring-kafka</artifactId>  
        </dependency>  
  
        <dependency>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-starter-test</artifactId>  
            <scope>test</scope>  
        </dependency>  
  
        <dependency>  
            <groupId>org.springframework.kafka</groupId>  
            <artifactId>spring-kafka-test</artifactId>  
            <scope>test</scope>  
        </dependency>  
  
    </dependencies>
```
### Docker Compose

```yaml
version: '3.8'  
services:  
  
  zookeeper:  
    containername: zookeeper-svc  
    image: confluentinc/cp-zookeeper:5.4.9  
    restart: always  
    ports:  
      - "2181:2181"  
    environment:  
      ZOOKEEPERCLIENTPORT: 2181  
  
  kafka:  
    containername: kafka-svc  
    image: confluentinc/cp-kafka:6.0.9  
    restart: always  
    dependson:  
      - zookeeper  
    ports:  
      - "9092:9092"  
    environment:  
      KAFKAZOOKEEPERCONNECT: "zookeeper:2181"  
      KAFKALISTENERSECURITYPROTOCOLMAP: PLAINTEXT:PLAINTEXT,PLAINTEXTHOST:PLAINTEXT  
      KAFKAADVERTISEDLISTENERS: PLAINTEXT://kafka:29092,PLAINTEXTHOST://localhost:9092  
      KAFKAOFFSETSTOPICREPLICATIONFACTOR: "1"  
      KAFKADELETETOPICENABLE: "true"  
      KAFKAADVERTISEDHOSTNAME:  
  
  kafdrop:  
    image: obsidiandynamics/kafdrop  
    containername: kafdrop-svc  
    restart: always  
    dependson:  
      - zookeeper  
      - kafka  
    ports:  
      - "9000:9000"  
    environment:  
      KAFKABROKERCONNECT: kafka:29092
```
Run the below command.
```shell
docker-compose up -d
```
### Docker Containers

![](https://miro.medium.com/v2/resize:fit:875/1*HTUlMrEhSnAhqh8BesB3Q.png)

### Common Order Model
```java
public class Order {  
  
    private int orderId;  
    private Date date;  
  
    public Order(int orderId, Date date) {  
        this.orderId = orderId;  
        this.date = date;  
    }  
  
    public Order() {  
    }  
  
   // getter and setter  
}
```
### Order Service (Producer)

-   **application.properties**
```shell
spring.application.name=order-application  
server.port=8080  
  
spring.kafka.bootstrap-servers=localhost:9092  
  
spring.kafka.producer.key-serializer=org.apache.kafka.common.serialization.StringSerializer  
spring.kafka.producer.value-serializer=org.springframework.kafka.support.serializer.JsonSerializer  
spring.kafka.producer.properties.spring.json.add.type.headers=false
```
-   **TopicConfig**
```java
@Configuration  
@Component  
public class TopicConfig {  
  
    @Bean  
    public NewTopic createTopic() {  
        return TopicBuilder.name("order-created-event")  
                .partitions(1)  
                .build();  
    }  
  
}
```
-   **OrderController**
```java
@RestController  
@RequestMapping("/api/v1/order")  
public class OrderController {  
  
    public final OrderCreatedEventProducer orderCreatedEventProducer;  
  
    @Autowired  
    public OrderController(OrderCreatedEventProducer orderCreatedEventProducer) {  
        this.orderCreatedEventProducer = orderCreatedEventProducer;  
    }  
  
    @GetMapping(path = "")  
    public String publishOrder() {  
        var id = (int) (Math.random() * 100) + 1;  
        var order = new Order(id, new Date());  
        orderCreatedEventProducer.produce(order);  
  
        return "Order created";  
    }  
}
```

-   **OrderCreatedEventProducer**
```java
@Component  
public class OrderCreatedEventProducer {  
  
    private KafkaTemplate<String, Object> kafkaTemplate;  
  
    @Autowired  
    public OrderCreatedEventProducer(KafkaTemplate<String, Object> kafkaTemplate) {  
        this.kafkaTemplate = kafkaTemplate;  
    }  
  
    public void produce(Order order) {  
        this.kafkaTemplate.send("order-created-event", order);  
    }  
}
```

`**public void produce(Order order)**`: This method is responsible for producing an order to a Kafka topic.

`**this.kafkaTemplate.send("order-created-event", order)**`: Inside the `produce` method, it uses the `kafkaTemplate` to send the `Order` object to a Kafka topic named "order-created-event."

### Stock Service (Consumer)

-   **application.properties**
```shell
spring.application.name=stock-application  
server.port=8082  
  
spring.kafka.bootstrap-servers=localhost:9092  
  
spring.kafka.consumer.group-id=stock-group  
spring.kafka.consumer.auto-offset-reset=earliest  
spring.kafka.consumer.key-deserializer=org.apache.kafka.common.serialization.StringDeserializer  
spring.kafka.consumer.value-deserializer=org.springframework.kafka.support.serializer.JsonDeserializer  
spring.kafka.consumer.properties.spring.json.add.type.headers=false  
spring.kafka.consumer.properties.spring.json.trusted.packages=*  
  
spring.kafka.listener.ack-mode=manualimmediate
```
-   **OrderCreatedEventConsumer**
```java
@Component  
public class OrderCreatedEventConsumer {  
  
    @KafkaListener(topics = "order-created-event", groupId = "stock-group", properties = {"spring.json.value.default.type=com.example.stockservice.model.Order"})  
    public void consumeOrderCreatedEvent(Order order, Acknowledgment acknowledgment) {  
        System.out.println(String.format("Stock Group, Order ID: %s", order.getOrderId()));  
        acknowledgment.acknowledge();  
    }  
}
```
`**groupId = "stock-group"**`: The `groupId` attribute specifies the Kafka consumer group to which this consumer belongs.

### Payment Service (Consumer)

-   **application.properties**
```shell
spring.application.name=payment-application  
server.port=8083  
  
spring.kafka.bootstrap-servers=${kafka-service:localhost}:9092  
  
spring.kafka.consumer.group-id=payment-group  
spring.kafka.consumer.auto-offset-reset=earliest  
spring.kafka.consumer.key-deserializer=org.apache.kafka.common.serialization.StringDeserializer  
spring.kafka.consumer.value-deserializer=org.springframework.kafka.support.serializer.JsonDeserializer  
spring.kafka.consumer.properties.spring.json.add.type.headers=false  
spring.kafka.consumer.properties.spring.json.trusted.packages=*  
  
spring.kafka.listener.ack-mode=manualimmediate
```
-   **OrderCreatedEventConsumer**
```java
@Component  
public class OrderCreatedEventConsumer {  
  
    @KafkaListener(topics = "order-created-event", groupId = "payment-group", properties = {"spring.json.value.default.type=com.example.paymentservice.model.Order"})  
    public void consumeOrderCreatedEvent(Order order, Acknowledgment acknowledgment) {  
        System.out.println(String.format("Payment Group,  Order ID: %s", order.getOrderId()));  
        acknowledgment.acknowledge();  
    }  
  
}
```
`**groupId = "payment-group"**`: The `groupId` attribute specifies the Kafka consumer group to which this consumer belongs.

### Start Services

![](https://miro.medium.com/v2/resize:fit:875/1*-FZQUxlFu3oaRBnUiuSA0Q.png)

> **Order Service:** UP  
> **Stock Service:** UP  
> **Payment Service:** UP

### Visit Kafdrop

> [http://127.0.0.1:9000](http://127.0.0.1:9000)

![](https://miro.medium.com/v2/resize:fit:875/1*S-ohkgetbC1DP4oZ0t9q1g.png)

### Send HTTP Requests to Order Service

> [GET] [http://127.0.0.1:8080/api/v1/order](http://127.0.0.1:8080/api/v1/order)

![](https://miro.medium.com/v2/resize:fit:875/1*yxUmY5kXbWQG-KmDq4RALg.png)

![](https://miro.medium.com/v2/resize:fit:875/1*unF6Dd1NRkAN024MG2P9Lg.png)

### Console Logs

![](https://miro.medium.com/v2/resize:fit:875/1*G0VdNwBdFi9GiBE0AQX5eA.png)

Same Kafka event consumed by `**Stock Service**` and `**Payment Service**`.

### GitHub Repository:

https://github.com/mertcakmak2/Medium-Stories-Projects/tree/master/spring-kafka-parallel-consuming


---
# Spring Boot Dynamic Kafka Consumer 

In [the previous article](/@zulffaza/change-spring-boot-kafka-consumer-state-at-runtime-5546341dfa5c), i wrote about how to change kafka consumer state at runtime. Then i started to think, what if I have a logic process that I want to apply for some kafka topics? Do I have to create multiple kafka consumers using the @KafkaListener annotation?

If you have tried to create a kafka consumer using a spring boot or have read my previous article, the answer of my question above is to create multiple consumer classes using the @KafkaListener annotation. However, every time we create a new consumer, we have to change the application code and run the application again, so that the consumer we just created can run.

In this article, I will try to use the KafkaListenerEndpointRegistry class to register the kafka consumer when the application is startup or when it is running. That way we don’t need to create multiple classes for each kafka consumer we want to create, and there’s no need to change the code and restart our application when we want to create a new kafka consumer.

### Create a Dynamic Kafka Consumer

If you take a deeper look at the KafkaListenerEndpointRegistry class, you will find a method for registering your consumer, which is the registerListenerContainer method. The method accepts 3 parameters, that is KafkaListenerEndpoint, KafkaListenerContainerFactory, and Boolean startImmediately. Knowing that, the first thing we need to create is a KafkaListenerEndpoint object which we will list it into.  
KafkaListenerEndpointRegistry

The KafkaListenerEndpoint class is a class that stores information to define a kafka consumer, including information regarding the consumer id, the listened topics, the consumer group id, the consumer class, the methods that used to process messages, and so on. Because KafkaListenerEndpoint is an interface, we can use one of its implementation classes, one of them is the MethodKafkaListenerEndpoint class. This MethodKafkaListenerEndpoint class is also used to define kafka consumers when we use the @KafkaListener annotation.

Because there are several things that we can define for all of our consumers later, I will create a parent class that is responsible for creating a template object from the MethodKafkaListenerEndpoint class. We will extend the parent class with our consumer class, and add some specific information to our consumer in the MethodKafkaListenerEndpoint object that has been created.

**CustomMessageListener.java**
```java
public abstract class CustomMessageListener {    
  
    private static int NUMBEROFLISTENERS = 0;    
    @Autowired  
    private KafkaProperties kafkaProperties;    
    
    public abstract KafkaListenerEndpoint createKafkaListenerEndpoint(String name, String topic);    
    
    protected MethodKafkaListenerEndpoint<String, String> createDefaultMethodKafkaListenerEndpoint(  
			String name, String topic) {  
        MethodKafkaListenerEndpoint<String, String> kafkaListenerEndpoint =   
			new MethodKafkaListenerEndpoint<>();  
        kafkaListenerEndpoint.setId(getConsumerId(name));  
        kafkaListenerEndpoint.setGroupId(kafkaProperties.getConsumer().getGroupId());  
        kafkaListenerEndpoint.setAutoStartup(true);  
        kafkaListenerEndpoint.setTopics(topic);  
        kafkaListenerEndpoint.setMessageHandlerMethodFactory(new DefaultMessageHandlerMethodFactory());  
        return kafkaListenerEndpoint;  
    }    private String getConsumerId(String name) {  
        if (isBlank(name)) {  
            return CustomMessageListener.class.getCanonicalName() + "#" + NUMBEROFLISTENERS++;  
        } else {  
            return name;  
        }  
    }    private boolean isBlank(String string) {  
        return Optional.ofNullable(string)  
                .map(String::isBlank)  
                .orElse(true);  
    }  
}
```
**MyCustomMessageListener.java**
```java
@Component  
public class MyCustomMessageListener extends CustomMessageListener {    
    @Override  
    @SneakyThrows  
    public KafkaListenerEndpoint createKafkaListenerEndpoint(String name, String topic) {  
        MethodKafkaListenerEndpoint<String, String> kafkaListenerEndpoint =  
                createDefaultMethodKafkaListenerEndpoint(name, topic);  
        kafkaListenerEndpoint.setBean(new MyMessageListener());  
        kafkaListenerEndpoint.setMethod(MyMessageListener.class.getMethod(  
			"onMessage", ConsumerRecord.class));  
        return kafkaListenerEndpoint;  
    }   
    
    @Slf4j  
    private static class MyMessageListener implements MessageListener<String, String> {        @Override  
        public void onMessage(ConsumerRecord<String, String> record) {  
            log.info("My message listener got a new record: " + record);  
            CompletableFuture.runAsync(this::sleep)  
                    .join();  
            log.info("My message listener done processing record: " + record);  
        }        @SneakyThrows  
        private void sleep() {  
            Thread.sleep(5000);  
        }  
    }  
}
```
### Register Kafka Consumer at Runtime

To be able to create a kafka consumer, based on our dynamic kafka consumer code, we need information regarding the name of the consumer and the topic that the consumer will support. Information regarding the consumer name and topic will be retrieved via the spring boot properties. However, later you will be able to change the source of the information, through databases, caches, files, restarts, and so on.

**CustomKafkaListenerProperty.java**
```java
@Data  
@Builder  
@NoArgsConstructor  
@AllArgsConstructor  
public class CustomKafkaListenerProperty {    
  private String topic;  
    private String listenerClass;  
}
```

**CustomKafkaListenerProperties.java**
```java
@Data  
@ConfigurationProperties(prefix = "custom.kafka")  
public class CustomKafkaListenerProperties {    
    private Map<String, CustomKafkaListenerProperty> listeners;  
}
```
In the 2 codes above, we define a class that will automatically read properties with the prefix “custom.kafka”. Since we are defining a variable listeners, properties with the prefix “custom.kafka.listeners” will be stored in that variable. In order to use these classes, an @ConfigurationPropertiesScan annotation is required, and dont forget @EnableKafka annotation.

**Application.java**
```java
@EnableKafka  
@SpringBootApplication  
@ConfigurationPropertiesScan  
public class Application {	
  public static void main(String[] args) {  
		  SpringApplication.run(Application.class, args);  
	}
}
```
  
application.properties**
```shell
spring.kafka.bootstrap-servers=localhost:9092  
spring.kafka.consumer.group-id=runtime-kafka-registry  
custom.kafka.listeners.listener-1.topic=com.faza.example.custom.listener.property  
custom.kafka.listeners.listener-1.listener-class=MyCustomMessageListener
```

Our kafka consumer properties can be set using “custom.kafka.listener. <key> .topic” and “custom.kafka.listener. <key> .listener-class”. The key will define the id of our consumer, topic will define the topic that will listened by our consumers, and listener-class is the class that will process messages from the topic we set. Then at application startup we will registering all our consumer that we already defined before with our custom registrar. It should be noted that the listener that we can use are classes that are inside “com.faza.example.dynamickafkaconsumer.listener” package.

**CustomKafkaListenerRegistrar.java**
```java
@Component  
public class CustomKafkaListenerRegistrar implements InitializingBean {    
    @Autowired  
    private CustomKafkaListenerProperties customKafkaListenerProperties;    
    @Autowired  
    private BeanFactory beanFactory;    
    @Autowired  
    private KafkaListenerEndpointRegistry kafkaListenerEndpointRegistry;    
    @Autowired  
    private KafkaListenerContainerFactory kafkaListenerContainerFactory;    
    @Override  
    public void afterPropertiesSet() {  
        customKafkaListenerProperties.getListeners()  
                .forEach(this::registerCustomKafkaListener);  
    }    
    public void registerCustomKafkaListener(String name, CustomKafkaListenerProperty      customKafkaListenerProperty) {  
        this.registerCustomKafkaListener(name, customKafkaListenerProperty, false);  
    }    
    
    @SneakyThrows  
    public void registerCustomKafkaListener(String name, CustomKafkaListenerProperty customKafkaListenerProperty,  
                                            boolean startImmediately) {  
        String listenerClass = String.join(".", CustomKafkaListenerRegistrar.class.getPackageName(),  
                customKafkaListenerProperty.getListenerClass());  
        CustomMessageListener customMessageListener =  
                (CustomMessageListener) beanFactory.getBean(Class.forName(listenerClass));  
        kafkaListenerEndpointRegistry.registerListenerContainer(  
                customMessageListener.createKafkaListenerEndpoint(name, customKafkaListenerProperty.getTopic()),  
                kafkaListenerContainerFactory, startImmediately);  
    }  
}
```
Let’s try running the application, you will be able to see through the logs that our customer has been created with the id that we have set to <key> in properties. In addition to logs, you can access our consumer information through rest api based on the article I wrote before.

2020-11-26 14:13:24.003  INFO 22200 --- [istener-1-0-C-1] o.a.k.c.c.internals.AbstractCoordinator  : [Consumer clientId=consumer-runtime-kafka-registry-1, groupId=runtime-kafka-registry] (Re-)joining group  
2020-11-26 14:13:24.080  INFO 22200 --- [istener-1-0-C-1] o.a.k.c.c.internals.ConsumerCoordinator  : [Consumer clientId=consumer-runtime-kafka-registry-1, groupId=runtime-kafka-registry] Finished assignment for group at generation 5: {consumer-runtime-kafka-registry-1-4e2cb25a-b72e-450a-ba1c-de9e4becbfc8=Assignment(partitions=[com.faza.example.custom.listener.property-0])}  
2020-11-26 14:13:24.090  INFO 22200 --- [istener-1-0-C-1] o.a.k.c.c.internals.AbstractCoordinator  : [Consumer clientId=consumer-runtime-kafka-registry-1, groupId=runtime-kafka-registry] Successfully joined group with generation 5  
2020-11-26 14:13:24.092  INFO 22200 --- [istener-1-0-C-1] o.a.k.c.c.internals.ConsumerCoordinator  : [Consumer clientId=consumer-runtime-kafka-registry-1, groupId=runtime-kafka-registry] Notifying assignor about the new Assignment(partitions=[com.faza.example.custom.listener.property-0])  
2020-11-26 14:13:24.097  INFO 22200 --- [istener-1-0-C-1] o.a.k.c.c.internals.ConsumerCoordinator  : [Consumer clientId=consumer-runtime-kafka-registry-1, groupId=runtime-kafka-registry] Adding newly assigned partitions: com.faza.example.custom.listener.property-0  
2020-11-26 14:13:24.114  INFO 22200 --- [istener-1-0-C-1] o.a.k.c.c.internals.ConsumerCoordinator  : [Consumer clientId=consumer-runtime-kafka-registry-1, groupId=runtime-kafka-registry] Found no committed offset for partition com.faza.example.custom.listener.property-0  
2020-11-26 14:13:24.128  INFO 22200 --- [istener-1-0-C-1] o.a.k.c.c.internals.SubscriptionState    : [Consumer clientId=consumer-runtime-kafka-registry-1, groupId=runtime-kafka-registry] Resetting offset for partition com.faza.example.custom.listener.property-0 to offset 0.  
2020-11-26 14:13:24.130  INFO 22200 --- [istener-1-0-C-1] o.s.k.l.KafkaMessageListenerContainer    : runtime-kafka-registry: partitions assigned: [com.faza.example.custom.listener.property-0]
[  
  {  
    "consumerId": "listener-1",  
    "groupId": "runtime-kafka-registry",  
    "listenerId": "listener-1",  
    "active": true,  
    "assignments": [  
      {  
        "topic": "com.faza.example.custom.listener.property",  
        "partition": 0  
      }  
    ]  
  }  
]

### Using REST-API to Registering Our New Consumer

In the previous section we created a dynamic consumer based on the data in the properties, this time we will try to register a new consumer using rest api. We’ll add a few lines of code to the KafkaConsumerRegistryController class to create a rest api that can register new consumers.

**KafkaConsumerRegistryController.java**

```java
    @Autowired  
    private CustomKafkaListenerRegistrar customKafkaListenerRegistrar;  
  
    @PostMapping(path = "/create")  
    @ResponseStatus(HttpStatus.CREATED)  
    public void createConsumer(@RequestParam String topic, @RequestParam String listenerClass,  
                               @RequestParam(required = false) boolean startImmediately) {  
        customKafkaListenerRegistrar.registerCustomKafkaListener(null,  
                CustomKafkaListenerProperty.builder()  
                        .topic(topic)  
                        .listenerClass(listenerClass)  
                        .build(),  
                startImmediately);  
    }  
```

Let’s try restarting the application, then hit the POST [http://localhost:8080/api/kafka/registry/create](http://localhost:8080/api/kafka/registry/create) by passing the topic and listenerClass parameters. The parameters that we send have the same definition with custom kafka properties that we set on properties. After that, try to hit GET [http://localhost:8080/api/kafka/registry,](http://localhost:8080/api/kafka/registry,) and you will see the consumer you just registered.
```json
[  
  {  
    "consumerId": "com.faza.example.dynamickafkaconsumer.listener.CustomMessageListener#0",  
    "groupId": "runtime-kafka-registry",  
    "listenerId": "com.faza.example.dynamickafkaconsumer.listener.CustomMessageListener#0",  
    "active": false,  
    "assignments": []  
  },  
  {  
    "consumerId": "listener-1",  
    "groupId": "runtime-kafka-registry",  
    "listenerId": "listener-1",  
    "active": true,  
    "assignments": [  
      {  
        "topic": "com.faza.example.custom.listener.property",  
        "partition": 0  
      }  
    ]  
  }  
]
```

However, the consumers that we have registered are not yet running, why aren’t they running? because previously we didn’t pass the startImmediately parameter, so the consumer doesn’t running immediately after it registered. You can add the parameter startImmediately true when registering consumers, or use [http://localhost:8080/api/kafka/registry/activate](http://localhost:8080/api/kafka/registry/activate) to make your consumers running.
```json
[  
  {  
    "consumerId": "com.faza.example.dynamickafkaconsumer.listener.CustomMessageListener#0",  
    "groupId": "runtime-kafka-registry",  
    "listenerId": "com.faza.example.dynamickafkaconsumer.listener.CustomMessageListener#0",  
    "active": true,  
    "assignments": [  
      {  
        "topic": "com.faza.example.custom.listener.property.new",  
        "partition": 0  
      }  
    ]  
  },  
  {  
    "consumerId": "listener-1",  
    "groupId": "runtime-kafka-registry",  
    "listenerId": "listener-1",  
    "active": true,  
    "assignments": [  
      {  
        "topic": "com.faza.example.custom.listener.property",  
        "partition": 0  
      }  
    ]  
  }  
]
```

You can also change the state of your kafka consumers using the api rest we created earlier in the KafkaConsumerRegistryController.

### Multi-VM Applications

Sometimes we have running applications in multiple vms, so we have many instance that will processing data. Therefore we need to create a consumer that will retrived action message, we just modify our action consumer from my previous article. We will make our action consumer support to create new kafka consumer, and modify our create rest api to publish action message.

**ConsumerAction.java**
```java
public enum ConsumerAction {    
    CREATE,  
    ACTIVATE,  
    DEACTIVATE,  
    PAUSE,  
    RESUME  
}
```

ConsumerActionRequest.java**
```java
@Data  
@Builder  
@JsonInclude(JsonInclude.Include.NONNULL)  
public class ConsumerActionRequest {    
    @Builder.Default  
    private long timestamp = System.currentTimeMillis();    
    private String consumerId;    
    private CustomKafkaListenerProperty consumerProperty;    
    private Boolean startImmediately;    
    private ConsumerAction consumerAction;  
}
```
**ConsumerActionListener.java**
```java 
    @Autowired  
    private CustomKafkaListenerRegistrar customKafkaListenerRegistrar;  
    private void processAction(ConsumerActionRequest request) {  
        String consumerId = request.getConsumerId();  
        MessageListenerContainer listenerContainer = Optional.ofNullable(consumerId)  
                .map(kafkaListenerEndpointRegistry::getListenerContainer)  
                .orElse(null);  
        switch (request.getConsumerAction()) {  
            case CREATE:  
                CustomKafkaListenerProperty consumerProperty = request.getConsumerProperty();  
                log.info(String.format("Creating a %s consumer for topic %s",  
                        consumerProperty.getListenerClass(), consumerProperty.getTopic()));  
                customKafkaListenerRegistrar.registerCustomKafkaListener(null,  
                        consumerProperty, request.getStartImmediately());  
                break;  
		  
	} 
``` 


**KafkaConsumerRegistryController.java**
```java  
    @PostMapping(path = "/create")  
    @ResponseStatus(HttpStatus.CREATED)  
    public void createConsumer(@RequestParam String topic, @RequestParam String listenerClass,  
                               @RequestParam(required = false) boolean startImmediately) {  
        publishMessage(ConsumerActionRequest.builder()  
                .consumerProperty(CustomKafkaListenerProperty.builder()  
                        .topic(topic)  
                        .listenerClass(listenerClass)  
                        .build())  
                .startImmediately(startImmediately)  
                .consumerAction(ConsumerAction.CREATE)  
                .build());  
    }  
```
### Conclusion

From now on, if we want to use the same consumer logic for multiple topics, we no longer need to define consumer classes for each topic. We simply define a consumer class, and register it for each topic we want.

In this article the source of our topic and consumer information is application properties, but you can change the source of that information. You can store this information in a database table or collection, and register new consumers when adding new data to the database. Apart from databases, you can use other sources of information such as cache, files, or even rest api from other applications.

The limitation in this article is that we cannot delete the consumers we have registered, because it is not possible to do this using the KafkaListenerEndpointRegistry class. In order to make this possible, we need to create our own registry class. I will discuss this in the next article.

All the code that we have done in this article can be seen in the following 

https://github.com/zulffaza/Dynamic-Kafka-Consumer

