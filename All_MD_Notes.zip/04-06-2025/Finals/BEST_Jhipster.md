# Create Full Microservice Stack Using JHipster Domain Language Under 30 Minutes

It’s been quite a while since I wrote a blog. I did [a few](https://mytechnorage.blogspot.com/) some years ago but never really continued writing. So when I decided to start writing again, I didn’t have to think a lot about a topic as it was very obvious — [JHipster](https://www.jhipster.tech/).

JHipster is a development platform for Java web applications and microservices development. If you are a JVM developer, you might have already heard about [JHipster](https://www.jhipster.tech/). If not, well, you are missing out on a lot, and I highly recommend you check it out. You can also check out my book **Full Stack Development with JHipster** on [Amazon](https://www.amazon.com/Stack-Development-JHipster-Deepu-Sasidharan/dp/178847631X) and [Packt](https://www.packtpub.com/application-development/full-stack-development-jhipster) to learn about JHipster.

I have been working on JHipster since April 2015, and the coolest feature that I got to implement so far is definitely multiple applications generation using JDL. This feature is available in the latest version of JHipster. If you are not familiar with JDL, I recommend you check out the docs at [https://www.jhipster.tech/jdl/](https://www.jhipster.tech/jdl/).

## The E-Commerce Application

Let us see how we can create a microservice stack using JHipster. We will build an e-commerce store today. The stack includes:

- Service discovery using [JHipster Registry](https://www.jhipster.tech/jhipster-registry/), a Spring Boot application that packs Eureka server and Spring Cloud Config server.
- [API management and Gateway](https://www.jhipster.tech/api-gateway/) using Spring Boot, Netflix Zuul, ReactJS, and Swagger.
- Microservices using Spring Boot.
- Monitoring using [JHipster Console](https://www.jhipster.tech/monitoring/#jhipster-console), which is made of the Elastic stack (ELK) and Zipkin.

![Microservice application architecture](https://miro.medium.com/v2/resize:fit:875/1*b4krMVZ-mqjxAIh_EM1jhQ.png)

The Gateway routes requests to two microservices: Invoice application and Notification application.

### Requirements

To follow this tutorial, you need a recent version of **Docker**, **Docker-compose**, **NodeJS**, and **Java 8** installed on your computer. Below are the versions I have installed:

```shell
$ docker -v
Docker version 18.06.1-ce, build e68fc7a

$ docker-compose -v
docker-compose version 1.20.1, build 5d8c71b

$ node -v
v8.11.4

$ java -version
java version "1.8.0_131"
Java(TM) SE Runtime Environment (build 1.8.0_131-b11)
Java HotSpot(TM) 64-Bit Server VM (build 25.131-b11, mixed mode)
```

First, install the latest version of JHipster:

```shell
$ npm install generator-jhipster -g
```

Verify that you have version **5.3.4** or above by running:

```shell
$ jhipster --version
```

### Creating the JDL

Now let us create our JDL. Head over to the [JDL Studio](https://www.jhipster.tech/jdl-studio/) (_use the older version for now as JDL 3 update is not released for the new JDL studio yet_) or your favorite IDE/Editor (_You can use_ [_JHipster IDE_](https://www.jhipster.tech/jhipster-ide/) _plugin if you like_).

First, let us define our applications. We will start with the Gateway:

```java
application {
  config {
    baseName store,
    applicationType gateway,
    packageName com.jhipster.demo.store,
    serviceDiscoveryType eureka,
    authenticationType jwt,
    prodDatabaseType mysql,
    cacheProvider hazelcast,
    buildTool gradle,
    clientFramework react,
    useSass true,
    testFrameworks [protractor]
  }
  entities *
}
```

Most of the options are self-explanatory. We are building an application named **Store** of type **Gateway** with **JWT** authentication and **Eureka**-based service discovery. The application uses a **MySQL** database and **Hazelcast** for the cache. It's built using **Gradle**. For the client-side, it uses **React** and **Sass**. It also has **Protractor** for end-to-end testing.

At the end of the definition, you can see `entities *`. We will come to this later.

Now let us define our Invoice microservice:

```java
application {
  config {
    baseName invoice,
    applicationType microservice,
    packageName com.jhipster.demo.invoice,
    serviceDiscoveryType eureka,
    authenticationType jwt,
    prodDatabaseType mysql,
    buildTool gradle,
    serverPort 8081,
    skipUserManagement true
  }
  entities Invoice, Shipment
}
```

It follows similar options like our Gateway, and since it is a microservice, it doesn’t define any client-side options and also skips user management as it will be handled by the Gateway. Additionally, we have also mentioned a custom port **8081** since we do not want this application to conflict with the default port 8080 used by the Gateway.

Now let us define the second microservice, the Notification application:

```java
application {
  config {
    baseName notification,
    applicationType microservice,
    packageName com.jhipster.demo.notification,
    serviceDiscoveryType eureka,
    authenticationType jwt,
    databaseType mongodb,
    prodDatabaseType mongodb,
    devDatabaseType mongodb,
    cacheProvider no,
    enableHibernateCache false,
    buildTool gradle,
    serverPort 8082,
    skipUserManagement true
  }
  entities Notification
}
```

This application follows many options similar to the Gateway and Invoice application but instead of using MySQL, it uses **MongoDB** as its database and also disables cache.

Now that our application definitions are done, we will proceed to define our entity model.

For our Gateway store application, let us define the below entities and enums:

```java
/** Product sold by the Online store */
entity Product {
    name String required
    description String
    price BigDecimal required min(0)
    size Size required
    image ImageBlob
}

enum Size {
    S, M, L, XL, XXL
}

entity ProductCategory {
    name String required
    description String
}

entity Customer {
    firstName String required
    lastName String required
    gender Gender required
    email String required pattern(/^[^@s]+@[^@s]+.[^@s]+$/)
    phone String required
    addressLine1 String required
    addressLine2 String
    city String required
    country String required
}

enum Gender {
    MALE, FEMALE, OTHER
}

entity ProductOrder {
    placedDate Instant required
    status OrderStatus required
    code String required
    invoiceId Long
}

enum OrderStatus {
    COMPLETED, PENDING, CANCELLED
}

entity OrderItem {
    quantity Integer required min(0)
    totalPrice BigDecimal required min(0)
    status OrderItemStatus required
}

enum OrderItemStatus {
    AVAILABLE, OUT_OF_STOCK, BACK_ORDER
}

relationship OneToOne {
    Customer{user(login) required} to User
}

relationship ManyToOne {
    OrderItem{product(name) required} to Product
}

relationship OneToMany {
    Customer{order} to ProductOrder{customer(email) required},
    ProductOrder{orderItem} to OrderItem{order(code) required},
    ProductCategory{product} to Product{productCategory(name)}
}

service Product, ProductCategory, Customer, ProductOrder, OrderItem with serviceClass
paginate Product, Customer, ProductOrder, OrderItem with pagination
```

The JDL defines the entities, enums, the relationship between entities, and options like pagination and service layer.

Refer to the [JDL docs](https://www.jhipster.tech/jdl/) for the full DSL reference.

The Invoice microservice application has the following entities:

```java
entity Invoice {
    code String required
    date Instant required
    details String
    status InvoiceStatus required
    paymentMethod PaymentMethod required
    paymentDate Instant required
    paymentAmount BigDecimal required
}

enum InvoiceStatus {
    PAID, ISSUED, CANCELLED
}

entity Shipment {
    trackingCode String
    date Instant required
    details String
}

enum PaymentMethod {
    CREDIT_CARD, CASH_ON_DELIVERY, PAYPAL
}

relationship OneToMany {
    Invoice{shipment} to Shipment{invoice(code) required}
}

service Invoice, Shipment with serviceClass
paginate Invoice, Shipment with pagination
microservice Invoice, Shipment with invoice
```

The Notification microservice application has the following entities:

```java
entity Notification {
    date Instant required
    details String
    sentDate Instant required
    format NotificationType required
    userId Long required
    productId Long required
}

enum NotificationType {
    EMAIL, SMS, PARCEL
}

microservice Notification with notification
```

Now let us go back to the entities keyword we used in our application definitions.

```java
application {
  config {
    ...
  }
  entities *
}

application {
  config {
    ...
  }
  entities Invoice, Shipment
}

application {
  config {
    ...
  }
  entities Notification
}

/* Entities for Store Gateway */
entity Product {
    ...
}
entity ProductCategory {
    ...
}
entity Customer {
    ...
}
entity ProductOrder {
    ...
}
entity OrderItem {
    ...
}

/** microservice Invoice, Shipment _with_ invoice */

/* Entities for Invoice microservice */
entity Invoice {
    ...
}
entity Shipment {
    ...
}

/* Entities for notification microservice */
entity Notification {
    ...
}

/** microservice Notification _with_ notification */
```

Here we instruct the store gateway application that it should contain all the entities defined in the JDL and the gateway will know to skip server-side code for the entities that belong to another microservice and hence will only generate the client-side code for those, here namely **Invoice**, **Shipment**, and **Notification**. We also instruct the Invoice application and Notification application to include its entities.

## Generating the Applications

Create a folder where we want to create our microservice stack.

```shell
$ mkdir ecommerce && cd ecommerce
```

Now, let us put everything together into a JDL file. Let us call it `app.jdl` and save it into this folder.

```java
application {
  config {
    baseName store,
    applicationType gateway,
    packageName com.jhipster.demo.store,
    serviceDiscoveryType eureka,
    authenticationType jwt,
    prodDatabaseType mysql,
    cacheProvider hazelcast,
    buildTool gradle,
    clientFramework react,
    useSass true,
    testFrameworks [protractor]
  }
  entities *
}

application {
  config {
    baseName invoice,
    applicationType microservice,
    packageName com.jhipster.demo.invoice,
    serviceDiscoveryType eureka,
    authenticationType jwt,
    prodDatabaseType mysql,
    buildTool gradle,
    serverPort 8081,
    skipUserManagement true
  }
  entities Invoice, Shipment
}

application {
  config {
    baseName notification,
    applicationType microservice,
    packageName com.jhipster.demo.notification,
    serviceDiscoveryType eureka,
    authenticationType jwt,
    databaseType mongodb,
    prodDatabaseType mongodb,
    devDatabaseType mongodb,
    cacheProvider no,
    enableHibernateCache false,
    buildTool gradle,
    serverPort 8082,
    skipUserManagement true
  }
  entities Notification
}

/* Entities for Store Gateway */
/** Product sold by the Online store */
entity Product {
    name String required
    description String
    price BigDecimal required min(0)
    size Size required
    image ImageBlob
}

enum Size {
    S, M, L, XL, XXL
}

entity ProductCategory {
    name String required
    description String
}

entity Customer {
    firstName String required
    lastName String required
    gender Gender required
    email String required pattern(/^[^@s]+@[^@s]+.[^@s]+$/)
    phone String required
    addressLine1 String required
    addressLine2 String
    city String required
    country String required
}

enum Gender {
    MALE, FEMALE, OTHER
}

entity ProductOrder {
    placedDate Instant required
    status OrderStatus required
    code String required
    invoiceId Long
}

enum OrderStatus {
    COMPLETED, PENDING, CANCELLED
}

entity OrderItem {
    quantity Integer required min(0)
    totalPrice BigDecimal required min(0)
    status OrderItemStatus required
}

enum OrderItemStatus {
    AVAILABLE, OUT_OF_STOCK, BACK_ORDER
}

relationship OneToOne {
    Customer{user(login) required} to User
}

relationship ManyToOne {
    OrderItem{product(name) required} to Product
}

relationship OneToMany {
    Customer{order} to ProductOrder{customer(email) required},
    ProductOrder{orderItem} to OrderItem{order(code) required},
    ProductCategory{product} to Product{productCategory(name)}
}

service Product, ProductCategory, Customer, ProductOrder, OrderItem with serviceClass
paginate Product, Customer, ProductOrder, OrderItem with pagination

/* Entities for Invoice microservice */
entity Invoice {
    code String required
    date Instant required
    details String
    status InvoiceStatus required
    paymentMethod PaymentMethod required
    paymentDate Instant required
    paymentAmount BigDecimal required
}

enum InvoiceStatus {
    PAID, ISSUED, CANCELLED
}

entity Shipment {
    trackingCode String
    date Instant required
    details String
}

enum PaymentMethod {
    CREDIT_CARD, CASH_ON_DELIVERY, PAYPAL
}

relationship OneToMany {
    Invoice{shipment} to Shipment{invoice(code) required}
}

service Invoice, Shipment with serviceClass
paginate Invoice, Shipment with pagination
microservice Invoice, Shipment with invoice

/* Entities for notification microservice */
entity Notification {
    date Instant required
    details String
    sentDate Instant required
    format NotificationType required
    userId Long required
    productId Long required
}

enum NotificationType {
    EMAIL, SMS, PARCEL
}

microservice Notification with notification
```

Now let us invoke JHipster CLI to import this file:

```shell
$ jhipster import-jdl app.jdl
```

This will create the **store**, **invoice**, and **notification** folders and will do the following in each of the folders:

- Generate the appropriate application and entities configuration.
- Generate the application and entities source code based on the configurations.
- Install the NPM dependencies for the application.

Once the process is complete, you should see the below on your console:

```shell
Entity Product generated successfully.
Entity ProductCategory generated successfully.
Entity Customer generated successfully.
Entity ProductOrder generated successfully.
Entity OrderItem generated successfully.
Entity Invoice generated successfully.
Entity Shipment generated successfully.
Entity Notification generated successfully.
```

**Congratulations, JHipster execution is complete!**

Walk around the generated code to familiarize yourself.

### Running the Applications with Docker

Now that our applications are created, it’s time to test them locally using Docker. To do this, first let us generate some Docker Compose configurations using JHipster.

Create a new folder inside the **ecommerce** folder and run the JHipster Docker Compose command:

```shell
$ mkdir docker-compose && cd docker-compose
$ jhipster docker-compose
```

It will prompt you with a few questions. Choose the answers as highlighted below:

```shell
🐳  Welcome to the JHipster Docker Compose Sub-Generator 🐳
Files will be generated in folder: /home/deepu/workspace/temp/ecommerce/docker-compose
✔ Docker is installed? Which *type* of application would you like to deploy? Microservice application
✔ Which *type* of gateway would you like to use? JHipster gateway based on Netflix Zuul
✔ Enter the root directory where your gateway(s) and microservices are located ../
✔ 3 applications found at /home/deepu/workspace/temp/ecommerce/
✔ Which applications do you want to include in your configuration? invoice, notification, store
✔ Which applications do you want to use with clustered databases (only available with MongoDB and Couchbase)?
✔ Do you want to setup monitoring for your applications? Yes, for logs and metrics with the JHipster Console (based on ELK and Zipkin)
✔ You have selected the JHipster Console which is based on the ELK stack and additional technologies. Which one do you want to use? Zipkin, for distributed tracing (only compatible with JHipster >= v4.2.0)
✔ JHipster registry detected as the service discovery and configuration provider used by your apps
✔ Enter the admin password used to secure the JHipster Registry admin
```

This will generate all the required Docker Compose configurations for the stack and will also print out further instructions to build the Docker images.

**Note:** In the latest JHipster versions, we migrated to using [Jib](https://github.com/GoogleContainerTools/jib) for creating Docker images. This is a huge improvement over the Docker Maven plugin that we were using. As a result, the command to create an image has changed to:

```shell
./gradlew -Pprod bootWar jibDockerBuild
```

Docker Compose configuration generated with missing images! To generate the missing Docker image(s), please run:

```shell
./gradlew -Pprod bootWar buildDocker
```

Follow the instructions and build the Docker images. Once all 3 images are built, run the below command from the **docker-compose** folder to fire everything up:

```shell
$ docker-compose up -d
```

Once the containers start, you can stream the logs using the below command:

```shell
$ docker-compose logs -f
```

Now point your favorite browser to [http://localhost:8080/](http://localhost:8080/) and see the E-Commerce microservice application in action.

![Gateway application (Store)](https://miro.medium.com/v2/resize:fit:875/1*NR3QX_Q88_a4cWJ9X3fcnw.png)

You can see the JHipster registry in action at [http://localhost:8761/](http://localhost:8761/#/).

![JHipster Registry](https://miro.medium.com/v2/resize:fit:875/1*F-MV1Q_jsBvUHHeInJR8TA.png)

And finally, the JHipster console at [http://localhost:5601](http://localhost:5601/).

![JHipster Console - Kibana dashboard](https://miro.medium.com/v2/resize:fit:875/1*v2tJsdLIJcVwm7RDAI_YVg.png)

Once you are done playing around, you can shut everything down by running the below command on the **docker-compose** folder:

```shell
$ docker-compose down
```

Hope you had fun creating microservices using JHipster. To learn how to convert a JHipster monolith to microservices, check out my book **Full Stack Development with JHipster** on [Amazon](https://www.amazon.com/Stack-Development-JHipster-Deepu-Sasidharan/dp/178847631X) and [Packt](https://www.packtpub.com/application-development/full-stack-development-jhipster).

In the coming weeks, I’ll write some posts about deploying this microservice stack to various cloud providers like GCP, Azure, AWS, Heroku, and so on.

If you like JHipster, don't forget to give it a star on [GitHub](https://github.com/jhipster/generator-jhipster).

If you like this article, please leave some claps (Did you know that you can clap multiple times? :P).

You can follow me on [Twitter](https://twitter.com/deepu105) and [LinkedIn](https://www.linkedin.com/in/deepu05/).

My other related posts:

1. [Deploying JHipster Microservices on Azure Kubernetes Service (AKS)](/@deepu105/deploying-jhipster-microservices-on-azure-kubernetes-service-aks-fb46991746ba)
2. [JHipster microservices with Istio service mesh on Kubernetes](/@deepu105/jhipster-microservices-with-istio-service-mesh-on-kubernetes-a7d0158ba9a3)

---

# Introducing JHipster: Streamlining Web Application Development

> **JHipster can generate a web application or microservice, including the frontend (Angular, React, or Vue.js), backend (Java Spring Boot), security, and DevOps integration.**

Building modern web applications and microservices can be complex and time-consuming, but JHipster aims to simplify this task. JHipster is an open-source development platform that helps developers create Java-based applications quickly and efficiently.

One of the key features of JHipster is its application generation capabilities. Developers can use the command-line interface (CLI) to quickly generate a fully functional web application or microservice, including the frontend (Angular, React, or Vue.js) and backend (Java Spring Boot).

JHipster also supports the creation of microservice-based architectures, with built-in support for service discovery, load balancing, and distributed configuration management. This makes it easier to build and manage complex, scalable applications.

Another notable feature of JHipster is its database integration. It supports various database technologies, including SQL (e.g., PostgreSQL, MySQL, Oracle) and NoSQL (e.g., MongoDB, Cassandra). Developers can easily configure the database connection and schema for their applications.

JHipster also emphasizes security, with built-in support for authentication and authorization using technologies like Spring Security, **OAuth 2.0, and JSON Web Tokens (JWT)**. This helps ensure that your applications are secure and compliant with industry standards.

Finally, JHipster provides seamless DevOps integration, allowing developers to easily integrate with popular tools like Docker, Kubernetes, and Travis CI. This makes it easier to build, package, and deploy applications, streamlining the entire development lifecycle.

---

### Installation

To install JHipster, you’ll need the following prerequisites:

- **Java 8 or higher**
- **Node.js 12 or higher**
- **Yarn or npm** (npm is installed with Node.js)

Install JHipster globally:

```shell
npm install -g generator-jhipster
```

---

### Creating a New Application

To create a new JHipster application, run:

```shell
jhipster
```

This will start the JHipster application generator and prompt you with a series of questions about the type of application you want to create, the technologies you want to use, and other configuration options.

After answering the questions, JHipster will generate the necessary files and configurations for your application.

---

### Running the Application

Navigate to your project directory and start the development server:

```shell
cd my-app
./gradlew
```

This will start the development server and allow you to access your application at [http://localhost:8080](http://localhost:8080).

---

### Creating a New Entity

Once you have generated your application, you can use JHipster to create new entities (e.g., database tables). For example, to create a new `Product` entity, run:

```shell
jhipster entity Product
```

This will generate the necessary files and code for the `Product` entity, including the database model, REST API, and user interface components.

---

### Customizing the Generated Code

JHipster generates a lot of boilerplate code, but you can customize this code as needed. For example, you can modify the database model for the `Product` entity by editing the generated JSON file:

```json
{
  "name": "Product",
  "fields": [
    { "fieldName": "name", "fieldType": "String" },
    { "fieldName": "description", "fieldType": "String" },
    { "fieldName": "price", "fieldType": "Double" }
  ]
}
```

You can then regenerate the code for the `Product` entity:

```shell
jhipster entity Product
```

---

### Integrating with DevOps Tools

JHipster also provides integration with popular DevOps tools, such as Docker and Kubernetes. For example, to generate Docker configuration files for your application, run:

```shell
jhipster docker-compose
```

This will generate the necessary Docker Compose and Kubernetes configuration files, making it easier to package and deploy your application.

---

Overall, these examples demonstrate the powerful features and capabilities of JHipster, which can help developers quickly and efficiently build modern web applications and microservices.

---
# Build a Spring Boot Microservices Project with JHipster in 10 Minutes

### Introduction

Spring Boot is an excellent framework for building REST APIs. It’s easy to use and abstracts many of the complex aspects of development. Developers can quickly get started with Spring Boot applications by using [Spring Initializer](https://start.spring.io/). However, creating a microservices architecture with Spring Boot requires significant effort, which is where JHipster comes in. JHipster helps you rapidly bootstrap a Spring Boot microservices project.

In this blog, I will outline the steps I took to create a gateway microservice with two additional business microservices. For this proof of concept, I chose to use PostgreSQL as the database and Maven as the build tool.

---

### Downloading JHipster

First, download the latest version of JHipster (v8.3.0 as of 04/23/2024) from the [JHipster release page](https://www.jhipster.tech/releases/). JHipster offers two methods for generating a Spring Boot project: [JHipster Online](https://start.jhipster.tech/) and npm. For this proof of concept, I used npm on macOS.

---

### Generating Projects

While generating projects, I selected the following core components:

- **Service discovery:** [Consul](https://www.consul.io/)
- **Build tool:** Apache Maven
- **Database:** Postgres

I created all projects within a root folder called `micro-services-seed`. Each project was generated into its own folder: `gateway`, `biz-service1`, and `biz-service2`.

To create the gateway project, I navigated to the Terminal and ran:

```shell
jhipster
```

inside the `gateway` folder. The tool presented several questions regarding the gateway project. For my proof of concept, I answered as follows:

![Gateway Setup](https://miro.medium.com/v2/resize:fit:875/0*qXDWiA148dLbMA1M)

After successfully generating the project, I verified that it would build without errors by running:

```shell
mvn clean install
```

During the build, I faced a permissions error related to npm, which I resolved by following the instructions recommended by npm.

Next, to generate the `biz-service1` project, I navigated to the `biz-service1` folder in the terminal, ran the `jhipster` command, and answered the following questions:

![Biz Service 1 Setup](https://miro.medium.com/v2/resize:fit:875/0*4pBlIhXSXUfjHkXc)

I followed the same steps to generate the `biz-service2` microservice. Once the projects were generated successfully, I confirmed that they would build without issues by running:

```shell
mvn clean install
```

---

### Running Projects

Before running each project, I started Consul and ElasticSearch services using Docker. When generating the gateway project, JHipster created Docker files for both services, which can be launched using the following commands:

```shell
docker-compose -f src/main/docker/consul.yml up
docker-compose -f src/main/docker/elasticsearch.yml up
```

I downloaded Docker from [Docker’s official website](https://docs.docker.com/desktop/install/mac-install/).

Next, I set up the PostgreSQL database. I created three schemas in the default PostgreSQL database and named them `gateway`, `biz_service_one`, and `biz_service_two`. I also verified that the `application-dev.yml` files in all projects contain the correct JDBC URLs for the data source and Liquibase configurations.

![Postgres Setup](https://miro.medium.com/v2/resize:fit:710/0*1fnvd3wzqdvMxJ_m)

Next, I opened three different terminal tabs for each project and ran:

```shell
./mvnw
```

in each project’s root folder. Once all projects started successfully, I saw the following output in the terminal window:

**Gateway project:**

![Gateway Running](https://miro.medium.com/v2/resize:fit:875/0*rRhzD-vPdUOsEnVA)

**Biz-service1 project:**

![Biz-service1 Running](https://miro.medium.com/v2/resize:fit:875/0*UvzTaB4U4Wl0jrV5)

**Biz-service2 project:**

![Biz-service2 Running](https://miro.medium.com/v2/resize:fit:875/0*qAxIiEOipNniJM4m)

As demonstrated in the terminal, all microservices are also connected to the Consul server. I confirmed this connection by checking the Consul UI locally at [http://localhost:8500/ui/](http://localhost:8500/ui/).

![Consul UI](https://miro.medium.com/v2/resize:fit:875/0*DaUPo0lXDo_xoFAy)

I also successfully added multiple instances of bizservice1, each running on a different port, using the Maven command:

```shell
./mvnw -Dspring-boot.run.jvmArguments='-Dserver.port=8082'
```

As expected, Consul UI displayed two instances of bizservice1.

![Multiple Instances](https://miro.medium.com/v2/resize:fit:875/0*BNK5M_DY09nreTRk)

---

### Validating Services

To validate the setup, I used Postman. As the projects were generated with JWT token-based authentication, all REST API calls are protected and can only be accessed with an Authorization header containing a Bearer token. To generate a token, I accessed the authentication gateway endpoint at:

```
POST http://localhost:8080/api/authenticate
```

and provided the username and password in the request body as shown below.

![JWT Auth](https://miro.medium.com/v2/resize:fit:875/0*4R0VoG0j4hVvvJR1)

> Note: The default username and password for a JHipster-generated gateway project is `admin/admin`.

After obtaining the token, I tested the `/health` management endpoint from each business microservice via the gateway. Spring Boot management endpoints are automatically enabled by JHipster.

I was able to access the gateway’s `/health` endpoint directly at:

```
http://localhost:8080/management/health
```

To route requests to individual microservices, JHipster includes a configuration in `application.yml` that requires `/services` in the URL.

```yaml
spring:
  application:
    name: gateway
  cloud:
    consul:
      discovery:
        healthCheckPath: /management/health
        instanceId: gateway:${spring.application.instance-id:${random.value}}
        service-name: gateway
      config:
        watch:
          enabled: false
    gateway:
      default-filters:
        - JWTRelay
      discovery:
        locator:
          enabled: true
          lower-case-service-id: true
          predicates:
            - name: Path
              args:
                pattern: "'/services/'+serviceId.toLowerCase()+'/**'"
          filters:
            - name: RewritePath
              args:
                regexp: "'/services/' + serviceId.toLowerCase() + '/(?<remaining>.*)'"
                replacement: "'/${remaining}'"
```

To access the `/health` endpoint of `bizservice1`, use:

```
http://localhost:8080/services/bizservice1/management/health
```

with the required Authorization header. You should receive a response from the `bizservice1` microservice.

![Health Endpoint](https://miro.medium.com/v2/resize:fit:875/0*hnMZaZMODlKwKahY)

---

### Wrapping Up

JHipster’s popularity in the Spring framework community is well-deserved. In just 10 minutes, I was able to generate all the necessary Spring Boot projects with the essential cross-cutting concerns already integrated. All the project sources are available on my GitHub page:

[https://github.com/savi-technologies/micro-services-seed](https://github.com/savi-technologies/micro-services-seed)

Thank you for reading! 🙏 🙏

---
# Creating a Simple Microservice Application with JHipster

### Prerequisites

- **Java** (recommended: Java 11)
- **Node.js** (recommended: 16.20.0)
- **JHipster** (recommended: 6.4.0)

Install JHipster globally:

```shell
npm install -g generator-jhipster@6.4.0
```

---

### Why JHipster?

JHipster significantly enhances productivity by automating various aspects of microservices development. It generates boilerplate code, project structure, and configuration files, saving developers time and effort. This allows you to quickly get started with building microservices and focus on implementing business logic. Within seconds, you can develop a gateway and microservices with centralized configuration, security, and monitoring capabilities.

---

### Architecture

![JHipster Microservices Architecture](https://miro.medium.com/v2/resize:fit:875/1*YaWGF-rnLDO_HAKximc3eQ.png)

---

### Components

1. **JHipster Registry**
2. **Gateway**
3. **Service Components (Microservices)**

---

### JHipster Registry

The JHipster Registry is a runtime application provided by the JHipster team. It serves three main purposes:

- **Eureka server:** Provides service discovery for applications, maintaining and distributing a dynamic list of available application instances for HTTP request routing and load balancing.
- **Spring Cloud Config Server:** Provides runtime configuration to all applications.
- **Administration server:** Offers dashboards to monitor and manage applications.

---

### Gateway

Using JHipster, you can generate API gateways with the following features:

- **Request routing:** Routes incoming requests to the appropriate microservice based on URL, headers, or other parameters.
- **Load balancing:** Distributes requests across multiple instances of the same microservice.
- **Authentication and authorization:** Handles authentication and authorization for the entire microservices system.
- **Caching:** Implements caching mechanisms to improve response times and reduce load.
- **Monitoring and logging:** Collects and analyzes data about requests, response times, errors, and more.
- **Automatic documentation:** Exposes Swagger API definitions for all proxied services, enabling tools like Swagger UI and swagger-codegen.

By providing these functionalities, a gateway promotes loose coupling and enhances scalability, security, and manageability.

---

### Implementation

### Running JHipster Registry Locally

Clone the project:

```shell
git clone https://github.com/jhipster/jhipster-registry.git
cd jhipster-registry
./mvnw
```

Once started, access the registry at [http://localhost:8761/](http://localhost:8761/#/) and log in with `admin/admin`.

---

### Creating Gateway Application

1. Create a folder named `Gateway` and open a terminal in that folder.
2. Run:
   ```shell
   jhipster
   ```
3. Select **Microservice gateway** as the application type.

![Gateway Creation](https://miro.medium.com/v2/resize:fit:875/1*AR2nW284mXi5cGnzAiopvw.png)

4. Select other options as needed (see sample below):

![Gateway Options](https://miro.medium.com/v2/resize:fit:875/1*TudzbCy2mm2twj3d_aDrXw.png)

---

### Creating Microservice Application

1. Create a folder named `Microservice1` and open a terminal in that folder.
2. Run:
   ```shell
   jhipster
   ```
3. Select **Microservice application** as the application type.

![Microservice Creation](https://miro.medium.com/v2/resize:fit:875/1*8J4_evCs-fJrtz3CiYpQ1Q.png)

4. Select other options as needed (see sample below):

![Microservice Options](https://miro.medium.com/v2/resize:fit:875/1*VaZfnJllaWLSO4AmOdyiAA.png)

---

In upcoming posts, I will cover how to use Spring Security for securing your application, Swagger documentation and its integration, and monitoring the application using the Elastic Stack.

---
# JHipster JDL To OpenAPI Generator

_Originally published at_ [_https://www.zenwave360.io_](https://www.zenwave360.io/posts/JHipster-As-IDL-for-OpenAPIv3/)_._

![JDL to OpenAPI](https://miro.medium.com/v2/resize:fit:875/1*3ui1XG59qSGKAaJyM-7zFA.png)

Writing YAML by hand is no fun, but you can simplify the process of writing OpenAPI definition files by using a Domain Specific Language (DSL).

[JHipster Domain Language (JDL)](https://www.jhipster.tech/jdl/intro) is a DSL used to define the domain model of a web application. With JDL, you can describe the entities, relationships, and constraints of your system in a concise and readable way.

[Zenwave SDK](https://zenwave360.github.io/zenwave-sdk/) is a set of tools to generate (and reverse engineer) code from JDL and API-First models like AsyncAPI and OpenAPI.

![Zenwave SDK Modeling](https://miro.medium.com/v2/resize:fit:875/1*7t2eeSXfrQmzokUxN1sz9w.png)

Thanks to ZenWave SDK, you can convert JDL models into OpenAPI definition files. This can save time and effort in the development process while ensuring that your APIs follow best practices and standards.

> **NOTE:** ZenWave SDK now uses its own Domain Language ([ZDL](https://www.zenwave360.io/docs/event-driven-design/zenwave-domain-language)), an extended superset of JHipster JDL. See this updated article: [Stop writing YAML for OpenAPI, use a compact DSL and save time and typing](https://medium.com/@ivangsa/stop-writing-yaml-for-openapi-use-a-compact-dsl-and-save-time-and-typing-574a138faddc)

---

### JDL Example

```java
@aggregate
entity Customer {
    username String required minlength(3) maxlength(250)
    password String required minlength(3) maxlength(250)
    email String required minlength(3) maxlength(250)
    firstName String required minlength(3) maxlength(250)
    lastName String required minlength(3) maxlength(250)
}
entity Address {
    street String
    city String
    country String
    zipCode String
}

relationship OneToOne {
    Customer{address} to Address{customer}
}

service Customer with serviceClass
```

---

### Generating OpenAPI Definition Files from JDL with ZenWave SDK

> _See_ [_JDL To OpenAPI Generator_](https://zenwave360.github.io/zenwave-sdk/plugins/jdl-to-openapi/) _for a complete list of options and the_ [_GitHub repository_](https://github.com/zenwave360/zenwave-sdk) _for install instructions._

ZenWave SDK will generate CRUD operations for your entities, including paginated lists and search operations.

Example command:

```shell
jbang zw -p io.zenwave360.sdk.plugins.ZDLToOpenAPIPlugin \
    specFile=entities-model.jdl \
    idType=integer \
    idTypeFormat=int64 \
    targetFolder=. \
    targetFile=openapi.yml
```

It will add `x-business-entity` and `x-business-entity-paginated` to generated schemas, which is very useful if you are also using ZenWave to [generate a complete backend](https://zenwave360.github.io/zenwave-sdk/) from JDL.

![ZenWave OpenAPI Output](https://miro.medium.com/v2/resize:fit:875/1*ozKHlKDOfikvJ6nCin08XA.png)

---

### Summary

By using JDL to define your domain model and ZenWave SDK to convert it into an OpenAPI definition file, you can simplify the process of designing and documenting your APIs. This can improve the overall quality and consistency of your APIs, while also reducing errors and inconsistencies.

Overall, using JDL and ZenWave SDK provides a streamlined and efficient way to implement Domain Driven Design principles in event-driven applications, while also improving the efficiency and quality of the development process.

> **NOTE:** You can also use [ZenWave SDK to generate complete AsyncAPI definitions](/p/231e1b46f156) from JDL models.
> 
https://zenwave360.github.io/Domain-Driven-Design/JDL-Domain-Language/JHipster-As-IDL-for-OpenAPIv3

---
# JHipster JDL To AsyncAPI Generator

_Originally published at_ [_https://zenwave360.github.io_](https://zenwave360.github.io/Domain-Driven-Design/JDL-Domain-Language/JHipster-As-IDL-for-AsyncAPIv2)_._

![JDL to AsyncAPI](https://miro.medium.com/v2/resize:fit:875/1*fvuCrjollFubDeu3QGiZfg.png)

Writing YAML by hand is no fun, but you can simplify the process of writing AsyncAPI definition files by using a Domain Specific Language (DSL).

[JHipster Domain Language (JDL)](https://www.jhipster.tech/jdl/intro) is a DSL used to define the domain model of a web application. With JDL, you can describe the entities, relationships, and constraints of your system in a concise and readable way.

[Zenwave SDK](https://zenwave360.github.io/zenwave-sdk/) is a set of tools to generate (and reverse engineer) code from JDL and API-First models like AsyncAPI and OpenAPI.

![Zenwave SDK Modeling](https://miro.medium.com/v2/resize:fit:875/1*7t2eeSXfrQmzokUxN1sz9w.png)

Thanks to ZenWave SDK, you can convert JDL models into AsyncAPI definition files. This can save time and effort in the development process while ensuring that your APIs follow best practices and standards.

---

### JDL Example

```java
@aggregate
entity Customer {
    username String required minlength(3) maxlength(250)
    password String required minlength(3) maxlength(250)
    email String required minlength(3) maxlength(250)
    firstName String required minlength(3) maxlength(250)
    lastName String required minlength(3) maxlength(250)
}
entity Address {
    street String
    city String
    country String
    zipCode String
}

relationship OneToOne {
    Customer{address} to Address{customer}
}
```

---

### Generating AsyncAPI Definition Files from JDL with ZenWave SDK

> _See_ [_JDL To AsyncAPI Generator_](https://zenwave360.github.io/zenwave-sdk/plugins/jdl-to-asyncapi/) _for a complete list of options and the_ [_GitHub repository_](https://github.com/zenwave360/zenwave-sdk) _for install instructions._

Because JDL can only describe static aspects of your models and doesn’t cover dynamic behaviour, ZenWave SDK can only infer CRUD operations from your entities, generating:

- **One channel for each entity** for both publishing Domain Events and subscribing to Commands/Requests.
- **Messages and payloads** for each entity Create/Update/Delete event (AVRO and AsyncAPI schema)

Example command:

```shell
jbang zw -p io.zenwave360.sdk.plugins.JDLToAsyncAPIPlugin \
    includeCommands=false \
    specFile=src/main/resources/model/entities-model.jdl \
    idType=integer \
    idTypeFormat=int64 \
    annotations=aggregate \
    payloadStyle=event \
    targetFile=src/main/resources/model/asyncapi.yml
```

You can choose to **generate only Events or Commands** using `includeEvents` (default: true) and `includeCommands` (default: false) to filter which channels you want to include in your AsyncAPI definition file.

You can also **filter which entities you want to include** using: `entities`, `skipEntities`, `annotations`, and `skipForAnnotations`.

---

**UPDATE:**

As of ZenWave SDK version 1.0.6, it now supports generating AsyncAPI v3 format. Use `asyncapiVersion=v3` like:

```shell
jbang zw -p io.zenwave360.sdk.plugins.JDLToAsyncAPIPlugin \
    includeCommands=false \
    specFile=src/main/resources/model/entities-model.jdl \
    idType=integer \
    idTypeFormat=int64 \
    annotations=aggregate \
    payloadStyle=event \
    asyncapiVersion=v3 \
    targetFile=src/main/resources/model/asyncapi.yml
```

![AsyncAPI v3](https://miro.medium.com/v2/resize:fit:875/1*tuuGXO47RMI8OgYp-nv63g.png)

---

### Supported Schema Formats and Message Styles

You can generate AsyncAPI definition files with the following options:

- **Supported Schema Formats:** AVRO and AsyncAPI schema
- **Supported [Payload Styles](https://zenwave360.github.io/Event-Driven-Architectures/API-First-with-AsyncAPI#different-styles-of-message-payloads):** “Entity State Transfer” and “Domain Event” (for Create/Update/Delete events)

> **Entity State Transfer** messages contain the **entire state of the aggregate** so the consumer does not need to make additional calls.
>
> **Domain Event Messages** contain information about the event and **interesting portions of the underlying aggregate**, but not the entire state.

---

### Summary

By using JDL to define your domain model and ZenWave SDK to convert it into an AsyncAPI definition file, you can simplify the process of designing and documenting your APIs. This can improve the overall quality and consistency of your APIs, while also reducing errors and inconsistencies.

Overall, using JDL and ZenWave SDK provides a streamlined and efficient way to implement Domain Driven Design principles in event-driven applications, while also improving the efficiency and quality of the development process.

**NOTE:** You can also use [ZenWave SDK to generate complete OpenAPI definitions](/p/420393cbd40a) from JDL models.

_Originally published at_ [_https://zenwave360.github.io_](https://zenwave360.github.io/Domain-Driven-Design/JDL-Domain-Language/JHipster-As-IDL-for-AsyncAPIv2)_._

---
# Generate a Quarkus Project with JHipster

For a long time, JHipster used Spring for all backend logic. Once I started working with Quarkus, I always thought it would be great to generate a Quarkus project with JHipster—and now we finally can!

In this article, I’ll show you how to generate a new JHipster Quarkus project with an Angular frontend and complex entity logic (relationships, pagination, security) in just a few minutes. I’ll also guide you through the project structure.

> This article is also available on the [Quarkify website](https://quarkify.net/generate-quarkus-project-with-jhipster/)

---

### Installing the Quarkus Blueprint

First, install JHipster’s Quarkus blueprint:

```shell
npm install -g generator-jhipster-quarkus
```

To update to the latest version:

```shell
npm update -g generator-jhipster-quarkus
```

### If You Don’t Have JHipster

Install JHipster itself:

```shell
npm install -g generator-jhipster
```

---

### Generate a JHipster Project

As with any other JHipster project:

```shell
jhipster --blueprints quarkus
```

You’ll see info messages like below:

![JHipster Quarkus CLI](https://miro.medium.com/v2/resize:fit:875/0*5706tYluSer9T6vWz.png)

At the end, you’ll be prompted for some information (gray means default value):

![Project Name](https://miro.medium.com/v2/resize:fit:875/0*lDLYFoL2ER3tclpM.png)

For example, use `quarkify_jhipster` as the project name, and `net.quarkify.jhipster` as the package name.

![Package Name](https://miro.medium.com/v2/resize:fit:875/0*ZWfnCD1Ivm8FEqtE.png)

Specify the **production** database type (e.g., SQL or none). For this example, use PostgreSQL.

![Database Type](https://miro.medium.com/v2/resize:fit:875/0*PHgggejuemHpkFH4.png)

For the **development** database, use `H2 with disk-based persistency` (or in-memory).

![Dev Database](https://miro.medium.com/v2/resize:fit:875/0*xFzQgckrU6FONBzE.png)

Choose the frontend framework (e.g., Angular):

![Frontend Framework](https://miro.medium.com/v2/resize:fit:875/0*YHXt3uiRJPcEqSHF.png)

Select a Bootstrap theme if desired (e.g., `darkly` with `primary` navbar):

![Bootstrap Theme](https://miro.medium.com/v2/resize:fit:875/0*wnLy6QpSfuIkcDSc.png)

![Theme Selection](https://miro.medium.com/v2/resize:fit:875/0*E0LYzaK-MEhUHOVx.png)

![Theme Confirmation](https://miro.medium.com/v2/resize:fit:875/0*gEBlk5qwMdjZCOg8.png)

Choose whether to enable internationalization (Y/n):

![i18n](https://miro.medium.com/v2/resize:fit:875/0*VGEaEazlfqNuRvH0.png)

JHipster will now generate and install all required dependencies.

---

### Running the App

To verify it’s running:

```shell
./mvnw
```

This will build the frontend and serve both frontend and backend. Visit [http://localhost:8080](http://localhost:8080) to see the result.

### Frontend Development Environment

To start the development server:

```shell
npm start
```

Visit [http://localhost:9000](http://localhost:9000). The page will auto-refresh on changes.

To build a static website to be served from Quarkus:

```shell
./mvnw clean compile
```

Login as `admin`/`admin` for admin features (some features may not work).

---

### Using JDL to Generate Logic

JHipster wouldn’t be JHipster without JDL ([JHipster Domain Language](https://www.jhipster.tech/jdl/)). JDL lets you describe entities and relationships, saving hours of development time.

- Copy a schema from [this gist](https://gist.github.com/dmi3coder/a0cca9e0f7e276dbd29be8ad252b7e68) and save as `schema.jh` in your project root.
- Import it with:

```shell
jhipster --blueprints quarkus import-jdl schema.jh
```

If prompted with a conflict, enter `a` to accept all. For new empty applications, this is safe.

---

### Verify JDL Import Result

After import, build and start the server:

```shell
./mvnw clean compile
./mvnw
```

Check the `Entities` section in the UI to see the new logic. You’ll see paginated lists and forms with relationships (e.g., Job to Task, Employee).

---

### Generated Project Structure

- `/config` — constants, JSONB config, security, mail properties
- `/domain` — domain logic (entities, enums)
- `/security` — security logic (JWT, etc.)
- `/service` — service interfaces and implementations, DTOs, mappers
- `/web/rest` — REST resources
- `/config/liquibase` — database migrations
- `/jwt/privateKey.pem` and `/META-INF/resources/publicKey.pem` — JWT keys
- `/mail/templates` — email templates
- `/resources` — includes preconfigured `application.properties`
- `/webapp` — frontend app (React or Angular, uses TypeScript)
- `/docker` — Dockerfiles and docker-compose files for various scenarios

---

### Conclusion

JHipster now supports generating Quarkus apps. Even if you don’t use it directly, the generated code contains many good patterns for future projects. It’s a great template to bootstrap your project, but you’ll still need to make changes for your needs.

_Originally published at_ [_https://quarkify.net_](https://quarkify.net/generate-quarkus-project-with-jhipster/) _on May 22, 2020._

---
# How to Set Up JHipster Microservices with Istio Service Mesh on Kubernetes

You can find a more up-to-date version of this post that uses JHipster 6 and the latest Istio & Kubernetes versions [here](https://dev.to/deepu105/how-to-set-up-java-microservices-with-istio-service-mesh-on-kubernetes-5bkn).

Istio is the coolest kid on the DevOps and Cloud block now. For those of you who aren’t following close enough — [Istio is a service mesh](https://istio.io/docs/concepts/what-is-istio/) for distributed application architectures, especially the ones that you run on the cloud with Kubernetes. Istio plays extremely nice with Kubernetes, so nice that you might think that it’s part of Kubernetes.

### Overview of Istio

Istio provides the following functionality in a distributed application architecture:

- Service discovery
- Automatic load balancing
- Routing, circuit breaking, retries, fail-overs, fault injection
- Policy enforcement for access control, rate limiting, A/B testing, traffic splits, and quotas
- Metrics, logs, and traces
- Secure service-to-service communication

Below is the architecture of Istio:

![Istio Architecture](https://miro.medium.com/v2/resize:fit:1250/1*_STCerKXb4L3Hutyn4P5Gw.png)

### Data Plane

Made of [Envoy](https://www.envoyproxy.io/) proxies deployed as sidecars to the application containers. They control all the incoming and outgoing traffic to the container.

### Control Plane

Uses Pilot to manage and configure the proxies to route traffic. It also configures Mixer to enforce policies and collect telemetry. Other components include Citadel (security) and Galley (configuration).

Istio also configures [Grafana](https://grafana.com/), [Prometheus](https://prometheus.io/), and [Jaeger](https://www.jaegertracing.io/) for monitoring and observability.

### Preparing the Kubernetes Cluster

### Prerequisites

Install [**kubectl**](https://kubernetes.io/docs/tasks/tools/install-kubectl/) to interact with Kubernetes.

### Create a Cluster on Azure Kubernetes Service (AKS)

```shell
$ az group create --name eCommerceCluster --location eastus
$ az aks create --resource-group eCommerceCluster --name eCommerceCluster --node-count 4 --kubernetes-version 1.11.4 --enable-addons monitoring --generate-ssh-keys
$ az aks get-credentials --resource-group eCommerceCluster --name eCommerceCluster
```

### Create a Cluster on Google Kubernetes Engine (GKE)

Install [**Gcloud CLI**](https://cloud.google.com/sdk/docs/) and log in with your GCP account.

```shell
$ gcloud projects create jhipster-demo-deepu
$ gcloud config set project jhipster-demo-deepu
$ gcloud container clusters create hello-hipster --cluster-version 1.10 --num-nodes 4 --machine-type n1-standard-2
$ gcloud container clusters get-credentials hello-hipster
```

### Install and Set Up Istio

Install Istio:

```shell
$ export ISTIO_VERSION=1.0.2
$ curl -L https://git.io/getLatestIstio | sh -
$ ln -sf istio-$ISTIO_VERSION istio
$ export PATH=~/istio/bin:$PATH
```

Apply Istio manifests:

```shell
$ kubectl apply -f ~/istio/install/kubernetes/helm/istio/templates/crds.yaml
$ kubectl apply -f ~/istio/install/kubernetes/istio-demo.yaml --as=admin --as-group=system:masters
$ watch kubectl get pods -n istio-system
```

### Creating the Microservice Application Stack

### Architecture

![Microservice Architecture with Istio](https://miro.medium.com/v2/resize:fit:1250/1*UmNJ-Ue362-OltPOxt-OFQ.png)

### Application JDL

```java
application {
  config {
    baseName store
    applicationType gateway
    packageName com.jhipster.demo.store
    serviceDiscoveryType no
    authenticationType jwt
    prodDatabaseType mysql
    cacheProvider hazelcast
    buildTool gradle
    clientFramework react
  }
  entities *
}

application {
  config {
    baseName product
    applicationType microservice
    packageName com.jhipster.demo.product
    serviceDiscoveryType no
    authenticationType jwt
    prodDatabaseType mysql
    cacheProvider hazelcast
    buildTool gradle
    serverPort 8081
  }
  entities Product, ProductCategory, ProductOrder, OrderItem
}

application {
  config {
    baseName invoice
    applicationType microservice
    packageName com.jhipster.demo.invoice
    serviceDiscoveryType no
    authenticationType jwt
    prodDatabaseType mysql
    buildTool gradle
    serverPort 8082
  }
  entities Invoice, Shipment
}

application {
  config {
    baseName notification
    applicationType microservice
    packageName com.jhipster.demo.notification
    serviceDiscoveryType no
    authenticationType jwt
    databaseType mongodb
    cacheProvider no
    enableHibernateCache false
    buildTool gradle
    serverPort 8083
  }
  entities Notification
}
```

### Deployment JDL

```java
deployment {
  deploymentType kubernetes
  appsFolders [store, invoice, notification, product]
  dockerRepositoryName "deepu105"
  serviceDiscoveryType no
  istio true
  kubernetesServiceType Ingress
  kubernetesNamespace jhipster
  ingressDomain "146.148.30.85.nip.io"
}
```

### Deploy to Kubernetes Cluster

Build and push Docker images:

```shell
$ ./gradlew bootWar -Pprod jibDockerBuild
$ docker image tag store deepu105/store
$ docker push deepu105/store
```

Deploy applications:

```shell
$ cd kubernetes
$ ./kubectl-apply.sh
```

Monitor pods:

```shell
$ watch kubectl get pods -n jhipster
```

### Monitoring and Observability

Set up port forwarding for Grafana:

```shell
$ kubectl -n istio-system port-forward $(kubectl -n istio-system get pod -l app=grafana -o jsonpath='{.items[0].metadata.name}') 3000:3000
```

Access Grafana at `localhost:3000`.

Set up port forwarding for Prometheus:

```shell
$ kubectl -n istio-system port-forward $(kubectl -n istio-system get pod -l app=prometheus -o jsonpath='{.items[0].metadata.name}') 9090:9090
```

Access Prometheus at `localhost:9090`.

Set up port forwarding for Jaeger:

```shell
$ kubectl -n istio-system port-forward $(kubectl -n istio-system get pod -l app=jaeger -o jsonpath='{.items[0].metadata.name}') 16686:16686
```

Access Jaeger at `localhost:16686`.

### Conclusion

Istio provides building blocks to build distributed microservices in a more Kubernetes-native way. JHipster provides a great Kubernetes setup to start with, which can be further tweaked as needed.

To learn more about JHipster and full-stack development, check out my book **Full Stack Development with JHipster** on [Amazon](https://www.amazon.com/Stack-Development-JHipster-Deepu-Sasidharan/dp/178847631X) and [Packt](https://www.packtpub.com/application-development/full-stack-development-jhipster).

If you like JHipster, give it a star on [GitHub](https://github.com/jhipster/generator-jhipster).

If you like this article, leave some claps (Did you know you can clap multiple times? 😁).

You can follow me on [Twitter](https://twitter.com/deepu105) and [LinkedIn](https://www.linkedin.com/in/deepu05/).

My other related posts:

1. [Create full Microservice stack using JHipster Domain Language under 30 minutes](/@deepu105/create-full-microservice-stack-using-jhipster-domain-language-under-30-minutes-ecc6e7fc3f77)
2. [Deploying JHipster Microservices on Azure Kubernetes Service (AKS)](/@deepu105/deploying-jhipster-microservices-on-azure-kubernetes-service-aks-fb46991746ba)


---
# Deploying JHipster Microservices on Azure Kubernetes Service (AKS)

![AKS Overview](https://miro.medium.com/v2/resize:fit:1250/1*nVYYKBoVYcKUcaGIIGSgmA.png)

If you are developing and deploying applications to production, especially cloud, you would have heard about [**Kubernetes**](https://kubernetes.io/). Kubernetes (**k8s**) is a container orchestration platform originally developed by Google and makes deploying containerized/dockerized applications to production more manageable and scalable.

[**Kubernetes**](https://kubernetes.io/) has been crowned as the undeniable champion of container orchestration for a while now, and every other ***KS** offering that we see sprouting up are testimonials for that. The **K** obviously stands for Kubernetes and **S/E** stands for Service/Engine, and the first letter stands for the product offering it. So far we have [**AKS**](https://docs.microsoft.com/en-us/azure/aks/) (Azure), [**GKE**](https://cloud.google.com/kubernetes-engine/) (Google), [**EKS**](https://aws.amazon.com/eks/) (Amazon ECS), and [**PKS**](https://content.pivotal.io/pivotal-container-service-pks) (Pivotal), along with flavors from [Oracle](https://cloud.oracle.com/en_US/containers/kubernetes-engine###) and RedHat (read [Openshift](https://www.redhat.com/en/technologies/cloud-computing/openshift)).

One of my colleagues has written a [nice article](https://blog.xebialabs.com/2017/12/12/future-container-solutions-will-k-shaped/) about it, which I highly recommend.

In this article, we will see how we can deploy a microservice architecture created by JHipster to Azure Kubernetes Service.

Azure Kubernetes Service (AKS) is the managed Kubernetes platform offering from Microsoft to host your containerized applications.

### Creating the Microservice Application

In one of my [previous posts](/@deepu105/create-full-microservice-stack-using-jhipster-domain-language-under-30-minutes-ecc6e7fc3f77), I showcased how to create a full-stack microservice architecture using **JHipster** and **JDL**. Read the post [here](/@deepu105/create-full-microservice-stack-using-jhipster-domain-language-under-30-minutes-ecc6e7fc3f77) for more details. For this exercise, we will use the same application.

Let us recap the steps required.

Create a JDL file, let’s say `app.jdl`, and copy the below content into it.

```java
application {
  config {
    baseName store,
    applicationType gateway,
    packageName com.jhipster.demo.store,
    serviceDiscoveryType eureka,
    authenticationType jwt,
    prodDatabaseType mysql,
    cacheProvider hazelcast,
    buildTool gradle,
    clientFramework react,
    testFrameworks [protractor]
  }
  entities *
}

application {
  config {
    baseName invoice,
    applicationType microservice,
    packageName com.jhipster.demo.invoice,
    serviceDiscoveryType eureka,
    authenticationType jwt,
    prodDatabaseType mysql,
    buildTool gradle,
    serverPort 8081
  }
  entities Invoice, Shipment
}

application {
  config {
    baseName notification,
    applicationType microservice,
    packageName com.jhipster.demo.notification,
    serviceDiscoveryType eureka,
    authenticationType jwt,
    databaseType mongodb,
    cacheProvider no,
    enableHibernateCache false,
    buildTool gradle,
    serverPort 8082
  }
  entities Notification
}
```

Now create a directory called **ecommerce** and navigate into it. Run the JHipster import-jdl command. It could take a few minutes, especially the NPM install step.

```shell
$ mkdir ecommerce && cd ecommerce
$ jhipster import-jdl app.jdl
```

Once the JHipster process is complete, you will see that we have our store gateway, invoice service, and notification service created and ready for us. The process until this is explained in more detail in my previous post [here](/@deepu105/create-full-microservice-stack-using-jhipster-domain-language-under-30-minutes-ecc6e7fc3f77), and you can deploy the application locally using Docker as explained in that post. If you haven’t done that before, I strongly suggest that step so that you get an idea of the application and you also can make sure it works locally on your machine.

### Generating the Kubernetes Configuration

Now that our application is ready, let us create the required configurations for Kubernetes using JHipster.

In the ecommerce folder we created earlier, create a new directory, let's call it **k8s** so that we get the below structure:

```plaintext
├── app.jdl
├── invoice
├── k8s
├── notification
└── store
```

Create the k8s directory and navigate to it. Now run the JHipster Kubernetes command there.

```shell
$ mkdir k8s && cd k8s
$ jhipster kubernetes
```

The generator will ask you a few questions. Choose the answers as highlighted below:

```plaintext
⎈ Welcome to the JHipster Kubernetes Generator ⎈
Files will be generated in folder: /home/deepu/workspace/temp/ecommerce/k8s
✔ Docker is installed? Which *type* of application would you like to deploy? Microservice application
✔ Enter the root directory where your gateway(s) and microservices are located ../
✔ 3 applications found at /home/deepu/workspace/temp/ecommerce/
✔ Which applications do you want to include in your configuration? invoice, notification, store
✔ Do you want to setup monitoring for your applications? No
✔ What should we use for the Kubernetes namespace? default
✔ What should we use for the base Docker repository name? <your Docker hub account id>
✔ What command should we use for push Docker image to repository? docker push
✔ Do you want to configure Istio? Not required
✔ Choose the Kubernetes service type for your edge services LoadBalancer - Let a Kubernetes cloud provider automatically assign an IP
```

The generator will create the required Kubernetes configuration files and print out useful information to proceed further. Go through the generated k8s files and familiarize yourself.

**Note:** Due to an [open issue in JHipster](https://github.com/jhipster/generator-jhipster/issues/8422), we need to make some adjustments to the generated Kubernetes configuration. This is also why monitoring with Elastic (ELK) stack was not enabled.

First, modify the file `k8s/notification/notification-mongodb.yml` to simplify it from a stateful set to a simple deployment:

```yaml
apiVersion: apps/v1beta1
kind: Deployment
metadata:
  name: notification-mongodb
  namespace: default
spec:
  replicas: 1
  template:
    metadata:
      labels:
        app: notification-mongodb
    spec:
      volumes:
      - name: data
        emptyDir: {}
      containers:
      - name: mongodb
        image: mongo:3.6.3
        ports:
        - name: peer
          containerPort: 27017
        volumeMounts:
        - name: data
          mountPath: /data/db/
```

Update the MongoDB URL in `k8s/notification/notification-deployment.yml`:

```yaml
mongodb://notification-mongodb.default.svc.cluster.local:27017
```

Now build and push the Docker images for the application.

### Preparing AKS Cluster

To deploy the applications to AKS, ensure the following tools are installed:

1. [kubectl](https://kubernetes.io/docs/tasks/tools/install-kubectl/): The command-line tool to interact with Kubernetes.
2. [Azure CLI](https://docs.microsoft.com/en-us/cli/azure/install-azure-cli?view=azure-cli-latest): The command-line tool to interact with Azure.

Create a resource group:

```shell
$ az group create --name eCommerceCluster --location eastus
```

Create an AKS cluster:

```shell
$ az aks create --resource-group eCommerceCluster --name eCommerceCluster --node-count 2 --enable-addons monitoring --generate-ssh-keys
```

Configure `kubectl` to connect to the AKS cluster:

```shell
$ az aks get-credentials --resource-group eCommerceCluster --name eCommerceCluster
```

Verify the connection:

```shell
$ kubectl get nodes
```

### Deploying the Application to AKS

Deploy the application using `kubectl apply`:

```shell
$ kubectl apply -f registry
$ kubectl apply -f invoice
$ kubectl apply -f notification
$ kubectl apply -f store
```

Alternatively, run the `kubectl-apply.sh` script.

Scale services using `kubectl scale`:

```shell
$ kubectl scale --replicas=2 deployment/invoice
```

### Cleanup

Delete the cluster and resources:

```shell
$ az group delete --name eCommerceCluster --yes --no-wait
```

### Conclusion

Kubernetes simplifies deploying microservice applications to production. Managed services like AKS and GKE make it even easier. JHipster provides a great Kubernetes setup to start with, which can be further tweaked as needed.

To learn more about JHipster, check out my book **Full Stack Development with JHipster** on [Amazon](https://www.amazon.com/Stack-Development-JHipster-Deepu-Sasidharan/dp/178847631X) and [Packt](https://www.packtpub.com/application-development/full-stack-development-jhipster).

If you like JHipster, give it a star on [GitHub](https://github.com/jhipster/generator-jhipster).

If you like this article, leave some claps (Did you know you can clap multiple times? :P).

You can follow me on [Twitter](https://twitter.com/deepu105) and [LinkedIn](https://www.linkedin.com/in/deepu05/).

My other related posts:

1. [Create full Microservice stack using JHipster Domain Language under 30 minutes](/@deepu105/create-full-microservice-stack-using-jhipster-domain-language-under-30-minutes-ecc6e7fc3f77)
2. [JHipster microservices with Istio service mesh on Kubernetes](/@deepu105/jhipster-microservices-with-istio-service-mesh-on-kubernetes-a7d0158ba9a3)

---

# Deploying JHipster Microservices on AWS EKS (Elastic Kubernetes Service)

This is my first blog on Medium. As a software entrepreneur and enthusiastic developer, I love **JHipster**. So, obviously, I’m writing about JHipster! This blog is largely based on the [blog](https://medium.com/jhipster/deploying-jhipster-microservices-on-azure-kubernetes-service-aks-fb46991746ba) of [Deepu K Sasidharan](https://medium.com/@deepu105), the JHipster co-lead.

### Creating the Microservice Application

In a [post](https://medium.com/jhipster/create-full-microservice-stack-using-jhipster-domain-language-under-30-minutes-ecc6e7fc3f77) by a fellow JHipster enthusiast, they showcased how to create a full-stack microservice architecture using **JHipster** and **JDL**. Read the post [here](https://medium.com/@deepu105/create-full-microservice-stack-using-jhipster-domain-language-under-30-minutes-ecc6e7fc3f77) for more details. For this exercise, we will use the same application.

Let's recap the steps required.

Create a JDL file, e.g., `app.jdl`, and copy the following content into it:

```java
// ...JDL content here...
```

Now create a directory called `ecommerce` and navigate into it. Run the JHipster import-jdl command. It could take a few minutes, especially the NPM install step.

```shell
mkdir ecommerce && cd ecommerce
jhipster import-jdl app.jdl
```

Once the JHipster process is complete, you will see that we have our store gateway, invoice service, and notification service created and ready. The process until this point is explained in more detail in my previous post [here](https://medium.com/@deepu105/create-full-microservice-stack-using-jhipster-domain-language-under-30-minutes-ecc6e7fc3f77). You can deploy the application locally using Docker as explained in that post. If you haven’t done that before, I strongly suggest that step so you get an idea of the application and can make sure it works locally on your machine.

### Generating the Kubernetes Configuration

Now that our application is ready, let’s create the required configurations for Kubernetes using JHipster.

In the `ecommerce` folder, create a new directory called `k8s` so that you get the following structure:

```
├── app.jdl
├── invoice
├── k8s
├── notification
└── store
```

Create the `k8s` directory and navigate to it. Now run the JHipster Kubernetes command there:

```shell
mkdir k8s && cd k8s
jhipster kubernetes
```

The generator will ask you a few questions. Choose the answers as highlighted below. For the “base Docker repository name,” provide your own Docker Hub account ID. For real-world use cases, you could also use a private image repository like [Amazon Elastic Container Registry](https://aws.amazon.com/ecr/) or [Azure Container Registry](https://docs.microsoft.com/en-us/azure/aks/tutorial-kubernetes-prepare-acr). For now, let’s keep it simple.

> ⎈ Welcome to the JHipster Kubernetes Generator ⎈
> Files will be generated in folder: /home/vrecon/workspace/temp/ecommerce/k8s
> ✔ Docker is installed? Which *type* of application would you like to deploy? **Microservice application**
> Enter the root directory where your gateway(s) and microservices are located: **../**
> 3 applications found at /home/deepu/workspace/temp/ecommerce/
> Which applications do you want to include in your configuration? **invoice, notification, store**
> Do you want to setup monitoring for your applications? **No**
> Which applications do you want to use with clustered databases (only available with MongoDB and Couchbase)?
> JHipster registry detected as the service discovery and configuration provider used by your apps?
> Enter the admin password used to secure the JHipster Registry: **admin**
> What should we use for the Kubernetes namespace? **default**
> What should we use for the base Docker repository name? **<your Docker hub account id>**
> What command should we use for push Docker image to repository? **docker push**
> Do you want to configure Istio? **Not required**
> Choose the kubernetes service type for your edge services: **LoadBalancer - Let a kubernetes cloud provider automatically assign an IP**

The generator will create the following files and output:

```shell
create invoice/invoice-deployment.yml
create invoice/invoice-service.yml
create invoice/invoice-mysql.yml
create notification/notification-deployment.yml
create notification/notification-service.yml
create notification/notification-mongodb.yml
create store/store-deployment.yml
create store/store-service.yml
create store/store-mysql.yml
create README.md
create registry/jhipster-registry.yml
create registry/application-configmap.yml
create kubectl-apply.sh
```

> **WARNING!** Kubernetes configuration generated with missing images! To generate the missing Docker image(s), please run:
> 
> ```shell
> ./gradlew -Pprod bootWar buildDocker # in each service directory
> ```
> 
> You will need to push your image to a registry. If you have not done so, use the following commands to tag and push the images:
> 
> ```shell
> docker image tag invoice <your-dockerhub-id>/invoice
> docker push <your-dockerhub-id>/invoice
> docker image tag notification <your-dockerhub-id>/notification
> docker push <your-dockerhub-id>/notification
> docker image tag store <your-dockerhub-id>/store
> docker push <your-dockerhub-id>/store
> ```
> 
> You can deploy all your apps by running the following script:
> 
> ```shell
> ./kubectl-apply.sh
> ```
> 
> Use these commands to find your application's IP addresses:
> 
> ```shell
> kubectl get svc store
> ```

Go through the generated k8s files and familiarize yourself.

Let’s build and push the Docker images for our application. Follow the instructions above and build Docker images in each of the application folders, then tag and push the images to your Docker Hub account.

### Preparing the AWS Cluster

Now that our applications are built and pushed, it's time to deploy them to AWS EKS. But before that, let’s make sure we have all the prerequisites ready. You will need the following tools:

1. [kubectl](https://kubernetes.io/docs/tasks/tools/install-kubectl/): The command line tool to interact with Kubernetes. Install and configure it.
2. [AWS CLI](https://docs.aws.amazon.com/cli/latest/userguide/cli-chap-install.html): Install the latest AWS Command Line Interface.
3. [eksctl](https://eksctl.io/): a CLI for Amazon EKS. Install and read this [tutorial](https://docs.aws.amazon.com/eks/latest/userguide/getting-started-eksctl.html) on how to get started.

#### Configure Your AWS CLI Credentials

Both `eksctl` and the AWS CLI require that you have AWS credentials configured in your environment. The `aws configure` command is the fastest way to set up your AWS CLI installation for general use.

```shell
aws configure
# AWS Access Key ID [None]: AKIAIOSFODNN7EXAMPLE
# AWS Secret Access Key [None]: wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
# Default region name [None]: us-west-2
# Default output format [None]: json
```

Once the tools are ready, let’s prepare our Kubernetes cluster.

First, create the cluster. Run the below command. This will create a cluster named `eCommerceCluster` in the US West region (you can use other [AWS Regions](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/using-regions-availability-zones.html) as well).

```shell
eksctl create cluster --name eCommerceCluster
```

This will take several minutes to complete.

The output will look something like this:

```
[ℹ]  using region us-west-2
[ℹ]  setting availability zones to [us-west-2b us-west-2c us-west-2d]
[ℹ]  subnets for us-west-2b - public:192.168.0.0/19 private:192.168.96.0/19
[ℹ]  subnets for us-west-2c - public:192.168.32.0/19 private:192.168.128.0/19
[ℹ]  subnets for us-west-2d - public:192.168.64.0/19 private:192.168.160.0/19
[ℹ]  nodegroup "standard-workers" will use "ami-0923e4b35a30a5f53" [AmazonLinux2/1.12]
[ℹ]  creating EKS cluster "ecommercecluster" in "us-west-2" region
[ℹ]  will create 2 separate CloudFormation stacks for cluster itself and the initial nodegroup
[ℹ]  if you encounter any issues, check CloudFormation console or try 'eksctl utils describe-stacks --region=us-west-2 --name=ecommercecluster'
[ℹ]  building cluster stack "eksctl-ecommercecluster-cluster"
[ℹ]  creating nodegroup stack "eksctl-ecommercecluster-nodegroup-standard-workers"
[✔]  all EKS cluster resource for "ecommercecluster" had been created
[✔]  saved kubeconfig as "/Users/ericn/.kube/config"
[ℹ]  adding role "arn:aws:iam::111122223333:role/eksctl-prod-nodegroup-standard-wo-NodeInstanceRole-IJP4S12W3020" to auth ConfigMap
[ℹ]  nodegroup "standard-workers" has 0 node(s)
[ℹ]  waiting for at least 1 node(s) to become ready in "standard-workers"
[ℹ]  nodegroup "standard-workers" has 2 node(s)
[ℹ]  node "ip-192-168-22-17.us-west-2.compute.internal" is not ready
[ℹ]  node "ip-192-168-32-184.us-west-2.compute.internal" is ready
[✔]  EKS cluster "ecommercecluster" in "us-west-2" region is ready
```

Verify that you are able to connect to the cluster by running:

```shell
kubectl get nodes
```

Example output:

```
NAME                                        STATUS   ROLES    AGE   VERSION
ip-192–168–28–143.us-west-2.compute.internal Ready    <none>   18h   v1.12.7
ip-192–168–72–37.us-west-2.compute.internal  Ready    <none>   18h   v1.12.7
```

# Deploying the Application to AWS EKS

Now that our cluster is ready, let’s deploy our microservice stack to this cluster.

We can deploy our application using the `kubectl apply` command. Navigate to the `k8s` folder and run the following commands in order:

```shell
kubectl apply -f registry
kubectl apply -f invoice
kubectl apply -f notification
kubectl apply -f store
```

Or you can just run the handy `kubectl-apply.sh` script generated earlier, which runs the above.

We deploy the JHipster Registry first as it is required for other services, followed by the microservices and finally our gateway (store).

If you get a timeout during any of these, just try the command again.

Though the services get created fast, the actual applications might not be up and running yet. Give the entire thing a minute or two to start.

Now run the following to see the status of your containers:

```shell
kubectl get pods -w
```

Example output:

```
NAME                                    READY  STATUS
invoice-5ffb46d944-h8x42                1/1    Running
invoice-mysql-66bc4b7874-p7ghk          1/1    Running
jhipster-registry-0                     1/1    Running
jhipster-registry-1                     1/1    Running
notification-76847b7667-d7xjb           1/1    Running
notification-mongodb-6db986b556-8bw8z   1/1    Running
store-8dc5cd6f7-s2dpx                   1/1    Running
store-mysql-779d66685d-tmkqd            1/1    Running
```

Wait until all the containers are in **Running** status. Once the containers are running, you can run the following to get the external IP for the application:

```shell
kubectl get service store
```

Example output:

```
NAME   TYPE         CLUSTER-IP    EXTERNAL-IP    PORT(S)         AGE
store  LoadBalancer 10.100.20.215 a317424b3765211e9831306d9c07d674-1390706390.us-west-2.elb.amazonaws.com 8080:32307/TCP 18h
```

In this case, the external IP for our gateway application is `a317424b3765211e9831306d9c07d674–1390706390.us-west-2.elb.amazonaws.com` running on port **8080**. 

The JHipster registry is deployed as a headless service by default. If you need to access the registry, create a secondary service with a Load Balancer:

```shell
kubectl expose service jhipster-registry --type=LoadBalancer --name=exposed-registry
```

Now run the following to get the IP:

```shell
kubectl get service exposed-registry
```

Example output:

```
NAME              TYPE         CLUSTER-IP       EXTERNAL-IP    PORT(S)
exposed-registry  LoadBalancer 10.100.194.130   af86bcd7c765211e9831306d9c07d674-372126431.us-west-2.elb.amazonaws.com 8761:31185/TCP 18h
```

Visit the URL in a browser to see the registry in action:

![JHipster Registry](https://miro.medium.com/v2/resize:fit:875/1*z-j53XLkFM79d9l0b4CDVA.png)

---

### Conclusion

Kubernetes is definitely the best way to deploy microservice applications to production, but creating and managing Kubernetes clusters itself is not an easy task. Kubernetes services like **EKSCTL** make it a bit easier.

JHipster provides a great Kubernetes setup to start with, which you can further tweak as per your needs and platform. Using AWS EKS works great, and scaling up and down instances can be done quite easily.

---

### Embedded Content: Example JDL

Below is an example JDL for the microservices architecture:

```java
application {
  config {
    baseName store
    applicationType gateway
    packageName com.jhipster.demo.store
    serviceDiscoveryType eureka
    authenticationType jwt
    prodDatabaseType mysql
    cacheProvider hazelcast
    buildTool gradle
    clientFramework react
    testFrameworks [protractor]
  }
  entities *
}

application {
  config {
    baseName invoice
    applicationType microservice
    packageName com.jhipster.demo.invoice
    serviceDiscoveryType eureka
    authenticationType jwt
    prodDatabaseType mysql
    buildTool gradle
    serverPort 8081
  }
  entities Invoice, Shipment
}

application {
  config {
    baseName notification
    applicationType microservice
    packageName com.jhipster.demo.notification
    serviceDiscoveryType eureka
    authenticationType jwt
    databaseType mongodb
    cacheProvider no
    enableHibernateCache false
    buildTool gradle
    serverPort 8082
  }
  entities Notification
}

// Entities for Store Gateway
entity Product {
  name String required
  description String
  price BigDecimal required min(0)
  size Size required
  image ImageBlob
}

enum Size {
  S, M, L, XL, XXL
}

entity ProductCategory {
  name String required
  description String
}

entity Customer {
  firstName String required
  lastName String required
  gender Gender required
  email String required pattern(/^[^@\s]+@[^@\s]+\.[^@\s]+$/)
  phone String required
  addressLine1 String required
  addressLine2 String
  city String required
  country String required
}

enum Gender {
  MALE, FEMALE, OTHER
}

entity ProductOrder {
  placedDate Instant required
  status OrderStatus required
  code String required
  invoiceId Long
}

enum OrderStatus {
  COMPLETED, PENDING, CANCELLED
}

entity OrderItem {
  quantity Integer required min(0)
  totalPrice BigDecimal required min(0)
  status OrderItemStatus required
}

enum OrderItemStatus {
  AVAILABLE, OUT_OF_STOCK, BACK_ORDER
}

relationship OneToOne {
  Customer{user(login) required} to User
}

relationship ManyToOne {
  OrderItem{product(name) required} to Product
}

relationship OneToMany {
  Customer{order} to ProductOrder{customer(email) required},
  ProductOrder{orderItem} to OrderItem{order(code) required},
  ProductCategory{product} to Product{productCategory(name)}
}

service Product, ProductCategory, Customer, ProductOrder, OrderItem with serviceClass
paginate Product, Customer, ProductOrder, OrderItem with pagination

// Entities for Invoice microservice
entity Invoice {
  code String required
  date Instant required
  details String
  status InvoiceStatus required
  paymentMethod PaymentMethod required
  paymentDate Instant required
  paymentAmount BigDecimal required
}

enum InvoiceStatus {
  PAID, ISSUED, CANCELLED
}

entity Shipment {
  trackingCode String
  date Instant required
  details String
}

enum PaymentMethod {
  CREDIT_CARD, CASH_ON_DELIVERY, PAYPAL
}

relationship OneToMany {
  Invoice{shipment} to Shipment{invoice(code) required}
}

service Invoice, Shipment with serviceClass
paginate Invoice, Shipment with pagination
microservice Invoice, Shipment with invoice

// Entities for notification microservice
entity Notification {
  date Instant required
  details String
  sentDate Instant required
  format NotificationType required
  userId Long required
  productId Long required
}

enum NotificationType {
  EMAIL, SMS, PARCEL
}

microservice Notification with notification
```

---

https://gist.github.com/deepu105/127b220d0c7a3bbf06386cef8128d2f5#file-online-store-jdl
---
# Add Self-Hosted Matomo Analytics with Angulartics2 in Your JHipster App

[Matomo](https://matomo.org/) is an excellent self-hosted, open-source analytics platform.

In this guide, you'll learn how to integrate Matomo with [angulartics2](https://github.com/angulartics/angulartics2) (a vendor-agnostic analytics library) into your JHipster app.

We'll also cover how to request user consent for Matomo cookies (GDPR compliance).

---

### Requirements

- A running Matomo instance for testing.
- For quick setup, use a [Matomo Docker image](https://github.com/matomo-org/docker).
- See the [Getting Started guide](https://matomo.org/docs/installation/#getting-started) for configuration details.

---

### Generate an Angular Project

Open a new folder and run:

```shell
jhipster
```

Follow the prompts to scaffold your app.

### Add Angulartics2 Library

Install the library in your project:

**With NPM:**

```shell
npm install --save angulartics2
```

**With Yarn:**

```shell
yarn add angulartics2
```

---

### Configure Angulartics2

Import and initialize the tracking library in your `app.module.ts`:

```typescript
import { Angulartics2Module } from 'angulartics2';

@NgModule({
  // ...existing code...
  imports: [
    // ...existing code...
    Angulartics2Module.forRoot(),
    // ...existing code...
  ],
  // ...existing code...
})
export class AppModule { }
```

Next, specify the analytics provider and start tracking users in `main.component.ts`:

- Inject `Angulartics2Piwik`
- Call the `startTracking()` method

```typescript
import { Angulartics2Piwik } from 'angulartics2/piwik';

constructor(private angulartics2Piwik: Angulartics2Piwik) {
  this.angulartics2Piwik.startTracking();
}
```

---

### Integrate Matomo Tracking Code

Configure your Matomo server details so your Angular app knows where to send tracking data.

In `prod.config.ts`, create a method named `initMatomo()` and call it inside the `if (!DEBUG_INFO_ENABLED)` block. This ensures tracking only runs in production mode (e.g., after `npm run-script build`).

Copy the tracking code from Matomo:

- Go to **Settings > Websites > Tracking code** in your Matomo dashboard.
- Paste the code into your `initMatomo()` method.

> **Note:** Delete the `trackPageView` option—this is handled by the Angular router.

Wrap your JS tracking code inside the method. Example:

```javascript
initMatomo() {
  const u = 'https://your-matomo-domain/';
  window._paq = window._paq || [];
  // ...existing code...
  // window._paq.push(['trackPageView']); // Remove this line
  // ...existing code...
  window._paq.push(['enableLinkTracking']);
  (function() {
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.src=u+'matomo.js'; s.parentNode.insertBefore(g,s);
  })();
}
```

---

### Build and Test

Run:

```shell
npm run-script build
./mvnw
```

Visit [http://localhost:8080](http://localhost:8080) and check your Matomo dashboard for real-time analytics.

![Matomo Real-Time View](https://miro.medium.com/v2/resize:fit:875/1*K3WddIfao8_0Az0BcNjGLA.png)

---

### Asking the User for Cookie Consent (Opt-in)

To respect user privacy, tracking should be off by default. Matomo supports this out of the box.

Add the following to your Matomo script in `prod.config.ts` before other options:

```javascript
_paq.push(['requireConsent']);
```

### Add a Consent Button

In `home.component.html`:

```html
<button type="button" class="btn btn-primary" (click)="onAcceptCookie()">Accept the cookie</button>
```

In `home.component.ts`, declare the global variable and add the consent method:

```typescript
declare var _paq: any;

onAcceptCookie() {
  if (typeof _paq !== 'undefined') {
    // 720h = 1 month
    _paq.push(['rememberConsentGiven', 720]);
  }
}
```

This will remember consent for one month. You can verify by inspecting cookies in your browser—look for a cookie named `mtm_consent`.

To allow users to withdraw consent:

```typescript
if (typeof _paq !== 'undefined') {
  _paq.push(['forgetConsentGiven']);
}
```

---

**And voilà! You now have GDPR-compliant, opt-in analytics.**

---

*I hope this post was useful! If you spot any mistakes or have feedback, let me know.*

By the way, I'm launching a Spring Boot / Angular course for beginners with integrated coaching. If you're interested, [click here](https://code-camp.dev/).

---
# Microservices using JHipster, Kubernetes, and Istio

In this guide, we'll create a system from scratch using microservices, deploy all the microservices to Kubernetes & Istio, and monitor using Grafana, Prometheus, Kiali, Jaeger, Elasticsearch, and Kibana. We'll also demonstrate a focused canary deployment (using a custom header).

> _This article is intended as a head start for those wanting to test Istio, Kubernetes, or JHipster. The demo is not production-ready; it's a proof of technology._

---

### System Overview

- **JHipster version:** 6.0.0
- **Istio version:** 1.0.6
- **Kubernetes version:** 1.11
- **Microservices:** Office Assistant (UI, ORGANIZATION, LEAVE, MEETING, NOTIFICATION)
- **Persistence:**
  - Organization: MySQL
  - Meeting, Leave, Notification: MongoDB
- **Monitoring:** Grafana, Prometheus, Kiali, Jaeger, Elasticsearch, Kibana

---

### Prerequisites

- Google Cloud account with Google Kubernetes Engine enabled
- [Google Cloud SDK](https://cloud.google.com/sdk/docs/) (Windows client used in this example)

### Authenticate and Set Up Project

```shell
gcloud auth login
gcloud projects create trc-office-1
gcloud config set project trc-office-1
```

---

### Enable Kubernetes API

> Ensure the [Google Kubernetes Engine API](https://console.cloud.google.com/apis/library/container.googleapis.com/) is enabled for your project.

---

### Create Google Kubernetes Engine Cluster

```shell
gcloud container clusters create office-cluster --cluster-version 1.11 --zone us-central1-a --num-nodes 4 --machine-type n1-standard-2
gcloud container clusters get-credentials office-cluster --zone us-central1-a
```

---

### Configure Google Kubernetes Engine

```shell
kubectl create clusterrolebinding cluster-admin-binding --clusterrole=cluster-admin --user="your.email@example.com"
```

---

### Install Istio and Helm

- Download and install [Helm](https://github.com/helm/helm)
- Download and unzip Istio 1.0.6: [Istio 1.0.6 Release](https://github.com/istio/istio/releases/tag/1.0.6)

---

### Install Istio in Kubernetes Cluster

```shell
cd C:/ProgramFiles/istio-1.0.6
kubectl apply -f install/kubernetes/helm/istio/templates/crds.yaml
kubectl apply -f install/kubernetes/istio-demo.yaml --as=admin --as-group=system:masters
```

---

### Check Istio Installation

```shell
kubectl get pods -n istio-system
kubectl get services -n istio-system
```

---

### Install Kiali

Apply the configuration:

```shell
kubectl apply -f kiali.yml
```

---

### Install Elastic GKE Logging

You can use the Google Kubernetes Marketplace for installation, or Stackdriver. For Kibana, after installation, run:

```shell
kubectl apply -f kibana-gateway.yml
```

---

### Generate JHipster Applications

Create the system descriptor using JHipster Domain Language (JDL). Replace the IP in `ingressDomain` with your Istio Ingress IP.

```shell
jhipster import-jdl office-assistant.jh
```

---

### Minor Bug Fixes

1. **UI npm postinstall task not working:** Remove the `postinstall` line from `ui/package.json` and run:
   ```shell
   npm i
   ```
2. **Change the ingress nip.io address in `ui-gateway.yml`**
3. **Update Istio virtual service matching prefixes for microservices in `ui-gateway.yml`**
4. **Change the health URL for each microservice**

---

### Build Docker Images

```shell
cd ui/ && gradlew bootJar -Pprod jibDockerBuild
cd ../organization && gradlew bootJar -Pprod jibDockerBuild
cd ../leave && gradlew bootJar -Pprod jibDockerBuild
cd ../meeting && gradlew bootJar -Pprod jibDockerBuild
cd ../notification && gradlew bootJar -Pprod jibDockerBuild
```

---

### Push Docker Images

Replace `razvansimiontrencadis` with your Docker username:

```shell
docker login
docker image tag ui yourdocker/office-ui
docker push yourdocker/office-ui
docker image tag organization yourdocker/office-organization
docker push yourdocker/office-organization
docker image tag leave yourdocker/office-leave
docker push yourdocker/office-leave
docker image tag meeting yourdocker/office-meeting
docker push yourdocker/office-meeting
docker image tag notification yourdocker/office-notification
docker push yourdocker/office-notification
```

---

### Deploy on Kubernetes

```shell
gcloud container clusters get-credentials office-cluster --zone us-central1-a
kubectl apply -f namespace.yml
kubectl label namespace office istio-injection=enabled --overwrite=true
kubectl apply -f ui/
kubectl apply -f organization/
kubectl apply -f leave/
kubectl apply -f meeting/
kubectl apply -f notification/
kubectl apply -f istio/
```

---

### Check Deployment Status

```shell
kubectl get pods -n office
```

---

### Accessing the System

- UI: [ui.35.184.190.237.nip.io](http://ui.35.184.190.237.nip.io/)
- Grafana: [grafana.35.184.190.237.nip.io](http://grafana.35.184.190.237.nip.io/)
- Kiali: [kiali.35.184.190.237.nip.io](http://kiali.35.184.190.237.nip.io/) (user: admin, password: admin)
- Kibana: [kibana.35.184.190.237.nip.io](http://kibana.35.184.190.237.nip.io/)
- Jaeger: [jaeger.35.184.190.237.nip.io](http://jaeger.35.184.190.237.nip.io/)

---

### Focused Canary Deployment

To test a new UI version (e.g., 1.0.2) for specific users, use a custom header (`qa: canary-test`). Update your deployment and Istio configs to route requests with this header to the new version.

---

### Example JDL for Office Assistant

```java
application {
  config {
    baseName ui
    applicationType gateway
    packageName ro.trc.office.ui
    serviceDiscoveryType no
    authenticationType jwt
    databaseType mongodb
    cacheProvider no
    enableHibernateCache false
    buildTool gradle
    useSass true
    testFrameworks [protractor]
  }
  entities *
}

application {
  config {
    baseName organization
    applicationType microservice
    packageName ro.trc.office.organization
    serviceDiscoveryType no
    authenticationType jwt
    prodDatabaseType mysql
    cacheProvider hazelcast
    buildTool gradle
    serverPort 8081
  }
  entities Department, Employee
}

application {
  config {
    baseName leave
    applicationType microservice
    packageName ro.trc.office.leave
    serviceDiscoveryType no
    authenticationType jwt
    databaseType mongodb
    cacheProvider no
    enableHibernateCache false
    buildTool gradle
    serverPort 8082
  }
  entities EmployeeLeave, LeaveRequest
}

application {
  config {
    baseName notification
    applicationType microservice
    packageName ro.trc.office.notification
    serviceDiscoveryType no
    authenticationType jwt
    databaseType mongodb
    cacheProvider no
    enableHibernateCache false
    buildTool gradle
    serverPort 8083
  }
  entities Notification
}

application {
  config {
    baseName meeting
    applicationType microservice
    packageName ro.trc.office.meeting
    serviceDiscoveryType no
    authenticationType jwt
    databaseType mongodb
    cacheProvider no
    enableHibernateCache false
    buildTool gradle
    serverPort 8084
  }
  entities MeetingRoom, Meeting, Participant
}

// ORGANIZATION
entity Employee {
  code String required
  firstName String required
  lastName String required
  gender Gender required
  email String required pattern(/^[^@\s]+@[^@\s]+\.[^@\s]+$/)
  phone String required
  addressLine1 String required
  addressLine2 String
  city String required
  country String required
}

entity Department {
  code String required
  name String required
}

enum Gender {
  MALE, FEMALE, OTHER
}

relationship ManyToOne {
  Employee{department(name) required} to Department
}

service Employee, Department with serviceClass
paginate Employee, Department with pagination
microservice Employee, Department with organization

// LEAVE
entity EmployeeLeave {
  employeeCode String required
  total BigDecimal required
  available BigDecimal required
}

enum LeaveRequestStatus {
  COMPLETED, PENDING, APPROVED, REJECTED, CANCELLED
}

enum LeaveRequestType {
  VACATION, MEDICAL
}

entity LeaveRequest {
  startDate Instant required
  endDate Instant required
  creationDate Instant required
  departmentCode String required
  employeeCode String required
  workingDays Long required
  description String
  leaveType LeaveRequestType required
  status LeaveRequestStatus required
}

service EmployeeLeave, LeaveRequest with serviceClass
paginate EmployeeLeave, LeaveRequest with pagination
microservice EmployeeLeave, LeaveRequest with leave

// NOTIFICATION
entity Notification {
  date Instant required
  details String
  sentDate Instant required
  format NotificationType required
  userId Long required
  productId Long required
}

enum NotificationType {
  EMAIL, PUSH
}

service Notification with serviceClass
paginate Notification with pagination
microservice Notification with notification

// MEETING
entity MeetingRoom {
  code String required
  location String required
  name String required
}

entity Participant {
  email String required
}

entity Meeting {
  title String required
  description String
  startDate Instant required
  endDate Instant required
}

relationship ManyToOne {
  Meeting{meetingRoom(name) required} to MeetingRoom
}

relationship ManyToMany {
  Meeting{participant(email)} to Participant{meeting(title)}
}

service MeetingRoom, Meeting, Participant with serviceClass
paginate MeetingRoom, Meeting, Participant with pagination
microservice MeetingRoom, Meeting, Participant with meeting

// DEPLOYMENT

deployment {
  deploymentType kubernetes
  appsFolders [ui, organization, leave, meeting, notification]
  dockerRepositoryName "razvansimiontrencadis"
  serviceDiscoveryType no
  istio true
  kubernetesServiceType Ingress
  kubernetesNamespace office
  ingressDomain "35.238.82.53.nip.io"
}
```

---

*View raw JDL: [office-assistant.jh](https://gist.github.com/RazvanSimion/0cccbcb22b8e5bda19f4ba3d478f2d15#file-office-assistant-jh) hosted with ❤ by [GitHub](https://github.com)*

---
# Kloud Native JHipster: JHipster ♥ Spring Boot ♥ K8s

JHipster is a developer-friendly platform to bootstrap, iterate, build, and deploy cloud-native Spring Boot-based services. It also generates scaffolding code for front-end services using popular frameworks like Angular and React. JHipster provides integration touchpoints with various data, logging, and monitoring services as well.

Over the years, scaffolding support has been added to deploy generated services across various native clouds and platforms. Developers love JHipster, and developer productivity is a core value that the community continuously improves. As Kubernetes grows in popularity, JHipster has added many K8s-friendly features. In this blog, we'll look at various K8s generator options and features available for developers to quickly iterate and test on any conformant K8s distribution in both private and public clouds.

### Outcomes

- Get to know various K8s generator options
- Leverage K8s-friendly toolkits to accelerate release velocity

### Prerequisites

- `jhipster` CLI binary installed locally

_Note: We'll use the K8s generator options after the project is bootstrapped and built using the JHipster CLI. K8s is one of the targeted platforms that JHipster supports for generating deployment artifacts._

---

### Wave #1: Kubernetes Generator

```shell
jhipster k8s
# or
jhipster kubernetes
```

This generator prompts you with a series of questions and then generates K8s manifests with a deployment script to deploy the service(s) at once. In addition to the `kubectl create|apply` option, support for popular K8s toolkits like `kustomize` and `skaffold` has been added.

You may now choose to deploy the generated manifests:

![K8s Generator](https://miro.medium.com/v2/resize:fit:875/1*S7vaZ8wRuUfBlPU26-ibgg.png)

- `./kubectl-apply.sh -f` — uses the standard `kubectl apply -f` option
- `./kubectl-apply.sh -k` — uses `kustomization` template to persist changes

With `skaffold`, you can turn your working directory into a CI/CD source. As you work on the source code, changes are detected, built, and deployed continuously. Developers focus on business problems while the dev software delivery pipeline is handled by Skaffold.

```shell
skaffold dev
```

![skaffold dev](https://miro.medium.com/v2/resize:fit:875/1*3A28p2YPmuXJDut3EQhE-g.png)

---

### Wave #2: Helm Generator

```shell
jhipster helm
# or
jhipster kubernetes-helm
```

The Helm generator uses the K8s generator for apps, but ancillary service manifests are pulled from upstream stable Helm sources. This provides enterprise-grade, stable manifests for services that you can confidently roll out to production.

![Helm Generator](https://miro.medium.com/v2/resize:fit:875/1*9TbZUIDPt_vRGNGm0roWLQ.png)

In addition to app and service manifests, it generates ready-to-execute scripts:

- `helm-apply.sh` — for initial installation

![helm-apply.sh](https://miro.medium.com/v2/resize:fit:875/1*WAW1fsRd00PkSmR1kEHHjw.png)

- `helm-upgrade.sh` — for subsequent updates as you iterate

![helm-upgrade.sh](https://miro.medium.com/v2/resize:fit:875/1*lh6Iync0tm3n11TLAog_6g.png)

Scripts support both Helm 2+ and 3+ semantics. The prerequisite is to have the Helm CLI installed. For Helm 2+, Tiller should be deployed in the cluster. The generated service manifests work on 2+, but you may face issues with 3+ if upstream distributions aren't fully compatible.

---

### Wave #3: Knative Generator (Experimental)

```shell
jhipster knative
# or
jhipster kubernetes-knative
```

Support for Knative constructs is experimental. This generator creates Knative `serving.knative.dev` service lifecycles for generated apps. The prerequisite is Istio, as this generator creates Istio-specific `VirtualService` and `DestinationRule` manifests. Developers are prompted to choose a generator (K8s or Helm) when using Knative.

![Knative Generator](https://miro.medium.com/v2/resize:fit:875/1*RW5AKYi0TB-EyFA97nuBmw.png)

- `kubectl-knative-apply.sh` — for Kubernetes generator

![knative-k8s](https://miro.medium.com/v2/resize:fit:875/1*FLyy9GlQ-2w8RAf0GPAnRA.png)

- Helm scripts for install and update if Helm is chosen

![knative-helm](https://miro.medium.com/v2/resize:fit:875/1*GwYTDpWoW1RQIL0vQhzudA.png)

---
