# Building a GraphQL API with Spring Boot: A Complete Guide

In modern API development, everyone focuses on flexibility and efficiency. Traditional REST APIs often lead to over- or under-fetching of data, especially in complex systems with deeply nested relationships. GraphQL, a query language developed by Facebook, addresses these issues by allowing clients to request the exact data they need.

When combined with Spring Boot, a powerful Java-based framework for building microservices, GraphQL becomes a robust solution for building flexible, scalable APIs. This blog discusses how to integrate GraphQL with Spring Boot, allowing you to build APIs that are not only performant and type-safe but also developer-friendly and adaptable to changing client requirements.

- [GraphQL Documentation](https://graphql.org/)
- [GraphQL with Spring Boot Documentation](https://spring.io/guides/gs/graphql-server)

# GraphQL vs REST

| Aspect         | REST                                   | GraphQL                                 |
| --------------|----------------------------------------|-----------------------------------------|
| Definition    | Conventions for APIs via multiple URLs  | Query language using a single endpoint  |
| Best for      | Simple, well-defined resources          | Complex, relational data                |
| Data Access   | Multiple endpoints                      | Single flexible endpoint                |
| Data Returned | Fixed by server                         | Defined by client                       |
| Typing        | Weakly typed                            | Strongly typed schema                   |
| Error Handling| Handled by client                       | Schema rejects invalid queries          |

# Set up Spring Boot Application

Add the following GraphQL dependency to your `pom.xml`:

```xml
<dependency>
  <groupId>org.springframework.graphql</groupId>
  <artifactId>spring-graphql-test</artifactId>
  <scope>test</scope>
</dependency>
```

You can create a simple Spring Boot application or clone it here:
[https://github.com/cdin8619-0/graphql-springboot.git](https://github.com/cdin8619-0/graphql-springboot.git)

## Project Structure

Let’s dive into the main components of our application:

1. Entity classes
2. Repository interfaces
3. Service classes
4. Controllers with GraphQL annotations
5. GraphQL schema definition

## Controller Implementation

```java
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;
import java.util.List;

@Controller
public class ProductController {
    private ProductService productService;

    @Autowired
    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @QueryMapping
    public List<Product> getProducts() {
        return productService.getAllProducts();
    }

    @QueryMapping
    public List<Product> getProductsByCategory(@Argument String category) {
        return productService.getProductsByCategory(category);
    }

    @MutationMapping
    public Product updateStock(@Argument int productId, @Argument int stock) {
        return productService.updateStock(productId, stock);
    }

    @MutationMapping
    public Product receiveNewShipment(@Argument int productId, @Argument int quantity) {
        return productService.receiveNewShipment(productId, quantity);
    }
}
```

The `@QueryMapping` and `@MutationMapping` annotations in Spring for GraphQL simplify linking methods to GraphQL query and mutation fields.

- **@QueryMapping**: Maps a method to a GraphQL query field, typically using the method name.
- **@MutationMapping**: Maps a method to a GraphQL mutation field for handling data changes.

## Service Implementation

```java
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepository;

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public List<Product> getProductsByCategory(String category) {
        return productRepository.findByCategory(category);
    }

    public Product updateStock(int id, int stock) {
        Product existingProduct = productRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Product not found"));
        existingProduct.setStock(stock);
        return productRepository.save(existingProduct);
    }

    public Product receiveNewShipment(int id, int quantity) {
        Product existingProduct = productRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Product not found"));
        existingProduct.setStock(existingProduct.getStock() + quantity);
        return productRepository.save(existingProduct);
    }
}
```

## GraphQL Schema Definition

Create a file named `schema.graphqls` in the `src/main/resources/graphql` directory:

```graphql
type Product {
    id: ID
    name: String
    category: String
    price: Float
    stock: Int
}

type Query {
    getProducts: [Product]
    getProductsByCategory(category: String): [Product]
}

type Mutation {
    updateStock(productId: ID, stock: Int): Product
    receiveNewShipment(productId: ID, quantity: Int): Product
}
```

## Entity Class and Repository Implementation

```java
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String name;
    private String category;
    private float price;
    private int stock;
}
```

```java
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {
    List<Product> findByCategory(String category);
}
```

## Example application.properties

```properties
spring.application.name=graphql-springboot
server.port=9090

# Database configuration
spring.datasource.url=jdbc:h2:mem:productdb
spring.datasource.driverClassName=org.h2.Driver
spring.datasource.username=sa
spring.datasource.password=
spring.jpa.database-platform=org.hibernate.dialect.H2Dialect
spring.h2.console.enabled=true
spring.datasource.auto-create=true

# GraphQL endpoint path (default is /graphql)
spring.graphql.path=/graphql

# Enable GraphiQL
spring.graphql.graphiql.enabled=true
spring.graphql.graphiql.path=/graphiql
```

## Testing with GraphiQL

Spring Boot with GraphQL provides an integrated GraphiQL interface for testing GraphQL queries. After running the application, navigate to [http://localhost:8080/graphiql](http://localhost:8080/graphiql) to interact with your API.

Here are some sample queries and mutations:

**Get All Products**
```graphql
query {
  getProducts {
    id
    name
    category
    price
    stock
  }
}
```

**Get Products by Category**
```graphql
query {
  getProductsByCategory(category: "Electronics") {
    id
    name
    price
    stock
  }
}
```

**Update Product Stock**
```graphql
mutation {
  updateStock(productId: 1, stock: 25) {
    id
    name
    category
    stock
  }
}
```

**Receive New Shipment**
```graphql
mutation {
  receiveNewShipment(productId: 2, quantity: 10) {
    id
    name
    category
    stock
  }
}
```

# Error Handling in GraphQL

GraphQL has a different approach to error handling compared to REST. Let’s enhance our application with proper error handling.

```java
package com.example.graphqlspringboot.exception;

import graphql.GraphQLError;
import graphql.GraphqlErrorBuilder;
import graphql.schema.DataFetchingEnvironment;
import org.springframework.graphql.execution.DataFetcherExceptionResolverAdapter;
import org.springframework.stereotype.Component;

@Component
public class GraphQLExceptionHandler extends DataFetcherExceptionResolverAdapter {

    @Override
    protected GraphQLError resolveToSingleError(Throwable ex, DataFetchingEnvironment env) {
        return GraphqlErrorBuilder.newError()
                .message(ex.getMessage())
                .path(env.getExecutionStepInfo().getPath())
                .location(env.getField().getSourceLocation())
                .build();
    }
}
```

# Advanced Features

## DataLoaders for Batch Loading

When dealing with complex data relationships, you might face the “N+1 queries” problem. GraphQL DataLoaders help solve this issue by batching and caching requests:

```java
import org.springframework.stereotype.Component;
import graphql.kickstart.tools.annotation.SchemaMapping;
import org.springframework.graphql.data.method.annotation.Argument;

import java.util.List;

@Component
public class ProductDataLoader {

    private final ProductRepository productRepository;

    public ProductDataLoader(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    @SchemaMapping(typeName = "Query", field = "productsByIds")
    public List<Product> getProductsByIds(@Argument List<Integer> ids) {
        return productRepository.findAllById(ids);
    }
}
```

## Subscriptions for Real-time Update

GraphQL also supports subscriptions for real-time updates. Let’s add a simple stock level subscription:

```graphql
# In GraphQL schema
type Subscription {
    stockLevelChanged: Product
}
```

```java
// In Java code
import org.springframework.graphql.data.method.annotation.SubscriptionMapping;
import org.springframework.stereotype.Controller;
import reactor.core.publisher.Flux;

@Controller
public class ProductSubscription {

    private final ProductPublisher productPublisher;

    public ProductSubscription(ProductPublisher productPublisher) {
        this.productPublisher = productPublisher;
    }

    @SubscriptionMapping
    public Flux<Product> stockLevelChanged() {
        return productPublisher;
    }
}
```

# Security Considerations

When implementing GraphQL APIs, consider these security aspects:

1.  **Query Complexity Analysis**: Prevent resource-exhausting queries
2.  **Rate Limiting**: Control the frequency of requests
3.  **Authentication and Authorization**: Protect sensitive operations
4.  **Input Validation**: Validate all client inputs

# Performance Optimization

For optimal GraphQL performance:

1.  **Query Depth Limiting**: Prevent deeply nested queries
2.  **Result Size Limiting**: Control response payload sizes
3.  **Caching**: Implement response caching
4.  **Pagination**: Use cursor-based pagination for large result sets

# Conclusion

GraphQL with Spring Boot offers a powerful alternative to traditional REST APIs, providing clients with the flexibility to request exactly the data they need. The strong typing, self-documenting nature, and single endpoint approach make it an excellent choice for modern applications with complex data requirements.

By implementing GraphQL in your Spring Boot applications, you can:

-   Reduce over-fetching and under-fetching of data
-   Create better developer experiences with strong typing and tooling
-   Enable clients to evolve independently of the server
-   Simplify API versioning
-   Build more responsive and efficient applications

The example provided in this article demonstrates basic GraphQL concepts with Spring Boot, but you can extend it with more complex features like relationships between entities, pagination, filtering, and advanced security measures.

Remember that GraphQL is not a replacement for REST in all cases — choose the approach that best fits your specific application requirements and constraints.


---
# Create Your First GraphQL API with Spring Boot

In this article, I will focus on **GraphQL with Spring Boot**, the leading enterprise-level application framework in the industry. If you are new to GraphQL, please read the article below for more details.

> [GraphQL, A Modern Approach to API Development](/@raviyasas/graphql-a-modern-approach-to-api-development-45c60a1b3d74)

---

## Project Structure

![Project Structure](https://miro.medium.com/v2/resize:fit:419/1*asoO26XNMyDmz-V0GsPcXQ.png)

## DB Script

```sql
-- public.client definition
CREATE TABLE public.client (
 id varchar NOT NULL,
 client_code varchar(255) NOT NULL,
 client_description varchar(255) NULL,
 client_name varchar(255) NOT NULL,
 is_active bool NULL,
 created_at timestamptz NULL,
 deleted_at timestamptz NULL,
 updated_at timestamptz NULL,
 created_by varchar(255) NULL,
 deleted_by varchar(255) NULL,
 updated_by varchar(255) NULL,
 CONSTRAINT client_pkey PRIMARY KEY (id)
);
```

## Required Dependencies

Add the following dependency to your `pom.xml`:

```xml
<dependency>
   <groupId>org.springframework.boot</groupId>
   <artifactId>spring-boot-starter-graphql</artifactId>
</dependency>
```

Enable GraphQL in **application.yml**:

```yaml
spring:
  graphql:
    graphiql:
      enabled: true
```

## schema.graphqls

Spring Boot natively supports the **schema-first** approach. Place your schema in `resources/graphql/schema.graphqls`.

```graphql
type ClientsResponseDto {
    success: Boolean!
    message: String!
    data: [Client!]!
}

type ClientResponseDto {
    success: Boolean!
    message: String!
    data: Client!
}

type BooleanResponseDto {
    success: Boolean!
    message: String!
    data: Boolean
}

type Client {
    id: String!
    clientName: String!
    clientCode: String!
    clientDescription: String
    isActive: Boolean
    createdAt: String!
    createdBy: String!
    updatedAt: String
    updatedBy: String
    deletedAt: String
    deletedBy: String
}

type Query {
    getAllClients: ClientsResponseDto!
    getClientById(id: String!): ClientResponseDto!
}

type Mutation {
    createClient(input: CreateClientInput!): ClientResponseDto!
    updateClient(input: UpdateClientInput!): ClientResponseDto!
    deleteClient(id: String!): BooleanResponseDto!
}

input CreateClientInput {
    clientName: String!
    clientCode: String!
    clientDescription: String
    isActive: Boolean
    createdBy: String
}

input UpdateClientInput {
    id: String!
    clientName: String
    clientCode: String
    clientDescription: String
    isActive: Boolean
    updatedBy: String
}
```

## Client Model

```java
package com.app.demo.client.model;

import com.app.demo.common.model.BaseModel;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "client")
@Data
public class Client extends BaseModel {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "id", nullable = false, updatable = false, columnDefinition = "uuid")
    private String id;

    @Column(name = "client_name", nullable = false)
    private String clientName;

    @Column(name = "client_code", nullable = false)
    private String clientCode;

    @Column(name = "client_description", nullable = true)
    private String clientDescription;

    @Column(name = "is_active")
    private Boolean isActive;
}
```

## Client Repository

```java
package com.app.demo.client.repository;

import com.app.demo.client.model.Client;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ClientRepository extends JpaRepository<Client, String> { }
```

## Client Service

```java
package com.app.demo.client.service;

import com.app.demo.client.dto.CreateClientInput;
import com.app.demo.client.dto.UpdateClientInput;
import com.app.demo.client.model.Client;
import com.app.demo.client.repository.ClientRepository;
import com.app.demo.common.dto.ResponseDto;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ClientService {
    private static final String DEFAULT_DELETED_BY = "graphql";
    private final ClientRepository clientRepository;

    @Transactional
    public ResponseDto<Client> createClient(CreateClientInput input) {
        try {
            if (input.clientName() == null || input.clientName().trim().isEmpty()) {
                return ResponseDto.error("Client name is required");
            }
            if (input.clientCode() == null || input.clientCode().trim().isEmpty()) {
                return ResponseDto.error("Client code is required");
            }
            if (input.createdBy() == null || input.createdBy().trim().isEmpty()) {
                return ResponseDto.error("CreatedBy is required");
            }
            Client client = new Client();
            client.setClientName(input.clientName().trim());
            client.setClientCode(input.clientCode().trim());
            client.setClientDescription(input.clientDescription());
            client.setIsActive(input.isActive() != null ? input.isActive() : true);
            client.setCreatedAt(currentTime());
            client.setCreatedBy(input.createdBy().trim());
            Client savedClient = clientRepository.save(client);
            return ResponseDto.ok(savedClient);
        } catch (Exception e) {
            return ResponseDto.error("Failed to create client: " + e.getMessage());
        }
    }

    @Transactional
    public ResponseDto<Client> updateClient(UpdateClientInput input) {
        try {
            Client client = clientRepository.findById(input.id()).orElseThrow(() -> new IllegalArgumentException("Client with ID " + input.id() + " not found"));
            Optional.ofNullable(input.clientName()).filter(name -> !name.trim().isEmpty()).ifPresent(name -> client.setClientName(name.trim()));
            Optional.ofNullable(input.clientCode()).filter(code -> !code.trim().isEmpty()).ifPresent(code -> client.setClientCode(code.trim()));
            Optional.ofNullable(input.clientDescription()).ifPresent(client::setClientDescription);
            Optional.ofNullable(input.isActive()).ifPresent(client::setIsActive);
            if (input.updatedBy() == null || input.updatedBy().trim().isEmpty()) {
                return ResponseDto.error("UpdatedBy is required");
            }
            client.setUpdatedAt(currentTime());
            client.setUpdatedBy(input.updatedBy().trim());
            Client updatedClient = clientRepository.save(client);
            return ResponseDto.ok(updatedClient);
        } catch (Exception e) {
            return ResponseDto.error("Failed to update client: " + e.getMessage());
        }
    }

    @Transactional
    public boolean softDeleteClient(String id) {
        return clientRepository.findById(id).map(client -> {
            client.setDeletedAt(currentTime());
            client.setDeletedBy(DEFAULT_DELETED_BY);
            clientRepository.save(client);
            return true;
        }).orElse(false);
    }

    public ResponseDto<List<Client>> getAllClients() {
        return ResponseDto.ok(clientRepository.findAll());
    }

    public ResponseDto<Optional<Client>> getClientById(String id) {
        Optional<Client> client = clientRepository.findById(id);
        if (client.isEmpty()) {
            return ResponseDto.error("Client not found");
        }
        return ResponseDto.ok(client);
    }

    private LocalDateTime currentTime() {
        return LocalDateTime.now();
    }
}
```

## Client Query Resolver

```java
package com.app.demo.client.resolver;

import com.app.demo.client.model.Client;
import com.app.demo.client.service.ClientService;
import com.app.demo.common.dto.ResponseDto;
import lombok.RequiredArgsConstructor;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;
import java.util.List;
import java.util.Optional;

@Controller
@RequiredArgsConstructor
public class ClientQueryResolver {
    private final ClientService clientService;

    @QueryMapping
    public ResponseDto<List<Client>> getAllClients() {
        return clientService.getAllClients();
    }

    @QueryMapping
    public ResponseDto<Optional<Client>> getClientById(@Argument String id) {
        if (id == null || id.trim().isEmpty()) {
            return ResponseDto.error("Id cannot be null");
        }
        return clientService.getClientById(id);
    }
}
```

## Client Mutation Resolver

```java
package com.app.demo.client.resolver;

import com.app.demo.client.dto.CreateClientInput;
import com.app.demo.client.dto.UpdateClientInput;
import com.app.demo.client.model.Client;
import com.app.demo.client.service.ClientService;
import com.app.demo.common.dto.ResponseDto;
import lombok.RequiredArgsConstructor;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.stereotype.Controller;

@Controller
@RequiredArgsConstructor
public class ClientMutationResolver {
    private final ClientService clientService;

    @MutationMapping
    public ResponseDto<Client> createClient(@Argument CreateClientInput input) {
        if (input == null) {
            return ResponseDto.error("Input data is null");
        }
        return clientService.createClient(input);
    }

    @MutationMapping
    public ResponseDto<Client> updateClient(@Argument UpdateClientInput input) {
        if (input == null) {
            return ResponseDto.error("Input data is null");
        }
        return clientService.updateClient(input);
    }

    @MutationMapping
    public ResponseDto<Boolean> deleteClient(@Argument String id) {
        boolean deleted = clientService.softDeleteClient(id);
        if (deleted) {
            return ResponseDto.ok(true);
        }
        return ResponseDto.error("Client not found");
    }
}
```

---

## Run the API

You can run the GraphQL playground in Postman or a browser. Example output:

![Sample output](https://miro.medium.com/v2/resize:fit:875/1*NIreVKYd-s_El6JpYeIbgA.png)

> 🔗 [Github link for the complete source code](https://github.com/raviyasas/spring-boot-graphql-demo)

---

## What are the best practices that you can use?

I’ve intentionally skipped best practices and design patterns in this article to keep things simple and help you focus on understanding GraphQL itself.

-   Create a Base entity that has all common attributes that an entity has.
-   Handle exceptions at the relevant levels.
-   Create a common response using the Builder design pattern. You may read this article, [**Practical Use of the Builder Design Pattern in Spring Boot**](/@raviyasas/practical-use-of-the-builder-design-pattern-in-spring-boot-7fbeef231b16) In this article, I clearly explained how to create a common flexible response.
-   Create a service interface to make the app loosely coupled and improve reusability.
-   Read this article for more important info: [**Spring Boot Best Practices for Developers**](/@raviyasas/spring-boot-best-practices-for-developers-3f3bdffa0090). This article will cover a wide range of topics.

I hope you enjoyed this article. Please check out my articles related to **Spring Boot** for your reference. I’d greatly appreciate it if you could help spread the word by sharing them with your network or developer community.

[**Spring Boot New Features and Best Practices for Developers 2025**](/@raviyasas/spring-boot-new-features-and-best-practices-for-developers-2025-b0016fb6c0ca) 😍😍😍

[**How to Optimize Your Spring Boot App Performance**](/@raviyasas/spring-boot-performance-upgrade-for-developers-f26ee1095d2e) 🚀🚀🚀

[**Which is the best, NestJS or Spring Boot?**](/@raviyasas/which-is-the-best-nestjs-or-spring-boot-33393612790d) 💯💯💯

[**Spring Boot Best Practices for Developers**](/@raviyasas/spring-boot-best-practices-for-developers-3f3bdffa0090) 💪💪💪

[**Practical use of the Builder design pattern in Spring Boot**](/@raviyasas/practical-use-of-the-builder-design-pattern-in-spring-boot-7fbeef231b16) 👷👷👷

[**The beginner’s guide — Transaction in Spring**](/@raviyasas/beginner-guide-transaction-in-spring-boot-65847ef16cc7) 🛑🛑🛑

[**Spring Boot file upload with Google Cloud Storage**](/@raviyasas/spring-boot-file-upload-with-google-cloud-storage-5445ed91f5bc) ☁️☁️☁️

[**How to use OpenAI with Spring Boot**](/@raviyasas/how-to-use-chatgpt-with-spring-boot-7f801855876f) 🤖🤖🤖

**Enjoyed this article?** If you found this helpful, consider supporting my work by buying me a coffee! Your support helps me create more content like this. 🚀☕

👉 [Buy Me a Coffee](http://buymeacoffee.com/raviyasas) ☕☕☕

---
# Build a GraphQL Server With Spring Boot and MySQL

Have you ever wondered if a client can impact an API request? Can they request what they actually need and get exactly that? If you’re surprised by these questions, you’ve probably never heard about GraphQL.

> With GraphQL, the answer is yes: clients can request exactly what they need and get just that.

## The First Step to GraphQL

GraphQL is a data query and manipulation language for your API. It exposes a single endpoint that receives a query from the front-end as part of the request, returning exactly the requested parts of data in a single response.

![How GraphQL works](https://miro.medium.com/v2/resize:fit:875/1*aXd1Atpt9B8QI2s9r3r_Ew.gif)

GraphQL is used in production by hundreds of organizations including Facebook, Credit Karma, GitHub, Intuit, PayPal, and the New York Times.

## The Battle: GraphQL Vs REST

REST is an architectural concept for network-based software. GraphQL, on the other hand, is a query language, a specification, and a set of tools that operates over a single endpoint.

> With REST, you might need multiple endpoints to fetch related data. With GraphQL, you can fetch all the data you need in a single request.

Example REST endpoints:
```
localhost:8080/book/:id
localhost:8080/author/:id
```
Example GraphQL endpoint:
```
localhost:8080/graphql
```

With GraphQL, you can limit the fields returned and avoid under-fetching or over-fetching data.

## Setting Up the Project

We'll create an app for fetching users and their posts, called **WriteUp**. Add these dependencies:
- Spring Data JPA
- MySQL Driver
- Lombok

## Configuring the Basics

Create entity models and add some dummy data to your MySQL database.

### User Entity Example

```java
package com.example.writeup.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "USER")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "USER_ID")
    private Integer userId;

    @Column(name = "FIRST_NAME")
    private String firstName;

    @Column(name = "LAST_NAME")
    private String lastName;

    @Column(name = "DOB")
    private Date dob;

    @Column(name = "ADDRESS")
    private String address;

    @Column(name = "POST_ID")
    private Integer postId;

    public User(String firstName, String lastName, Date dob, String address, Integer postId) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.dob = dob;
        this.address = address;
        this.postId = postId;
    }
}
```

### User Repository Example

```java
package com.example.writeup.repository;

import com.example.writeup.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
}
```

### Data Loader Service Example

```java
package com.example.writeup.service;

import com.example.writeup.model.Post;
import com.example.writeup.model.User;
import com.example.writeup.repository.PostRepository;
import com.example.writeup.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.annotation.PostConstruct;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class DataLoader {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private PostRepository postRepository;

    @PostConstruct
    public void loadData() {
        User user1 = new User("Yasas", "Sandeepa", DataLoader.getRandomDate(), "Mount Pleasant Estate Galle", 1);
        User user2 = new User("Sahan", "Rambukkna", DataLoader.getRandomDate(), "Delkanda Nugegoda", 2);
        User user3 = new User("Ranuk", "Silva", DataLoader.getRandomDate(), "Yalawatta gampaha", 3);
        Post post1 = new Post("Graphql with SpringBoot", DataLoader.getRandomDate());
        Post post2 = new Post("Flutter with Firebase", DataLoader.getRandomDate());
        Post post3 = new Post("Nodejs Authentication with JWT", DataLoader.getRandomDate());
        postRepository.save(post1);
        postRepository.save(post2);
        postRepository.save(post3);
        userRepository.save(user1);
        userRepository.save(user2);
        userRepository.save(user3);
    }

    public static Date getRandomDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, 1990);
        calendar.set(Calendar.MONTH, 1);
        calendar.set(Calendar.DATE, 2);
        Date date1 = calendar.getTime();
        calendar.set(Calendar.YEAR, 1996);
        Date date2 = calendar.getTime();
        long startMillis = date1.getTime();
        long endMillis = date2.getTime();
        long randomMillisSinceEpoch = ThreadLocalRandom.current().nextLong(startMillis, endMillis);
        return new Date(randomMillisSinceEpoch);
    }
}
```

### User Service Example (Query Resolver)

```java
package com.example.writeup.service;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.example.writeup.model.User;
import com.example.writeup.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class UserService implements GraphQLQueryResolver {
    @Autowired
    private UserRepository userRepository;
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
}
```

### User Service Example (Query & Mutation Resolver)

```java
package com.example.writeup.service;

import com.coxautodev.graphql.tools.GraphQLMutationResolver;
import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.example.writeup.model.User;
import com.example.writeup.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class UserService implements GraphQLQueryResolver, GraphQLMutationResolver {
    @Autowired
    private UserRepository userRepository;
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
    public User updateUserAddress(Integer userId, String address) throws Exception {
        try {
            userRepository.updateUserAddress(address, userId);
            User user = userRepository.findById(userId).get();
            return user;
        } catch (Exception e) {
            throw new Exception(e);
        }
    }
}
```

### User Repository with Custom Update

```java
package com.example.writeup.repository;

import com.example.writeup.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
    @Transactional
    @Modifying
    @Query(value = "UPDATE user SET address = ?1 WHERE user_id = ?2 ", nativeQuery = true)
    int updateUserAddress(String address, Integer user_id);
}
```

### Example GraphQL Schema

```graphql
schema {
    query: Query,
    mutation: Mutation,
}

type Query {
    # Fetch All Users
    getAllUsers: [User]
}

type Mutation {
    # Update the user address
    updateUserAddress(userId: Int, address: String): User
}

type User {
    userId: ID!
    firstName: String
    lastName: String
    dob: String
    address: String
    postId: Int
}
```

### Example application.properties

```properties
server.port=7000
#mysql properties
spring.jpa.generate-ddl=true
spring.datasource.url=jdbc:mysql://localhost/writeup
spring.datasource.username=user
spring.datasource.password=password
spring.datasource.driverClassName=com.mysql.cj.jdbc.Driver
spring.jpa.hibernate.ddl-auto=create
#graphql properties
graphql.servlet.corsEnabled=true
graphql.servlet.mapping=/graphql
graphql.servlet.enabled=true
```

---

## Conclusion

With GraphQL and Spring Boot, you can build flexible APIs that allow clients to request exactly the data they need. This guide covered the basics of setting up a GraphQL server with Spring Boot and MySQL, including entity modeling, repository setup, data loading, schema definition, and resolver implementation.

For more details and the complete source code, see the [WriteUp GitHub repository](https://github.com/Yasas4D/WriteUp).

---
# GraphQL in Spring Boot : A comparative study among the libraries and their implementation know-how

> GraphQL is a query language for APIs and a runtime for fulfilling those queries with your existing data. GraphQL provides a complete and understandable description of the data in your API, gives clients the power to ask for exactly what they need and nothing more, makes it easier to evolve APIs over time, and enables powerful developer tools.
> 
> From [https://graphql.org/](https://graphql.org/)

It was introduced to “query what you need”. With traditional REST, the clients are bounded by the interface exposed, even though some attributes or objects are not needed, there is no way to filter that out. Also adds overhead to the server to fetch, aggregate and process that data before sending it back.

So Facebook designed it to get around common constraints in fetching data via REST and was open sourced in 2015.

Since then, a lot of development and innovation happened in the GraphQL space and specifically how to write such APIs in Java and Spring Boot.

In this blog, I will go through the available libraries we have, to implement GraphQL in Spring Boot and a comprehensive comparison on different aspects of these libraries.

# The Libraries

There are 3 libraries to write GraphQL APIs in Spring Boot. All these libraries are active and back by a very enthusiastic community. Below are the details of these libraries as of August’21.

**graphql-java**

This it the recommended library listed in graphql.org. The oldest one to implement GraphQL in Java.

![](https://miro.medium.com/v2/resize:fit:844/1*WWR9ChWDcqZBekPaWB6yGA.png)

The current version is 17.0 and last released on Aug’21.

Documentation: [https://www.graphql-java.com/](https://www.graphql-java.com/)

Code: [https://github.com/graphql-java](https://github.com/graphql-java)

This library requires an extra dependency for Spring Boot. They also have a reactive version (instead of webmvc, it is webflux)

![](https://miro.medium.com/v2/resize:fit:851/1*c7OOUEeTgAKDEfZ1jsEIcA.png)
pom dependencies for graphql-java

**graphql-java-kickstart**

Introduced in 2018, this library has all you need for a Spring Boot application in one artifact. Originally was part of graphql-java but separated in a later stage.

![](https://miro.medium.com/v2/resize:fit:844/1*VAuXw99jXWCPebGpVYSDeA.png)

Current version is 11.1.0 and was last released on May’21

Documentation: [https://graphql-java-kickstart.com/](https://graphql-java-kickstart.com/)

Code: [https://github.com/graphql-java-kickstart](https://github.com/graphql-java-kickstart)

You only need one dependency to start writing graphql APIs. .

![](https://miro.medium.com/v2/resize:fit:851/1*gJYfySieM8oalWNLSiMBww.png)
pom dependency for graphql-java-kickstart

**dgs-framework**

Released/Open-sourced on November’20, developed Netflix, this library is the latest addition to the graphql community with Spring Boot. And from the looks of it, this library has it all.

Current version is 4.5.0 and last released on July’21.

Documentation: [https://netflix.github.io/dgs/](https://netflix.github.io/dgs/)

Code: [https://github.com/Netflix/dgs-framework](https://github.com/Netflix/dgs-framework)

You only need one dependency to start coding GraphQL APIs with this library.

![](https://miro.medium.com/v2/resize:fit:851/1*uAo6NEaP9fwpb89srlIZkw.png)
pom dependency for dgs-framework

# Comparative study

## Application Architecture

How does your code base look like if you want to implement GraphQL with any of these libraries.

I will take an example of a simple microservice, implemented with Controller-Service-Repository architecture with an H2 database in-memory. But you can also choose to replace the repository with external service/endpoint calls without changing the way you would expose GraphQL.

**Sample baseline application**

For the sample baseline application to compare with I will refer to a [previous blog](/springboot-chronicles/api-first-approach-with-openapi-contracts-maven-spring-boot-6aa9b9251341) I wrote.

Code: [https://github.com/sohamda/serivce-repository-swagger](https://github.com/sohamda/serivce-repository-swagger)

![](https://miro.medium.com/v2/resize:fit:875/1*MnWZGp6w_zAZ_lBoTHf8rw.png)
baseline application structure

**Application architecture for “graphql-java”**

You need Dataloader & Datafetcher to map Service/Repository implementations, Dataregistry to map N+1 queries to DataLoaders, GraphQLSchema for parsing the graphql schema and Runtimewiring to map queries and mutations to Datafetchers.

![](https://miro.medium.com/v2/resize:fit:875/1*JncfgyiPdNmzygGNQudVTg.png)
graphql-java application structure

**Application architecture for “graphql-java-kickstart”**

You need Resolvers to map graphql schema definitions to Service/Repository methods, DataRegistry to map N+1 queries and GraphQLServletContextBuilder to define Dataregistry.

![](https://miro.medium.com/v2/resize:fit:875/1*7nsIt27wihFh09ziOaeV3w.png)
graphql-java-kickstart application structure

**Application architecture for “dgs-framework”**

This uses a annotation based model, so @DgsData for mapping graphql schema definitions and @DgsDataLoader for N+1 queries.

![](https://miro.medium.com/v2/resize:fit:875/1*cvM3nw0AR-4tVG0HPl_w7w.png)
dgs-framework application structure

# Code level comparison among the 3 libraries

## Code structure with “graphql-java”

Following are the implementation details of GraphQL API with “graphql-java” libary.

The code is in Github: [https://github.com/sohamda/graphql-java](https://github.com/sohamda/graphql-java)

1.  Create @Component classes to define the DataFetchers. These have methods with return type DataFetcher which maps to the Service or Repository methods.
2.  Define a @Component class to define a GraphQL bean.
3.  In a @PostConstruct of this class, parse/build the graphql schema.
4.  Also define the mapping(RuntimeWiring) of the graphql schema definitions (query, mutation, field-level mapping) to associated DataFetchers, defined in Step #1.
5.  For N+1 queries, define a DataLoader(method with return type BatchLoader/MapLoader) in a @Component class. Then define a DataLoaderRegistry bean which maps the DataLoader to a “key”. This key will be the trigger for the runtime to invoke the DataLoader.

![](https://miro.medium.com/v2/resize:fit:875/1*NbOKJOZ5JhbI6irCK1ChrQ.png)
example: graphql-java

## Code structure with “graphql-java-kickstart”

Following are the implementation details of GraphQL API with “graphql-java-kickstart” libary.

The code is in Github: [https://github.com/sohamda/graphql-java-kickstart](https://github.com/sohamda/graphql-java-kickstart)

1.  Define @Component class for mapping the graphql schema Query operations which implements GraphQLQueryResolver. The query definitions should match the method names. That’s how the schema to code mapping happens at runtime. Within these methods you call the Service or Repository classes.
2.  Define @Component class for mapping the graphql schema Mutation operations which implements GraphQLMutationResolver. The query definitions should match the method names. That’s how the schema to code mapping happens at runtime. Within these methods you call the Service or Repository classes.
3.  Define @Component class for the field-level mappings, this should implement GraphQLResolver<T>. Within these methods you call the Service or Repository classes.
4.  For N+1 queries, define a @Component class which defines the DataLoader and defines the DataLoaderRegistry. Then define another @Component class which implements GraphQLServletContextBuilder to actually register the DataLoaderRegistry.

![](https://miro.medium.com/v2/resize:fit:875/1*jmeIvHnPY_O9PTsUTcCHsw.png)
example: graphql-java-kickstart

## Code structure with “dgs-framework”

Following are the implementation details of GraphQL API with “dgs-framework” libary.

The code is in Github: [https://github.com/sohamda/graphql-dgs-netflix](https://github.com/sohamda/graphql-dgs-netflix)

1.  Define a class with @DgsComponent annotation and declare methods with @DgsData annotations to map graphql schema query, mutations and field-level mappings. Within these methods you call the Service or Repository classes.
2.  For N+1 queries, define a class with @DgsDataLoader which implements BatchLoader or MapLoader and implement the required method to return a CompletableFuture.

![](https://miro.medium.com/v2/resize:fit:875/1*2eMBio3q8fmIlTLUTpBwrw.png)
example: dgs-framework

## Error handling with “graphql-java”, “graphql-java-kickstart” and “dgs-framework”

It is important to mention, a GraphQL API always returns a 200, even in the case of server side exceptions and errors, what you get back is an error object with details of the error in it.

All these 3 libraries have their own way of handling errors.

1.  graphql-java: You need to implement GraphQLError interface and override the methods.
2.  graphql-java-kickstart: This library provides two ways to handle errors, the spring boot way of defining exception handler beans or a component class which implements GraphQLErrorHandler and there you can manage the errors the way you want to.
3.  dgs-framework: You need to define a component which implements DataFetcherExceptionHandler and then manage the errors inside the overridden method.

![](https://miro.medium.com/v2/resize:fit:875/1*KL9YA3jHMABdZ90zl5AjlA.png)
example: error handling in 3 different libraries

## Java client for “graphql-java”, “graphql-java-kickstart” and “dgs-framework”

While it is quite interesting to implement the server side of GraphQL APIs, but it is also quite important to explore on how would such APIs will be consumed.

1.  graphql-java: This library has no defined way to create Java clients. The only way to do it is define some text templates(mustach) and generate the query and mutation request at runtime. Then just use RestTemplate/Feign/Webclient (or your choice of client library) to do a post request to the endpoint.
2.  graphql-java-kickstart: This library provides a Webclient library to call a GraphQL endpoint, but although you still need to use text templates(mustach) to generate the query and mutation request at runtime.
3.  dgs-framework: This library provides GraphQLClient which can be used with text templates as the previous two. But they also provides a Gradle plugin to generate the model classes, which you can use to generate the request in a type-safe way. This is a huge improvement from the text templates, since the schema file can be used as single source of truth for server side as well as client side.

You can find the sample client code in here: [https://github.com/sohamda/graphql-restclient](https://github.com/sohamda/graphql-restclient)

## Image-size & Runtime memory consumption for “graphql-java”, “graphql-java-kickstart” and “dgs-framework”

If containerized and ran on a container platform the applications doesn’t show that much of a difference in image sizes or memory consumption on the tests I did on my sample applications.

![](https://miro.medium.com/v2/resize:fit:875/1*hD2zulLi2t1-m9eptWLxEg.png)
example: image sizes & runtime memory

# Final Words

Been working with all 3 of these libraries for sometime now, although dgs-framework is very new but the other libs are very matured and has evolved with the time. All these libraries have a strong community presence, so it is easy to find help around specific questions/issues. So, it doesn’t really matter which one you choose to implement your GraphQL endpoints. But, as an honest opinion from the author self, “dgs-framework” is a winner for me here.

“dgs-framework” is being used internally at Netflix for couple of years before they open-sourced it. Implementation easiness, annotation driven structure, code-generation, error handling flexibility are the strongest points of this library over others. So my recommendation : dgs-framework

All code used for this blog can be found [here](https://github.com/sohamda?tab=repositories&q=graph&type=&language=&sort=).

---
# GraphQL With Spring Boot: Introduction

## Introduction

In this article, I’ll explain how to integrate a GraphQL API with a Spring Boot application and perform create, read, and delete operations on a MySQL Database. We’ll implement GraphQL queries, mutations, and exception handling.

---

## What is API?

An **API** (Application Programming Interface) is a way to communicate between different software services over the internet. Web APIs allow developers to send and receive instructions and data between a web server and a web browser, usually in JSON format, to build applications.

---

## What is GraphQL?

GraphQL is an open-source query language for APIs that allows you to fetch and manipulate your data. Its functionality is similar to REST APIs, but it offers architectural and behavioral improvements.

---

## Why Use GraphQL Over Traditional REST API?

- **Over- and Under-fetching Data is Avoided:**
  - *Over-fetching* happens when the response fetches more than is required. With GraphQL, you define the fields you want to fetch, and it returns only the requested data.
  - *Under-fetching* is not fetching adequate data in a single API request. GraphQL lets you fetch all relevant data in a single query.
- **Queries Return Predictable Results**
- **Apps are Fast and Stable**
- **Network and Memory Usage Decrease**
- **No Need for Endpoint Versioning**

---

## GraphQL Operation Types

- **Query:** Used to fetch/read data
- **Mutation:** Used to create, update, and delete data
- **Subscription:** Used to fetch data that changes over time (real-time updates)

---

## What is a Schema?

A schema is the entry point for the application and specifies GraphQL data types, queries, and mutations. It has a `.graphqls` file extension.

---

## What is a Resolver?

Resolvers map the schema to the data model in your application. They connect GraphQL fields, queries, mutations, and subscriptions to their respective data sources.

---

## Objective

The goal of this example is to build GraphQL APIs to perform CRUD operations with a MySQL database. This exercise is around post and comment data, where each post has many comments (One-to-Many relationship).

---

## Technology

- Java 8
- Spring Boot 2.7.8.RELEASE (Spring Web, Spring Data JPA, mysql-connector)
- graphql-spring-boot-starter 12.0.0
- graphiql-spring-boot-starter 11.1.0
- Gradle build tool

---

## Project Structure

![Project Structure](https://miro.medium.com/v2/resize:fit:434/1*KPxwetMVzHGJnyHdQPNZqw.jpeg)

---

## Set Up the Project

- Create a Spring Boot application at [Spring Initializr](https://start.spring.io).
- Choose Gradle or Maven as the build tool (this example uses Gradle and Java 18).

**Sample `build.gradle` dependencies:**

```groovy
plugins {
    id 'java'
    id 'org.springframework.boot' version '2.7.8'
    id 'io.spring.dependency-management' version '1.0.15.RELEASE'
}
group = 'com.graphql'
version = '0.0.1-SNAPSHOT'
sourceCompatibility = '17'
repositories {
    mavenCentral()
}
dependencies {
    implementation 'org.springframework.boot:spring-boot-starter-data-jpa'
    implementation 'com.graphql-java-kickstart:graphql-spring-boot-starter:12.0.0'
    implementation 'com.graphql-java-kickstart:graphiql-spring-boot-starter:11.1.0'
    implementation 'org.springframework.boot:spring-boot-starter-web'
    runtimeOnly 'com.mysql:mysql-connector-j'
    developmentOnly 'org.springframework.boot:spring-boot-devtools'
    implementation group: 'org.modelmapper', name: 'modelmapper', version: '2.1.1'
}
tasks.named('test') {
    useJUnitPlatform()
}
```

**Sample `application.properties`:**

```properties
spring.jpa.hibernate.ddl-auto=update
spring.datasource.url=jdbc:mysql://localhost:3306/test_graphql
spring.datasource.username=root
spring.datasource.password=amila
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
```

**Sample data in `data.sql`:**

```sql
insert into posts (id, content, is_display, name, no_of_likes) values (1, 'Java is a oop language and it is a one of most popular open source language', true, 'About Java', 6);
insert into posts (id, content, is_display, name, no_of_likes) values (2, 'GraphQL is a query language for APIs and a runtime for fulfilling those queries with your existing data.', true, 'About GraphQl', 10);
insert into posts (id, content, is_display, name, no_of_likes) values (3, 'React is a free and open-source front-end JavaScript library for building user interfaces based on components', true, 'About React', 8);
insert into post_comments (id, coment_content, post_id) values (1, 'Very informative', 1);
insert into post_comments (id, coment_content, post_id) values (2, 'Very nice post', 1);
insert into post_comments (id, coment_content, post_id) values (3, 'Please give sample code', 2);
insert into post_comments (id, coment_content, post_id) values (4, 'Very informative', 2);
insert into post_comments (id, coment_content, post_id) values (5, 'You make my day,thanks in advanced', 1);
insert into post_comments (id, coment_content, post_id) values (6, 'Nice article', 3);
```

---

## Create GraphQL Schema

Create `queryPosts.graphqls` and `mutationPosts.graphqls` under `src/main/resources/schema.post`.

**Sample `queryPosts.graphqls`:**

```graphql
type Query {
    allPosts: PostContentDTO
    getPosts(PostId: Float!): PostContentDTO
}

type PostContentDTO {
    statusCode: Int!
    totalRecord: Int!
    postList: [PostDTO]
}

type PostDTO {
    id: Float
    name: String
    content: String
    noOfLikes: Int
    isDisplay: Boolean
    comments: [PostCommentsDTO]
}

type PostCommentsDTO {
    id: Float
    comentContent: String
}
```

**Sample `mutationPosts.graphqls`:**

```graphql
type Mutation {
    createPosts(createPostDTO: CreatePostDTO): Posts
    deletePosts(postId: Float!): String
}

input CreatePostDTO {
    postName: String
    postContent: String
    noOfLikes: Int
    postIsDisplay: Boolean
}

type Posts {
    id: Float
    name: String
    content: String
    noOfLikes: Int
    isDisplay: Boolean
    comments: [PostComments]
}

type PostComments {
    id: Float
    comentContent: String
}
```

---

## Define Data Models

### Posts.java

```java
@Entity
public class Posts {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String content;
    private int noOfLikes;
    private boolean isDisplay;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @JoinColumn(name = "post_id")
    private List<PostComments> comments = new ArrayList<>();
    // Getters and Setters
}
```

### PostComments.java

```java
@Entity
public class PostComments {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String comentContent;
    public PostComments() { super(); }
    // Getters and Setters
}
```

---

## Define DTO (Data Transfer Objects) Models

### PostContentDTO.java

```java
public class PostContentDTO extends CommonResponse {
    private List<PostDTO> postList;
    public PostContentDTO() { super(); }
    public List<PostDTO> getPostList() { return postList; }
    public void setPostList(List<PostDTO> postList) { this.postList = postList; }
    @Override
    public String toString() { return "PostContentDTO [postList=" + postList + "]"; }
}
```

### PostDTO.java

```java
public class PostDTO implements Serializable {
    private Long id;
    private String name;
    private String content;
    private int noOfLikes;
    private boolean isDisplay;
    private List<PostCommentsDTO> comments;
    // Getters and Setters
}
```

---

## Create Repositories

```java
@Repository
public interface PostRepository extends JpaRepository<Posts, Long> {
}
```

---

## Define Service Layer

```java
@Service
public class PostsService {
    private PostRepository postRepository;
    private ModelMapper modelMapper;
    @Autowired
    public PostsService(PostRepository postRepository, ModelMapper modelMapper) {
        this.postRepository = postRepository;
        this.modelMapper = modelMapper;
    }
    public PostContentDTO getPosts(Long PostId) {
        PostContentDTO postContentDto = new PostContentDTO();
        Optional<Posts> post = postRepository.findById(PostId);
        if (!post.isPresent()) {
            throw new ResourceNotFoundException("Unable to find post with given post id :" + PostId);
        }
        PostDTO postDto = this.modelMapper.map(post.get(), PostDTO.class);
        List<PostDTO> objects = Collections.singletonList(postDto);
        postContentDto.setStatusCode(HttpStatus.FOUND.value());
        postContentDto.setTotalRecord(1);
        postContentDto.setPostList(objects);
        return postContentDto;
    }
    public PostContentDTO allPosts() {
        PostContentDTO postContentDto = new PostContentDTO();
        List<Posts> post = postRepository.findAll();
        List<PostDTO> objectList = new ArrayList<>();
        post.stream().forEach(postObj -> objectList.add(this.modelMapper.map(postObj, PostDTO.class)));
        postContentDto.setStatusCode(HttpStatus.FOUND.value());
        postContentDto.setTotalRecord(post.size());
        postContentDto.setPostList(objectList);
        return postContentDto;
    }
    public Posts createPost(CreatePostDTO createPostDTO) {
        Posts post = this.modelMapper.map(createPostDTO, Posts.class);
        postRepository.save(post);
        return post;
    }
    public void deletePost(Long postId) {
        Optional<Posts> post = postRepository.findById(postId);
        if (post.isPresent()) {
            postRepository.deleteById(postId);
        } else {
            throw new ResourceNotFoundException("Unable to find post with given post id :" + postId);
        }
    }
}
```

---

## Implement GraphQL Query Resolver

```java
@Component
public class PostsQueryResolver implements GraphQLQueryResolver {
    private final PostsService postsService;
    @Autowired
    public PostsQueryResolver(PostsService postsService) {
        super();
        this.postsService = postsService;
    }
    public PostContentDTO getPosts(Long PostId) {
        return postsService.getPosts(PostId);
    }
    public PostContentDTO allPosts() {
        return postsService.allPosts();
    }
}
```

---

## Implement GraphQL Mutation Resolver

```java
@Component
public class PostMutationResolver implements GraphQLMutationResolver {
    @Autowired
    private ModelMapper modelMapper;
    @Autowired
    private PostsService postsService;
    public Posts createPosts(CreatePostDTO createPostDTO) {
        return postsService.createPost(createPostDTO);
    }
    public String deletePosts(Long postId) {
        postsService.deletePost(postId);
        return "Deleted post Id :" + postId;
    }
}
```

---

## Error Handling

All errors in GraphQL go through the `GraphQlErrorHandler` interface. You can implement a custom error handler as follows:

```java
public class ResourceNotFoundException extends RuntimeException implements GraphQLError {
    public ResourceNotFoundException(String message) {
        super(message);
    }
    @Override
    public List<SourceLocation> getLocations() {
        // specify the location where error happens
        return null;
    }
    @Override
    public ErrorClassification getErrorType() {
        return ErrorType.DataFetchingException;
    }
}
```

---

## Run & Check Result

Run the Spring Boot application with:

```shell
mvn spring-boot:run
```

Then access [http://localhost:8080/graphiql](http://localhost:8080/graphiql) to use the GraphQL playground and query data from your browser. You can also use Postman.

---

## Example Screenshots

- Get posts by Id:
  ![](https://miro.medium.com/v2/resize:fit:875/1*TlT1QtFH6bmmQSVLZxis_A.jpeg)
- Get all posts:
  ![](https://miro.medium.com/v2/resize:fit:875/1*3GGVxypg2lZUpGwiZw-1TA.jpeg)
- Save post using mutation:
  ![](https://miro.medium.com/v2/resize:fit:875/1*jBmcKY4EGEvAiJ6Ez8RGBw.jpeg)
- Check mutation via db:
  ![](https://miro.medium.com/v2/resize:fit:875/1*3xYCrTLrEcpHAbTs5l0ZzQ.jpeg)
- Delete post:
  ![](https://miro.medium.com/v2/resize:fit:875/1*RDIz1tak8eV7tiTwcBxpwQ.jpeg)
- Delete post with non-existing id:
  ![](https://miro.medium.com/v2/resize:fit:875/1*-5ScQ4SLchaqkFXQKdb1qw.jpeg)
- Informative exception after error handle:
  ![](https://miro.medium.com/v2/resize:fit:875/1*I4I_AlHk2RwSmyfFmPJElQ.jpeg)

# GraphQL Types | Medium

If you are new to GraphQL, I highly recommend checking out my [previous article](/@dhakresumitra5/graphql-with-spring-boot-java-d2fa3ca1b12c). In this article, we’ll see GraphQL types and queries in more detail. The requirements to start are the same as mentioned in the previous article.

As the `@Autowired` annotation is optional, the first thing I did was to replace all `@Autowired` annotations with constructors. With Lombok, it is much easier to do.

![BookQuery Resolver Class](https://miro.medium.com/v2/resize:fit:875/1*D74Ob_q09kM0VTfzjYej-A.png)

The code looks much cleaner. No more boring getters and setters. Now let’s code the GraphQL schema according to the [GraphQL rules](https://graphql-rules.com/rules/credits). There are many rules mentioned, but we’ll be looking at a few of them. First, I decided to split the schema into multiple files to make it more manageable and coherent with the names of the `.graphqls` files.

![Schema Files](https://miro.medium.com/v2/resize:fit:431/1*sjqHaI0k-KCYR6I_LNWtMw.png)

I moved all _author-related_ schema to `author.graphqls`, same for the _books-related_ schema. And I created `query.graphqls` for all _queries_ and _mutations_. Thanks to [graphql-java-kickstart](https://github.com/graphql-java-kickstart), all schema files were picked up automatically.

---

## Input Types

GraphQL offers a basic set of [scalar types](https://graphql.org/learn/schema/#scalar-types) such as `String`. These basic scalars are used as arguments for fields and queries. This is ok if you have few arguments, but if you have multiple it gets tedious to manage. In such cases, grouping all arguments into objects is much better. This is where GraphQL [input types](https://graphql.org/learn/schema/#input-types) come into the picture, especially in the case of mutations. In the schema, it looks similar to regular object types but has an `input` keyword to define it instead of the `type`.

Let’s change the simple query **getBookByName** by adding an input type. To do that, I added a field **filter** in the query of the type **BankFilter**.

![All bookApi queries](https://miro.medium.com/v2/resize:fit:681/1*eMXgejUUBZqrmHykYT_yWA.png)

The **BankFilter** has the same content in the schema as in the Java class.

![BookFilter class](https://miro.medium.com/v2/resize:fit:456/1*ztXNZNaVzm3r77hJN42RUQ.png)

Now let's build the project and run the docker containers to test it.

```shell
mvn clean install
docker-compose up -d
```

![getBookByName query in postman](https://miro.medium.com/v2/resize:fit:875/1*LIgauXl2lsGWNd03G9qCkA.png)

Unlike before, the query argument **filter** is a complex input object of the type **BankFilter**. Therefore, we define its field **name** inside the curly brackets. It gives you the flexibility to add future parameters without changing the actual query.

For just one argument it doesn’t look much useful. But when you have multiple arguments, like for mutations, it’s very practical.

![newBook mutation with input type](https://miro.medium.com/v2/resize:fit:804/1*Ekb24_oAxv7I3g-QF0bdYA.png)

Here, instead of having multiple arguments, a single input type **BookInput** in **newBook** mutation is much cleaner and manageable.

It’s [good practice](https://graphql-rules.com/rules/mutation-payload) to add a unique output type to each mutation. So let’s do that.

![all bookApi mutations](https://miro.medium.com/v2/resize:fit:775/1*-2qzbplpHWr4iQ3ogcharw.png)

I created a new output type **NewBook** which is identical to the **Book** type in this case. The output of the query remains the same.

![newBook mutation in postman](https://miro.medium.com/v2/resize:fit:869/1*m-Hsb6on6aal5EeupA4EHw.png)

Even though _input types_ and _output types_ look quite similar, you cannot mix both types in the schema. Arguments on fields are also not allowed for input types.

---

## Arguments on Fields

In GraphQL, every field of objects and nested objects can be passed with [arguments](https://graphql.org/learn/schema/#arguments). The syntax to define this is quite similar to that of the query. It also gives GraphQL the ability to do multiple API fetches without much development overhead.

In the real world, a single book could be written by multiple authors. Let’s change the Book type to reflect this, by returning a list of **Authors** instead of just one. The updated **Book** type looks like this:

![Book type with an argument on the author field](https://miro.medium.com/v2/resize:fit:555/1*lCamX7WhHZ6_HKRsHD6d2A.png)

GraphQL [lists](https://graphql.org/learn/schema/#lists-and-non-null) are defined by square brackets. Now each book type contains a list of authors. Here the **author** field accepts one argument of type **order**, which in turn is of type [enum](https://graphql.org/learn/schema/#enumeration-types) **ListOrder**. With this, we can decide in which order we want the author list. This kind of field argument can be useful to show ordered data for the front end.

I also added a new field **starRating** to **author** type. This rating will be used to order the author list in ascending or descending order.

![Author type](https://miro.medium.com/v2/resize:fit:368/1*mbJfmmK93ndlhR89TO708A.png)

Now let's modify the **BookAuthorResolver** class to resolve the author list with field argument order. All field arguments are available in the GraphQLResolver, so I just added the order field to **getAuthor()** resolver method.

![Book resolver class](https://miro.medium.com/v2/resize:fit:875/1*FD8vFqfmhPFbhSYCq1Sj_w.png)

Let's test the **getBookByName** query in descending order.

![getBookByName query with field argument](https://miro.medium.com/v2/resize:fit:875/1*A97XB_FI4tzPQnxgB_zq8Q.png)

As expected, the author list is in descending order of **starRating**. Because of the [auto fetch schema feature](https://learning.postman.com/docs/sending-requests/supported-api-frameworks/graphql/#introspection-and-importing-graphql-schemas), Postman is aware of the expected values for the **order** field. If you try to enter some random values, it shows you a warning like the below.

![getBookByName query with wrong field argument](https://miro.medium.com/v2/resize:fit:825/1*67RxbKdtngPe-mlDRVubuA.png)

In such cases, you can use [schema introspection queries](https://graphql.org/learn/introspection/) to get more info about the schema types.

![schema introspection query](https://miro.medium.com/v2/resize:fit:875/1*4VrlyVy4eMlXCtciWMJY3w.png)

Since the field argument **order** isn't mandatory, we can just query without it.

![simple getBookByName query](https://miro.medium.com/v2/resize:fit:875/1*VYlGGXFpqdXZgPEm1_A82A.png)

Here you get the default list order returned by the `authorRepository`. You can check out this project [here](https://github.com/dhakre/APIBook/tree/graphqlTypes).

I hope this quick look at GraphQL types will help you use more advanced GraphQL features to build faster APIs.
---
# GraphQL with spring-boot-starter-graphql

Finally, after 10 months of waiting, GraphQL is integrated with the latest release of [**Spring Boot 2.7.0**](https://spring.io/blog/2022/05/19/spring-boot-2-7-0-available-now). With this release, **spring-boot-starter-graphql** replaces the current **GraphQL Java Spring**. For more details on this release, check [here](https://spring.io/blog/2022/05/19/spring-for-graphql-1-0-release).

In this article, we’ll see how you can start using this new GraphQL starter or simply migrate your existing project. Here, I am using my previous [project](https://medium.com/@dhakresumitra5/graphql-with-spring-boot-java-d2fa3ca1b12c) that was built with GraphQL Java Spring.

---

## Requirements

Setup you’ll need:

- Basic understanding of Spring Boot and GraphQL
- Existing GraphQL Java project or clone one [here](https://github.com/dhakre/APIBook/tree/graphqlTypes)
- Docker installed on your machine
- IntelliJ or IDE of your choice
- Postman for testing the API

---

## Project Migration

Unlike before, with **Spring Boot 2.7.0** we only need one dependency to integrate GraphQL in our project. So I started by upgrading the Spring Boot version to:

```xml
<parent>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-parent</artifactId>
    <version>2.7.0</version>
    <relativePath/>
</parent>
```

Then I **removed the previous GraphQL dependencies**:

```xml
<dependency>
    <groupId>com.graphql-java-kickstart</groupId>
    <artifactId>graphql-java-tools</artifactId>
    <version>12.0.0</version>
</dependency>
<dependency>
    <groupId>com.graphql-java-kickstart</groupId>
    <artifactId>graphql-spring-boot-starter</artifactId>
    <version>12.0.0</version>
</dependency>
```

And **added the new Spring Boot GraphQL starter**:

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-graphql</artifactId>
</dependency>
```

After this, remove all the implemented Resolvers and clean the project by removing all the imports from GraphQL Java Spring.

![Project Cleaned](https://miro.medium.com/v2/resize:fit:875/1*kSn40Z1k_l-lw-vHZvLMxw.png)

Now our project is clean and updated with the new dependencies. According to the [**Spring GraphQL documentation**](https://docs.spring.io/spring-graphql/docs/current-SNAPSHOT/reference/html/#overview), the biggest changes come with the _new annotated controllers_. The [default location for schema files](https://docs.spring.io/spring-boot/docs/2.7.0-SNAPSHOT/reference/html/web.html#web.graphql.schema) is **src/main/resources/graphql/**. This is the case here, so we don’t need to touch the GraphQL schema files. All files will be picked up automatically by Spring GraphQL starter.

![Schema File Location](https://miro.medium.com/v2/resize:fit:345/1*xGFVwa1NnMuuiw3md4Rgtg.png)

You can also customize the schema file location in the `application.properties`. But here we’ll go with the defaults.

![Schema File Location in Properties](https://miro.medium.com/v2/resize:fit:509/1*O4Azxnt8q-8-B6YGmX7PMA.png)

---

# GraphQL Annotations

With GraphQL Spring Java, the resolvers component is needed to implement `GraphQLQueryResolver` or `GraphQLMutationResolver` classes. But with the **spring-boot-starter-graphql**, it’s moved to an [**annotation-based programming**](https://docs.spring.io/spring-graphql/docs/current-SNAPSHOT/reference/html/#controllers) model. In short, previous resolvers are replaced by annotations:

- `GraphQLMutationResolver` → `@MutationMapping`
- `GraphQLQueryResolver` → `@QueryMapping`

And the **@Controller** component uses the annotated handler methods to bind and resolve GraphQL schema fields/queries.

---

## Query Mapping

As the name suggests, this annotation maps the **handler method** to the **query type in GraphQL schema**.

![Query Schema](https://miro.medium.com/v2/resize:fit:629/1*xb69_zHVLcoqrD36VgtZEg.png)

![BookQuery Class](https://miro.medium.com/v2/resize:fit:875/1*AStc_kFGbOjBKzYW41kU9g.png)

Now let’s configure our query methods by annotating them with `@QueryMapping`. For mapping query arguments, we can use the annotation [`@Argument`](https://docs.spring.io/spring-graphql/docs/1.0.0/reference/html/#controllers-schema-mapping-argument). For more flexibility, you can also define alias names for the arguments. For example:

![Argument Alias](https://miro.medium.com/v2/resize:fit:629/1*LzCFaNIJYCrrCRxU8JWr9w.png)

The query `getBookByName` has an argument `filter` in the schema and in the handler method, it’s `bookFilter`. So we need to define an alias with the `@Argument("filter")`. If you forget to do this, your project will just deploy successfully but the query will end up with NPE. Which I wasted some time on, and later figured out it was just missing the right matching argument names.

---

# Schema Mapping

This annotation maps and binds a handler with the field in the GraphQL schema. It can be used at the **method** or **class level**. It accepts two parameters: `typeName=` and `field=`. It’s also the parent annotation of the other query-specific annotations.

![Schema Mapping Meta-Annotations](https://miro.medium.com/v2/resize:fit:875/1*kfTigEsXEJx_R4RcctDtag.png)

We’ll need this annotation to resolve the **author** field type of the Book type.

![Book Type in Schema](https://miro.medium.com/v2/resize:fit:493/1*e__s9pLa-aztdAKieH1sPg.png)

![Author Resolver Method](https://miro.medium.com/v2/resize:fit:875/1*ZkUlV72DeAqcC4m6fMxWOw.png)

Here we define the `@SchemaMapping` annotation with parameters:

- `typeName = Book`, which is the type to which the author field belongs
- `field = author`, to specify which field of the specified typeName will be resolved by this handler method.

After, I defined the argument on the field, `order`, with the `@Argument` annotation. As it has the same name `order` both in schema and handler method, Spring will map it automatically. Since we are defining the schema annotation at the method level, the previous `BookAuthorResolver` class is unnecessary, so I removed it and moved the method to the `BookQuery` class.

![BookQuery Class with Query Handler and Author Resolver](https://miro.medium.com/v2/resize:fit:875/1*dYfnMEwRqOjn9yHvUzocAQ.png)

---

# Mutation Mapping

This annotation maps handler methods with the mutation query in the GraphQL schema.

![Mutation Schema](https://miro.medium.com/v2/resize:fit:718/1*M1X9Lla6Eb_zQQBJBTRmNw.png)

![DeleteBook Method with Mutation Annotation](https://miro.medium.com/v2/resize:fit:875/1*Lab0bUJzcKKCu79Q7Eli6g.png)

Just like we changed for the `@QueryMapping`, add the `@MutationMapping` to the mutation query method and annotate the mutation argument with `@Argument("input")` annotation with the alias.

```java
@MutationMapping
public Boolean deleteBook(@Argument("input") String bookId) {
    // ...handler logic...
}
```

Since **Mutation** and **Query** mapping annotations are **meta-annotations of SchemaMapping**, we can also replace them like this:

![Defining Mutation Method with @SchemaMapping](https://miro.medium.com/v2/resize:fit:875/1*kyN7eDtc9xLeAx_Wsqs07w.png)

---

# Test API

Now all the changes are done, let's build and run the project.

```shell
mvn clean install
```

Then deploy with Docker:

```shell
docker-compose up -d
```

![Docker Containers](https://miro.medium.com/v2/resize:fit:823/1*eclqVsNJqlHrErW3FrkUUA.png)

Let’s test one **query** first:

![allBook Query in Postman](https://miro.medium.com/v2/resize:fit:875/1*Pl-EtOS9EEPkx3HBEEiq9A.png)

As mentioned in the specs, the new Spring GraphQL starter uses **Runtime wiring** to **register handler methods** to the `graphql.schema.Datafetcher`. Therefore, even if you annotate a handler method wrong (e.g., instead of `@QueryMapping` you accidentally put `@MutationMapping`),

![Wrong Annotation Example](https://miro.medium.com/v2/resize:fit:875/1*999ERE_p4GajhPwrZU0t8g.png)

you won’t see any errors but the result won’t be the one expected. So just be careful while annotating the handler methods.

![Unexpected Result](https://miro.medium.com/v2/resize:fit:875/1*-TqDAw-qC86bqz3i8JNe3Q.png)

Now let’s test one **mutation**:

![newBook Mutation in Postman](https://miro.medium.com/v2/resize:fit:850/1*NxnrFpXzAlx-Oiew3X_Oqw.png)

The API works as expected. I hope this quick article will help you get started with the new **spring-boot-graphql-starter** and play with the other cool features it has. You can check out this project on [GitHub here](https://github.com/dhakre/APIBook/tree/springGraphQL). If you like this article, be sure to check out my other [articles related to Spring Boot](https://medium.com/@dhakresumitra5/list/graphql-with-spring-boot-java-6bbc89446107).

---
# Building a Robust REST API with GraphQL and Spring Boot using H2 Database

> This article is a comprehensive guide that explains how to create a RESTful API using GraphQL and Spring Boot while integrating H2 database. It provides a step-by-step approach to building a robust API that can handle complex queries and mutations. The article also includes a discussion on how GraphQL can be used to improve the performance of your API and how H2 database can be used to persist data in-memory during development.

> The article covers topics such as schema design, data fetching, and mutation handling using GraphQL and Spring Boot. It also discusses how to configure and use H2 database for your API.
> 
> Overall, this article is a must-read for anyone looking to create a scalable and high-performing API using GraphQL and Spring Boot while integrating an H2 database for efficient data management during development.

---

## Documentation and Resources

- [Spring GraphQL Documentation](https://docs.spring.io/spring-graphql/docs/current/reference/html/)
- [H2 Database Documentation](https://www.h2database.com/html/main.html)
- [Spring Initializr](https://start.spring.io/)

---

## Sample Application: CRUD on User Entity with GraphQL & Spring Boot

### 1. Add Dependencies to `pom.xml`

```xml
<dependency>
   <groupId>com.graphql-java</groupId>
   <artifactId>graphql-java-extended-scalars</artifactId>
   <version>20.2</version>
</dependency>
<dependency>
   <groupId>org.springframework.boot</groupId>
   <artifactId>spring-boot-starter-graphql</artifactId>
</dependency>
```

The final `pom.xml` will look like:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
 xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
 <modelVersion>4.0.0</modelVersion>
 <parent>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-starter-parent</artifactId>
  <version>3.0.6</version>
  <relativePath/> <!-- lookup parent from repository -->
 </parent>
 <groupId>com.example</groupId>
 <artifactId>GraphqlDemo</artifactId>
 <version>0.0.1-SNAPSHOT</version>
 <name>GraphqlDemo</name>
 <description>Demo project for Spring Boot with GraphQl</description>
 <properties>
  <java.version>17</java.version>
 </properties>
 <dependencies>
  <dependency>
   <groupId>com.graphql-java-kickstart</groupId>
   <artifactId>graphql-spring-boot-starter-test</artifactId>
   <version>15.0.0</version>
   <scope>test</scope>
  </dependency>
  <dependency>
   <groupId>com.graphql-java</groupId>
   <artifactId>graphql-java-extended-scalars</artifactId>
   <version>20.2</version>
  </dependency>
  <dependency>
   <groupId>org.springframework.boot</groupId>
   <artifactId>spring-boot-starter-graphql</artifactId>
  </dependency>
  <dependency>
   <groupId>org.springframework.boot</groupId>
   <artifactId>spring-boot-starter-data-jpa</artifactId>
  </dependency>
  <dependency>
   <groupId>org.springframework.boot</groupId>
   <artifactId>spring-boot-starter-web</artifactId>
  </dependency>
  <dependency>
   <groupId>org.springframework.boot</groupId>
   <artifactId>spring-boot-starter-test</artifactId>
   <scope>test</scope>
  </dependency>
  <dependency>
   <groupId>com.h2database</groupId>
   <artifactId>h2</artifactId>
   <scope>runtime</scope>
  </dependency>
  <dependency>
   <groupId>org.projectlombok</groupId>
   <artifactId>lombok</artifactId>
   <optional>true</optional>
  </dependency>
  <dependency>
   <groupId>org.springframework.boot</groupId>
   <artifactId>spring-boot-starter-test</artifactId>
   <scope>test</scope>
  </dependency>
  <dependency>
   <groupId>io.projectreactor</groupId>
   <artifactId>reactor-test</artifactId>
   <scope>test</scope>
  </dependency>
 </dependencies>
 <build>
  <plugins>
   <plugin>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-maven-plugin</artifactId>
    <configuration>
     <excludes>
      <exclude>
       <groupId>org.projectlombok</groupId>
       <artifactId>lombok</artifactId>
      </exclude>
     </excludes>
    </configuration>
   </plugin>
   <plugin>
    <groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-compiler-plugin</artifactId>
    <configuration>
     <source>16</source>
     <target>16</target>
    </configuration>
   </plugin>
  </plugins>
 </build>
</project>
```

---

### 2. Create GraphQL Schemas

Create at `src/main/resources/graphql/schemas.graphqls`:

```graphql
scalar UUID

type Query {
    getUser(userId: UUID): User
    getAllUsers: [User]
}

type User {
    id: UUID
    username: String
    address: Address
    phoneNumber: PhoneNumber
}

input UserInput {
    id: UUID
    username: String
    address: AddressInput
    phoneNumber: PhoneNumberInput
}

type PhoneNumber {
    id: ID
    primaryPhoneNumber: String
    secondaryPhoneNumber: [String]
}

input PhoneNumberInput {
    id: ID
    primaryPhoneNumber: String
    secondaryPhoneNumber: [String]
}

type Address {
    id: ID
    primaryAddress: String
    secondaryAddress: [String]
}

input AddressInput {
    id: ID
    primaryAddress: String
    secondaryAddress: [String]
}

type Mutation {
    createUser(user: UserInput!): User
    deleteUser(userId: UUID): Boolean
    updateUser(user: UserInput): Boolean
}
```

---

### 3. Register UUID Scalar in Spring Boot

```java
package com.example.GraphqlDemo;

import graphql.scalars.ExtendedScalars;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.graphql.execution.RuntimeWiringConfigurer;

@SpringBootApplication
public class GraphqlDemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(GraphqlDemoApplication.class, args);
    }
    @Bean
    public RuntimeWiringConfigurer runtimeWiringConfigurer() {
        return wiringBuilder -> wiringBuilder.scalar(ExtendedScalars.UUID);
    }
}
```

---

### 4. Model Classes

#### Address.java

```java
package com.example.GraphqlDemo.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.List;
import java.util.UUID;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "address")
public class Address {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    UUID id;
    @Column
    String primaryAddress;
    @ElementCollection
    @Column(name = "secondaryAddresses")
    List<String> secondaryAddresses;
}
```

#### PhoneNumber.java

```java
package com.example.GraphqlDemo.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.List;
import java.util.UUID;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "phone_number")
public class PhoneNumber {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    UUID id;
    @Column
    String primaryPhoneNumber;
    @ElementCollection
    @Column
    List<String> SecondaryPhoneNumbers;
}
```

#### User.java

```java
package com.example.GraphqlDemo.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.UUID;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    UUID id;
    String username;
    @OneToOne(cascade = {CascadeType.ALL})
    Address Address;
    @OneToOne(cascade = {CascadeType.ALL})
    PhoneNumber phoneNumber;
}
```

---

### 5. UserController.java (CRUD Operations)

```java
package com.example.GraphqlDemo.controller;

import com.example.GraphqlDemo.model.User;
import com.example.GraphqlDemo.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;
import java.util.List;
import java.util.UUID;

@Controller
public class UserController {
    @Autowired
    UserService userService;
    private static Logger LOGGER = LoggerFactory.getLogger(UserController.class);

    @MutationMapping
    public User createUser(@Argument User user) {
        LOGGER.info("Entering the create user method to create user");
        try {
            user = userService.save(user);
            LOGGER.info("Successfully created user with id {}", user.getId());
        } catch (Exception exception) {
            LOGGER.error(exception.getMessage());
        }
        LOGGER.info("Returning the final response from create user method");
        return user;
    }

    @QueryMapping
    public User getUser(@Argument UUID userId) {
        LOGGER.info("Entering the get user method with id : {}", userId);
        User user = null;
        try {
            user = userService.get(userId);
            LOGGER.info("Successfully fetched the user with id {}", user.getId());
        } catch (Exception exception) {
            LOGGER.error(exception.getMessage());
        }
        LOGGER.info("Returning the final response from get user method");
        return user;
    }

    @QueryMapping
    public List<User> getAllUsers() {
        LOGGER.info("Entering the get all users method");
        List<User> users = null;
        try {
            users = userService.getAll();
            LOGGER.info("Successfully fetched all users");
        } catch (Exception exception) {
            LOGGER.error(exception.getMessage());
        }
        LOGGER.info("Returning the final response from get all users method");
        return users;
    }

    @MutationMapping
    Boolean updateUser(@Argument User user) {
        LOGGER.info("Entering the update user method to update user");
        Boolean response = Boolean.FALSE;
        try {
            response = userService.update(user);
            LOGGER.info("Successfully updated user with id {}", user.getId());
            response = Boolean.TRUE;
        } catch (Exception exception) {
            LOGGER.error(exception.getMessage());
        }
        LOGGER.info("Returning the final response from update user method");
        return response;
    }

    @MutationMapping
    public Boolean deleteUser(@Argument UUID userId) {
        LOGGER.info("Entering the delete user method with id : {}", userId);
        Boolean response = null;
        try {
            response = userService.delete(userId);
            LOGGER.info("Successfully deleted the user with id {}", userId);
        } catch (Exception exception) {
            LOGGER.error(exception.getMessage());
        }
        LOGGER.info("Returning the final response from delete user method");
        return response;
    }
}
```

---

### 6. Service and Repository Layer

#### UserService.java

```java
package com.example.GraphqlDemo.service;

import com.example.GraphqlDemo.model.User;
import java.util.List;
import java.util.UUID;

public interface UserService {
    User save(User user) throws Exception;
    Boolean update(User user) throws Exception;
    Boolean delete(UUID userId) throws Exception;
    User get(UUID userId) throws Exception;
    List<User> getAll() throws Exception;
}
```

#### UserServiceImpl.java

```java
package com.example.GraphqlDemo.service;

import com.example.GraphqlDemo.model.User;
import com.example.GraphqlDemo.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class UserServiceImpl implements UserService {
    private static Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);
    @Autowired
    UserRepository userRepository;

    @SchemaMapping
    @Override
    public User save(User user) throws Exception {
        LOGGER.info("Entered the save user method in user service");
        user = userRepository.save(user);
        if (user == null) {
            LOGGER.error("Error in creating the user");
            throw new Exception("Error in creating the user");
        }
        LOGGER.info("Exiting the save user method in user service");
        return user;
    }

    @SchemaMapping
    @Override
    public Boolean update(User user) throws Exception {
        LOGGER.info("Entered the update user method in user service");
        Optional<User> userOptional = userRepository.findById(user.getId());
        Boolean response = Boolean.FALSE;
        if (!userOptional.isEmpty()) {
            userRepository.save(user);
            response = Boolean.TRUE;
        } else {
            LOGGER.error("Error in updating the user");
            throw new Exception("Error in updating the user");
        }
        LOGGER.info("Exiting the update user method in user service");
        return response;
    }

    @SchemaMapping
    @Override
    public Boolean delete(UUID userId) throws Exception {
        LOGGER.info("Entered the delete user method in user service");
        Optional<User> userOptional = userRepository.findById(userId);
        Boolean response = Boolean.FALSE;
        if (!userOptional.isEmpty()) {
            userRepository.delete(userOptional.get());
            response = Boolean.TRUE;
        } else {
            LOGGER.error("Error in deleting the user");
            throw new Exception("Error in deleting the user");
        }
        LOGGER.info("Exiting the delete user method in user service");
        return response;
    }

    @SchemaMapping
    @Override
    public User get(UUID userId) throws Exception {
        LOGGER.info("Entered the get user method in user service");
        Optional<User> userOptional = userRepository.findById(userId);
        if (userOptional.isEmpty()) {
            LOGGER.error("No user found with the ID {}", userId);
            throw new Exception("No user found with the ID " + userId);
        }
        LOGGER.info("Exiting the get user method in user service");
        return userOptional.get();
    }

    @SchemaMapping
    @Override
    public List<User> getAll() throws Exception {
        LOGGER.info("Entered the getAll users method in user service");
        List<User> users = userRepository.findAll();
        if (users.size() == 0) {
            LOGGER.error("No users found");
            throw new Exception("No users found");
        }
        LOGGER.info("Exiting the getAll users method in user service");
        return users;
    }
}
```

#### UserRepository.java

```java
package com.example.GraphqlDemo.repository;

import com.example.GraphqlDemo.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.UUID;

@Repository
public interface UserRepository extends JpaRepository<User, UUID> {
}
```

---

### 7. Configuration: `application.yml`

```yaml
spring:
  datasource:
    url: jdbc:h2:mem:mydb
    username: sa
    password:
    driverClassName: org.h2.Driver
  jpa:
    database-platform: org.hibernate.dialect.H2Dialect
  h2:
    console:
      enabled: true
      settings.trace: false
      settings.web-allow-others: false
  graphql:
    servlet:
      enabled: true
      mapping: /graphql
      cors-enabled: true
    graphiql:
      enabled: true
      path: /graphiql
```

---

## Testing the GraphQL Endpoint

Use Postman to test the GraphQL endpoint:

- **Endpoint:** `http://localhost:8080/graphql`
- **Request body:**

```json
{
  "query": "{ getUser(userId: \"c6c2e6e6-f436-4367-9c98-f93e64cf5a50\"){ username } }"
}
```

**POSTMAN COLLECTION:** [Link](https://github.com/digvijay17july/projects/blob/master/GraphqlDemo/src/main/resources/spring-boot-graphql.postman_collection.json)

![Postman Example](https://miro.medium.com/v2/resize:fit:875/1*NfL52t9FuudYn5tYPCf4uA.png)

[GitHub Source Code](https://github.com/digvijay17july/projects/tree/master/GraphqlDemo)

---

# Boosting Your Spring Boot App with GraphQL

*Learn how to use GraphQL with Spring Boot to make the API development process easy and more developer-friendly.*

In this blog, we’ll explore how GraphQL and Spring Boot collaborate seamlessly. They make it easy and enjoyable for developers to create APIs with simplicity and friendliness. Spring Boot is renowned for its rapid setup and configuration capabilities, making it a popular choice for deploying backend applications. Meanwhile, GraphQL is a cutting-edge technology crafted to revolutionize APIs with its speed, adaptability, and developer-centric design. Together, they form a powerful combination for modern API development.

GraphQL boasts a smart query language and runtime crafted by Facebook. This innovation tackles the drawbacks of regular REST APIs. With GraphQL, we can pinpoint the exact data we need, avoiding the hassles of getting too much or too little. It’s all about efficiency and delivering just what’s necessary.

In our Spring Boot project, we’ll harness the power of GraphQL. By combining it with Spring Boot, we’ll create an intuitive and seamless integration. We’ll begin by crafting a GraphQL schema—a masterpiece that defines data types and governs queries and mutations. We’ll use GraphQL Schema Definition Language (SDL) to orchestrate this process.

---

## What is GraphQL?

> GraphQL is an innovative open-source data query and manipulation language for APIs. It revolutionizes the way developers interact with data, offering a visionary approach. With its query runtime engine, GraphQL allows declarative data fetching, freeing developers from over-fetching data. They can now precisely request what they need from a single API endpoint.
>
> Imagine a developer’s dream come true, where managing multiple API endpoints becomes a thing of the past. GraphQL emerges as the ultimate solution, streamlining data retrieval with efficiency and elegance like never before.

---

## Key Terms in GraphQL

**Schema:** The schema is the core of GraphQL, an essential blueprint that shapes your API’s structure, defines its data types, and showcases its impressive capabilities. It acts as a friendly agreement between the client and server, laying out which data can be requested and what will be provided in return.

Imagine the schema as a detailed roadmap that guides developers and clients through the API landscape. It clarifies what data can be accessed and how to make it a breeze to interact with the API efficiently.

```graphql
schema {
  query: Query
  mutation: Mutation
}
```

**Type:** At the core of GraphQL’s charm is its dedication to precision and clarity through strict typing. With a belief that “types matter,” GraphQL provides developers with an elegant and robust foundation for API development.

Strict typing in GraphQL ensures that data is well-defined and consistent, making it easier for developers to understand and work with the API.

```graphql
type User {
    name: String!
    email: String!
}
```

**Field:** In GraphQL, a field is a crucial element found within a Type. It represents a specific piece of data that the Type holds, just like properties in a Java class. For example, in a `User` Type, fields like `name` and `email` define the user’s identity. Each field acts like a brushstroke, painting a clear picture of the data it represents within the GraphQL universe.

**Query:** In GraphQL, a query is a powerful tool that fetches data from the API endpoint. It acts as a gateway to access information, like a key unlocking the treasures of the GraphQL universe. But remember, queries are meant only for reading data, not for updating or creating it. They are like reading glasses, allowing you to explore and retrieve the data you need with ease and clarity.

```graphql
type Query {
    findAllUser: [User]
    findUserById(id: ID): User
}
```

Here, _findAllUser_ and _findUserById_ are queries we defined to fetch user data.

> **Note:** We cannot update or insert data using queries.

**Mutation:** In GraphQL, a mutation is a specialized tool designed for data manipulation. Unlike queries, which are used for reading data, mutations take on the role of guardians of change. They provide a controlled and elegant way to perform insert or update operations within the GraphQL universe.

```graphql
type Mutation {
  createUser(user: User): Void
  updateUser(user: User): User
}
```

**Scalar:** In GraphQL, a scalar is a fundamental data type representing a single value. Scalars are the building blocks used to define the shape and structure of the data within the GraphQL schema. Unlike object types that can have multiple fields, scalars can hold only one value at a time.

GraphQL comes with a set of default scalar types, including `Int`, `Float`, `String`, `Boolean`, and `ID`.

---

## Let’s Create a Spring Boot Application and Dive into the Mesmerizing World of GraphQL

Set up the Spring Boot Project using your preferred IDE and build tool, such as Maven, and create a new Spring Boot project. Here, we’ll create a simple Todo app to demonstrate how GraphQL works.

Add the necessary dependencies for Spring Boot and GraphQL to your project’s configuration file:

```xml
<dependency>
    <groupId>com.graphql-java</groupId>
    <artifactId>graphql-spring-boot-starter</artifactId>
    <version>5.0.2</version>
</dependency>
```

Create `Todo` and `TodoItem` entities and necessary JPA repositories. You can see the entities I have created [here](https://github.com/Amit-Chavda/todo-app-grapql/tree/master/src/main/java/com/graphql/graphqldemo/entity).

Create `schema.graphqls` resource in the resources package which will contain GraphQL queries.

![GraphQL schema file](https://miro.medium.com/v2/resize:fit:666/1*HgUTcf9ZQewQIcRn-_sA2A.png)
*Figure 1: GraphQL schema file*

Since GraphQL doesn’t have native support for Java `LocalDate` and `LocalDateTime`, we’ll create custom scalar types to handle these types in our schema. You can find the implementation of these custom scalar types [here](https://github.com/Amit-Chavda/todo-app-grapql/tree/master/src/main/java/com/graphql/graphqldemo/scalar).

Define `Todo` and `TodoItem` types with the following fields:

```graphql
scalar LocalDate
scalar LocalDateTime

type Todo {
    id: ID
    title: String
    markAsComplete: Boolean
    completionDate: LocalDate
    items: [TodoItem]
}

type TodoItem {
    id: ID
    notes: String
    dueDate: LocalDate
    markAsComplete: Boolean
    completionDate: LocalDate
    createdAt: LocalDateTime
    updatedAt: LocalDateTime
}
```

Define the GraphQL schema and query to get all Todo items:

```graphql
schema {
    query: Query
}

type Query {
    getAllTodo: [Todo]
}
```

Now let’s create `TodoController` and create a method that returns a list of Todo and annotate it with `@QueryMapping` so that this `getAllTodo` query will be mapped. You can find the full code [here](https://github.com/Amit-Chavda/todo-app-grapql/blob/master/src/main/java/com/graphql/graphqldemo/controller/TodoController.java).

```java
@QueryMapping
public List<TodoDto> getAllTodo() {
    return todoService.getAllTodos();
}
```

Additionally, you can enable GraphQL with the following property, a powerful GraphQL interface to easily develop and test GraphQL APIs. You will be able to access the interface on `http://localhost:[port]/graphiql` endpoint.

```yaml
spring:
  graphql:
    graphiql:
      enabled: true
      path: /graphiql
```

When you hit `http://localhost:[port]/graphiql`, you’ll see the following interface in your browser:

![GraphiQL or GraphQL Playground](https://miro.medium.com/v2/resize:fit:875/1*5hd6sqK6BZDvUa9T_8Chbg.png)
*Figure 2: GraphiQL or GraphQL Playground*

Now, let’s write the query to fetch data from the database. Some data has already been pushed into the database. After this, we’ll learn how to create mutations and use them to add/update data in the database.

![GraphQL Query example requesting all fields](https://miro.medium.com/v2/resize:fit:875/1*yy9aDaS-4r2QwTLLyy4L1g.png)
*Figure 3: GraphQL Query example requesting all fields in GraphQL Playground*

As you can see, we have fetched all the fields available in the query we created earlier. However, the real power of GraphQL lies in its flexibility to access only the fields that are required. This ability allows for more efficient data retrieval, reducing unnecessary overhead and optimizing performance.

![GraphQL Query example requesting fewer fields](https://miro.medium.com/v2/resize:fit:875/1*HYGQRIUI1ylSpYPBomqNgQ.png)
*Figure 4: GraphQL Query example requesting fewer fields in GraphQL Playground*

In the snapshot above, I have removed the `id`, `createdAt`, and `updatedAt` fields, and upon execution, I received only the specified fields and values, not all of them.

Now, let’s create a mutation to save the Todo. In GraphQL, we cannot pass a type object as a request body. Therefore, we need to define input types separately from the types we used for the query earlier. We will define the input types as follows:

### Input Types

```graphql
input TodoInput {
    title: String
    markAsComplete: Boolean
    items: [TodoItemInput]
}

input TodoItemInput {
    id: ID
    notes: String
    dueDate: LocalDate
    markAsComplete: Boolean
}
```

We’ll add mutation in the schema as well:

```graphql
schema {
    mutation: Mutation
    query: Query
}

type Mutation {
    createTodo(todo: TodoInput): Todo
}
```

Create a method in `TodoController` that saves Todo in the database. To map this mutation with our logic, we’ll use the `@MutationMapping` annotation, and GraphQL will identify the parameters using the `@Argument` annotation. See the full implementation [here](https://github.com/Amit-Chavda/todo-app-grapql/blob/master/src/main/java/com/graphql/graphqldemo/controller/TodoController.java).

```java
@MutationMapping
public TodoDto createTodo(@Argument(value = "todo") TodoDto todoDto) {
    return todoService.addTodo(todoDto);
}
```

Open the GraphQL interface and hit the play button with the following request body, and we’ll get the response as follows:

![GraphQL Mutation example in GraphQL Playground](https://miro.medium.com/v2/resize:fit:875/1*Y0Rn_bvCb1XEHAn2jvU1xA.png)
*Figure 5: GraphQL Mutation example in GraphQL Playground*

The field mentioned outside the `createTodo()` method determines the response structure. Whatever fields we include here will be returned in the response. This allows us to customize the data returned as per the requirements.

---

## Advantages

- **Flexible Queries:** With GraphQL, we can request exactly the data we need and nothing more. This eliminates issues related to over-fetching or under-fetching data, reducing the payload size and optimizing network performance.
- **Single Endpoint:** Unlike traditional REST APIs that often require multiple endpoints for different resources, GraphQL provides a single endpoint for all data operations. This simplifies the API structure and reduces the number of network requests needed.
- **Strongly Typed Schema:** GraphQL uses a strongly typed schema to define the data structure. This schema acts as a contract between the client and server, providing clear documentation of the available data and operations.
- **Introspection:** GraphQL provides introspection capabilities, allowing us to query the schema itself. This feature enables powerful client tools, such as GraphQL Playground or GraphiQL, to explore the API and understand its capabilities.
- **Rapid Development and Iteration:** GraphQL allows front-end and back-end teams to work independently, as long as they follow the agreed-upon schema. This promotes faster development and iteration, as changes to the schema do not necessarily break the client applications.
- **Version Free API:** Unlike REST APIs, which often require versioning to manage backward compatibility, GraphQL allows for seamless backward-compatible schema changes without breaking existing clients. Fields can be added, deprecated, or modified without changing the overall structure.
- **Reduced API Churn:** Since clients can request precisely the data they need, they are less affected by changes in the backend data structures. This reduces API churn and the need for constant adjustments in the client codebase.

---

## Disadvantages

- **Complexity:** GraphQL introduces additional complexity compared to traditional REST APIs, especially for developers who are new to the technology. Setting up a GraphQL server and defining a schema properly requires a good understanding of GraphQL concepts and best practices.
- **Caching:** GraphQL does not inherently support caching like traditional REST APIs, where you can use HTTP caching mechanisms. Implementing caching in GraphQL can be more challenging, and custom caching solutions are often required.
- **Increased Payloads:** While GraphQL offers the flexibility to request only the required data, it can lead to over-fetching or under-fetching of data. In some cases, GraphQL responses may be larger than necessary, causing increased payload sizes and potentially impacting network performance.
- **File Uploads:** Handling file uploads in GraphQL can be less straightforward compared to traditional REST APIs, where it’s common to use `multipart/form-data`. GraphQL doesn't natively support file uploads, requiring additional configuration or extensions like GraphQL multipart requests.
- **Learning Curve:** Adopting GraphQL may require a learning curve for developers who are already familiar with REST APIs. Understanding GraphQL schemas, queries, mutations, and subscriptions can take time to grasp fully.
- **Security Concerns:** GraphQL’s flexibility can introduce potential security risks if not properly implemented. For instance, malicious queries could lead to data exposure or denial-of-service attacks. Implementing rate limiting and access controls is critical to mitigate these risks.

---

## Key Takeaways

With GraphQL, we can request only the data we need, avoiding over-fetching and under-fetching. This optimization results in reduced data transfer and improved network performance.

The combination of GraphQL and Spring Boot empowers developers to build efficient APIs that meet the demands of modern applications. This approach offers a robust and future-proof solution for creating backend services that cater to evolving needs.

> To stay in the loop with the coolest and latest trends in the development world, follow us on [**Medium**](https://medium.com/simform-engineering), [**LinkedIn**](https://www.linkedin.com/company/simform/) and [**Twitter**](https://twitter.com/simform).

---
# Using GraphQL with Spring Boot Java Application

## Introduction

GraphQL is a query language for your API that allows clients to request exactly the data they need, and nothing more. It can be used to power modern applications, including those built with Java and Spring Boot. In this post, we’ll walk through the steps of setting up a Spring Boot application to use GraphQL.

---

## Prerequisites

Before we get started, you’ll need to have the following tools installed:

- Java 8 or higher
- Maven 3.5 or higher
- A text editor or IDE

---

## Setting up the Spring Boot Project

First, let’s create a new Spring Boot project using the Spring Initializr. We’ll select the following dependencies:

- Web
- GraphQL

Once the project has been generated, open the project in your text editor or IDE.

---

## Adding GraphQL Dependencies

Add the GraphQL Java implementation and the GraphQL Spring Boot starter to your `pom.xml` file:

```xml
<dependency>
  <groupId>com.graphql-java</groupId>
  <artifactId>graphql-java</artifactId>
  <version>11.0</version>
</dependency>
<dependency>
  <groupId>com.graphql-java</groupId>
  <artifactId>graphql-java-tools</artifactId>
  <version>5.2.4</version>
</dependency>
<dependency>
  <groupId>com.graphql-java</groupId>
  <artifactId>graphql-spring-boot-starter</artifactId>
  <version>5.0.2</version>
</dependency>
```

---

## Creating the GraphQL Schema

Create a new file called `schema.graphqls` in the `src/main/resources` directory and add the following code:

```graphql
type Query {
  hello: String
}
```

This defines a single query called `hello` that returns a string.

---

## Creating the GraphQL Resolvers

Now that we have defined the schema, we need to create the code that actually resolves the queries. We’ll do this by creating a class called `QueryResolver` that implements the `GraphQLQueryResolver` interface:

```java
@Component
public class QueryResolver implements GraphQLQueryResolver {
  public String hello() {
    return "Hello, world!";
  }
}
```

This resolver class contains a single method that returns the string “Hello, world!”.

---

## Configuring the GraphQL Endpoint

Now that we have our schema and resolvers set up, we need to configure the endpoint that will accept GraphQL queries. To do this, we’ll create a new configuration class that extends `AbstractGraphQLHttpServlet`:

```java
@Configuration
public class GraphQLConfiguration extends AbstractGraphQLHttpServlet {
  @Autowired
  GraphQL graphQL;

  @Override
  protected GraphQL getGraphQL() {
    return graphQL;
  }

  @Override
  protected ServletContext getServletContext() {
    return null;
  }
}
```

This configuration class tells Spring Boot to use the GraphQL bean as the GraphQL engine, and to not use a servlet context.

---

## Create the GraphQL Bean

Next, we need to create the GraphQL bean. We’ll do this by creating a new configuration class that defines the bean:

```java
@Configuration
public class GraphQLBeanConfiguration {
  @Bean
  public GraphQL graphQL(GraphQLSchema schema, GraphQLContextBuilder contextBuilder) {
    return GraphQL.newGraphQL(schema)
        .queryExecutionStrategy(new AsyncExecutionStrategy())
        .mutationExecutionStrategy(new AsyncSerialExecutionStrategy())
        .contextBuilder(contextBuilder)
        .build();
  }

  @Bean
  public GraphQLSchema schema(GraphQLObjectMapper objectMapper) throws IOException {
    URL url = Resources.getResource("schema.graphqls");
    String sdl = Resources.toString(url, Charsets.UTF_8);
    GraphQLSchema schema = objectMapper.makeExecutableSchema(sdl, QueryResolver.class);
    return schema;
  }

  @Bean
  public GraphQLObjectMapper objectMapper() {
    return new GraphQLObjectMapper();
  }

  @Bean
  public GraphQLContextBuilder contextBuilder() {
    return new GraphQLContextBuilder() {
      @Override
      public GraphQLContext build(HttpServletRequest request, HttpServletResponse response) {
        return new AuthContext(request.getHeader("Authorization"));
      }
    };
  }
}
```

This configuration class creates the following beans:

- `GraphQL`: the GraphQL engine
- `GraphQLSchema`: the GraphQL schema, generated from the `schema.graphqls` file
- `GraphQLObjectMapper`: a helper class for parsing the GraphQL schema
- `GraphQLContextBuilder`: a factory for creating the GraphQL context object, which can be used to store information about the current request

---

## Testing the GraphQL Endpoint

Now that our GraphQL endpoint is set up, let’s test it out. Start the Spring Boot application and navigate to [http://localhost:8080/graphql](http://localhost:8080/graphql).

You should see the GraphQL Playground, a tool for testing GraphQL queries. In the left-hand panel, enter the following query:

```graphql
{
  hello
}
```

Then click the “Play” button. You should see the following response in the right-hand panel:

```json
{
  "data": {
    "hello": "Hello, world!"
  }
}
```

---

## When to Use GraphQL

Here are a few scenarios where you might consider using GraphQL:

- When you want to give clients more control over the data that they receive from your API. With GraphQL, clients can specify exactly which fields they want to retrieve, and can request nested data using a single API call. This can be especially useful if you have a complex API with many different resources and relationships, or if you need to support a wide range of client applications with different data requirements.
- When you want to avoid the over-fetching or under-fetching of data that can occur with a traditional REST API. With GraphQL, clients can request exactly the data they need, and nothing more. This can help reduce the amount of data that needs to be transferred over the network, and can improve the performance of your API.
- When you want to support real-time updates in your application. With GraphQL subscriptions, clients can subscribe to updates on specific events or data changes, and the server can push updates to the subscribed clients in real time.

That being said, there are also scenarios where you might not want to use GraphQL:

- If you only have a simple API with a small number of resources, or if your client applications have relatively simple data requirements, a traditional REST API might be sufficient.
- If you are working with a backend system that is not well-suited to a flexible, schema-based API like GraphQL (e.g. a legacy system with a fixed, inflexible data model), you might want to consider using a different approach.
- If you are concerned about the overhead of implementing and maintaining a GraphQL API, you might want to consider whether the benefits of GraphQL outweigh the additional development effort.

---

## Alternatives to GraphQL

- **REST APIs**: Representational State Transfer (REST) is a common architectural style for building APIs that exposes a set of resources and operations on those resources. With a REST API, clients can access resources using HTTP methods such as GET, POST, PUT, and DELETE, and can receive data in formats such as JSON or XML. REST APIs are well-established and can be easy to implement, but they can suffer from problems such as over-fetching (retrieving more data than necessary) or under-fetching (not retrieving enough data).
- **Falcor**: Falcor is a JavaScript library developed by Netflix that allows clients to access data from a server using a single-route JSON graph. Like GraphQL, Falcor allows clients to request specific data and avoid over-fetching, but it uses a different approach based on a JSON graph rather than a schema and a query language.
- **gRPC**: gRPC is a remote procedure call (RPC) framework developed by Google that uses HTTP/2 and Protocol Buffers to allow clients to call methods on a server in a different process. gRPC can be used to build APIs that are fast, efficient, and easy to scale, but it requires clients and servers to use a specific set of generated code and can be more complex to set up and maintain than other approaches.

Each of these alternatives has its own strengths and weaknesses, and the best choice will depend on the specific requirements of your application.

---

## Pros and Cons of Using GraphQL

**Pros:**

- Allows clients to request exactly the data they need, and nothing more. This can reduce the amount of data transferred over the network and improve the performance of your API.
- Flexible and adaptable. GraphQL allows you to define a flexible schema that can be modified and extended as your application changes. This can make it easier to add or modify features, and can allow you to iterate quickly on your API.
- Can be used with a variety of different client and server technologies. GraphQL has a large and active community, and there are many libraries and frameworks available for a variety of languages and platforms.

**Cons:**

- Requires a learning curve. GraphQL has a different approach to building APIs than other technologies, and developers may need to spend time learning the GraphQL query language and schema definition language.
- Can be more complex to implement and maintain than other approaches. GraphQL requires you to define a schema and to write resolver functions to handle queries and mutations, which can add additional development overhead.
- May not be a good fit for all applications. GraphQL is best suited for APIs with complex data models or a wide range of client requirements, and may not be the best choice for simpler APIs.

---

## About GraphQL and GraphiQL

GraphQL was developed and open-sourced by Facebook in 2015. It was created as an alternative to REST APIs and other approaches for building APIs, with the goal of providing a more flexible and efficient way to request and transfer data over the network.

Since its release, GraphQL has gained a large and active community of users and contributors, and has been adopted by many companies and organizations for building APIs for a wide range of applications.

**GraphiQL** is an in-browser tool for testing and exploring GraphQL APIs. It provides a graphical user interface that allows you to construct GraphQL queries and mutations, and to view the results of those queries and mutations in real time.

GraphiQL is commonly used to debug and test GraphQL APIs during development, and it can also be used as an interactive documentation tool for users of the API. It is often included as a built-in feature in GraphQL servers and libraries, and it is also available as a standalone application that can be used with any GraphQL API.

To use GraphiQL, you simply enter a GraphQL query or mutation into the left-hand side of the interface and press the “Play” button to execute the query or mutation. The results are displayed on the right-hand side of the interface. GraphiQL also includes features such as syntax highlighting, autocompletion, and a built-in documentation explorer to make it easier to use.

---

## Conclusion

Integrating GraphQL with a Spring Boot Java application can be a powerful way to build APIs that are flexible, efficient, and easy to maintain. By using a GraphQL library or framework such as GraphQL-Java or Apollo, you can easily add GraphQL support to your application and take advantage of features such as schema generation, type safety, and automatic query execution.

With Spring Boot, you can use the `spring-boot-starter-graphql` dependency to get started quickly, and you can use features such as JPA and Spring Data to integrate your GraphQL API with a database.

By following best practices for designing and implementing a GraphQL API, you can create a robust and scalable API that meets the needs of your clients and users.

We hope you liked this post on Overview of Using GraphQL with Spring Boot Java Application.

---
# Building an Employee Management System with GraphQL and Spring Boot

In today's rapidly evolving tech landscape, efficient data querying and manipulation are crucial. **GraphQL**, a query language for APIs, provides a more flexible and powerful alternative to REST. When combined with **Spring Boot**, a popular framework for building Java applications, you get a robust and efficient system for managing data. In this blog, we'll walk through building an Employee Management System using GraphQL and Spring Boot.

---

## Table of Contents

1. [Introduction to GraphQL and Spring Boot](#introduction-to-graphql-and-spring-boot)
2. [Setting Up the Project](#setting-up-the-project)
3. [Configuring Spring Boot and GraphQL](#configuring-spring-boot-and-graphql)
4. [Defining the GraphQL Schema](#defining-the-graphql-schema)
5. [Creating the Employee Entity](#creating-the-employee-entity)
6. [Building the Repository Layer](#building-the-repository-layer)
7. [Implementing the Service Layer](#implementing-the-service-layer)
8. [Developing GraphQL Resolvers](#developing-graphql-resolvers)
9. [Testing the API](#testing-the-api)
10. [Conclusion](#conclusion)

---

## Introduction to GraphQL and Spring Boot

> **GraphQL** is a query language for APIs that allows clients to request exactly the data they need, making APIs fast and flexible. It was developed by Facebook and is now an open-source project.
>
> **Spring Boot** is an open-source Java-based framework used to create microservices. It is easy to set up and enables rapid application development.

Combining these two technologies allows developers to build efficient and flexible data APIs.

---

## Setting Up the Project

First, ensure you have the necessary tools installed:

- JDK 11 or later
- Maven
- An IDE (IntelliJ IDEA, Eclipse, etc.)

Create a new Spring Boot project using [Spring Initializr](https://start.spring.io/):

- **Project:** Maven Project
- **Language:** Java
- **Spring Boot:** Latest stable version
- **Dependencies:** Spring Web, Spring Data JPA, H2 Database, GraphQL Spring Boot Starter

Download the project and import it into your IDE.

---

## Configuring Spring Boot and GraphQL

In the `pom.xml` file, ensure the following dependencies are included:

```xml
<dependencies>
    <!-- Spring Boot dependencies -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-data-jpa</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <!-- H2 Database dependency -->
    <dependency>
        <groupId>com.h2database</groupId>
        <artifactId>h2</artifactId>
    </dependency>
    <!-- GraphQL dependencies -->
    <dependency>
        <groupId>com.graphql-java-kickstart</groupId>
        <artifactId>graphql-spring-boot-starter</artifactId>
    </dependency>
    <dependency>
        <groupId>com.graphql-java-kickstart</groupId>
        <artifactId>graphiql-spring-boot-starter</artifactId>
    </dependency>
</dependencies>
```

Configure the database in `src/main/resources/application.properties`:

```properties
spring.datasource.url=jdbc:h2:mem:testdb
spring.datasource.driverClassName=org.h2.Driver
spring.datasource.username=sa
spring.datasource.password=password
spring.h2.console.enabled=true
spring.jpa.hibernate.ddl-auto=update
```

---

## Defining the GraphQL Schema

Create a directory `src/main/resources/graphql` and add a file `schema.graphqls`:

```graphql
type Query {
    getAllEmployees: [Employee]
    getEmployeeById(id: ID!): Employee
}

type Mutation {
    createEmployee(employeeInput: EmployeeInput): Employee
    updateEmployee(id: ID!, employeeInput: EmployeeInput): Employee
    deleteEmployee(id: ID!): Boolean
}

type Employee {
    id: ID!
    firstName: String!
    lastName: String!
    email: String!
    department: String!
}

input EmployeeInput {
    firstName: String!
    lastName: String!
    email: String!
    department: String!
}
```

---

## Creating the Employee Entity

Define the `Employee` entity in `src/main/java/com/example/employeemanagement/model/Employee.java`:

```java
package com.example.employeemanagement.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private String department;

    // Getters and Setters
}
```

---

## Building the Repository Layer

Create the repository interface in `src/main/java/com/example/employeemanagement/repository/EmployeeRepository.java`:

```java
package com.example.employeemanagement.repository;

import com.example.employeemanagement.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
}
```

---

## Implementing the Service Layer

Create the service class in `src/main/java/com/example/employeemanagement/service/EmployeeService.java`:

```java
package com.example.employeemanagement.service;

import com.example.employeemanagement.model.Employee;
import com.example.employeemanagement.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {
    @Autowired
    private EmployeeRepository employeeRepository;

    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public Optional<Employee> getEmployeeById(Long id) {
        return employeeRepository.findById(id);
    }

    public Employee createEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    public Employee updateEmployee(Long id, Employee employeeDetails) {
        Employee employee = employeeRepository.findById(id).orElseThrow(() -> new RuntimeException("Employee not found"));
        employee.setFirstName(employeeDetails.getFirstName());
        employee.setLastName(employeeDetails.getLastName());
        employee.setEmail(employeeDetails.getEmail());
        employee.setDepartment(employeeDetails.getDepartment());
        return employeeRepository.save(employee);
    }

    public boolean deleteEmployee(Long id) {
        Employee employee = employeeRepository.findById(id).orElseThrow(() -> new RuntimeException("Employee not found"));
        employeeRepository.delete(employee);
        return true;
    }
}
```

---

## Developing GraphQL Resolvers

Create the GraphQL resolvers in `src/main/java/com/example/employeemanagement/resolver`:

### Query Resolver

```java
package com.example.employeemanagement.resolver;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.example.employeemanagement.model.Employee;
import com.example.employeemanagement.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class Query implements GraphQLQueryResolver {
    @Autowired
    private EmployeeService employeeService;

    public List<Employee> getAllEmployees() {
        return employeeService.getAllEmployees();
    }

    public Employee getEmployeeById(Long id) {
        return employeeService.getEmployeeById(id).orElse(null);
    }
}
```

### Mutation Resolver

```java
package com.example.employeemanagement.resolver;

import com.coxautodev.graphql.tools.GraphQLMutationResolver;
import com.example.employeemanagement.model.Employee;
import com.example.employeemanagement.service.EmployeeService;
import com.example.employeemanagement.input.EmployeeInput;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Mutation implements GraphQLMutationResolver {
    @Autowired
    private EmployeeService employeeService;

    public Employee createEmployee(EmployeeInput employeeInput) {
        Employee employee = new Employee();
        employee.setFirstName(employeeInput.getFirstName());
        employee.setLastName(employeeInput.getLastName());
        employee.setEmail(employeeInput.getEmail());
        employee.setDepartment(employeeInput.getDepartment());
        return employeeService.createEmployee(employee);
    }

    public Employee updateEmployee(Long id, EmployeeInput employeeInput) {
        Employee employeeDetails = new Employee();
        employeeDetails.setFirstName(employeeInput.getFirstName());
        employeeDetails.setLastName(employeeInput.getLastName());
        employeeDetails.setEmail(employeeInput.getEmail());
        employeeDetails.setDepartment(employeeInput.getDepartment());
        return employeeService.updateEmployee(id, employeeDetails);
    }

    public boolean deleteEmployee(Long id) {
        return employeeService.deleteEmployee(id);
    }
}
```

### Employee Input Class

```java
package com.example.employeemanagement.input;

public class EmployeeInput {
    private String firstName;
    private String lastName;
    private String email;
    private String department;
    // Getters and Setters
}
```

---

## Testing the API

Run the application using your IDE or by executing:

```shell
mvn spring-boot:run
```

Open your browser and navigate to [http://localhost:8080/graphiql](http://localhost:8080/graphiql) to access the GraphiQL interface for testing GraphQL queries and mutations.

### Sample Queries

Get all employees:

```graphql
query {
    getAllEmployees {
        id
        firstName
        lastName
        email
        department
    }
}
```

Get an employee by ID:

```graphql
query {
    getEmployeeById(id: 1) {
        id
        firstName
        lastName
        email
        department
    }
}
```

### Sample Mutations

Create an employee:

```graphql
mutation {
    createEmployee(employeeInput: {
        firstName: "John"
        lastName: "Doe"
        email: "john.doe@example.com"
        department: "Engineering"
    }) {
        id
        firstName
        lastName
        email
        department
    }
}
```

Update an employee:

```graphql
mutation {
    updateEmployee(id: 1, employeeInput: {
        firstName: "Jane"
        lastName: "Smith"
        email: "jane.smith@example.com"
        department: "Marketing"
    }) {
        id
        firstName
        lastName
        email
        department
    }
}
```

Delete an employee:

```graphql
mutation {
    deleteEmployee(id: 1)
}
```

---

## Conclusion

In this blog, we walked through building an Employee Management System using GraphQL and Spring Boot. We covered setting up the project, configuring GraphQL, defining the schema, creating entities, building the repository and service layers, implementing GraphQL resolvers, and testing the API. This combination of technologies provides a powerful and flexible way to handle data in modern applications.

---
# Exploring Integration of MinIO, MySQL, Jasper, and GraphQL with Spring Boot — Part 1

In modern application development, flexibility and efficiency are two key aspects that developers often look for. One technology that makes this possible is GraphQL. Unlike REST, GraphQL offers a more dynamic approach to interacting with APIs. Let’s see why GraphQL can be a more flexible option compared to REST, as well as the advantages of using Spring Boot in developing applications.

## Why is GraphQL More Flexible Than REST?

GraphQL allows clients to request only the data they need, no more and no less. Thus, overhead is reduced, and application performance is increased. In addition, GraphQL type schemas can be customized easily without disrupting existing clients. You only need one endpoint for different types of queries and mutations, which makes API management and documentation easy. In modern development, the flexibility offered by GraphQL is increasingly in demand due to its ability to cope with the complexity of data retrieval.

---

No need to linger, let’s create a simple project with Spring Boot GraphQL fruit-commerce case study. First, let’s understand the DB schema before initializing the project:

![Schema DB fruit-commer](https://miro.medium.com/v2/resize:fit:816/1*Gdn8eOZKJG7ArDVEH0LVqw.png)

There are 3 simple tables. Later, I will practice a simple transaction from this project using mutations from GraphQL.

---

## 1. Initiation

To start, we will initiate the Spring Boot project using Spring Initializr or a similar tool. We will add the necessary dependencies for MinIO, MySQL, Jasper, GraphQL, Lombok, Spring Data JPA, and Spring Boot Starter Web.

---

## 2. Create Entities According to the Database Schema

After setting up the connection configuration to the MySQL database, the next step is to create entities according to the database schema. Make sure the datasource configuration is set correctly in the `application.properties` file:

```properties
# Datasource Configuration
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
spring.datasource.url=jdbc:mysql://localhost:3306/xxx
spring.datasource.username=xxx
spring.datasource.password=xxx
```

Create a package called `entity` in your project to store all entity classes. Create an `Items` class. Here is an example of an `Items` class that you can use. This entity will represent the items table in your database.

```java
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class Items {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(unique = true, nullable = false, name = "item_id")
    private int itemId;
    private String itemName;
    private String itemCode;
    private String itemDescription;
    private Long stock;
    private Long price;
    private Boolean isAvailable;
    private LocalDateTime lastRestock;
    @OneToMany(mappedBy = "items", orphanRemoval = true, cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<Orders> orders;

    public Items(String itemName, String itemDescription, Long stock, Long price) {
        this.itemName = itemName;
        this.itemCode = generateItemCode();
        this.itemDescription = itemDescription;
        this.stock = stock;
        this.price = price;
        this.isAvailable = itemAvailable(stock);
    }

    public void setStock(Long stock) {
        this.stock = stock;
        this.isAvailable = stock > 0;
        this.lastRestock = LocalDateTime.now();
    }

    public void updateStock(Long stock) {
        this.stock = this.stock - stock;
        this.lastRestock = LocalDateTime.now();
        if (this.stock == 0) {
            this.isAvailable = itemAvailable(this.stock);
        }
    }

    private Boolean itemAvailable(Long Stock) {
        this.stock = Stock;
        this.isAvailable = stock > 0;
        return isAvailable;
    }

    private String generateItemCode() {
        UUID uuid = UUID.randomUUID();
        return uuid.toString().substring(0, 5);
    }
}
```

- `setStock()`: Sets the stock quantity and updates the availability status and the last restock time.
- `updateStock()`: Decreases the stock and updates the last restock time.
- `itemAvailable()`: Checks item availability based on stock.
- `generateItemCode()`: Generates a unique item code using the UUID.

Example on `ORDER` entity:

```java
@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
@JoinColumn(name = "item_id", nullable = false)
@JsonProperty("itemName")
private Items items;
```

The relationship between table item and table Order is one to many. In best practice, there should be no need to use cascade All because if you delete one item that references an order then both data in the table can be deleted.

---

## 3. Creating Repository for Communication with Database

Repository is an important component in Spring Data JPA that provides an interface for CRUD (Create, Read, Update, Delete) operations on entities. Here is an example of a repository implementation for the Items entity.

```java
@Repository
public interface ItemRepository extends JpaRepository<Items, Long> {
    // Search by item name only
    Page<Items> findByItemNameContainingIgnoreCase(String itemName, Pageable pageable);
    // Search by availability only
    Page<Items> findByIsAvailable(Boolean isAvailable, Pageable pageable);
    // Search by item name and availability
    Page<Items> findByItemNameContainingIgnoreCaseAndIsAvailable(String itemName, Boolean isAvailable, Pageable pageable);
}
```

- `@Repository`: Indicates that this interface is a Spring repository. It will be scanned by Spring and integrated into the application context.
- `JpaRepository<Items, Long>`: Provides built-in methods for CRUD operations and complex queries. `Items` is the entity type and `Long` is the data type of the primary key (`itemId`).
- **Custom Query Methods:**
    - `findByItemNameContainingIgnoreCase(String itemName, Pageable pageable)`: Returns the page (`Page<Items>`) of the item whose name contains the given text, regardless of case. The `Pageable` parameter is used for pagination of query results.
    - `findByIsAvailable(Boolean isAvailable, Pageable pageable)`: Returns the page of the item based on the availability status.
    - `findByItemNameContainingIgnoreCaseAndIsAvailable(String itemName, Boolean isAvailable, Pageable pageable)`: Returns a page of items whose names contain the given text and have the given availability status.

---

## 4. Creating a Service with Business Logic

A service is a place to store business logic in a Spring Boot application. The following is an explanation of the methods in the `ItemService` that implement the business logic for the `Items` entity.

```java
@Service
public class ItemService {
    private final ItemRepository itemRepository;
    @Autowired
    public ItemService(ItemRepository itemRepository) {
        this.itemRepository = itemRepository;
    }
    public ResponGetAllData<Items> getAllData(String itemName, Boolean isAvailable, int page, int size) {
        Pageable pageable = PageRequest.of(page - 1, size);
        Page<Items> itemsPage;
        if (itemName != null && isAvailable != null) {
            itemsPage = itemRepository.findByItemNameContainingIgnoreCaseAndIsAvailable(itemName, isAvailable, pageable);
        } else if (itemName != null) {
            itemsPage = itemRepository.findByItemNameContainingIgnoreCase(itemName, pageable);
        } else if (isAvailable != null) {
            itemsPage = itemRepository.findByIsAvailable(isAvailable, pageable);
        } else {
            itemsPage = itemRepository.findAll(pageable); // Fallback to all items
        }
        ResponHeader header = ResponHeaderMessage.getRequestSuccess();
        return new ResponGetAllData<>(header, itemsPage.getContent());
    }
    public ResponGetData getItem(String itemId) {
        Long id = Long.parseLong(itemId);
        Optional<Items> existingItem = itemRepository.findById(id);
        if (existingItem.isPresent()) {
            Items item = existingItem.get();
            ResponHeader header = ResponHeaderMessage.getRequestSuccess();
            return new ResponGetData(header, item);
        }
        ResponHeader header = ResponHeaderMessage.getDataNotFound();
        return new ResponGetData(header, null);
    }
    @Transactional
    public ResponHeader createItem(RequestItemCreateUpdate request) {
        ResponHeader header;
        try {
            Items newItem = new Items(
                    request.getItemName(),
                    request.getItemDescription(),
                    request.getStock() != null ? request.getStock() : 0,
                    request.getPrice() != null ? request.getPrice() : 0
            );
            itemRepository.save(newItem);
            header = ResponHeaderMessage.getRequestSuccess();
            header.setMessage("Success Create Item");
        } catch (Exception e) {
            header = ResponHeaderMessage.getBadRequestError();
            header.setMessage(e.getMessage());
        }
        return header;
    }
    @Transactional
    public ResponHeader updateItem(String itemId, RequestItemCreateUpdate request) {
        Long id = Long.parseLong(itemId);
        Optional<Items> existingItem = itemRepository.findById(id);
        if (existingItem.isPresent()) {
            Items item = existingItem.get();
            if (request.getItemName() != null) {
                item.setItemName(request.getItemName());
            }
            if (request.getStock() != null) {
                item.setStock(request.getStock());
                item.setLastRestock(LocalDateTime.now());
            }
            if (request.getPrice() != null) {
                item.setPrice(request.getPrice());
            }
            if (request.getItemDescription() != null) {
                item.setItemDescription(request.getItemDescription());
            }
            itemRepository.save(item);
            ResponHeader header = ResponHeaderMessage.getRequestSuccess();
            header.setMessage("Success Update Item");
            return header;
        }
        return ResponHeaderMessage.getBadRequestError();
    }
    @Transactional
    public ResponHeader deleteItem(String itemId) {
        Long id = Long.parseLong(itemId);
        Optional<Items> existingItem = itemRepository.findById(id);
        if (existingItem.isPresent()) {
            itemRepository.delete(existingItem.get());
            return ResponHeaderMessage.getRequestSuccess();
        }
        return ResponHeaderMessage.getBadRequestError();
    }
}
```

- `getAllData`: Retrieves data on all items by name and/or availability, with pagination support.
- `getItem`: Converts itemId to Long type. Searches for items by ID using the repository. Returns the item data if found, or an error message if not.
- `createItem`: Creates a new `Items` object from the data provided in the request. Saves the new item to the database using the repository. Handles exceptions if an error occurs during storage. Returns an appropriate response based on the result of the operation.
- `updateItem`: Converts itemId to Long type. Searches for the item by ID using the repository. If the item is found, updates the properties given in the request. Saves the changes to the database using the repository. Returns the appropriate response based on the result of the operation.
- `deleteItem`: Converts itemId to Long type. Searches for the item based on the ID using the repository. If the item is found, removes it from the database using the repository. Returns the appropriate response based on the result of the operation.

---

## 5. DTO and Response Classes

In this project, you have used several Data Transfer Object (DTO) and response classes to manage the input and output of the service. Here is a description of each class and their roles:

### DTO: RequestItemCreateUpdate

This DTO is used to receive input data when creating or updating items.

```java
@AllArgsConstructor
@Getter
@Setter
public class RequestItemCreateUpdate {
    private String itemName;
    private String itemDescription;
    private Long price;
    private Long stock;
}
```

### Response Classes

#### ResponGetAllData

Serves as a header in each response that provides general information about the status of the response.

```java
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ResponGetAllData<T> {
    private ResponHeader header;
    private List<T> data;
}
```

#### ResponGetData

Used to return a response that contains one entity (single data)

```java
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ResponGetData<T> {
    private ResponHeader header;
    private T data;
}
```

---

## 6. Creating a Controller that Integrates Client Responses with GraphQL

This controller is responsible for handling requests from the client and directing them to the appropriate service. In the context of Spring Boot with GraphQL, this controller also serves as a resolver for GraphQL queries and mutations.

```java
@Controller
public class ItemController {
    private final ItemService itemService;
    @Autowired
    public ItemController(ItemService itemService) {
        this.itemService = itemService;
    }
    @QueryMapping
    public ResponGetAllData<?> getAllItem(@Argument String itemName, @Argument Boolean isAvailable, @Argument int page, @Argument int size) {
        return itemService.getAllData(itemName, isAvailable, page, size);
    }
    @QueryMapping
    public ResponGetData<?> getItem(@Argument String itemId) {
        return itemService.getItem(itemId);
    }
    @MutationMapping
    public ResponHeader createItem(@Argument("createItem") RequestItemCreateUpdate requestItemCreateUpdate) {
        return itemService.createItem(requestItemCreateUpdate);
    }
    @MutationMapping
    public ResponHeader updateItem(@Argument String id, @Argument("updateItem") RequestItemCreateUpdate requestItemCreateUpdate) {
        return itemService.updateItem(id, requestItemCreateUpdate);
    }
    @MutationMapping
    public ResponHeader deleteItem(@Argument String id) {
        return itemService.deleteItem(id);
    }
}
```

### Query Mapping and Mutation

- **Query Mapping (`@QueryMapping`)**: Used to define a GraphQL query that will retrieve data without modifying it. This annotated method will be called when the client executes the corresponding GraphQL query. Example: `getAllItem` and `getItem`.
- **Mutation (`@MutationMapping`)**: Used to define GraphQL mutations that will modify data. This annotated method will be called when the client executes the corresponding GraphQL mutation. Example: `createItem`, `updateItem`, and `deleteItem`.

---

## Controller as Resolver

This controller acts as a GraphQL resolver, which means it is responsible for mapping GraphQL queries and mutations to corresponding Java methods. The resolver parses the GraphQL request and calls the relevant business logic in the service, then returns the results in the format specified by the GraphQL schema.

---

I am very excited to write this article and share my knowledge with you all. Learning and technological developments are always interesting to follow. Given the length of the topic, I decided to split this article into two parts.

In this first part, we have covered the basics and initial steps in building a Spring Boot project with MySQL, and GraphQL integration. In the second part, we will continue with a more in-depth discussion and complete this project to completion Minio, Jasper, and Graphql.

Thank you for following along until the end of this first part. Keep up the good work and keep growing. See you in part two!
---

# GraphQL with Spring Boot 
GraphQL is a query language for APIs that allows you to control what properties are needed for your use case and query exactly for those properties.

Spring Boot is a very popular Java framework and from Spring Boot 2.7 we are getting framework support for GraphQL.

If you are not a member, you can read from [here](https://fahimfahad92.medium.com/graphql-with-spring-boot-05fcc1f8080b?sk=4aa2828da130a0b9b946cc7d71b78dcd)

---

## Overview

In this article I will demonstrate:

1. Basic mutation type
2. Mutation with input type
3. Basic Query type (single and batch)
4. Multiple schema files for specific domains
5. Exception handling
6. Integration tests

The template is also available in [GitHub](https://github.com/fahimfahad92/spring-boot-graphql). Let’s begin 🙂

---

## Initial Setup

For this demonstration, I will write GraphQL mutations and queries to get user data. User has basic properties and one nested object for address.

To keep it simple, I did not use any databases. I will create users using mutation and store them in the memory.

I created a Spring Boot project using IntelliJ IDEA. I am using Spring Boot 3.3.4 and Java 21. But Java 17 should be enough too.

For GraphQL, I have added a few dependencies in `pom.xml`:

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-graphql</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-web</artifactId>
</dependency>
<!-- For integration tests -->
<dependency>
    <groupId>org.springframework.graphql</groupId>
    <artifactId>spring-graphql-test</artifactId>
    <scope>test</scope>
</dependency>
<!-- Needed for WebTestClient -->
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-webflux</artifactId>
    <version>${spring-webflux.version}</version>
</dependency>
```

In the resources folder, I created a directory named `graphql` and added a file named `schema.graphqls` where I will write my initial GraphQL specific types.

In the `application.properties` file, I set `spring.graphql.graphiql.enabled=true` to enable GraphQL IDE. If I run the project locally, GraphQL IDE will be available here: [http://localhost:8080/graphiql](http://localhost:8080/graphiql)

---

We are all set for writing our mutations and queries.

# Mutation

Mutation is a GraphQL way of creating or updating data on the server side. For my case, I created two objects for user and address in the `schema.graphqls` file.

```graphql
type User {
    id: ID
    name: String
    address: Address
}

type Address {
    id: ID
    road: String
    house: String
    flat: String
}
```

## Basic Mutation Type

Now to create user data on the server, I added a basic GraphQL mutation. I created a `UserController` to receive mutation requests.

Here I am only setting the user name. Initially, the address will be null, and I will add another mutation to update the address.

```graphql
type Mutation {
    addUser(name: String): User
}
```

If I run the project, I should be able to create a user using the below mutation:

```graphql
mutation {
  addUser(name: "Fahim") {
    id
    name
  }
}
```

Server will return user id and name as I listed these 2 properties in the mutation.

```java
@MutationMapping
public User addUser(@Argument String name) {
    return userService.addUser(name);
}
```

Here, `name` is mapped to `@Argument` name and `UserService` will add the user to our storage. I am not going into the detail on how I am managing users in the memory/DB.

---

## Mutation with Input Type

For the address object, we can see there are more properties to send in the request. For a normal mutation we will need to write a mutation like this:

```graphql
mutation {
  updateAddress(road: "road", house: "house", flat: "flat") {
    id
    road
    house
    flat
  }
}
```

But it will get complex for larger objects. To make it readable we can use **Input** type. I am using input type for updating user address.

I created an input type in the schema file:

```graphql
input AddressRequest {
    userId: ID
    road: String
    house: String
    flat: String
}
```

My GraphQL mutations are:

```graphql
type Mutation {
    addUser(name: String): User
    updateAddress(addressRequest: AddressRequest): User
}
```

Now I can simplify the mutation request and it will update user address and return the specified properties.

```graphql
mutation {
  updateAddress(addressRequest: {
    userId: 1,
    flat: "flat",
    house: "house",
    road: "road"
  }) {
    id
    name
    address {
      id
      road
      flat
      house
    }
  }
}
```

In the backend I created a record `AddressRequest`:

```java
public record AddressRequest(int userId, String road, String house, String flat) {}
```

Now I can easily map the mutation in my controller:

```java
@MutationMapping
public User updateAddress(@Argument AddressRequest addressRequest) {
    return userService.updateAddress(addressRequest);
}
```

Here, I am taking an object as argument because I specified an input type in the mutation. This simplifies the request.

---

## GraphQL Query

Now I created my mutation types and created a few data. I will now add three queries to get all users, get a specific user by ID, and get user addresses by user ID.

```graphql
type Query {
    users: [User]
    userByID(id: Int): User
    userAddress(userId: Int): Address
}
```

Now the basic queries can be like below:

### First Query: Returns all the users in the system

```graphql
query {
  users {
    id
    name
    address {
      road
      flat
      house
    }
  }
}
```

In the `UserController`:

```java
@QueryMapping
public Collection<User> users() {
    logger.info("Getting all user");
    return userService.users();
}

@BatchMapping
Map<User, Address> address(Collection<User> users) {
    logger.info("Getting data for {}", users.size());
    Map<User, Address> userAddressMap = new HashMap<>();
    Map<Integer, Address> addressMap =
        userService.getUserAddress(users.stream().map(User::getId).collect(Collectors.toList()));
    for (User user : users) {
        userAddressMap.put(user, addressMap.get(user.getId()));
    }
    return userAddressMap;
}
```

Here, the user got the address property, which is nested, and we need another query to get the user’s address. I am using `@BatchMapping` here to optimize the performance. It is taking all the users in the argument and this will allow us to get all users addresses at the same time. If the address is in DB, then we can get all the user addresses in one query.

If we used `@SchemaMapping` then it will cause N+1 problem and it will cause performance issues. `@BatchMapping` is an excellent way to improve performance for cases like this.

### Second Query: This will return a single user using the id passed as argument

```graphql
query {
  userByID(id: 1) {
    id
    name
    address {
      road
      flat
      house
    }
  }
}
```

UserController:

```java
@QueryMapping
public User userByID(@Argument int id) {
    logger.info("Getting user {}", id);
    return userService.userByID(id);
}
```

This is a very simple query mapping. I am passing user id in the query and it is mapped in the `@Argument`.

### Third Query: This will return only the address of a user based on userId passed as argument

```graphql
query {
  userAddress(userId: 1) {
    road
    flat
    house
  }
}
```

UserController:

```java
@QueryMapping
public Address userAddress(@Argument int userId) {
    logger.info("Getting user address {}", userId);
    return userService.getUserAddress(userId);
}
```

We need to be very careful about the `@Argument` and method naming. They need to match with the graphqls files.

---

## Multiple GraphQL Files for Specific Domain

It is very common that we have many objects in our system and if we add all of them in a single graphqls file, it will become unmanageable and unreadable. So to improve readability and management, I used separate graphqls files for my user related objects. My updated file structure looks like below:

![GraphQL Folder Structure](https://miro.medium.com/v2/resize:fit:514/1*-sVpd-XjcDFIZZ0SlSg7bA.png)

Inside the `graphql` directory, I created another folder named `user` and created two more graphqls files. One is for user related query and mutation. Another is for user related objects. Now my updated files will look like below:

**schema.graphqls:**

```graphql
type Query {}
type Mutation {}
```

**user-dto.graphqls:**

```graphql
type User {
    id: ID
    name: String
    address: Address
}

type Address {
    id: ID
    road: String
    house: String
    flat: String
}

input AddressRequest {
    userId: ID
    road: String
    house: String
    flat: String
}
```

**user-query.graphqls:**

```graphql
extend type Query {
    users: [User]
    userByID(id: Int): User
    userAddress(userId: Int): Address
}

extend type Mutation {
    addUser(name: String): User
    updateAddress(addressRequest: AddressRequest): User
}
```

---

## Exception Handling

It is very common for an application to throw exceptions and return error messages. But the GraphQL error response was not very helpful for me. So I added an exception resolver for GraphQL. I override the `resolveToSingleError` method of the `DataFetcherExceptionResolverAdapter` class to return a proper error message for error cases.

```java
@Component
public class GraphQLExceptionResolver extends DataFetcherExceptionResolverAdapter {
    @Override
    public GraphQLError resolveToSingleError(Throwable ex, DataFetchingEnvironment env) {
        return switch (ex) {
            case UserNotFound unf ->
                prepareGraphQLErrorResponse(
                    unf.getMessage(), ErrorType.NOT_FOUND, env, Map.of("statusCode", 400));
            case AddressNotFound anf ->
                prepareGraphQLErrorResponse(
                    anf.getMessage(), ErrorType.NOT_FOUND, env, Map.of("statusCode", 400));
            default ->
                prepareGraphQLErrorResponse(
                    "Internal server error",
                    ErrorType.INTERNAL_ERROR,
                    env,
                    Map.of("statusCode", HttpStatusCode.valueOf(500)));
        };
    }

    private GraphQLError prepareGraphQLErrorResponse(
        String message,
        ErrorType errorType,
        DataFetchingEnvironment env,
        Map<String, Object> extensions) {
        return GraphqlErrorBuilder.newError()
            .errorType(errorType)
            .message(message)
            .path(env.getExecutionStepInfo().getPath())
            .location(env.getField().getSourceLocation())
            .extensions(extensions)
            .build();
    }
}
```

---

## Integration Test

Now I will add some integration tests for my mutations and queries. Sample class is below:

```java
@SpringBootTest
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class UserTest {
    WebTestClient client;
    HttpGraphQlTester tester;

    @BeforeAll
    void setUp(WebApplicationContext context) {
        client =
            MockMvcWebTestClient.bindToApplicationContext(context)
                .configureClient()
                .baseUrl("/graphql")
                .build();
        tester = HttpGraphQlTester.create(client);
    }

    @Test
    @Order(1)
    void shouldCreateUser() {
        var document =
            """
                mutation {
                  addUser(name: \"Fahim\") {
                    id
                    name
                  }
                }
            """;
        var user = tester.document(document).execute().path("addUser").entity(User.class).get();
        assertEquals(user.getName(), "Fahim");
        assertTrue(user.getId() > 0);
    }
}
```

Complete test class can be found [here](https://github.com/fahimfahad92/spring-boot-graphql/blob/master/src/test/java/com/rnd/springbootgraphql/UserTest.java). For my test I had to configure `WebTestClient` and `HttpGraphQlTester`.

---

## Conclusion

GraphQL is a great way to communicate with backend servers and optimize the APIs. Spring Boot integration is very simple and easy to write. I hope this article will help you get started.
---
# Exploring Integration of MinIO, MySQL, Jasper, and GraphQL with Spring Boot — Part 2

In the second part of this article, we will dive deeper into integration with GraphQL, MinIO implementation, and creating a reporting API using Jasper Report. Let’s start by explaining the GraphQL schema that you have created. In the resources folder we will find the `graphql` folder if you have added dependencies. In that folder, let’s create a schema that represents the item entity that was created earlier:

## GraphQL Schema

```graphql
type Items {
    itemId: ID!
    itemName: String
    itemDescription: String
    price: Float
    stock: Int
    isAvailable: Boolean
    lastRestock: String
}

input RequestItemCreateUpdate {
    itemName: String!
    itemDescription: String
    price: Int!
    stock: Int!
}

type ResponseItems {
    header: ResponHeader
    data: [Items]
}

type ResponseItem {
    header: ResponHeader
    data: Items
}

type ResponHeader {
    code: String
    status: Boolean
    message: String
}

type Query {
    getAllItem(itemName: String, isAvailable: Boolean, page: Int, size: Int): ResponseItems
    getItem(itemId: ID!): ResponseItem
}

type Mutation {
    updateItem(id: ID!, updateItem: RequestItemCreateUpdate): ResponHeader
    createItem(createItem: RequestItemCreateUpdate): ResponHeader
    deleteItem(id: ID!): ResponHeader
}
```

- **Data Types:** GraphQL defines some basic data types such as ID, String, Float, Int, and Boolean. These are used to define the data structures sent and received by the API.
- **Input Types:** Used to define the format of data received from the client while mutating. This helps ensure that the data sent matches the expected format.
- **Response Types:** Defines the structure of the data returned by the API. This includes header information and data, allowing the client to understand the result of the query or mutation performed.

With this schema, you have defined the data structure that will be used in your GraphQL API, which includes how data will be sent to the server and how the server will respond to client requests. We will proceed by defining the query and mutation in GraphQL using the `schema.graphqls` file. This file contains definitions for the query and mutation that will be associated with the resolver in the controller.

---

## Synchronization with Controller

To ensure that the schema in `schema.graphqls` is properly connected to the controller and works as a resolver, note the following:

- **Names and Parameters:** Ensure that the names and parameters used in queries and mutations in `schema.graphqls` match the methods in the controller. For example, the names of the `getAllItem` and `getItem` methods in the schema must match the names of the methods defined in the `ItemController`. The same goes for mutations like `updateItem`, `createItem`, and `deleteItem`.
- **Resolver:** Any method in the controller defined with `@QueryMapping` or `@MutationMapping` will act as a resolver for queries and mutations defined in the schema. If there is a mismatch in the name or parameters, the method will not be detected as a resolver, and GraphQL will not be able to execute the query or mutation.

By ensuring that the definitions in `schema.graphqls` and the methods in the controller match, you can ensure that GraphQL will be able to process and respond to requests correctly.

---

## 8. Integrating MinIO with Your Application

To start, we’ll set up MinIO using Docker. Below is a `docker-compose.yml` configuration file for running MinIO locally:

```yaml
version: '3.7'
services:
  minio:
    image: minio/minio
    container_name: minio
    environment:
      MINIO_ROOT_USER: minioadmin
      MINIO_ROOT_PASSWORD: minioadmin
    ports:
      - "9000:9000"
      - "9001:9001"
    volumes:
      - ./src/main/resources/photo:/data
    command: server /data --console-address ":9001"
volumes:
  minio-data:
```

With this setup, you can access MinIO’s web interface at `localhost:9001` to manage buckets and files.

---

### Configuring MinIO in `application.properties`

Add the following MinIO configurations to your `application.properties`:

```properties
# MinIO Configuration
minio.endpoint=http://localhost:9000
minio.accessKey=minioadmin
minio.secretKey=minioadmin
minio.bucketName=webstore
```

These properties configure the endpoint, access key, secret key, and bucket name for MinIO.

---

## MinIO Service Configuration

Here’s the `MinioService` class for managing MinIO operations:

```java
@Service
public class MinioService {
    @Value("${minio.endpoint}")
    private String endpoint;
    @Value("${minio.accessKey}")
    private String accessKey;
    @Value("${minio.secretKey}")
    private String secretKey;
    @Value("${minio.bucketName}")
    private String bucketName;
    private MinioClient minioClient;

    @PostConstruct
    public void initializeMinioClient() {
        minioClient = MinioClient.builder()
                .endpoint(endpoint)
                .credentials(accessKey, secretKey)
                .build();
        createBucketIfNotExists();
    }

    public void createBucketIfNotExists() {
        try {
            boolean isExist = minioClient.bucketExists(BucketExistsArgs.builder().bucket(bucketName).build());
            if (!isExist) {
                minioClient.makeBucket(MakeBucketArgs.builder().bucket(bucketName).build());
            }
        } catch (Exception e) {
            throw new RuntimeException("Error while checking or creating bucket", e);
        }
    }

    public void uploadFile(String fileName, byte[] data) {
        try {
            InputStream inputStream = new ByteArrayInputStream(data);
            minioClient.putObject(
                    PutObjectArgs.builder()
                            .bucket(bucketName)
                            .object(fileName)
                            .stream(inputStream, data.length, -1)
                            .contentType("image/jpeg")
                            .build()
            );
        } catch (Exception e) {
            throw new RuntimeException("Error while uploading file", e);
        }
    }

    public void deleteFile(String fileName) {
        try {
            minioClient.removeObject(
                    RemoveObjectArgs.builder()
                            .bucket(bucketName)
                            .object(fileName)
                            .build()
            );
        } catch (Exception e) {
            throw new RuntimeException("Error while deleting file", e);
        }
    }

    public String getObjectUrl(String objectName) {
        return endpoint + "/" + bucketName + "/" + objectName;
    }
}
```

- `initializeMinioClient`: Initializes the MinIO client and ensures the bucket exists.
- `uploadFile`: Uploads a file to MinIO using a byte array. Converts the byte array to an `InputStream` and specifies the content type.
- `deleteFile`: Deletes a file from MinIO based on the file name.
- `getObjectUrl`: Returns the URL of the stored object in MinIO.

---

## Integrating MinIO with Customer Service

Here’s how the `CustomerService` class utilizes `MinioService`:

```java
@Transactional
public ResponHeader createCustomer(RequestCustomerCreateUpdate request) {
    Customers customer = Customers.builder()
            .customerName(request.getCustomerName())
            .customerPhone(request.getCustomerPhone())
            .customerAddress(request.getCustomerAddress())
            .isActive(request.getIsActive())
            .build();
    customer.setCustomerCode(UUID.randomUUID().toString().substring(0, 5));
    // Decode base64 image data if present
    if (request.getPic() != null) {
        try {
            String base64Data = request.getPic().replaceFirst("data:image/.*;base64,", "");
            byte[] decodedBytes = Base64.getDecoder().decode(base64Data);
            String fileName = customer.getCustomerCode() + "_" + customer.getCustomerName() + ".jpg";
            minioService.uploadFile(fileName, decodedBytes);
            customer.setPic(fileName);
        } catch (Exception e) {
            ResponHeader header = ResponHeaderMessage.getBadRequestError();
            header.setMessage(e.getMessage());
            return header;
        }
    }
    repository.save(customer);
    ResponHeader header = ResponHeaderMessage.getRequestSuccess();
    header.setMessage("Customer created successfully");
    return header;
}

public ResponGetData getCustomerById(String id) {
    Long customerId = Long.parseLong(id);
    Optional<Customers> customerExisting = repository.findById(customerId);
    if (customerExisting.isPresent()) {
        Customers customer = customerExisting.get();
        customer.setPic(minioService.getObjectUrl(customer.getPic()));
        ResponHeader header = ResponHeaderMessage.getRequestSuccess();
        return new ResponGetData(header, customer);
    }
    ResponHeader header = ResponHeaderMessage.getDataNotFound();
    return new ResponGetData(header, null);
}

@Transactional
public ResponHeader deleteCustomer(String id) {
    Long customerId = Long.parseLong(id);
    Optional<Customers> customer = repository.findById(customerId);
    if (customer.isPresent()) {
        Customers deleteCustomer = customer.get();
        try {
            String fileName = deleteCustomer.getPic();
            repository.delete(deleteCustomer);
            if (fileName != null && !fileName.isEmpty()) {
                minioService.deleteFile(fileName);
            }
            ResponHeader header = ResponHeaderMessage.getRequestSuccess();
            header.setMessage("Customer deleted successfully");
            return header;
        } catch (DataIntegrityViolationException e) {
            return ResponHeaderMessage.getBadRequestError();
        }
    }
    return ResponHeaderMessage.getDataNotFound();
}
```

- `createCustomer`: Creates a new customer and uploads the picture to MinIO if provided. The image data is decoded from Base64 format.
- `getCustomerById`: Retrieves a customer by ID and provides a URL to the stored picture in MinIO.
- `deleteCustomer`: Deletes a customer and its associated picture from MinIO.

With these integrations, you now have a fully functional setup for managing customer images using MinIO and handling them within your application.

---

## 9. Creating Reports with JasperReports

In this final section, we’ll integrate JasperReports for generating reports in your application. JasperReports is a powerful tool for creating dynamic and interactive reports. Here’s a step-by-step guide to get started:

### Download and Install Jasper Studio

Before starting to build a report template, you need to install Jasper Studio [here](https://community.jaspersoft.com/download-jaspersoft/community-edition/).

- Create a new report: File → New → Jasper Report → Choose a template → Enter report name → Select sample database → Input query (e.g., `SELECT * FROM orders`).
- Adjust the report template to match your database schema.

By following these steps, you can successfully create, customize, and integrate JasperReports into your application, providing powerful reporting capabilities for your users.

---

### Integrate with Spring Boot

This service handles generating reports based on orders and exporting them as PDF files.

```java
@Service
public class ReportService {
    private final OrderService orderService;
    @Autowired
    public ReportService(OrderService orderService) {
        this.orderService = orderService;
    }
    public File exportJasperReport(String name, String item) throws JRException, IOException {
        ResponGetAllData<Orders> data = orderService.getAllOrder(name, item, 1, 100);
        List<Orders> ordersList = data.getData();
        // Get file and compile it
        File file = ResourceUtils.getFile("classpath:order_report.jrxml");
        JasperReport jasperReport = JasperCompileManager.compileReport(file.getAbsolutePath());
        JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(ordersList);
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("createdBy", "Simplifying Tech");
        // Fill Jasper report
        JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, dataSource);
        // Define the output directory and file name
        String reportDir = "src/main/resources/report";
        File reportDirFile = new File(reportDir);
        if (!reportDirFile.exists()) reportDirFile.mkdirs(); // Create directory if it does not exist
        String fileName = "order_report_" + new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + ".pdf";
        File pdfFile = new File(reportDirFile, fileName);
        // Export report to PDF
        try (OutputStream outputStream = new FileOutputStream(pdfFile)) {
            JasperExportManager.exportReportToPdfStream(jasperPrint, outputStream);
        }
        return pdfFile;
    }
}
```

- **Initialization:** The `exportJasperReport` method fetches order data, compiles the `.jrxml` report, fills it with data, and exports it as a PDF file.
- **Output Directory:** The report is saved in `src/main/resources/report` with a timestamp in its filename.
- **Service Integration:** The `ReportService` relies on `OrderService` to retrieve data and generate the report.

---

## 10. Creating the Report Controller

This controller exposes an endpoint to generate and download a PDF report based on the specified parameters. Here’s how you can set it up:

```java
@RestController
@Slf4j
@RequestMapping("/v1")
public class ReportController {
    private final ReportService service;
    @Autowired
    public ReportController(ReportService service) {
        this.service = service;
    }
    @GetMapping("/report-download")
    public ResponseEntity<Resource> createPDF(
            @RequestParam(value = "name", required = false) String name,
            @RequestParam(value = "item", required = false) String item) throws IOException, JRException {
        // Generate report and get the file
        File pdfFile = service.exportJasperReport(name, item);
        // Prepare response
        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + pdfFile.getName());
        headers.setContentType(org.springframework.http.MediaType.APPLICATION_PDF);
        return ResponseEntity.ok()
                .headers(headers)
                .contentLength(pdfFile.length())
                .body(new FileSystemResource(pdfFile));
    }
}
```

- **Request URL:** `http://localhost:8080/v1/report-download?name=JohnDoe&item=Laptop`
- **Response:** The client will receive a PDF file download prompt with the generated report.

---

## Conclusion

The project successfully integrates Spring Boot with GraphQL, MinIO, and JasperReports to create a robust application for managing data and generating reports. The use of modern technologies ensures that the system is scalable, flexible, and capable of handling various reporting needs. With a well-defined architecture and clear integration points, this project provides a solid foundation for further development and customization. You can find my code on GitHub for both [server](https://github.com/ZudaPradana/Spring-GrapQL-Store-Project.git) and simple [client](https://github.com/ZudaPradana/simple-angular17-store-project.git) using Angular.

---
# Implementing CRUD Operations in GraphQL with Spring Boot and MySQL

This guide provides a step-by-step tutorial on how to implement CRUD (Create, Read, Update, Delete) operations using GraphQL with Spring Boot and MySQL. It covers setting up a Spring Boot project, configuring MySQL, defining models, creating GraphQL schemas, implementing repository and service layers, and using GraphQL queries and mutations to interact with the database.

## Steps Overview

1. **Set up the project with Spring Boot and GraphQL dependencies.**
2. **Configure MySQL database in Spring Boot.**
3. **Define the model (entity) class.**
4. **Create the GraphQL schema.**
5. **Implement the service and repository layer.**
6. **Implement the GraphQL resolvers.**
7. **Test the CRUD operations using Postman.**

---

## Step 1: Set Up the Spring Boot Project

You can generate a Spring Boot project using [Spring Initializr](https://start.spring.io/) with the following dependencies:

- Spring Web
- Spring Data JPA
- MySQL Driver
- GraphQL

Your `pom.xml` will look like this:

```xml
<dependencies>
    <!-- Spring Boot Starter for Web -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <!-- Spring Boot Starter Data JPA -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-data-jpa</artifactId>
    </dependency>
    <!-- MySQL Connector -->
    <dependency>
        <groupId>mysql</groupId>
        <artifactId>mysql-connector-java</artifactId>
        <scope>runtime</scope>
    </dependency>
    <!-- GraphQL Dependencies -->
    <dependency>
        <groupId>com.graphql-java-kickstart</groupId>
        <artifactId>graphql-spring-boot-starter</artifactId>
        <version>11.1.0</version>
    </dependency>
    <dependency>
        <groupId>com.graphql-java-kickstart</groupId>
        <artifactId>graphiql-spring-boot-starter</artifactId>
        <version>11.1.0</version>
        <scope>runtime</scope>
    </dependency>
    <!-- Lombok for reducing boilerplate code -->
    <dependency>
        <groupId>org.projectlombok</groupId>
        <artifactId>lombok</artifactId>
        <optional>true</optional>
    </dependency>
    <!-- Spring Boot DevTools -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-devtools</artifactId>
        <scope>runtime</scope>
    </dependency>
</dependencies>
```

---

## Step 2: Configure MySQL Database in Spring Boot

Add the MySQL database connection details to `src/main/resources/application.properties`:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/graphql_db?useSSL=false
spring.datasource.username=root
spring.datasource.password=your_password
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQL5Dialect
```

---

## Step 3: Define the Model (Entity) Class

We'll create a `User` entity with fields like `id`, `name`, and `email`.

```java
package com.example.graphql.model;

import lombok.Data;
import javax.persistence.*;

@Data
@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;
}
```

---

## Step 4: Create the GraphQL Schema

In `src/main/resources/graphql/` create a file `schema.graphqls`:

```graphql
type User {
    id: ID
    name: String
    email: String
}

type Query {
    getUser(id: ID!): User
    getAllUsers: [User]
}

type Mutation {
    createUser(name: String!, email: String!): User
    updateUser(id: ID!, name: String!, email: String!): User
    deleteUser(id: ID!): String
}
```

- **Query Resolvers**: Handle requests to **fetch** data (like `getUser`, `getAllUsers`).
- **Mutation Resolvers**: Handle requests to **modify** data (like `createUser`, `updateUser`, `deleteUser`).

---

## Step 5: Implement the Service and Repository Layer

### Repository Interface

```java
package com.example.graphql.repository;

import com.example.graphql.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
}
```

### Service Class

```java
package com.example.graphql.service;

import com.example.graphql.model.User;
import com.example.graphql.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public User createUser(String name, String email) {
        User user = new User();
        user.setName(name);
        user.setEmail(email);
        return userRepository.save(user);
    }

    public User updateUser(Long id, String name, String email) {
        Optional<User> optionalUser = userRepository.findById(id);
        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            user.setName(name);
            user.setEmail(email);
            return userRepository.save(user);
        }
        throw new RuntimeException("User not found");
    }

    public String deleteUser(Long id) {
        userRepository.deleteById(id);
        return "User deleted";
    }

    public User getUser(Long id) {
        return userRepository.findById(id).orElse(null);
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
}
```

---

## Step 6: Implement the GraphQL Resolvers

### User GraphQL Query and Mutation Resolvers

```java
package com.example.graphql.resolver;

import com.example.graphql.model.User;
import com.example.graphql.service.UserService;
import graphql.kickstart.tools.GraphQLMutationResolver;
import graphql.kickstart.tools.GraphQLQueryResolver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class UserResolver implements GraphQLQueryResolver, GraphQLMutationResolver {
    @Autowired
    private UserService userService;

    // Queries
    public User getUser(Long id) {
        return userService.getUser(id);
    }

    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }

    // Mutations
    public User createUser(String name, String email) {
        return userService.createUser(name, email);
    }

    public User updateUser(Long id, String name, String email) {
        return userService.updateUser(id, name, email);
    }

    public String deleteUser(Long id) {
        return userService.deleteUser(id);
    }
}
```

---

## Step 7: Testing CRUD Operations in Postman

To test your GraphQL API in Postman, follow these steps:

1. **Create a Postman request:**
   - URL: `http://localhost:8080/graphql`
   - Method: `POST`
   - Header: `Content-Type: application/json`

2. **Sample Input for Create User (Mutation):**

```json
{
  "query": "mutation { createUser(name: \"John Doe\", email: \"john.doe@example.com\") { id name email } }"
}
```

**Expected Output:**

```json
{
  "data": {
    "createUser": {
      "id": "1",
      "name": "John Doe",
      "email": "john.doe@example.com"
    }
  }
}
```

3. **Sample Input for Get User (Query):**

```json
{
  "query": "query { getUser(id: 1) { id name email } }"
}
```

**Expected Output:**

```json
{
  "data": {
    "getUser": {
      "id": "1",
      "name": "John Doe",
      "email": "john.doe@example.com"
    }
  }
}
```

4. **Sample Input for Update User (Mutation):**

```json
{
  "query": "mutation { updateUser(id: 1, name: \"Jane Doe\", email: \"jane.doe@example.com\") { id name email } }"
}
```

**Expected Output:**

```json
{
  "data": {
    "updateUser": {
      "id": "1",
      "name": "Jane Doe",
      "email": "jane.doe@example.com"
    }
  }
}
```

5. **Sample Input for Delete User (Mutation):**

```json
{
  "query": "mutation { deleteUser(id: 1) }"
}
```

**Expected Output:**

```json
{
  "data": {
    "deleteUser": "User deleted"
  }
}
```

6. **Sample Input for Get All Users (Query):**

```json
{
  "query": "query { getAllUsers { id name email } }"
}
```

**Expected Output:**

```json
{
  "data": {
    "getAllUsers": [
      {
        "id": "1",
        "name": "Jane Doe",
        "email": "jane.doe@example.com"
      }
    ]
  }
}
```
# GraphQL in Spring Boot: Advanced Schema Design and Performance Optimization

**GraphQL** offers a flexible way to build APIs by allowing clients to request exactly the data they need. While basic GraphQL APIs are easy to set up with Spring Boot, advanced use cases like **complex filtering**, **schema stitching**, and **performance optimization** for deeply nested queries require specialized techniques.

This guide explores **advanced GraphQL schema design** and performance tuning to create efficient, scalable APIs with Spring Boot.

---

## 1. Setting Up GraphQL in Spring Boot

### 1.1 Add GraphQL Dependencies

Include the necessary GraphQL dependencies in your `pom.xml`:

```xml
<dependency>
    <groupId>com.graphql-java-kickstart</groupId>
    <artifactId>graphql-spring-boot-starter</artifactId>
    <version>15.0.0</version>
</dependency>
<dependency>
    <groupId>com.graphql-java-kickstart</groupId>
    <artifactId>graphql-java-tools</artifactId>
    <version>11.1.0</version>
</dependency>
```

### 1.2 Basic GraphQL Setup

Define your schema in a `.graphqls` file:

```graphql
type Query {
    books(filter: BookFilter): [Book]
}

type Book {
    id: ID!
    title: String!
    author: Author
}

type Author {
    id: ID!
    name: String!
}
```

Implement resolvers using Spring components:

```java
@Component
public class BookResolver implements GraphQLQueryResolver {
    public List<Book> books(BookFilter filter) {
        return bookService.getBooks(filter);
    }
}
```

This setup enables basic GraphQL query functionality.

---

## 2. Advanced Schema Design Techniques

### 2.1 Complex Filtering and Pagination

For complex filtering, define a `FilterInput` type with nested filter options.

**Schema Definition:**

```graphql
input BookFilter {
    title: String
    authorName: String
    priceRange: PriceRange
}

input PriceRange {
    min: Float
    max: Float
}
```

**Resolver Implementation:**

```java
public List<Book> books(BookFilter filter) {
    return bookRepository.findBooks(filter.getTitle(), filter.getAuthorName(), filter.getPriceRange());
}
```

Combine filtering with **cursor-based pagination** for large datasets.

**Schema with Pagination:**

```graphql
type PaginatedBooks {
    books: [Book]
    nextCursor: String
}

type Query {
    paginatedBooks(cursor: String, limit: Int): PaginatedBooks
}
```

**Resolver Implementation:**

```java
public PaginatedBooks paginatedBooks(String cursor, int limit) {
    return bookService.getPaginatedBooks(cursor, limit);
}
```

---

### 2.2 Schema Stitching for Modular APIs

**Schema stitching** allows you to merge multiple GraphQL schemas into a unified API, useful for microservices or modularized domains.

**Service A Schema:**

```graphql
type Query {
    authors: [Author]
}
```

**Service B Schema:**

```graphql
type Query {
    books: [Book]
}
```

**Unified Schema:**

```graphql
type Query {
    authors: [Author]
    books: [Book]
}
```

> Use tools like **Apollo Federation** or **GraphQL Mesh** for stitching schemas dynamically across services.

---

## 3. Integrating GraphQL with REST APIs

In many cases, existing REST endpoints need to be exposed via GraphQL. Use the following approach:

### 3.1 Fetching Data from REST Endpoints

In your resolver, call REST APIs to retrieve data:

```java
@RestController
public class BookResolver implements GraphQLQueryResolver {
    private final RestTemplate restTemplate;
    public BookResolver(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }
    public Book getBook(String id) {
        ResponseEntity<Book> response = restTemplate.getForEntity("http://api.example.com/books/" + id, Book.class);
        return response.getBody();
    }
}
```

### 3.2 Batch REST Requests

For performance, use **batch loading** to minimize REST calls for deeply nested queries.

```java
@Component
public class BatchLoader {
    @BatchLoader
    public Map<String, Author> loadAuthors(List<String> authorIds) {
        // Call REST API once for multiple authors
        List<Author> authors = restTemplate.postForObject("http://api.example.com/authors", authorIds, List.class);
        return authors.stream().collect(Collectors.toMap(Author::getId, author -> author));
    }
}
```

---

## 4. Handling Deeply Nested Queries

Deeply nested queries, such as fetching authors with their books and reviews, can introduce significant performance issues.

### 4.1 Avoid N+1 Query Problems

The **N+1 problem** occurs when fetching nested data results in multiple database or REST calls. Use **DataLoader** to batch and cache requests.

**DataLoader Example:**

```java
@Bean
public DataLoaderRegistry dataLoaderRegistry() {
    DataLoaderRegistry registry = new DataLoaderRegistry();
    registry.register("bookLoader", DataLoader.newMappedDataLoader(bookService::getBooksByAuthorIds));
    return registry;
}
```

Apply the `DataLoader` in the resolver:

```java
public CompletableFuture<List<Book>> getBooks(Author author, DataFetchingEnvironment env) {
    DataLoader<String, List<Book>> bookLoader = env.getDataLoader("bookLoader");
    return bookLoader.load(author.getId());
}
```

### 4.2 Optimize Field Resolution

Resolve fields lazily to avoid fetching unnecessary data:

```java
@GraphQLField
public CompletableFuture<String> getAuthorName(DataFetchingEnvironment env) {
    return CompletableFuture.supplyAsync(() -> {
        if (env.containsArgument("fetchFullName")) {
            return authorService.getFullName();
        } else {
            return authorService.getFirstName();
        }
    });
}
```

---

## 5. Performance Optimization for GraphQL APIs

### 5.1 Query Complexity Analysis

Prevent expensive queries by limiting query complexity and depth.

**Add Complexity Limit:**

```java
graphql.execution.instrumentation.Instrumentation instrumentation = new MaxQueryComplexityInstrumentation(100);
GraphQL.newGraphQL(schema).instrumentation(instrumentation).build();
```

### 5.2 Caching Results

Use a caching layer to store frequently accessed data:

- **In-Memory Cache:** Use Spring’s `@Cacheable` for local caching.
- **Distributed Cache:** Use Redis or Hazelcast for shared caching across instances.

```java
@Cacheable("books")
public List<Book> getBooks(BookFilter filter) {
    return bookRepository.findBooks(filter);
}
```

### 5.3 Monitoring GraphQL Performance

Monitor performance using tools like **Apollo Studio** or **Prometheus** with custom GraphQL metrics.

**Custom Metrics Example:**

```java
public DataFetcher<Object> instrumentedDataFetcher(DataFetcher<Object> fetcher) {
    return (dataFetchingEnvironment) -> {
        long start = System.currentTimeMillis();
        Object result = fetcher.get(dataFetchingEnvironment);
        long duration = System.currentTimeMillis() - start;
        metricsRecorder.record(dataFetchingEnvironment.getField().getName(), duration);
        return result;
    };
}
```

---

## 6. Best Practices for Advanced GraphQL APIs

1. **Design Granular Schemas:** Break down large schemas into smaller, reusable types for modularity.
2. **Optimize Nested Queries:** Use batching and caching to reduce REST and database calls.
3. **Control Query Depth:** Limit query depth and complexity to prevent misuse.
4. **Leverage Federation:** Use schema stitching or federation for modularized microservices.
5. **Monitor API Usage:** Track query performance and optimize based on usage patterns.

---

Building robust GraphQL APIs in Spring Boot requires thoughtful schema design and performance optimizations. By implementing techniques like **complex filtering**, **schema stitching**, and **batch loading**, you can create scalable APIs capable of handling deeply nested queries and dynamic data requirements.

With proper monitoring and performance tuning, Spring Boot applications powered by GraphQL can deliver efficient, flexible, and maintainable APIs for modern application architectures.

---
# GraphQL with Spring Boot 🍃🔍 — Part 1: Creating GraphQL Queries

## Introduction

In a world where APIs are the backbone of digital interactions, GraphQL has emerged as a powerful alternative to REST, offering flexibility and efficiency in data querying. For developers using Spring Boot, integrating GraphQL opens up exciting possibilities for creating more adaptable and performant APIs. In this article, we’ll dive into how GraphQL works with Spring Boot, exploring its core concepts, setup, and the advantages it brings to modern API development.

---

## Creating Our Project

As we typically do, we’ll start off by visiting [Spring Initializr](https://start.spring.io/). For the purposes of this article, we will create a **Maven** project using **Java 21** on **Spring Boot 3.3.5**. The dependencies we will be needing are:

- **Spring for GraphQL:** The main dependency allowing us to build GraphQL applications with Spring Boot / Java.
- **Spring Web:** A widely-used dependency that is also used for RESTful APIs and provides core web functionalities which are necessary for setting up our GraphQL endpoints over HTTP.

The result should look similar to the below:

![Generating a Spring Boot / GraphQL project](https://miro.medium.com/v2/resize:fit:875/1*zLUDJ25G5630QX6CisqjVw.png)

---

## Creating the GraphQL Schema

GraphQL relies on schemas to define the structure of your API, including the types, queries, and mutations available.

- **Types:** Define the shape and structure of the data in a GraphQL API, specifying what fields are available and their types. Every object in your API has a defined type, which acts like a blueprint for what data can be queried or modified.
- **Queries:** The way you retrieve data from the API. A query defines a read operation, specifying what data you want to fetch.
- **Mutations:** Handle creating, updating, or deleting data. While queries are used for retrieving data, mutations are used for changing it.

Schemas should be placed in `src/main/resources/graphql` and follow the naming convention of `<name>.graphqls`. We will go ahead and open our project on an IDE in order to create an empty schema file called `schema.graphqls`.

### Creating Our Custom Type

Let’s imagine we are developing an e-commerce application and want to create a query for retrieving purchases. We will start by defining the type of objects that will be returned by the query, the `Purchase` objects. To do this, we will start by defining our custom `Purchase` type:

```graphql
type Purchase {
    id: ID!
    amount: Float!
    madeOn: String!
    address: String!
    country: String!
    apartmentFloor: Int
    shouldCallOnDelivery: Boolean!
}
```

As you notice, to define fields we follow the `<name>: <type>` convention. The `!` dictates whether a field is nullable or not. The basic GraphQL types are:

- `ID`: A unique identifier often used as a primary key — Behaves as a `String`, since it may contain both numeric and alphanumeric characters.
- `Float`: A signed double-precision floating-point value.
- `String`: A UTF-8 character sequence.
- `Int`: A 32-bit integer.
- `Boolean`: A true or false value.

So, our `Purchase` has the following fields:

- `id`: A unique identifier, which in our case will be a UUID string (Mandatory).
- `amount`: The amount paid, as a decimal value (Mandatory).
- `madeOn`: The timestamp of when the purchase was made, as a string (Mandatory).
- `address`: The delivery address (Mandatory).
- `country`: The delivery country (Mandatory).
- `apartmentFloor`: The floor of the apartment (Optional).
- `shouldCallOnDelivery`: Whether the delivery team should call the purchaser on arrival (Mandatory).

---

### Creating Our Query

Now that we have our custom return type, we can go ahead and define our query. In the same file, we will go ahead and append:

```graphql
type Query {
    getPurchases: [Purchase!]!
}
```

Again, we use `type`, but with the `Query` name that the framework uses to specifically look up GraphQL queries. In `Query`, we provide a name: `getPurchases`, as well as the return type which is a collection of `Purchase` items. We use `!` after `Purchase` to indicate that every object in the collection will be non-nullable if it exists, while we use `!` after the `]` character to specify that the collection will always exist, even if it is returned without any records in it.

To define queries, we generally follow the format:

`<queryName>(<argName1>: <argType1>, ..., <argNameN>: <argTypeN>): <returnType>`

Keep in mind that we can define as many queries as we would like, inside the `type Query` object. Also, notice that `getPurchases` has no arguments at all.

The final version of `schema.graphqls` is:

```graphql
type Purchase {
    id: ID!
    amount: Float!
    madeOn: String!
    address: String!
    country: String!
    floor: Int
    shouldCallOnDelivery: Boolean!
}

type Query {
    getPurchases: [Purchase!]!
}
```

---

## Creating Our Java DTO Class

Next item in the list is to define our Java DTO class for the `Purchase` type we previously specified. We will create a package called `dto` and in there a file called `PurchaseResponseDto.java`. The file will have identical field names and corresponding field types as the `Purchase` type:

```java
package com.medium.graphql_demo.dto;

import java.util.UUID;

public class PurchaseResponseDto {
    private UUID id;
    private Float amount;
    private String madeOn;
    private String address;
    private String country;
    private Integer floor;
    private Boolean shouldCallOnDelivery;

    public PurchaseResponseDto(UUID id,
                               Float amount,
                               String madeOn,
                               String address,
                               String country,
                               Integer floor,
                               Boolean shouldCallOnDelivery) {
        this.id = id;
        this.amount = amount;
        this.madeOn = madeOn;
        this.address = address;
        this.country = country;
        this.floor = floor;
        this.shouldCallOnDelivery = shouldCallOnDelivery;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Float getAmount() {
        return amount;
    }

    public void setAmount(Float amount) {
        this.amount = amount;
    }

    public String getMadeOn() {
        return madeOn;
    }

    public void setMadeOn(String madeOn) {
        this.madeOn = madeOn;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public Integer getFloor() {
        return floor;
    }

    public void setFloor(Integer floor) {
        this.floor = floor;
    }

    public Boolean getShouldCallOnDelivery() {
        return shouldCallOnDelivery;
    }

    public void setShouldCallOnDelivery(Boolean shouldCallOnDelivery) {
        this.shouldCallOnDelivery = shouldCallOnDelivery;
    }
}
```

---

## Creating Our Controller

Last but not least, we will define our GraphQL controller. This will enable HTTP requests to be mapped and processed. For this, we will create a package called `controller` and a file named `GraphQlController.java`:

```java
package com.medium.graphql_demo;

import com.medium.graphql_demo.dto.PurchaseResponseDto;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.UUID;

@Controller
public class GraphQlController {
    private static final List<PurchaseResponseDto> PURCHASE_RESPONSE_DTOS = List.of(
        new PurchaseResponseDto(UUID.randomUUID(), 105.3f, "2024-11-05",
            "4950 Holt Street", "United States", null, true),
        new PurchaseResponseDto(UUID.randomUUID(), 25.2f, "2024-10-02",
            "1232 Deans Lane", "United States", 2, false)
    );

    @QueryMapping
    public List<PurchaseResponseDto> getPurchases() {
        return PURCHASE_RESPONSE_DTOS;
    }
}
```

> In a production-grade application you would not be returning a hard-coded list of items. Most likely, you would be using a `service` to run a query on your database and retrieve purchases accordingly. The way purchases are retrieved is not our topic of discussion, so we will be proceeding with this.

---

## Testing Time

Okay. We defined our custom GraphQL type, GraphQL query, and created a controller that should process GraphQL HTTP requests. Now how do I verify everything works as expected? Here comes the magic.

First, go to `application.properties` and add the following:

```properties
spring.graphql.graphiql.enabled=true
```

This will enable GraphiQL, a graphical interactive in-browser GraphQL IDE. It is very popular amongst developers as it makes it easy to explore and interactively develop GraphQL APIs.

Now, run the application and visit [http://localhost:8080/graphiql?path=/graphql](http://localhost:8080/graphiql?path=%2Fgraphql). You should see something similar to:

![Running the application — GraphiQL](https://miro.medium.com/v2/resize:fit:875/1*C0WuHB1amCeknwqcUh8Exw.png)

Replace the commented-out content of the panel on the left with the following:

```graphql
query {
  getPurchases {
    id
    amount
    madeOn
    address
    country
    floor
    shouldCallOnDelivery
  }
}
```

Now if we execute this, we will get the following:

![GraphiQL — Executing the purchases query with all fields](https://miro.medium.com/v2/resize:fit:875/1*h3pJi-SCDES9Koz-1GMTBA.png)

On the right panel we see the response. The records are inside `data` and then `getPurchases`, which is the name of the query. Now if we go to the left panel and change the query to:

```graphql
query {
  getPurchases {
    id
    amount
  }
}
```

Then execute this:

![GraphiQL — Executing the query with only id and amount](https://miro.medium.com/v2/resize:fit:875/1*G31S2kVbcMIuXXNPD_6S-g.png)

As you see on the right-hand side, we are only fetching the `id` and `amount` fields, as specified.

---

## Where Do HTTP Requests Go?

As per the GraphQL specification, all GraphQL operations are sent to the `/graphql` path as a `POST` HTTP request with a body that describes the operations that shall be executed. On our last example, the request was the following:

```bash
curl 'http://localhost:8080/graphql' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  -H 'Cache-Control: no-cache' \
  -H 'Connection: keep-alive' \
  -H 'Origin: http://localhost:8080' \
  -H 'Pragma: no-cache' \
  -H 'Referer: http://localhost:8080/graphiql?path=/graphql' \
  -H 'accept: application/json, multipart/mixed' \
  -H 'content-type: application/json' \
  --data-raw '{"query":"query { getPurchases { id amount } }"}'
```

That is why on our controller class we did not have to specify any request mapping, as you would typically do with a REST controller.

---

## Outro

Building a GraphQL API with Spring Boot opens up a world of flexibility for managing and querying data. By defining types, queries, and leveraging Spring Boot’s integration with GraphQL, we’ve created a straightforward API that’s easy to customize and scale. Using GraphiQL, we can efficiently test and refine our queries, ensuring they deliver exactly the data we need. As you continue exploring, consider extending your API with more complex types, mutations, and even subscriptions to fully harness the power of GraphQL with Spring Boot.

# Building a CRUD Application with GraphQL and Spring Boot

GraphQL has become a popular choice for building APIs due to its flexibility and efficiency in handling data. In this article, we will walk through creating simple CRUD (Create, Read, Update, Delete) APIs for user details using Spring Boot and GraphQL.

> At the end of this article, you will be able to set up a Spring Boot project with a basic CRUD example using GraphQL queries and mutations.

## A Quick Introduction to GraphQL

- GraphQL is a query language for APIs and a runtime for executing those queries with your existing data. It is an alternative to REST, SOAP, or gRPC.
- Unlike REST APIs where the server defines the response structure, GraphQL allows clients to request only the specific fields they need. This reduces over-fetching and under-fetching of data, improving performance and flexibility.

---

## Create a New Spring Boot Project

You can use [https://start.spring.io/](https://start.spring.io/) to create a new Spring Boot project. Make sure you add the following dependencies:

- Spring Data JPA
- Spring Web
- H2 Database (for simplicity)
- Spring for GraphQL
- Lombok

![Spring Boot Project Dependencies](https://miro.medium.com/v2/resize:fit:875/1*HjfEfZpTj37ydEgYIMof0g.png)

---

## Connecting to the H2 Database

For establishing a connection to the H2 database, add the following content to `application.properties`:

```properties
spring.application.name=GraphQLIntro
spring.datasource.url=jdbc:h2:mem:testdb
spring.datasource.driverClassName=org.h2.Driver
spring.datasource.username=sa
spring.datasource.password=password
spring.jpa.database-platform=org.hibernate.dialect.H2Dialect
spring.h2.console.enabled=true
spring.h2.console.path=/h2-console
spring.h2.console.settings.trace=false
spring.h2.console.settings.web-allow-others=false
spring.datasource.generate-unique-name=false
```

If you want help in configuring the H2 database, please find more details here: [Spring Boot with H2 Database](https://medium.com/stackademic/springboot-with-h2-database-8c1502c3ef54)

---

## Creating Schema for GraphQL

Next, create a `schema.graphqls` file inside `src/main/resources/graphql/` and define the types and operations (queries and mutations) for managing users.

```graphql
type User {
    id: ID
    name: String
    email: String
}

type UserResponse {
    message: String
    user: User
    userList: [User]
}

type Query {
    user(id: ID!): UserResponse
    users: UserResponse
}

type Mutation {
    createUser(name: String!, email: String!): UserResponse
    updateUser(id: ID!, name: String, email: String): UserResponse
    deleteUser(id: ID!): String
}
```

**This GraphQL schema defines types and operations for managing users in a system.**

- The `Query` type defines the operations that can be performed to fetch data from the server.
- The `User` type represents a user object in the system.
- The `UserResponse` type represents a UserResponse object in the system.
- The `Mutation` type defines the operations that can modify data on the server (such as creating, updating, or deleting users).

---

## Creating Model Classes for User and UserResponse

### User Model

Create a simple `User` model class in `src/main/java/com/example/GraphQLIntro/model/User.java`:

```java
package com.example.GraphQLIntro.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class User {
    private long id;
    private String name;
    private String email;

    public User(String name, String email) {
        this.name = name;
        this.email = email;
    }
}
```

### UserResponse Model

The `UserResponse` class wraps the response message and user details:

```java
package com.example.GraphQLIntro.model;

import lombok.*;
import java.util.List;

@Builder
@Data
@Getter
@Setter
public class UserResponse {
    String message;
    User user;
    List<User> userList;
}
```

---

## Create User Entity

Now, create a `UserEntity` class that represents the user in the database. This will be used by Spring Data JPA to interact with the database.

```java
package com.example.GraphQLIntro.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserEntity {
    @GeneratedValue
    @Id
    private long id;
    private String name;
    private String email;
    public UserEntity(String name, String email) {
        this.email = email;
        this.name = name;
    }
}
```

---

## Creating Repository Layer to Manage DB Operations

The repository will handle database operations for the `UserEntity` class. Create the `UserRepository` interface:

```java
package com.example.GraphQLIntro.repository;

import com.example.GraphQLIntro.entity.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<UserEntity, Long> {
}
```

---

## Creating Service and ServiceImpl for User Business Logic

Now, let’s implement the business logic for the CRUD operations in the `UserService` and `UserServiceImpl`.

### UserService Interface

```java
package com.example.GraphQLIntro.service;

import com.example.GraphQLIntro.entity.UserEntity;
import com.example.GraphQLIntro.model.User;
import com.example.GraphQLIntro.model.UserResponse;

public interface UserService {
    UserResponse findAll();
    UserResponse findById(Long id);
    UserResponse save(User user);
    String delete(Long id);
    UserResponse update(Long id, UserEntity updatedUserEntity);
}
```

### UserServiceImpl

```java
package com.example.GraphQLIntro.service;

import com.example.GraphQLIntro.entity.UserEntity;
import com.example.GraphQLIntro.model.User;
import com.example.GraphQLIntro.model.UserResponse;
import com.example.GraphQLIntro.repository.UserRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    private UserRepository userRepository;

    // Find all users
    public UserResponse findAll() {
        List<UserEntity> userEntity = userRepository.findAll();
        List<User> userList = objectMapper.convertValue(userEntity, new TypeReference<List<User>>() {});
        UserResponse userResponse = UserResponse.builder()
                .userList(userList)
                .message("Successfully fetched the user list")
                .build();
        return userResponse;
    }

    // Find user by id
    public UserResponse findById(Long id) {
        Optional<UserEntity> userEntity = userRepository.findById(id);
        if (userEntity.isPresent()) {
            User user = objectMapper.convertValue(userEntity.get(), User.class);
            UserResponse userResponse = UserResponse.builder()
                    .user(user)
                    .message("Fetched user successfully for id - " + id)
                    .build();
            return userResponse;
        } else {
            return UserResponse.builder()
                    .message("User not found for id - " + id)
                    .build();
        }
    }

    // Save a new user
    public UserResponse save(User user) {
        try {
            UserEntity userEntity = new UserEntity(user.getName(), user.getEmail());
            userRepository.save(userEntity);
            return UserResponse.builder()
                    .message("User Saved Successfully")
                    .build();
        } catch (Exception e) {
            throw new RuntimeException("Failed to save user");
        }
    }

    // Delete a user by id
    public String delete(Long id) {
        try {
            userRepository.deleteById(id);
            return "User deleted successfully";
        } catch (Exception e) {
            throw new RuntimeException("Failed to delete user");
        }
    }

    // Update user by id
    public UserResponse update(Long id, UserEntity updatedUserEntity) {
        try {
            // Check if user exists
            Optional<UserEntity> existingUser = userRepository.findById(id);

            if (existingUser.isPresent()) {
                UserEntity userEntity = existingUser.get();

                // Update fields (set new values from the updatedUserEntity)
                if (updatedUserEntity.getName() != null) {
                    userEntity.setName(updatedUserEntity.getName());
                }
                if (updatedUserEntity.getEmail() != null) {
                    userEntity.setEmail(updatedUserEntity.getEmail());
                }
                userRepository.save(userEntity);
                User updatedUser = objectMapper.convertValue(userEntity, User.class);

                return UserResponse.builder()
                        .user(updatedUser)
                        .message("User updated successfully for id - " + id)
                        .build();
            } else {
                return UserResponse.builder()
                        .message("User not found for id - " + id)
                        .build();
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to update user", e);
        }
    }
}
```

---

## Creating Controller

The controller will handle the GraphQL queries and mutations. It will use the service methods to perform CRUD operations.

```java
package com.example.GraphQLIntro.controller;

import com.example.GraphQLIntro.entity.UserEntity;
import com.example.GraphQLIntro.model.User;
import com.example.GraphQLIntro.model.UserResponse;
import com.example.GraphQLIntro.service.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

@Controller
public class UserController {
    @Autowired
    private UserServiceImpl userService;

    @QueryMapping
    public UserResponse users() {
        return userService.findAll();
    }

    @QueryMapping
    public UserResponse user(@Argument Long id) {
        return userService.findById(id);
    }

    @MutationMapping
    public UserResponse createUser(@Argument String name, @Argument String email) {
        User user = new User(name, email);
        return userService.save(user);
    }

    @MutationMapping
    public UserResponse updateUser(@Argument Long id, @Argument String name, @Argument String email) {
        UserEntity user = new UserEntity(name, email);
        return userService.update(id, user);
    }

    @MutationMapping
    public String deleteUser(@Argument Long id) {
        return userService.delete(id);
    }
}
```

---

After all classes have been added, your folder structure should look like:

![Folder Structure](https://miro.medium.com/v2/resize:fit:875/1*sBgDR9Arzyk0-OSbcWjvjw.png)

Run the project and once the application is up, test the GraphQL endpoint at [http://localhost:8080/graphql](http://localhost:8080/graphql)

---

## Create User

Use this mutation for creating a user:

```graphql
mutation CreateUser {
    createUser(name: "Adam Dev", email: "adam.dev@dailydebug.com") {
        message
    }
}
```

![Create User Mutation](https://miro.medium.com/v2/resize:fit:875/1*iIxEYYbFmHiIyzfeFVr_kA.png)

---

## Get All Users

Query all users from the database:

```graphql
query Users {
    users {
        message
        userList {
            id
            name
            email
        }
    }
}
```

![Get All Users](https://miro.medium.com/v2/resize:fit:875/1*vG8nOFOyXlCZ4swZYU-K8w.png)

---

## Get User By Id

```graphql
query User {
    user(id: "1") {
        user {
            id
            name
            email
        }
        message
    }
}
```

![Get User By Id](https://miro.medium.com/v2/resize:fit:875/1*X5ZqNqME5-LXLa8t_CrSLw.png)

---

## Update User

```graphql
mutation UpdateUser {
    updateUser(id: "1", name: "adam1") {
        message
    }
}
```

![Update User](https://miro.medium.com/v2/resize:fit:875/1*o7X8pnqFZV_Em8BlqMqyUw.png)

Check if the update was done in the database by using the get user by id query:

![Check Update](https://miro.medium.com/v2/resize:fit:875/1*wAVqFHKPchwAnSz-TUWpVQ.png)

---

## Delete User

```graphql
mutation DeleteUser {
    deleteUser(id: 1)
}
```

![Delete User](https://miro.medium.com/v2/resize:fit:875/1*8pefbz3dp7WyzA-CjT3vog.png)

Check if the user was deleted from the database by using the get user list query:

```graphql
query Users {
    users {
        userList {
            id
            name
            email
        }
    }
}
```

![Check Delete](https://miro.medium.com/v2/resize:fit:875/1*tqNubanvZJ8HXSVIynPwTA.png)

---

## Understanding GraphQL Functionality: Fetching Specific Fields

One of the key benefits of GraphQL is its flexibility to allow clients to request only the data they need. Unlike REST, where the server determines what data to return, in GraphQL, the client can specify exactly which fields to fetch in a query. This helps in reducing over-fetching (getting unnecessary data) and under-fetching (getting insufficient data).

For example, in a traditional REST API, if you want to get user data, you might fetch the full user details, including all fields like `id`, `name`, and `email`. However, with GraphQL, you can request only the fields you need.

### Example: Fetching Only User ID and Name

Suppose you want to fetch only the `id` and `name` of a user, but not the `email`. Here's how you can do that by modifying the GraphQL query:

```graphql
query Users {
    users {
        userList {
            id
            name
        }
    }
}
```

![Fetch Only ID and Name](https://miro.medium.com/v2/resize:fit:875/1*Hf5D3QC7UqwywwCElelY9A.png)

---

## Summary

In this article, we explored how to build a basic CRUD (Create, Read, Update, Delete) application using **Spring Boot** and **GraphQL**. GraphQL provides a more flexible and efficient alternative to traditional REST APIs by allowing clients to specify exactly which data they need in a single query.

### Key Benefits of GraphQL

- **Flexibility:** Clients have full control over which fields they request, resulting in minimal data transfer.
- **Customization:** Queries can be customized to return only the necessary data, making the API more efficient.
- **No Over-fetching:** Unlike REST, where responses may include unnecessary fields, GraphQL ensures that only the requested fields are returned.

By following this guide, you can easily create a CRUD application with GraphQL and Spring Boot, leveraging the power of GraphQL’s flexible querying capabilities to optimize your API’s performance and responsiveness.

> If you are facing any issue setting up the application, the entire code can be found at this repository — [https://github.com/prerna1996/GraphQlCrudWithSpringBoot/](https://github.com/prerna1996/GraphQlCrudWithSpringBoot/tree/main)

> Thanks for reading the article till the end. Give a clap, follow, and subscribe for more such articles.

Feel free to drop any suggestion, feedback, or queries in the comment box.
---
# Exploring GraphQL with Spring Boot

In the realm of web development, efficient data communication between clients and servers is crucial for delivering a seamless user experience. Traditional RESTful APIs have been widely used for this purpose, but they sometimes present limitations in terms of _over-fetching_ or _under-fetching_ data and multiple round-trips to the server. Enter [GraphQL](https://graphql.org/) — a powerful query language that addresses these challenges and provides more flexibility in requesting and manipulating data from the server. In this article, we’ll delve into the world of GraphQL and its integration with Spring Boot, showcasing its benefits and providing code examples to help you get started.

## Understanding GraphQL

GraphQL is a query language for APIs that enables clients to request the _exact data they need and nothing more_. Unlike traditional REST APIs where the server determines the _shape_ and _structure_ of the response, GraphQL shifts this control to the client. This means that **clients can specify the fields and relationships they want to retrieve in a single query, reducing over-fetching of data and optimizing network requests.**

In scenarios where a front-end application, such as a single-page application or a mobile app, needs to fetch data from the server, GraphQL’s flexibility shines. As the application evolves and new requirements arise, the client can adapt its data requests without requiring changes to the server.

## Spring Boot Integration with GraphQL

Spring Boot, a popular framework for building Java applications, seamlessly integrates with GraphQL through the Spring for GraphQL module. This module builds on the GraphQL Java library to provide various _ServerTransport_ mechanisms for accessing the GraphQL engine, including HTTP, WebSocket, and RSocket.

To get started with GraphQL in a Spring Boot application, add the required dependencies to your `pom.xml`:

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-graphql</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.graphql</groupId>
    <artifactId>spring-graphql-test</artifactId>
    <scope>test</scope>
</dependency>
```

These dependencies enable GraphQL support for your Spring Boot application and provide testing capabilities for GraphQL endpoints.

## GraphQL Schema

Defining the GraphQL schema is a crucial step in building a GraphQL API, as it determines the _structure_ of the data that clients can query, the available _operations_, and the _types_ of data that can be _mutated_. In the Spring Boot application, GraphQL schema is defined using the _GraphQL schema definition language (SDL)_ in a separate file.

### GraphQL Schema Definition Language (SDL)

The GraphQL Schema Definition Language (SDL) is a textual way to define the types, queries, mutations, and relationships of your GraphQL API. It provides a clear and concise syntax for describing the shape of your API. SDL includes various components that collectively define your schema:

```graphql
type Query {
    allProducts: [ProductPayload]
    product(id: ID!): ProductPayload
}

type Mutation {
    createProduct(productInput: ProductInput): ProductPayload
    updateProduct(productInput: ProductInput): ProductPayload
    deleteProduct(id: ID!): String
}

input ProductInput {
    name: String
    price: Float
    description: String
}

type ProductPayload {
    id: ID
    name: String
    price: Float
    description: String
}
```

- The `Query` type defines the queries that can be made to retrieve data.
- The `Mutation` type defines the mutations that can be made to modify data.
- The `ProductInput` type is used as an input object for mutations that create or update products.
- The `ProductPayload` type represents the output data returned by queries and mutations.

### Benefits of Defining a Schema

- **Type Safety**: SDL enforces strict typing, reducing chances of mismatched data types.
- **Documentation**: SDL serves as a self-documenting contract between the frontend and backend teams.
- **Strongly Typed API**: Clients know exactly what data they can expect, improving efficiency.
- **Flexibility**: GraphQL schemas can evolve without breaking existing clients.

## GraphQL Controller

In Spring Boot, you’ll need to create a GraphQL controller to handle GraphQL requests. This is similar to creating controllers for RESTful APIs but uses annotations specific to GraphQL. Here’s an example of a GraphQL controller for our blogging application:

```java
import com.example.demo.dto.ProductInput;
import com.example.demo.dto.ProductPayload;
import com.example.demo.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;
import java.util.List;

@Controller
@RequiredArgsConstructor
public class ProductGraphQLController {
    private final ProductService productService;

    @QueryMapping
    public List<ProductPayload> allProducts() {
        return productService.getAllProducts();
    }

    @QueryMapping
    public ProductPayload product(@Argument Long id) {
        return productService.getProductById(id);
    }

    @MutationMapping
    public ProductPayload createProduct(@Argument ProductInput productInput) {
        return productService.createProduct(productInput);
    }

    @MutationMapping
    public ProductPayload updateProduct(@Argument ProductInput productInput) {
        return productService.updateProduct(productInput);
    }

    @MutationMapping
    public String deleteProduct(@Argument Long id) {
        productService.deleteProduct(id);
        return "Product deleted successfully";
    }
}
```

The `ProductGraphQLController` acts as a bridge between the GraphQL schema and the underlying service layer. It receives GraphQL queries and mutations, processes them, and delegates the actual data manipulation to the `ProductService`. This separation of concerns follows the best practices of creating maintainable and scalable GraphQL APIs.

- `@QueryMapping` annotation is used to map methods to GraphQL query operations.
- `@MutationMapping` annotation is used to map methods to GraphQL mutation operations.
- The `@Argument` annotation is used to bind GraphQL arguments to Java method parameters.

## Enabling GraphiQL UI Client

To interactively test your GraphQL endpoints, you can enable the GraphiQL UI client. This provides a user-friendly interface where you can compose and execute GraphQL queries. To enable GraphiQL, add the following property to your `application.properties` or `application.yml`:

```properties
spring.graphql.graphiql.enabled=true
```

Once enabled, you can access the GraphiQL interface by visiting the URL [http://localhost:8080/graphiql](http://localhost:8080/graphiql) in your browser.

![GraphiQL UI](https://miro.medium.com/v2/resize:fit:875/1*c6el4aDO_IJtmhmkvk2vCA.png)

## Testing GraphQL with Spring Boot

Testing GraphQL endpoints is essential to ensure the correctness of your API. Spring for GraphQL provides a testing framework that allows you to write integration tests for your GraphQL queries and mutations. Here’s an example of how you can write integration tests using the `HttpGraphQlTester`:

```java
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.graphql.tester.AutoConfigureGraphQLTest;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.graphql.test.tester.HttpGraphQlTester;

@WebMvcTest(ProductGraphQLController.class)
@AutoConfigureGraphQLTest
public class ProductGraphQLControllerTest {

    @MockBean
    private ProductService productService; // Mock or use real implementation

    @Test
    public void testAllProducts() {
        HttpGraphQlTester httpGraphQlTester = HttpGraphQlTester.create();
        httpGraphQlTester.query("query { allProducts { id name description price } }")
                .execute()
                .path("allProducts")
                .entityList(ProductPayload.class)
                .hasSize(2); // Example assertion
    }

    @Test
    public void testProduct() {
        HttpGraphQlTester httpGraphQlTester = HttpGraphQlTester.create();
        httpGraphQlTester.query("query { product(id: 1) { id name description price } }")
                .execute()
                .path("product")
                .entity(ProductPayload.class)
                .satisfies(product -> {
                    assertEquals("Sample Product", product.getName());
                    assertEquals("Description of Sample Product", product.getDescription());
                    assertEquals(99.99, product.getPrice(), 0.01);
                }); // Example assertion
    }

    @Test
    public void testCreateProduct() {
        HttpGraphQlTester httpGraphQlTester = HttpGraphQlTester.create();
        httpGraphQlTester.query("mutation { createProduct(productInput: { name: \"New Product\", description: \"Description of New Product\", price: 49.99 }) { id name description price } }")
                .execute()
                .path("createProduct")
                .entity(ProductPayload.class)
                .satisfies(product -> {
                    assertNotNull(product.getId());
                    assertEquals("New Product", product.getName());
                    assertEquals("Description of New Product", product.getDescription());
                    assertEquals(49.99, product.getPrice(), 0.01);
                }); // Example assertion
    }

    @Test
    public void testUpdateProduct() {
        HttpGraphQlTester httpGraphQlTester = HttpGraphQlTester.create();
        httpGraphQlTester.query("mutation { updateProduct(productInput: { id: 1, name: \"Updated Product\", description: \"Updated Description\", price: 59.99 }) { id name description price } }")
                .execute()
                .path("updateProduct")
                .entity(ProductPayload.class)
                .satisfies(product -> {
                    assertEquals(1L, product.getId());
                    assertEquals("Updated Product", product.getName());
                    assertEquals("Updated Description", product.getDescription());
                    assertEquals(59.99, product.getPrice(), 0.01);
                }); // Example assertion
    }

    @Test
    public void testDeleteProduct() {
        HttpGraphQlTester httpGraphQlTester = HttpGraphQlTester.create();
        httpGraphQlTester.query("mutation { deleteProduct(id: 1) }")
                .execute()
                .path("deleteProduct")
                .entity(String.class)
                .isEqualTo("Product with id 1 has been deleted."); // Example assertion
    }
}
```

## Final Thoughts

GraphQL offers a more flexible and efficient approach to data communication between clients and servers compared to traditional REST APIs. When integrated with Spring Boot, GraphQL provides developers with the tools to define schemas, create controllers, and test endpoints with ease. By leveraging GraphQL’s ability to request exactly the data needed, developers can optimize data fetching and improve application performance. As you delve further into GraphQL and Spring Boot, you’ll discover the powerful capabilities they bring to modern web development.

---
# GraphQL Spring Boot Case Study

This story focuses on GraphQL learning in Spring Boot. At the end, we discuss the Pros and Cons.

When you talk about API design, the first thing that probably comes to mind is Representational State Transfer (REST). REST gave us important concepts for API design — stateless servers and structured access to resources. However, APIs have gotten more complex and data-driven, affected by:

- Efficient data loading (load only what is needed)
- REST returns a fixed data structure for a URL, which may include unnecessary data
- Multiple API endpoints for CRUD operations (e.g., Book entity: create, get by ID, get by author, etc.)

GraphQL, a modern alternative to REST, aims to solve these shortcomings. Unlike REST, GraphQL allows requesting only the specific data a client needs.

## What is GraphQL?

Developers describe **GraphQL** as "A data query language and runtime". It was designed and used at Facebook since 2012 and released as open source in 2015. GraphQL is strongly typed and allows you to define your own datatypes, including complex nested objects.

Let's look at a sample application: a library containing books, authors, publications, and languages.

### Database Representation

![Database Model for Book](https://miro.medium.com/v2/resize:fit:463/1*ODGZ7amY3NRMdetrSuLKvA.png)

The Book has many-to-many relationships with publication, language, and author.

## Spring Boot Application Setup

Generate a Spring Boot application from [Spring Initializr](https://start.spring.io/).

Add the following dependencies to your `pom.xml`:

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-jpa</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-web</artifactId>
</dependency>
<dependency>
    <groupId>org.postgresql</groupId>
    <artifactId>postgresql</artifactId>
    <scope>runtime</scope>
</dependency>
<dependency>
    <groupId>org.hibernate</groupId>
    <artifactId>hibernate-java8</artifactId>
</dependency>
<dependency>
    <groupId>org.liquibase</groupId>
    <artifactId>liquibase-core</artifactId>
</dependency>
<dependency>
    <groupId>io.leangen.graphql</groupId>
    <artifactId>graphql-spqr-spring-boot-starter</artifactId>
    <version>0.0.4</version>
</dependency>
<dependency>
    <groupId>org.projectlombok</groupId>
    <artifactId>lombok</artifactId>
    <optional>true</optional>
</dependency>
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-test</artifactId>
    <scope>test</scope>
    <exclusions>
        <exclusion>
            <groupId>org.junit.vintage</groupId>
            <artifactId>junit-vintage-engine</artifactId>
        </exclusion>
    </exclusions>
</dependency>
```

## GraphQL with Spring Boot

There will be no REST controllers in the Spring Boot application. Instead, we expose Service classes as APIs using GraphQL annotations:

- `@GraphQLApi`: Exposes the service/component class as an HTTP URL
- `@GraphQLMutation`: Exposes mutations
- `@GraphQLQuery`: Exposes queries

### Example: AuthorService

```java
@Service
@GraphQLApi
public class AuthorService {
    @Autowired
    AuthorRepository authorRepository;

    @GraphQLMutation(name = "saveAuthor")
    public Author saveAuthor(@GraphQLArgument(name = "author") Author author) {
        if (StringUtils.isBlank(author.getId())) {
            Author authorData = authorRepository.findByEmailId(author.getEmailId());
            if (authorData != null) {
                throw new RuntimeException("Email Already Exists");
            }
        }
        return authorRepository.save(author);
    }
}
```

### Example: LanguageService

```java
@Service
@GraphQLApi
public class LanguageService {
    @Autowired
    LanguageRepository languageRepository;

    @GraphQLMutation(name = "saveLanguage")
    public Language saveLanguage(@GraphQLArgument(name = "language") Language language) {
        if (StringUtils.isBlank(language.getId())) {
            Language existingLanguage = languageRepository.findByShortCodeAndName(language.getShortCode(), language.getName());
            if (existingLanguage != null) {
                throw new RuntimeException("Language already exists in the system");
            }
        }
        return languageRepository.save(language);
    }
}
```

### Example: PublicationService

```java
@Service
@GraphQLApi
public class PublicationService {
    @Autowired
    PublicationRepository publicationRepository;

    @GraphQLMutation(name = "savePublication")
    public Publication savePublication(@GraphQLArgument(name = "publication") Publication publication) {
        if (StringUtils.isBlank(publication.getId())) {
            Publication publicationExists = publicationRepository.findByRegistration(publication.getRegistration());
            if (publicationExists != null) {
                throw new RuntimeException("This publication is already registered");
            }
        }
        return publicationRepository.save(publication);
    }
}
```

### Example: BookDetailsService

```java
@Service
@GraphQLApi
public class BookDetailsService {
    @Autowired
    BookDetailsRepository bookDetailsRepository;
    @Autowired
    AuthorRepository authorRepository;
    @Autowired
    LanguageRepository languageRepository;
    @Autowired
    PublicationRepository publicationRepository;

    @GraphQLQuery(name = "books")
    public List<BookDetails> getBooks() {
        return bookDetailsRepository.findAll();
    }

    @GraphQLQuery(name = "book")
    public BookDetails getBookDetails(@GraphQLArgument(name = "id") String id) {
        return bookDetailsRepository.getOne(id);
    }

    @GraphQLMutation(name = "saveBook")
    @Transactional
    public BookDetails saveBookDetails(@GraphQLArgument(name = "book") BookDetails bookDetails) {
        List<Author> authors = authorRepository.findByIdIn(bookDetails.getAuthors().stream().map(Author::getId).collect(Collectors.toList()));
        List<Publication> publications = publicationRepository.findByIdIn(bookDetails.getPublications().stream().map(Publication::getId).collect(Collectors.toList()));
        List<Language> languages = languageRepository.findByIdIn(bookDetails.getLanguages().stream().map(Language::getId).collect(Collectors.toList()));
        bookDetails.setAuthors(authors);
        bookDetails.setLanguages(languages);
        bookDetails.setPublications(publications);
        return bookDetailsRepository.save(bookDetails);
    }
}
```

## Using the Playground

Deploy the application and open [http://localhost:9002/gui](http://localhost:9002/gui) to access the GraphQL playground.

### Example Mutation

```graphql
mutation {
  saveBook(
    book: {
      id: "7bbfc994-58e3-42d4-ac83-310de2664852"
      bookName: "Book"
      publications: [
        { id: "55bc93e1-ebb0-4198-a112-1b768192605d" }
        { id: "6755ee54-61a1-480e-9fc5-1804544921a1" }
      ]
      authors: [{ id: "31179e17-ff27-4ef8-a771-959e2800a552" }]
      languages: [{ id: "c5030914-042c-434e-9ce1-afeeadef69b4" }]
    }
  ) {
    id
    bookName
    languages {
      id
      name
      description
      shortCode
      createdDate
      updatedDate
    }
    authors {
      id
      name
      dateOfBirth
      age
      emailId
      mobileNumber
      createdDate
      updatedDate
    }
    publications {
      id
      name
      description
      emailAddress
      contactNumbers
      createdDate
      updatedDate
      registration
      establishmentDate
    }
  }
}
```

You can minimize the response by requesting only the fields you need.

## Comparisons between REST and GraphQL

- **Data fetching:** GraphQL allows you to fetch only the data you need in a single request, unlike REST which may require multiple endpoints.
- **Network Requests:** REST endpoints return fixed data structures, often resulting in over-fetching or under-fetching. GraphQL queries are declarative and fetch only what you specify.
- **Error Handling:** REST uses HTTP status codes for errors. GraphQL always returns `200 OK` and includes error details in the response body.
- **Caching:** REST can use HTTP caching. GraphQL does not have built-in caching, so clients must handle it.
- **Versioning:** REST often uses versioned endpoints (e.g., `/v1/`). GraphQL can evolve without versioning by adding new fields/types and deprecating old ones.

---

https://github.com/ereshzealous/spring-samples/tree/master/spring-graphql

# GraphQL Spring Boot Starter with Java

GraphQL is both an API query language and a runtime for executing those queries using your current data. GraphQL allows clients to ask for exactly what they need and nothing more, makes it easier to evolve APIs over time, and enables powerful developer tools by providing a clear and intelligible description of the data in your API.

In this article, we will create a simple Airport location app.

![Airport App](https://miro.medium.com/v2/resize:fit:500/1*yLfL1JBsbYWHdD_CWphs2A.png)

## Generate the Project

Go to [Spring Initializr](https://start.spring.io/) and generate a project. Add the following dependencies:
- Spring Web
- H2 Database
- Spring Data JPA

![Spring Initializr](https://miro.medium.com/v2/resize:fit:875/1*umxFVATP3TBKkJGabNcKzQ.png)

## Add Dependencies

To enable GraphQL, add these dependencies to your `pom.xml`:

```xml
<dependency>
    <groupId>com.graphql-java</groupId>
    <artifactId>graphql-spring-boot-starter</artifactId>
    <version>5.0.2</version>
</dependency>
<dependency>
    <groupId>com.graphql-java</groupId>
    <artifactId>graphql-java-tools</artifactId>
    <version>5.2.4</version>
</dependency>
```

## Schema

The GraphQL schema defines the data points available through an API. The schema describes the data types and their relationships, as well as the available operations, such as queries for retrieving data and mutations for creating, updating, and deleting data.

In the `resources` folder, create a file named `location.graphqls`:

```graphql
type Location {
    id: ID!
    name: String!
    address: String!
}

type Query {
    findAllLocations: [Location]!
}

type Mutation {
    newLocation(name: String!, address: String): Location!
    deleteLocation(id: ID!): Boolean
    updateLocationName(newName: String!, id: ID!): Location!
}
```

The `!` means the field is required.

## Entity and Repository

Create an entity called `Location` with three attributes: `id`, `name`, and `address`.

```java
// ... imports ...
@Entity
public class Location {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String address;
    // Getters, Setters, Constructors
}
```

Create a repository interface:

```java
// ... imports ...
public interface LocationRepository extends CrudRepository<Location, Long> {
}
```

## Queries & Exceptions

### 1. Query

A query allows us to retrieve data. Create a resolver package, then add a new `Query` class that implements `GraphQLQueryResolver` and add the `@Component` annotation. Only add the queries that you previously entered into `location.graphqls`.

```java
// ... imports ...
@Component
public class Query implements GraphQLQueryResolver {
    private final LocationRepository locationRepository;
    public Query(LocationRepository locationRepository) {
        this.locationRepository = locationRepository;
    }
    public Iterable<Location> findAllLocations() {
        return locationRepository.findAll();
    }
}
```

### 2. Mutator

Mutations in GraphQL allow you to update the data stored on the server. Create a mutator package and add a new class `Mutation` that implements `GraphQLMutationResolver` and add the `@Component` annotation. Add the mutations that you previously entered into `location.graphqls`.

```java
// ... imports ...
@Component
public class Mutation implements GraphQLMutationResolver {
    private final LocationRepository locationRepository;
    public Mutation(LocationRepository locationRepository) {
        this.locationRepository = locationRepository;
    }
    public Location newLocation(String name, String address) {
        Location location = new Location(name, address);
        locationRepository.save(location);
        return location;
    }
    public boolean deleteLocation(Long id) {
        locationRepository.deleteById(id);
        return true;
    }
    public Location updateLocationName(String newName, Long id) {
        Optional<Location> optionalLocation = locationRepository.findById(id);
        if(optionalLocation.isPresent()) {
            Location location = optionalLocation.get();
            location.setName(newName);
            locationRepository.save(location);
            return location;
        } else {
            throw new LocationNotFoundException("Location Not Found", id);
        }
    }
}
```

### 3. Exceptions

Create an exception package and add a new class `LocationNotFoundException` that extends `RuntimeException` and implements `GraphQLError`.

```java
// ... imports ...
public class LocationNotFoundException extends RuntimeException implements GraphQLError {
    private Map<String, Object> extensions = new HashMap<>();
    public LocationNotFoundException(String message, Long invalidLocationId) {
        super(message);
        extensions.put("invalidLocationId", invalidLocationId);
    }
    @Override
    public List<SourceLocation> getLocations() {
        return null;
    }
    @Override
    public Map<String, Object> getExtensions() {
        return extensions;
    }
    @Override
    public ErrorType getErrorType() {
        return ErrorType.DataFetchingException;
    }
}
```

---

## Resources
- [https://www.graphql-java.com](https://www.graphql-java.com/)
- [https://graphql.org](https://graphql.org/)
- [Source code on GitHub](https://github.com/sabbarmehdi/graphql)

---
# Spring Boot GraphQL Example with `graphql-spring-boot-starter`

In this article, we will look at a sample Spring Boot application using Spring GraphQL Boot Starter. This example will cover how to implement a controller for a GraphQL schema and how to write test code.

### Dependency

According to the Spring GraphQL reference, add the following dependency to your `pom.xml`:

```xml
<dependency>
    <groupId>org.springframework.experimental</groupId>
    <artifactId>graphql-spring-boot-starter</artifactId>
    <version>1.0.0-SNAPSHOT</version>
</dependency>
```

Add the following repositories for milestone and snapshot releases:

```xml
<repositories>
    <repository>
        <id>spring-milestones</id>
        <name>Spring Milestones</name>
        <url>https://repo.spring.io/milestone</url>
    </repository>
    <repository>
        <id>spring-snapshots</id>
        <name>Spring Snapshots</name>
        <url>https://repo.spring.io/snapshot</url>
        <snapshots>
            <enabled>true</enabled>
        </snapshots>
    </repository>
</repositories>
```

### GraphQL Schema

Define your GraphQL schema in `src/main/resources/graphql/schema.graphqls`:

```graphql
type Query {
    employees: [Employee]
    departments: [Department]
    departmentById(id: ID!): Department
}

type Mutation {
    updateDepartmentName(id: ID!, name: String): Department
}

type Department {
    id: ID!
    name: String
    employees: [Employee]
}

type Employee {
    id: ID!
    name: String
    departmentId: String
}
```

### Implementing the Controller

There are a few rules to follow when mapping a GraphQL schema to a controller:

1. `Query` types are mapped with `@QueryMapping`
2. `Mutation` types are mapped with `@MutationMapping`
3. Method names of the controller class need to match the type names (e.g., `employees`, `departments`, `departmentById`, `updateDepartmentName`)
4. Arguments are mapped with `@Argument`

Here is an example controller implementation:

```java
import io.jay.springgraphqlsample.Department;
import io.jay.springgraphqlsample.service.DepartmentService;
import io.jay.springgraphqlsample.service.EmployeeService;
import lombok.RequiredArgsConstructor;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;
import java.util.List;

@Controller
@RequiredArgsConstructor
public class GraphQLController {
    private final EmployeeService employeeService;
    private final DepartmentService departmentService;

    @QueryMapping
    public List<EmployeeResponse> employees() {
        return employeeService.getAll();
    }

    @QueryMapping
    public List<DepartmentResponse> departments() {
        return departmentService.getAll();
    }

    @QueryMapping
    public DepartmentResponse departmentById(@Argument long id) {
        return departmentService.getById(id);
    }

    @MutationMapping
    public DepartmentResponse updateDepartmentName(@Argument("id") long id, @Argument("name") String name) {
        Department department = departmentService.find(id);
        department.setName(name);
        Department updated = departmentService.persist(department);
        return new DepartmentResponse(updated);
    }
}
```

The GraphQL endpoint can be tested with your favorite REST client tool (such as Insomnia, Postman, etc). By default, the GraphQL endpoint is at `POST /graphql`.

### Writing Tests

GraphQL endpoints can be tested with `WebGraphQlTester`. The approach is to define some queries to test against and use them in test cases. Queries can be typed as strings if preferred.

Here is a sample test class:

```java
import io.jay.springgraphqlsample.Department;
import io.jay.springgraphqlsample.Employee;
import io.jay.springgraphqlsample.service.DepartmentService;
import io.jay.springgraphqlsample.service.EmployeeService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.graphql.test.tester.WebGraphQlTester;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.test.web.servlet.client.MockMvcWebTestClient;
import org.springframework.web.context.WebApplicationContext;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import static org.mockito.Mockito.when;

@SpringBootTest
@ActiveProfiles("test")
public class GraphQLControllerTests {
    @Autowired
    private WebApplicationContext context;

    @MockBean
    private EmployeeService mockEmployeeService;
    @MockBean
    private DepartmentService mockDepartmentService;

    private WebGraphQlTester graphQlTester;

    public static String fileToQuery(String fileName) throws IOException {
        return new String(Files.readAllBytes(Paths.get("src/test/resources/graphql-queries/" + fileName)));
    }

    @BeforeEach
    void setUp() {
        WebTestClient client = MockMvcWebTestClient.bindToApplicationContext(context)
            .configureClient()
            .baseUrl("/graphql")
            .build();
        graphQlTester = WebGraphQlTester.builder(client).build();
    }

    @Test
    void test_query_employees_returnsEmployeeList() throws IOException {
        Employee employee = new Employee();
        employee.setId(1L);
        employee.setName("John");
        Department department = new Department();
        department.setId(999L);
        employee.setDepartment(department);
        when(mockEmployeeService.getAll())
            .thenReturn(Arrays.asList(new EmployeeResponse(employee)));
        graphQlTester.query(fileToQuery("employees.graphql"))
            .execute()
            .path("employees[0].id").entity(Long.class).isEqualTo(1L)
            .path("employees[0].name").entity(String.class).isEqualTo("John")
            .path("employees[0].departmentId").entity(Long.class).isEqualTo(999L);
    }

    @Test
    void test_mutation_updateDepartmentName_updatesName() throws IOException {
        Department department = new Department();
        department.setId(1L);
        department.setName("Human Resources");
        when(mockDepartmentService.find(1L))
            .thenReturn(department);
        Department departmentWithUpdatedName = new Department();
        departmentWithUpdatedName.setId(1L);
        departmentWithUpdatedName.setName("DevOps");
        when(mockDepartmentService.persist(department))
            .thenReturn(departmentWithUpdatedName);
        graphQlTester.query(fileToQuery("updateDepartmentName.graphql"))
            .execute()
            .path("updateDepartmentName.id").entity(Long.class).isEqualTo(1L)
            .path("updateDepartmentName.name").entity(String.class).isEqualTo("DevOps");
    }
}
```

### Example GraphQL Queries

**employees.graphql**
```graphql
query {
    employees {
        id
        name
        departmentId
    }
}
```

**updateDepartmentName.graphql**
```graphql
mutation {
    updateDepartmentName(id: 1, name: "DevOps") {
        id
        name
        employees {
            id
            name
        }
    }
}
```

### References
- [Spring GraphQL Sample (GitHub)] https://github.com/jskim1991/spring-graphql-sample
- [GraphQL Schema Reference](https://graphql.org/learn/schema/)
- [Spring GraphQL Documentation](https://docs.spring.io/spring-graphql/docs/1.0.0-SNAPSHOT/reference/html/###boot-graphql)
---
# GraphQL with Spring Boot: A Comprehensive Guide

GraphQL, an API query language developed by Facebook, has revolutionized how developers interact with APIs. Unlike traditional RESTful APIs, where multiple requests are required to fetch related resources, GraphQL allows clients to request exactly the data they need in a single query. With its flexibility and efficiency, GraphQL is becoming the go-to solution for building modern APIs.

In this article, we will explore how to integrate GraphQL into a **Spring Boot** application, compare it with traditional RESTful API approaches, and provide detailed examples, including before-and-after scenarios. By the end of this article, you’ll have a deep understanding of how to leverage GraphQL in Spring Boot for building efficient and scalable APIs.

# What is GraphQL?

GraphQL is a query language for APIs and a runtime for executing queries against your data model. It allows clients to request only the data they need and nothing more, minimizing the number of API requests and reducing the size of the response payload.

## Key Features of GraphQL

- **Flexible queries**: Clients can specify exactly what data they need, reducing over-fetching and under-fetching.
- **Single request**: Clients can get related data in a single request, eliminating multiple round trips.
- **Strongly typed**: GraphQL schemas define the types of data, which makes it easier to validate and document the API.
- **Real-time updates**: With subscriptions, GraphQL can support real-time updates for clients.

# Using GraphQL with Spring Boot

Let’s begin by comparing how data retrieval works in a traditional RESTful approach versus using GraphQL in Spring Boot. We’ll demonstrate how using GraphQL improves flexibility and efficiency in the way data is fetched.

---

## 1. RESTful API Example: Before GraphQL

### Scenario: Fetching User Details and Their Posts

In a typical RESTful API, you’d need to make separate requests to retrieve user details and their posts. You might have an endpoint like `/users/{id}` to fetch user data and another one like `/posts?userId={id}` to fetch the user's posts.

### UserController (RESTful Approach)

```java
@RestController
@RequestMapping("/api/users")
public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    private PostService postService;

    // Endpoint to get user details
    @GetMapping("/{id}")
    public UserDTO getUser(@PathVariable Long id) {
        return userService.getUserById(id);
    }

    // Endpoint to get posts of a user
    @GetMapping("/{id}/posts")
    public List<PostDTO> getUserPosts(@PathVariable Long id) {
        return postService.getPostsByUserId(id);
    }
}
```

Here, a client would need to make two requests:

1. `/api/users/1` to fetch user details.
2. `/api/users/1/posts` to fetch posts of the user.

> This approach may lead to **over-fetching** (getting unnecessary data) or **under-fetching** (missing related data). In this example, we are fetching all user details even if the client only needs a subset of the information.

---

## 2. Using GraphQL

Now, let’s implement the same functionality using GraphQL in a Spring Boot application. We’ll allow clients to request the user data and related posts in a single query.

### GraphQL Setup in Spring Boot

First, we need to add the necessary dependencies to our Spring Boot project to enable GraphQL.

```xml
<!-- In pom.xml -->
<dependencies>
    <dependency>
        <groupId>com.graphql-java</groupId>
        <artifactId>graphql-java</artifactId>
        <version>17.3</version>
    </dependency>
    <dependency>
        <groupId>com.graphql-java</groupId>
        <artifactId>spring-boot-starter-graphql</artifactId>
        <version>1.0.0</version>
    </dependency>
</dependencies>
```

Next, we’ll define a **GraphQL schema** for the user and posts data.

### GraphQL Schema Definition (`schema.graphqls`)

```graphql
type Query {
    user(id: Long): User
    posts(userId: Long): [Post]
}

type User {
    id: Long
    username: String
    email: String
    posts: [Post]  # Embedded posts within user type
}

type Post {
    id: Long
    title: String
    content: String
}
```

### GraphQL Resolvers

Now, we need to define the resolvers that handle fetching data from the database or service layer.

```java
@Component
public class GraphQLResolver {
    @Autowired
    private UserService userService;
    @Autowired
    private PostService postService;

    // Resolver for querying user by ID
    @QueryMapping
    public UserDTO user(@Argument Long id) {
        return userService.getUserById(id);
    }

    // Resolver for querying posts by user ID
    @QueryMapping
    public List<PostDTO> posts(@Argument Long userId) {
        return postService.getPostsByUserId(userId);
    }
}
```

### Controller Layer (GraphQL Endpoint)

In GraphQL, we no longer need multiple endpoints like in REST. Instead, we define a single endpoint for all GraphQL queries.

```java
@RestController
@RequestMapping("/graphql")
public class GraphQLController {
    private final GraphQL graphQL;

    @Autowired
    public GraphQLController(GraphQL graphQL) {
        this.graphQL = graphQL;
    }

    @PostMapping
    public ResponseEntity<Object> query(@RequestBody String query) {
        ExecutionResult executionResult = graphQL.execute(query);
        return ResponseEntity.ok(executionResult.getData());
    }
}
```

---

## GraphQL Query Example

Now, a client can query for the user’s details along with their posts in a single request:

```graphql
query {
  user(id: 1) {
    id
    username
    email
    posts {
      title
      content
    }
  }
}
```

### Response

```json
{
  "data": {
    "user": {
      "id": 1,
      "username": "john_doe",
      "email": "john.doe@example.com",
      "posts": [
        {
          "title": "GraphQL for Beginners",
          "content": "This is an introduction to GraphQL."
        },
        {
          "title": "Advanced GraphQL",
          "content": "This article covers advanced GraphQL concepts."
        }
      ]
    }
  }
}
```

In this approach, the client only requests the data they need (`id`, `username`, `email`, `posts.title`, and `posts.content`) — nothing more, nothing less.

---

# Advantages of Using GraphQL over REST

## 1. Fetch Exactly What You Need

With GraphQL, clients can request only the fields they need, reducing unnecessary data transfer. In the REST example, the client was forced to fetch full user data and then make a second request for posts. With GraphQL, they can retrieve everything in a single, optimized request.

## 2. Single Endpoint

In RESTful APIs, you often need multiple endpoints to fetch related resources. In contrast, GraphQL uses a single endpoint (`/graphql`) for all queries and mutations, simplifying the API structure.

## 3. Reduced Over-fetching and Under-fetching

GraphQL’s ability to specify exactly what data you want eliminates the problem of over-fetching (retrieving unnecessary data) and under-fetching (not getting enough data in one request).

## 4. Real-time Updates with Subscriptions

GraphQL also supports **subscriptions**, allowing clients to receive real-time updates when data changes. This is something traditional REST APIs struggle with, as they rely on polling or long-lived connections for real-time updates.

### Example Subscription (GraphQL Schema)

```graphql
type Subscription {
    postAdded: Post
}
```

### GraphQL Resolver for Subscription

```java
@SubscriptionMapping
public Flux<Post> postAdded() {
    return postService.getPostUpdates();  // Stream of new posts
}
```

---

# Summary

Integrating **GraphQL** into a **Spring Boot** application significantly enhances how you interact with your API. Compared to the traditional RESTful approach, GraphQL offers a more efficient way to query data, reduces over-fetching, and simplifies the structure of your API by consolidating multiple endpoints into a single one. Additionally, it supports real-time data updates through subscriptions, making it a powerful tool for building modern, efficient, and flexible APIs.

---
# Beginner’s Guide to GraphQL with Spring Boot

GraphQL is a query language for APIs that allows clients to request only the data they need, making it possible to gather data in a limited number of requests. GraphQL is a strongly typed protocol and all data operations are validated against a GraphQL schema.

In this article, we will build a simple GraphQL server with Spring Boot.

## Adding Maven Dependencies

Create a sample Spring Boot application and add the following dependencies:

1. _graphql-spring-boot-starter_ is used for enabling the GraphQL servlet and becomes available at the path `/graphql`. It initializes the `GraphQLSchema` bean.
2. _graphql-java_ allows you to write schema with GraphQL schema language which is simple to understand.
3. _graphiql-spring-boot-starter_ provides a user interface to test GraphQL queries and view query definitions.

```xml
<dependency>
    <groupId>com.graphql-java</groupId>
    <artifactId>graphql-spring-boot-starter</artifactId>
    <version>5.0.2</version>
</dependency>
<dependency>
    <groupId>com.graphql-java</groupId>
    <artifactId>graphql-java-tools</artifactId>
    <version>5.2.4</version>
</dependency>
<dependency>
    <groupId>com.graphql-java</groupId>
    <artifactId>graphiql-spring-boot-starter</artifactId>
    <version>5.0.2</version>
</dependency>
```

Here is the complete `pom.xml` file content:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.techshard.graphql</groupId>
    <artifactId>springboot-graphql</artifactId>
    <version>1.0-SNAPSHOT</version>
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>2.1.6.RELEASE</version>
        <relativePath />
    </parent>
    <properties>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <project.reporting.outputEncoding>UTF-8</project.reporting.outputEncoding>
    </properties>
    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-jpa</artifactId>
        </dependency>
        <dependency>
            <groupId>com.graphql-java</groupId>
            <artifactId>graphql-spring-boot-starter</artifactId>
            <version>5.0.2</version>
        </dependency>
        <dependency>
            <groupId>com.graphql-java</groupId>
            <artifactId>graphql-java-tools</artifactId>
            <version>5.2.4</version>
        </dependency>
        <dependency>
            <groupId>com.graphql-java</groupId>
            <artifactId>graphiql-spring-boot-starter</artifactId>
            <version>5.0.2</version>
        </dependency>
        <dependency>
            <groupId>com.h2database</groupId>
            <artifactId>h2</artifactId>
            <scope>runtime</scope>
        </dependency>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <version>1.18.8</version>
            <optional>true</optional>
        </dependency>
    </dependencies>
    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
    </build>
</project>
```

## Creating JPA Entity and Repository

Let’s create a simple entity called _Vehicle_ and a corresponding JPA repository. We will use Lombok to avoid writing boilerplate code such as getters and setters.

```java
package com.techshard.graphql.dao.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

@Data
@EqualsAndHashCode
@Entity
public class Vehicle implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID", nullable = false)
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @Column(name = "type", nullable = false)
    private String type;

    @Column(name = "model_code", nullable = false)
    private String modelCode;

    @Column(name = "brand_name")
    private String brandName;

    @Column(name = "launch_date")
    private LocalDate launchDate;

    private transient String formattedDate;

    // Getter and setter
    public String getFormattedDate() {
        return getLaunchDate().toString();
    }
}
```

Here is the corresponding JPA repository:

```java
package com.techshard.graphql.dao.repository;

import com.techshard.graphql.dao.entity.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface VehicleRepository extends JpaRepository<Vehicle, Integer> {
}
```

## GraphQL Schema

GraphQL comes with its own language to write GraphQL Schema called [Schema Definition Language](https://www.howtographql.com/basics/2-core-concepts/) (SDL). The schema definition consists of all the API functionalities available at an endpoint.

A typical example of a GraphQL schema would look like this:

```graphql
type Vehicle {
    id: ID!,
    type: String,
    modelCode: String,
    brandName: String,
    launchDate: String
}

type Query {
    vehicles(count: Int): [Vehicle]
    vehicle(id: ID): Vehicle
}

type Mutation {
    createVehicle(type: String!, modelCode: String!, brandName: String, launchDate: String): Vehicle
}
```

Create a folder `graphql` under `src/main/resources` and create a file `vehicleql.graphqls` under that folder. Copy the above contents and paste them in the `vehicleql.graphqls` file. Note that the name of the file could be any name of your choice. Just make sure to keep the file extension as `.graphqls`.

## Root Query

Query or Mutation objects are root GraphQL objects, they don’t have any associated data class. In such cases, the resolver classes would implement `GraphQLQueryResolver` or `GraphQLMutationResolver`. These resolvers will be searched for methods that map to fields in their respective root types.

Let’s define root resolvers for _Vehicle_:

```java
package com.techshard.graphql.query;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.techshard.graphql.dao.entity.Vehicle;
import com.techshard.graphql.service.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.List;
import java.util.Optional;

@Component
public class VehicleQuery implements GraphQLQueryResolver {
    @Autowired
    private VehicleService vehicleService;

    public List<Vehicle> getVehicles(final int count) {
        return this.vehicleService.getAllVehicles(count);
    }

    public Optional<Vehicle> getVehicle(final int id) {
        return this.vehicleService.getVehicle(id);
    }
}
```

Now, let’s define a Mutation resolver:

```java
package com.techshard.graphql.mutation;

import com.coxautodev.graphql.tools.GraphQLMutationResolver;
import com.techshard.graphql.dao.entity.Vehicle;
import com.techshard.graphql.service.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.time.LocalDate;

@Component
public class VehicleMutation implements GraphQLMutationResolver {
    @Autowired
    private VehicleService vehicleService;

    public Vehicle createVehicle(final String type, final String modelCode, final String brandName, final String launchDate) {
        return this.vehicleService.createVehicle(type, modelCode, brandName, launchDate);
    }
}
```

In this class, we only have one method to create a _Vehicle_ object and this corresponds to type _Mutation_ in our schema definition.

Now, define a service which would make actual transactions:

```java
package com.techshard.graphql.service;

import com.techshard.graphql.dao.entity.Vehicle;
import com.techshard.graphql.dao.repository.VehicleRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class VehicleService {
    private final VehicleRepository vehicleRepository;

    public VehicleService(final VehicleRepository vehicleRepository) {
        this.vehicleRepository = vehicleRepository;
    }

    @Transactional
    public Vehicle createVehicle(final String type, final String modelCode, final String brandName, final String launchDate) {
        final Vehicle vehicle = new Vehicle();
        vehicle.setType(type);
        vehicle.setModelCode(modelCode);
        vehicle.setBrandName(brandName);
        vehicle.setLaunchDate(LocalDate.parse(launchDate));
        return this.vehicleRepository.save(vehicle);
    }

    @Transactional(readOnly = true)
    public List<Vehicle> getAllVehicles(final int count) {
        return this.vehicleRepository.findAll().stream().limit(count).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public Optional<Vehicle> getVehicle(final int id) {
        return this.vehicleRepository.findById(id);
    }
}
```

## Testing the Application

The application is now ready for testing. Run the Spring Boot application. Open the link [http://localhost:8080/graphiql](http://localhost:8080/graphiql) in the browser. You will see a nice user interface.

Now, run the following mutation:

```graphql
mutation {
  createVehicle(type: "car", modelCode: "XYZ0192", brandName: "XYZ", launchDate: "2016-08-16") {
    id
  }
}
```

This will create a row in the _Vehicle_ table. The result would be:

```json
{
  "data": {
    "createVehicle": {
      "id": "1"
    }
  }
}
```

Let us now run a query to get the data:

```graphql
query {
  vehicles(count: 1) {
    id
    type
    modelCode
  }
}
```

The output will be:

```json
{
  "data": {
    "vehicles": [
      {
        "id": "1",
        "type": "bus",
        "modelCode": "XYZ123"
      }
    ]
  }
}
```

Note that we are requesting only a limited number of fields. We can change our query by adding or removing fields and see the new results.

# Conclusion

In this article, we looked at the basic concepts of GraphQL. Check out the detailed documentation [here](https://graphql.org/learn/).

The complete source code for this tutorial can be found on [GitHub](https://github.com/swathisprasad/graphql-with-spring-boot).
---
# Using GraphQL With Spring Boot: Interfaces and Unions

## First and Foremost

I’ll start with the explanation of the concepts, and then we’ll look into its implementation with Spring Boot and Kotlin.

Consider the following data classes and interface:

```java
// Example Java interface and classes (replace with your actual code)
public interface Profile {}
public class User implements Profile {}
public class Company implements Profile {}
```

Now we’re going to write a GraphQL schema that models the same interfaces and classes. We’ll have a query to fetch the `Profile`, which will give us a `User` or `Company` based on what the client needs in a single query.

In our GraphQL schema, when using interfaces, we’ll add the following:

```graphql
interface Profile {
  id: ID!
  name: String!
}

type User implements Profile {
  id: ID!
  name: String!
  email: String!
}

type Company implements Profile {
  id: ID!
  name: String!
  registrationNumber: String!
}

type Query {
  profile(id: ID!): Profile
}
```

We can also use `Union` instead of `Interface`:

```graphql
union ProfileUnion = User | Company

type Query {
  profileUnion(id: ID!): ProfileUnion
}
```

## Which one should we use?

> It can vary based on the use case and your end goal. The following points can be used to finalize the option:
>
> - There isn’t always an advantage to grouping shared fields into interfaces — it depends on the use case
> - Interfaces are good for when the types have a fundamental commonality in how they should be used
> - Unions are good for documenting and forcing the client to understand how different types should be treated

# Implementation With Spring Boot

## 1. The setup

You can skip to the third section if you know how to set up a Spring Boot project with GraphQL. Also, the code to this is available [here](https://github.com/maniish-jaiin/graphql-interfaces-unions).

Otherwise, go to [https://start.spring.io/](https://start.spring.io/).

Select a `Gradle` project, and set the language as `Kotlin`.

You don’t have to select any dependencies for a bare-minimum implementation.

Download the ZIP file, and open it in your favorite IDE.

Jump to `build.gradle.kts`, and add:

```kotlin
dependencies {
    implementation("com.graphql-java-kickstart:graphql-spring-boot-starter:11.1.0")
    implementation("com.graphql-java-kickstart:graphiql-spring-boot-starter:11.1.0")
    implementation("org.jetbrains.kotlin:kotlin-reflect")
    implementation("org.jetbrains.kotlin:kotlin-stdlib-jdk8")
}
```

These are the GraphQL libraries you’d need to get started with your first endpoint.

## 2. The first endpoint

Create a file called `schema.graphqls` inside the `resources` directory. Add the following lines:

```graphql
type Query {
  hello: String
}
```

And then create a resolver class that can actually do something when the query is triggered by the client:

```java
import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import org.springframework.stereotype.Component;

@Component
public class HelloWorldResolver implements GraphQLQueryResolver {
    public String hello() {
        return "Hello, GraphQL!";
    }
}
```

That’s it. Run the server using `./gradlew bootRun`.

Go to your browser, and open `http://localhost:8080/playground`. The [Playground](https://www.apollographql.com/docs/apollo-server/testing/graphql-playground/) is one of the developer tools used as a client for GraphQL APIs.

This will be the output when you trigger the query:

![Query and response in the Playground](https://miro.medium.com/v2/resize:fit:875/1*bXp3vgDRYOG6LUYwW8KuCQ.png)

## 3. The interface implementation

Let’s start by changing the schema. In your `schema.graphqls` file, add the following code:

```graphql
interface IVehicle {
  id: ID!
  name: String!
}

type Car implements IVehicle {
  id: ID!
  name: String!
  model: String!
}

type Bike implements IVehicle {
  id: ID!
  name: String!
  type: String!
}

type Query {
  getIVehicles: [IVehicle]
}
```

Now add some Kotlin classes and interfaces to match the schema entities:

```java
public interface IVehicle {
    String getId();
    String getName();
}

public class Car implements IVehicle {
    private String id;
    private String name;
    private String model;
    // getters, setters, constructor
}

public class Bike implements IVehicle {
    private String id;
    private String name;
    private String type;
    // getters, setters, constructor
}
```

After this mapping, we can start creating the service that’ll fetch the `IVehicle` data when the `getIVehicles` query is triggered. You need to create a `Resolver` and a `Service`:

```java
import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import org.springframework.stereotype.Component;
import java.util.Arrays;
import java.util.List;

@Component
public class VehicleResolver implements GraphQLQueryResolver {
    public List<IVehicle> getIVehicles() {
        return Arrays.asList(
            new Car("1", "Tesla", "Model S"),
            new Bike("2", "Yamaha", "Sport")
        );
    }
}
```

You’ve successfully created an endpoint that can fetch both car and bike data with the same query.

You can run this query to fetch the data:

```graphql
query {
  getIVehicles {
    id
    name
    ... on Car {
      model
    }
    ... on Bike {
      type
    }
  }
}
```

Wait a minute! One more thing before this actually works: you need to add those interface types in the GraphQL’s schema parser dictionary. The way to do that is to add this code:

```java
import com.coxautodev.graphql.tools.SchemaParserDictionary;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GraphqlConfig {
    @Bean
    public SchemaParserDictionary schemaParserDictionary() {
        return new SchemaParserDictionary()
            .add(Car.class)
            .add(Bike.class);
    }
}
```

This needs to be done because there’s a problem in the library, and autodiscovery for these types doesn’t work unless you explicitly put it. You can find the issue [here](https://github.com/graphql-java-kickstart/graphql-java-tools/issues/97#issuecomment-364860537).

# Conclusion

I’m not adding the implementation for `Union` here, as it’s pretty similar to the implementation of interfaces. Don’t worry: If you’re interested, you can find the implementation [here](https://github.com/maniish-jaiin/graphql-interfaces-unions).

---

# Mastering GraphQL in Spring Boot: Advanced Schema Design and Performance Tuning

## Introduction

GraphQL has emerged as a powerful alternative to REST, enabling developers to query APIs with precision by fetching only the data they need. Spring Boot, combined with GraphQL, offers a modern and efficient approach to build scalable APIs. However, advanced schema design and performance optimization remain critical for leveraging GraphQL’s full potential. In this blog, we’ll explore how to design advanced GraphQL schemas and optimize performance in a Spring Boot application with a practical example of a rental service API.

## Why GraphQL?

### Advantages of GraphQL Over REST

- **Precise Data Fetching:** Fetch only the required fields, reducing over-fetching and under-fetching.
- **Single Endpoint:** Consolidates multiple REST endpoints into one GraphQL endpoint.
- **Strongly Typed:** Provides robust type-checking and documentation via its schema.

### Challenges

- **Complexity in Schema Design:** Requires careful structuring for scalability.
- **N+1 Query Problem:** Risk of performance bottlenecks when resolving nested fields.

---

## Case Study: Rental Service API

### Scenario

You’re building a rental service API where users can query rental properties by location, price, and amenities. The API should support advanced filtering and efficient data fetching to ensure seamless user experiences.

---

## Setting Up the Spring Boot Application

### Dependencies

Add the following dependencies to your `pom.xml`:

```xml
<dependencies>
    <dependency>
        <groupId>com.graphql-java-kickstart</groupId>
        <artifactId>graphql-spring-boot-starter</artifactId>
        <version>12.0.0</version>
    </dependency>
    <dependency>
        <groupId>com.graphql-java-kickstart</groupId>
        <artifactId>graphql-java-tools</artifactId>
        <version>12.0.0</version>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-data-jpa</artifactId>
    </dependency>
    <dependency>
        <groupId>org.postgresql</groupId>
        <artifactId>postgresql</artifactId>
        <scope>runtime</scope>
    </dependency>
</dependencies>
```

---

## Designing the GraphQL Schema

### Schema File: `schema.graphqls`

```graphql
type Query {
    rentals(filter: RentalFilterInput): [Rental]!
    rental(id: ID!): Rental
}

type Rental {
    id: ID!
    title: String!
    location: String!
    price: Float!
    amenities: [String]!
}

input RentalFilterInput {
    location: String
    minPrice: Float
    maxPrice: Float
    amenities: [String]
}
```

This schema defines a `Rental` type with a query to fetch rentals by ID or through advanced filtering.

---

## Implementing the API

### Entity Class

```java
@Entity
public class Rental {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title;
    private String location;
    private Double price;
    @ElementCollection
    private List<String> amenities;
    // Getters and Setters
}
```

### Repository

```java
@Repository
public interface RentalRepository extends JpaRepository<Rental, Long>, JpaSpecificationExecutor<Rental> {}
```

### Resolver Logic

#### DTO for Filtering

```java
public class RentalFilterInput {
    private String location;
    private Double minPrice;
    private Double maxPrice;
    private List<String> amenities;
    // Getters and Setters
}
```

#### Query Resolver

```java
@Component
public class RentalQueryResolver implements GraphQLQueryResolver {
    private final RentalRepository rentalRepository;
    public RentalQueryResolver(RentalRepository rentalRepository) {
        this.rentalRepository = rentalRepository;
    }
    public List<Rental> rentals(RentalFilterInput filter) {
        return rentalRepository.findAll((root, query, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();
            if (filter.getLocation() != null) {
                predicates.add(criteriaBuilder.equal(root.get("location"), filter.getLocation()));
            }
            if (filter.getMinPrice() != null) {
                predicates.add(criteriaBuilder.greaterThanOrEqualTo(root.get("price"), filter.getMinPrice()));
            }
            if (filter.getMaxPrice() != null) {
                predicates.add(criteriaBuilder.lessThanOrEqualTo(root.get("price"), filter.getMaxPrice()));
            }
            if (filter.getAmenities() != null && !filter.getAmenities().isEmpty()) {
                predicates.add(root.get("amenities").in(filter.getAmenities()));
            }
            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        });
    }
    public Rental rental(Long id) {
        return rentalRepository.findById(id).orElseThrow(() -> new RuntimeException("Rental not found!"));
    }
}
```

---

## Performance Optimization

### Batch DataLoader for N+1 Problem

Use a `DataLoader` to fetch related data in bulk.

```java
@Bean
public DataLoaderRegistry dataLoaderRegistry(RentalRepository rentalRepository) {
    DataLoader<Long, Rental> rentalDataLoader = DataLoader.newMappedDataLoader(ids ->
        CompletableFuture.supplyAsync(() -> rentalRepository.findAllById(ids))
            .thenApply(rentals -> rentals.stream().collect(Collectors.toMap(Rental::getId, rental -> rental)))
    );

    DataLoaderRegistry registry = new DataLoaderRegistry();
    registry.register("rentalLoader", rentalDataLoader);
    return registry;
}
```

Use the `DataLoader` in resolvers for nested fields.

---

## Testing the API

### Sample Queries

Fetch all rentals with filters:

```graphql
query {
    rentals(filter: {
        location: "New York",
        minPrice: 1000,
        maxPrice: 3000,
        amenities: ["WiFi", "Pool"]
    }) {
        id
        title
        price
    }
}
```

Fetch a specific rental by ID:

```graphql
query {
    rental(id: 1) {
        id
        title
        location
        amenities
    }
}
```

---

## Conclusion

By combining Spring Boot with GraphQL, we can build flexible and efficient APIs. Advanced schema design ensures scalability, while performance optimization techniques like batching and filtering prevent bottlenecks. As demonstrated, implementing a dynamic rental service API showcases the power and flexibility of GraphQL for modern application development.

> Ready to take your APIs to the next level? Dive into GraphQL with Spring Boot and unlock endless possibilities!

---
# Building Flexible APIs with GraphQL and Spring Boot: A Java 17 Guide

GraphQL is a modern API standard designed to give clients the power to request specific data, making APIs more flexible and efficient compared to REST APIs. In this article, we’ll walk through how to set up a Spring Boot application with Java 17 to use GraphQL. We’ll cover the dependencies, GraphQL schema creation, resolver definitions, and example queries and mutations.

## Prerequisites

- Java 17
- Spring Boot (version 2.7 or above for better support with GraphQL)
- Basic knowledge of Spring Boot, Java, and APIs

# 1. Setting Up the Project

## Add Dependencies

Spring Boot provides the Spring GraphQL library, which offers GraphQL support. You can add it to your project in the `pom.xml` file:

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-graphql</artifactId>
</dependency>
<dependency>
    <groupId>com.graphql-java-kickstart</groupId>
    <artifactId>graphql-spring-boot-starter</artifactId>
    <version>11.1.0</version>
</dependency>
<dependency>
    <groupId>com.graphql-java-kickstart</groupId>
    <artifactId>graphql-java-tools</artifactId>
    <version>11.1.0</version>
</dependency>
```

These dependencies enable Spring Boot to support GraphQL and provide tools for schema and query definitions.

# 2. Define Your Data Model

We'll create a simple application that manages a list of `Book` entities. Start by defining a `Book` class:

```java
public class Book {
    private String id;
    private String title;
    private String author;
    private int pages;

    public Book(String id, String title, String author, int pages) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.pages = pages;
    }

    // Getters and setters
    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public int getPages() { return pages; }
}
```

# 3. Create a GraphQL Schema

In GraphQL, schemas define the shape and type of the data available for querying or mutation. Place the schema in a file named `schema.graphqls` under `src/main/resources/graphql`.

```graphql
type Query {
    getBookById(id: ID!): Book
    getAllBooks: [Book]
}

type Mutation {
    addBook(id: ID!, title: String!, author: String!, pages: Int!): Book
}

type Book {
    id: ID!
    title: String!
    author: String!
    pages: Int!
}
```

- **Query**: Defines the structure for fetching data, with two queries: `getBookById` and `getAllBooks`.
- **Mutation**: Used for creating new data, with an `addBook` mutation in this example.

# 4. Implement Resolvers

Resolvers handle the logic for each query and mutation defined in the schema. Create a `BookService` class to store and retrieve `Book` data:

```java
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class BookService {
    private final Map<String, Book> bookRepository = new HashMap<>();

    public Book getBookById(String id) {
        return bookRepository.get(id);
    }

    public List<Book> getAllBooks() {
        return new ArrayList<>(bookRepository.values());
    }

    public Book addBook(Book book) {
        bookRepository.put(book.getId(), book);
        return book;
    }
}
```

Now, create the resolvers for queries and mutations by using GraphQL annotations in Spring:

```java
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;
import java.util.List;

@Controller
public class BookController {
    private final BookService bookService;

    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    @QueryMapping
    public Book getBookById(@Argument String id) {
        return bookService.getBookById(id);
    }

    @QueryMapping
    public List<Book> getAllBooks() {
        return bookService.getAllBooks();
    }

    @MutationMapping
    public Book addBook(@Argument String id, @Argument String title,
                        @Argument String author, @Argument int pages) {
        Book book = new Book(id, title, author, pages);
        return bookService.addBook(book);
    }
}
```

- **@QueryMapping**: Annotates methods for handling GraphQL queries.
- **@MutationMapping**: Annotates methods for handling GraphQL mutations.
- **@Argument**: Maps GraphQL arguments to method parameters.

# 5. Testing the GraphQL API

To test your GraphQL API, you can use tools like GraphiQL or Postman, or you can set up the Spring Boot Actuator `/graphiql` endpoint to directly execute queries in a browser.

Here are some example queries and mutations to run in a GraphQL client:

## Query a Book by ID

```graphql
query {
    getBookById(id: "1") {
        id
        title
        author
        pages
    }
}
```

## Query All Books

```graphql
query {
    getAllBooks {
        id
        title
        author
        pages
    }
}
```

## Add a New Book

```graphql
mutation {
    addBook(id: "1", title: "GraphQL Basics", author: "John Doe", pages: 200) {
        id
        title
    }
}
```

# 6. Error Handling and Logging

For error handling, Spring GraphQL automatically wraps exceptions and provides meaningful messages in responses. For custom error handling, you can define exception classes and exception handlers using `@ControllerAdvice`.

```java
import org.springframework.graphql.execution.ErrorType;
import org.springframework.graphql.execution.GraphQLErrorHandler;
import org.springframework.stereotype.Component;
import graphql.GraphQLError;
import java.util.List;

@Component
public class CustomGraphQLErrorHandler implements GraphQLErrorHandler {
    @Override
    public List<GraphQLError> processErrors(List<GraphQLError> errors) {
        return errors;
    }
}
```

# 7. Running and Testing the Application

Run your application using the `main` method in Spring Boot or by running `./mvnw spring-boot:run` in the command line. Once running, navigate to `http://localhost:8080/graphiql` or use a GraphQL client to interact with the API.

# Conclusion

With GraphQL and Spring Boot, you can create highly flexible and efficient APIs. The declarative structure of GraphQL gives clients control over the data they need, reducing bandwidth and improving application performance. This guide should help you integrate GraphQL into your Java 17 Spring Boot applications. Happy coding!

---
