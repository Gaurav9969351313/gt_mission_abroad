# Split your Monolith into Microservices.How

‘Branch By Abstraction’ & ‘Database-Per-Service’ patterns implementation using Quarkus REST Client Reactive and Feature Toggles.E-commerce Case Study.

In the previews articles we started building the back-end system for our fictional e-shop. We have implemented 2 **Resource Endpoints**, the **ProductResource** and the **OrderResource** providing functionality for products and orders. However our system is sharing the same database with all the scalability problems arising from that.

> It is time to break down our monolithic application into a micro-service architecture following the **Database-Per-Service pattern and Branch By Abstraction Pattern**. You can read more about this patterns by visiting [microservices.io](https://microservices.io/patterns/data/database-per-service.html) and also [Martin Fowler’s blog](https://martinfowler.com/bliki/BranchByAbstraction.html).

> Lets go into some theory first about database sharing between domains in a monolithic application and what are the options of communicating and sharing data between micro-services

# A. Database-Per-Service Pattern

Breaking down a monolithic application with a shared database into a microservices architecture with separate databases is a complex process that comes with various challenges and issues. While microservices offer benefits like **scalability, flexibility, and faster development,** they also introduce complexities that need to be carefully managed.

Our order system is the one shown. When a new item is requested to be added to the order then the item is fetched from the local database using Panache ORM [1] as shown in figure 1.

![](https://miro.medium.com/v2/resize:fit:875/1*vEnQgoFwKxdMwdKps3Jq1Q.png)
Figure 1. Monolithic Application using a Single Database for both orders and products.

In this series of articles, our goal is to implement a functionality where, upon the addition of a new item to an order, we retrieve both product data and stock availability information from a newly developed inventory microservice. To achieve this, we’ll utilize the Quarkus REST Client. The architecture we aim to build aligns with the representation in Figure 2.

![](https://miro.medium.com/v2/resize:fit:875/1*z8XQPsASMmdmYm0boxFHqg.png)
Figure 2. Micro-Service Architecture following the Database per Service Pattern.

# B. InterService Communication using REST Client Reactive.

For this inter-service REST comunication for finding a unique product and validating the stock we are going to explore the **Quarkus REST Client Reactive**, an implementation of **MicroProfile Rest Client**, which provides a more convenient and type-safe way to invoke RESTful APIs compared to traditional approaches.

> ‘MicroProfile Rest Client is a part of the Eclipse MicroProfile project, which aims to provide a set of specifications for building microservices-based Java applications. MicroProfile Rest Client is specifically focused on simplifying the consumption of RESTful web services within Java microservices applications. ‘

Here are some key features and benefits of MicroProfile Rest Client:

> **Declarative API**: MicroProfile Rest Client allows you to define RESTful API interfaces using annotations and Java interfaces. This declarative approach means you can create a Java interface that represents the REST API, and the client implementation is generated automatically.
> 
> **Type Safety**: The generated client code is strongly typed, which means you can use Java interfaces and data objects to interact with the REST service. This reduces the chances of runtime errors and makes your code more maintainable.

> However Sharing product data through a REST API is not the fastest thing to do comparing to a solution using reference tables in a share database.

# C. Monolithic to Micro-Service ‘Data’ Challenge.

Designing a microservice architecture where each microservice corresponds to a single entity may seem like an intuitive approach, but it can lead to excessive inter-service communication.

By definition, microservices should be self-contained units capable of performing their business functions independently. However, most business processes involve multiple entities.

> In monolithic applications, it’s common for modules to access required data from a different module through an SQL join to the other table. In our case OrderItem has a reference to Products table as well as to Customers table.

# **The Latency Problem And Micro-Services Communication**

If we decide to adopt a microservices approach, we must be prepared for changes in how data relationships are managed. In our new architecture, orders and products reside in completely different databases.

We may tempted to replace the traditional database join to products [2] by API calls between microservices, introducing latency.

> Although the purpose of the article demonstrates the ‘Branch by Abstraction Pattern’ using Quarkus synchronous communication by no means it is the recommended approach for production.The correct approaches are:

A**synchronous Communication:**Instead of synchronous communication, consider using asynchronous messaging patterns. This can be achieved through message queues or publish-subscribe systems. The order-service can send a request to the inventory-service and continue processing other tasks while awaiting a response.

C**aching**:Another technique is to implement caching mechanisms in the order-service to store frequently requested stock information. This can help reduce the need for frequent requests to the inventory service, especially for data that doesn’t change frequently.

R**etry and Circuit Breaker Pattern:**  
If you tempted for a synchronous communication FOR START then YOU MUST implement retry mechanisms with backoff strategies for failed requests to the inventory service. In **Quarkus** it is easy to use the **Circuit Breaker Pattern** to temporarily halt requests if the inventory service is experiencing issues, preventing cascading failures.

B**atch Processing:**  
If the order-service requires multiple pieces of information from the inventory service, consider the ‘Request Batch’ Pattern by [batching requests](http://Request Batch) to reduce the overhead of making individual calls. This can be particularly effective since there are multiple items to be checked in a single order.

# **Data Integrity Problem**

Now, let’s address the concern about data integrity. In a microservices architecture, each microservice typically has its own database or separate schema in the same database.

This makes establishing traditional foreign key relationships between the product table of both order-service and inventory-service impractical. As a result, enforcing data integrity at the database level becomes challenging.

# **The Data Consistency Challenge**

The challenge arises from the independent nature of these micro-services where each one manages its own data store and also another problem is that business transactions often involve interactions with multiple microservices. The real problem however is:

> There is not a shared transactional mechanism of any kind

Unlike a monolithic system where transactions are typically managed within a single database, microservices operate independently with their own databases **and there is not a shared transaction mechanism**.

> Ensuring consistent and synchronized data across microservices becomes a complex challenge. Scenarios where updates to one service succeed while updates to another may fail, leading to inconsistencies, are common

**Achieving traditional ACID properties (Atomicity, Consistency, Isolation, Durability) across distributed services is difficult, nearly impossible if you are building a mission-critical strong consistency application.**

To address these problems microservice architecture often rely on patterns like the **Saga Pattern**, **Eventual Consistency**, and **Compensating Transactions** to address the **Data Consistency Problem**. These patterns introduce mechanisms for managing transactions across services, handling failures, and

> **EVENTUALLY** converging towards a consistent state.
> 
> ENENTUALLY. That is.

> As noted by a great reader which I’m thankfull, the original ‘**The Data Consistency Problem’** paragraph introduced confusion due to the use of the term “splitting business transactions**.” You don’t actually split the transaction.** The original paragraph:
> 
> “Another challenge is maintaining data consistency in a microservices architecture, as business transactions are split across multiple microservices. This necessitates the use of patterns like the SAGA pattern, which involves orchestrating local transactions and creating compensating transactions to handle rollbacks effectively.”

# U**UID for Product Records**

> In a microservices architecture, using UUIDs (Universally Unique Identifiers) for primary keys in database tables is a common practice, and it can be particularly beneficial when dealing with distributed systems and services like the order service and the inventory service. Here are some reasons why using UUIDs for the product table might be a good idea:

1.  **Uniqueness**: UUIDs are designed to be globally unique. This means that in our distributed environment with multiple services and a database per service , we can be reasonably sure that the UUIDs used for products will not collide or conflict with each other.
2.  **Decoupling**: UUIDs allow each microservice to generate its own unique local primary key identifiers without needing to coordinate with other services. This promotes independence and reduces the need for centralized identity management.
3.  **Data Integration**: When multiple services need to interact or share data, using UUIDs can simplify data integration. Since UUIDs are globally unique, they can serve as a common identifier across services.
4.  **Data Replication**: In our case stock and price information about a product needs to be replicated across databases, using Kafka messaging or other techniques. UUIDs make it easier to merge or synchronize data without conflicts.
5.  **Avoiding Exposing Internal IDs**: Using UUIDs can help prevent the exposure of internal database IDs to external clients, which can be a security best practice.

# D. Monolithic to Micro-Service ‘Refactoring Code’ Challenge.

This is another important part. There a few patterns to migrate from our monolithic application to micro-services such as the **Strangler Fig pattern**, **Pattern of Parallel Runs** the pattern of **Branch By Abstraction** and much more**.**

If you want to dive deep into the theory read this very nice article [Patterns to migrate from Monolith to Microservices](https://refactorizando.com/en/patterns-to-migrate-from-monolith-to-microservices/) .

According to Martin Fowler

> “Branch by Abstraction” is a technique for making a large-scale change to a software system in gradual way that allows you to release the system regularly while the change is still in-progress.

Gradual. This is the key word. **Branch by Abstraction** we allow us to do gradual refactor our application. It promotes a structured and incremental approach.

> Essentially using an abstraction layer will allow multiple implementations to co-exist in the software system, ensuring that the system builds and runs correctly and when we don’t longer want the old functionality we will remove it.

> Lastly we didn’t choose the **Strangle Fig Pattern** since we are going to do refactoring and changes at **component level .**
> 
> **Strangle Fig Pattern** is more suited at the **monolith’s perimeter** by interpet calls of the endpoints using let’s say a proxy, façade or a load balancer .

T**hese are the six phases that are being followed in Branch by Abstraction:**

1.  **Identify the Change**: First, we need to identify the specific change or feature we want to introduce or modify in your software system. This change can range from refactoring code to adding new functionality or even upgrading a critical component.
2.  **Create an Abstraction Layer**: Instead of directly making changes to the existing codebase, we create an abstraction layer or interface that represents the new functionality or change. This abstraction layer acts as an intermediary between the old and new code.
3.  **Implement the Change Separatel**y: We implement the desired change or feature within this abstraction layer or interface. This allows to work on the new code independently of the existing codebase, reducing the risk of conflicts and errors.
4.  **Gradual Integration**: Once the new functionality is fully developed and tested within the abstraction layer, we can gradually integrate it into the existing codebase. This integration can be done incrementally, piece by piece, or module by module, depending on the complexity of the change and the structure of our codebase.
5.  **Deprecate the Old Code**: As we integrate the new code, we can start deprecating or phasing out the old code that the abstraction layer replaces. This can involve removing or refactoring the old code to use the new abstraction.

> E**nough with the theory! We our now ready to start!**

# STEP 1. Initialization. Add the Rest Client library.

In this article in order to share product stock info between our micro-services we emply a synchronous communication techique using a REST Client invocation library. In Quarkus that librasy is named ‘**rest-client-reactive-jackson**’, or ‘’r**est-reactive**’ .

REST Client Reactive is the REST Client implementation compatible with RESTEasy Reactive. This is the library needed in order to create REST Clients and interact with REST API Services or in quarkus terminology our ‘RESTEasy Reactive’ Services. Read more about it in [Quarkus Official Documentation.](https://quarkus.io/guides/rest-client-reactive)

> ‘RESTEasy Reactive’ and ‘REST Client Reactive’ terminology doesn’t mean that our REST Endpoints and Services are written in a ‘reactive’ non-blocking style.

**Remember this:**

S**ERVER PART — REST Easy Reactive**: Providing JSON REST Endpoints

C**LIENT PART — REST Client Reactive**: Invoking JSON REST Endpoints compatible with **RESTEasy Reactive.**

> We are adding the **rest-client-reactive-jackson** in our **order-service** micro-service. Open up a terminal within the order-service project type the following:

quarkus extension add 'rest-client-reactive-jackson'

# Branch By Abstraction:STEP 1. Identify T**he Change**

We said that we are going to fetch specific for the needs of our microservice product info from a new hypothetical micro-service named **inventory-service** through RESΤ API calls and not from the local database.

Thus we need to abstract the **findProductById** functionality at line [1].

**OrderResource.java**

..............  
```java
@Path("add/item/{orderId}")  
    @POST  
    public Response addOrderItem(@PathParam("orderId") Long orderId, OrderItem orderItemForm) {  
       [1] Product product = Product.findProductById(orderItemForm.productId);   
       Order.addOrderItem(orderId, product, orderItemForm.quantity);  
       return Response.status(Response.Status.OK).build();  
             
    }  
```
.................

# Branch By Abstraction:STEP 2. Create the Abstraction Layer.

We start by creating a new **Interface** named **IInventoryService** and we are adding 2 methods for single product data and product availability validation named **findProductByUUID** and **checkStockAvailability** respectively, assuming our new **inventory-service** provides that functionality. As we said we introduce UUIDs for the main product identification mechanism.

**IInventoryService.java**
```java
package com.platform.ecommerce.order.service;  
  
import com.platform.ecommerce.order.model.InventoryProductRecord;  
import com.platform.ecommerce.order.model.InventoryStockResultRecord;  
import com.platform.ecommerce.order.model.Product;  
  
public interface IInventoryService {  
  
  
    InventoryProductRecord findProductByUUID(String UUID);  
  
    InventoryStockResultRecord checkStockAvailability(String UUID, Integer quantity);  
  
}
```

We also introduce **Java Records** which can be a convenient choice for representing immutable Data Transfer Objects (DTOs) in our distributed micro-service environment to ex-change data between our micro-services. In addition we reduce all the boilerplate code such as writing getters, setters etc.

**InventoryStockResultRecord** for the inventory Product Stock Result

and **InventoryProductRecord** for Products.

**InventoryStockResultRecord.java**
```java
package com.platform.ecommerce.order.model;  
  
public record InventoryStockResultRecord(String productUUID, Integer availableQuantity, Integer requestedQuantity, Boolean available, Integer missingQuantity) {  
  
    public InventoryStockResultRecord(Product product, Integer requestedQuantity) {  
        this(product.UUID,product.getStock(),requestedQuantity, requestedQuantity < product.getStock()    ? true : false, requestedQuantity > product.getStock() ?  requestedQuantity - product.getStock() :  0);  
  
    }  
  
}
```

**InventoryProductRecord.java**
```java
package com.platform.ecommerce.order.model;  
  
public record InventoryProductRecord(String UUID, String name) {  
    public InventoryProductRecord(Product product) {  
        this(product.UUID, product.name);  
    }  
  
}
```

> Clean! Java Records are Cool!

# Branch By Abstraction:STEP 3. Implement the Change Part 1. Introduce Product UUIDs and Refactor Model Entities.

Since we introduce UUID as a global identifier of products we need to make a lot of refactoring changes to our model entities. Our Product entity introduces a new method **findProductByUUID** and the **UUID** column

**Product.java**

```java
import io.quarkus.hibernate.orm.panache.PanacheEntity;  
import jakarta.persistence.Column;  
import jakarta.persistence.Entity;  
import org.hibernate.annotations.CreationTimestamp;  
import java.time.ZonedDateTime;  
  
@Entity  
public class Product extends PanacheEntity  {  

    @Column(nullable = false,unique = true)  
    public String UUID;  
  
    @Column(nullable = false)  
    public String name;  
  
    @Column  
    private String description;  
  
    @Column  
    public Double price;  
  
    @Column(nullable = false)  
    public  Integer stock;  
  
    //default stock value  
    {stock = 100;}  
  
    @CreationTimestamp  
    public ZonedDateTime created;  
  
    public Product() {}  
  
    public static Product findProductByUUID(String UUID) {  
        return find("UUID", UUID).firstResult();  
    }  
  
    public static Product findProductById(Long id) {  
        return findById(id);  
    }  
  
    public static Product findByName(String name){      return find("name", name).firstResult();  }  
  
    public Integer getStock() {  
        return stock;  
    }   
}  
```

We change the method signatures of **addOrderItem, updateOrderItemQuantity** and **deleteOrderItem** to use product UUID instead of the local database product primary key.

**Order.java**
```java
package com.platform.ecommerce.order.model;  
  
  
import com.fasterxml.jackson.annotation.JsonIgnore;  
import io.quarkus.hibernate.orm.panache.PanacheEntity;  
import io.quarkus.logging.Log;  
import io.quarkus.panache.common.Sort;  
import jakarta.persistence.*;  
import jakarta.transaction.Transactional;  
import org.hibernate.annotations.CreationTimestamp;  
import jakarta.persistence.Column;  
  
import java.time.ZonedDateTime;  
import java.util.ArrayList;  
import java.util.List;  
  
  
@Entity  
@Table(name = "orders")  
public class Order extends PanacheEntity {  
  
  
    @Column(nullable = false)  
    public double totalAmount;  
  
    @Column(nullable = false)  
    public String status;  
  
    @JsonIgnore  
    @ManyToOne()  
    @JoinColumn(name = "customerid", nullable = true)  
    public Customer customer;  
  
    @CreationTimestamp  
    @Column(updatable = false, nullable = false)  
    public ZonedDateTime created;  
  
  
    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true)  
    public List<OrderItem> orderItems = new ArrayList<>();  
  
  
    @Transient  
    public void setTotalPrice() {  
        double total = 0D;  
        for (OrderItem item : orderItems) {  
            total += item.totalAmount;  
        }  
        totalAmount = total;  
    }  
  
  
    public static Order findOrderById(Long id) {  
        return findById(id);  
    }  
  
    public static List<Order> findOrdersByStatus(String status) {  
        List<Order> orderList = Order.list("status", Sort.by("customer.id").and("created"), status);  
        return orderList;  
    }  
  
    public static List<Order> findOrdersByCustomerId(Long customerId) {  
        List<Order> orderList = Order.list("customer.id", Sort.by("created"), customerId);  
        return orderList;  
    }  
  
    @Transactional  
    public static void createOrder(Long customerId, Order order) {  
        Customer customer = findById(customerId);  
        order.customer = customer;  
        order.persist();  
    }  
  
  
    @Transactional  
    public static void addOrderItem(Long orderId,String productUUID, Integer quantity) {  
        Order order =  findOrderById(orderId);  
        Product product = Product.findProductByUUID(productUUID);  
        OrderItem orderItem = new OrderItem(order,product,quantity);  
        order.orderItems.add(orderItem);  
        order.setTotalPrice();  
        order.persist();  
        //orderItem.persist(); //CASCADING TYPE IS SET TO ALL SO NO NEEDED  
    }  

    @Transactional  
    public static void updateOrderItemQuantity(Long orderId, String productUUID, Integer quantity) {  
        Order order =  findOrderById(orderId);  
        Log.info("Order found:"+order.id);  
  
        OrderItem orderItem = order.orderItems.stream().filter(o -> productUUID.equals(o.product.UUID)).findFirst().orElse(null);  
        Log.info("Order item found:"+orderItem.id);  
  
        orderItem.quantity = quantity;  
        Log.info("Update quantity to:"+quantity);  
  
        orderItem.setTotalPrice();  
        order.setTotalPrice();  
        order.persist();  
    }  
  
    @Transactional  
    public static void updateOrderStatus(Long id, String status) {  
        Order order = findOrderById(id);  
        order.status = status;  
        order.persist();  
    }  
  
    @Transactional  
    public static void deleteOrderItem(Long orderId, String productUUID) {  
        Order order = findOrderById(orderId);  
        Log.info("Order found:"+order.id);  
  
        OrderItem orderItem = order.orderItems.stream().filter(o -> productUUID.equals(o.productUUID)).findFirst().orElse(null);  
        Log.info("Order item found:"+orderItem.id);  
  
        order.orderItems.remove(orderItem);  
        Log.info("Remove item:"+orderItem.id);  
  
        order.setTotalPrice();  
        order.persist();  
    }  
  
    @Transactional  
    public static void deleteOrder(Long id) {  
        findById(id).delete();  
    }  
}
```
and our **OrderItem** entity becomes

**OrderItem.java**
```java
import com.fasterxml.jackson.annotation.JsonIgnore;  
import io.quarkus.hibernate.orm.panache.PanacheEntity;  
import jakarta.persistence.*;  
  
@Entity  
public class OrderItem extends PanacheEntity {  
  
  
    //default constructor  
    public OrderItem() {  
    }  
  
    public OrderItem(Order order, Product product, Integer quantity) {  
        this.order = order;  
        this.product = product;  
        this.productUUID = product.UUID;  
        this.quantity = quantity;  
        totalAmount = product.price*quantity;  
    }  
  
    public Long getId() {  
        return id;  
    }  
  
  
    @Column(nullable = false)  
    public double totalAmount;  
  
    @Column(nullable = false)  
    public Integer quantity;  
  
    @Transient  
    public String productUUID;  
  
  
    @OneToOne  
    @JoinColumn(name = "productuuid",referencedColumnName = "uuid",insertable = true,updatable = false)  
    public Product product = new Product();  
  
    @ManyToOne(optional = false, fetch = FetchType.EAGER)  
    @JoinColumn(name="orderid", nullable=false)  
    @JsonIgnore  
    public Order order;  
  
  
    @Transient  
    public void  setTotalPrice() {  
        totalAmount = product.price*quantity;  
    }  
}  
```

# Branch By Abstraction:STEP 3. Implement the Change Part 2. Create the Service Layers.

We create 2 implementations of the **IInventoryService** interface**.** One for the already exisiting functionality for product ferching using a local database access and one for remote micro-service REST invocation of the **inventory-service**.

Our local implementation of the **IInventoryService** is **ProductLocalDatabaseService** which uses Panache ORM to fetch product data from our local database. It’s the default functionality of our monolith since we are not want to break the existing production system (**also we are using the @DefaultBean annotation**) but this time is using product UUID instead of the local database primary key of products table to fetch product records.

**ProductLocalDatabaseService.java**
```java
package com.platform.ecommerce.order.service;  
  
import com.platform.ecommerce.order.model.InventoryProductRecord;  
import com.platform.ecommerce.order.model.InventoryStockResultRecord;  
import com.platform.ecommerce.order.model.Product;  
  
@ApplicationScoped  
@DefaultBean  
public class ProductLocalDatabaseService implements IInventoryService {  
  
  
    @Override  
    public InventoryProductRecord findProductByUUID(String UUID) {  
          Product product = Product.findProductByUUID(UUID);  
        InventoryProductRecord productResult = new InventoryProductRecord(product);  
          return productResult;  
    }  
  
    @Override  
    public InventoryStockResultRecord checkStockAvailability(String UUID, Integer requestedQuantity) {  
        Product product = Product.findProductByUUID(UUID);  
        InventoryStockResultRecord availabilityResult = new InventoryStockResultRecord(product,requestedQuantity);  
        return availabilityResult;  
    }  
  
}
```

Then we create a new implementation of our **IInventoryService** named **ProductRemoteMicroService** which supports REST API client invocation to our new inventory micro-service. This is essentially our ‘**Branch**’

> Don’t worry about the **@RestClient IProductInventoryClient** at the moment**.** In the next step I explain in depth about it.

**ProductRemoteMicroService.java**
```java
package com.platform.ecommerce.order.service;  
  
import com.platform.ecommerce.order.model.InventoryProductRecord;  
import com.platform.ecommerce.order.model.InventoryStockResultRecord;  
import com.platform.ecommerce.order.rest.IProductInventoryClient;  
import io.quarkus.arc.profile.UnlessBuildProfile;  
import io.quarkus.arc.properties.UnlessBuildProperty;  
import jakarta.enterprise.context.ApplicationScoped;  
import org.eclipse.microprofile.rest.client.inject.RestClient;  
  
  
@ApplicationScoped  
@UnlessBuildProperty(name = "microservices.inventory.release.enabled", stringValue = "false")  
//@UnlessBuildProfile("prod")  
public class ProductRemoteMicroService implements IInventoryService {  
  
    IProductInventoryClient inventoryClient;  
  
    public ProductRemoteMicroService(@RestClient IProductInventoryClient inventoryClient) {  
        this.inventoryClient = inventoryClient;  
    }  
  
    @Override  
    public InventoryProductRecord findProductByUUID(String UUID) {  
        return inventoryClient.findProductByUUID(UUID);  
    }  
  
    @Override  
    public InventoryStockResultRecord checkStockAvailability(String UUID, Integer quantity) {  
        return inventoryClient.checkStockAvailability(UUID, quantity);  
    }  
 
}
```

# Branch By Abstraction:STEP 4. Using feature toggles to switch between implementations

Sam Newman at his book “Monolith to Microservices” at page 108 introduces the idea of using ‘feature toggles’ to switch between the new and the old implementation when implementing branch by abstraction.

Therefore within **application.properties** of our **order-service** we also enter the following config value.

microservices.inventory.release.enabled = false

> But wait! What is the **@UnlessBuildProperty(name = “microservices.inventory.release.enabled”, stringValue = “false”)** annotation?

> We want to conditionallly enable the new functionality based on quarkus build profiles such as prod, dev and test, or based on some sort of configuration entry in application properties. We are trying to break our monolith but not break the production system!
> 
> You can read more about it at the official quarkus documentation about contexts and dependency injection at [**4.7. Enabling Beans for Quarkus Build Profile**.](https://quarkus.io/guides/cdi-reference)

Tip: To conditionally enable our new implementation based on the build profiles use the [**@io**](http://twitter.com/io)**.quarkus.arc.profile.IfBuildProfile** and [**@io**](http://twitter.com/io)**.quarkus.arc.profile.UnlessBuildProfile** annotations. For example we want our **ProductRemoteMicroService** to run only at **test** and **dev** profiles and not in **production**. We annotate like this to protect our production system and have the new functionality ONLY WHEN TESTING
```java
@UnlessBuildProfile("prod")  
  
// OR  
  
@IfBuildProfile("test")
```

> We then insert this **new inventory data service layer** as well as the **product availability validation code** and **product fetching code** in our **OrderResource** EndPoint at [1], [2].

**OrderResource.java**
```java
package com.platform.ecommerce.order.resource;  
  
  
import com.platform.ecommerce.order.model.InventoryProductRecord;  
import com.platform.ecommerce.order.model.InventoryStockResultRecord;  
import com.platform.ecommerce.order.model.*;  
import com.platform.ecommerce.order.service.IInventoryService;  
import io.quarkus.logging.Log;  
import jakarta.enterprise.context.ApplicationScoped;  
import jakarta.inject.Inject;  
import jakarta.ws.rs.*;  
import jakarta.ws.rs.core.MediaType;  
import jakarta.ws.rs.core.Response;  
  
import java.util.List;  
  
@Path("order-service/v1/order")  
@ApplicationScoped  
@Produces(MediaType.APPLICATIONJSON)  
@Consumes(MediaType.APPLICATIONJSON)  
  
public class OrderResource {  
  
  
    @Inject  
    IInventoryService inventoryService;  
  
  
    @GET  
    @Path("all")  
    public List<Order> getAllOrders() {return Order.listAll(); }  
  
    @GET  
    @Path("{id}")  
    public Response findById(@PathParam("id") Long id) {  
  
    return Order.findByIdOptional(id)  
                .map(order -> Response.ok(order).build())  
                .orElse(Response.status(Response.Status.NOTFOUND).build());  
    }  
  
  
    @POST  
    @Path("create/{customerId}")  
    public Response createOrder(@PathParam("customerId") Long customerId, Order order) {  
        Order.createOrder(customerId,order);  
        Log.info("Order created:"+order.id);  
        return Response.status(Response.Status.CREATED).build();  
    }  
    @PUT  
    @Path("update/status/{id}")  
    public Response updateOrderStatus(@PathParam("id") Long id, String status) {  
        Order.updateOrderStatus(id,status);  
        return Response.status(Response.Status.NOCONTENT).build();  
    }  
    @Path("add/item/{orderId}")  
    @POST  
    public Response addOrderItem(@PathParam("orderId") Long orderId, OrderItem orderItemForm) {  
                [1] InventoryStockResultRecord inventoryStockResult = inventoryService.checkStockAvailability(orderItemForm.productUUID, orderItemForm.quantity);  
                    Log.infof(":requested stock validation check from inventory for item: %s.  Available quantity is:  %s", inventoryStockResult.productUUID(),inventoryStockResult.availableQuantity());  
  
                if(inventoryStockResult.available()) {  
                    Log.info("inventory stock validation passed");  
  
                    [2] InventoryProductRecord inventoryProductResult = inventoryService.findProductByUUID(orderItemForm.productUUID);  
                        Log.infof(":requested  details for item  with id: %s from inventory",inventoryProductResult.UUID());  
  
                    Order.addOrderItem(orderId,orderItemForm.productUUID, orderItemForm.quantity);  
  
                    return Response.status(Response.Status.OK).build();  
                } else {  
                    Log.info("inventory stock validation failed");  
                    return Response.status(Response.Status.NOTACCEPTABLE).entity(inventoryStockResult).build();  
                }  
    }  
  
    @Path("update/item/{orderId}")  
    @PUT  
    public Response updateOrderItemQuantity(@PathParam("orderId") Long orderId, OrderItem orderItemForm) {  
          [1] InventoryStockResultRecord inventoryStockResult = inventoryService.checkStockAvailability(orderItemForm.productUUID,orderItemForm.quantity);  
              Log.infof(":requested stock validation check from inventory for item: %s.  Available quantity is:  %s", inventoryStockResult.productUUID(),inventoryStockResult.availableQuantity());  
  
        if(inventoryStockResult.available()) {  
            Log.info("inventory stock validation passed");  
  
            [2] InventoryProductRecord inventoryProductResult = inventoryService.findProductByUUID(orderItemForm.productUUID);  
                Log.infof(":requested  details for item  with id: %s from inventory",inventoryProductResult.UUID());  
  
            Order.updateOrderItemQuantity(orderId,inventoryProductResult.UUID(),orderItemForm.quantity);  
            return Response.status(Response.Status.OK).build();  
        } else {  
            Log.info("inventory stock validation failed");  
            return Response.status(Response.Status.NOTACCEPTABLE).entity(inventoryStockResult).build();  
        }  
    }  
  
    @Path("delete/item/{orderId}")  
    @PUT  
    public Response deleteOrderItem(@PathParam("orderId") Long orderId, OrderItem orderItemForm) {  
        Order.deleteOrderItem(orderId,orderItemForm.productUUID);  
        return Response.status(Response.Status.OK).build();  
    }  
  
    @GET  
    @Path("customer/{id}")  
    public  List<Order> findOrdersByCustomerId(@PathParam("id") Long id) {  
        return Order.findOrdersByCustomerId(id);  
  
  
    }  
  
    @DELETE  
    @Path("delete/{id}")  
    public Response deleteOrder(@PathParam("id") Long id) {  
        Order.deleteOrder(id);  
        return Response.status(Response.Status.OK).build();  
    }  
}  
```
# STEP 5. Implementing the REST Client Reactive Interface for our new inventory-service.

We then create a new interface class to handle the REST calls of our code branch to the inventory micro-service.

This new interface is called **IProductInventoryClient** within package **com.platform.ecommerce.order.rest**.

**IProductInventoryClient.java**
```java
package com.platform.ecommerce.order.rest;  
  
  
import com.platform.ecommerce.order.model.InventoryProductRecord;  
import com.platform.ecommerce.order.model.InventoryStockResultRecord;  
import jakarta.ws.rs.GET;  
import jakarta.ws.rs.Path;  
import jakarta.ws.rs.PathParam;  
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;  
  
@RegisterRestClient(configKey="inventory-service")  
@Path("/inventory-service/v1/product") // The base URL of the REST resource  
public interface IProductInventoryClient {  
    @GET  
    @Path("stock/availability/{UUID}/{quantity}")  
    InventoryStockResultRecord checkStockAvailability(@PathParam("UUID") String  UUID, @PathParam("quantity") Integer quantity);  
  
    @GET  
    @Path("uuid/{UUID}")  
    InventoryProductRecord findProductByUUID(@PathParam("UUID") String  UUID);  
  
}
```

Lets examine what is going on:

1.  **Declaring the methods**:  
    First, we define a Java interface for the REST API of our hypothetical inventory micro-service.
2.  **Annotating the interface**:  
    Second, we are using the `@RegisterRestClient` annotation, **which is a key annotation used in MicroProfile Rest Client** to declare and register a Java interface as a REST client.

> Thus we are telling Quarkus to generate an implementation of that interface at runtime and to interact with the REST API of our inventory micro-service.

**3. Specify the URL of our inventory micro-service:  
**Within the **@RegisterRestClient** annotation we specify information about the base URL of the REST API of the inventory micro-service as well as other config parameters using **configKey=”inventory-service”.**

We also add within application.properties that config-key using the format quarkus.rest-client.**{config-key-name}**.url

**application.properties**
```shell
quarkus.rest-client.inventory-service.url=http://localhost:8091
```

4. **Injecting the REST Client**:  
In our I**ProductRemoteMicroService** we inject an instance of this interface using either the `@Inject` annotation or other dependency injection mechanisms like the constructor style as shown at line [1].

```java
package com.platform.ecommerce.order.service;  
  
import com.platform.ecommerce.order.model.InventoryProductRecord;  
import com.platform.ecommerce.order.model.InventoryStockResultRecord;  
import com.platform.ecommerce.order.rest.IProductInventoryClient;  
import io.quarkus.arc.profile.UnlessBuildProfile;  
import io.quarkus.arc.properties.UnlessBuildProperty;  
import jakarta.enterprise.context.ApplicationScoped;  
import org.eclipse.microprofile.rest.client.inject.RestClient;  
  
  
@ApplicationScoped  
@UnlessBuildProperty(name = "microservices.inventory.release.enabled", stringValue = "false")  
//@UnlessBuildProfile("prod")  
public class ProductRemoteMicroService implements IInventoryService {  
  
    IProductInventoryClient inventoryClient;  
  
    [1] public ProductRemoteMicroService(@RestClient IProductInventoryClient inventoryClient) {  
        this.inventoryClient = inventoryClient;  
    }  
  
    @Override  
    public InventoryProductRecord findProductByUUID(String UUID) {  
        return inventoryClient.findProductByUUID(UUID);  
    }  
  
    @Override  
    public InventoryStockResultRecord checkStockAvailability(String UUID, Integer quantity) {  
        return inventoryClient.checkStockAvailability(UUID, quantity);  
    }  
  
}
```
# STEP 6. Import Product Sample Data with UUIDs.

Within resources directory we change **import.sql** file to include insert product statements with UUIDs. We also re-written our sample data to include more items and better names and descriptions this time.

> **We don’t touch stock info since we said aleady that we will turn on and off the new functiionality. Thus we need the local database stock info to coexist with the new functionality of fetching that data from the inventory micro-service.**

The import SQL file

**import.sql**
```sql
INSERT INTO customer (id, name, surname,email,address,phone) VALUES ( nextval('customerseq'), 'Marco','Verratti','marco.verratti@gmail.com','Princes Park (Le Parc des Princes)','000000000');  
INSERT INTO customer (id, name, surname,email,address,phone) VALUES ( nextval('customerseq'), 'Kylian','Mbappé','kylian.mbappé@gmail.com','Princes Park (Le Parc des Princes)','000000000');  
  
------------------------------- Products  -----------------------------------------------------  
  
-- Apple Product 1  
INSERT INTO product(id,  uuid, price, description, name, stock)  
VALUES (1, '4a05b88a-6e9f-4e94-b799-9d032b33d749', 3999, 'Powerful desktop computer for professionals', 'Mac Pro', 75);  
  
-- Apple Product 2  
INSERT INTO product(id,  uuid, price, description, name, stock)  
VALUES (2, 'b74fe0a0-5799-4343-9820-251d4b3c49ef',  1999, 'Slim and lightweight laptop with Retina display', 'Mac Book', 100);  
  
-- Apple Product 3  
INSERT INTO product(id,  uuid, price, description, name, stock)  
VALUES (3, '7d06a914-4ec3-42d1-821a-21ff8a98e13f',  1999, 'High-performance tablet with Apple Pencil support', 'iPad Pro', 100);  
  
-- Apple Product 4  
INSERT INTO product(id,  uuid, price, description, name, stock)  
VALUES (4,  'b3f42c5e-8c7e-4e8f-92f6-104a7a480932',  2999, 'Compact desktop computer for creative professionals', 'Mac Studio', 100);  
  
-- Apple Product 5  
INSERT INTO product(id,  uuid, price, description, name, stock)  
VALUES (5,  '6a5e89d0-17a6-4b5a-85de-12fb17001f9d',  999, 'Lightweight and versatile iPad', 'iPad Air', 100);  
  
-- Apple Product 6  
INSERT INTO product(id,  uuid, price, description, name, stock)  
VALUES (6,  '14cfe9e5-5d5e-45d3-8b60-8d89e5cdd96e',  1499, 'Professional tablet with Apple Pencil support', 'iPad Pro', 100);  
  
-- Apple Product 7  
INSERT INTO product(id,  uuid, price, description, name, stock)  
VALUES (7,  'a70c22b7-5a0e-4587-92e5-f85572ca075f',  899, 'Latest iPhone with A15 Bionic chip', 'iPhone 13', 100);  
  
-- Apple Product 8  
INSERT INTO product(id,  uuid, price, description, name, stock)  
VALUES (8, 'bc4e30d8-5089-4e35-94cc-d305c0906b22',  1099, 'Advanced iPhone with Pro camera system', 'iPhone 13 Pro', 100);  
  
-- Apple Product 9  
INSERT INTO product(id,  uuid, price, description, name, stock)  
VALUES (9,  '28aa1913-67a3-4929-ba4b-93019e00e3b5',  499, 'Compact iPhone with powerful features', 'iPhone SE', 100);  
  
-- Apple Product 10  
INSERT INTO product(id,  uuid, price, description, name, stock)  
VALUES (10, 'ad0da00c-2633-4dd1-9329-aa9437e208e4',  1299, 'Flagship iPhone with Pro Max camera system', 'iPhone 13 Pro Max', 100);  
  
INSERT INTO users (id, name, password) VALUES ( nextval('usersseq'), 'Kylian','1234');  
INSERT INTO users (id, name, password) VALUES ( nextval('usersseq'), 'Marco','1234');  
```

**OrderResourceTest.java**

```java
  
package com.platform.ecommerce.order.resource;  
  
import com.platform.ecommerce.order.model.OrderStatus;  
import com.platform.ecommerce.order.model.OrderItem;  
import io.quarkus.test.common.http.TestHTTPEndpoint;  
import io.quarkus.test.junit.QuarkusTest;  
import jakarta.json.Json;  
import jakarta.json.JsonObject;  
import jakarta.ws.rs.core.MediaType;  
import jakarta.ws.rs.core.Response;  
import org.junit.jupiter.api.*;  
import static io.restassured.RestAssured.given;  
  
@QuarkusTest  
@TestHTTPEndpoint(OrderResource.class)  
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)  
//@Disabled  
public class OrderResourceTest {  
  
    String  testProductUUID = "4a05b88a-6e9f-4e94-b799-9d032b33d749";  
  
  
    @Test  
    @Order(1)  
    public void createOrder() {  
  
        JsonObject order = Json.createObjectBuilder()  
                .add("status", OrderStatus.Pending).build();  
  
  
        // Test POST  
        given()  
                .contentType(MediaType.APPLICATIONJSON)  
                .body(order.toString())  
                .when()  
                .when().post("create/{customerId}",1)  
                .then()  
                .statusCode(Response.Status.CREATED.getStatusCode());  
    }  
  
  
    @Test  
    @Order(2)  
    public void addOrderItem() {  
  
        JsonObject orderItem = Json.createObjectBuilder()  
                .add("productUUID", testProductUUID)  
                .add("quantity", 2)  
                .build();  
  
  
        // Test POST  
        given()  
                .contentType(MediaType.APPLICATIONJSON)  
                .body(orderItem.toString())  
                .when()  
                .when().post("add/item/{orderId}",1)  
                .then()  
                .statusCode(Response.Status.OK.getStatusCode());  
    }  
  
  
    @Test  
    @Order(3)  
    public void whenFetchOrderThenAtLeastOneOrderShouldBeFound() {  
        //TEST GET  
        com.platform.ecommerce.order.model.Order order = given()  
                .accept(MediaType.APPLICATIONJSON)  
                .when().get("{id}",1)  
                .then()  
                .statusCode(Response.Status.OK.getStatusCode())  
                .extract()  
                .body().as(com.platform.ecommerce.order.model.Order.class);  
  
    }  
  
  
   @Test  
   @Order(4)  
    public void whenUpdateOrderItemQuantityThenQuantityShouldBeEqual() {  
        JsonObject orderItemJSON = Json.createObjectBuilder()  
                .add("productUUID", testProductUUID)  
                .add("quantity", 5)  
                .build();  
  
        // Test UPDATE  
        given()  
                .contentType(MediaType.APPLICATIONJSON)  
                .body(orderItemJSON.toString())  
                .when().put("update/item/{orderId}",1)  
                .then()  
                .statusCode(Response.Status.OK.getStatusCode());  
  
        //FETCH ORDER  
        com.platform.ecommerce.order.model.Order order = given()  
                .accept(MediaType.APPLICATIONJSON)  
                .when().get("{id}",1)  
                .then()  
                .statusCode(Response.Status.OK.getStatusCode())  
                .extract()  
                .body().as(com.platform.ecommerce.order.model.Order.class);  
  
  
        //EXTRACT THE ORDER ITEM FOR PRODUCT WITH ID=1  
        OrderItem orderItem = order.orderItems.stream().filter(o -> o.product.UUID.equalsIgnoreCase(testProductUUID)).findFirst().orElse(null);  
        Assertions.assertEquals(orderItem.quantity,5);  
  
    }  
  
  
    @Test  
    @Order(5)  
    public void whenAddingOrderItemGreaterThanStockQuantityThenValidationShouldReturn() {  
  
        JsonObject orderItem = Json.createObjectBuilder()  
                .add("productUUID", testProductUUID)  
                .add("quantity", 100)  
                .build();  
  
  
        // Test POST  
        com.platform.ecommerce.order.model.InventoryStockResultRecord availability = given()  
                .contentType(MediaType.APPLICATIONJSON)  
                .body(orderItem.toString())  
                .when()  
                .when().post("add/item/{orderId}",1)  
                .then()  
                .statusCode(Response.Status.NOTACCEPTABLE.getStatusCode()).extract()  
                .body().as(com.platform.ecommerce.order.model.InventoryStockResultRecord.class);  
  
        Assertions.assertEquals(availability.missingQuantity(),25);  
  
    }  
  
}
```

Then within IntelliJ open up a terminal and hit **mvn clean test.**

> Don’t forget that the feature toggle **microservices.inventory.release.enabled** should be set to **false** since we haven’t yet implemented the **inventory-service.**

# Epilogue.

A few thoughts: We invoke twice the REST Service. One for **product availability** and a second time for **fetching products**. Of course this is done only for the purpose of this tutorial and in real-life scenario we may use only one invocation both for inventory stock and product info, since our product data comes from only one micro service, the **inventory-service**.

However let’s say we have the product image served by another micro-service named **file-service**. Then we need that second invocation. We will explore that scenario in a next article and see how GraphQL with Quarkus comes into play.

> **GraphQL is a query language for your API that allows clients to request exactly the data they need and nothing more. One of the key advantages of GraphQL is that it enables clients to make multiple related queries in a single request, which can reduce the over-fetching of data and minimize the number of network requests compared to traditional REST APIs.**
---

# 📡Spring Boot API Gateway in Microservices: The Unsung Hero of Scalable Architecture 

### 🔰 What Is an API Gateway?

> An **API Gateway** is a server that acts as a **single entry point** into a system composed of multiple microservices. It functions as a reverse proxy, receiving requests from clients, routing them to the appropriate microservices, and aggregating responses for the client. API gateways also provide additional functionalities like authentication, authorization, rate limiting, and monitoring.

Instead of clients talking directly to dozens of services, they hit the **API Gateway**, which handles all the complexity under the hood.

![API Gateway](https://miro.medium.com/v2/resize:fit:875/1*O3vkMhxP8GzM73pQhg1hWg.png)

### ☘️ Why Do Microservices Need an API Gateway?

Without an API Gateway:

-   Clients must know **where each service lives**
-   They must manage **authentication** for every service
-   They must **handle retries, versioning, errors**, etc.
-   Any change in internal services means updating clients

> This defeats the whole purpose of modularity. The API Gateway restores sanity.

### 🛠️ Key Responsibilities of an API Gateway

### 🔐 1. Authentication & Authorization

-   Validate JWT tokens or API keys.
-   Integrate with OAuth, SSO, or IAM systems.
-   Prevent unauthorized access.

### 🌍 2. Routing & Aggregation

-   Route requests to the right microservice.
-   Aggregate responses from multiple services (backend-for-frontend pattern).

### 🚥 3. Rate Limiting & Throttling

-   Protect internal services from abuse or spikes.
-   Return `429 Too Many Requests` when limits are hit.

### 📦 4. Load Balancing

-   Distribute requests across multiple service instances.
-   Support retries, timeouts, and circuit breaking.

### 🐞 5. Error Handling

-   Return consistent error formats.
-   Hide internal service errors from client.

### 🎯 6. API Versioning

-   Route `/v1/users` and `/v2/users` to different services.
-   Avoid breaking changes for clients.

### 📜 7. Logging, Tracing, and Metrics

-   Capture logs and traces for observability.
-   Integrate with systems like Prometheus, OpenTelemetry, ELK, etc.

![](https://miro.medium.com/v2/resize:fit:875/1*86jVtKqLEOiE6KUPRJzOWA.png)

### 🚀 Popular API Gateway Tools

![Popular API Gateway Tools](https://miro.medium.com/v2/resize:fit:875/1*8dFoX2tWuinBYItv621j1A.png)

### ⚠️ Challenges to Watch For

-   **Single Point of Failure**: If your gateway dies, so does access to everything.
-   **Latency Bottleneck**: Adds an extra hop to every request.
-   **Overengineering**: Not every microservice system needs a gateway right away.
-   **Complex Configuration**: Routing rules, auth filters, etc., can get messy fast.

> **Tip**: Use a **clustered setup** and **monitor gateway health** aggressively.

### 💡 Best Practices

✅ Use standardized error and success response formats.
✅ Set clear timeouts, retries, and circuit breakers.
✅ Add API key or OAuth2-based authentication.
✅ Log everything — but sample to reduce noise.
✅ Keep the gateway thin — delegate business logic to services.
✅ Use API schema management (OpenAPI / Swagger) to version and validate.

### 🔎 Conclusion

-   An **API Gateway** is a **single entry point** for microservices.
-   Handles **authentication, routing, rate limiting, logging**, and more.
-   Improves **scalability, maintainability, and client simplicity**.
-   Tools include **Kong, NGINX, AWS API Gateway, Envoy, Istio**.
-   Don’t overstuff it — keep it lean, fast, and observant.

### 💬 Final Thoughts

If microservices are your micro-villages, the API Gateway is the **highway that connects them all** — enforcing tolls, directions, and safety rules. It’s essential, powerful, and like most infra heroes — **invisible when it works perfectly**.
---


# Mastering Spring's @Retryable & @Recover

Software systems are unpredictable, with challenges like network delays and third-party service outages. Handling failures properly is important for keeping applications stable. Spring’s `@Retryable` annotation helps by automatically retrying methods that fail due to temporary issues. This article covers how to use `@Retryable` to make Spring applications more resilient.

I publish free articles like this daily, if you want to support my work and get access to exclusive content and weekly recaps, consider subscribing to my [Substack](https://alexanderobregon.substack.com/).

### Introduction to Spring’s @Retryable

Modern applications often rely on external services, databases, and APIs to function. But real-world conditions aren’t always ideal — network delays, timeouts, and temporary outages can disrupt operations. If a critical part of your application depends on these external connections, it needs a way to handle failures and recover from temporary issues on its own. This is where Spring’s `@Retryable` annotation comes in, allowing methods to automatically retry when they fail due to short-lived problems.

### The Need for Retrying Operations

Imagine a service that fetches data from a remote API. In a perfect world, you send a request, and the data comes back without any issues. But in reality, things don’t always go smoothly. The server might be overloaded, your own network could be slow, or other temporary problems might get in the way. If your application isn’t prepared for these situations, failed requests can lead to frustrated users and lost opportunities.

Retrying the request sounds like an obvious fix, but adding manual retry logic everywhere in your code can quickly become messy and hard to manage. Here’s a basic example:
```java
public class ManualRetryService {  
  
    public String fetchDataFromRemote() {  
        int attempts = 0;  
        while(attempts < 3) {  
            try {  
                // Make the API call  
                return "Success";  
            } catch (Exception e) {  
                attempts++;  
            }  
        }  
        throw new MyCustomException("Failed after 3 attempts");  
    }  
}
```
Writing the retry logic manually with a `while` loop makes the code harder to manage. As more features are added—such as custom retry intervals or handling different types of exceptions—it quickly becomes more complicated and harder to keep track of.

### How @Retryable Makes the Process Easy

Before using `@Retryable`, you need to activate Spring Retry. This is done by adding the `@EnableRetry` annotation to your main application class or a configuration class:
```java
@Configuration  
@EnableRetry  
@SpringBootApplication  
public class MyApplication {  
    public static void main(String[] args) {  
        SpringApplication.run(MyApplication.class, args);  
    }  
}
```
With that in place, Spring lets you add retry logic with `@Retryable`, keeping your code clean and focused. Instead of manually handling retries, you can annotate methods that need to be retried when they fail due to temporary issues. Here’s how our earlier example looks when using `@Retryable`:
```java
import org.springframework.retry.annotation.Retryable;  
import org.springframework.stereotype.Service;  
  
@Service  
public class MyService {  
  
     @Retryable(retryFor = MyCustomException.class)  
    public String fetchDataFromRemote() {  
        // Make the API call that might fail  
        return "Success";  
    }  
}
```
Now, if `fetchDataFromRemote` throws a `MyCustomException`, Spring will automatically retry the method. This keeps the method focused on its main task, without extra retry logic cluttering the code. If needed, you can fine-tune the retry behavior with additional settings like delays and retry limits.

### Behind the Scenes

When a method is annotated with `@Retryable`, Spring wraps it with a proxy. This lets the framework step in and handle retries automatically when the method fails. It works the same way as other Spring features that use proxies, like transaction management with `@Transactional`.

### Why Choose @Retryable Over Manual Retries

1.  **Code Cleanliness:** Your business logic remains separate from your fault tolerance logic.
2.  **Maintainability:** Easier to extend or modify retry configurations without touching the business code.
3.  **Readability:** Annotations make the developer’s intent clear, making it easier to understand the expected behavior of a method.

The `@Retryable` annotation lets you add retry logic to your methods without making the code harder to read or manage. It keeps the focus on business logic while Spring handles failures in the background, helping your application stay reliable.

### Configuring @Retryable

The `@Retryable` annotation isn't a one-size-fits-all solution. It can be adjusted to fit different scenarios through a range of configuration options. With various settings available, you can control how retries are handled, making it useful for both simple and complex failure cases.

### Specifying Exception Types

Your method could throw multiple types of exceptions, but you might not want to retry the operation for all of them. For example, retrying an operation that fails due to a `NullPointerException` would likely be pointless, as the exception is probably caused by a programming error. On the other hand, retrying a failed network operation makes sense.

With `@Retryable`, you specify which exceptions should trigger a retry using the `retryFor` attribute. This is how you can tell Spring to retry a method only when specific exceptions occur:
```java
@Retryable(retryFor = { MyNetworkException.class, TimeoutException.class })  
public String fetchRemoteData() {  
    // Network call that might fail  
    return "Data";  
}
```
### Configuring Maximum Attempts

The default `maxAttempts` is 3, meaning the method is called once and retried up to two additional times (for a total of three attempts). However, you can easily customize this behavior by setting the `maxAttempts` attribute:
```java
@Retryable(retryFor = MyNetworkException.class, maxAttempts = 5)  
public String fetchRemoteData() {  
    // Network call that might fail  
    return "Data";  
}
```
### Delay Between Retries

Often, it’s useful to introduce a delay between retry attempts. This can help in situations where an external service might be temporarily overloaded. Spring allows you to configure this through the `backoff` attribute, which accepts a `@Backoff` annotation. Here's an example that specifies a two-second delay between retry attempts:
```java
@Retryable(retryFor = MyNetworkException.class, backoff = @Backoff(delay = 2000))  
public String fetchRemoteData() {  
    return "Data";  
}
```
### Exponential Backoff

In some cases, you might want to use an exponential backoff strategy, which increases the delay between each retry attempt. This can be helpful when you are dealing with services that need time to recover or scale up. The `@Backoff` annotation supports this through its `multiplier` attribute:
```java
@Retryable(retryFor = MyNetworkException.class, backoff = @Backoff(delay = 1000, multiplier = 2))  
public String fetchRemoteData() {  
    // Network call that might fail  
    return "Data";  
}
```
### Combining Multiple Parameters

The real power of `@Retryable` comes when you start combining these attributes. Here's an example that sets multiple attributes for a finely-tuned retry policy:
```java
@Retryable(retryFor = { MyNetworkException.class, TimeoutException.class },  
           maxAttempts = 5,  
           backoff = @Backoff(delay = 1000, multiplier = 2))  
public String fetchRemoteData() {  
    // Network call that might fail  
    return "Data";  
}
```
This example would retry up to 5 times, only for `MyNetworkException` and `TimeoutException`, starting with a delay of 1000 milliseconds, and doubling the delay between each subsequent retry.

### Making it Conditional

There might be scenarios where you want to control whether to proceed with the retry dynamically, based on some runtime condition or the exception thrown. You can implement this logic manually within the method by selectively throwing exceptions that trigger retries.
```java
@Retryable(retryFor = MyNetworkException.class)  
public String fetchRemoteData(String controlFlag) {  
    // Network call that might fail  
    // If you need conditional logic, implement it manually within this method or throw different exceptions  
    return "Data";  
}
```

In this example, the method first checks the `controlFlag` argument. If it is `"no-retry"`, the method returns early, avoiding retries. Otherwise, it proceeds with the operation, and if a `MyNetworkException` is thrown, Spring Retry will handle the retries automatically.

Structuring the logic this way keeps the retry mechanism flexible enough to fit specific project needs without overloading the business logic with unnecessary fault-tolerance code.

### Understanding the Parameters

The `@Retryable` annotation gives you several options for shaping how retries work. You don’t need a bunch of setup to get started. If you’re just trying to retry with a fixed delay or need something like exponential backoff, these parameters let you control the behavior in a way that fits your code.

**retryFor**  
The `retryFor` parameter tells Spring which exceptions should trigger a retry. It takes an array of exception classes. If you leave out both `retryFor` and `noRetryFor`, all exceptions are treated as retryable.
```java
@Retryable(retryFor = { MyNetworkException.class, TimeoutException.class })  
public String execute() {  
    // Code  
}
```

**noRetryFor**  
The `noRetryFor` parameter lets you skip retries for specific exceptions. This is useful when you want to retry most exceptions but skip the ones you know won’t benefit from another try.
```java
@Retryable(retryFor = Exception.class, noRetryFor = IllegalArgumentException.class)  
public String execute() {  
    // Code  
}
```
**maxAttempts**  
Use `maxAttempts` to set how many times the method should be called in total. The default is 3: one initial try and two retries. You can raise or lower that if needed.
```java
@Retryable(maxAttempts = 5)  
public String execute() {  
    // Code  
}
```
**backoff**  
The `backoff` parameter gives you a way to add a delay between attempts. It uses the `@Backoff` annotation. You can set a fixed delay or use the `multiplier` option to space out retries more gradually.
```java
@Retryable(backoff = @Backoff(delay = 2000, multiplier = 2))  
public String execute() {  
    // Code  
}
```
stateful  
When retries are `stateful`, Spring tracks the failed method call and keeps the state across attempts. This matters if your method depends on internal state that shouldn’t reset between tries.
```java
@Retryable(stateful = true)  
public String execute() {  
    // Code  
}
```
**listeners**  
The `listeners` parameter hooks into retry attempts. You pass the name of a bean that implements `RetryListener`. This is handy if you want to log retries or track metrics.
```java
@Retryable(listeners = "myRetryListenerBean")  
public String execute() {  
    // Code  
}
```
**Putting It All Together**  
You can use these parameters together to get fine-grained control over how a method retries. Here’s a combined example:
```java
@Retryable(retryFor = { MyNetworkException.class, TimeoutException.class },  
           maxAttempts = 5,  
           backoff = @Backoff(delay = 1000, multiplier = 2))  
public String execute(String arg) {  
    // Code  
    // If you need to skip retries based on arg, add logic here or throw a different exception.  
}
```
The method retries up to five times, only for the two exceptions listed. It starts with a delay of 1000 milliseconds, then doubles the wait time with each retry. If the `arg` parameter says to skip, the method can return early or throw something else to stop the retries.

Getting familiar with how these parameters work makes it easier to use `@Retryable` in a way that fits what your app needs. With the right combination, retries feel like part of the code instead of bolted on later.

### Combining @Retryable with @Recover

When using the `@Retryable` annotation, it's essential to consider what should happen if all retry attempts fail. While the retries can increase the chances of a successful operation, they can't guarantee it. That's where the `@Recover` annotation comes into the picture.

### How @Recover Works

The `@Recover` annotation allows you to define a fallback method that will be invoked when all the retry attempts configured by `@Retryable` have been exhausted. The fallback method is meant to execute alternative logic, such as sending an error message, attempting to connect to a backup service, or updating the application state to reflect the failure.

Here’s a simple example to show its use:
```java
import org.springframework.retry.annotation.Recover;  
import org.springframework.retry.annotation.Retryable;  
import org.springframework.stereotype.Service;  
  
@Service  
public class MyService {  
  
    @Retryable(retryFor = MyNetworkException.class)  
    public String fetchDataFromRemote() {  
        // Network call that might fail  
        return "Data";  
    }  
  
    @Recover  
    public String recover(MyNetworkException e) {  
        // Fallback logic  
        return "Default Data";  
    }  
}
```

In this example, if the `fetchDataFromRemote` method throws a `MyNetworkException` and exhausts all retry attempts, the `recover` method will be invoked, returning "Default Data" as a fallback.

**Matching Exception Types**  
The `@Recover` method's parameter list must match that of the `@Retryable` method but with an additional first parameter for the exception type you want to recover from.

For example, if the `@Retryable` method takes two parameters like this:
```java
@Retryable(retryFor = MyNetworkException.class)  
public String fetchData(String param1, int param2) {  
    // Network call  
}
```
Then, the `@Recover` method signature can look like this:
```java
@Recover  
public String recover(MyNetworkException e, String param1, int param2) {  
    // Fallback logic  
}
```

**Multiple Recovery Paths**  
You can define multiple `@Recover` methods for different types of exceptions. This way, you can execute different recovery logic depending on the exception type that caused all retries to fail. This is how you can set it up:
```java
@Retryable(retryFor = { MyNetworkException.class, TimeoutException.class })  
public String fetchDataFromRemote() {  
    // Network call  
}  
  
@Recover  
public String recover(MyNetworkException e) {  
    return "Default Data for MyNetworkException";  
}  
  
@Recover  
public String recover(TimeoutException e) {  
    return "Default Data for TimeoutException";  
}
```
In this example, there are two `@Recover` methods: one for `MyNetworkException` and another for `TimeoutException`. The appropriate `@Recover` method will be invoked depending on the exception that causes the retries to be exhausted.

**Making it Conditional**  
`@Recover` doesn’t have a built-in way to apply conditions like `@Retryable` does, but you can still control fallback behavior by adding checks inside the method. This lets you handle different cases based on parameters or the exception details.
```java
@Recover  
public String recover(MyNetworkException e, String param1) {  
    if ("specialcase".equals(param1)) {  
        return "Special Recovery Logic";  
    }  
    return "General Recovery Logic";  
}
```
When to Use @Recover  
While `@Retryable` can help recover from transient failures, `@Recover` comes into play when you have to deal with more persistent issues or when you want to execute a "plan B" after all retry attempts have failed.

Combining `@Retryable` with `@Recover` helps create a system that can handle both temporary failures and more persistent problems. This keeps your application running smoothly and improves the overall experience for users.

### Use Cases

There are many situations where retrying a failed operation can prevent unnecessary disruptions. Some errors are temporary, and giving the system another chance to complete the task can save time and avoid unnecessary failures. Below are some common cases where `@Retryable` can help.

**Remote Service Calls**  
When your application depends on a remote service that might be temporarily unavailable or facing intermittent issues, using `@Retryable` can increase the probability of successfully completing the operation.
```java
@Retryable(retryFor = MyNetworkException.class)  
public String fetchFromRemoteService() {  
    // HTTP request to an external API  
    return "Data";  
}
```
**Distributed Systems**  
In microservices or distributed architectures, network glitches or temporary service unavailability are common. `@Retryable` can make sure that your system is resilient to such failures.
```java
@Retryable(retryFor = TimeoutException.class)  
public void sendMessageToQueue(String message) {  
    // Send message to a message queue  
}
```
**Databases**  
Sometimes database operations can fail due to a deadlock or temporary connection issues. Retrying the transaction can often resolve these issues.
```java
@Retryable(retryFor = DatabaseException.class)  
public void updateDatabaseRecord() {  
    // Update database record  
}
```
**File Operations**  
File operations may fail due to various reasons like lack of permissions or disk space. Retrying can be effective after resolving the specific issue that led to the failure.
```java
@Retryable(retryFor = IOException.class)  
public void writeFile() {  
    // Write to a file  
}
```

**Complex Conditional Retries**  
If you need to retry based on a runtime condition, you can implement it manually inside the method. For example, you might throw a retry-triggering exception only if certain parameters meet your criteria:
```java
@Retryable(retryFor = CustomException.class)  
public void complexConditionMethod(int someArg) {  
    // If someArg > 100, throw an exception that @Retryable is configured to catch  
    if (someArg > 100) {  
        throw new CustomException("someArg exceeded threshold!");  
    }  
    // Otherwise proceed  
}
```
### Limitations

While `@Retryable` can help recover from temporary failures, it’s not always the right solution. Retrying too often or in the wrong scenarios can create new problems instead of solving them. Below are some challenges to keep in mind when adding retries to your application.

1.  **Performance Overheads:** Each retry consumes resources, whether it’s CPU cycles, memory, or even network bandwidth. Excessive retries could lead to performance bottlenecks.
2.  **Not Suitable for All Errors:** Not all types of errors are retryable. For example, retrying a failed operation due to a “file not found” exception will likely result in repeated failure.
3.  **Cascading Failures:** Too many retries in a microservices architecture can lead to cascading failures, where one failing service causes others to fail as well.
4.  **Complexity in Stateful Systems:** In systems that maintain state, a failed operation that alters the state could complicate retries.
5.  **Error Handling:** Using `@Recover` methods might lead to scattered error-handling logic, which can be difficult to manage in larger codebases.

### Conclusion

The `@Retryable` and `@Recover` annotations in Spring make it easier to add retry logic and handle failures in your applications. They offer plenty of ways to customize behavior, but it’s important to use them carefully, keeping their benefits and drawbacks in mind. Knowing how these features work and applying them thoughtfully can make your application more reliable.

---
# Observability (Part 3 - Distributed Tracing): Spring Boot integration with Kafka, Tempo, and Grafana 


In parts [1](/devops-dev/custom-micrometer-metrics-in-spring-boot-and-scrape-and-visualize-using-prometheus-and-grafana-66d020a6c90f) and [2](/@yogendra.209/observability-part-2-logging-spring-boot-integration-with-kafka-loki-and-grafana-6c87f4a26fd4), we discussed Metrics and Logs, respectively. In this part of the Observability series, we will discuss Traces.

![](https://miro.medium.com/v2/resize:fit:1700/1*NyhP9HnXkFY2wbBBwqLzPw.png)

Traces provides detailed information regarding end-to-end flow from start to end. It tracks requests as it passes through an application’s various components or services. Traces are more complex than logs and metrics. In most of the cases, Logs and Metrics should be sufficient for observations, but when an application includes multiple services, traces become essential to understand the complete path taken by a particular request across services within an application. Before we start implementation, let’s go through some concepts:

1.  **Span** represents a unit of work. A Span can have multiple child spans which will have their own scope. We can attach attributes and events to a span.
2.  **SpanContext** is an immutable object that contains span id, trace id, trace flags, trace state.
3.  **Context** is an immutable object of key value pairs. It contains currently active span, by default a span’s parent is assigned to whatever span is currently in context.
4.  **ContextPropagators** is a container which is actually responsible for distributed tracing. Context is injected into a carrier when leaving an application (or service), and extracted from a carrier when entering an application (or service).

To read more, I would suggest reading OpenTelemetry [docs](https://opentelemetry.io/docs/what-is-opentelemetry/).

Tracing system involves four major components: client instrumentation, pipeline, backend and visualization. Let’s go through each of them:

1.  **Client instrumentation** is the process of adding instrumentation points in the application that create and offload spans. We will use OpenTelemetry for this. Further, Opentelemetry provides two ways to instrument applications: Code-based solutions and Zero-code solutions. We will use Code-based solutions in our application as it gives you more control over generating telemetry data.
2.  **Pipeline** can be used to offloads spans from application, buffers them, and send to backend. This is an optional step which we will skip in our implementation.
3.  **Backend (Tempo)** is an easy-to-use distributed tracing backend to store and query traces. Like we have Loki for Logs, we have Tempo for Traces.
4.  **Visualization (Grafana)** has built-in Tempo data source that can be used to query Tempo and visualize traces. We will update our existing Grafana dashboard to display traces.

Let’s start our implementation (I have used Java and Spring Boot application but, same approach can be used for any framework or language):

### **Client instrumentation**

We will start with client instrumentation, so we will add required dependencies of OpenTelemetry (snippet from pom file):
```xml
<dependencyManagement>  
  <dependencies>  
   <dependency>  
     <groupId>io.opentelemetry</groupId>  
     <artifactId>opentelemetry-bom</artifactId>  
     <version>1.44.0</version>  
     <type>pom</type>  
     <scope>import</scope>  
   </dependency>  
  </dependencies>  
</dependencyManagement>  
  
<dependencies>  
 <dependency>  
      <groupId>io.opentelemetry</groupId>  
      <artifactId>opentelemetry-api</artifactId>  
 </dependency>  
 <dependency>  
      <groupId>io.opentelemetry</groupId>  
      <artifactId>opentelemetry-sdk</artifactId>  
 </dependency>  
 <dependency>  
      <groupId>io.opentelemetry</groupId>  
      <artifactId>opentelemetry-exporter-otlp</artifactId>  
 </dependency>  
</dependencies>
```
Now we will configure Spring bean for `OpentelemetrySdk` :
```java
@Configuration  
public class OpenTelemetryConfig {  
    @Value("${otel.trace.endpoint}")  
    private String traceEndPoint;  
  
    private SpanExporter spanExporter() {  
        return OtlpHttpSpanExporter  
                .builder()  
                .setEndpoint(traceEndPoint)  
                .build();  
    }  
  
    private SpanProcessor spanProcessor() {  
        return SimpleSpanProcessor  
                .builder(spanExporter())  
                .build();  
    }  
  
    private SdkTracerProvider sdkTracerProvider() {  
        Resource resource = Resource.builder().put("service.name", "account-producer").build();  
        return SdkTracerProvider  
                .builder()  
                .setResource(resource)  
                .addSpanProcessor(spanProcessor())  
                .build();  
    }  
  
    @Bean  
    public OpenTelemetrySdk openTelemetrySdk() {  
        return OpenTelemetrySdk  
                .builder()  
                .setTracerProvider(sdkTracerProvider())  
                .build();  
    }  
}
```
Now we can inject `OpenTelemetrySdk` and create `Tracer` instance which we can use to create and start spans.

Once done we can use `ContextPropagators` to inject current span and send across networks which can be an HTTP call, message to a Queue etc. We will also have to configure one carrier object here. For complete code, please refer to the git repo.

At the receiving application, we can construct back `ContextPropagators` from the carrier object, and get access to an existing context.

### **Tempo Setup**

Now it’s time to configure Tempo. To install Tempo locally, we can follow this [link](https://grafana.com/docs/tempo/latest/setup/linux/###install-tempo). We will keep configurations minimum and use local system for data storage. For production, we can use S3, GCS, or Azure.
```yml
server:  
  http_listen_port: 3200  
  
distributor:  
  receivers:  
    otlp:  
      protocols:  
        http:  
        grpc:  
  
compactor:  
  compaction:  
    block_retention: 48h  
  
storage:  
  trace:  
    backend: local  
    wal:  
      path: /tmp/tempo/wal  
    local:  
      path: /tmp/tempo/blocks
```

Once updated, we can restart the Tempo service using `sudo systemctl restart tempo.service`

### Grafana Setup

To install Grafana in your local system, use [this](https://grafana.com/docs/grafana/latest/setup-grafana/installation/) link. Once Grafana is up and running we will configure a data source. Go to Home > Connections > Data sources > Add new data source, select Tempo, and enter the connection URL we set up in the previous step. Now we can add visualization to the existing dashboard or create a new one. I will share the TraceQL query for visualizations we will add to our dashboard:
```yml
{resource.service.name=~"account-producer|account-consumer"}
```
Here, the service name was configured at the application level while configuring `OpentelemetrySdk` bean.

Find the link to the application code [here](https://github.com/yogi0209/account-application.git).

---

# Design a multi-tenant,Spring Boot event-driven microservices architecture using Spring Boot — Project Description

> [Youtube](https://www.youtube.com/@codefarm0) | [LinkedIn](https://www.linkedin.com/in/arvind4gl/) | [Schedule meeting with me](https://topmate.io/codefarm)

Alright Engineer Sir, you asked for a Spring Boot interview question that **hurts in the right places** — a true stress-test for even seasoned devs. One that doesn’t just ask “what is X” but why, how, what if it breaks, and what would you do in prod at 2am with pagers going off. Buckle up.

### 🔥 The Question:

**“Design a multi-tenant, event-driven microservices architecture using Spring Boot where:**

-   Each tenant has isolated data (per-tenant PostgreSQL or schema).
-   The services communicate asynchronously (Kafka).
-   Events must be ordered per tenant.
-   Events must be idempotent.
-   Dead-letter handling and delayed retries are required.
-   The system should scale to 10,000 tenants with isolated rate-limiting and observability.

**Describe how you would implement this, covering:**

1.  Spring Boot-level configurations for multi-tenancy.
2.  Kafka topic structure and partitioning strategy.
3.  How you ensure idempotency across microservices.
4.  Retry and DLQ strategy using Spring Kafka.
5.  Distributed tracing across asynchronous flows.
6.  Any race conditions or failure modes you foresee — and how to fix them.”**

### 🎯 The Real-World Pain Points You’re Being Tested On:

### 1. Spring Boot Multi-Tenancy Setup

-   Schema-per-tenant using a `TenantRoutingDataSource`.
-   `TenantContext` in a request filter for HTTP requests.
-   For Kafka consumers, you’ll need to extract tenant info from headers and switch the datasource on the fly (non-trivial, thread-local pitfalls).

👉 **Follow-up drill**: What happens if two tenants collide on schema names during provisioning?

### 2. Kafka Partitioning & Ordering

-   Kafka preserves order **only within a partition**.
-   So you partition based on `tenantid` to preserve per-tenant order.

👉 **Tradeoff**: 10,000 tenants = 10,000 partitions? Good luck. Kafka brokers will cry.

✅ **Solution**: Group low-volume tenants together, use a consistent hashing strategy (`Hash(tenantid) % N`), or leverage **Kafka tiered storage** and **compact topics**.

### 3. Idempotency

-   You must store `eventId` in the DB with a uniqueness constraint.
-   Use Spring Kafka’s `ConsumerInterceptor` or message headers to track duplicates.

👉 **Bonus twist**: What if the event is processed, the DB is updated, but the ack fails? Kafka will re-deliver.

✅ Use **outbox pattern** with **transactional producer** + **exactly-once semantics (EOS)** if using Kafka >=2.5 and idempotence is enabled.

### 4. Retry & DLQ

-   Spring Kafka’s `SeekToCurrentErrorHandler` allows retries with exponential backoff.
-   Add a custom retry topic (`events.retry.v2.<tenantid>`) for delayed retries (e.g., 5min, 15min buckets).
-   Use `DeadLetterPublishingRecoverer` for final DLQ.

👉 **Real prod twist**: What if retry causes duplicates because your consumer is not idempotent?

✅ That’s why idempotency and retry design go hand-in-hand. Otherwise, you’re just redoing bugs faster.

### 5. Distributed Tracing

-   Use **Spring Cloud Sleuth** or **Micrometer Tracing** with Kafka headers.
-   Correlate logs using `traceId` passed across services via headers.

👉 **Follow-up**: What happens when one consumer modifies headers before forwarding?

✅ Build a **non-mutating message interceptor** that validates and copies headers instead of overwriting.

### 6. Race Conditions & Failure Modes

-   Kafka consumers + multi-threading + schema switching = deadlock hell if you use the same `DataSource` across threads.
-   One tenant doing 10K TPS can starve others if you don’t have **per-tenant backpressure**.

✅ **Possible** **Solutions**:

-   Use **virtual threads** (Project Loom) for non-blocking processing.
-   Shard consumer groups by tenant priority.
-   Enforce **Bucket4j per-tenant limits**.

# 🧠 Bonus Mind-Bender:

**“Suppose your audit service writes every tenant event to S3 via Kafka. But suddenly, you see a 3-minute delay in audit logs for only 30% of tenants. No errors. No retries. Kafka lag is near zero. What’s your first guess?”**

👉 You’re being tested on:

-   Async processing behavior
-   Kafka consumer lag vs. actual processing delay
-   S3 rate limits
-   Tenant-to-shard mapping

✅ Maybe those 30% share a slow S3 region. Or maybe your async batch size in Spring Integration is misconfigured, causing batching lag.

# 🧮 Back-of-the-Envelope Estimate

Let’s break it down by **scale, throughput, latency, and cost drivers**:

### Tenants:

-   Target: **10,000 active tenants**
-   Average concurrent active tenants: ~500–1,000 at peak
-   Growth expectation: 2x in 12–18 months

### Kafka Events:

-   Average events per tenant per day: **~10,000**
-   Total daily events: `10,000 x 10,000 = 100M/day`
-   Peak: ~**5K–10K events/sec**

### Database:

-   Schema-per-tenant or DB-per-tenant
-   Estimated data growth:
-   5–10 GB/month/tenant for high-activity customers
-   Storage: `~50–100 TB over a year` across all tenants

### S3 (Audit Logs):

-   1KB per event, 100M events/day = ~100 GB/day
-   Yearly S3 usage: ~36 TB
-   With versioning & retries: **~50 TB/year**

### Infra Components:

![](https://miro.medium.com/v2/resize:fit:875/1*kAbkGQYxDzcvuXIuQv3HQA.png)

# 📋 Non-Functional Requirements (NFRs)

### Performance

-   **P99 end-to-end latency**: ≤ 2 seconds for event propagation (Kafka → Service → DB/S3)
-   **Consumer processing latency**: ≤ 500ms
-   **API response time**: ≤ 150ms for simple endpoints

### Scalability

-   Horizontal scalability for Kafka consumers/producers per tenant
-   Auto-scaling of Spring Boot pods based on event load
-   Partitioning and load balancing for tenant isolation

### Fault Tolerance

-   Retry strategy with exponential backoff (3–5 attempts)
-   DLQ support with alerting
-   Outbox pattern with Kafka transactions (at-least-once to exactly-once)

### Security

-   JWT-based tenant isolation with context propagation
-   Database credentials scoped per tenant/schema
-   Kafka topic ACLs per producer/consumer role

### Observability

-   Distributed tracing: Correlate event flow from API → Kafka → DB/S3
-   Metrics: Per-tenant TPS, lag, retries, failures, circuit-breaker status
-   Alerting: Kafka lag, DLQ threshold, S3 write failures

### Maintainability

-   Feature-flag driven tenant rollout
-   Centralized config management (Spring Cloud Config / Consul)
-   Modular services with domain isolation (Hexagonal architecture optional)

### Cost Management

-   Kafka and S3 usage alerts
-   Per-tenant metering for billing support
-   Efficient retry logic (avoid retry storms)

### 🚀 Wrap-up Summary:

This isn’t just a Spring Boot question. It’s **how a real Staff Engineer thinks**:

-   Multi-tenancy: Check.
-   Async communication: Check.
-   Ordering + idempotency: Check.
-   Observability: Check.
-   Edge cases, retries, race conditions: Absolutely.
-   Estimaation numbers
-   NFR

---
### Communicating Between Services Using Feign Client (Openfeign) 

In Spring Boot applications, when we want to send a request from one service to another service, we use the RestTemplate class. I am going directly to the example so that the subject can be easily understood. We have two Spring Boot applications. The first of these services does the taxation calculations. The other service does the operations related to displaying it on the screen.

In Calculation-Service, there is a class called Calculation-Controller.
```java
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.PathVariable;  
import org.springframework.web.bind.annotation.RestController;  
  
@RestController  
public class CalculationController {  
  
    @GetMapping("/{price}/{productType}")  
    public Double calculateTotalPrice(@PathVariable double price, @PathVariable String productType) {  
        int tax = 0;  
        if (productType.equalsIgnoreCase("lux")) {  
            tax = 25;  
        } else if (productType.equalsIgnoreCase("standart")) {  
            tax = 18;  
        } else if (productType.equalsIgnoreCase("must")) {  
            tax = 8;  
        }  
  
        return price + (price * tax / 100);  
    }  
  
    @GetMapping("/ratios")  
    public String getRatios() {  
        return "LUX=25, STANDART=18, MUST=8";  
    }  
}
```
The service that will use the endpoints in the Calculation Controller class belongs to the Presentation-Service.

NOTE:  
Presentation-Service, [http://localhost:8080](http://localhost:8080)  
Calculation-Service, [http://localhost:8081](http://localhost:8081)  
It has been raised with IP and port information.
```java
@RestController  
public class PresentationController {  
  
    private RestTemplate restTemplate = new RestTemplate();  
   
    @GetMapping("/{price}/{productType}")  
    public String showTotalPrice(@PathVariable double price, @PathVariable String productType) {  
        String resourceUrl = "http://localhost:8081/" + price + "/" + productType;  
        ResponseEntity<Double> response = restTemplate.getForEntity(resourceUrl, Double.class);  
        return "Product Price: " + price + "   ---   Product Type: " + productType + "   ---   Total Price: " + productType  
                + "   ---   Total Price: " + response.getBody();  
    }  
}
```

When the two services are up, we send a request to [http://localhost:8080/300/lux](http://localhost:8080/300/lux) and the response will be as follows.

Product Price: 300.0 — — Product Type: lux — — Total Price: lux — — Total Price: 375.0

Let’s talk about how the above process happens. First of all, we send a request by entering the product price and product type in the Presentation-Service. Because the Calculation-Service does the tax calculations, the Presentation-Service sends a request to the Calculation-Service. First, Calculation-Service returns the value it calculated, Presentation-Service performs the necessary operations on the returned value in Presentation-Service and returns the answer.

Since we are able to perform the process of sending requests and receiving responses between services, why do we need something like a Feign Client?

-   Service within the Calculation-Service and Presentation-Service is defined, which makes it easier to use and makes the code cleaner.
-   Information is managed from a common location with Calculation-Service. For example, Calculation-Service’s IP and port information.
-   We can easily track which endpoints are used by Calculation-Service from this section.
-   We do not need the RestTemplate class.

Let’s update our code to include Feign Client.

Since Presentation-Service will send requests via Feign Client, we need to add the relevant dependencies to the pom.xml file.
```xml
<dependencies>  
    <dependency>  
        <groupId>org.springframework.cloud</groupId>  
        <artifactId>spring-cloud-starter-openfeign</artifactId>  
    </dependency>  
</dependencies>  
<dependencyManagement>  
    <dependencies>  
        <dependency>  
            <groupId>org.springframework.cloud</groupId>  
            <artifactId>spring-cloud-dependencies</artifactId>  
            <version>2020.0.2</version>  
            <type>pom</type>  
            <scope>import</scope>  
        </dependency>  
    </dependencies>  
</dependencyManagement>
```
-   We add the @EnableFeignClients annotation to the PresentationServiceApplication class where our main method is located.
-   Also, we add an interface named CalculationService as follows:
```java
import org.springframework.cloud.openfeign.FeignClient;  
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.PathVariable;  
  
@FeignClient(value = "calculation-service", url = "http://localhost:8081/")  
public interface CalculationService {  
    
    @GetMapping("/{price}/{productType}")  
    Double showTotalPrice(@PathVariable double price, @PathVariable String productType);  
}
```
-   We need to make some updates to the PresentationController class in Presentation-Service.
```java
@RestController  
public class PresentationController {  
  
    private final CalculationService calculationService;  
  
    public PresentationController(CalculationService calculationService) {  
        this.calculationService = calculationService;  
    }  
  
    @GetMapping("/{price}/{productType}")  
    public String showTotalPrice(@PathVariable double price, @PathVariable String productType) {  
        Double totalPrice = calculationService.showTotalPrice(price, productType);  
        return "Product Price: " + price + "   ---   Product Type: " + productType + "   ---   Total Price: " + productType  
                + "   ---   Total Price: " + totalPrice;  
    }  
}
```

We inject CalculationService. Then, in line 12, we call the showTotalPrice method of the CalculationService. This method sends a request to the Calculation-Service via the Feign Client. We assign the return value to the totalPrice variable.

We’ve improved our code quality in many ways. This is the information I will give about Feign Client.

BONUS: We will see how to use Eureka (Service Discovery) and Feign Client together.

You are correct that Eureka allows us to abstract away the IP and port information of services. For example, if the Calculation-Service is serving on [http://localhost:8081](http://localhost:8081/), changing its port to 8082 would break the Presentation-Service client.

However, in this conversation, we won’t dive into the details of Eureka. You can find more information about Eureka Server in my upcoming article.

Sure, here are the dependencies that need to be added to the pom.xml file for a Spring Boot Eureka Server application:
```xml
<dependencies>  
    <dependency>  
        <groupId>org.springframework.cloud</groupId>  
        <artifactId>spring-cloud-starter-netflix-eureka-server</artifactId>  
    </dependency>  
</dependencies>  
<dependencyManagement>  
    <dependencies>  
        <dependency>  
            <groupId>org.springframework.cloud</groupId>  
            <artifactId>spring-cloud-dependencies</artifactId>  
            <version>2020.0.2</version>  
            <type>pom</type>  
            <scope>import</scope>  
        </dependency>  
    </dependencies>  
</dependencyManagement>
```
The [@EnableEurekaServer](http://twitter.com/EnableEurekaServer) annotation is added to the DiscoveryServiceApplication class where the Main method is located.  
Relevant information is entered in the application.properties file.
```shell
server.port=8761  
eureka.instance.hostname=localhost  
eureka.client.registerWithEureka=false  
eureka.client.fetchRegistry=false
```
The [@EnableDiscoveryClien](http://twitter.com/EnableDiscoveryClien)t annotation is added to the classes that have the main method of all the clients we want to register to the Discovery Server.

The following additions are made to the pom.xml files of the clients.
```xml
<dependencies>  
    <dependency>  
        <groupId>org.springframework.cloud</groupId>  
        <artifactId>spring-cloud-starter-netflix-eureka-server</artifactId>  
    </dependency>  
</dependencies>  
<dependencyManagement>  
    <dependencies>  
        <dependency>  
            <groupId>org.springframework.cloud</groupId>  
            <artifactId>spring-cloud-dependencies</artifactId>  
            <version>2020.0.2</version>  
            <type>pom</type>  
            <scope>import</scope>  
        </dependency>  
    </dependencies>  
</dependencyManagement>
```
When we go to [http://localhost:8761/](http://localhost:8761/) after putting three projects together, we reach the Eureka Dashboard. In this section, we can see which clients are standing.

![](https://miro.medium.com/v2/resize:fit:875/0*--h6gX88BFUEQYsK.png)

We see that both Calculation and Presentation Services are standing (status UP).

We are removing the url information in the [@FeignClient](http://twitter.com/FeignClient) annotation in the CalculationService interface in Presentation-Service. In this way, when the request comes, the Eureka service will give the IP and port information from the client name and direct it to the Calculation-Service.

You can reach the related projects from the links below.

**Eureka Server:** [https://github.com/mtnaln/eureka-server-for-feign-client-example](https://github.com/mtnaln/eureka-server-for-feign-client-example)

**Presentation Service:** [https://github.com/mtnaln/presentation-service-for-feign-client-example](https://github.com/mtnaln/presentation-service-for-feign-client-example)

**Calculation Service:** [https://github.com/mtnaln/calculation-service-for-feign-client-example](https://github.com/mtnaln/calculation-service-for-feign-client-example)


### How Spring Boot Feign Clients Exception Handling

Spring Boot integrates Feign clients to make REST API calls more straightforward and declarative. Feign is an HTTP client that lets developers define REST endpoints using Java interfaces. Instead of writing repetitive code for handling HTTP requests, developers can define the endpoints and their behavior in a clear and concise way. This article will be a technical look at the mechanics of how Feign clients work in Spring Boot, including how they are configured, how requests and responses are handled, and how errors are managed behind the scenes.

### The Basics of Feign in Spring Boot

Feign is an open-source library designed to abstract the complexities of HTTP communication by allowing developers to define HTTP clients declaratively. In Spring Boot, Feign is integrated via Spring Cloud, which automates the process of creating, managing, and using Feign clients within a Spring application. This integration transforms HTTP interactions into method invocations, allowing developers to focus on interface design rather than the specifics of HTTP communication.

At its core, Feign employs Java’s reflection and dynamic proxy mechanisms. When a Feign client interface is annotated and loaded into the application context, Spring creates a proxy object to represent that interface. This proxy object intercepts method calls and translates them into HTTP requests. The underlying mechanics involve several layers of abstraction and integration, which we will break down in detail.

### Dynamic Proxy Creation

Feign relies heavily on Java’s `Proxy` class to create dynamic implementations of interfaces. The process begins when Spring scans for interfaces annotated with `@FeignClient`. For each detected interface, Feign uses the following process:

1.  **Interface Registration**: The annotated interface is registered as a bean in the Spring application context. This registration triggers the creation of a proxy object.
2.  **Proxy Generation**: Feign uses Java’s `Proxy.newProxyInstance` method to generate a dynamic proxy for the interface. This proxy intercepts all method calls made to the interface and redirects them to an invocation handler provided by Feign.
3.  **Invocation Handler**: The invocation handler is responsible for interpreting the intercepted method call. Feign provides an implementation of the `InvocationHandler` interface that maps the method signature and annotations to an HTTP request.

For example, a method like this:
```java
@FeignClient(name = "example-client", url = "https://api.example.com")  
public interface ExampleClient {  
  
    @GetMapping("/data")  
    ResponseEntity<String> getData();  
}
```
Would result in a proxy object that, when `getData()` is called, constructs an HTTP GET request to `[https://api.example.com/data](https://api.example.com/data.)`[.](https://api.example.com/data.)

### Feign Contract and Method Parsing

Feign’s internal workings are guided by a “contract” system. The contract defines how method signatures and annotations are interpreted to construct HTTP requests. The default contract used by Spring Boot is `SpringMvcContract`, which extends Feign's base contract to support Spring MVC-specific annotations like `@RequestMapping`, `@GetMapping`, `@PathVariable`, and more.

The contract performs the following tasks:

1.  Parses the method signature to identify the HTTP method, endpoint, and expected parameters.
2.  Extracts information from annotations to map method arguments to request elements (e.g., headers, query parameters, or request body).
3.  Converts the parsed information into a `RequestTemplate`, which serves as a blueprint for the HTTP request.

For example, in the `getData` method, the `@GetMapping("/data")` annotation informs the contract to create an HTTP GET request to the `/data` endpoint of the specified URL. The contract then generates a `RequestTemplate` with this information.

### RequestTemplate and Encoding

The `RequestTemplate` is a central component in Feign’s implementation. It stores all the necessary details about the HTTP request, including:

-   HTTP method (e.g., GET, POST)
-   URL path
-   Query parameters
-   Headers
-   Request body (if applicable)

When the proxy object intercepts a method call, it uses the `RequestTemplate` to encode the request. Feign’s `RequestTemplate` allows for runtime modifications, such as adding headers or query parameters dynamically.

Encoding is handled by an `Encoder` implementation. Spring Boot configures a default encoder that integrates with Jackson for serializing Java objects into JSON. This allows Feign to seamlessly send complex Java objects in the request body.

### Request Execution and Response Handling

Once the `RequestTemplate` is fully prepared, Feign hands it over to an underlying HTTP client for execution. Spring Boot configures Feign to work with a variety of HTTP clients, such as Apache HttpClient or OkHttp, providing flexibility in terms of performance and features.

The request execution process involves:

1.  Feign converting the `RequestTemplate` into a format that the HTTP client can use, including headers, query strings, and serialized body content.
2.  The HTTP client sending the request to the target server and receiving the response.
3.  Feign deserializing the response body into the return type defined in the method signature.

The response deserialization process is handled by a `Decoder`. By default, Spring Boot uses a Jackson-based decoder to map JSON responses to Java objects. The decoder makes sure that the response data aligns with the expected return type, throwing an exception if a mismatch occurs.

Feign’s implementation in Spring Boot revolves around the concepts of dynamic proxies, contracts, and templates. The dynamic proxy mechanism intercepts method calls and translates them into HTTP requests based on the contract’s interpretation of annotations. Request templates serve as the blueprint for constructing HTTP requests, while encoders and decoders handle serialization and deserialization. Together, these components provide a easy and declarative way to interact with REST APIs within a Spring Boot application.

### Configuring Feign Clients in Spring Boot

Feign clients in Spring Boot are tightly integrated into the application context through Spring Cloud’s extensions. This configuration process involves detecting and registering Feign client interfaces, establishing default settings, and providing opportunities for customization. The mechanics behind this involve Spring’s component scanning, dynamic proxy creation, and the injection of client-specific behaviors.

### Registration of Feign Clients

When a Spring Boot application uses the `@EnableFeignClients` annotation, it triggers a specialized component scan. This scan searches for interfaces annotated with `@FeignClient` and registers them as beans in the application context. This process is handled by the `FeignClientsRegistrar` class, which is part of Spring Cloud OpenFeign.

1.  **Component Scanning**: Spring Boot scans the packages specified in the `@EnableFeignClients` annotation or its default package for interfaces with the `@FeignClient` annotation. The scan detects these interfaces and collects metadata, including the interface name, target URL, and configuration.
2.  **Bean Definition Registration**: The `FeignClientsRegistrar` registers each detected Feign client as a bean definition. This involves creating a `FactoryBean`, which generates a dynamic proxy for the client interface.
3.  **Proxy Factory Setup**: The `FeignClientFactoryBean` is used to construct the proxy for each client. It encapsulates the logic required to configure the client, such as setting the base URL and applying any custom settings.

### Default Configuration of Feign Clients

Feign clients come with a set of default configurations that dictate their behavior. These defaults include HTTP client settings, logging levels, timeout durations, and more. Spring Boot establishes these defaults by initializing a `FeignContext`, which acts as a child application context dedicated to managing Feign-related beans.

1.  **Timeouts**: Default timeout values for connection and read operations are provided through the configuration. These values can be adjusted globally or per client. The timeout settings are passed to the underlying HTTP client during its initialization.
2.  **HTTP Client Integration**: Feign can work with various HTTP client implementations, such as Apache HttpClient or OkHttp. By default, Feign uses the JDK’s HttpURLConnection, or if present, OkHttp or Apache HttpClient. This can be overridden by registering a different `Client` bean in the context.
3.  **Logging**: Feign supports multiple logging levels, such as `NONE`, `BASIC`, `HEADERS`, and `FULL`. The logging level controls the verbosity of HTTP request and response information. By default, Feign uses the `NONE` level, which disables logging. `BASIC` logs the request method, URL, response status, and execution time.

### Customizing Feign Clients

Spring Boot allows developers to override the default configurations for Feign clients by defining custom beans or applying specific configurations to individual clients.

**Custom Configuration Classes**  
A `@FeignClient` annotation can reference a custom configuration class using the `configuration` attribute. This class should define beans that modify the client’s behavior, such as custom encoders, decoders, interceptors, or error decoders. These configuration classes must not be registered as Spring-managed beans in the global context to avoid unintended side effects.

**Example:**
```java
@FeignClient(name = "custom-client", url = "https://api.example.com", configuration = CustomFeignConfig.class)  
public interface CustomClient {  
    // Method definitions  
}  
  
public class CustomFeignConfig {  
    @Bean  
    public Logger.Level feignLoggerLevel() {  
        return Logger.Level.FULL;  
    }  
  
    @Bean  
    public RequestInterceptor authInterceptor() {  
        return requestTemplate -> requestTemplate.header("Authorization", "Bearer token");  
    }  
}
```

**Global Configuration**  
Feign clients can share a global configuration defined in the `application.properties` or `application.yml` file. This configuration is applied to all clients unless overridden for specific clients. For example:
```shell
feign.client.config.default.connect-timeout=5000  
feign.client.config.default.read-timeout=10000  
feign.client.config.default.loggerLevel=full
```
**Per-Client Configuration**  
Settings can also be applied to specific clients by using their names as prefixes in the configuration file:

feign.client.config.custom-client.connect-timeout=8000  
feign.client.config.custom-client.read-timeout=15000

### FeignContext and Dependency Management

The `FeignContext` acts as an intermediary layer between the application and the Feign client. It provides a separate container for Feign-related beans, isolating their lifecycle from the rest of the application. When a Feign client is initialized, the `FeignContext` supplies the necessary dependencies, such as the HTTP client, encoder, decoder, and interceptors.

The `FeignContext` makes sure that each client can have a unique set of dependencies while sharing common resources where applicable. This isolation prevents conflicts between clients and allows for fine-grained control over their behavior.

### Integration with Spring Cloud Features

Feign’s integration with Spring Cloud extends beyond basic HTTP communication. It interacts with other Spring Cloud components to provide advanced features like service discovery and load balancing.

1.  **Service Discovery**: When a Feign client is configured with a service name instead of a URL, Spring Cloud integrates with tools like Eureka or Consul to resolve the service’s address dynamically. The service discovery mechanism queries the registry for available instances and selects one based on the configured load balancing strategy.
2.  **Load Balancing**: Historically, Feign leveraged Ribbon (now deprecated) or other supported libraries to distribute requests across multiple service instances. Modern Spring Cloud projects typically use Spring Cloud LoadBalancer for this purpose. The load balancer intercepts the request before it reaches the target service and dynamically determines the appropriate instance to handle the request.
3.  **Circuit Breakers**: Feign integrates with circuit breaker libraries such as Resilience4j (commonly used in newer projects) or Hystrix (now deprecated) to provide fault tolerance. These libraries monitor the health of downstream services and prevent cascading failures by short-circuiting requests when a service becomes unresponsive. Many existing applications still rely on Hystrix, but new projects generally favor Resilience4j.

Feign offers a flexible foundation for building microservice architectures in Spring Boot applications. The underlying mechanics of client registration, configuration management, and dependency injection make Feign clients seamlessly integrated into the application lifecycle.

### Request and Response Mappings

Request and response mappings in Feign rely on the integration of Spring MVC-style annotations and Feign’s internal mechanisms for transforming method calls into HTTP requests and handling the corresponding responses. The process involves interpreting annotations on methods and parameters, constructing HTTP requests based on this metadata, and deserializing responses back into Java objects. The implementation leverages several layers of abstraction to decouple the client interface from the specifics of HTTP communication.

### Method Signature Analysis

The starting point for mapping a request is the method signature of the Feign client interface. When a method is invoked on a Feign proxy, the metadata from the method and its annotations is analyzed to construct the HTTP request. This involves parsing:

1.  The HTTP method (e.g., GET, POST) defined by annotations such as `@GetMapping` or `@PostMapping`.
2.  The endpoint path, which may include static segments and dynamic placeholders, extracted from annotations like `@RequestMapping` or `@PathVariable`.
3.  Method parameters annotated with metadata that specifies how they should be included in the request, such as query parameters, headers, or body content.

**Example Code:**
```java
@FeignClient(name = "product-client", url = "https://api.example.com")  
public interface ProductClient {  
  
    @GetMapping("/products/{id}")  
    Product getProductById(@PathVariable("id") String productId);  
  
    @PostMapping("/products")  
    Product createProduct(@RequestBody Product product);  
  
    @GetMapping("/products")  
    List<Product> searchProducts(@RequestParam("category") String category,  
                                  @RequestParam("page") int page,  
                                  @RequestHeader("Authorization") String authHeader);  
}
```

In this example:

1.  The `@GetMapping("/products/{id}")` annotation specifies a GET request to the `/products/{id}` endpoint, with `@PathVariable("id")` mapping the `productId` method parameter to the `{id}` placeholder in the URL.
2.  The `@PostMapping("/products")` annotation defines a POST request to the `/products` endpoint, with the `@RequestBody` annotation indicating that the `product` parameter will be serialized into the body of the request.
3.  The `@GetMapping("/products")` annotation defines a GET request to `/products`, with `@RequestParam` annotations mapping the `category` and `page` parameters to query string parameters. The `@RequestHeader` annotation adds an `Authorization` header to the request.

### RequestTemplate Construction

The data extracted from the method signature is encapsulated in a `RequestTemplate`. This object serves as a blueprint for the HTTP request, capturing all relevant details, including the HTTP method, target URL, headers, query parameters, and body content.

-   **URL and Path Variables**: Path variables defined by annotations such as `@PathVariable` are dynamically replaced in the URL template with the values provided during the method call. Feign uses a placeholder-based approach to substitute these values into the URL.
-   **Query Parameters**: Parameters annotated with `@RequestParam` are added to the query string of the URL. Feign handles the encoding of these parameters to manage special characters and spaces properly.
-   **Headers**: Custom headers can be added using the `@RequestHeader` annotation. These headers are stored in the `RequestTemplate` and appended to the HTTP request during execution.
-   **Body Content**: For methods annotated with `@RequestBody`, the provided object is serialized into the request body. By default, Feign uses Jackson for serialization, but this can be customized with a user-defined `Encoder`.

The `RequestTemplate` is a mutable object, allowing modifications to be made at runtime. This flexibility is particularly useful for applying global headers, query parameters, or other request-specific customizations.

**Example Code:**
```java
@FeignClient(name = "order-client", url = "https://api.example.com")  
public interface OrderClient {  
  
    @PostMapping("/orders")  
    Order createOrder(@RequestBody Order order,  
                      @RequestHeader("Authorization") String authHeader);  
  
    @GetMapping("/orders/{id}")  
    Order getOrderById(@PathVariable("id") String orderId,  
                       @RequestHeader("Authorization") String authHeader);  
  
    @GetMapping("/orders")  
    List<Order> getOrdersByStatus(@RequestParam("status") String status,  
                                  @RequestParam("limit") int limit,  
                                  @RequestHeader("Authorization") String authHeader);  
}
```
In this example:

1.  The `createOrder` method generates a `RequestTemplate` with the HTTP method set to POST, the URL set to `/orders`, a serialized JSON body from the `order` parameter, and an `Authorization` header.
2.  The `getOrderById` method constructs a template with a GET request, dynamically replaces the `{id}` placeholder in the URL with the value of the `orderId` parameter, and includes the `Authorization` header.
3.  The `getOrdersByStatus` method builds a GET request template with query parameters (`status` and `limit`) encoded into the URL and the `Authorization` header added to the request.

### Encoding and Serialization

Before the `RequestTemplate` is sent to the HTTP client, its contents must be encoded into a format suitable for transmission. This process is handled by Feign’s `Encoder` interface. The default implementation integrates with Jackson, which is used to serialize Java objects into JSON.

-   **JSON Serialization**: For methods that include a request body, Feign invokes the configured encoder to convert the Java object into a JSON string. This string is then added to the `RequestTemplate` as the body content, with the appropriate `Content-Type` header.
-   **Form Data Encoding**: If a method requires form data, Feign uses a specialized encoder to serialize the parameters into the `application/x-www-form-urlencoded` format.

he encoder is responsible for aligning the serialized data with the expected format of the target API, which may involve handling custom serialization logic or third-party libraries.

**Example Code:**
```java
@FeignClient(name = "payment-client", url = "https://api.example.com", configuration = CustomFeignConfig.class)  
public interface PaymentClient {  
  
    @PostMapping(value = "/payments", consumes = "application/json")  
    PaymentResponse initiatePayment(@RequestBody PaymentRequest paymentRequest);  
  
    @PostMapping(value = "/payments/form", consumes = "application/x-www-form-urlencoded")  
    PaymentResponse initiatePaymentWithForm(@RequestParam("amount") double amount,  
                                            @RequestParam("currency") String currency,  
                                            @RequestHeader("Authorization") String authHeader);  
}  
  
public class PaymentRequest {  
    private double amount;  
    private String currency;  
  
    // Getters and setters  
}
```
**Custom Encoder Configuration:**
```java
@Configuration  
public class CustomFeignConfig {  
  
    @Bean  
    public Encoder customEncoder() {  
        return new JacksonEncoder(new ObjectMapper().enable(SerializationFeature.INDENTOUTPUT));  
    }  
}
```

Explanation:

1.  **JSON Serialization**: In the `initiatePayment` method, the `PaymentRequest` object is serialized into JSON by the Jackson-based encoder. The `Content-Type` header is set to `application/json` to indicate the payload format.
2.  **Form Data Encoding**: The `initiatePaymentWithForm` method serializes the `amount` and `currency` parameters into a form-encoded string (e.g., `amount=100&currency=USD`). This is achieved by Feign’s built-in form data encoder.
3.  **Custom Encoder**: The custom encoder in the `CustomFeignConfig` class uses a customized Jackson `ObjectMapper` to modify serialization behavior, such as enabling pretty-printed JSON.

This code shows how Feign utilizes encoders to transform Java objects or parameter values into the required format for the HTTP request body. Customization of the encoder allows developers to handle specialized serialization scenarios efficiently.

### HTTP Request Execution

Once the `RequestTemplate` is fully constructed and encoded, Feign passes it to the configured HTTP client for execution. The HTTP client translates the template into an actual HTTP request, sends it to the target server, and waits for the response.

-   **Headers and Query Parameters**: The HTTP client includes all headers and query parameters from the `RequestTemplate` in the outgoing request. Headers are appended directly to the request, while query parameters are appended to the URL.
-   **Body Content**: If the request includes a body, the encoded content is transmitted as part of the HTTP request. The `Content-Type` header makes sure that the server interprets the body correctly.

Feign abstracts the complexity of HTTP request execution by delegating the actual communication to a pluggable HTTP client, such as Apache HttpClient or OkHttp.

**Example Code:**
```java
@FeignClient(name = "order-client", url = "https://api.example.com", configuration = HttpClientConfig.class)  
public interface OrderClient {  
  
    @GetMapping("/orders/{id}")  
    Order getOrderById(@PathVariable("id") String orderId,  
                       @RequestHeader("Authorization") String authHeader);  
  
    @PostMapping(value = "/orders", consumes = "application/json")  
    Order createOrder(@RequestBody Order order,  
                      @RequestHeader("Authorization") String authHeader);  
}  
  
public class Order {  
    private String id;  
    private String description;  
  
    // Getters and setters  
}
```

**Custom HTTP Client Configuration:**
```java
@Configuration  
public class HttpClientConfig {  
  
    @Bean  
    public Client feignClient() {  
        return new ApacheHttpClient(); // Configures Feign to use Apache HttpClient  
    }  
  
    @Bean  
    public Logger.Level feignLoggerLevel() {  
        return Logger.Level.FULL; // Logs the full HTTP request and response details  
    }  
}
```

How It Works:

**Execution of** `**getOrderById**`:

-   Feign constructs an HTTP GET request to `[https://api.example.com/orders/{id}](https://api.example.com/orders/{id}.)`[.](https://api.example.com/orders/{id}.)
-   The `{id}` placeholder in the URL is replaced with the `orderId` parameter.
-   The `Authorization` header is added to the request with the provided value.
-   The configured HTTP client (Apache HttpClient in this case) sends the request and receives the response.

**Execution of** `**createOrder**`:

-   Feign constructs an HTTP POST request to `[https://api.example.com/orders](https://api.example.com/orders.)`[.](https://api.example.com/orders.)
-   The `order` object is serialized into a JSON string and included in the request body.
-   The `Content-Type` header is set to `application/json` and the `Authorization` header is appended.

**Logging**:

-   The Feign logger, configured to `FULL` level, logs details of the HTTP request and response, including headers, query parameters, and body content.

This shows how Feign delegates the construction of the actual HTTP request to its underlying client and how headers, query parameters, and body content from the `RequestTemplate` are transmitted to the server. The pluggable HTTP client architecture allows developers to select or customize the client to meet performance or compatibility requirements.

### Response Mapping and Decoding

Once the server responds, Feign processes the HTTP response and maps it to the return type of the method. This involves:

1.  Extracting the response body, status code, and headers from the HTTP response.
2.  Decoding the response body into a Java object using Feign’s `Decoder` interface.

-   **Decoding with Jackson**: The default decoder integrates with Jackson to deserialize JSON responses into Java objects. The method’s return type is used to determine the target object type for deserialization. For example, a method returning `ResponseEntity<User>` will invoke Jackson to map the response body into a `User` object.
-   **Handling Non-Body Responses**: If the response does not include a body (e.g., HTTP 204 No Content), Feign returns `null` or an empty wrapper type based on the method’s return type.
-   **Custom Decoding**: Developers can provide custom decoders to handle specialized response formats or data transformation requirements. For example, a custom decoder might be used to process XML responses or to extract specific fields from a nested JSON structure.

**Example Code:**
```java
@FeignClient(name = "user-client", url = "https://api.example.com", configuration = CustomFeignDecoderConfig.class)  
public interface UserClient {  
  
    @GetMapping("/users/{id}")  
    User getUserById(@PathVariable("id") String userId);  
  
    @GetMapping("/users")  
    List<User> getAllUsers();  
  
    @GetMapping("/users/metadata")  
    Metadata getUserMetadata(@RequestHeader("Authorization") String authHeader);  
}  
  
public class User {  
    private String id;  
    private String name;  
    private String email;  
  
    // Getters and setters  
}  
  
public class Metadata {  
    private int totalUsers;  
    private String lastUpdated;  
  
    // Getters and setters  
}

**Custom Decoder Configuration:**

@Configuration  
public class CustomFeignDecoderConfig {  
  
    @Bean  
    public Decoder customDecoder() {  
        return (response, type) -> {  
            if (type == Metadata.class) {  
                String responseBody = Util.toString(response.body().asReader());  
                // Custom logic to parse metadata  
                ObjectMapper mapper = new ObjectMapper();  
                return mapper.readValue(responseBody, Metadata.class);  
            }  
            return new JacksonDecoder().decode(response, type); // Default decoding for other types  
        };  
    }  
}
```

Explanation:

**Decoding JSON Responses**:

-   The `getUserById` and `getAllUsers` methods rely on the default Jackson-based decoder to map the response body to `User` and `List<User>` objects, respectively.
-   Feign automatically determines the return type of the method and uses it to guide the decoding process.

**Custom Decoding**:

-   The `getUserMetadata` method demonstrates how a custom decoder can be used for responses requiring specialized processing. For example, if the server sends metadata in a specific format, the custom decoder parses it into the `Metadata` class.

**Handling Non-Body Responses**:

-   For HTTP responses with no body, such as `204 No Content`, Feign would return `null` for methods like `getUserById` or an empty collection for methods like `getAllUsers`, depending on the return type.

This example demonstrates how Feign decodes responses into Java objects, either using the default Jackson decoder or a custom decoder for more specialized use cases. The flexibility to handle different response formats and map them to meaningful return types is central to Feign’s declarative HTTP client model.

### Headers and Metadata Processing

Feign retains metadata from the HTTP response, including headers and status codes. These details are particularly useful for methods that return objects such as `ResponseEntity` or other types that require access to the raw response. By preserving this information, Feign allows developers to access additional context about the server’s response beyond the body.

-   **Status Codes**: The HTTP status code is directly mapped to `ResponseEntity` or similar wrapper types. Feign does not enforce behavior based on status codes but leaves it up to the application logic to interpret them.
-   **Headers**: Response headers are exposed as part of the mapped object. If a method returns `ResponseEntity<T>`, the headers can be accessed via the `ResponseEntity` object.

**Example Code:**
```java
@FeignClient(name = "order-client", url = "https://api.example.com")  
public interface OrderClient {  
  
    @GetMapping("/orders/{id}")  
    ResponseEntity<Order> getOrderWithMetadata(@PathVariable("id") String orderId);  
  
    @GetMapping("/orders")  
    ResponseEntity<List<Order>> getAllOrdersWithHeaders();  
}  
  
public class Order {  
    private String id;  
    private String description;  
    private double price;  
  
    // Getters and setters  
}
```

How It Works:

**Accessing Headers**:

-   In the `getOrderWithMetadata` method, Feign maps the HTTP response body to an `Order` object and wraps it in a `ResponseEntity`. The `ResponseEntity` also includes metadata such as HTTP headers and the status code.

Example usage:
```java
ResponseEntity<Order> response = orderClient.getOrderWithMetadata("12345");  
HttpHeaders headers = response.getHeaders();  
int statusCode = response.getStatusCodeValue();  
Order order = response.getBody();  
  
System.out.println("Headers: " + headers);  
System.out.println("Status Code: " + statusCode);  
System.out.println("Order Details: " + order);
```
**Accessing Metadata for Lists**:

-   The `getAllOrdersWithHeaders` method wraps a `List<Order>` in a `ResponseEntity`, allowing access to both the response body and the accompanying headers.

Example usage:
```java
ResponseEntity<List<Order>> response = orderClient.getAllOrdersWithHeaders();  
List<Order> orders = response.getBody();  
HttpHeaders headers = response.getHeaders();  
  
System.out.println("Total Orders: " + orders.size());  
System.out.println("Headers: " + headers);
```
**Custom Header Processing**  
If specific headers require processing, custom logic can be added to extract and handle them. For example:
```java
public class CustomHeaderProcessor {  
  
    public static void processResponseHeaders(HttpHeaders headers) {  
        String rateLimit = headers.getFirst("X-RateLimit-Remaining");  
        String totalCount = headers.getFirst("X-Total-Count");  
  
        System.out.println("Rate Limit Remaining: " + rateLimit);  
        System.out.println("Total Count: " + totalCount);  
    }  
}
```

By abstracting these complex details, Feign provides a declarative interface for REST communication while maintaining the flexibility to handle custom scenarios. The combination of method signature parsing, template-based request construction, and decoder-based response mapping forms the foundation of Feign’s request and response handling process.

### Exception Handling in Feign Clients

Exception handling in Feign involves multiple layers of abstraction and integration to manage scenarios where HTTP requests fail, non-2xx responses are returned, or unexpected behaviors occur during the lifecycle of a request. Feign provides a framework that maps HTTP errors to exceptions, customizes error handling, and integrates seamlessly with Spring’s broader mechanisms.

### FeignException and Default Behavior

The `FeignException` class is the default mechanism for wrapping errors during HTTP communication. When a non-2xx response is received, or a client-level issue occurs, Feign encapsulates the error in a `FeignException`.

1.  **Error Detection**: Feign identifies a failure when the HTTP response code falls outside the 2xx range or when an HTTP client error (e.g., a timeout) occurs.
2.  **Exception Wrapping**: The `FeignException` object is constructed with metadata such as the HTTP status code, response body (if available), and the request details.

**Example:**
```java
try {  
    MyFeignClient client = ... // Feign client  
    client.getData(); // Call to a remote API  
} catch (FeignException e) {  
    System.out.println("HTTP Status: " + e.status());  
    System.out.println("Response Body: " + e.contentUTF8());  
}
```

This code demonstrates how to catch a `FeignException` and extract information like the status code and response body for diagnostics.

### ErrorDecoder Mechanism

The `ErrorDecoder` interface provides a way to map specific HTTP response codes or error conditions to custom exceptions. This allows developers to translate HTTP errors into application-specific exceptions that align with their domain logic.

1.  **Custom Error Mapping**: The `decode` method is called whenever Feign receives a non-2xx response. The method can analyze the response status, headers, and body to construct an exception that encapsulates relevant information.
2.  **Exception Propagation**: The exception returned by the `decode` method is propagated back to the caller of the Feign client.

**Example of a custom** `**ErrorDecoder**`**:**
```java
public class CustomErrorDecoder implements ErrorDecoder {  
  
    @Override  
    public Exception decode(String methodKey, Response response) {  
        if (response.status() == 404) {  
            return new ResourceNotFoundException("Resource not found: " + methodKey);  
        } else if (response.status() >= 500) {  
            return new ServerErrorException("Server error occurred: " + methodKey);  
        }  
        return new ErrorDecoder.Default();  
    }  
}
```

**To apply the custom decoder:**
```java
@Configuration  
public class FeignConfig {  
  
    @Bean  
    public ErrorDecoder customErrorDecoder() {  
        return new CustomErrorDecoder();  
    }  
}
```
In this configuration, the custom `ErrorDecoder` is used to map specific HTTP status codes to meaningful exceptions, such as `ResourceNotFoundException` or `ServerErrorException`.

### Integration with Spring’s Exception Handling

Feign integrates seamlessly with Spring’s exception handling capabilities, allowing Feign-specific exceptions to be managed globally using `@ControllerAdvice`.

**Example:**
```java
@ControllerAdvice  
public class GlobalExceptionHandler {  
  
    @ExceptionHandler(ResourceNotFoundException.class)  
    public ResponseEntity<String> handleNotFound(ResourceNotFoundException ex) {  
        return ResponseEntity.status(HttpStatus.NOTFOUND).body(ex.getMessage());  
    }  
  
    @ExceptionHandler(ServerErrorException.class)  
    public ResponseEntity<String> handleServerError(ServerErrorException ex) {  
        return ResponseEntity.status(HttpStatus.INTERNALSERVERERROR).body(ex.getMessage());  
    }  
}
```
In this example, Feign exceptions like `ResourceNotFoundException` and `ServerErrorException` are intercepted and mapped to appropriate HTTP responses, maintaining consistency in error handling across the application.

### Circuit Breaker Integration

Feign often works with circuit breaker libraries, such as Resilience4j, to add fault-tolerant behaviors. Circuit breakers prevent excessive load on unresponsive services by short-circuiting requests and triggering fallback logic.

**Example with Resilience4j:**
```java
@FeignClient(name = "my-client", fallback = MyClientFallback.class)  
public interface MyFeignClient {  
  
    @GetMapping("/data")  
    String getData();  
}  
  
@Component  
public class MyClientFallback implements MyFeignClient {  
  
    @Override  
    public String getData() {  
        return "Fallback response";  
    }  
}
```

In this example, if the remote service is unresponsive, the fallback class provides a default response, reducing the impact of service outages.

### Logging and Diagnostics

Detailed logging is vital for understanding and debugging exceptions in Feign. Feign’s logging mechanisms capture the request and response details, which are crucial for diagnosing issues.

**Example of enabling detailed logging:**
```java
@Configuration  
public class FeignLoggingConfig {  
  
    @Bean  
    public Logger.Level feignLoggerLevel() {  
        return Logger.Level.FULL; // Logs request and response details  
    }  
}
```

When logging is set to `FULL`, Feign captures all aspects of the request and response, including headers, query parameters, and body content. This is especially useful for troubleshooting complex failures in HTTP communication.

### Customization of Retry Behavior

Retries can be configured to handle transient errors, such as timeouts or temporary service unavailability. Feign’s `Retryer` interface governs the retry logic.

**Example of a custom** `**Retryer**`**:**
```java
public class CustomRetryer implements Retryer {  
  
    private int attempt = 1;  
    private final int maxAttempts = 3;  
  
    @Override  
    public void continueOrPropagate(RetryableException e) {  
        if (attempt++ >= maxAttempts) {  
            throw e;  
        }  
        try {  
            Thread.sleep(1000); // Delay between retries  
        } catch (InterruptedException ex) {  
            Thread.currentThread().interrupt();  
        }  
    }  
  
    @Override  
    public Retryer clone() {  
        return new CustomRetryer();  
    }  
}
```
**To apply the custom retryer:**
```java
@Configuration  
public class FeignRetryConfig {  
  
    @Bean  
    public Retryer customRetryer() {  
        return new CustomRetryer();  
    }  
}
```

This implementation retries failed requests up to three times with a one-second delay between attempts. It is helpful for mitigating temporary network issues or service flaps.

### Conclusion

Feign utilizes dynamic proxies, contracts, and templates to abstract the complexities of HTTP requests and responses. It retains flexibility through customizable configurations, error handling mechanisms, and integration with Spring’s broader ecosystem. The mechanics behind Feign provide a solid foundation for efficient and adaptable REST API communication in Spring Boot applications.

