# Centralized Monitoring with Spring Boot Admin 
This post is only for those who work with Spring Boot, others can ignore.

In a microservices ecosystem, monitoring individual applications becomes unwieldy. Spring Boot Admin (SBA) solves this by providing a unified dashboard to manage, monitor, and alert on your Spring Boot services.

> **Not a paid member of Medium?,** You can read here: [**Centralized Monitoring with Spring Boot Admin**](/@storybydhanush/2ae1e49aeef3?sk=0535d00acd723babce14642186dc5de5)

Let’s build an Admin server, connect client apps, configure alerts, and dynamically control logging — all while keeping your ops team sane.

### Table of Contents:

· [**Step 1:** Create the Spring Boot Admin Server](#3fdd)  
∘ [Initialize the Admin Server Project](#6db9)  
∘ [Enable the Admin Server](#717a)  
· [**Step 2:** Register Client Applications](#50d1)  
∘ [Client Setup](#ab77)  
· [**Step 3:** Monitor Health and Metrics](#b1ad)  
∘ [Dashboard Overview](#8a45)  
· [**Step 4:** Configure Alerts](#63a1)  
∘ [Email Notifications](#ac89)  
· [Slack Alerts (Bonus)](#efb4)  
· [**Step 5:** Dynamic Log Level Management](#4b67)  
∘ [Enable Loggers Endpoint on Clients](#5f34)  
∘ [Adjust Log Levels via Admin UI](#767e)  
· [**Best Practices** for Production](#7598)  
· [Build a Multi-Service Monitoring Dashboard](#000f)  
∘ [Try yourself](#1555)  
· [Conclusion](#0cce)

### Step 1: Create the Spring Boot Admin Server

### Initialize the Admin Server Project

Create a new Spring Boot application and add the SBA(Spring boot admin starter server) dependency:

**Maven**:
```xml
<dependency>    
    <groupId>de.codecentric</groupId>    
    <artifactId>spring-boot-admin-starter-server</artifactId>    
    <version>3.2.0</version>    
</dependency>
```
**Gradle**:
```java
implementation 'de.codecentric:spring-boot-admin-starter-server:3.2.0'
```
### Enable the Admin Server

Annotate your main class with `@EnableAdminServer`:
```java
@SpringBootApplication    
@EnableAdminServer    
public class AdminServerApplication {    
    public static void main(String[] args) {    
        SpringApplication.run(AdminServerApplication.class, args);    
    }    
}
```

**Configure the Server Port** (optional):

### application.properties    
```java
server.port=8080
```
### Step 2: Register Client Applications

We are using spring boot starter client dependency here.

### Client Setup

Add the SBA client dependency to your Spring Boot services:
```xml
<dependency>    
    <groupId>de.codecentric</groupId>    
    <artifactId>spring-boot-admin-starter-client</artifactId>    
    <version>3.2.0</version>    
</dependency>
```
**Point Clients to the Admin Server**:

### application.properties    
### ======================  
```shell
spring.boot.admin.client.url=http://localhost:8080    
management.endpoints.web.exposure.include=*    
management.endpoint.health.show-details=always
```
-   `management.endpoints.web.exposure.include=*` exposes all Actuator endpoints.
-   Clients automatically register on startup.

### Step 3: Monitor Health and Metrics

It is not like sitting and watching 24/7, there is more of it.

### Dashboard Overview

Access the Admin UI at `http://localhost:8080`:

-   **Applications**: List of registered services.
-   **Health Status**: UP/DOWN indicators.
-   **Details**: CPU usage, threads, heap memory.

### Step 4: Configure Alerts

### Email Notifications

Add mail dependencies to the Admin server:
```xml
<dependency>    
    <groupId>org.springframework.boot</groupId>    
    <artifactId>spring-boot-starter-mail</artifactId>    
</dependency>
```
**Configure SMTP and Notifications**:

### Admin server’s application.properties    
```shell
spring.mail.host=smtp.gmail.com    
spring.mail.port=587    
spring.mail.username=admin@example.com    
spring.mail.password=your-app-password    
spring.mail.properties.mail.smtp.auth=true    
spring.mail.properties.mail.smtp.starttls.enable=true    
spring.boot.admin.notify.mail.to=alerts@example.com    
spring.boot.admin.notify.mail.from=admin-server@example.com
```
**Trigger Conditions**:
```java
@Configuration    
public class AlertConfig {    
    @Bean    
    public MailNotifier mailNotifier(JavaMailSender mailSender) {    
        MailNotifier notifier = new MailNotifier(mailSender);    
        notifier.setIgnoreChanges(new String[]{"UNKNOWN:UP"}); // Alert only on DOWN    
        return notifier;    
    }    
}
```
### Slack Alerts (Bonus)

Use a `WebhookNotifier` for Slack:
```java
@Bean    
public WebhookNotifier slackNotifier() {    
    return new WebhookNotifier(    
        List.of("https://hooks.slack.com/services/TXXXXXX/BXXXXXX/XXXXXXXX"),    
        new ObjectMapper()    
    );    
}
```
### Step 5: Dynamic Log Level Management

### Enable Loggers Endpoint on Clients

Ensure clients expose the `/actuator/loggers` endpoint:

### client-service/application.properties    
```shell
management.endpoints.web.exposure.include=health,metrics,loggers
```
### Adjust Log Levels via Admin UI

1.  Navigate to the client’s detail page.
2.  Select **Loggers** from the sidebar.
3.  Search for a package (e.g., `com.example.service`).
4.  Change the log level (e.g., DEBUG → WARN).

### Best Practices for Production

**Secure the Admin Server**:
```java
@Configuration    
@EnableWebSecurity    
public class SecurityConfig {    
    @Bean    
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {    
        http    
            .authorizeHttpRequests(auth -> auth    
                .anyRequest().authenticated()    
            )    
            .formLogin(withDefaults());    
        return http.build();    
    }    
}
```

**Client Authentication**

### Client application.properties     
```shell
spring.boot.admin.client.username=admin     
spring.boot.admin.client.password=secret
```
**Retention Policies**: Archive old metrics using Prometheus or Elasticsearch.

### Build a Multi-Service Monitoring Dashboard

### **Try yourself**

**Deploy 2+ Spring Boot clients** (e.g., orders-service, users-service).

**Configure the Admin Server** to monitor both.

**Set Up Alerts**:

-   Email on any service going DOWN.
-   Slack alert on high JVM memory usage (>90%).

**Dynamic Logging**: Change the log level of a service via the UI.

**Example Alert Configuration**:
```java
@Bean    
public CompositeNotifier compositeNotifier(MailNotifier mail, WebhookNotifier slack) {    
    return new CompositeNotifier(List.of(mail, slack));    
}
```

**Share Your Setup**:

-   Post screenshots of your Admin dashboard.
-   Share your `application.properties` for alerts.
-   GitHub repo with client/server code.

Spring Boot Admin enhances observability by centralizing health checks, enabling dynamic logging, and sending targeted alerts, allowing you to address issues before they escalate — all from a single dashboard.

---
### Spring Boot ResponseBodyAdvice in Spring Boot part(1)

### Introduction:

When you build a Spring Boot application with a RESTful API, one of the concepts you need to focus on is the General Response Structure for the Client side, and in this Article, I want to talk about a `ResponseBodyAdvice interface` and the interface provided by the Springboot framework, to help us build a General Response structure, with `ResponseBodyAdvice` and `@ControllerAdvice` We can build a centralized and standardized API response.

So let`s go on to know how to use it with our applications.

### The Problem with Inconsistent API Responses

Before we go to a deep dive and see how we can implement the solution, we need to know what the problem we faced is, to change the approach, and use a different one.

When returning the response to the client side, the client side will wait for data to present it to the application user, and the data here will be different depending on the API that was called.

And here you can find a response from two different APIs, and how the response structures changed between the two of them.
```json
// One endpoint returns:  
{  
  "id": 1,  
  "name": "John"  
}  
  
// Another returns:  
{  
  "status": "success",  
  "data": {  
    "id": 2,  
    "name": "Jane"  
  }  
}
```

### What is `ResponseBodyAdvice` in Spring Boot?

And now, after we have seen the problem, we will fix it, using `ResponseBodyAdvice` .

So what is the `ResponseBodyAdvice` ?

The Spring Boot provides us with, handy solution to build our response using an `ResponseBodyAdvice<T>` interface, which will help us to wrap the response into our general response before returning it from the Controller.

Also, to use it you need to know about the `@ControllerAdvice` .

And here we will start implementing it.

So we need to build the following response for each existing API in our application
```json
{  
  "success": true,  
  "data": { ... }  
}
```
### 2. Define the Warrper DTO class.
```java
public class ApiResponse<T> {  
    private boolean success;  
    private T data;  
  
    public ApiResponse(boolean success, T data) {  
        this.success = success;  
        this.data = data;  
    }  
  
    // Getters and setters  
}
```
### 2. Create the Response Advice
```java
import org.springframework.core.MethodParameter;  
import org.springframework.http.MediaType;  
import org.springframework.http.server.ServerHttpRequest;  
import org.springframework.http.server.ServerHttpResponse;  
import org.springframework.web.bind.annotation.ControllerAdvice;  
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;  
  
@ControllerAdvice  
public class GlobalResponseAdvice implements ResponseBodyAdvice<Object> {  
  
    @Override  
    public boolean supports(MethodParameter returnType, Class converterType) {  
        // You can add conditions here if you want to exclude certain controllers or methods  
        return true;  
    }  
  
    @Override  
    public Object beforeBodyWrite(Object body,  
                                  MethodParameter returnType,  
                                  MediaType selectedContentType,  
                                  Class selectedConverterType,  
                                  ServerHttpRequest request,  
                                  ServerHttpResponse response) {  
  
        // Avoid double-wrapping if already wrapped  
        if (body instanceof ApiResponse) {  
            return body;  
        }  
  
        return new ApiResponse<>(true, body);  
    }  
}
```
### 3. Define the RestController
```java
@GetMapping("/user")  
public User getUser() {  
    return new User("Abdalrhman", "Alkraien");  
}
```
And the response will automatically be wrapped as the follwoing.
```json
{  
  "success": true,  
  "data": {  
    "firstName": "Abdalrhman",  
    "lastName": "Alkraien"  
  }  
}
```
### Conclusion

In modern API development, consistency is key.

By using `ResponseBodyAdvice` In Spring Boot, you gain a powerful way to centralize and standardize your API responses across the entire application, without cluttering your controller logic.

It enables backend teams to maintain a unified response structure, ensuring seamless collaboration and eliminating the need for team-specific adjustments.

> **If you enjoyed the article, don’t forget to give it some claps — you can clap up to 50 times per post! You can also connect with me on** [**LinkedIn**](https://www.linkedin.com/in/abd-alrhman-alkraien-83a93a1b1/)**. If you have any questions or suggestions, feel free to reach out — I’d love to hear from you!**

---
# Spring Boot integrated pmd plugin quick start Demo

### 1. What is the PMD plugin?

The PMD plugin allows you to run automatically on your project’s source code[PMD](https://pmd.github.io/)code analysis tool and generate a site report with its results. It also supports a separate copy/paste detector tool (or CPD) that is distributed with the PMD. This version of the Maven PMD plugin uses PMD 6.42.0 and requires Java 8. For more information, see[Upgrade the PMD at runtime.](https://maven.org.cn/plugins/maven-pmd-plugin/examples/upgrading-PMD-at-runtime.html) The plugin accepts configuration parameters that can be used to customize the execution of the PMD tool.

###### Overview of the objectives

This plugin has the following goals:

-   [pmd:pmd](https://maven.org.cn/plugins/maven-pmd-plugin/pmd-mojo.html)Create PMD site reports based on the rule set and configuration set in the plug-in. In addition to site reports, it can generate PMD output files in any of the following formats: XML, CSV, or TXT.
-   [pmd:aggregate-pmd](https://maven.org.cn/plugins/maven-pmd-plugin/aggregate-pmd-mojo.html)Depending on the set of rules set in the plugin and configured in**Aggregators**Create a PMD site report in the project. In addition to site reports, it can generate PMD output files in any of the following formats: XML, CSV, or TXT.
-   [pmd:aggregate-pmd-no-fork在](https://maven.org.cn/plugins/maven-pmd-plugin/aggregate-pmd-no-fork-mojo.html)**Aggregators**Create a PMD site report in your project without having to fork it againTest compilationStage.
-   [pmd:cpd](https://maven.org.cn/plugins/maven-pmd-plugin/cpd-mojo.html)Create a report for PMD’s Copy/Paste Detector (CPD) tool. It can also generate CPD result files in any of the following formats: XML, CSV, or TXT.
-   [pmd: aggregate-cpd](https://maven.org.cn/plugins/maven-pmd-plugin/aggregate-cpd-mojo)**Aggregators**Create a report for PMD’s Copy/Paste Detector (CPD) tool in the project. It can also generate CPD result files in any of the following formats: XML, CSV, or TXT.
-   If there are any PMD violations in the source code, then[pmd:check causes the build to fail.](https://maven.org.cn/plugins/maven-pmd-plugin/check-mojo.html)This target is automatically invoked before executing itselfpmd:pmd 。
-   If there are any PMD violations in the source code, then[pmd:aggregate-pmd-check](https://maven.org.cn/plugins/maven-pmd-plugin/aggregate-pmd-check-mojo.html)**Aggregators**The build in the project failed. This target is automatically invoked before executing itselfpmd:aggregate-pmd 。
-   If there are any CPD violations in the source code, then[pmd:cpd-check will make the build fail.](https://maven.org.cn/plugins/maven-pmd-plugin/cpd-check-mojo.html)This target is automatically invoked before executing itselfpmd:cpd 。
-   If there are any CPD violations in the source code, then[pmd:aggregate-cpd-check](https://maven.org.cn/plugins/maven-pmd-plugin/aggregate-cpd-check-mojo.html)**Aggregators**The build in the project failed. This target is automatically invoked before executing itselfpmd:aggregate-cpd 。

### 2. Code engineering

###### Purpose of the experiment

Use pmd to check if the code in your project is violated

###### The first method: Maven plugin integration
```xml
<?xml version="1.0" encoding="UTF-8"?>  
<project xmlns="http://maven.apache.org/POM/4.0.0"  
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">  
    <parent>  
        <artifactId>springboot-demo</artifactId>  
        <groupId>com.et</groupId>  
        <version>1.0-SNAPSHOT</version>  
    </parent>  
    <modelVersion>4.0.0</modelVersion>  
    <artifactId>pmd</artifactId>  
    <properties>  
        <maven.compiler.source>8</maven.compiler.source>  
        <maven.compiler.target>8</maven.compiler.target>  
        <pmd.version>3.15.0</pmd.version>  
    </properties>  
    <dependencies>  
        <dependency>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-starter-web</artifactId>  
        </dependency>  
        <dependency>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-autoconfigure</artifactId>  
        </dependency>  
        <dependency>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-starter-test</artifactId>  
            <scope>test</scope>  
        </dependency>  
  
    </dependencies>  
    <build>  
        <plugins>  
            <plugin>  
                <groupId>org.apache.maven.plugins</groupId>  
                <artifactId>maven-pmd-plugin</artifactId>  
                <version>${pmd.version}</version>  
                <configuration>  
                    <sourceEncoding>utf-8</sourceEncoding>  
                    <minimumTokens>100</minimumTokens>  
                    <targetJdk>${maven.compiler.target}</targetJdk>  
                    <excludes>  
                        <!--<exclude>**/*Bean.java</exclude>-->  
                        <!--<exclude>**/generated/*.java</exclude>-->  
                    </excludes>  
                    <excludeRoots>  
                        <!--<excludeRoot>target/generated-sources/stubs</excludeRoot>-->  
                    </excludeRoots>  
                    <rulesets>  
                        <ruleset>rulesets/java/quickstart.xml</ruleset>  
                    </rulesets>  
                    <outputDirectory>target/pmd-reports</outputDirectory>  
                </configuration>  
                <!--在clean后自动执行check-->  
                <!--<executions>-->  
                <!--<execution>-->  
                <!--<id>pmd-check</id>-->  
                <!--<phase>clean</phase>-->  
                <!--<goals>-->  
                <!--<goal>check</goal>-->  
                <!--</goals>-->  
                <!--</execution>-->  
                <!--</executions>-->  
            </plugin>  
        </plugins>  
    </build>  
</project>
```

###### The second method: the ideal plugin

Installation

![](https://miro.medium.com/v2/resize:fit:875/0*nU9BuCWJVlPoQqUv.png)

use

![](https://miro.medium.com/v2/resize:fit:875/0*abqDmpcJiYFgOGvb.png)

The above are just some of the key codes, all of which can be found in the repositories below

###### Code repositories

-   [https://github.com/Harries/springboot-demo](https://github.com/Harries/springboot-demo)

### 3. Testing

Run mvn pmd:check, and a detection report will be generated under target/pmd-reports/

![](https://miro.medium.com/v2/resize:fit:875/0*N1DCMvcqyLRhLB1M.png)

### 4. References

-   [https://maven.org.cn/plugins/maven-pmd-plugin](https://maven.org.cn/plugins/maven-pmd-plugin)
-   [http://www.liuhaihua.cn/archives/710665.html](http://www.liuhaihua.cn/archives/710665.html)
---

# Spring Boot integration jasypt quickstart demo

### 1. What is Jasypt?

Jasypt（Java Simplified Encryption）**is a tool focused on simplifying Java encryption operations**。 It provides a simple yet powerful way to handle the encryption and decryption of data, enabling developers to easily protect sensitive information in their applications, such as database passwords, API keys, and more. Jasypt is designed to simplify crypto operations and make it more developer-friendly.

### Jasypt encryption scenario

-   System Property
-   Envirnment Property
-   Command Line argument
-   Application.properties
-   Yaml properties
-   other custom property sources

### 2. Code engineering

### Objectives of the experiment

Experimental configuration file parameter encryption

### pom.xml
```xml
<?xml version="1.0" encoding="UTF-8"?>  
<project xmlns="http://maven.apache.org/POM/4.0.0"  
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">  
    <parent>  
        <artifactId>springboot-demo</artifactId>  
        <groupId>com.et</groupId>  
        <version>1.0-SNAPSHOT</version>  
    </parent>  
    <modelVersion>4.0.0</modelVersion>  
    <artifactId>jasypt</artifactId>  
    <properties>  
        <maven.compiler.source>8</maven.compiler.source>  
        <maven.compiler.target>8</maven.compiler.target>  
    </properties>  
    <dependencies>  
        <dependency>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-starter-web</artifactId>  
        </dependency>  
        <dependency>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-autoconfigure</artifactId>  
        </dependency>  
        <dependency>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-starter-test</artifactId>  
            <scope>test</scope>  
        </dependency>  
        <dependency>  
            <groupId>com.github.ulisesbocchio</groupId>  
            <artifactId>jasypt-spring-boot-starter</artifactId>  
            <version>2.1.1</version>  
        </dependency>  
    </dependencies>  
</project>
```
### controller

To obtain the encrypted username, the decrypted data should be obtained
```java
package com.et.jasypt.controller;  
import org.springframework.beans.factory.annotation.Value;  
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RestController;  
import java.util.HashMap;  
import java.util.Map;  

@RestController  
public class HelloWorldController {

    @Value("${username}")  
    private String username;  

    @RequestMapping("/hello")  
    public Map<String, Object> showHelloWorld(){  
        Map<String, Object> map = new HashMap<>();  
        map.put("msg", "HelloWorld");  
        map.put("username", username);  
        return map;  
    }  
}
```
### application.yaml

Jasypt provides a class specifically for encryption and decryption, which provides the main method, which is called as follows:
```shell
java -cp ./jasypt-1.9.3.jar org.jasypt.intf.cli.JasyptPBEStringEncryptionCLI password=pkslow algorithm=PBEWithMD5AndTripleDES input=larry
```
The output is:

----ENVIRONMENT-----------------  
Runtime: Oracle Corporation Java HotSpot(TM) 64-Bit Server VM 25.212-b10   
----ARGUMENTS-------------------  
input: larry  
algorithm: PBEWithMD5AndTripleDES  
password: pkslow  
----OUTPUT----------------------  
SUfiOs8MvmAUjg+oWl/6dQ==

A password profile, which is mostly used in the development environment
```yaml
server:  
  port: 8088  
username: ENC(SUfiOs8MvmAUjg+oWl/6dQ==)  
jasypt:  
  encryptor:  
    ###password: pkslow  
    algorithm: PBEWithMD5AndTripleDES
```
There is also a configuration of startup parameters in the multi-user production environment
```shell
java -jar -Djasypt.encryptor.password=pkslow xxx.jar
```
![](https://miro.medium.com/v2/resize:fit:875/0*l74bvzhmFzFMgumu.png)

### DemoApplication.java
```java
package com.et.jasypt;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;  
import org.springframework.boot.SpringApplication;  
import org.springframework.boot.autoconfigure.SpringBootApplication;  

@SpringBootApplication  
@EnableEncryptableProperties  
public class DemoApplication {  
   public static void main(String[] args) {  
      SpringApplication.run(DemoApplication.class, args);  
   }  
}
```

The above are just some of the key codes, all of which can be found in the repositories below

### Code repositories
-   https://github.com/Harries/springboot-demo

### 3. Testing

-   Start the Spring Boot application
-   Visit [http://127.0.0.1:8088/hello](http://127.0.0.1:8088/hello)
-   Returns plaintext data
-   {“msg”:”HelloWorld”,”username”:”larry”}
---

# Optimize Your Spring Boot Application with Dynamic Logging

**Ever spent hours debugging a weird issue that only happens in production?** In my previous project, we faced a similar challenge. We needed a way to turn on extra detailed logging (debug level) for specific parts of the code, but only when the application was running live. Restarting the entire system to enable debug logs wasn’t ideal.

This is where dynamic logging in Spring comes in. Imagine being able to adjust how much information your application logs, where it gets sent (appenders), and even how it’s formatted — all while the application is running! This makes troubleshooting and monitoring a breeze.

Spring Boot Actuator makes dynamic logging easy. It provides simple RESTful endpoints that let you control logging behavior on the fly. This not only saves you time managing complex logging configurations, but also empowers you to quickly adapt to changing situations. With dynamic logging, you can ensure your application runs smoothly and debug issues efficiently.

# Setting Up Demo app with Dynamic Logging

This section dives into building a simple Spring MVC application with dynamic logging capabilities. We’ll leverage Spring Boot Actuator to achieve this. Here’s a step-by-step breakdown:

**1. Project Setup:**

-   Create a new Maven project with your preferred IDE. or use [Spring Initializr](https://start.spring.io/) to create project
-   Add the following dependencies to your `pom.xml`:
```xml
        <dependency>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-starter-actuator</artifactId>  
        </dependency>  
        <dependency>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-starter-web</artifactId>  
        </dependency>
```
**2. Application Structure:**

-   Create a package named `dev.knowledgecafe.springlogging` to add your application code.
-   Inside this package, there will be two classes:
-   `HomeController.java`: This restcontroller class will handle the `/home` GET endpoint.
-   `SpringLoggingApplication.java`: This is your main application class.

**3. HomeController.java:**

This class has Get endpoint with different log lines and returns “Hello, World” string
```java
@RestController  
public class HomeController {  
  
    Logger logger = org.slf4j.LoggerFactory.getLogger(HomeController.class);  
  
    //Create get endpoint for home controller which returns string hello world  
    @GetMapping("/home")  
    public String home(){  
        logger.trace("This is a TRACE level message for demo purpose");  
        logger.debug("This is a DEBUG level message for demo purpose");  
        logger.info("This is an INFO level message for demo purpose");  
        logger.warn("This is a WARN level message for demo purpose");  
        logger.error("This is an ERROR level message for demo purpose");  
        return "Hello, World";  
    }  
}
```

4. Update application.properties file with following entries to enable Actuator endpoint and logging management
```shell
management.endpoints.web.exposure.include=loggers  
management.endpoint.loggers.enabled=true
```
Fully working code is committed to [GitHub for reference](https://github.com/amithimani/spring-logging).

Build your project using Maven and run the application using the generated executable JAR file or from `SpringLoggingApplication.java`.

### Testing Application

We can use browser or postman to test the application. I will explain it using postman.

1.  Send GET request on “/home” endpoint — Verify the response and check the logs on console, There will be Info, Warn and Error log will be printed because default log level is INFO.

2024-04-20T12:55:51.650+01:00  INFO 47987 --- [spring-loging] [nio-8080-exec-2] d.k.springlogging.HomeController         : This is an INFO level message for demo purpose  
2024-04-20T12:55:51.650+01:00  WARN 47987 --- [spring-loging] [nio-8080-exec-2] d.k.springlogging.HomeController         : This is a WARN level message for demo purpose  
2024-04-20T12:55:51.650+01:00 ERROR 47987 --- [spring-loging] [nio-8080-exec-2] d.k.springlogging.HomeController         : This is an ERROR level message for demo purpose

2. Update log level to trace for HomeController class using actuator endpoint.

![](https://miro.medium.com/v2/resize:fit:875/1*VeHXZierJbCckA1u2k-7Q.png)

We can verify logging level by hitting /actuator/loggers end point or looking at log after sending request to /home endpoint.

![](https://miro.medium.com/v2/resize:fit:875/1*TFFQOt1XLNbi9icKS1w29Q.png)

# Spring Boot Actuator: Security Considerations for Production

Spring Boot Actuator offers a powerful tool for monitoring and managing your application, but exposing these endpoints in production demands a security-conscious approach.

**1. Authentication and Authorization:**

-   **Never expose Actuator endpoints publicly.** Restrict access using mechanisms like Spring Security, OAuth, or IP whitelisting.
-   **Implement role-based access control (RBAC).** Grant access to specific endpoints only to authorized users with appropriate roles.

**2. Endpoint Exposure:**

-   **Minimize exposed endpoints.** Only enable endpoints you genuinely need for monitoring or management (e.g., `/health`, `/info`). Disable unnecessary ones to reduce attack surface.
-   **Consider a separate management port.** Isolate Actuator endpoints on a different port than your main application to further compartmentalize access.

**3. Sensitive Information Redaction:**

-   **Review endpoint behavior.** Certain endpoints might expose sensitive information by default (e.g., environment variables, bean details). Configure them to redact such information or disable them entirely if not crucial.
-   **Leverage property source encryption.** For sensitive configuration details in `application.properties`, explore encryption mechanisms like Jasypt to prevent unauthorized access.

**4. Monitoring and Logging:**

-   **Monitor Actuator endpoint access logs.** Identify any suspicious activity or unauthorized attempts.
-   **Implement security tools.** Utilize vulnerability scanners or penetration testing frameworks to proactively identify and address potential weaknesses in your Actuator configuration.

By following these security best practices, you can leverage the benefits of Spring Boot Actuator while safeguarding your application in a production environment.

### Summary

This blog post explored the power of dynamic logging in Spring MVC applications with Spring Boot Actuator. We saw how it empowers developers to fine-tune logging behavior on the fly, aiding in troubleshooting complex issues that might not occur locally. We then discussed crucial security considerations for production environments, emphasizing authentication, authorization, endpoint exposure, sensitive information redaction, and ongoing monitoring.
---
# Spring Boot — Redis Cache autoconfiguration and actuator/conditions

I wanted to disable Redis cache from my spring boot application, and towards that I commented out the redis connection host details. When I restarted the application, the startup failed saying it is unable to establish redis connection to `127.0.0.1`

This was happening due to Spring Boot auto configuration. How do I check if that is indeed the case?

Using actuator.

-   Added the dependency `implementation('org.springframework.boot:spring-boot-starter-actuator)` in build.gradle file.
-   Configured all endpoints in `application.yaml` file
```yml
management:  
  endpoints:  
    web:  
      base-path:  "/appname/v1/actuator"  
      exposure:  
         include: "*"
```
-   Accessed the actuator endpoint `/actuator/conditions` that would list the autoconfigurations that were done, and why they were done.

Sure enough, RedisCache had been autoconfigured as evidenced in the output of the GET call to `/actuator/conditions`

The output said that the RedisCacheConfiguration had been automatically configured. This was done due to two reasons

-   One the OnClassCondition was met for the class `org.springframework.data.redis.connection.RedisConnectionFactory`
-   Two, the CacheCondition was met as the cache configuration was set to be automatic

`Cache org.springframework.boot.autoconfigure.cache.RedisCacheConfiguration automatic cache type`
```json
{  
  "context" : {  
    "application" : {  
       "positiveMatches" : {  
          "RedisCacheConfiguration" : [  
              {  
                 "condition" : "OnClasscondition",  
                 "message" : "ConditionalOnClass found required class 'org.springframework.data.redis.connection.RedisConnectionFactory' "  
              },  
              {  
                  "condition": "CacheCondition",  
                  "message": "Cache org.springframework.boot.autoconfigure.cache.RedisCacheConfiguration automatic cache type"   
             }  
          ]  
    }  
}
```
---
# Generic Api Response and Global Exception Handling in Spring Boot

### Why Care About API Response?

-   **Improves client-side error handling**: Your frontend team will thank you.
-   **Enhances readability and maintainability**: Future you (or your team) will appreciate the clarity.
-   **Simplifies debugging and logging**: Spot issues quickly and efficiently.

Here’s an example `pom.xml` for Maven:
```xml
<dependencies>  
    <!-- Spring Boot Web for building REST APIs -->  
    <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-web</artifactId>  
    </dependency>  
  
    <!-- Spring Boot Starter Validation -->  
    <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-validation</artifactId>  
    </dependency>  
  
    <!-- H2 Database (for in-memory testing) -->  
    <dependency>  
        <groupId>com.h2database</groupId>  
        <artifactId>h2</artifactId>  
        <scope>runtime</scope>  
    </dependency>  
  
    <!-- Spring Boot Starter Data JPA (for database interactions) -->  
    <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-data-jpa</artifactId>  
    </dependency>  
  
    <!-- MySQL Driver (if using MySQL database) -->  
    <dependency>  
        <groupId>mysql</groupId>  
        <artifactId>mysql-connector-java</artifactId>  
        <scope>runtime</scope>  
    </dependency>  
  
    <!-- Spring Boot DevTools (for development convenience, optional) -->  
    <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-devtools</artifactId>  
        <scope>runtime</scope>  
    </dependency>  
  
    <!-- Spring Boot Test (for unit testing, optional) -->  
    <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-test</artifactId>  
        <scope>test</scope>
```
**MySQL Configuration** (for production or persistent storage):

### MySQL Database Configuration  
```shell
spring.datasource.url=jdbc:mysql://localhost:3306/yourdbname  
spring.datasource.username=root  
spring.datasource.password=yourpassword  
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver  
```
### JPA (Hibernate) Properties
```shell  
spring.jpa.hibernate.ddl-auto=update  ### Automatically creates/updates tables based on entities  
spring.jpa.show-sql=true  ### To print SQL queries for debugging  
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQL8Dialect
```
### 1. Create the `Employee` Entity

This is the basic employee model that we’ll use in our application.
```java
import javax.persistence.Entity;  
import javax.persistence.GeneratedValue;  
import javax.persistence.GenerationType;  
import javax.persistence.Id;  
import javax.validation.constraints.NotNull;  
  
@Entity  
public class Employee {  
  
    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    private Long id;  
  
    @NotNull  
    private String name;  
  
    @NotNull  
    private String department;  
  
    // Getters and Setters  
    public Long getId() {  
        return id;  
    }  
  
    public void setId(Long id) {  
        this.id = id;  
    }  
  
    public String getName() {  
        return name;  
    }  
  
    public void setName(String name) {  
        this.name = name;  
    }  
  
    public String getDepartment() {  
        return department;  
    }  
  
    public void setDepartment(String department) {  
        this.department = department;  
    }  
}
```
### 2. Define `ApiResponse<T>`
```java
package com.example.demo.response;  

import java.util.List;  
  
public class ApiResponse<T> {  
    private boolean success;  
    private String message;  
    private T data;  
    private List<String> errors;  
    private int errorCode;  
    private long timestamp;  
    private String path;  
  
    // Getters and Setters  
  
    public boolean isSuccess() {  
        return success;  
    }  
  
    public void setSuccess(boolean success) {  
        this.success = success;  
    }  
  
    public String getMessage() {  
        return message;  
    }  
  
    public void setMessage(String message) {  
        this.message = message;  
    }  
  
    public T getData() {  
        return data;  
    }  
  
    public void setData(T data) {  
        this.data = data;  
    }  
  
    public List<String> getErrors() {  
        return errors;  
    }  
  
    public void setErrors(List<String> errors) {  
        this.errors = errors;  
    }  
  
    public int getErrorCode() {  
        return errorCode;  
    }  
  
    public void setErrorCode(int errorCode) {  
        this.errorCode = errorCode;  
    }  
  
    public long getTimestamp() {  
        return timestamp;  
    }  
  
    public void setTimestamp(long timestamp) {  
        this.timestamp = timestamp;  
    }  
  
    public String getPath() {  
        return path;  
    }  
  
    public void setPath(String path) {  
        this.path = path;  
    }  
}
```
`ApiResponse<T>` is a generic class used to standardize the structure of responses (both success and error) in a Spring Boot application. The `T` represents the type of data that will be returned in the response, which makes the `ApiResponse` flexible enough to handle different types of data.

**Generic Type (**`**T**`**)**: This allows the response to include any type of data. For example, it could return an `Employee` object, a `List<Employee>`, or any other type.

**Fields in** `**ApiResponse<T>**`:

-   `success`: A `boolean` indicating whether the request was successful or not.
-   `message`: A `String` message that describes the result (e.g., "Employee found" or "Resource not found").
-   `data`: The actual response data of type `T` (can be an entity, a list, or any other object).
-   `errors`: A list of `String` errors that describe what went wrong if the request failed.
-   `errorCode`: An integer error code that can be used to classify different types of errors.
-   `timestamp`: A `long` representing the time the response was generated.
-   `path`: The URL path of the request, which helps in debugging.

### 3. Create Custom Exceptions

Here are two custom exceptions: `ResourceNotFoundException` and `ResponseNotFoundException`.
```java
package com.example.demo.exception;  
  
public class ResourceNotFoundException extends RuntimeException {  
    public ResourceNotFoundException(String message) {  
        super(message);  
    }  
}  
  
public class ResponseNotFoundException extends RuntimeException {  
    public ResponseNotFoundException(String message) {  
        super(message);  
    }  
}
```
### 4. Global Exception Handler

The `GlobalExceptionHandler` class handles different exceptions and returns an appropriate `ApiResponse<T>`.
```java
package com.example.demo.exception;  
  
import com.example.demo.response.ApiResponse;  
import com.example.demo.util.ResponseUtil;  
import org.springframework.http.HttpStatus;  
import org.springframework.web.bind.annotation.ExceptionHandler;  
import org.springframework.web.bind.annotation.RestControllerAdvice;  
  
import javax.servlet.http.HttpServletRequest;  
import java.util.Arrays;  
  
@RestControllerAdvice  
public class GlobalExceptionHandler {  
  
    @ExceptionHandler(Exception.class)  
    public ApiResponse<Object> handleGeneralException(Exception ex, HttpServletRequest request) {  
        return ResponseUtil.error(Arrays.asList(ex.getMessage()), "An unexpected error occurred", 1001, request.getRequestURI());  
    }  
  
    @ExceptionHandler(ResourceNotFoundException.class)  
    public ApiResponse<Object> handleResourceNotFoundException(ResourceNotFoundException ex, HttpServletRequest request) {  
        return ResponseUtil.error(Arrays.asList(ex.getMessage()), "Resource not found", 404, request.getRequestURI());  
    }  
  
    @ExceptionHandler(ResponseNotFoundException.class)  
    public ApiResponse<Object> handleResponseNotFoundException(ResponseNotFoundException ex, HttpServletRequest request) {  
        return ResponseUtil.error(Arrays.asList(ex.getMessage()), "Response data not found", 204, request.getRequestURI());  
    }  
}
```
### @RestControllerAdvice

`@RestControllerAdvice` is a specialized annotation in Spring Boot used for global exception handling. It combines the functionalities of `@ControllerAdvice` and `@ResponseBody`:

-   `**@ControllerAdvice**`: This annotation allows you to handle exceptions across multiple controllers. It's a centralized place where you can define how to handle specific exceptions thrown by any controller in your application.
-   `**@ResponseBody**`: This ensures that the returned data is automatically serialized into JSON or XML (based on the client's request) and sent as a response body.

`@RestControllerAdvice` is used to create a global exception handler that will return JSON or XML responses (instead of views or pages), making it ideal for REST APIs.

### `@ExceptionHandler`

`@ExceptionHandler` is an annotation used to define the method that handles specific exceptions. When an exception is thrown by a controller, Spring will look for a method annotated with `@ExceptionHandler` that matches the type of exception, and that method will handle the exception instead of the default behavior (e.g., showing a server error page).

-   `@ExceptionHandler(ResourceNotFoundException.class)` tells Spring that this method will handle `ResourceNotFoundException`.
-   When `ResourceNotFoundException` is thrown, this method returns an `ApiResponse` object with error details, instead of letting the exception propagate to the user as a default error page.

### How They Work Together

-   `@RestControllerAdvice` allows defining exception handling logic globally for all controllers.
-   `@ExceptionHandler` methods inside the `@RestControllerAdvice` class define how to handle specific exceptions like `ResourceNotFoundException`, `Exception`, etc.

This combination ensures that your application can consistently handle and format exceptions into JSON responses, improving error handling in RESTful services.

### 5. `ResponseUtil` Class

You provided this class, and it will help us generate standardized success or error responses.
```java
package com.example.demo.util;  
  
import com.example.demo.response.ApiResponse;  
  
import java.util.Arrays;  
import java.util.List;  
  
public class ResponseUtil {  
  
    public static <T> ApiResponse<T> success(T data, String message, String path) {  
        ApiResponse<T> response = new ApiResponse<>();  
        response.setSuccess(true);  
        response.setMessage(message);  
        response.setData(data);  
        response.setErrors(null);  
        response.setErrorCode(0); // No error  
        response.setTimestamp(System.currentTimeMillis());  
        response.setPath(path);  
        return response;  
    }  
  
    public static <T> ApiResponse<T> error(List<String> errors, String message, int errorCode, String path) {  
        ApiResponse<T> response = new ApiResponse<>();  
        response.setSuccess(false);  
        response.setMessage(message);  
        response.setData(null);  
        response.setErrors(errors);  
        response.setErrorCode(errorCode);  
        response.setTimestamp(System.currentTimeMillis());  
        response.setPath(path);  
        return response;  
    }  
  
    public static <T> ApiResponse<T> error(String error, String message, int errorCode, String path) {  
        return error(Arrays.asList(error), message, errorCode, path);  
    }  
}
```

The `ResponseUtil` class is a utility class used to simplify the process of creating consistent `ApiResponse<T>` objects in a Spring Boot application. It provides reusable methods for generating success and error responses, making the controller code more concise and standardized.

### Methods in `ResponseUtil`

1.  `**success(T data, String message, String path)**`:

**Parameters**:

-   `T data`: The actual data being returned (e.g., an `Employee` object).
-   `String message`: A message that describes the result (e.g., "Employee found").
-   `String path`: The request URL path, useful for debugging.

**Returns**: A successful `ApiResponse<T>` object.

**2. error(List<String> errors, String message, int errorCode, String path)**

**Parameters**:

-   `List<String> errors`: A list of error messages explaining what went wrong.
-   `String message`: A message describing the overall error (e.g., "Resource not found").
-   `int errorCode`: An error code for further classification (e.g., `404` for "not found").
-   `String path`: The request URL path where the error occurred.

**Returns**: An `ApiResponse<T>` object containing the error details.

`**3. error(String error, String message, int errorCode, String path)**`:

**Parameters**:

-   `String error`: A single error message.
-   `String message`: The error message.
-   `int errorCode`: The error code (e.g., `404`).
-   `String path`: The request URL path where the error occurred.

**Returns**: An `ApiResponse<T>` object containing the error details.

### 6. Employee Controller

Here’s an example controller to test the different exceptions and return the `ApiResponse<T>`.
```java
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.http.ResponseEntity;  
import org.springframework.web.bind.annotation.*;  
  
@RestController  
@RequestMapping("/api/employees")  
public class EmployeeController {  
  
    @Autowired  
    private EmployeeService employeeService;  
  
    @PutMapping("/{id}")  
    public ResponseEntity<ApiResponse<Employee>> updateEmployee(  
            @PathVariable Long id,  
            @RequestBody Employee employee,  
            HttpServletRequest request) {  
        Employee updatedEmployee = employeeService.updateEmployee(id, employee);  
        return ResponseEntity.ok(ResponseUtil.success(updatedEmployee, "Employee updated successfully", request.getRequestURI()));  
    }  
}
```

**7. Write a Service Layer  
**The service layer will contain the business logic for updating an employee:
```java
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.stereotype.Service;  
import javax.transaction.Transactional;  
import java.util.Optional;  
  
@Service  
public class EmployeeService {  
  
    @Autowired  
    private EmployeeRepository employeeRepository;  
  
    @Transactional  
    public Employee updateEmployee(Long id, Employee updatedEmployee) {  
        Optional<Employee> existingEmployeeOptional = employeeRepository.findById(id);  
          
        if (existingEmployeeOptional.isPresent()) {  
            Employee existingEmployee = existingEmployeeOptional.get();  
            existingEmployee.setName(updatedEmployee.getName());  
            existingEmployee.setDepartment(updatedEmployee.getDepartment());  
            return employeeRepository.save(existingEmployee);  
        } else {  
            throw new ResourceNotFoundException("Employee not found with id " + id);  
        }  
    }  
}
```

**8. Create a Repository Interface**  
Create an interface for data access operations:
```java
import org.springframework.data.jpa.repository.JpaRepository;  
import org.springframework.stereotype.Repository;  
  
@Repository  
public interface EmployeeRepository extends JpaRepository<Employee, Long> {  
}
```

### 9. Application Entry Point

The main application class.
```java
package com.example.demo;  
  
import org.springframework.boot.SpringApplication;  
import org.springframework.boot.autoconfigure.SpringBootApplication;  
  
@SpringBootApplication  
public class DemoApplication {  
    public static void main(String[] args) {  
        SpringApplication.run(DemoApplication.class, args);  
    }  
}
```

**Sample SQL Schema**

// Create the Employee Table  
```sql  
CREATE TABLE Employee (  
    id BIGINT AUTOINCREMENT PRIMARY KEY,  
    name VARCHAR(100) NOT NULL,  
    department VARCHAR(100) NOT NULL  
);  

-- Insert Sample Records  
  
INSERT INTO Employee (name, department) VALUES ('John Doe', 'Engineering');  
INSERT INTO Employee (name, department) VALUES ('Jane Smith', 'Marketing');  
INSERT INTO Employee (name, department) VALUES ('Emily Johnson', 'Sales');  
```
---
# Stop Writing Your Own Code — Use These Java Libraries Instead

Let’s admit it: we’ve all reinvented the wheel at some point.

-   Manually parsing JSON
-   Crafting object mappers line by line
-   Manually creating a Utility for String Handling
-   Manually creating a Utility for Date Handling
-   Manually creating a Utility for Collections Handling
-   Writing custom HTTP clients
-   Coding retry logic from scratch
-   Handling nulls manually
-   Logging with `System.out.println()`

But in 2025, there’s no excuse.

> Java has evolved. The ecosystem has matured. Libraries are battle-tested. And now, modern Java features like **records**, **HttpClient**, **new String methods**, and **Optional** make it easier than ever to write clean, concise code — without doing everything yourself.

In this article, we’ll show you 15 things you should stop building from scratch — and which **modern Java tools and libraries** to use instead.

### ❌ 1. Writing Your Own JSON Parser

✅ Use: **Jackson** or **Gson**

If you’re still building JSON with string concatenation, stop now.

Use Jackson to write and read the JSON:
```java
ObjectMapper mapper = new ObjectMapper();  
String json = mapper.writeValueAsString(new Product("Laptop", 899.99));
```
Or, to read:
```java
Product product = mapper.readValue(json, Product.class);
```
✅ Jackson supports:

-   Records (Java 14+)
-   Optional fields
-   Date/time support
-   Custom serializers

💡 Modern Tip: Use `@JsonInclude`, `@JsonProperty` and Java Records for clean JSON mapping.

### ❌ 2. Manually Mapping Entities to DTOs

✅ Use: **MapStruct**

Writing this is a productivity killer:
```java
ProductDTO dto = new ProductDTO(product.getId(), product.getName());
```
Instead, use MapStruct:
```java
@Mapper  
public interface ProductMapper {  
    ProductDTO toDto(Product product);  
}
```

### ❌ 3. Building Custom HTTP Clients

✅ Use: **Java 11+ HttpClient**

In the past, we needed OkHttp or Apache HttpClient. But now?
```java
HttpClient client = HttpClient.newHttpClient();  
HttpRequest request = HttpRequest.newBuilder()  
    .uri(URI.create("https://api.example.com/data"))  
    .build();  
  
HttpResponse<String> response = client.send(request, BodyHandlers.ofString());  
System.out.println(response.body());
```
✅ Built-in, non-blocking, supports async and HTTP/2.  
✅ No external library needed for 80% of use cases.

### ❌ 4. Writing Getters, Setters, Equals, HashCode

✅ Use: **Lombok** or **Java Records**

Still writing boilerplate? Use Lombok:
```java
@Data  
public class User {  
    private Long id;  
    private String name;  
}
```
Or just switch to **records**:
```java
public record User(Long id, String name) {}
```
✅ Java Records are immutable, concise, and perfect for DTOs.

### ❌ 5. Writing Your Own Retry Logic

✅ Use: **Resilience4j**

Stop doing this:
```java
for (int i = 0; i < 3; i++) {  
    try {  
        callApi();  
        break;  
    } catch (Exception ignored) {}  
}
```
Use this instead:
```java
Retry retry = Retry.ofDefaults("backend");  
Supplier<String> supplier = Retry.decorateSupplier(retry, () -> api.call());  
String result = Try.ofSupplier(supplier).get();
```
✅ Includes backoff, circuit breaker, rate limiter, fallback.  
🔧 Production-ready resilience.

### ❌ 6. Logging with `System.out.println()`

✅ Use: **SLF4J + Logback** or **Log4j2**
```java
private static final Logger log = LoggerFactory.getLogger(MyApp.class);  
log.info("Starting application...");
```
✅ Structured logs, levels, log files, and integrations with ELK/Grafana.

💡 Bonus: Use parameterized logs to avoid string concatenation:
```java
log.info("User {} logged in", username);
```

### ❌ 7. Writing String Utilities

✅ Use: **Apache Commons Lang**
```java
StringUtils.isBlank("   "); // true  
StringUtils.capitalize("java"); // Java
```
✅ Includes DateUtils, ArrayUtils, NumberUtils — save time and reduce bugs.

### ❌ 8. Creating Fake Data for Testing

✅ Use: **Java Faker** or **Datafaker**
```java
Faker faker = new Faker();  
String email = faker.internet().emailAddress();  
String name = faker.name().fullName();
```
✅ Great for tests, demos, or DB seeding.

### ❌ 9. Building Your Own Date/Time Helpers

✅ Use: **java.time** (Java 8+)
```java
LocalDate date = LocalDate.now();  
String iso = date.format(DateTimeFormatter.ISODATE);
```
✅ Use `Period`, `Duration`, `ZonedDateTime`, `ChronoUnit` — all built-in.

💡 Bonus: No more `Date`/`Calendar` bugs or timezone nightmares.

### ❌ 10. Rolling Your Own Database Migrations

✅ Use: **Flyway** or **Liquibase**

Version-controlled migrations:

src/main/resources/db/migration  
  ├── V1createusers.sql  
  ├── V2addemailcolumn.sql

Then run:
```shell
mvn flyway:migrate
```
✅ Auto-applies changes across all environments, CI/CD friendly.

### ❌ 11. Manually Handling Null Checks

✅ Use: **Optional**
```java
Optional<User> userOpt = repository.findById(id);  
userOpt.map(User::getEmail).ifPresent(this::sendEmail);
```
✅ No `NullPointerException`. Express intent clearly.

### ❌ 12. Manually Writing Validation Logic

✅ Use: **Hibernate Validator (JSR 380)**
```java
public record SignupRequest(  
    @NotNull @Email String email,  
    @NotBlank String password  
) {}
```
Add to controller:
```java
@PostMapping("/signup")  
public ResponseEntity<?> signup(@Valid @RequestBody SignupRequest request) {  
    // already validated!  
}
```
✅ Cleaner input validation, integrates with Spring Boot out of the box.

### ❌ 13. Writing Manual CSV Parsers

✅ Use: **OpenCSV**
```java
CSVReader reader = new CSVReader(new FileReader("users.csv"));  
List<String[]> records = reader.readAll();
```
✅ Also supports bean mapping:
```java
ColumnPositionMappingStrategy<User> strategy = new ColumnPositionMappingStrategy<>();  
strategy.setType(User.class);
```
### ❌ 14. Managing Object Pools Yourself

✅ Use: **Apache Commons Pool2**

If you build expensive resources (like FTP connections or parsers), use object pools.
```java
GenericObjectPool<MyExpensiveService> pool = new GenericObjectPool<>(new MyFactory());  
MyExpensiveService service = pool.borrowObject();
```
✅ Handles lifecycle, errors, and efficient reuse.

### ❌ 15. Implementing Your Own Dependency Injection

Manually wiring dependencies makes your codebase harder to maintain, test, and scale.

### ✅ Use Spring Core for Dependency Injection

Add the **Spring Core** dependency to your `pom.xml`:

<!-- https://mvnrepository.com/artifact/org.springframework/spring-core -->  
```xml
<dependency>  
    <groupId>org.springframework</groupId>  
    <artifactId>spring-core</artifactId>  
    <version>6.2.6</version>  
</dependency>
```
### ✅ Embrace Clean Dependency Injection with Spring

Let Spring manage object creation and wiring through annotations:
```java
@Service  
public class OrderService {  
  
    private final PaymentService paymentService;  
  
    // Constructor injection  
    public OrderService(PaymentService paymentService) {  
        this.paymentService = paymentService;  
    }  
}
```
### 🌟 Benefits:

-   ✅ **Constructor-based injection** (recommended)
-   ✅ **Lifecycle management** (no manual `new`)
-   ✅ **Profiles & environment support**
-   ✅ **Loose coupling for better testing & scalability**

✅ **Tip:** Use annotations like `@Component`, `@Service`, `@Repository`, and `@Autowired` to fully leverage Spring's dependency injection features.

Modern Java isn’t about writing everything yourself — it’s about knowing where to plug in the right tool.

These libraries:

-   Save you time
-   Reduce bugs
-   Are tested in production
-   Let you focus on business logic, not plumbing
---

# Spring Boot Dynamic Bean Switching: A Complete Guide

### Dynamic Bean Switching in Spring Boot: A Complete Guide

Dynamic Bean Switching is a powerful pattern in Spring Boot that allows applications to switch between different bean implementations at runtime based on various conditions. This technique is particularly useful for creating flexible, configurable applications that can adapt their behavior without code changes or application restarts.

![](https://miro.medium.com/v2/resize:fit:875/1*KEK1XIiGd-pNWORM5uMdQ.png)

### Lets move on how Dynamic Bean Switching works

Dynamic Bean Switching enables your application to choose between multiple implementations of the same interface based on runtime conditions such as:

-   Configuration properties
-   Environment variables
-   User preferences
-   Business logic conditions
-   External system availability

### Core Approaches to Dynamic Bean Switching

**I. Using @ConditionalOnProperty**

The simplest approach uses Spring’s conditional annotations to register beans based on application properties.
```java
// Common interface  
public interface PaymentProcessor {  
    void processPayment(double amount);  
}  
  
// Bkash implementation  
@Component  
@ConditionalOnProperty(name = "payment.provider", havingValue = "bkash")  
public class BkashPaymentProcessor implements PaymentProcessor {  
    @Override  
    public void processPayment(double amount) {  
        System.out.println("Processing $" + amount + " payment via Bkash");  
        // Bkash-specific logic  
    }  
}  
  
// PayPal implementation  
@Component  
@ConditionalOnProperty(name = "payment.provider", havingValue = "paypal")  
public class PayPalPaymentProcessor implements PaymentProcessor {  
    @Override  
    public void processPayment(double amount) {  
        System.out.println("Processing $" + amount + " payment via PayPal");  
        // PayPal-specific logic  
    }  
}  
  
// Default implementation  
@Component  
@ConditionalOnProperty(name = "payment.provider", havingValue = "default", matchIfMissing = true)  
public class DefaultPaymentProcessor implements PaymentProcessor {  
    @Override  
    public void processPayment(double amount) {  
        System.out.println("Processing $" + amount + " payment via default processor");  
    }  
}
```
Configuration in `application.properties`:
```shell
payment.provider=bkash
```
### II. Using Factory Pattern with Application Context

For more dynamic switching, create a factory that can select implementations at runtime:
```java
@Component  
public class PaymentProcessorFactory {  
      
    private final ApplicationContext applicationContext;  
      
    public PaymentProcessorFactory(ApplicationContext applicationContext) {  
        this.applicationContext = applicationContext;  
    }  
      
    public PaymentProcessor getProcessor(String processorType) {  
        switch (processorType.toLowerCase()) {  
            case "Bkash":  
                return applicationContext.getBean(BkashPaymentProcessor.class);  
            case "paypal":  
                return applicationContext.getBean(PayPalPaymentProcessor.class);  
            default:  
                return applicationContext.getBean(DefaultPaymentProcessor.class);  
        }  
    }  
}  
  
@Service  
public class PaymentService {  
      
    private final PaymentProcessorFactory processorFactory;  
      
    public PaymentService(PaymentProcessorFactory processorFactory) {  
        this.processorFactory = processorFactory;  
    }  
      
    public void processPayment(double amount, String processorType) {  
        PaymentProcessor processor = processorFactory.getProcessor(processorType);  
        processor.processPayment(amount);  
    }  
}
```
### III. Using Strategy Pattern with Map-based Registry

This is more elegant approach uses a map-based registry for automatic discovery:
```java
Public interface NotificationService {  
    void sendNotification(String message);  
    String getType();  
}  
  
@Component  
public class EmailNotificationService implements NotificationService {  
    @Override  
    public void sendNotification(String message) {  
        System.out.println("Sending email: " + message);  
    }  
      
    @Override  
    public String getType() {  
        return "email";  
    }  
}  
  
@Component  
public class SmsNotificationService implements NotificationService {  
    @Override  
    public void sendNotification(String message) {  
        System.out.println("Sending SMS: " + message);  
    }  
      
    @Override  
    public String getType() {  
        return "sms";  
    }  
}  
  
@Component  
public class SlackNotificationService implements NotificationService {  
    @Override  
    public void sendNotification(String message) {  
        System.out.println("Sending Slack message: " + message);  
    }  
      
    @Override  
    public String getType() {  
        return "slack";  
    }  
}  
  
@Component  
public class NotificationServiceRegistry {  
      
    private final Map<String, NotificationService> services;  
      
    public NotificationServiceRegistry(List<NotificationService> notificationServices) {  
        this.services = notificationServices.stream()  
            .collect(Collectors.toMap(  
                NotificationService::getType,  
                service -> service  
            ));  
    }  
      
    public NotificationService getService(String type) {  
        NotificationService service = services.get(type);  
        if (service == null) {  
            throw new IllegalArgumentException("Unknown notification type: " + type);  
        }  
        return service;  
    }  
      
    public Set<String> getAvailableTypes() {  
        return services.keySet();  
    }  
}
```
### IV. Configuration-Driven Dynamic Switching

Now It’s time to Create a configuration class that manages dynamic switching based on properties:
```java
@ConfigurationProperties(prefix = "app.features")  
@Data  
public class FeatureConfiguration {  
    private String database = "mysql";  
    private String cache = "redis";  
    private String messaging = "rabbitmq";  
    private boolean useAdvancedLogging = false;  
}  
  
@Configuration  
@EnableConfigurationProperties(FeatureConfiguration.class)  
public class DynamicBeanConfiguration {  
      
    @Bean  
    @ConditionalOnProperty(name = "app.features.database", havingValue = "mysql")  
    public DatabaseService mysqlDatabaseService() {  
        return new MySqlDatabaseService();  
    }  
      
    @Bean  
    @ConditionalOnProperty(name = "app.features.database", havingValue = "postgresql")  
    public DatabaseService postgresqlDatabaseService() {  
        return new PostgreSqlDatabaseService();  
    }  
      
    @Bean  
    @ConditionalOnProperty(name = "app.features.cache", havingValue = "redis")  
    public CacheService redisCacheService() {  
        return new RedisCacheService();  
    }  
      
    @Bean  
    @ConditionalOnProperty(name = "app.features.cache", havingValue = "hazelcast")  
    public CacheService hazelcastCacheService() {  
        return new HazelcastCacheService();  
    }  
}
```
### V. Runtime Bean Switching with Bean Factory

For truly dynamic switching, manipulate the bean registry at runtime:
```java
@Component  
public class DynamicBeanSwitcher {  
      
    private final ConfigurableApplicationContext applicationContext;  
    private final DefaultListableBeanFactory beanFactory;  
      
    public DynamicBeanSwitcher(ConfigurableApplicationContext applicationContext) {  
        this.applicationContext = applicationContext;  
        this.beanFactory = (DefaultListableBeanFactory) applicationContext.getBeanFactory();  
    }  
      
    public void switchImplementation(String beanName, Object newImplementation) {  
        // Remove existing bean if it exists  
        if (beanFactory.containsBean(beanName)) {  
            beanFactory.destroySingleton(beanName);  
        }  
          
        // Register new implementation  
        beanFactory.registerSingleton(beanName, newImplementation);  
          
        System.out.println("Switched bean '" + beanName + "' to new implementation: "   
                         + newImplementation.getClass().getSimpleName());  
    }  
}  
  
@RestController  
@RequestMapping("/api/admin")  
public class AdminController {  
      
    private final DynamicBeanSwitcher beanSwitcher;  
      
    public AdminController(DynamicBeanSwitcher beanSwitcher) {  
        this.beanSwitcher = beanSwitcher;  
    }  
      
    @PostMapping("/switch-payment-provider/{provider}")  
    public ResponseEntity<String> switchPaymentProvider(@PathVariable String provider) {  
        PaymentProcessor newProcessor;  
          
        switch (provider.toLowerCase()) {  
            case "bkash":  
                newProcessor = new BkashPaymentProcessor();  
                break;  
            case "paypal":  
                newProcessor = new PayPalPaymentProcessor();  
                break;  
            default:  
                newProcessor = new DefaultPaymentProcessor();  
        }  
          
        beanSwitcher.switchImplementation("paymentProcessor", newProcessor);  
        return ResponseEntity.ok("Payment provider switched to: " + provider);  
    }  
}
```
### Advanced Example: Multi-Tenant Bean Switching

Here’s a comprehensive example for multi-tenant applications:
```java
@Component  
public class TenantContext {  
    private static final ThreadLocal<String> currentTenant = new ThreadLocal<>();  
      
    public static void setCurrentTenant(String tenant) {  
        currentTenant.set(tenant);  
    }  
      
    public static String getCurrentTenant() {  
        return currentTenant.get();  
    }  
      
    public static void clear() {  
        currentTenant.remove();  
    }  
}  
  
public interface TenantConfigurationService {  
    String getDatabaseUrl();  
    String getCacheConfig();  
    Map<String, String> getCustomSettings();  
}  
  
@Component  
public class TenantConfigurationRegistry {  
      
    private final Map<String, TenantConfigurationService> tenantConfigs = new HashMap<>();  
      
    @PostConstruct  
    public void initializeTenantConfigs() {  
        // Initialize configurations for different tenants  
        tenantConfigs.put("tenant1", new Tenant1ConfigurationService());  
        tenantConfigs.put("tenant2", new Tenant2ConfigurationService());  
        tenantConfigs.put("default", new DefaultTenantConfigurationService());  
    }  
      
    public TenantConfigurationService getConfigurationForCurrentTenant() {  
        String tenant = TenantContext.getCurrentTenant();  
        return tenantConfigs.getOrDefault(tenant, tenantConfigs.get("default"));  
    }  
}  
  
@Component  
public class DynamicDataSourceProvider {  
      
    private final TenantConfigurationRegistry configRegistry;  
    private final Map<String, DataSource> dataSources = new ConcurrentHashMap<>();  
      
    public DynamicDataSourceProvider(TenantConfigurationRegistry configRegistry) {  
        this.configRegistry = configRegistry;  
    }  
      
    public DataSource getDataSource() {  
        String tenant = TenantContext.getCurrentTenant();  
        return dataSources.computeIfAbsent(tenant, this::createDataSource);  
    }  
      
    private DataSource createDataSource(String tenant) {  
        TenantConfigurationService config = configRegistry.getConfigurationForCurrentTenant();  
        HikariConfig hikariConfig = new HikariConfig();  
        hikariConfig.setJdbcUrl(config.getDatabaseUrl());  
        // Configure other datasource properties  
        return new HikariDataSource(hikariConfig);  
    }  
}
```
Some Best Practices

### Use Proper Abstraction

Always define clear interfaces and avoid tight coupling between switching logic and implementations.

### Handle Errors Gracefully
```java
@Component  
public class SafeNotificationService {  
      
    private final NotificationServiceRegistry registry;  
      
    public SafeNotificationService(NotificationServiceRegistry registry) {  
        this.registry = registry;  
    }  
      
    public void sendNotification(String message, String type) {  
        try {  
            NotificationService service = registry.getService(type);  
            service.sendNotification(message);  
        } catch (IllegalArgumentException e) {  
            // Fall back to default service  
            registry.getService("email").sendNotification(message);  
        }  
    }  
}
```
### Consider Performance Implications

Cache frequently accessed beans and avoid creating new instances unnecessarily.

### **Use Configuration Validation**
```java
@Component  
@Validated  
public class PaymentConfiguration {  
      
    @Value("${payment.provider}")  
    @Pattern(regexp = "bkash|paypal|default", message = "Invalid payment provider")  
    private String provider;  
      
    // Getters and setters  
}
```
Testing Dynamic Bean Switching
```java
@SpringBootTest  
@TestPropertySource(properties = "payment.provider=bkash")  
class DynamicBeanSwitchingTest {  
      
    @Autowired  
    private PaymentProcessor paymentProcessor;  
      
    @Test  
    void shouldInjectBkashProcessor() {  
        assertThat(paymentProcessor).isInstanceOf(BkashPaymentProcessor.class);  
    }  
}  
  
@SpringBootTest  
class PaymentServiceTest {  
      
    @MockBean  
    private PaymentProcessorFactory processorFactory;  
      
    @Autowired  
    private PaymentService paymentService;  
      
    @Test  
    void shouldSwitchProcessorsDynamically() {  
        PaymentProcessor mockProcessor = mock(PaymentProcessor.class);  
        when(processorFactory.getProcessor("bkash")).thenReturn(mockProcessor);  
          
        paymentService.processPayment(100.0, "bkash");  
          
        verify(mockProcessor).processPayment(100.0);  
    }  
}
```

### Common Pitfalls and Solutions

### 1. Bean Scope Issues

Be careful with singleton vs prototype scopes when switching beans dynamically.

### 2. Circular Dependencies

Avoid circular dependencies by using proper dependency injection patterns.

### 3. Thread Safety

Ensure thread safety when switching beans in multi-threaded environments.

### 4. Memory Leaks

Properly clean up resources when switching implementations, especially for beans that hold expensive resources.

### Conclusion

Dynamic Bean Switching in Spring Boot provides powerful flexibility for creating adaptable applications. Whether you choose conditional annotations, factory patterns, or runtime manipulation, the key is to maintain clean abstractions and handle edge cases properly. This pattern is particularly valuable in microservices architectures, multi-tenant applications, and systems that need to adapt to different environments or business requirements without downtime.

---

### Keystore & Truststore Mysteries:Why Do Companies Heavily Rely on Keystore & Truststore? 

Keystores and Truststores are widely used in **companies** for securing communication, authentication, and encryption. Businesses handle sensitive data, and without proper security mechanisms, they risk data breaches, unauthorized access, and cyberattacks.

Think of **Keystore** and **Truststore** as two different security safes in a bank, each serving a different purpose when dealing with digital certificates.

### Analogy: Bank and Security Vaults

Imagine you are running a **bank** where customers want to deposit their valuables and access services securely.

**Keystore (Your Personal Vault in the Bank)**

-   This is like your **personal locker** inside the bank where you keep your important documents (like your passport or property papers).
-   It stores **your private key** (used to sign transactions) and **your public certificates** (used to prove your identity).
-   Just like your bank locker has a **key** to open it, the **Keystore is protected by a password**.

**Truststore (Bank’s Trusted List of Authorities)**

-   This is like the **bank’s official list of trusted notaries** or officials who are allowed to verify documents.
-   It contains **certificates of external parties (public keys)** that you trust.
-   When a customer brings a document notarized by someone, the bank verifies if the notary is on the **trusted list** before accepting it.

### Example: Mutual Authentication Between Two Servers

Let’s say two servers, **Client** and **Server**, want to communicate securely.

**Server’s Keystore (Server’s Personal Vault)**

-   The server stores its own certificate and private key in a **Keystore** (like keeping its own identity documents in a locker).
-   When a client connects, the server provides its certificate to prove its identity.

**Client’s Truststore (Client’s List of Trusted Certificates)**

-   The client checks if the server’s certificate is in its **Truststore** (like checking if the bank trusts the notary).
-   If the certificate is trusted, the client allows the connection.

**Client’s Keystore (If Mutual Authentication is Needed)**

-   If the server also wants to verify the client’s identity, the client provides its own certificate from its **Keystore**.

**Server’s Truststore (Verifying Client’s Certificate)**

-   The server checks the client’s certificate against its **Truststore** before allowing access.

### How Password Authentication Works with Keystore/Truststore

-   **Keystore Password**: Unlocks the keystore to access the private key.
-   **Truststore Password**: Protects access to the list of trusted certificates.
-   **Key Password**: Even if you access the keystore, an additional password may be needed to use the private key.

### Real-World Java Example

In a **Spring Boot application using SSL/TLS**, we configure the keystore and truststore like this:
```shell
server.ssl.key-store=classpath:server-keystore.jks  
server.ssl.key-store-password=changeit  
server.ssl.trust-store=classpath:server-truststore.jks  
server.ssl.trust-store-password=changeit
```
This ensures:

-   The server presents its certificate from the keystore.
-   The client verifies it against the truststore before allowing communication.

### Securing Communication (SSL/TLS for HTTPS & Microservices)

**Why?** To prevent hackers from intercepting data during transmission.

**How?**

-   A **Keystore** is used by servers to store SSL certificates (to prove identity).
-   A **Truststore** is used by clients (or other microservices) to verify if they trust the server’s certificate.

**Example:** In a banking app, the backend APIs are secured using **TLS**, ensuring that customer data is encrypted and safe from attackers.

### Enabling Mutual Authentication (Zero Trust Security)

![](https://miro.medium.com/v2/resize:fit:849/1*FWljM6SorKwH3_z2RgYngQ.png)

**Why?** So that **both** the client and server verify each other’s identity before sharing sensitive data.

**How?**

-   The **server** stores its own certificate in a **Keystore** and verifies client certificates using a **Truststore**.
-   The **client** does the same, ensuring a two-way secure connection.

**Example:** In **B2B API integrations**, a payment gateway authenticates an e-commerce platform before allowing transactions.

### Protecting Sensitive Data (Encryption & Digital Signatures)

**Why?** To ensure that data at rest and in transit is **not tampered with** or stolen.

**How?**

-   **Private keys** stored in a **Keystore** are used for encrypting/decrypting sensitive data.
-   **Truststores** verify the authenticity of digital signatures.

**Example:** In **healthcare applications**, patient records are encrypted before storage, preventing unauthorized access.

### Enterprise-Grade Security Compliance (SOC2, ISO 27001, HIPAA, GDPR)

**Why?** Many industries **legally require** companies to use secure authentication.

**How?**

-   **Keystores** and **Truststores** help businesses comply with industry regulations by ensuring encrypted, authenticated communication.

**Example:** A **cloud-based document storage service** must use SSL certificates stored in a Keystore to comply with **GDPR (EU data privacy laws)**.

### Securing Internal Microservices (Service-to-Service Authentication)

**Why?** To prevent unauthorized access inside **distributed systems**.

**How?**

-   Internal microservices use **mTLS (Mutual TLS)**, requiring both parties to verify each other’s certificates using Keystores and Truststores.

**Example:** A **ride-hailing app (like Uber)** secures communication between its **Payment Service** and **Booking Service** using Keystore and Truststore.

### Cloud Security & Kubernetes (Secrets Management)

**Why?**

Cloud deployments require **secure key storage** and **certificate-based authentication**.

**How?**

-   **Keystores** securely store credentials and encryption keys in **AWS Secrets Manager, Kubernetes Secrets, or HashiCorp Vault**.

**Example:** A company running **Spring Boot microservices on AWS EKS** stores SSL certificates in a Keystore and loads them dynamically during startup.

### Conclusion: Why Companies Use It?

Protects **sensitive customer data**  
Prevents **MITM (Man-in-the-Middle) attacks**  
Ensures **regulatory compliance**  
Enables **secure microservice communication**  
Strengthens **authentication and encryption**

**Without Keystores & Truststores, companies risk security breaches, non-compliance fines, and loss of customer trust!**

Hope you all liked the content. Clap if you like this and follow me for more interesting content .It will be great if you show your love and encouragement :)

Meet you all with my next article soon.

Meanwhile, keep reading my other articles too :)  
[https://medium.com/@letslearnnow/list/reading-list](https://medium.com/@letslearnnow/list/reading-list)

---
# Spring Boot - Change logging level at runtime, Spring Boot using Actuator and Custom APIs.

![](https://miro.medium.com/v2/resize:fit:875/1*Mg7GIZu3faObRI7qzwVmw.jpeg)
Change logging level dynamically in Java spring boot Application | Image by Author created using Bing Copilot

**L**ogging is a crucial feature for any application. On production environments, it helps in debugging, monitoring, and troubleshooting issues efficiently at runtime. In this case, you are setting a fixed log level in your `application.properties` file — it may not always be ideal. In the worst situation, what if you need to change the login levels dynamically at runtime, and you cannot restart your running application? What will be your strategy?

In this article, we are going to take a deep dive into two approaches for changing log levels dynamically.

1.  **Spring Boot Actuator (Inbuilt support)**
2.  **Create a Custom REST API Endpoint**

At the end of this article, you will have a clear, full proof working understanding of how to modify logging levels when the Spring Boot application is running, and without restarting it, you can change logging levels dynamically.

### Why Change Log Level Dynamically in Spring Boot Application?

### **1. Production Monitoring —**

You just need to adjust log levels dynamically in your live environment without restarting the server.

### **2. Quick Debugging and Better Troubleshooting —**

You can enable `TRACE` or `Debug` level only when you are required to find an issue with an already running live environment.

> **Always remember — If it is working, don’t touch it**

### **3. Security and Compliance —**

You can modify logging settings to capture only necessary information without exposing sensitive data or information.

### **4. Performance Optimization —**

Due to debug or trace logging, all your requests and responses will be captured, including all handshake requests and their certificate information if you are using HTTPS. You must avoid excessive logging, which might slow down the performance of the application.

### Method 1. Changing Log Levels Using Spring Boot Actuator

Spring Boot actuators provide an inbuilt way to modify logging levels through `/actuator/loggers` endpoint.

### Step 1: First, Add the Spring Boot Actuator Dependency

To use Actuator, add the following dependency in your `pom.xml` (for Maven users):
```xml
<dependency>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-starter-actuator</artifactId>  
</dependency>
```
For **Gradle** users,
```java
implementation 'org.springframework.boot:spring-boot-starter-actuator'
```
### Step 2: Enable Loggers Endpoint in Application Properties

By default, the `/actuator/loggers` endpoint is disabled in the spring boot application. You need to enable it in using your `application.properties`. Enable it using the below line,
```shell
management.endpoints.web.exposure.include=loggers
```
In case, if you are using `application.yml`:
```yml
management:  
  endpoints:  
    web:  
      exposure:  
        include: loggers
```
### Step 3: Use Actuator to Modify Log Levels

So now, you can dynamically change the logging level by making an API call to below given link:

**Check the Current Logging Level:**
```shell
GET /actuator/loggers
```
It will return a list of all loggers and their current levels.

**Modify Log Level**

If you want to make changes to your logging level dynamically, use a `POST` request in the below manner:
```shell
POST /actuator/loggers/com.example.demo  
Content-Type: application/json

{  
"configuredLevel": "DEBUG"  
}
```

This will set the logging level of `com.example.demo` to `DEBUG` at runtime.

### Step 4: Secure the Actuator Endpoint (Optional but Recommended)

As per security concerns and compliances, if you are exposing the `/actuator/loggers` endpoint without security, your application might be risky. You can secure it using **Spring Security** by modifying `application.properties`:
```shell
management.endpoints.web.exposure.include=loggers  
management.endpoint.loggers.enabled=true  
management.security.enabled=true
```
Just make sure security liabilities are addressed and ensure that only authenticated users can modify log levels. Others (Unauthorized users) cannot see your information.

### Method 2: Creating a Custom REST API for Log Level Modification

If you are new to actuators, but don’t want to use them? — You should try out this custom traditional approach by creating a custom API to dynamically change the log levels.

### Step 1: Create a Controller for Log Level Changes

In the traditional approach, we usually follow the Controller, Services, and Dao Layers approach. In the same manner, you can also create your customer endpoint as given below.
```java
import org.slf4j.LoggerFactory;  
import org.springframework.web.bind.annotation.*;  
import ch.qos.logback.classic.Level;  
import ch.qos.logback.classic.Logger;  
import org.springframework.http.ResponseEntity;  
  
@RestController  
@RequestMapping("/logs")  
public class LogLevelController {  
    @PostMapping("/{loggerName}/{level}")  
    public ResponseEntity<String> changeLogLevel(@PathVariable String loggerName, @PathVariable String level) {  
        Logger logger = (Logger) LoggerFactory.getLogger(loggerName);  
        Level newLevel = Level.toLevel(level.toUpperCase(), Level.INFO);  
        logger.setLevel(newLevel);  
        return ResponseEntity.ok("Log level changed for " + loggerName + " to " + newLevel);  
    }  
}
```
### Step 2: Use the Custom API to Change Log Levels

When you need to modify the log level dynamically, make the following API request with POST method:
```shell
POST /logs/com.example.demo/DEBUG
```
This will set the logging level of `com.example.demo` to `DEBUG`.

Bingo 👏👏👏

**You did a great job, isn’t it so easy?!**

### Comparison: Actuator vs. Custom API Endpoints

![](https://miro.medium.com/v2/resize:fit:875/1*Lkal6bPPqw0UU1aDdx7wA.png)
Which one you should use? — Actuator vs. Custom API Endpoints | Image by Author created in MS Word file

### Best Practices for Managing Logging Levels

-   **Use** `**INFO**` **or** `**WARN**` **in production:** You must avoid the use of `TRACE` and `DEBUG` log levels in production unless it is necessary.
-   **Log rotations:** By choosing the correct loggers for your production, test, or development environments, you can prevent log files from growing indefinitely.
-   **Secure the logging endpoint:** Unauthorized users cannot change your application’s log level without permission. Securing your custom endpoint is very necessary.
-   **Monitor logs in real-time:** By using cloud-based log management tools from AWS, Datadog, or Cloud Watch, etc.
-   **Use structured logging:** You can use tools like ELK Stack (Elasticsearch, Logstash, and Kibana) to help in better log analysis.

### Wrapping Up…

When we want to change logging levels is necessary to run production environments, so developers can debug and monitor the issues smoothly.

Using the below given 3 steps, you can change log levels dynamically in your Spring Boot application.

1.  **Spring Boot Actuator** is the easiest and most secure way to manage logging levels.
2.  A **custom REST API Endpoint** provides more flexibility if an Actuator is not an option.
3.  Always follow best practices to ensure logging security and efficiency.

Using the above simple implementation techniques, you can optimize your logging strategy for better performance, monitoring, and debugging in production or other environments.

### **FAQ — Frequently Asked Questions**

**1. Can I change the root logging level dynamically?**  
Yes, using Actuator: `POST /actuator/loggers/root` with `{ "configuredLevel": "INFO" }` you can change the root logging level dynamically.

**2. Does changing the logging level persist after a restart?**  
No, the changes are runtime only. To persist changes, You need to update your `application.properties`.

**3. Can I modify the logging levels of third-party libraries?**  
Yes, specify the package name, e.g., `org.springframework` instead of `com.example.demo`.
---


# ❇️REST API Naming Conventions 

> When building RESTful APIs, your endpoints are your product’s **language**. Clear naming isn’t just about aesthetics — it’s about **developer experience**, **maintainability**, and **future-proofing** your systems.

In this guide, we’ll break down naming best practices and give real-world examples you can copy (or steal with pride).

### 🧱 The Golden Rule: Treat Your API Like a Resource-Based Interface

REST stands for **REpresentational State Transfer**. That means we’re not calling actions — we’re accessing **resources**.

### ✅ DO:

GET /users/123

### ❌ DON’T:

GET /getUserById?id=123

### 🔖 1. Use Nouns, Not Verbs

You’re interacting with things, not calling methods.

![](https://miro.medium.com/v2/resize:fit:875/1*Jmyf90QtiqA9RxpMKxkGFg.png)

> Let the HTTP method define the action. The URL is just the **noun**.

### 📦 2. Use Plural Nouns for Collections

REST is designed around collections and individual resources.

![](https://miro.medium.com/v2/resize:fit:875/1*w1xU4J3u-nhnGA8kq4wJyw.png)

> Plurals reflect that the endpoint is a collection. `GET /user` feels like it’ll give you one—maybe randomly.

### 🌲 3. Use Sub-Resources for Hierarchical Data

When a resource belongs to another, nest it.

![](https://miro.medium.com/v2/resize:fit:875/1*1iwzVzcRZjLvaUeNSE3bg.png)

This is especially useful for:

-   Comments on articles
-   Orders from customers
-   Reviews on products

> Think of your URL as a breadcrumb trail.

### 🧭 4. Use Query Parameters for Filtering, Sorting, and Pagination

Let the path represent the resource. Let the **query string** handle refinement.

![](https://miro.medium.com/v2/resize:fit:875/1*WbE5MnwQTTaj2KPH6VVvRA.png)

> Query parameters = **filters**, not **commands**.

### 🔁 5. Avoid CRUD Verbs in URL Paths

The method already says what you’re doing.

![](https://miro.medium.com/v2/resize:fit:875/1*zWDf5GL-qhN4nGWMOfTPYQ.png)

### 🛡️ 6. Use Consistent Naming Across Endpoints

Pick a convention and stick to it:

-   Snake case? `userid`
-   Camel case? `userId`
-   Kebab case? `user-id`

### 🔥 Pro Tip:

Use **kebab-case** in URLs (`/user-posts`)  
Use **camelCase** in JSON keys (`userId`, `createdAt`)

### ⚠️ 7. Avoid Deep Nesting

While nesting is good, too much of it is a nightmare.

### ❌ Don’t do this:

GET /users/42/orders/7/items/12/reviews/3

It’s hard to read and tightly couples your API to your data model.

### 📌 Bonus: Action-Oriented Endpoints (Sometimes Okay)

For **non-resource** actions (e.g., authentication), it’s okay to bend the rules:

![](https://miro.medium.com/v2/resize:fit:875/1*3IdbEYQa8zZutGmasGDQ.png)

### 💬 Example REST API Structure

GET    /users  
POST   /users  
GET    /users/{id}  
PUT    /users/{id}  
DELETE /users/{id}  
GET    /users/{id}/orders  
POST   /users/{id}/orders  
GET    /products  
GET    /products/{id}

> This is **RESTful**, scalable, and predictable.

### 🧠 Conclusion

![](https://miro.medium.com/v2/resize:fit:875/1*PNSq12rHkdbzcKMnuxdrPA.png)

### 👨‍💻 Final Thought

REST APIs aren’t just for machines — they’re for **developers**. Your naming decisions affect onboarding, documentation, and debug time.

> Great APIs are invisible. Bad APIs become tech debt.

If you want to design APIs your team won’t hate six months from now — start with clean naming.

# 🚀 Structured Logging in Spring Boot: Make Your Logs Work for You

**Logs are the first place developers look when something goes wrong.** But more often than not, those logs are a tangled mess of human-readable strings, impossible to filter and even harder to analyze.

That’s where **structured logging** comes in.

In this article, you’ll learn how to implement structured logging in a Spring Boot application using practical examples. By the end, you’ll be able to turn messy text logs into structured, queryable JSON logs enriched with metadata like user ID, request path, execution time, and even trace IDs.

### 📘 What Is Structured Logging?

Traditional logs might look like this:

bash2024-06-13 10:22:45.123 INFO 2345 --- [  main] com.example.DemoApplication : App started

This is fine for human eyes but **terrible for machines**. You can’t easily filter by user ID or error code. Searching requires regex gymnastics.

Now look at a **structured JSON log**:
```json
{  
  "timestamp": "2024-06-13T10:22:45.123",  
  "level": "INFO",  
  "logger": "com.example.DemoApplication",  
  "thread": "main",  
  "message": "App started",  
  "userId": "alice",  
  "codePath": "web"  
}
```
This format is **machine-readable** and enables powerful filtering, monitoring, and alerting in tools like Kibana, Datadog, or Loki.

### 🧰 Setting Up Structured Logging in Spring Boot

### Step 1: Add Dependencies

For JSON output, we’ll use **Logback** with the `logstash-logback-encoder`.

**Maven:**
```xml
<dependency>  
  <groupId>net.logstash.logback</groupId>  
  <artifactId>logstash-logback-encoder</artifactId>  
  <version>7.4</version>  
</dependency>
```
### Step 2: Configure Logback

Create or update your `logback-spring.xml`:
```xml
<configuration>  
  <include resource="org/springframework/boot/logging/logback/defaults.xml" />  
  
  <appender name="JSON_CONSOLE" class="net.logstash.logback.appender.LoggingEventCompositeJsonEncoder">  
    <encoder class="net.logstash.logback.encoder.LogstashEncoder">  
      <includeMdcKeyName>userId</includeMdcKeyName>  
      <includeMdcKeyName>codePath</includeMdcKeyName>  
      <includeMdcKeyName>traceId</includeMdcKeyName>  
    </encoder>  
  </appender>  
  
  <root level="INFO">  
    <appender-ref ref="JSON_CONSOLE" />  
  </root>  
  
</configuration>
```
This tells Logback to output structured JSON to the console and include custom MDC (Mapped Diagnostic Context) fields like `userId`.

### 💡 Add Contextual Metadata to Logs

### ✅ Example 1: Add User ID to Logs

Use a Spring interceptor to inject user information:
```java
public class LoggingInterceptor implements HandlerInterceptor {  
  
    @Override  
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {  
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();  
        String username = (principal instanceof UserDetails)  
            ? ((UserDetails) principal).getUsername()  
            : principal.toString();  
        MDC.put("userId", username);  
        return true;  
    }  
  
    @Override  
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {  
        MDC.remove("userId");  
    }  
}
```

Register it:
```java
@Configuration  
public class WebConfig implements WebMvcConfigurer {  
    @Override  
    public void addInterceptors(InterceptorRegistry registry) {  
        registry.addInterceptor(new LoggingInterceptor());  
    }  
}
```
### ✅ Example 2: Identify the Code Path

Add `codePath` to differentiate between UI calls, APIs, and background jobs:
```java
MDC.put("codePath", "api");
```
For scheduled tasks:
```java
@Scheduled(fixedRate = 60000)  
public void syncJob() {  
    MDC.put("codePath", "job");  
    logger.info("Running scheduled job");  
    MDC.remove("codePath");  
}
```
### ✅ Example 3: Capture Execution Time

Measure how long expensive operations take:
```java
Instant start = Instant.now();  
// perform operation  
Duration duration = Duration.between(start, Instant.now());  
MDC.put("durationMs", String.valueOf(duration.toMillis()));  
logger.info("External call finished");  
MDC.remove("durationMs");
```
### ✅ Example 4: Log Root Cause of Exceptions

Use `@ControllerAdvice` to capture the root cause:
```java
@ControllerAdvice  
public class GlobalExceptionHandler {  
  
    @ExceptionHandler(Exception.class)  
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)  
    public void handleAll(Exception ex) {  
        MDC.put("rootCause", getRootCause(ex).getClass().getSimpleName());  
        logger.error("Unhandled exception", ex);  
        MDC.remove("rootCause");  
    }  
  
    private Throwable getRootCause(Throwable throwable) {  
        Throwable cause = throwable;  
        while (cause.getCause() != null) {  
            cause = cause.getCause();  
        }  
        return cause;  
    }  
}
```
### 🌐 Bonus: Distributed Tracing with Sleuth

To track logs across services, use **Spring Cloud Sleuth**:
```xml
<dependency>  
  <groupId>org.springframework.cloud</groupId>  
  <artifactId>spring-cloud-starter-sleuth</artifactId>  
</dependency>
```
Sleuth automatically adds `traceId` and `spanId` to MDC, making logs traceable across microservices.

### 🧪 Sample JSON Log Output

Here’s what a structured log might look like:
```json
{  
  "timestamp": "2024-06-13T10:30:45.200",  
  "level": "INFO",  
  "logger": "com.example.UserController",  
  "message": "User login successful",  
  "userId": "alice",  
  "codePath": "web",  
  "traceId": "a1b2c3d4e5f6"  
}
```
Now your logs are **filterable, traceable, and ready for automation**.

### ✅ Wrapping Up

Structured logging gives you **clarity, context, and control**. It turns logs from a mess of text into a goldmine of insights.

Here’s a quick recap of what you learned:

-   ✅ Use `logstash-logback-encoder` for JSON logging
-   ✅ Enrich logs with MDC fields like `userId`, `codePath`, and `traceId`
-   ✅ Automatically capture performance and root causes
-   ✅ Integrate with tools like Sleuth for distributed tracing

🎯 Whether you’re running a monolith or a fleet of microservices, **structured logging is a must-have** for modern observability.

Thank you for your patience in reading this article! If you found this article helpful, please give it a clap 👏, bookmark it ⭐, and share it with friends in need and **follow** for more Spring Boot insights. Your support is my biggest motivation to continue to output technical insights!

# Liquibase Tutorial. Spring boot application with Liquibase

### Introduction:

Sometimes we need to create a database and put fake data inside it, when running the application, we can do it manually using **SQL command**, but this way is very traditional, so we will use **Liquibase Technology** to do it.

### What is Liquibase in general?

**Liquibase** is an open-source database-independent library for tracking, managing and applying database schema changes.

Liquibase enables you to go faster and automate your processes by tracking, versioning and deploying database changes.

### **How does it work?**

After running your application **Liquibase** will create two tables inside your Database, the first one called `DataBaseChangeLog` & `DataBaseChangeLogLock` each of these tables has its own work, and **Liquibase** uses it to handle its work.

-   `DataBaseChangeLog` : This table will be tracking ChangeSet and whos author of this file and what is the Id of this file, and where is the location of the file.

The following image represent this table with information about ChangeSet

![](https://miro.medium.com/v2/resize:fit:875/1*9uChiF3R94ll2PN1e6Rx0Q.png)

-   `DataBaseChangeLogLock` : Which will ensure that only one instance of Liquibase is running at a time so that no conflict will happen during the migration.

The following image represents this table with information about the table

![](https://miro.medium.com/v2/resize:fit:875/1*bUHiZr9kji7TilNJ-dqwg.png)

### How to set it up?

-   we need to add the following **dependency** inside the **POM.xml** file

> I use version **4.16.1** with **Liquibase** which is the latest version.
```xml
<!-- [https://mvnrepository.com/artifact/org.liquibase/liquibase-core](https://mvnrepository.com/artifact/org.liquibase/liquibase-core) -->  
<dependency>  
    <groupId>org.liquibase</groupId>  
    <artifactId>liquibase-core</artifactId>  
    <version>{{liquibase.verion}}</version>  
</dependency><!-- [https://mvnrepository.com/artifact/org.liquibase/liquibase-maven-plugin](https://mvnrepository.com/artifact/org.liquibase/liquibase-maven-plugin) -->  
<dependency>  
    <groupId>org.liquibase</groupId>  
    <artifactId>liquibase-maven-plugin</artifactId>  
    <version>{{liquibase.verion}}</version>  
</dependency>

-   we need to add the following **plugin** inside the **POM.xml** file

<plugin>  
   <groupId>org.liquibase</groupId>  
   <artifactId>liquibase-maven-plugin</artifactId>     
   <version>${liquibase.version}</version>  
   <configuration>      
      <propertyFile>${liquibase.propertyFile}</propertyFile>  
      <promptOnNonLocalDatabase>false</promptOnNonLocalDatabase>      
   </configuration>  
</plugin>
```
`${liquibase.propertyFile}` : We will replace it with liquibase properties file path like the following image.

![](https://miro.medium.com/v2/resize:fit:875/1*9opQnFODj7kb80rAUv3LZA.png)

-   We need to fill data inside liquibase.properties the common path to define this folder inside the resource file in your project.

In this file, we will define information about the database.

`username` `databaseUrl` `password` `changeLog file location` and now let’s fill the data
```shell
url=${your urlPath}  
username=$${your username}  
password=${your password}  
driver=${your data base driver} eg: org.postgresql.Driver  
changeLogFiles= ${your change log file path} cahngelogmaster path
```
### ChangeLog Vs ChangeSet In liquibase

> **To create a changeLog and changeSet we need to know what is the meaning of these files.**

-   **changeLog**

The change log is a YAML file, we write inside it, how we want to run the liquibase environment.and how we want to order our SQL files at run time

**cahnageLog.yaml structures**
```yml
databaseChangeLog:  
  - include:  
      file: src/main/resources/db/changelog/0001/changelog.yaml
```
-   **changeSet**

The chnageLog files will run cahngeSet file, the cahnge set can be a `sql` `xml` `json` and run the query using changeLog file.

**cahngeSet structures:**
```sql
--liquibase formatted sql  
--changeset author:idCREATE TABLE ...INSERT QUERY ... etc ....-- rollback DROP TABLE ...;
```
**Like the above structures**

-   In the first line, we need to define the syntax for the changeset file.
-   In the second line, we need to define who is the author.
-   After that, we will write syntax like the above example.
-   Finally, we will write a rollback query.

### How we can use the changelog and changeSet files together?

In the first step and to organize our application I will create a folder in the resource folder called DB.

Now we need to create file called a `changelog-master.yaml`

-   `changelog-master.yaml` : It is a master **cahngeLog** file. the content in it, all of the logs operators sequentially running. using it we can run **changeLog** or **changeSet** file.

for example `changelog-master.yaml`:
```yml
databaseChangeLog:  
  - include:  
      file: src/main/resources/db/changelog/0001/changelog.yaml
```
> **And now we will create another package called 0001, and we will create files inside it.**

-   the first file called **cahngelog.yaml**:

It is a cahgneLog file for the `0001` package and it is a master for the `0001 package` .

It will call SQL files using this sequentially.
```yml
databaseChangeLog:  
  - include:  
      file: src/main/resources/db/changelog/0001/createUserTable.sql  
  - include:  
      file: src/main/resources/db/changelog/0001/insertUsers.sql
```
-   The second file called `**createUserTable.Sql**`
```sql
--liquibase formatted sql  
--changeset abed:0001-01  
CREATE TABLE IF NOT EXISTS usertb (id integer PRIMARY KEY AUTOINCREMENT,  
firstname VARCHAR(255),  
lastname VARCHAR(255),  
mobilenumber VARCHAR(255)  
);-- rollback DROP TABLE usertb;

--liquibase formatted sql  
--changeset abed:0001-02  
  
INSERT INTO usertb  
(  
 firstname,  
 lastname,  
 mobilenumber  
)  
VALUES  
    ('USERFIRSTA','USERLASTA','99625541'),  
    ('USERFIRSTB','USERLASTB','99625511'),  
    ('USERFIRSTC','USERLASTC','99625555');  
  
-- rollback DELETE FROM product WHERE firstname IN ('USERFIRSTA', 'USERFIRSTB', 'USERFIRSTC');
```
And we need to update **application.yml** and add the following command to allow liquibase when running your application.
```yml
spring:  
  liquibase:  
    enabled: true  
    drop-first: true  
    change-log: classpath:db/changelog/changelog-master.yml  
    default-schema: public
```
https://github.com/abdalrhmanAlkraien/Liquibase-and-springboot

### Organizing changesets by feature

The way I usually organise the `changesets` is by creating a folder for each new feature, with the folder being identified by a feature id, that way each feature will have its own `changelog` file.

![](https://miro.medium.com/v2/resize:fit:696/1*15rWegw1N4LUIX8fywILw.png)

### conclusion:

Sometimes we need to initial test data or some column inside the database, for saving your time you can use **liquibase** to do it, after preparing your changeLog and changeSet.


# SQL Performance Tuning. 


SQL performance tuning is a process of optimizing SQL queries to ensure they execute as fast as possible. There are many factors that affect the performance of SQL queries, such as the number of tables queried, the size and number of columns in tables, and indexes on tables.

SQL is a critical component of many database systems and is a well-known language for querying, updating and managing data.  
SQL performance tuning is an important topic to master as it can help with scalability and speed of queries.

In this post, we will cover different ways SQL tuning.

All of us always wants a fast response on the data retrieval process. So we need to design a good database that provides best performance during data manipulation which results into the best performance of an application.

However, there is no straightforward way to define the best performance but we can choose multiple ways to improving SQL query performance, which falls under various categories like creation of Indexes, usage of joins, and rewrite a subquery to use JOIN, etc.

As a developer, we know any SQL query can be written in multiple ways but we should follow best practices/ techniques to achieve better query performance.

Some of them are highlighted below :

1.  Use EXISTS instead of IN to check existence of data.  
    1. Avoid * in SELECT statement. Give the name of columns which you require.  
    2. Choose appropriate Data Type. E.g. To store strings use varchar in place of text data type. Use text data type, whenever you need to store large data (more than 8000 characters).  
    3. Avoid nchar and nvarchar if possible since both the data types takes just double memory as char and varchar.  
    4. Avoid NULL in fixed-length field. In case of requirement of NULL, use variable-length (varchar) field that takes less space for NULL.  
    5. Avoid Having Clause. Having clause is required if you further wish to filter the result of an aggregations.  
    6. Create Clustered and Non-Clustered Indexes.  
    7. Keep clustered index small since the fields used in clustered index may also used in non-clustered index.  
    8. Most selective columns should be placed leftmost in the key of a non-clustered index.  
    9.  Drop unused Indexes.  
    10. Better to create indexes on columns that have integer values instead of characters. Integer values use less overhead than character values.  
    11. Use joins instead of sub-queries.  
    12. Use WHERE expressions to limit the size of result tables that are created with joins.  
    13. Use TABLOCKX while inserting into a table and TABLOCK while merging.  
    14. Use WITH (NOLOCK) while querying the data from any table.  
    15. Use SET NOCOUNT ON and use TRY- CATCH to avoid deadlock condition.  
    16. Avoid Cursors since cursor are very slow in performance.  
    17. Use Table variable in place of Temp table. Use of Temp tables required interaction with TempDb database which is a time taking task.  
    18. Use UNION ALL in place of UNION if possible.  
    19. Use Schema name before SQL objects name.  
    21. Use Stored Procedure for frequently used data and more complex queries.  
    22. Keep transaction as small as possible since transaction lock the processing tables data and may results into deadlocks.  
    23. Avoid prefix “sp” with user defined stored procedure name because SQL server first search the user defined procedure in the master database and after that in the current session database.  
    24. Avoid use of Non-correlated Scalar Sub Query. Use this query as a separate query instead of part of the main query and store the output in a variable, which can be referred to in the main query or later part of the batch.  
    25. Avoid Multi-statement Table Valued Functions (TVFs). Multi-statement TVFs are more costly than inline TVFs.  
      
    As we have seen above , In SQL Server , there are several steps you can take to improve the performance of your queries and database as a whole. There are many steps that will be applicable for other RDBMS as well like ORACLE.

Here are some general tips for performance tuning in Oracle SQL:

1.  Use EXPLAIN PLAN or AUTOTRACE to analyze the execution plan of your queries and identify any issues with the way they are being executed.
2.  Use the INDEX hint to specify which index should be used by the optimizer for a particular query.
3.  Consider using hints such as FULL or INDEXFFS to force the optimizer to use a full table scan or an index fast full scan, respectively.
4.  Use the OPTIMIZERMODE hint to specify a particular optimization mode for a query.
5.  Consider using materialized views to pre-calculate and store frequently-accessed data, which can improve the performance of queries that access that data.
6.  Use the DBMSSTATS package to analyze and gather statistics about your database and its objects, which can help the optimizer make more informed decisions when creating execution plans.
7.  Consider using partitioning to break large tables into smaller, more manageable pieces, which can improve the performance of queries that access those tables.
8.  Use the SQL Tuning Advisor to identify and fix any potential performance issues with your SQL statements.
9.  These are just a few of the many techniques you can use to improve the performance of your Oracle SQL queries and database. It’s important to keep in mind that the specific steps you’ll need to take will depend on your specific database and workload.
10.  It’s always a good idea to consult with a database administrator or other experts if you’re having performance issues.


# Performance Testing with Apache Bench

Have you just started making APIs ? Do you wonder if your API will be able to handle thousands of request concurrently ? Well you can make sure with [Apache](https://httpd.apache.org/docs/2.4/programs/ab.html)Bench. It helps to test our APIs with different load settings just to make sure your API has what it takes.

We are going to assume you’ve installed ab on your system. To make sure just type man ab on your Mac/Linux terminal and it should throw it manuals on the screen. For the tech stack I would be using :-

-   **NodeJs** with **expressJS**.
-   **Postgres** as our database.
-   **Postman** to make sure APIs are working fine.
-   **ApacheBench.**

We would be using a [DVD rental](https://www.dropbox.com/s/920bvej7tto45r8/dvdrental.tar?dl=0) store data, I got it in the Udemy course “[The complete SQL Bootcamp](https://www.udemy.com/the-complete-sql-bootcamp/)”. So let’s get started.

######### **Setting Up the Project**

The whole project will be available on my [github](https://github.com/Pkfication/dvd-rental). So let set up node, express and pg. I am using [express generator](https://expressjs.com/en/starter/generator.html) to get a boilerplate code. Just follow the guidelines there and whenever you are ready install the other dependency like pg. Here are the list of commands I used. Make sure you are in the right directory.
```shell
express --view=jade --css=sass --gitnpm installnpm install pg --save
```
Lets check if everything is up and running with the following command.

npm start

It starts the dev server on localhost:3000, If you navigate to this address, you should see this.

![](https://miro.medium.com/v2/resize:fit:875/1*oCaIdZsNxkkT6guGBCYJyA.png)

After initial setup, we have to build API endpoints, we will only be making a couple of them but we will do it right. Writing endpoints is an art, once you know the standards, it’s hard to not follow it, your heart won’t agree to do anything else. I follow [Vinay Sahni](https://www.vinaysahni.com/best-practices-for-a-pragmatic-restful-api) as my guide for pragmatic restful API. I will be writing more on API endpoints in some other article. Brace yourselves, AB is finally here.

######### Simple Load Test

I have made two endpoints :

1. /films  
2. /films/:id

Lets start the server using ‘npm start’, it should start on localhost:3000. Use postman to check if the endpoints are working fine, if not then refer to my repository.

Let do our stress test.
```shell
$ ab -n 1000 -c 100 localhost:3000/filmsBenchmarking localhost (be patient)  
```
Completed 100 requests  
Completed 200 requests  
Completed 300 requests  
Completed 400 requests  
Completed 500 requests  
Completed 600 requests  
Completed 700 requests  
Completed 800 requests  
Completed 900 requests  
Completed 1000 requests  
Finished 1000 requestsServer Software:  
Server Hostname:        localhost  
Server Port:            3000Document Path:          /film  
Document Length:        1232 bytesConcurrency Level:      100  
Time taken for tests:   5.142 seconds  
Complete requests:      1000  
Failed requests:        0  
Non-2xx responses:      1000  
Total transferred:      1442000 bytes  
HTML transferred:       1232000 bytes  
**Requests per second:    194.48 [#########/sec] (mean)**  
Time per request:       514.182 [ms] (mean)  
Time per request:       5.142 [ms] (mean, across all concurrent requests)  
Transfer rate:          273.87 [Kbytes/sec] receivedConnection Times (ms)  
              min  mean[+/-sd] median   max  
Connect:        0    1   1.4      0       7  
Processing:    56  432  74.2    429     656  
Waiting:       55  432  74.1    429     656  
Total:         63  433  73.6    429     657Percentage of the requests served within a certain time (ms)  
  50%    429  
  66%    458  
  75%    466  
  80%    472  
  90%    511  
  95%    558  
  98%    606  
  99%    631  
 100%    657 (longest request)

After running the command you’ll get to see this screen. The first and easiest thing to understand is the Requests per second which is 194.48/sec for 100 users making 1000 requests. Let us break down the command.

-c: ("Concurrency"). Indicates how many clients (people/users) will be hitting the site at the same time. While ab runs, there will be -c clients hitting the site. This is what actually decides the amount of stress your site will suffer during the benchmark.-n: Indicates how many requests are going to be made. This just decides the length of the benchmark. A high -n value with a -c value that your server can support is a good idea to ensure that things don't break under sustained stress: it's not the same to support stress for 5 seconds than for 5 hours.

You can use ab on your website to see what your server is capable of. ApacheBench is a very basic tool but gives you a good idea about the performance. It is not a good idea to rely completely on this for production.

It’s a really cool tool to get you started on stress testing. I hope this helps you to add something to your arsenal. If you like to learn more follow these amazing resources:

-   [ApacheBench documentations.](https://httpd.apache.org/docs/2.4/programs/ab.html)
-   [Stackoverflow discussion on ApacheBench.](https://stackoverflow.com/questions/12732182/ab-load-testing)

---
# Spring Boot Custom Annotation Localization from Database

Localization and internationalization are concepts related to adapting software applications to different languages, regions, and cultural preferences to make them accessible and usable by people around the world.

Internationalization (often abbreviated as “i18n”) is the process of designing and developing software applications in a way that allows for easy adaptation to different languages, regions, and cultures without requiring code changes. It involves separating the user interface (UI) text, messages, and other localizable elements from the application’s code and storing them in resource files or databases. This enables the application to be easily translated and localized for different target audiences.

Localization (often abbreviated as “l10n”) is the process of adapting a software application that has been internationalized to a specific language, region, or culture. It involves translating the text, messages, labels, and other UI elements into the target language, as well as adjusting the application’s behavior and appearance to suit the cultural norms and preferences of the target audience. This may include formatting dates, numbers, currencies, and other locale-specific information correctly, as well as considering factors such as language direction (left-to-right or right-to-left), character encoding, and localized content.

Localization typically involves working with translators and linguists who are proficient in the target language and have an understanding of the target culture. They translate the text and adapt the application’s content to ensure it is linguistically and culturally appropriate for the target audience.

To implement localization with a custom annotation in Spring Boot, we can follow these step-by-step instructions:

Step 1: Create a Custom Annotation  
Create a custom annotation to mark the fields that require localization. For example, let’s create a `@I18NProperty` annotation:
```java
@Target(ElementType.FIELD)  
@Retention(RetentionPolicy.RUNTIME)  
public @interface I18NProperty {  
   /**  
    * id to find the translation  
    */  
   String fieldId() default "id";  
   /**  
    * type of translate  
    */  
   String type();  
     
   String locale() default "";  
}
```
Step 2: Create a Interface  
A provider interface specifies a set of methods that must be implemented by a service provider in order to provide a specific functionality. It defines the contract or API that the provider must adhere to, without specifying the actual implementation details.now we greate a Interface with some parameters to query from database to get message from the specific locale. For example, let’s create a I18NProvider Interface:
```java
public interface I18NProvider {  
    String getMessage(String key, String type, String locale, String defaultMessage);  
}
```
Step 3: Create a extends class of StdSerializer  
To serialize to JSON, we need to create a custom serializer using `StdSerializer`, and extend the class and implement the `serialize()` method. This method defines how Java object should be serialized to JSON. we can customize the serialization process according to our specific requirements.

Here’s an example of how you can create a custom serializer by extending `StdSerializer`:
```java
@Slf4j  
public class I18NSerializer extends StdSerializer<Object> {  
    private static final long serialVersionUID = -2391442805192997903L;  
    private final I18NProvider provider;  
    public I18NSerializer(I18NProvider provider) {  
        super(Object.class);  
        this.provider = provider;  
    }  
    @Override  
    public void serialize(Object value, JsonGenerator gen, SerializerProvider provider) throws IOException {  
        String i18nValue = getI18NProperty(value, gen);  
        if (ObjectUtils.isNotEmpty(i18nValue))  
            gen.writeString(i18nValue);  
        else  
            gen.writeNull();  
    }  
    @Override  
    public void serializeWithType(Object value, JsonGenerator gen, SerializerProvider serializers, TypeSerializer typeSer) throws IOException {  
        String i18nValue = getI18NProperty(value, gen);  
        if (ObjectUtils.isNotEmpty(i18nValue))  
            super.serializeWithType(i18nValue, gen, serializers, typeSer);  
        else  
            gen.writeNull();  
    }  
    private String getI18NProperty(Object value, JsonGenerator gen) {  
        try {  
            ObjectMapper objectMapper = (ObjectMapper) gen.getCodec();  
            PropertyNamingStrategy namingStrategy = objectMapper.getPropertyNamingStrategy();  
            String fieldName = gen.getOutputContext().getCurrentName();  
            if (PropertyNamingStrategies.SNAKECASE.equals(namingStrategy))  
                fieldName = this.snakeCaseToCamelCase(fieldName);  
            Object obj = gen.getCurrentValue();  
            I18NProperty annotation = obj.getClass().getDeclaredField(fieldName).getAnnotation(I18NProperty.class);  
            String locale = annotation.locale();  
            locale = StringUtils.isNotEmpty(locale) ? locale : LocaleContextHolder.getLocale().getLanguage();  
            String i18nId = (String) PropertyUtils.getProperty(obj, annotation.fieldId());  
            return this.provider.getMessage(i18nId, annotation.type(), locale.toLowerCase(), (String) value);  
        } catch (Exception e) {  
            log.warn("exception occurred while serializer I18N property {} of class {} {}", gen.getOutputContext().getCurrentName(), gen.getCurrentValue().getClass().getName(), e.getMessage());  
            return (String) value;  
        }  
    }  
    private String snakeCaseToCamelCase(String string) {  
        if (ObjectUtils.isEmpty(string)) return string;  
        StringBuilder sb = new StringBuilder(string);  
        for (int i = 0; i < sb.length(); i++) {  
            if (sb.charAt(i) == '') {  
                sb.deleteCharAt(i);  
                sb.replace(i, i + 1, String.valueOf(Character.toUpperCase(sb.charAt(i))));  
            }  
        }  
        return sb.toString();  
    }  
}
```

In this class, `I18NSerialzer` extends `StdSerializer<CustomObject>`, where `I18nSerializer` is the implemented interface that we want got message to serialize. The `serialize()` method is overridden to define the serialization logic of our message from the specific locale. In this case, it writes the fields of the annotated field`@I18NProperty`to the JSON generator.

Step 4: Create a extends class of SimpleModule  
`SimpleModule` is a part of the Jackson ObjectMapper framework. Jackson is a popular library used for JSON (JavaScript Object Notation) serialization and deserialization in Java. To register custom serializers(`I18NSerialzer`) and deserializers for specific types. It provides a simple way to extend the serialization and deserialization capabilities of the ObjectMapper.
```java
public class I18NModule extends SimpleModule {  
    private static final long serialVersionUID = 8750960660810211977L;  
    private final I18NSerializer i18NSerializer;  
    public I18NModule(I18NProvider provider) {  
        Assert.notNull(provider, "I18N provider must not be null");  
        this.i18NSerializer = new I18NSerializer(provider);  
    }  
    @Override  
    public void setupModule(SetupContext context) {  
        context.addBeanSerializerModifier(new BeanSerializerModifier() {  
            @Override  
            public List<BeanPropertyWriter> changeProperties(SerializationConfig config, BeanDescription beanDesc, List<BeanPropertyWriter> beanProperties) {  
                for (BeanPropertyWriter writer : beanProperties) {  
                    if (ObjectUtils.isNotEmpty(writer.getAnnotation(I18NProperty.class))) {  
                        writer.assignSerializer(i18NSerializer);  
                        writer.assignNullSerializer(i18NSerializer);  
                    }  
                }  
                return beanProperties;  
            }  
        });  
    }  
}
```
In this class, `I18NModule` is a module to be registering a custom serializer (`I18NSerialzer`) with the `SimpleModule`.

Step 5: How we creare bean for this module(`I18NModule`)  
There are two ways to register this module as we can see from the below examples:
```java
@Bean  
public I18NModule i18NModule(I18nServiceImpl provider) {  
    return new I18NModule(provider);  
}  
// or  
@Bean  
public ObjectMapper mapper(I18nServiceImpl provider) {  
    Jackson2ObjectMapperBuilder builder = new Jackson2ObjectMapperBuilder();  
    builder.failOnUnknownProperties(false);  
    ObjectMapper mapper = builder.build();  
    SerializerProvider serializerProvider = mapper.getSerializerProvider();  
    if (ObjectUtils.isNotEmpty(serializerProvider))  
        mapper.setSerializerProvider(new CustomDefaultSerializerProvider());  
    mapper.setPropertyNamingStrategy(new PropertyNamingStrategies.SnakeCaseStrategy());  
    mapper.registerModule(new I18NModule(provider));  
    return mapper;  
}
```
The below class show how we set the default locale and supported locales and also how we create bean for this class
```java
public class SmartLocaleResolver extends AcceptHeaderLocaleResolver {  
    @Override  
    public Locale resolveLocale(HttpServletRequest request) {  
        Locale defaultLocale = new Locale("en");  
        List<Locale> supportedLocales = Arrays.asList(new Locale("km"), new Locale("en"), new Locale("kr"));  
        if (StringUtils.isBlank(request.getHeader("Accept-Language"))) {  
            return defaultLocale;  
        }  
        this.setSupportedLocales(supportedLocales);  
        List<Locale.LanguageRange> list = Locale.LanguageRange.parse(request.getHeader("Accept-Language"));  
        Locale locale = Locale.lookup(list, getSupportedLocales());  
        if (ObjectUtils.isEmpty(locale))  
            return defaultLocale;  
        return locale;  
    }  
  
}  
@Bean  
public LocaleResolver localeResolver() {  
    return new SmartLocaleResolver();  
}
```
And all of these below classes, show how we store the message of locale in database and query back from the implementation of provider interface `I18NProvider`
```java
@Setter  
@Getter  
@Entity  
@Table(name = I18nEntity.TABLENAME)  
public class I18nEntity {  
    public static final String TABLENAME = "i18n";  
    @Id  
    @Column(nullable = false, unique = true)  
    private String id;  
    @Column(nullable = false)  
    private String key;  
    @Column(nullable = false)  
    private String locale;  
    @Column(nullable = false)  
    private String type;  
    private String message;  
    @Column(name = "createdby")  
    protected String createdBy;  
    @Temporal(TemporalType.TIMESTAMP)  
    @Column(name = "createddate")  
    protected Date createdDate;  
    @Override  
    public int hashCode() {  
        return Objects.hash(key, locale, type);  
    }  
    private String status;  
}
```
```sql
create table public.i18n (  
 id bigserial not null,  
 "type" varchar(255) not null,  
 locale varchar(255) not null,  
 "key" varchar(255) not null,  
 createdby varchar(255) null,  
 createddate timestamp null,  
 message text null,  
 status varchar(255) null,  
 constraint i18npkey primary key (id)  
);
```

```java
@Data  
public class I18nDTO implements Serializable {  
    private static final long serialVersionUID = 1905122041950251207L;  
    private String id;  
    private String key;  
    private String locale;  
    private String message;  
    private String type;  
}

public interface I18nService {  
}  
  
@Service  
@AllArgsConstructor  
public class I18nServiceImpl implements I18nService, I18NProvider {  
    private final I18nRepository repository;  
  
    @Override  
    public String getMessage(String key, String type, String locale, String defaultMessage) {  
        I18nEntity entity = new I18nEntity();  
        entity.setKey(key);  
        entity.setType(type);  
        entity.setLocale(locale);  
        entity.setStatus("ACTIVE");  
        Optional<I18nEntity> nEntity = this.repository.findOne(Example.of(entity));  
        if (nEntity.isPresent())  
           return nEntity.get().getMessage();  
        return defaultMessage;  
    }  
}
```

And finally here is the use case and sample

This sample will localize from header locale
```java
@I18NProperty(fieldId = "gender", type = "gender.label")  
private String gender;

private String id; // product id  
@I18NProperty(type = "product.name")  
private String productName;
```
This sample will localize for “km” only
```java
private String id; // product id  
@I18NProperty(type = "product.name", locale = "km")  
private String productName;

@I18NProperty(fieldId = "gender", type = "gender.label", locale = "km")  
private String gender;
```
phsophea101/spring-boot-localization-with-custom-annotation-from-database



https://github.com/phsophea101/spring-boot-localization-with-custom-annotation-from-database

---
# Spring Boot Creating Dynamic SQL Queries 

### Introduction

Dynamic SQL queries offer flexibility and power when working with databases. In applications like rental platforms, users may need to filter properties based on multiple parameters like location, price, or amenities. Writing static queries for every combination is impractical. Instead, dynamic SQL queries allow us to construct queries at runtime, tailoring them to user inputs without sacrificing performance.

In this blog, we’ll dive into building high-performance dynamic SQL queries in Spring Boot. We’ll use Spring Data JPA and the Criteria API for efficiency and maintainability. Additionally, we’ll create a rental endpoint to showcase dynamic filtering, complete with code samples and explanations.

### Why Dynamic SQL Queries?

Dynamic SQL queries solve two main problems:

1.  Flexibility: Users can filter data using various criteria, like location, price range, or availability.
2.  Performance: By only including necessary query parts, you reduce database overhead.

### Case Study: Rental Platform Filtering

Imagine a rental platform where users can search for properties. The search parameters might include:

-   Location: The city or neighborhood.
-   Price Range: Minimum and maximum price.
-   Amenities: Options like Wi-Fi, parking, or a swimming pool.

Hardcoding all these combinations would be tedious. Instead, we’ll dynamically generate the query.

### Step-by-Step Implementation

### 1. Project Setup

Create a Spring Boot project with the following dependencies:

-   Spring Web
-   Spring Data JPA
-   H2 Database (for simplicity, use any database as needed)

Add the necessary dependencies to your `pom.xml`:
```xml
<dependencies>  
    <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-data-jpa</artifactId>  
    </dependency>  
    <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-web</artifactId>  
    </dependency>  
    <dependency>  
        <groupId>com.h2database</groupId>  
        <artifactId>h2</artifactId>  
        <scope>runtime</scope>  
    </dependency>  
</dependencies>
```
### 2. Define the Entity

Create an `Entity` for rental properties:
```java
import jakarta.persistence.Entity;  
import jakarta.persistence.GeneratedValue;  
import jakarta.persistence.GenerationType;  
import jakarta.persistence.Id;  
  
@Entity  
public class RentalProperty {  
    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    private Long id;  
    private String location;  
    private Double price;  
    private Boolean hasWifi;  
    private Boolean hasParking;  
    private Boolean hasPool;  
    // Getters and Setters  
}
```
### 3. Create the Repository

We’ll use the `JpaSpecificationExecutor` interface to enable dynamic query generation:
```java
import org.springframework.data.jpa.repository.JpaRepository;  
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;  
  
public interface RentalPropertyRepository   
        extends JpaRepository<RentalProperty, Long>, JpaSpecificationExecutor<RentalProperty> {  
}
```
### 4. Build the Dynamic Query

We’ll use the Criteria API to construct dynamic SQL queries:
```java
import org.springframework.data.jpa.domain.Specification;  
import jakarta.persistence.criteria.Predicate;  
  
public class RentalPropertySpecifications {  
    public static Specification<RentalProperty> filterProperties(String location, Double minPrice, Double maxPrice, Boolean hasWifi, Boolean hasParking, Boolean hasPool) {  
        return (root, query, criteriaBuilder) -> {  
            Predicate predicate = criteriaBuilder.conjunction();  
            if (location != null && !location.isEmpty()) {  
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("location"), location));  
            }  
            if (minPrice != null) {  
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.greaterThanOrEqualTo(root.get("price"), minPrice));  
            }  
            if (maxPrice != null) {  
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.lessThanOrEqualTo(root.get("price"), maxPrice));  
            }  
            if (hasWifi != null) {  
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("hasWifi"), hasWifi));  
            }  
            if (hasParking != null) {  
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("hasParking"), hasParking));  
            }  
            if (hasPool != null) {  
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("hasPool"), hasPool));  
            }  
            return predicate;  
        };  
    }  
}
```
### 5. Create the Service Layer

The service layer will handle business logic and call the repository with the dynamic query:
```java
import org.springframework.data.domain.Sort;  
import org.springframework.stereotype.Service;  
import java.util.List;  
  
@Service  
public class RentalPropertyService {  
    private final RentalPropertyRepository repository;  
    public RentalPropertyService(RentalPropertyRepository repository) {  
        this.repository = repository;  
    }  
    public List<RentalProperty> searchProperties(String location, Double minPrice, Double maxPrice, Boolean hasWifi, Boolean hasParking, Boolean hasPool) {  
        return repository.findAll(RentalPropertySpecifications.filterProperties(location, minPrice, maxPrice, hasWifi, hasParking, hasPool), Sort.by("price").ascending());  
    }  
}
```
### 6. Develop the Controller

Create an endpoint to handle search requests:
```java
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.RequestParam;  
import org.springframework.web.bind.annotation.RestController;  
import java.util.List;  
  
@RestController  
public class RentalPropertyController {  
    private final RentalPropertyService service;  
    public RentalPropertyController(RentalPropertyService service) {  
        this.service = service;  
    }  
    @GetMapping("/rentals")  
    public List<RentalProperty> search(  
            @RequestParam(required = false) String location,  
            @RequestParam(required = false) Double minPrice,  
            @RequestParam(required = false) Double maxPrice,  
            @RequestParam(required = false) Boolean hasWifi,  
            @RequestParam(required = false) Boolean hasParking,  
            @RequestParam(required = false) Boolean hasPool) {  
        return service.searchProperties(location, minPrice, maxPrice, hasWifi, hasParking, hasPool);  
    }  
}
```
### 7. Test the API

Start the application and use a tool like Postman or cURL to test the endpoint:
```shell
GET http://localhost:8080/rentals?location=NewYork&minPrice=500&hasWifi=true
```
### Performance Tips

1.  Indexing: Ensure frequently queried columns like `location` and `price` are indexed in the database.
2.  Paging: Use pagination to handle large datasets efficiently.
3.  Profiling: Use tools like Hibernate’s query logging to monitor and optimize query execution.

### Conclusion

Dynamic SQL queries in Spring Boot empower developers to build flexible, high-performance applications. By leveraging the Criteria API and Spring Data JPA, we can create maintainable solutions tailored to user requirements. With the rental filtering example, you’ve seen how to implement a robust dynamic query system that’s both powerful and easy to extend.

This approach isn’t limited to rental platforms; it can be adapted for e-commerce filters, employee directories, or any application requiring dynamic searches. Take these concepts and build your own dynamic query implementations to elevate your Spring Boot applications!

---

# 🔁 How to Make Spring Boot Dynamic Configuration Changes Without Restarting the Application

![](https://miro.medium.com/v2/resize:fit:875/1*rNIyQLt9-oI2Cw6lAbJeQ.jpeg)
Dynamic Configuration in Spring Boot

Spring Boot has become the go-to framework for building modern Java applications due to its simplicity, production-readiness, and developer productivity. However, one common limitation is the static nature of its configuration — properties are typically read only at startup. Restarting the application just to change a configuration value (like a feature flag or timeout) isn’t ideal, especially in production.

Fortunately, there are several approaches in Spring Boot to **dynamically change configurations** at runtime — **without restarting the app**.

# 🚀 Why You Need Dynamic Configuration

Imagine you’re running a **live payment processing** system. Suddenly, due to heavy traffic, you need to:

-   Increase the timeout limit,
-   Disable a feature temporarily,
-   Switch API endpoints.

If your app requires a **restart** every time you do this, you risk **downtime** and **loss of transactions**. That’s where **dynamic configuration** comes in.

# ✅ 1. Spring Cloud Config with Actuator Refresh 🔁

This is ideal for **microservices** or distributed applications where you want a **centralized config server** to manage all configurations dynamically.

# 📌 Setup:

-   Store configs in a **Git repo** or **file system**
-   Use Spring Cloud Config Server
-   Clients fetch updated config from the server

# `application.yml` on the client:
```yml
spring:  
  application:  
    name: payment-service  
  cloud:  
    config:  
      uri: http://localhost:8888
```
# Add dependencies:
```xml
<!-- Client Side -->  
<dependency>  
  <groupId>org.springframework.cloud</groupId>  
  <artifactId>spring-cloud-starter-config</artifactId>  
</dependency>  
<dependency>  
  <groupId>org.springframework.boot</groupId>  
  <artifactId>spring-boot-starter-actuator</artifactId>  
</dependency>
```
# Annotate beans with `@RefreshScope`:
```java
@RefreshScope  
@Component  
public class PaymentSettings {  
@Value("${payment.timeout}")  
    private int timeout;  
    public int getTimeout() {  
        return timeout;  
    }  
}
```
# Trigger refresh:

After changing the config in Git, send a POST request:

curl -X POST http://localhost:8080/actuator/refresh

# ✅ 2. Spring Boot Actuator + `@RefreshScope` (No Cloud Required)

This works great for **monolithic** or **standalone apps** where configs may change occasionally.

# Use case: Feature toggle for a dashboard.
```java
@RefreshScope  
@Component  
public class FeatureToggle {  
@Value("${feature.dashboard.enabled:false}")  
    private boolean isDashboardEnabled;  
    public boolean isDashboardEnabled() {  
        return isDashboardEnabled;  
    }  
}
```

-   Change the value in `application.properties`:
```shell
feature.dashboard.enabled=true
```
-   Hit refresh:

curl -X POST http://localhost:8080/actuator/refresh

# ✅ 3. `@ConfigurationProperties` with Refreshable Beans

Great for **grouping related configs** into a POJO. Combine it with `@RefreshScope` to allow dynamic reloading.
```java
@Configuration  
@ConfigurationProperties(prefix = "mail")  
@RefreshScope  
public class MailSettings {  
    private String host;  
    private int port;  
// Getters and setters  
}
```
```shell
mail.host=smtp.example.com  
mail.port=587
```
This makes the configuration type-safe and easier to manage.

# ✅ 4. External Configuration from Database/Cache

If configs change frequently or are user-specific, consider storing them in a **DB** or **Redis**.

# Use case: Personalized pricing threshold from DB.
```java
@Component  
public class PricingService {  
@Autowired  
    private ConfigRepository configRepo;  
    private int priceThreshold;  
    @Scheduled(fixedRate = 60000)  
    public void refreshThreshold() {  
        this.priceThreshold = configRepo.getThreshold();  
    }  
    public boolean isAboveThreshold(int price) {  
        return price > priceThreshold;  
    }  
}
```

This approach allows your app to adapt **in real-time**, even based on analytics or admin input.

# ✅ 5. Spring Boot DevTools (For Local Development Only)

Spring Boot DevTools automatically reloads the app when changes are made to `application.properties`, class files, or templates.
```xml
<dependency>  
  <groupId>org.springframework.boot</groupId>  
  <artifactId>spring-boot-devtools</artifactId>  
  <scope>runtime</scope>  
</dependency>
```
Just save the file, and it reloads. Perfect for **local prototyping** — but **never use in production**.

# ✅ Summary Table

![](https://miro.medium.com/v2/resize:fit:875/1*w2SUCovoFErmcXohNBD2Bw.png)
Summary Table

# 💡 Final Thoughts

Dynamic configuration in Spring Boot is **essential** for maintaining uptime and responsiveness in today’s fast-moving environments. Whether you’re running a **large-scale microservices architecture** or a **simple standalone app**, you can leverage these techniques to update behavior **without restarts**.

Using **Spring Cloud Config**, **Actuator**, or **external sources** can drastically improve your deployment agility, especially when integrated with CI/CD and monitoring.

---

### Enabling Dynamic Property Injection in Spring Boot

Sometimes your application needs to respond to changing configuration values without restarting, like when a property changes in a config server or external file. Instead of rebuilding everything from scratch, you can use features like `@RefreshScope` and the `Environment` object to reload values while the application keeps running. This article covers how that process works under the surface and shows how to design beans that can pick up new values automatically when triggered. We'll take a close look at what happens in the background to make this work and how to use it in a real Spring Boot setup.

### Using @RefreshScope and How It Works

### What @RefreshScope Does in a Spring Context

In a typical Spring application, beans are created once and managed as singletons for the life of the application. The values injected into those beans — through `@Value`, configuration properties, or constructor arguments—are fixed at startup. So, even if you update your `application.properties` file or change values in a config server, your running app won’t see those updates without restarting.

This is where `@RefreshScope` comes into play. When applied to a bean, it tells Spring to treat that bean a little differently. Instead of being created once and kept around, the bean becomes refreshable. If something triggers a refresh event, Spring will throw out the existing instance and create a brand-new one, pulling in any updated property values in the process.

For example:
```java
@RefreshScope  
@Component  
public class FeatureToggle {  
  
    @Value("${feature.enabled:false}")  
    private boolean enabled;  
  
    public boolean isEnabled() {  
        return enabled;  
    }  
}
```

This bean will reload the `feature.enabled` value whenever a refresh is triggered, so you can change the toggle at runtime without needing to bring down the app.

### What Happens Behind the Scenes

To make this work, Spring relies on a few important pieces: the application context, the refresh scope itself, and an event-driven mechanism.

When the application starts up, Spring creates a special `RefreshScope` bean that manages all beans annotated with `@RefreshScope`. These beans aren’t kept as regular singletons. Instead, they’re wrapped in proxies—temporary stand-ins that delay the creation of the real bean until it’s actually needed.

These proxies give Spring the ability to swap out the underlying bean later. If a refresh event is triggered, the scope clears its cache of bean instances. The next time the bean is accessed, Spring creates a new instance with the most up-to-date configuration.

This behavior is built on Spring’s normal bean lifecycle and context hierarchy. No reflection tricks or bytecode hacks — it just uses standard bean management features in a slightly different way.

### How the Refresh is Triggered

The actual refresh doesn’t happen on its own — you have to tell Spring when to do it. Most applications that use `@RefreshScope` pair it with Spring Boot Actuator and Spring Cloud dependencies, which provide a `/actuator/refresh` HTTP endpoint.

Here’s how it works:

1.  You update a config file or a remote config server value.
2.  You send a `POST` request to `/actuator/refresh`.
3.  Spring Cloud publishes a `RefreshEvent` to the application context.
4.  The refresh scope listens for this event and clears its internal cache of beans.
5.  The next time any `@RefreshScope` bean is accessed, a fresh instance is created using the latest configuration.

The `/refresh` endpoint is optional—you can trigger the refresh programmatically too. The important part is the `RefreshEvent`. As long as that event is published, the refresh scope will react to it.

Here’s what a manual trigger might look like:
```java
@Autowired  
private ApplicationEventPublisher publisher;  
  
public void triggerRefresh() {  
    publisher.publishEvent(new RefreshEvent(this, null, "Manual refresh"));  
}
```
This sends the signal to clear out and rebuild refreshable beans without using the actuator endpoint.

### Scope Isolation and Performance Notes

A useful detail about `@RefreshScope` is that it doesn’t affect the rest of the application context. Only the beans in that scope are touched during a refresh. Other singleton or prototype beans stay as they are.

That means you can safely use `@RefreshScope` for just the components that need dynamic configuration—such as feature flags, URLs for external services, thresholds, or timeout settings—without worrying about unrelated parts of the app being disrupted.

There is a small cost in terms of overhead. Beans under refresh scope are proxied, and Spring has to manage a bit more state internally. But unless you’re calling the refresh hundreds of times per minute, it’s unlikely to affect performance in a noticeable way.

### Practical Use Cases

`@RefreshScope` is a good fit when you're working with:

-   Config servers that push frequent updates (like Spring Cloud Config)
-   Feature toggles that change during the day
-   Limits or thresholds that come from external sources
-   Flags that control behavior for experimentation or gradual rollout

It lets you keep your application flexible and responsive to change without making big compromises or rewriting configuration logic by hand.

Just remember, the bean has to be accessed after the refresh is triggered in order for the updated values to take effect. If no one calls it, the new instance won’t be created until it’s needed.

### Using the Environment Object for Real-Time Configuration Access

### What the Environment Object Gives You

Property values in most Spring-based projects are loaded during startup and stay the same for the rest of the application’s lifetime. But if you ever need to check the latest value of something at runtime — without restarting or rebuilding anything — you can use Spring’s `Environment` object. This gives you a way to look up the current value of a property whenever you need it.

You can inject the `Environment` into any Spring-managed bean and use it like this:
```java
@Component  
public class ConfigLookupService {  
  
    @Autowired  
    private Environment environment;  
  
    public String getDatabaseHost() {  
        return environment.getProperty("database.host");  
    }  
}
```
Every time `getDatabaseHost()` runs, it checks what `database.host` is right now. So if the value changes in a config server or a properties file and your app picks it up, this method will return the updated value without needing anything else to happen.

This works well for things you want to look up on the fly, like feature flags, thresholds, or service URLs that might change while the app is running.

### Where Environment Gets Its Data

The `Environment` object doesn’t just look in one place. Spring builds it using a stack of sources, each one contributing to the final result. These sources are checked in order, and the first one that contains the property you’re looking for is the one that gets used.

Some common places it looks:

-   `application.properties` or `application.yml`
-   System environment variables
-   JVM system properties (like `-D` flags)
-   Command-line arguments
-   Spring Cloud Config Server (if you’re using it)
-   Profile-specific files like `application-dev.yml`

Spring organizes these sources by priority. So, for example, a value passed in through the command line will override the same value in a `.properties` file. This layering is what makes the system flexible—you can tweak your config in different ways depending on the environment without having to rewrite the same settings over and over.

You don’t have to manage this order yourself. Spring does it automatically as part of the startup process.

### Why Environment Lookups Stay Current

One nice thing about using the `Environment` directly is that you're not getting a frozen copy of the config. You’re asking for the value each time. If something has changed behind the scenes—like a config server update or a refresh of property files—the result you get reflects that change. In contrast, when you inject a property with `@Value`, Spring reads it once when the bean is created and then doesn’t touch it again. So if you want a value that might change later, `Environment` is the better tool.

This doesn’t require anything fancy to work. There’s no proxy or reload mechanism involved. It’s just a method call, and behind that, Spring is checking its list of property sources for the latest known value.

### When This Pattern Makes Sense

There are a lot of cases where it’s better to read a config value at the time you need it instead of holding on to it. Here are some common ones:

-   **Feature toggles**: If you’re rolling out a new feature gradually, you can check the flag each time you need it instead of restarting the app every time the flag changes.
-   **Timeouts and thresholds**: Services that deal with different load conditions might need to adjust their limits without being brought down. Reading a fresh value every time lets you do that.
-   **Scheduled jobs**: If you have a batch task that runs every hour, it might need to know how much data to process, or which service to call. Using the `Environment` lets the job read those values right before it starts.
-   **External service configuration**: If you’re talking to APIs or other systems and those endpoints can change, reading them at runtime gives you more control and fewer surprises.

Here’s an example of how you can use it in a scheduled job:
```java
@Service  
public class BatchProcessor {  
  
    @Autowired  
    private Environment env;  
  
    public void runJob() {  
        int maxItems = Integer.parseInt(env.getProperty("job.maxItems", "100"));  
        // Use maxItems to decide how much to process  
    }  
}
```
You can change `job.maxItems` in your config and trigger a refresh, and the next time this method runs, it will pick up the new value. No restarts, no reloading, just the latest value when you ask for it.

### Conclusion

Spring gives you a few different ways to work with configuration that might change while your application is still running. With `@RefreshScope`, Spring handles the process of rebuilding specific beans after a refresh is triggered, making it possible to update values without affecting the rest of the application. On the other hand, the `Environment` object gives you a way to check the latest value of a property anytime you need it, without needing to reload anything at all. Both features depend on how Spring wires beans, manages scope, and keeps track of property sources. Once you understand how those pieces fit together, it's easier to build something that reacts to changes without a full restart. These tools don’t require anything special to set up beyond what Spring already gives you—they just take advantage of how the framework already works internally.

---
# How Spring Boot Dynamically Switches Between JSON, XML & CSV Like Magic
> **🎉** Article Published: 181
> 
> if you are not a medium member then Click [here](/@gaddamnaveen192/how-spring-boot-dynamically-switches-between-json-xml-csv-like-magic-414f4020adde?sk=adc80f8769b7bf24814858b8b9afe5fb) to read free

### What is Content Negotiation?

**Content Negotiation** is the mechanism that allows a **client** (e.g., browser, mobile app, Postman) to specify **which format** it wants the **server response** to be in — such as JSON, XML, HTML, or plain text.

In Spring Boot, content negotiation is handled by the **ContentNegotiationManager**, which checks:

-   What the client is asking for
-   What formats the server can provide
-   And then selects the most appropriate **media type** (also called **MIME type**) for the response

![](https://miro.medium.com/v2/resize:fit:875/1*8PKQDtIkr2OKuI3zsKTNYQ.png)

### Why is Content Negotiation Useful?

-   APIs can support **multiple clients** — web, mobile, legacy systems — that want different formats.
-   Useful in **integration testing** to simulate different consumers.
-   Helps in **API versioning** using custom headers/media types.

![](https://miro.medium.com/v2/resize:fit:875/1*kYdXjcCdxCuoPCj27MxfQ.png)

### 1️ Accept Header Based Content Negotiation

### How it works:

The client specifies the expected response format in the `Accept` HTTP header.

######### No configuration needed

######### Request:
```shell
GET /api/user  
Accept: application/json
```
or
```shell
Accept: application/xml
```
Controller
```java
@RestController  
@RequestMapping("/api")  
public class UserController {  
  
    @GetMapping(value = "/user", produces = { MediaType.APPLICATIONJSONVALUE, MediaType.APPLICATIONXMLVALUE })  
    public User getUser() {  
        return new User(1, "John");  
    }  
}
```
Model
```java
@JacksonXmlRootElement(localName = "user")  
public class User {  
    private int id;  
    private String name;  
  
    // constructors, getters, setters  
}
```
### Real-Time Use Case: Dynamic Response Format Based on Accept Header

### Scenario: Multi-Format User API

A company is building a public API that needs to serve both JSON and XML responses to accommodate different client requirements. They want to implement content negotiation where the response format is determined by the client’s `Accept` header, without any server-side configuration changes.

### 2️ URL File Extension Based Negotiation (e.g., `.json`, `.xml`)

######### Real-World Use Case: URL Extension-Based Content Negotiation

### Scenario: Legacy System Integration

A financial institution maintains a critical legacy mainframe system that processes customer data. This system was built in the early 2000s and cannot properly set HTTP headers, but needs to consume data from a modern Spring Boot API that serves both internal web applications and this legacy system.

######### Implementation Details

######### Configuration (Deprecated but Still Used)
```java
@Configuration  
public class WebConfig implements WebMvcConfigurer {  
    @Override  
    public void configureContentNegotiation(ContentNegotiationConfigurer configurer) {  
        configurer  
            .favorPathExtension(true)  // Enable URL extension detection  
            .ignoreAcceptHeader(true) // Ignore Accept headers  
            .defaultContentType(MediaType.APPLICATIONJSON)  
            .mediaType("json", MediaType.APPLICATIONJSON)  
            .mediaType("xml", MediaType.APPLICATIONXML);  
    }  
}
```
### Controller
```java
@RestController  
@RequestMapping("/api/transactions")  
public class TransactionController {  
      
    @GetMapping(value = "/{accountId}",   
                produces = { MediaType.APPLICATIONJSONVALUE,   
                           MediaType.APPLICATIONXMLVALUE })  
    public List<Transaction> getTransactions(@PathVariable String accountId) {  
        return transactionService.getRecentTransactions(accountId);  
    }  
}
```
### Model
```java
@JacksonXmlRootElement(localName = "transaction")  
public class Transaction {  
    private String id;  
    private LocalDate date;  
    private BigDecimal amount;  
    private String description;  
      
    // Constructors, getters, setters  
}
```
######### Real-World Usage Examples

### 1. Legacy COBOL System Integration

**Situation:** The bank’s core banking system written in COBOL can only make basic HTTP requests without header modification.

**Request**
```shell
GET https://bank-api.example.com/api/transactions/ACC12345.xml
```
**Response**
```xml
<List>  
  <transaction>  
    <id>TXN1001</id>  
    <date>2023-11-15</date>  
    <amount>150.00</amount>  
    <description>ATM WITHDRAWAL</description>  
  </transaction>  
  <transaction>  
    <id>TXN1002</id>  
    <date>2023-11-14</date>  
    <amount>2500.00</amount>  
    <description>SALARY CREDIT</description>  
  </transaction>  
</List>
```
### 2. Modern Web Application

**Situation:** The bank’s online portal built with React needs transaction data.

**Request:**
```shell
GET https://bank-api.example.com/api/transactions/ACC12345.json
```
**Response:**
```json
[  
  {  
    "id": "TXN1001",  
    "date": "2023-11-15",  
    "amount": 150.00,  
    "description": "ATM WITHDRAWAL"  
  },  
  {  
    "id": "TXN1002",  
    "date": "2023-11-14",  
    "amount": 2500.00,  
    "description": "SALARY CREDIT"  
  }  
]
```
### 3. Third-Party Partner Integration

**Situation:** An accounting software vendor needs to integrate with the bank but their middleware has limited HTTP capabilities.

**Request**
```shell
`GET https://bank-api.example.com/api/transactions/ACC12345.xml?fromDate=2023-01-01&toDate=2023-11-30
```
### Why This Approach is Still Used (Despite Being Deprecated)

1.  **Legacy System Constraints:**

-   Older systems (IBM Mainframes, AS/400) with HTTP libraries that can’t set headers
-   Embedded systems with limited HTTP stack implementations

**2. Debugging Simplicity:**

-   Easier to test APIs directly in browsers by just changing the URL
```shell
https://api.example.com/data.xml  
https://api.example.com/data.json
```
1.  **Documentation Clarity:**

-   The format is visibly apparent in the URL itself
-   Helps when sharing API examples in documentation

**2. Transition Period:**

-   Many organizations still maintain this for backward compatibility
-   Phasing out gradually as systems modernize

### Security Considerations

While convenient, this approach has risks:

-   Potential extension-based attack vectors
-   Less secure than header-based negotiation
-   Can expose implementation details in URLs

### Migration Path

Organizations using this should:

1.  Add Accept header support alongside URL extensions
2.  Document and encourage header-based negotiation
3.  Gradually deprecate the extension approach
4.  Prvide clear migration timelines for consumers

### 3. Real-World Use Case: Query Parameter-Based Content Negotiation

### Scenario: E-Commerce API with Flexible Response Formats

An e-commerce platform provides a product API that needs to support multiple response formats through simple query parameters. This approach is particularly useful for:

-   Frontend developers quickly testing APIs in browsers
-   Third-party developers integrating with limited HTTP capabilities
-   Internal tools that need to switch formats easily

######### Implementation Details

######### Configuration
```java
@Configuration  
public class WebConfig implements WebMvcConfigurer {  
    @Override  
    public void configureContentNegotiation(ContentNegotiationConfigurer configurer) {  
        configurer  
            .favorParameter(true)          // Enable format parameter  
            .parameterName("format")      // Use "format" as parameter name  
            .ignoreAcceptHeader(false)    // Still honor Accept headers  
            .defaultContentType(MediaType.APPLICATIONJSON)  
            .mediaType("json", MediaType.APPLICATIONJSON)  
            .mediaType("xml", MediaType.APPLICATIONXML)  
            .mediaType("txt", MediaType.TEXTPLAIN)  
            .mediaType("csv", new MediaType("text", "csv"));  
    }  
}
```
### Controller
```java
@RestController  
@RequestMapping("/api/products")  
public class ProductController {  
      
    @GetMapping(produces = {   
        MediaType.APPLICATIONJSONVALUE,  
        MediaType.APPLICATIONXMLVALUE,  
        MediaType.TEXTPLAINVALUE,  
        "text/csv"  
    })  
    public List<Product> getProducts(  
        @RequestParam(required = false) String category,  
        @RequestParam(required = false) Double minPrice,  
        @RequestParam(required = false) Double maxPrice) {  
          
        return productService.findProducts(category, minPrice, maxPrice);  
    }  
}
```
### Model
```java
public class Product {  
    private String id;  
    private String name;  
    private String category;  
    private double price;  
    private int stock;  
      
    // Constructors, getters, setters  
}
```

### Real-World Usage Examples

### 1. Browser Testing by Frontend Developers

**Situation:** A frontend developer quickly checks API responses during development.

**Request:**
```shell
GET /api/products?category=electronics&minPrice=100&format=json
```
**Response (JSON):**
```json
[  
  {  
    "id": "P1001",  
    "name": "Wireless Headphones",  
    "category": "electronics",  
    "price": 129.99,  
    "stock": 45  
  },  
  {  
    "id": "P1002",  
    "name": "Smart Watch",  
    "category": "electronics",  
    "price": 199.99,  
    "stock": 32  
  }  
]
```
### 2. Legacy Integration with Limited HTTP Support

**Situation:** An old inventory system that can’t set headers needs CSV output.

**Request**
```shell
GET /api/products?format=csv
```
**Response (CSV)**

id,name,category,price,stock  
P1001,Wireless Headphones,electronics,129.99,45  
P1002,Smart Watch,electronics,199.99,32  
P1003,Desk Lamp,home,39.99,120

### 3. Debugging with Plain Text Output

**Situation:** A support engineer needs quick human-readable output.

**Request:**
```shell
GET /api/products?id=P1001&format=txt
```
**Response**

Product Details:  
ID: P1001  
Name: Wireless Headphones  
Category: electronics  
Price: $129.99  
Stock: 45 units

### 4. XML for Enterprise Integration

**Situation:** A partner system requires XML format for their middleware.

**Request:**
```shell
GET /api/products?category=home&format=xml
```
**Response**
```xml
<List>  
  <product>  
    <id>P1003</id>  
    <name>Desk Lamp</name>  
    <category>home</category>  
    <price>39.99</price>  
    <stock>120</stock>  
  </product>  
  <product>  
    <id>P1004</id>  
    <name>Throw Pillow</name>  
    <category>home</category>  
    <price>24.99</price>  
    <stock>85</stock>  
  </product>  
</List>
```
### Why This Approach is Valuable

1.  **Developer Experience:**

-   Extremely easy to test in browsers without plugins
-   Simplifies API exploration and documentation
-   Quick format switching during development

**2. Integration Flexibility:**

-   Works with systems that can’t modify headers
-   Supports tools like Excel that can directly consume CSV
-   Compatible with simple HTTP clients

**3. Progressive Enhancement:**

-   Can be used alongside header-based negotiation
-   Doesn’t prevent using proper Accept headers
-   Provides a fallback mechanism

### Best Practices Implementation

1.  **Default Format:**

-   JSON as default for modern applications
-   Proper 406 responses for unsupported formats

**2. Content-Type Headers:**

-   Still sets correct Content-Type in responses
-   Example: `Content-Type: application/json` even when using ?format=json

**3. Documentation:**

######### Response Formats  
  
The API supports multiple response formats specified either by:  
- `Accept` header (preferred method)  
- `format` query parameter (for convenience)  
  
Available formats:  
- JSON: `?format=json` (default)  
- XML: `?format=xml`  
- Plain Text: `?format=txt`  
- CSV: `?format=csv`

### 4️ Custom Media Type (For Versioning or Enterprise APIs)

### How it works:

Use custom `Accept` headers like `application/vnd.myapp.v1+json`.

### Controller
```java
@GetMapping(value = "/user", produces = "application/vnd.myapp.v1+json")  
public User getCustomUser() {  
    return new User(1, "Custom");  
}
```
Request
```shell
Accept: application/vnd.myapp.v1+json
```
### Use Case:

Versioning APIs — different clients can call v1, v2 by changing Accept header

### 5️ Default Content Type

### How it works:

If the client doesn’t specify any preference, Spring will use a **default**.

### ⚙ Configuration:
```java
configurer.defaultContentType(MediaType.APPLICATIONJSON);
```
### Use Case:

Set a fallback content type (usually JSON) for compatibility and clarity

### 6️ Custom Message Converter (For YAML, CSV, etc.)

### Example (YAML)
```java
@Bean  
public HttpMessageConverter<Object> createYamlHttpMessageConverter() {  
    return new MappingJackson2YamlHttpMessageConverter();  
}
```
Request
```shell
Accept: application/x-yaml
```
### Use Case:

Your system talks to third-party clients that require YAML, CSV, or proprietary formats.
---

### Understanding Spring Boot Virtual Threads in : A Practical Guide

Virtual threads, introduced in Java 21, represent a significant advancement in Java’s concurrency model. This guide demonstrates the practical differences between traditional threads and virtual threads in a Spring Boot application, showing how virtual threads can handle thousands of concurrent requests without the limitations of physical threads.

### Prerequisites

-   Java 21 or later
-   Maven or Gradle
-   Basic understanding of Spring Boot
-   Basic understanding of concurrent programming

### Key Concepts

### Traditional Threads

-   Each thread maps to an OS thread
-   Limited by the number of available CPU cores
-   High memory overhead (typically 1MB per thread)
-   Blocking operations tie up the thread

### Virtual Threads

-   Lightweight threads managed by the JVM
-   Not limited by CPU cores
-   Minimal memory overhead (few KB per thread)
-   Efficient handling of blocking operations
-   Perfect for I/O-bound applications

### Project Setup

1.  Create a new Spring Boot project with Java 21
2.  Add the following dependencies to your `pom.xml` (alternatively you can use gradle too)
```xml
<dependencies>  
    <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-web</artifactId>  
    </dependency>  
    <dependency>  
        <groupId>org.projectlombok</groupId>  
        <artifactId>lombok</artifactId>  
        <optional>true</optional>  
    </dependency>  
</dependencies>
```
### Implementation

### 1. Thread Configuration

Create `ThreadConfig.java` to configure both traditional and virtual thread executors:
```java
@Configuration  
@EnableAsync  
public class ThreadConfig {  
    @Bean(name = "traditionalExecutor")  
    public Executor traditionalExecutor() {  
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();  
        executor.setCorePoolSize(10);  // Limited number of threads  
        executor.setMaxPoolSize(10);  
        executor.setQueueCapacity(100);  
        executor.setThreadNamePrefix("traditional-");  
        executor.initialize();  
        return executor;  
    }  
  
@Bean(name = "virtualExecutor")  
    public Executor virtualExecutor() {  
        return Executors.newVirtualThreadPerTaskExecutor();  
    }  
}
```

### 2. Test Controller

Create `TestController.java` with endpoints to demonstrate both thread types:
```java
@RestController  
@RequestMapping("/api/test")  
public class TestController {  
    private static final Logger logger = LoggerFactory.getLogger(TestController.class);  
  
@Async("traditionalExecutor")  
    @GetMapping("/traditional")  
    public CompletableFuture<String> traditionalThread() {  
        logger.info("Starting traditional thread request. Thread: {}",   
                   Thread.currentThread().getName());  
        try {  
            TimeUnit.SECONDS.sleep(1);  
        } catch (InterruptedException e) {  
            Thread.currentThread().interrupt();  
            return CompletableFuture.completedFuture("Task interrupted");  
        }  
        return CompletableFuture.completedFuture(  
            "Traditional thread completed. Thread: " + Thread.currentThread().getName()  
        );  
    }  
    @Async("virtualExecutor")  
    @GetMapping("/virtual")  
    public CompletableFuture<String> virtualThread() {  
        logger.info("Starting virtual thread request. Thread: {}",   
                   Thread.currentThread());  
        try {  
            TimeUnit.SECONDS.sleep(1);  
        } catch (InterruptedException e) {  
            Thread.currentThread().interrupt();  
            return CompletableFuture.completedFuture("Task interrupted");  
        }  
        return CompletableFuture.completedFuture(  
            "Virtual thread completed. Thread: " + Thread.currentThread()  
        );  
    }  
}
```
# Testing the Implementation

### 1. Start the Application
```shell
./mvnw spring-boot:run
```
### 2. Test Traditional Threads

### Test with 200 concurrent requests (should see some failures)  
```shell
seq 1 200 | xargs -n1 -P200 curl -s "http://localhost:8080/api/test/traditional"
```
**Explaining the above command**

-   **seq 1 200**: Generates numbers from 1 to 200
-   **|**: Pipes the output to the next command
-   **xargs**: Takes input and converts it to command line arguments
-   **-n1**: Process one input item at a time
-   -P200: Run up to 200 processes in parallel
-   **curl**: Command to make HTTP requests
-   **-s**: Silent mode (no progress meter or error messages)
-   “http://localhost:8080/api/test/traditional": The target URL to test

### 3. Test Virtual Threads

### Test with 5000 concurrent requests (should all succeed) 
```shell 
seq 1 5000 | xargs -n1 -P5000 curl -s "http://localhost:8080/api/test/virtual"
```
### Expected Results

## Traditional Threads

-   Limited to 10 concurrent threads + 100 queued requests
-   Requests beyond 110 will fail or timeout
-   Thread names will be “traditional-1” to “traditional-10”
-   High memory usage with many concurrent requests

## Virtual Threads

-   Can handle thousands of concurrent requests
-   No failures or timeouts
-   Thread names will be “VirtualThread-1” to “VirtualThread-N”
-   Minimal memory overhead

# Understanding the Results

## Why Traditional Threads Fail

-   Each thread consumes significant memory
-   Limited by OS thread limits
-   Blocking operations tie up threads
-   Queue capacity limits concurrent requests

### Why Virtual Threads Succeed

-   Lightweight implementation
-   Efficient handling of blocking operations
-   Not limited by physical resources
-   Perfect for I/O-bound applications

### Best Practices

1.  Use virtual threads for:

-   I/O-bound applications
-   High-concurrency scenarios
-   Microservices with many concurrent requests
-   Applications with many blocking operations

2. Use traditional threads for:

-   CPU-bound tasks
-   Tasks requiring thread-local storage
-   Legacy code that doesn’t support virtual threads

### Common Pitfalls

1.  Not using Java 21 or later
2.  Mixing virtual and traditional threads without understanding the implications
3.  Not properly handling thread interruption
4.  Not monitoring thread usage and performance

### Conclusion

Virtual threads represent a significant advancement in Java’s concurrency model, particularly for I/O-bound applications. By understanding the differences between traditional and virtual threads, developers can make informed decisions about which to use in their applications.

### Further Reading

-   [Java Virtual Threads Documentation](https://docs.oracle.com/en/java/javase/21/core/virtual-threads.html)
-   [Spring Boot Async Documentation](https://docs.spring.io/spring-framework/docs/current/reference/html/integration.html#scheduling-annotation-support)
-   [Project Loom](https://openjdk.org/projects/loom/)

---
# Spring Cloud Config Server with JDBC and Cloud Bus Kafka (Spring Boot 3.1.3)

I had struggle while i was searching cloud config server implementation with **JDBC** as backend and **Cloud Bus** with **Kafka**.Thats why i am writing this article to help who needs updated article.

There are some articles about these topics but some of them does not include Kafka, some of them is not up to date(older SpringBoot versions).

I will use latest SpringBoot version which is **3.1.3** now.First of all, we need Spring Config Server implementation before clients.

![](https://miro.medium.com/v2/resize:fit:875/1*Usk1p6KJtXMJMIxRwA3k5A.png)

### **Setup Config Server :**

I will use **MYSQL**.Here are the dependicies we need for Config Server:
```xml
<dependency>  
   <groupId>org.springframework.boot</groupId>  
   <artifactId>spring-boot-starter-actuator</artifactId>  
  </dependency>  
  <dependency>  
   <groupId>org.springframework.boot</groupId>  
   <artifactId>spring-boot-starter-data-jdbc</artifactId>  
  </dependency>  
  <dependency>  
   <groupId>org.springframework.cloud</groupId>  
   <artifactId>spring-cloud-config-server</artifactId>  
  </dependency>  
  <dependency>  
   <groupId>com.mysql</groupId>  
   <artifactId>mysql-connector-j</artifactId>  
   <scope>runtime</scope>  
  </dependency>  
  <dependency>  
   <groupId>org.springframework.cloud</groupId>  
   <artifactId>spring-cloud-starter-bootstrap</artifactId>  
  </dependency>
```
In properties set :

**<spring-cloud.version>2022.0.4</spring-cloud.version>**

**Dependency Management part in pom.xml:**
```xml
<dependencyManagement>  
  <dependencies>  
   <dependency>  
    <groupId>org.springframework.cloud</groupId>  
    <artifactId>spring-cloud-dependencies</artifactId>  
    <version>${spring-cloud.version}</version>  
    <type>pom</type>  
    <scope>import</scope>  
   </dependency>  
  </dependencies>  
 </dependencyManagement>
```
After that we add **@EnableConfigServer** annotation to our main class and then add configurations to our config files.
```java
@SpringBootApplication  
@EnableConfigServer  
public class ConfigServerApplication {  
  
 public static void main(String[] args) {  
  SpringApplication.run(ConfigServerApplication.class, args);  
 }  
}
```

**Application.properties file** :
```shell
server.port=8888  
management.endpoints.web.exposure.include=*  
  
spring.datasource.url=jdbc:mysql://localhost:3306/configdb  
spring.datasource.username=root  
spring.datasource.password=root  
spring.jpa.properties.hibernate.dialect = org.hibernate.dialect.MySQLDialect  
spring.jpa.show-sql=true
```
**Bootstrap.yml file** :
```yaml
spring:  
  application:  
    name: config-server-with-jdbc  
  
  profiles:  
    active: jdbc  

  cloud:  
    config:  
      server:  
        jdbc:  
          sql: SELECT PROPKEY, VALUE from PROPERTIES where APPLICATION=? and PROFILE=? and LABEL=?  
          order: 1
```
And lastly we need a table named ‘properties’ in database with client-related configurations.

### **Setup Database**

To create table :
```sql
create table PROPERTIES (  
  id serial primary key,   
  CREATEDON timestamp ,  
  APPLICATION text,   
  PROFILE text,   
  LABEL text,   
  PROPKEY text,   
  VALUE text  
 );
```
To insert config data :
```sql
INSERT INTO properties (CREATEDON, APPLICATION, PROFILE, LABEL, PROPKEY, VALUE) VALUES (NULL,'config-client','dev','latest','Config1','Config Value of Client 1');  
INSERT INTO properties (CREATEDON, APPLICATION, PROFILE, LABEL, PROPKEY, VALUE) VALUES (NULL,'config-client-2','dev','latest','Config2','Config Value of Client 2');
```
**JDBC works with key pattern <application-name>/<profile>/<label>.**

In our case config-client/dev/latest and config-client-2/dev/latest.

Now Config Server implementation is done.Start Config Server hit the 
```json
  http://localhost:8888/config-client/dev/latest

{"name":"config-client","profiles":["dev"],"label":"latest","version":null,"state":null,"propertySources":[{"name":"config-client-dev","source":{"Config of Client 1":"Config Value of Client 1"}}]}
```

Now we will implement clients.

### **Setup Config Clients**

Here is the dependicies we need for client :
```xml
 <dependency>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-starter-actuator</artifactId>  
        </dependency>  
        <dependency>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-starter-web</artifactId>  
        </dependency>  
        <dependency>  
            <groupId>org.springframework.cloud</groupId>  
            <artifactId>spring-cloud-starter-config</artifactId>  
        </dependency>  
        <dependency>  
            <groupId>org.springframework.cloud</groupId>  
            <artifactId>spring-cloud-starter-bootstrap</artifactId>  
        </dependency>
```
And, if you did not include cloud in spring initialzr then add this to properties : **<spring-cloud.version>2022.0.4</spring-cloud.version>**, and add dependency management part same as config-server, which i mentioned above.

**Application.properties file :**
```shell
server.port=8081  
management.endpoints.web.exposure.include=*  
spring.cloud.config.enabled=false
```
**Bootstrap.properties file :**
```shell
spring.cloud.config.uri=http://localhost:8888  
spring.cloud.config.label=latest  
spring.profiles.active=dev  
spring.application.name=config-client
```
> **application.name — profile — label values must match with the properties table.**

Now we’ll create a Controller class to show the value that we got from database.
```java
@RestController  
@RefreshScope  
public class Controller {  
  
    @Value("${Config1}")  
    private String config1;  
  
    @GetMapping("/configs")  
    public Map<String,Object> getConfigs(){  
        return Map.of("config1",config1);  
    }  
}
```
The @Value must match with the PROPKEY column in DB.

**@RefreshScope needed for values to be refreshed after we hit the /refresh url.**

Now, with the same properties and dependicies we are implementing client-2 to see Cloud Bus advantage later.Only difference is server.port and application.name in properties.

Now, start Config-Server in port 8888, then start clients.

When we go [http://localhost:8081/configs](http://localhost:8081/configs) and [http://localhost:8082/configs](http://localhost:8082/configs) url, we’ll see :

{"config1":"Config Value of Client 1"} - from 8081  
{"config2":"Config Value of Client 2"} - from 8082

Now we’ll go db and update values ;

Config Value of Client 1 to -> Updated config value 1

Config Value of Client 2 to -> Updated config value 2

After the changes, if you go Config-Server with [http://localhost:8888/config-client/dev/latest](http://localhost:8888/config-client/dev/latest) url, you will see updated value, but in clients you will not see updated values.

To refresh these values in clients, we can use **Postman**.

If you don’t have Postman you can install from here : [https://www.postman.com/downloads/](https://www.postman.com/downloads/)

![](https://miro.medium.com/v2/resize:fit:875/1*KXsG5eT9siDbGuvlMIzgHw.png)
Trigger the refresh

After we send this post request to the 8081 client, go [http://localhost:8081/configs](http://localhost:8081/configs) url and u’ll see updated config value from db, but if you go [http://localhost:8082/configs](http://localhost:8081/configs) url u’ll still see old value.Because u need to send same actuator/refresh request for every client.

Let’s think in your app you have 8–10 config-clients.You need to trigger actuator/refresh for every clients which makes no sense.Thats why we will use Spring Cloud Bus with Kafka(of course you can use RabbitMQ too).

With Cloud Bus and Kafka we will only trigger one client or directly config server with actuator/busrefresh endpoint and all of clients who listens Kafka will automatically update values.

### **SETUP DOCKER AND KAFKA**

I will use **Docker for Kafka**.You can manually run Kafka in your machine.

To download **Docker** : [https://www.docker.com/products/docker-desktop/](https://www.docker.com/products/docker-desktop/)

So, create a new directory called kafkadockerforconfig and under that directory create a docker-compose.yml.

![](https://miro.medium.com/v2/resize:fit:241/1*ArKaQJ7yVlyeL9oyhE-row.png)
Docker-compose file under project.

**docker-compose.yml :**
```yaml
version: "3.1"  
  
services:  
  zookeeper:  
    image: wurstmeister/zookeeper  
    containername: zookeeperJdbc  
    ports:  
      - "2181:2181"  
  kafka:  
    image: wurstmeister/kafka  
    containername: kafkaJdbc  
    ports:  
      - "9092:9092"  
    environment:  
      KAFKAADVERTISEDHOSTNAME: localhost  
      KAFKAZOOKEEPERCONNECT: zookeeper:2181
```
You can change containername’s.After that from terminal use **cd** command to enter kafkadockerforconfigfile path.Then type

**“docker-compose up”** command end press enter.

After that you should see container and images running on Docker Desktop like that :

![](https://miro.medium.com/v2/resize:fit:875/1*j1GnMt77z6CatSuPYdPBBA.png)
Docker Desktop shows container running successfully

If you see this, then its means your Kafka running in your machine successfully.

After that part, we need some dependicies on our Config-Server and in Clients.Let’s add them.

In Config-Server and all clients add these dependicies :
```xml
<dependency>  
   <groupId>org.springframework.cloud</groupId>  
   <artifactId>spring-cloud-starter-bus-kafka</artifactId>  
  </dependency>  
  <dependency>  
   <groupId>org.springframework.kafka</groupId>  
   <artifactId>spring-kafka</artifactId>  
  </dependency>
```

and add this property in application.properties file : **spring.cloud.bus.enabled=true**

and in client’s bootsrap.properties file add this property : **spring.cloud.bus.enabled=true**

Now we’re ready to test.First start config-server and then start clients.You’ll see logs in the console about Kafka.

Go to database and change values of both clients.Go check client’s config first, [http://localhost:8081/configs](http://localhost:8081/configs).U’ll see old values.

Then go Postman and Send **POST** Request to **localhost:8888/actuator/busrefresh** -> not refresh this time with busrefresh.Response body will be empty with Status Code of 204 with No Content like this:

![](https://miro.medium.com/v2/resize:fit:875/1*lf1prKSygpuPOwAIJ-ZE3w.png)
Trigger busrefresh endpoint via Postman.

After that request check [http://localhost:8081/configs](http://localhost:8081/configs) and [http://localhost:8082/configs](http://localhost:8081/configs) urls, both clients have updated configs.

As you can see, we don’t have to refresh all of clients manually, we just refresh config-server once and all clients updated automatically via Cloud Bus and Kafka.

### **!NOTE**

If you using Kafka locally, you don’t need any configuration.You just need to start Kafka and add dependicies like we did and Spring handles rest.

But if you run remotely, use Spring Cloud Connectors or Spring Boot conventions to define the broker credentials, as shown in the following example for Rabbit:

**application.yml**
```yaml
spring:  
  rabbitmq:  
    host: mybroker.com  
    port: 5672  
    username: user  
    password: secret
```
https://github.com/koraykahramaan/spring-cloud-config-server-with-jdbc

---
# Spring Boot Dynamic Thread Pool Management with 
In a high-traffic web application, efficient thread management is crucial for optimal performance. In this blog post, we’ll explore how to create a Spring Boot application with dynamic thread pool management that adjusts based on HTTP request load. We’ll cover:

1.  **Setting Up a Custom Thread Pool Executor**
2.  **Creating a Servlet Context Listener**
3.  **Implementing a Filter for Dynamic Adjustment**
4.  **Building a Simple REST Controller**
5.  **Configuring and Running the Application**

### 1. Setting Up a Custom Thread Pool Executor

We’ll start by defining a custom `ThreadPoolExecutor` class that allows us to dynamically adjust the core and maximum pool sizes.
```java
import java.util.concurrent.LinkedBlockingQueue;  
import java.util.concurrent.ThreadPoolExecutor;  
import java.util.concurrent.TimeUnit;  
  
public class DynamicThreadPoolExecutor extends ThreadPoolExecutor {  
  
    public DynamicThreadPoolExecutor(int corePoolSize, int maximumPoolSize, long keepAliveTime, TimeUnit unit) {  
        super(corePoolSize, maximumPoolSize, keepAliveTime, unit, new LinkedBlockingQueue<>());  
    }  
  
    public void adjustPoolSize(int newCorePoolSize, int newMaximumPoolSize) {  
        setCorePoolSize(newCorePoolSize);  
        setMaximumPoolSize(newMaximumPoolSize);  
    }  
}
```
### 2. Creating a Servlet Context Listener

Next, we need to manage our thread pool’s lifecycle. We’ll use a `ServletContextListener` to initialize the thread pool when the application starts and shut it down gracefully when it stops.
```java
import javax.servlet.ServletContextEvent;  
import javax.servlet.ServletContextListener;  
import javax.servlet.annotation.WebListener;  
import java.util.concurrent.TimeUnit;  
  
@WebListener  
public class ThreadPoolInitializer implements ServletContextListener {  
  
    private DynamicThreadPoolExecutor threadPool;  
  
    @Override  
    public void contextInitialized(ServletContextEvent sce) {  
        threadPool = new DynamicThreadPoolExecutor(10, 20, 60, TimeUnit.SECONDS);  
        sce.getServletContext().setAttribute("threadPool", threadPool);  
    }  
  
    @Override  
    public void contextDestroyed(ServletContextEvent sce) {  
        if (threadPool != null) {  
            threadPool.shutdown();  
            try {  
                if (!threadPool.awaitTermination(60, TimeUnit.SECONDS)) {  
                    threadPool.shutdownNow();  
                }  
            } catch (InterruptedException e) {  
                threadPool.shutdownNow();  
            }  
        }  
    }  
}
```
### 3. Implementing a Filter for Dynamic Adjustment

We’ll create a `Filter` to monitor the number of active threads and adjust the thread pool size accordingly.
```java
import javax.servlet.Filter;  
import javax.servlet.FilterChain;  
import javax.servlet.FilterConfig;  
import javax.servlet.ServletException;  
import javax.servlet.ServletRequest;  
import javax.servlet.ServletResponse;  
import java.io.IOException;  
  
public class DynamicThreadPoolFilter implements Filter {  
  
    private DynamicThreadPoolExecutor threadPool;  
  
    @Override  
    public void init(FilterConfig filterConfig) {  
        threadPool = (DynamicThreadPoolExecutor) filterConfig.getServletContext().getAttribute("threadPool");  
    }  
  
    @Override  
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)  
            throws IOException, ServletException {  
  
        if (threadPool != null) {  
            int activeCount = threadPool.getActiveCount();  
            int corePoolSize = threadPool.getCorePoolSize();  
            int maxPoolSize = threadPool.getMaximumPoolSize();  
  
            if (activeCount > corePoolSize * 0.75 && corePoolSize < maxPoolSize) {  
                threadPool.adjustPoolSize(corePoolSize + 5, maxPoolSize + 10);  
            } else if (activeCount < corePoolSize * 0.25 && corePoolSize > 10) {  
                threadPool.adjustPoolSize(corePoolSize - 5, maxPoolSize - 10);  
            }  
        }  
  
        chain.doFilter(request, response);  
    }  
  
    @Override  
    public void destroy() {  
        // No cleanup necessary  
    }  
}
```
### 4. Building a Simple REST Controller

To test our setup, we’ll create a simple REST controller that responds with the current thread name.
```java
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RestController;  
  
@RestController  
@RequestMapping("/api")  
public class ThreadController {  
  
    @GetMapping("/threads")  
    public String entry() {  
        return "Request processed by thread: " + Thread.currentThread().getName();  
    }  
}
```

### 5. Configuring and Running the Application

Finally, ensure your Spring Boot application is set up correctly with the necessary configurations:

**Main Application Class**
```java
import org.springframework.boot.SpringApplication;  
import org.springframework.boot.autoconfigure.SpringBootApplication;  
  
@SpringBootApplication  
public class DynamicThreadPoolApplication {  
  
    public static void main(String[] args) {  
        SpringApplication.run(DynamicThreadPoolApplication.class, args);  
    }  
}
```
**Add Filter and Listener Configuration**

Ensure that the `DynamicThreadPoolFilter` and `ThreadPoolInitializer` are registered correctly. In Spring Boot, filters and listeners are automatically detected and registered if they are annotated with `@WebListener` or if registered in `application.properties` or `application.yml`.

### Conclusion

In this blog post, we created a Spring Boot application with a dynamically adjustable thread pool. We defined a custom `ThreadPoolExecutor` for dynamic adjustments, used a `ServletContextListener` to manage the thread pool lifecycle, and implemented a `Filter` to adjust the thread pool size based on HTTP request load. Finally, we tested the setup with a simple REST controller.

This approach allows your application to handle varying traffic levels efficiently by scaling the thread pool size up or down based on the current load, optimizing both performance and resource utilization.

Feel free to adjust the dynamic adjustment logic according to your specific needs and test thoroughly to ensure the best performance for your application.

https://github.com/shishirkpd/dynamic-threading

---

# Dynamic Task scheduling with Spring Boot

How many times have we had the requirement to schedule tasks ahead of time in our projects? Sometimes it seems like a major headache to write the logic to encapsulate the scheduling of a task.

→We might create a Cron job and have it invoke a jar.

→We might try a polling mechanism that polls the system time and when the time to trigger the task is reached, we perform the task. But that would be a very inefficient way to solve this problem given that most operating systems already have a Task Scheduler.

Well worry not, for Spring Boot has the Task Scheduler api that will help us achieve just this — schedule a task from anywhere to run at anytime on our system.

We will specifically be using CronTrigger to trigger the task based on the provided cron expression. Its extremely straightforward and won’t have you wracking your brains to implement your own solution.

Prerequisites:

I have created a sample Spring Boot project and am spilling the innards for you to see.
```java
@SpringBootApplication  
@EnableScheduling  
public class SchedulingappApplication {  
  
   public static void main(String[] args) {  
      SpringApplication.run(SchedulingappApplication.class, args);  
   }  
  
}
```

That is the main class and of note should be the **@EnableScheduling** annotation that allows us to run scheduling within the app.

Then we have a TaskDefinitionBean that implements Runnable and performs the unit of work in its run method.
```java
@Service  
public class TaskDefinitionBean implements Runnable {  
  
    private TaskDefinition taskDefinition;  
  
    @Override  
    public void run() {  
        System.out.println("Running action: " + taskDefinition.getActionType());  
        System.out.println("With Data: " + taskDefinition.getData());  
    }  
  
    public TaskDefinition getTaskDefinition() {  
        return taskDefinition;  
    }  
  
    public void setTaskDefinition(TaskDefinition taskDefinition) {  
        this.taskDefinition = taskDefinition;  
    }  
}
```

In this case we are simply printing the Task Definition to the console as our unit of work. This could be anything from

-   Sending an email
-   Sending a reminder notification
-   Reading data from a database and sending it elsewhere

The possibilities are limitless.

We have a TaskDefinition POJO (or TDO — Task Definition Object) that encapsulates the actual data and task definition.
```java
@Data  
public class TaskDefinition {  
  
    private String cronExpression;  
    private String actionType;  
    private String data;  
}
```

> @Data is a lombok annotation to create the getter setters in the generated class file when the code is compiled.

We have the TaskSchedulingService that actually schedules the task to be executed according to its cron expression.
```java
@Service  
public class TaskSchedulingService {  
  
    @Autowired  
    private TaskScheduler taskScheduler;  
  
    Map<String, ScheduledFuture<?>> jobsMap = new HashMap<>();  
  
    public void scheduleATask(String jobId, Runnable tasklet, String cronExpression) {  
        System.out.println("Scheduling task with job id: " + jobId + " and cron expression: " + cronExpression);  
        ScheduledFuture<?> scheduledTask = taskScheduler.schedule(tasklet, new CronTrigger(cronExpression, TimeZone.getTimeZone(TimeZone.getDefault().getID())));  
        jobsMap.put(jobId, scheduledTask);  
    }  
  
    public void removeScheduledTask(String jobId) {  
        ScheduledFuture<?> scheduledTask = jobsMap.get(jobId);  
        if(scheduledTask != null) {  
            scheduledTask.cancel(true);  
            jobsMap.put(jobId, null);  
        }  
    }  
}  
```

The **scheduleATask** method schedules the Cron job based on the provided cron expression. When the trigger time is reached, the tasklet run method will be executed and the provided TaskDefinition will be processed.

> You will also notice that we have exposed a jobsmap to store the created tasks and remove them once they are no longer needed. We use a UUID generator to generate random UUIDs to identify the created jobs an then remove them at a later time. But for the purposes of this article, we will only be talking about the scheduling and triggering of the task.

Last but not the least, we have the rest controller to allow us to schedule tasks from anywhere at anytime and for anytime.
```java
@RestController  
@RequestMapping(path = "/schedule")  
public class JobSchedulingController {  
  
    @Autowired  
    private TaskSchedulingService taskSchedulingService;  
  
    @Autowired  
    private TaskDefinitionBean taskDefinitionBean;  
  
    @PostMapping(path="/taskdef", consumes = "application/json", produces="application/json")  
    public void scheduleATask(@RequestBody TaskDefinition taskDefinition) {  
        taskDefinitionBean.setTaskDefinition(taskDefinition);  
        taskSchedulingService.scheduleATask(UuidGenerator.generateUuid(), taskDefinitionBean, taskDefinition.getCronExpression());  
    }  
  
    @GetMapping(path="/remove/{jobid}")  
    public void removeJob(@PathVariable String jobid) {  
        taskSchedulingService.removeScheduledTask(jobid);  
    }  
}  
```

Based on the provided TaskDefinition to the **/taskdef** endpoint, the TaskSchedulingService will queue the task to be executed at a later time.

Next we run the Spring Boot app to start the Task Scheduling Service. We then submit a task through postman.

I am scheduling the task to be executed at **11.24 pm** which you might thing is an oddly weird time to be executing a task but its just the time at which I was running this demo. Yes I sleep late once the midnight oil is burnt.

And we see the result of task submission helpfully printed to the console

> Scheduling task with job id: 167a3e89-a86b-4f20–85cc-961251c909ee and cron expression: 0 4 23 * * ?

And at **11.24 pm** we see the result of the execution.

> Running action: PrintDataTask  
> With Data: Data to be printed

---
# Spring Boot: Dynamic Cron Expression Changes

### Summary:

This article offers an elegant solution for dynamically changing Cron expressions in SpringBoot projects. By default, Cron expressions in SpringBoot are immutable once initialized. However, this piece introduces an approach that allows developers to dynamically alter these expressions even after the tasks have started. The solution involves retaining key task information during registration, checking for configuration changes, and replacing tasks with updated configurations. This approach offers a lightweight and elegant solution for most project scenarios without the need for additional middleware.

In SpringBoot projects, we can enable support for scheduled tasks with the `@EnableScheduling` annotation and quickly establish a series of timed tasks using the `@Scheduled` annotation.

`@Scheduled` supports three ways to configure execution timing:

-   `cron(expression)`: Executes based on a Cron expression.
-   `fixedDelay(period)`: Executes at a fixed interval, regardless of the task's execution duration; the interval between two task executions is always the same.
-   `fixedRate(period)`: Executes at a fixed frequency; tasks execute at a fixed moment after starting, and if a task execution is missed due to running too long (delayed), it is immediately executed.

The most commonly used is the first method, the execution mode based on Cron expressions, due to its relative flexibility.

### Mutable and Immutable

By default, the timing task methods marked with the `@Scheduled` annotation do not change after initialization. Spring intercepts all methods with the `@Scheduled` annotation via a post-processor after initializing the beans. It parses the corresponding annotation parameters and places them into the appropriate scheduled task list for subsequent unified execution processing. We have the opportunity to change the task's execution period and other parameters before the scheduled task actually starts.

In other words, we can specify the task’s Cron expression through the `application.properties` configuration file combined with the @Value annotation, or we can load and register scheduled tasks from a database or any other storage middleware using `CronTrigger`. This is the mutable part that Spring provides us.

But often, we want more. Is it possible to dynamically change the Cron expression or even disable a scheduled task after it has already been executed? Unfortunately, by default, this is not possible. Once a task is registered and executed, the parameters used for registration are fixed, which is the immutable part.

### Creation and Destruction

Since what is created cannot be changed, we might as well destroy it and rebuild it. Thus, our approach is to retain the key information of the task during registration and use another scheduled task to check whether the configuration has changed. If there is a change, we “kill” the predecessor and replace it. If there is no change, we keep it as it is.

Let’s abstract the task for easy identification and management:
```java
public interface IPollableService {  
    /**  
     * Execution method  
     */  
    void poll();      
      
    /**  
     * Get the cycle expression  
     *  
     * @return CronExpression  
     */  
    default String getCronExpression() {  
        return null;  
    }     
      
     /**  
     * Get the task name  
     *  
     * @return Task name  
     */  
    default String getTaskName() {  
        return this.getClass().getSimpleName();  
    }  
}
```
The most important method is `getCronExpression()`, where each timed service implementation can control its own expression, choosing whether to be mutable or immutable. As for where to get it and how to get it, I leave it to you to be creative. Next, we implement the dynamic registration of tasks:
```java
@Configuration  
@EnableAsync  
@EnableScheduling  
public class SchedulingConfiguration implements SchedulingConfigurer, ApplicationContextAware {  
    private static final Logger log = LoggerFactory.getLogger(SchedulingConfiguration.class);  
  
    private static ApplicationContext appCtx;  
  
    private final ConcurrentMap<String, ScheduledTask> scheduledTaskHolder = new ConcurrentHashMap<>(16);  
  
    private final ConcurrentMap<String, String> cronExpressionHolder = new ConcurrentHashMap<>(16);  
  
    private ScheduledTaskRegistrar taskRegistrar;      
      
    public static synchronized void setAppCtx(ApplicationContext appCtx) {  
        SchedulingConfiguration.appCtx = appCtx;  
    }      
      
    @Override  
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {  
        setAppCtx(applicationContext);  
    }      
      
    @Override  
    public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {  
        this.taskRegistrar = taskRegistrar;  
    }      
      
    /**  
     * Refresh the timing task expressions  
     */  
    public void refresh() {  
        Map<String, IPollableService> beanMap = appCtx.getBeansOfType(IPollableService.class);  
        if (beanMap.isEmpty() || taskRegistrar == null) {  
            return;  
        }  
        beanMap.forEach((beanName, task) -> {  
            String expression = task.getCronExpression();  
            String taskName = task.getTaskName();  
            if (null == expression) {  
                log.warn("The task expression for scheduled task [{}] is not configured or misconfigured, please check", taskName);  
                return;  
            }  
            // If the strategy execution time has changed, cancel the current strategy task and re-register  
            boolean unmodified = scheduledTaskHolder.containsKey(beanName) && cronExpressionHolder.get(beanName).equals(expression);  
            if (unmodified) {  
                log.info("The task expression for scheduled task [{}] has not changed, no refresh needed", taskName);  
                return;  
            }  
            Optional.ofNullable(scheduledTaskHolder.remove(beanName)).ifPresent(existTask -> {  
                existTask.cancel();  
                cronExpressionHolder.remove(beanName);  
            });  
            if (ScheduledTaskRegistrar.CRONDISABLED.equals(expression)) {  
                log.warn("The task expression for scheduled task [{}] is configured to be disabled and will not be scheduled", taskName);  
                return;  
            }  
            CronTask cronTask = new CronTask(task::poll, expression);  
            ScheduledTask scheduledTask = taskRegistrar.scheduleCronTask(cronTask);  
            if (scheduledTask != null) {  
                log.info("Scheduled task [{}] has been loaded with the current expression [{}]", taskName, expression);  
                scheduledTaskHolder.put(beanName, scheduledTask);  
                cronExpressionHolder.put(beanName, expression);  
            }  
        });  
    }  
}
```

The key is to save the reference to the `ScheduledTask` object, which is crucial for controlling the start and stop of the task. The expression "-" is used as a special marker to disable a certain scheduled task.

Of course, a disabled task can be “revived” by reassigning a new Cron expression. After completing the above steps, we still need a scheduled task to dynamically monitor and refresh the configuration of the scheduled tasks:
```java
@Component  
public class CronTaskLoader implements ApplicationRunner {  
    private static final Logger log = LoggerFactory.getLogger(CronTaskLoader.class);  
    private final SchedulingConfiguration schedulingConfiguration;  
    private final AtomicBoolean appStarted = new AtomicBoolean(false);  
    private final AtomicBoolean initializing = new AtomicBoolean(false);      
      
    public CronTaskLoader(SchedulingConfiguration schedulingConfiguration) {  
        this.schedulingConfiguration = schedulingConfiguration;  
    }      
      
    /**  
     * Scheduled task configuration refresh  
     */  
    @Scheduled(fixedDelay = 5000)  
    public void cronTaskConfigRefresh() {  
        if (appStarted.get() && initializing.compareAndSet(false, true)) {  
            log.info("Dynamic loading of scheduled tasks begins>>>>>>");  
            try {  
                schedulingConfiguration.refresh();  
            } finally {  
                initializing.set(false);  
            }  
            log.info("Dynamic loading of scheduled tasks ends<<<<<<");  
        }  
    }      
      
    @Override  
    public void run(ApplicationArguments args) {  
        if (appStarted.compareAndSet(false, true)) {  
            cronTaskConfigRefresh();  
        }  
    }  
}
```
Of course, this part of the code can be directly integrated into `SchedulingConfiguration`, but for the sake of convenience in expansion, execution and triggering are separated here. After all, in addition to triggering refreshes through scheduled tasks, you can also manually trigger refreshes through a button on the interface or through a callback via a messaging mechanism. Please feel free to develop this part according to the actual business situation.

### Verification

Let’s create a prototype project and three simple scheduled tasks to verify it. The first task has a fixed execution cycle, assuming its Cron expression will never change, like this:
```java
@Service  
public class CronTaskBar implements IPollableService {  
    @Override  
    public void poll() {  
        System.out.println("Say Bar");  
    }      
    @Override  
    public String getCronExpression() {  
        return "0/1 * * * * ?";  
    }  
}
```
The second task is one that frequently changes its execution cycle. We use a random number generator to simulate its variability:
```java
@Service  
public class CronTaskFoo implements IPollableService {  
    private static final Random random = new SecureRandom();      
    @Override  
    public void poll() {  
        System.out.println("Say Foo");  
    }      
    @Override  
    public String getCronExpression() {  
        return "0/" + (random.nextInt(9) + 1) + " * * * * ?";  
    }  
}
```

The third task is impressive, acting like a switch for a light, jumping back and forth between enabled and disabled:
```java
@Service  
public class CronTaskUnavailable implements IPollableService {  
    private String cronExpression = "-";  
    private static final Map<String, String> map = new HashMap<>();      
      
    static {  
        map.put("-", "0/1 * * * * ?");  
        map.put("0/1 * * * * ?", "-");  
    }      
      
    @Override  
    public void poll() {  
        System.out.println("Say Unavailable");  
    }      
      
    @Override  
    public String getCronExpression() {  
        return (cronExpression = map.get(cronExpression));  
    }  
}
```

If all the steps above are correct, the log should show output like this:

Dynamic loading of scheduled tasks begins>>>>>>  
The task expression for scheduled task [CronTaskBar] has not changed, no refresh needed  
Scheduled task [CronTaskFoo] has been loaded with the current expression [0/6 * * * * ?]  
The task expression for scheduled task [CronTaskUnavailable] is configured to be disabled and will not be scheduled  
Dynamic loading of scheduled tasks ends<<<<<<  
Say Bar  
Say Bar  
Say Foo  
Say Bar  
Say Bar  
Say Bar  
Dynamic loading of scheduled tasks begins>>>>>>  
The task expression for scheduled task [CronTaskBar] has not changed, no refresh needed  
Scheduled task [CronTaskFoo] has been loaded with the current expression [0/3 * * * * ?]  
Scheduled task [CronTaskUnavailable] has been loaded with the current expression [0/1 * * * * ?]  
Dynamic loading of scheduled tasks ends<<<<<<  
Say Unavailable  
Say Bar  
Say Unavailable  
Say Bar  
Say Foo  
Say Unavailable  
Say Bar  
Say Unavailable  
Say Bar  
Say Unavailable  
Say Bar

### Summary

In the above text, we implemented the requirement to dynamically change Cron expressions through periodic refresh and rebuilding of tasks. This can meet the needs of most project scenarios, and it is very lightweight and elegant without introducing additional middleware such as Quartz. Of course, if you have better methods, please do not hesitate to teach us.

---
# A Complete Guide to Memory Leaks Caused by Caffeine Cache

Hello everyone! Today I want to share with you a common but easily overlooked problem in Java development: **memory leaks caused by Caffeine cache**. As the most powerful local cache library in the current Java ecosystem, Caffeine is widely used in various projects. However, if used improperly, it may become a “memory black hole” in your system.

In this article, I will use easy-to-understand language and practical cases to deeply analyze the memory leak problem that may be caused by Caffeine cache and provide targeted solutions. Whether you are a novice who has just come into contact with Caffeine or an old hand who has been using it extensively in projects, this article is worth reading.

### Caffeine: A Quick Introduction 🚀

Caffeine is a high-performance Java cache library that provides near-optimal hit rates and excellent read and write performance. Its design is inspired by Google’s Guava Cache but has significant improvements in performance and functionality.

Caffeine’s core features include:

-   Autoloading
-   Eviction policies based on size, age, and references
-   Statistics and monitoring functions
-   Asynchronous refresh
-   Write Propagation

Think of it like this: your application needs data. Instead of always going to the (slower) data source, it first checks the super-fast Caffeine cache. If the data is there (a “hit”), awesome! If not (a “miss”), Caffeine can load it, store it, and then serve it. It also intelligently manages what to keep and what to discard based on rules like size, age, or how frequently items are used.

### Why Do Caffeine Caches Leak Memory? The Root Causes 💧

Before diving into specific cases, let’s understand the fundamental reason for memory leaks when using Caffeine.

A **memory leak** happens when objects that are no longer needed cannot be reclaimed by the garbage collector (GC), thus hogging valuable memory space. When we use a cache, we are _intentionally_ keeping objects in memory. This, by its nature, works against the GC’s goal of freeing up unused memory.

If the cache isn’t configured or used carefully, objects can remain referenced by the cache indefinitely, even when they _should_ be eligible for garbage collection. This leads to a memory leak.

When using Caffeine, the following situations are prime suspects for causing memory leaks:

1.  **The cache has no upper limit and no reasonable expiration policy**: It just keeps growing!
2.  **Improper key-value object design**: Leads to unexpected objects being held onto.
3.  **Improper cache lifecycle management**: The cache outlives its usefulness or isn’t cleaned up.
4.  **ThreadLocal cache not cleaned up correctly**: A sneaky one, especially with thread pools.

Let’s explore these with real-world (simplified) examples.

### Case 1: Memory Leak Caused by Unlimited Cache 📈

**Problem Description:** Xiao Wang was developing a user information query system. To boost performance, he used Caffeine to cache user data. His initial code looked like this:
```java
// Incorrect Example)  
Cache<String, UserInfo> userCache = Caffeine.newBuilder()  
    .build();  
  
public UserInfo getUserInfo(String userId) {  
    return userCache.get(userId, key -> loadUserFromDatabase(key));  
}
```
After the system went live, as user numbers climbed, the application server’s memory usage kept rising, eventually crashing with an `OutOfMemoryError`.

**Problem Analysis:** Xiao Wang’s seemingly simple code hid a major memory risk:

-   **No upper limit on cache size was set.**
-   **No expiration policy was set.**
-   **No eviction mechanism was defined.**

As more user data was loaded, the cache grew and grew. Without any mechanism to clean up old or excess cache items, memory was consumed relentlessly until none was left.

**Solution:** Modify the cache configuration to add reasonable size limits and expiration policies:
```java
// (Correct Example)  
Cache<String, UserInfo> userCache = Caffeine.newBuilder()  
    .maximumSize(10000)           // Set a maximum cache size  
    .expireAfterWrite(1, TimeUnit.HOURS)  // Expire items 1 hour after they are written  
    .recordStats()                // Record statistics for monitoring  
    .build();  
  
public UserInfo getUserInfo(String userId) {  
    return userCache.get(userId, key -> loadUserFromDatabase(key));  
}
```
With this setup, the cache automatically controls its size, and expired items are cleaned up, preventing unchecked memory growth.

### Case 2: Memory Leak Caused by Large Objects as Keys 🔑🐘

**Problem Description:** Xiao Li developed a document processing system and used Caffeine to cache processing results. To try and improve the cache hit rate, he used the entire `Document` object as the cache key:
```java
// (Problematic Code)  
Cache<Document, ProcessResult> resultCache = Caffeine.newBuilder()  
    .maximumSize(1000)  
    .build();  
  
public ProcessResult processDocument(Document doc) {  
    return resultCache.get(doc, this::processDocumentInternal);  
}
```

After some time, memory usage was abnormally high. Even with a cache size limit, memory kept growing.

**Problem Analysis:** The core issue is using a `Document` object, potentially containing large amounts of data (e.g., megabytes of content), as the cache key.
```java
public class Document {  
    private String id;  
    private String title;  
    private byte[] content; // Can be very large (e.g., MBs of document content)  
  
    @Override  
    public boolean equals(Object obj) {  
        if (obj instanceof Document) {  
            return ((Document) obj).id.equals(this.id);  
        }  
        return false;  
    }  
    @Override  
    public int hashCode() {  
        return id.hashCode();  
    }  
}
```
Even if `Document` correctly implements `equals()` and `hashCode()` (based on `id`, for example), the cache holds a **strong reference to the key object itself**. Each time `processDocument` is called, a new `Document` instance might be created as the key. Although the cache might recognize these `Document` objects as logically the same (due to the same `id`), it still holds references to _all these distinct_ `_Document_` _key instances_.

Over time, numerous `Document` objects, each potentially large due to its `content`, accumulate in memory because they are referenced as keys in the cache. While the cache might logically have only 1,000 entries, it could be holding onto tens of thousands of heavy `Document` key objects, preventing them from being garbage collected.

**Solution:** There are two primary ways to fix this:

-   **Use the document ID (or a lightweight representation) as the cache key:**
```java
// (Solution 1: Use ID as key)  
Cache<String, ProcessResult> resultCache = Caffeine.newBuilder()  
    .maximumSize(1000)  
    .build();  
  
public ProcessResult processDocument(Document doc) {  
    return resultCache.get(doc.getId(), id -> processDocumentInternal(doc));  
}
```
-   **If more information from the** `**Document**` **is needed for the key, create a lightweight key object:**
```java
// (Solution 2: Use a lightweight object as key)  
public class DocumentKey {  
    private final String id;  
    private final String title; // If title is part of the key  
  
    public DocumentKey(Document doc) {  
        this.id = doc.getId();  
        this.title = doc.getTitle();  
    }  
  
    @Override  
    public boolean equals(Object obj) {  
        if (obj instanceof DocumentKey) {  
            DocumentKey other = (DocumentKey) obj;  
            return this.id.equals(other.id) && Objects.equals(this.title, other.title);  
        }  
        return false;  
    }  
  
    @Override  
    public int hashCode() {  
        return Objects.hash(id, title);  
    }  
}  
  
Cache<DocumentKey, ProcessResult> resultCache = Caffeine.newBuilder()  
    .maximumSize(1000)  
    .build();  
  
public ProcessResult processDocument(Document doc) {  
    DocumentKey key = new DocumentKey(doc);  
    return resultCache.get(key, k -> processDocumentInternal(doc));  
}
```
Both approaches avoid embedding large data (like document content) within the cache key, dramatically reducing memory overhead.

### Case 3: Memory Leak Caused by Improper Value Reference Management 🖼️🔗

**Problem Description:** Xiao Zhang was developing an image processing system and used Caffeine to cache large processed images:
```java
//(Problematic Code)  
Cache<String, ProcessedImage> imageCache = Caffeine.newBuilder()  
    .maximumSize(100) // Cache up to 100 processed images  
    .build();  
  
public ProcessedImage getProcessedImage(String imageId) {  
    return imageCache.get(imageId, id -> {  
        Image originalImage = loadOriginalImage(id); // originalImage can be very large  
        return processImage(originalImage);  
    });  
}
```
Despite setting a cache size limit, memory issues could still arise after the system ran for a while.

**Problem Analysis:** The problem lies in the `ProcessedImage` class implementation:
```java
public class ProcessedImage {  
    private Image originalImage;  // Holds a reference to the original image!  
    private byte[] processedData; // The actual processed data  
  
    public ProcessedImage(Image originalImage, byte[] processedData) {  
        this.originalImage = originalImage; // This is the culprit  
        this.processedData = processedData;  
    }  
    // Other methods...  
}
```

A `ProcessedImage` object, stored as a value in the cache, not only contains the (potentially smaller) processed data but also **holds a reference to the original** `**Image**` **object**. This means each cache entry indirectly pins a large amount of memory (the original image data) for as long as the `ProcessedImage` is in the cache. Even if the cache is limited to 100 `ProcessedImage` objects, if each original image is large, the total memory footprint can be huge.

**Solution:** Modify the `ProcessedImage` class to no longer hold a reference to the original image if it's not strictly needed after processing.
```java
// (Improved ProcessedImage class)  
public class ProcessedImage {  
    private byte[] processedData; // Only store the processed data  
  
public ProcessedImage(byte[] processedData) {  
        this.processedData = processedData;  
    }  
    // Other methods...  
}  
// (Improved cache usage)  
public ProcessedImage getProcessedImage(String imageId) {  
    return imageCache.get(imageId, id -> {  
        Image originalImage = loadOriginalImage(id);  
        byte[] processedData = processImage(originalImage); // Perform processing  
        // originalImage is now only in local scope and can be GC'd after this lambda  
        return new ProcessedImage(processedData);  
    });  
}
```

This way, once the cache loading function completes, the `originalImage` (which is local to the lambda) can be garbage collected if not referenced elsewhere, significantly reducing the memory held by each cache entry.

### Case 4: ThreadLocal Cache Not Cleaned Up Correctly 🧵🧹

**Problem Description:** Xiao Zhao was developing a high-concurrency processing system. To avoid cache contention between threads, he opted to give each thread its own dedicated Caffeine cache using `ThreadLocal`:
```java
// (Problematic Code)  
private static final ThreadLocal<Cache<String, ExpensiveObject>> THREAD_LOCAL_CACHE =  
    ThreadLocal.withInitial(() -> Caffeine.newBuilder()  
        .maximumSize(1000)  
        .build());  
  
public ExpensiveObject processData(String key) {  
    Cache<String, ExpensiveObject> cache = THREAD_LOCAL_CACHE.get();  
    return cache.get(key, this::loadExpensiveObject);  
}
```

During testing, even when the load decreased, memory usage continued to climb. The server eventually hit an OOM error after running for an extended period. This is especially problematic in environments using thread pools (like web servers), where threads are reused. If `ThreadLocal` values aren't cleaned up, their associated cache instances (and the data within them) survive with the thread for a long time.

**Problem Analysis:** The issue is that `ThreadLocal` is used to store Caffeine cache instances, but these instances are **never properly cleaned up**. In a thread pool environment (common in application servers), threads are not terminated after a task but are returned to the pool for reuse. Therefore, each reused thread retains its `ThreadLocal` Caffeine cache instance, which accumulates data over time.

Even if each individual cache instance has a size limit, the _total_ memory usage across many long-lived, reused threads can become substantial. When a thread finishes a task and goes back to the pool, its `ThreadLocal` cache (and all its entries) remains, leading to prolonged data retention and memory bloat.

**Solution:** Here are a couple of recommended solutions:

-   **Clean up the** `**ThreadLocal**` **after each use (Recommended):**
```java
// (Solution 1: Clean up after use - Recommended)  
public ExpensiveObject processData(String key) {  
    Cache<String, ExpensiveObject> cache = THREAD_LOCAL_CACHE.get();  
    try {  
        return cache.get(key, this::loadExpensiveObject);  
    } finally {  
        // Clean up the ThreadLocal value for the current thread  
        // This removes the cache instance associated with this thread for this ThreadLocal  
        THREAD_LOCAL_CACHE.remove();  
    }  
}
```
-   **Use a shared, concurrency-safe cache instead of** `**ThreadLocal**` **cache (Often a better approach):**
```java
// (Solution 2: Use a concurrency-safe shared cache - Recommended)  
private static final Cache<String, ExpensiveObject> SHARED_CACHE =  
    Caffeine.newBuilder()  
        .maximumSize(5000) // Adjust size for shared use  
        .build();  
  
public ExpensiveObject processData(String key) {  
    return SHARED_CACHE.get(key, this::loadExpensiveObject);  
}
```
A third option, periodically cleaning all threads’ `ThreadLocal` caches, is complex, potentially unreliable (due to accessing thread internals via reflection), and generally not advised over the other two solutions.

It’s usually best to **avoid** `**ThreadLocal**` **for caching unless absolutely necessary** for strong thread isolation with a lifecycle shorter than the thread itself. If you must use it, ensure meticulous cleanup via `remove()`.

### Case 5: Memory Leak Caused by Custom Loader (Non-Static Inner Class) 🎁➡️🗑️

**Problem Description:** Xiao Chen implemented a data analysis system and used Caffeine with a custom `CacheLoader`:
```java
//(Problematic Code)  
LoadingCache<String, AnalysisResult> analysisCache = Caffeine.newBuilder()  
    .maximumSize(500)  
    .build(new CacheLoader<String, AnalysisResult>() { // Anonymous inner class  
        private final DataProcessor processor = new ExpensiveDataProcessor(); // Heavy object  
          
        @Override  
        public AnalysisResult load(String key) throws Exception {  
            Data data = fetchData(key);  
            return processor.analyze(data);  
        }  
    });
```
The system exhibited abnormally high memory usage and didn’t free up the expected amount of memory even after cache items were evicted.

**Problem Analysis:** The problem stems from using a **non-static inner class** (in this case, an anonymous inner class) as the `CacheLoader`. A non-static inner class implicitly holds a reference to an instance of its outer class. Additionally, `DataProcessor` is instantiated as a field within this inner class and is a heavyweight object:
```java
public class ExpensiveDataProcessor {  
    private final byte[] largeBuffer = new byte[100 * 1024 * 1024]; // 100MB buffer!  
    private final Map<String, Object> processingState = new HashMap<>();  
    // Other fields and methods...  
}
```

Even if a cache entry (and its `AnalysisResult`) is evicted, the `CacheLoader` instance itself is still held by the `LoadingCache`. Because the `CacheLoader` is a non-static inner class, it retains a reference to its enclosing class instance (if any). More importantly here, the `CacheLoader` instance itself holds a strong reference to the `ExpensiveDataProcessor` instance. This `ExpensiveDataProcessor` (with its 100MB buffer and other resources) cannot be garbage collected as long as the `CacheLoader` is alive, which is for the lifetime of the cache. This leads to a memory leak.

**Solution:** There are three good ways to resolve this:

-   **Using Lambda expressions (often the cleanest):** Lambdas (if they don’t capture `this` of the enclosing class in a problematic way or are effectively static) won't hold onto the outer class instance in the same problematic manner for this specific `CacheLoader` scenario. The `DataProcessor` can be instantiated within the lambda.
```java
// (Solution 1: Use Lambda expression)  
LoadingCache<String, AnalysisResult> analysisCache = Caffeine.newBuilder()  
    .maximumSize(500)  
    .build(key -> {  
        // Processor is created only when needed and is local to the load method  
        DataProcessor processor = new ExpensiveDataProcessor();  
        Data data = fetchData(key);  
        return processor.analyze(data);  
        // processor goes out of scope here, allowing GC if not referenced elsewhere  
    });
```
-   **Using a static inner class:** Static inner classes do not hold an implicit reference to the outer class instance.
```java
// (Solution 2: Use a static inner class)  
private static class AnalysisLoader implements CacheLoader<String, AnalysisResult> {  
    @Override  
    public AnalysisResult load(String key) throws Exception {  
        DataProcessor processor = new ExpensiveDataProcessor(); // Create per load  
        Data data = fetchData(key);  
        return processor.analyze(data);  
    }  
}  
  
LoadingCache<String, AnalysisResult> analysisCache = Caffeine.newBuilder()  
    .maximumSize(500)  
    .build(new AnalysisLoader());
```
-   **Using a standalone (separate) class:** A completely separate class also avoids the implicit outer class reference.
```java
// (Solution 3: Use a standalone class)  
public class StandaloneAnalysisLoader implements CacheLoader<String, AnalysisResult> {  
    @Override  
    public AnalysisResult load(String key) throws Exception {  
        DataProcessor processor = new ExpensiveDataProcessor(); // Create per load  
        Data data = fetchData(key);  
        return processor.analyze(data);  
    }  
}  
  
LoadingCache<String, AnalysisResult> analysisCache = Caffeine.newBuilder()  
    .maximumSize(500)  
    .build(new StandaloneAnalysisLoader());
```
These solutions ensure that the `CacheLoader` doesn't inadvertently cause the `LoadingCache` to hold long-term references to large resources like `ExpensiveDataProcessor` beyond their necessary lifespan.

### How to Detect and Monitor Caffeine Memory Leaks 🕵️‍♂️📊

To discover and pinpoint Caffeine-related memory leaks, you can use these techniques:

### **JVM Memory Monitoring:**

-   Use tools like **VisualVM, JConsole, or Java Mission Control (JMC)** to monitor JVM memory usage. Keep an eye on memory trends, especially the growth of the old generation heap space. A constantly increasing old gen, even after GCs, is a red flag.

### **Heap Dump Analysis:**

-   When a memory leak is suspected, generate a **heap dump** and analyze it using tools like **Eclipse MAT (Memory Analyzer Tool)** or IntelliJ’s built-in analyzer.
-   You can trigger a heap dump programmatically (e.g., using `java.lang.management.ManagementFactory.getPlatformMBeanServer()`) or via tools like `jmap`:
```shell
jmap -dump:format=b,file=heap.hprof <pid>
```
-   In MAT, look for Caffeine cache-related objects (e.g., `com.github.benmanes.caffeine.cache.BoundedLocalCache`) and inspect their retained sizes and the reference chains (Paths to GC Roots) to see what's holding onto them.

### **Enable Caffeine Statistics:**

-   Caffeine provides built-in statistics to help you understand cache usage. This is invaluable!
```java
Cache<Key, Value> cache = Caffeine.newBuilder()  
    .maximumSize(10_000)  
    .recordStats() // Enable statistics recording!  
    .build();  
  
// Later, to get stats:  
CacheStats stats = cache.stats();  
System.out.println("Cache estimated size: " + cache.estimatedSize());  
System.out.println("Hit rate: " + stats.hitRate());  
System.out.println("Eviction count: " + stats.evictionCount());  
System.out.println("Load success count: " + stats.loadSuccessCount());  
System.out.println("Load failure count: " + stats.loadFailureCount());  
System.out.println("Total load time: " + stats.totalLoadTime() + " ns");
```
-   Monitoring cache size, hit rate, miss rate, eviction count, and load times can help you determine if the cache is behaving as expected or if, for example, evictions aren’t happening when they should.

### **Add JMX Monitoring (Advanced):**

For real-time monitoring in production environments, you can expose Caffeine cache statistics via JMX MBeans. This allows tools like JConsole or VisualVM to connect and view live cache metrics.
```java
// 1. Define an MXBean interface  
public interface CacheStatsMXBean {  
    long getEstimatedSize();  
    double getHitRate();  
    long getEvictionCount();  
    long getLoadSuccessCount();  
    long getLoadFailureCount();  
    // ... other stats you want to expose  
}  
  
// 2. Implement the interface  
public class CaffeineCacheStatsMBean implements CacheStatsMXBean {  
    private final Cache<?, ?> cache;  
    private final com.github.benmanes.caffeine.cache.stats.CacheStats caffeineStats;  
  
    public CaffeineCacheStatsMBean(Cache<?, ?> cache) {  
        this.cache = cache;  
        // It's better to get a snapshot of stats if you have a stats counter enabled  
        // Or ensure your cache is configured with .recordStats()  
        this.caffeineStats = cache.stats(); // Get a snapshot  
    }  
  
    @Override  
    public long getEstimatedSize() {  
        return cache.estimatedSize();  
    }  
  
    @Override  
    public double getHitRate() {  
        return cache.stats().hitRate(); // Get current stats  
    }  
  
    @Override  
    public long getEvictionCount() {  
        return cache.stats().evictionCount();  
    }  
  
    @Override  
    public long getLoadSuccessCount() {  
        return cache.stats().loadSuccessCount();  
    }  
  
    @Override  
    public long getLoadFailureCount() {  
        return cache.stats().loadFailureCount();  
    }  
    // ... implement other methods  
}  
  
// 3. Register the MBean  
// MBeanServer mBeanServer = ManagementFactory.getPlatformMBeanServer();  
// ObjectName name = new ObjectName("com.yourapp:type=Cache,name=UserCacheMetrics");  
// CaffeineCacheStatsMBean mbean = new CaffeineCacheStatsMBean(userCache); // your actual cache instance  
// mBeanServer.registerMBean(mbean, name);
```
-   _Note: For live updating stats in JMX, you’d typically need the MBean methods to call_ `_cache.stats()_` _directly or have a mechanism to periodically refresh the_ `_caffeineStats_` _field._ Caffeine's `Cache.stats()` method returns an immutable snapshot, so calling it each time in the MBean getter is appropriate for up-to-date values.

### Strategies for Preventing Caffeine Memory Leaks 🛡️

Prevention is always better than cure!

-   **Properly Configure Cache Size:** _Always_ set a maximum cache size based on expected usage and available memory.
```java
Cache<Key, Value> cache = Caffeine.newBuilder()  
    .maximumSize(10_000)  // Max number of entries  
    // OR, use maximumWeight for more fine-grained control  
    // .maximumWeight(10_000_000) // e.g., 10MB if weight is in bytes  
    // .weigher((Key key, Value value) -> calculateSizeOf(value)) // Custom weigher  
    .build();
```
-   **Use an Appropriate Expiration Strategy:** Configure expiration policies based on data freshness requirements.
```java
Cache<Key, Value> cache = Caffeine.newBuilder()  
    .expireAfterWrite(10, TimeUnit.MINUTES)    // Expire 10 mins after last write  
    // .expireAfterAccess(5, TimeUnit.MINUTES)   // Expire 5 mins after last access  
    // .expireAfter(new Expiry<Key, Value>() {    // Custom expiration logic  
    //     @Override  
    //     public long expireAfterCreate(Key key, Value value, long currentTime) {  
    //         // Return nanoseconds until expiry  
    //         return value.getCustomExpirationNanos();  
    //     }  
    //     @Override  
    //     public long expireAfterUpdate(Key key, Value value, long currentTime, long currentDuration) {  
    //         return currentDuration; // Keep existing duration  
    //     }  
    //     @Override  
    //     public long expireAfterRead(Key key, Value value, long currentTime, long currentDuration) {  
    //         return currentDuration; // Keep existing duration  
    //     }  
    // })  
    .build();
```
-   **Consider Weak References (Use with Caution):** Use weak references when the lifecycle of a cache item should be tied to external object reachability. This allows entries to be GC’d if the key or value is no longer strongly referenced elsewhere.
```java
Cache<Key, Value> cache = Caffeine.newBuilder()  
    .weakKeys()       // Keys are weak references  
    // .weakValues()     // Values are weak references  
    .build();
```
-   **Important:** Weak references should _not_ be your primary strategy for managing memory. Sensible size limits and time-based expiration policies should be prioritized. Weak references are a supplementary mechanism.
-   `weakKeys()`: If a key object has no other strong references outside the cache, the cache entry can be collected by the GC. Useful if key lifecycle is managed externally.
-   `weakValues()`: If a value object has no other strong references outside the cache, the cache entry can be collected. Useful if the cache is a "secondary" reference.

**Notes:** GC timing for weak references is non-deterministic. They can increase GC pressure. Keys still need correct `equals()`/`hashCode()`.

-   **Regular Manual Cleanup (If Necessary):** For some long-running applications or specific scenarios, you might consider periodic manual cleanup, although well-configured eviction policies usually suffice.
```java
// cache.cleanUp(); // Manually performs maintenance, including removing expired entries  
// This is often called by Caffeine internally on writes and sometimes on reads.  
// Explicitly calling it might be needed if you have very few writes.  
// Example:  
// ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();  
// executor.scheduleAtFixedRate(cache::cleanUp, 1, 1, TimeUnit.HOURS);
```
-   **Use Lightweight Key and Value Objects:** Design dedicated, lightweight objects for cache keys and, where possible, for values. Avoid inadvertently referencing large objects or objects with complex lifecycles within your cache keys/values if that data isn’t essential for the caching logic itself.
```java
// Lightweight cache key example  
public class UserCacheKey {  
    private final String userId;  
    // Potentially other lightweight attributes that define uniqueness  
  
    public UserCacheKey(String userId /*...*/) {  
        this.userId = userId;  
    }  
    // equals and hashCode MUST be implemented correctly!  
    @Override  
    public boolean equals(Object o) { /* ... */ }  
    @Override  
    public int hashCode() { /* ... */ }  
}  
```
// Cache<UserCacheKey, UserData> cache = ...

### Summary: Key Takeaways 📝

![](https://miro.medium.com/v2/resize:fit:875/1*VRPCaNg6Fr3YPh_bRu_AGQ.png)

By understanding these common pitfalls and applying the suggested solutions and preventative strategies, you should be better equipped to use Caffeine cache effectively without inadvertently introducing memory leaks. Cache is a powerful tool: wield it wisely!

Thank you for your patience in reading this article! If you found this article helpful, please give it a clap 👏, bookmark it ⭐, and share it with friends in need. Your support is my biggest motivation to continue to output technical insights!

---
# Spring Boot @DynamicUpdate

**Introduction**

In Hibernate, the `@DynamicUpdate` annotation is used to dynamically generate an SQL update statement at runtime, considering only the modified properties of an entity. By default, Hibernate generates an SQL update statement that includes all the properties of an entity, regardless of whether they have been modified or not. However, with the `@DynamicUpdate` annotation, Hibernate optimizes the update process by only including the modified properties in the generated update statement. This can improve the performance of update operations, especially when dealing with large entities.

**Benefits of @DynamicUpdate Annotation**

- **Reduced network traffic**: By including only the modified properties in the update statement, the `@DynamicUpdate` annotation reduces the amount of data sent over the network. This can be particularly beneficial when working with entities that have a large number of properties, as it minimizes the size of the update statement.
- **Improved performance**: Since the generated update statement includes only the modified properties, executing the update query becomes more efficient. The database server needs to process less data, resulting in improved performance for update operations.
- **Data integrity preservation**: By updating only the modified properties, the `@DynamicUpdate` annotation helps in preserving the integrity of the remaining properties of an entity. This is particularly useful when multiple users or processes are concurrently modifying the same entity, as it reduces the chances of unintentionally overwriting changes made by other users.

**Using @DynamicUpdate Annotation**

To use the `@DynamicUpdate` annotation in Hibernate, you need to annotate your entity class with it. Here's an example:

```java
@Entity
@DynamicUpdate
public class Product {
    @Id
    private Long id;

    @Column
    private String name;

    @Column
    private double price;

    // Getters and setters
}
```

In the above example, the `@DynamicUpdate` annotation is added to the `Product` entity class. This ensures that only the modified properties (`name` and `price`) will be included in the generated SQL update statement.

**Conclusion**

The `@DynamicUpdate` annotation in Hibernate is a useful tool for optimizing update operations on entities. By dynamically generating update statements that include only the modified properties, it reduces network traffic, improves performance, and helps in preserving data integrity. When working with large entities or scenarios where concurrent updates occur, using `@DynamicUpdate` can be particularly beneficial. By leveraging this annotation, developers can optimize their Hibernate-based applications and achieve better performance and efficiency in update operations.



<iframe height="0" width="0" src="https://www.googletagmanager.com/static/serviceworker/55j0/swiframe.html?origin=https%3A%2F%2Fmedium.com" style="display: none; visibility: hidden;"></iframe>

---

# 🎚️ Spring Boot @ConditionalOnProperty  — Enable or Disable Beans with a Switch

In complex Spring Boot applications, you often want to enable or disable beans based on configuration. That’s where `@ConditionalOnProperty` shines.

Let’s dive into what it is, how it works, and how you can use it like a pro. 👇

### ✅ What Is `@ConditionalOnProperty`?

`@ConditionalOnProperty` is a Spring Boot annotation used to **conditionally register beans** based on the presence and value of a configuration property.

It gives you the flexibility to **toggle features**, switch implementations, or activate behaviors per environment — all without touching your code.

🔧 Basic Syntax
```java
@ConditionalOnProperty(  
    name = "property.name",  
    havingValue = "expectedValue",  
    matchIfMissing = false  
)
```
![](https://miro.medium.com/v2/resize:fit:875/1*em1SHNo0-GFygwoV8GpcpA.png)

### 🪜 Step-by-Step Example

### 🎯 Goal: Enable a service only when a flag is true

### 1️⃣ Create a service class
```java
public class EmailService {  
    public void send() {  
        System.out.println("Email sent!");  
    }  
}
```
2️⃣ Configure with `@ConditionalOnProperty`
```java
@Configuration  
public class ServiceConfig {  
  
    @Bean  
    @ConditionalOnProperty(  
        name = "feature.email.enabled",  
        havingValue = "true",  
        matchIfMissing = false  
    )  
    public EmailService emailService() {  
        return new EmailService();  
    }  
}
```
3️⃣ Add to `application.properties`
```shell
feature.email.enabled=true
```
👉 When this property is `true`, the `EmailService` bean is created.

### 🧪 Real-World Use Cases

### 1. 🔁 Switch Between Dev and Prod Beans
```java
@Bean  
@ConditionalOnProperty(name = "env.type", havingValue = "dev")  
public DataSource devDataSource() {  
    return new H2DataSource();  
}  
  
@Bean  
@ConditionalOnProperty(name = "env.type", havingValue = "prod")  
public DataSource prodDataSource() {  
    return new OracleDataSource();  
}
```
2. 🧪 Enable Metrics, Logging, or Monitoring
```java
@Bean  
@ConditionalOnProperty(name = "feature.prometheus.enabled", havingValue = "true")  
public PrometheusExporter prometheusExporter() {  
    return new PrometheusExporter();  
}
```
### 🤔 What If the Property Is Missing?

Use `matchIfMissing = true` to default-enable the bean:
```java
@ConditionalOnProperty(  
    name = "feature.x.enabled",  
    havingValue = "true",  
    matchIfMissing = true  
)
```
➡️ This will enable the bean **if the property is missing or set to** `**true**`.

### 🚫 Tips

-   The property **must be in your environment** (e.g., `.properties`, `.yml`, or environment variable).
-   For `havingValue`, match is **case-sensitive**.
-   Works only in **Spring Boot** (not plain Spring Framework).

### 📦 Perfect for Auto-Configurations

If you’re writing a **starter module or library**, use `@ConditionalOnProperty` to make features optional and easily controlled by consumers.

### 🧵 Final Thoughts

`@ConditionalOnProperty` is a hidden gem in Spring Boot. It’s simple yet powerful — helping you build **flexible, configurable, and environment-aware** applications with just a few lines of code.

---

# Spring Boot @EventListener

The `@EventListener` annotation in Spring Framework is used to handle events in an application. This can be applied to methods in any Spring-managed component to listen for specific application events, both predefined and custom.

It is part of the Spring event-driven programming model, which promotes loose coupling between components. You can leverage `@EventListener` to react to certain actions or changes within your application, such as a user registration, order placement, or application startup.

# Key Features of `@EventListener`

1.  **Event-Driven Architecture**: Facilitates decoupled communication between components.
2.  **Handles Custom and Built-In Events**: Works with predefined Spring events (`ContextRefreshedEvent`, `ApplicationReadyEvent`, etc.) or user-defined events.
3.  **Asynchronous Handling**: Can be combined with `@Async` for non-blocking event processing.
4.  **Conditional Listening**: Use SpEL (Spring Expression Language) with `condition` attribute to listen based on conditions.

# Example Use Cases of `@EventListener`

## 1. Custom Event Handling

When a user registers, trigger an event to send a welcome email.
```java
// Custom Event Class  
public class UserRegisteredEvent {  
    private final String username;  
  
    public UserRegisteredEvent(String username) {  
        this.username = username;  
    }  
    public String getUsername() {  
        return username;  
    }  
}  
// Event Publisher  
@Component  
public class UserService {  
    @Autowired  
    private ApplicationEventPublisher eventPublisher;  
    public void registerUser(String username) {  
        // Perform registration logic here...  
        System.out.println("User registered: " + username);  
        // Publish event  
        eventPublisher.publishEvent(new UserRegisteredEvent(username));  
    }  
}  
// Event Listener  
@Component  
public class WelcomeEmailService {  
    @EventListener  
    public void handleUserRegistered(UserRegisteredEvent event) {  
        System.out.println("Sending welcome email to: " + event.getUsername());  
    }  
}  
// Controller to trigger the event  
@RestController  
public class UserController {  
    @Autowired  
    private UserService userService;  
    @PostMapping("/register")  
    public String registerUser(@RequestBody String username) {  
        userService.registerUser(username);  
        return "User Registered!";  
    }  
}
```

## 2. Built-In Event Handling

Automatically perform an action when the application starts, like initializing resources.
```java
@Component  
public class StartupListener {  
    @EventListener(ApplicationReadyEvent.class)  
    public void onApplicationReady() {  
        System.out.println("Application is ready! Performing startup tasks...");  
    }  
}
```

## 3. Asynchronous Event Handling

If the event handling process is time-consuming, use `@Async` for non-blocking execution.
```java
@Configuration  
@EnableAsync  
public class AsyncConfig {  
    @Bean  
    public Executor taskExecutor() {  
        return new SimpleAsyncTaskExecutor();  
    }  
}  
  
@Component  
public class NotificationService {  
    @Async  
    @EventListener  
    public void sendNotification(UserRegisteredEvent event) {  
        System.out.println("Processing notification for user: " + event.getUsername());  
        // Simulate delay  
        try {  
            Thread.sleep(3000);  
        } catch (InterruptedException e) {  
            Thread.currentThread().interrupt();  
        }  
        System.out.println("Notification sent for: " + event.getUsername());  
    }  
}
```

## 4. Conditional Listening

Handle events based on specific conditions using the `condition` attribute.
```java
@Component  
public class AdminNotificationService {  
    @EventListener(condition = "#event.username == 'admin'")  
    public void notifyAdmin(UserRegisteredEvent event) {  
        System.out.println("Special handling for admin user: " + event.getUsername());  
    }  
}
```
More complex conditional examples
```java
@EventListener(condition = "#event.user=='arvind'")     // Equality  
@EventListener(condition = "#event.user!='arvind'")     // Inequality  
@EventListener(condition = "#event.age > 18")           // Greater than  
@EventListener(condition = "#event.age >= 18")          // Greater than or equal  
@EventListener(condition = "#event.age < 18")           // Less than  
@EventListener(condition = "#event.age <= 18")          // Less than or equal  
@EventListener(condition = "#event.user matches 'ar.*'") // Regex match  
@EventListener(condition = "#event.role.equals('ADMIN')") // Object equality  
  
// Logical operators  
@EventListener(condition = "#event.age > 18 and #event.user=='arvind'")  // AND  
@EventListener(condition = "#event.age > 18 or #event.user=='arvind'")   // OR  
@EventListener(condition = "!#event.isDeleted")                          // NOT  
  
// Collection operations  
@EventListener(condition = "#event.roles.contains('ADMIN')")             // Contains  
@EventListener(condition = "#event.tags.size() > 0")                     // Size check  
  
// Null checks  
@EventListener(condition = "#event.user != null")                        // Not null  
  
@EventListener(condition = "#event.user?.length() > 5")  // Safe navigation  
@EventListener(condition = "#event instanceof T(com.example.AdminEvent)") // Type check  
@EventListener(condition = "#event.timestamp > T(java.time.Instant).now().minusSeconds(3600)") // Time comparison
```

# Benefits of Using `@EventListener`

-   **Decoupling**: Event publishers and listeners don’t depend on each other, promoting better modularity.
-   **Flexibility**: Listeners can act on multiple types of events, reducing repetitive code.
-   **Scalability**: With asynchronous event processing, applications can handle multiple events without blocking.

---
# Master-Slave Architecture in Spring Boot @useslave with Just One Annotation — @UseSlave

Modern backend systems often deal with heavy read and write workloads. To maintain performance, it’s common to separate these operations using a Master-Slave (Primary-Replica) database architecture. But integrating that seamlessly in a Spring Boot application, without littering your codebase with plumbing logic, is where things get interesting.

Let’s walk through how you can implement dynamic datasource routing with just one annotation: `@UseSlave`.

![](https://miro.medium.com/v2/resize:fit:863/1*Attp-TqPpggwgPl9H_tgAg.png)

### Why Master-Slave?

The idea is simple:

-   Writes go to the master (primary) DB.
-   Reads are served from replicas (slaves) to offload pressure from the master.

This improves read throughput and ensures that long-running read-heavy queries (like analytics, reporting, joins, etc.) don’t block writes.

### Goal

Our goal is to route read-only operations to a slave database just by annotating a method with `@UseSlave`, like this:
```java
@UseSlave  
public List<User> fetchUsersByCity(String city) {  
    return userRepository.findByCity(city);  
}
```
Behind the scenes, Spring will switch the DataSource context for this method to use the slave DB.

### Overall Design

Before starting with the implementation, let us look at the overall design using an ASCII diagram.

                           ┌────────────────────┐  
                           │     @UseSlave      │  
                           │   (Annotation)     │  
                           └────────┬───────────┘  
                                    │  
                                    ▼  
         ┌────────────────────────────────────────────┐  
         │           Service Layer (UserService)       │  
         └────────────────┬────────────────────────────┘  
                          │  
          ┌───────────────┴────────────────┐  
          ▼                                ▼  
  ┌───────────────────┐          ┌────────────────────┐  
  │ DataSourceContext │          │ Repository Layer    │  
  │   Holder (AOP)    │─────────▶│ (JPA/Hibernate)     │  
  └───────────────────┘          └──────────┬──────────┘  
                                            │  
                                            ▼  
                  ┌────────────────────────────────────────┐  
                  │     RoutingDataSource (ThreadLocal)     │  
                  └────────────┬──────────────┬─────────────┘  
                               │              │  
                               ▼              ▼  
                     ┌──────────────┐   ┌──────────────┐  
                     │   Master DB  │   │   Slave DB   │  
                     │ (Read/Write) │   │   (Read-Only)│  
                     └──────────────┘   └──────────────┘

### Step-by-Step Implementation

### 1. Define DataSources

Configure at least two data sources — master and slave:
```yaml
spring:  
  datasource:  
    master:  
      url: jdbc:postgresql://master-db:5432/app  
      username: postgres  
      password: pass  
    slave:  
      url: jdbc:postgresql://slave-db:5432/app  
      username: postgres  
      password: pass
```
### 2. Define a Routing DataSource

Use an `AbstractRoutingDataSource` to dynamically resolve which datasource to use.
```java
public class RoutingDataSource extends AbstractRoutingDataSource {  
    @Override  
    protected Object determineCurrentLookupKey() {  
        return DataSourceContextHolder.getDataSourceType(); // MASTER or SLAVE  
    }  
}
```
### 3. DataSource Context Holder

This keeps track of the current datasource in a `ThreadLocal`.
```java
public class DataSourceContextHolder {  
    private static final ThreadLocal<String> CONTEXT = new ThreadLocal<>();  
  
    public static void setDataSourceType(String type) {  
        CONTEXT.set(type);  
    }  
  
    public static String getDataSourceType() {  
        return CONTEXT.get() == null ? "MASTER" : CONTEXT.get();  
    }  
  
    public static void clear() {  
        CONTEXT.remove();  
    }  
}
```
### 4. Create the `@UseSlave` Annotation
```java
@Target({ElementType.METHOD})  
@Retention(RetentionPolicy.RUNTIME)  
public @interface UseSlave {}
```
### 5. Route Using AOP

Use an Aspect to intercept methods annotated with `@UseSlave` and switch the datasource context accordingly.
```java
@Aspect  
@Component  
public class DataSourceAspect {  
  
    @Before("@annotation(com.example.UseSlave)")  
    public void setSlaveDataSource() {  
        DataSourceContextHolder.setDataSourceType("SLAVE");  
    }  
  
    @After("@annotation(com.example.UseSlave)")  
    public void clearDataSource() {  
        DataSourceContextHolder.clear();  
    }  
}
```
### 6. Configure the DataSource Bean
```java
@Configuration  
public class DataSourceConfig {  
  
    @Bean  
    @Primary  
    public DataSource dataSource() {  
        Map<Object, Object> dataSources = new HashMap<>();  
        dataSources.put("MASTER", masterDataSource());  
        dataSources.put("SLAVE", slaveDataSource());  
  
        RoutingDataSource routingDataSource = new RoutingDataSource();  
        routingDataSource.setTargetDataSources(dataSources);  
        routingDataSource.setDefaultTargetDataSource(masterDataSource());  
  
        return routingDataSource;  
    }  
  
    @Bean  
    public DataSource masterDataSource() {  
        return DataSourceBuilder.create()  
            .url("jdbc:postgresql://master-db:5432/app")  
            .username("postgres")  
            .password("pass")  
            .build();  
    }  
  
    @Bean  
    public DataSource slaveDataSource() {  
        return DataSourceBuilder.create()  
            .url("jdbc:postgresql://slave-db:5432/app")  
            .username("postgres")  
            .password("pass")  
            .build();  
    }  
}
```
### Benchmark

We tested this setup on a production-like workload:

-   80% reads, 20% writes.
-   Heavy join queries moved to slave using `@UseSlave`.

**Results**:

-   45% decrease in average read latency.
-   20–30% reduction in CPU load on master DB.
-   0 code changes in repository/service logic apart from the annotation.

### Where This Shines

-   Non-invasive: One annotation. Zero boilerplate.
-   Composable: Works with Spring AOP — no custom proxies.
-   Safe: ThreadLocal ensures routing is request-bound.

### Gotchas

-   Replication lag: Ensure your replicas are synced for strong consistency use cases.
-   Avoid in write methods — don’t use `@UseSlave` where writes/updates happen, even indirectly.
-   Use it only on top-level service methods — not within private or nested calls.

### Final Thoughts

This pattern lets you introduce read-write splitting elegantly without rewriting your application logic. With `@UseSlave`, you control routing declaratively and cleanly — the way Spring was meant to be used.

If you’re scaling a Spring-based monolith or migrating to microservices, this architecture gives you an edge with minimal changes and maximum payoff.

---
# Micrometer — Custom Gauge Metric Type Implementation In Spring Boot

In this article, we will:

-   Create custom metric of type “Gauge” such that it should be visible under “/actuator/metrics”.
-   Why would someone choose Gauge over Counter and vice-versa ?

> If you are not the paid member then read this article [**here**](/@sehgal.mohit06/micrometer-custom-gauge-metric-type-implementation-in-spring-boot-d886e7c9e303?sk=07dd6e81e68bc4a20019f0c13200623c).

Lets Go though the spring boot application below:

There is a restController with just one endpoint. In the service layer, I have created a hardcoded HashMap that takes name of a student as key and marks of that student as value. RestController has one GET endpoint that takes name and marks as path variables. It will add the name/marks key/value pair to the map.

The requirement is to create metric that would measure the number of entries in the map. We should show marks of each student as value attached to tags with “name” as tag name and marks value as tag value.

Do not worry if my previous statement is not making any sense to you. I will share screenshot of the output on how it must be.

1.  application.properties:
```shell
spring.application.name=metrics  
server.port=19000  
management.endpoints.web.exposure.include=*
```
2. pom.xml:
```xml
<?xml version="1.0" encoding="UTF-8"?>  
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  
 xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">  
 <modelVersion>4.0.0</modelVersion>  
 <parent>  
  <groupId>org.springframework.boot</groupId>  
  <artifactId>spring-boot-starter-parent</artifactId>  
  <version>3.3.3</version>  
  <relativePath/> <!-- lookup parent from repository -->  
 </parent>  
 <groupId>com.custom.app</groupId>  
 <artifactId>metrics</artifactId>  
 <version>0.0.1-SNAPSHOT</version>  
 <name>metrics</name>  
 <description>Demo project for Spring Boot</description>  
 <url/>  
 <licenses>  
  <license/>  
 </licenses>  
 <developers>  
  <developer/>  
 </developers>  
 <scm>  
  <connection/>  
  <developerConnection/>  
  <tag/>  
  <url/>  
 </scm>  
 <properties>  
  <java.version>17</java.version>  
 </properties>  
 <dependencies>  
  <dependency>  
   <groupId>org.springframework.boot</groupId>  
   <artifactId>spring-boot-starter-actuator</artifactId>  
  </dependency>  
  <dependency>  
   <groupId>org.springframework.boot</groupId>  
   <artifactId>spring-boot-starter-web</artifactId>  
  </dependency>  
  
  <dependency>  
   <groupId>org.springframework.boot</groupId>  
   <artifactId>spring-boot-starter-test</artifactId>  
   <scope>test</scope>  
  </dependency>  
 </dependencies>  
  
 <build>  
  <plugins>  
   <plugin>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-maven-plugin</artifactId>  
   </plugin>  
   <plugin>  
    <groupId>com.diffplug.spotless</groupId>  
    <artifactId>spotless-maven-plugin</artifactId>  
    <version>2.43.0</version>  
  
   </plugin>  
  </plugins>  
 </build>  
  
</project>
```
3. Main Class:
```java
package com.custom.app.metrics;  
  
import org.springframework.boot.SpringApplication;  
import org.springframework.boot.autoconfigure.SpringBootApplication;  
  
@SpringBootApplication  
public class MetricsApplication {  
  
 public static void main(String[] args) {  
  SpringApplication.run(MetricsApplication.class, args);  
 }  
  
}
```
4. RestController:
```java
package com.custom.app.metrics;  
  
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.PathVariable;  
import org.springframework.web.bind.annotation.RestController;  
  
@RestController  
public class MarksRestController {  
  
    private final CustomMetricSource customMetricSource;  
  
    public MarksRestController(CustomMetricSource customMetricSource){  
        this.customMetricSource = customMetricSource;  
    }  
  
    @GetMapping("/{name}/{marks}")  
    public void addData(@PathVariable String name, @PathVariable String marks){  
        customMetricSource.addDataToMarksMap(name,marks);  
    }  
}
```
5. Service:
```java
package com.custom.app.metrics;  
  
import io.micrometer.core.instrument.Gauge;  
import io.micrometer.core.instrument.MeterRegistry;  
import io.micrometer.core.instrument.Tag;  
import org.springframework.stereotype.Service;  
  
import java.util.HashMap;  
import java.util.List;  
import java.util.concurrent.atomic.AtomicInteger;  
  
@Service  
public class CustomMetricSource {  
  
    private final MeterRegistry registry;  
    HashMap<String, String> marksData = new HashMap<String, String>();  
    private Gauge gauge;  
    private AtomicInteger value = new AtomicInteger(0);  
    private static final String metricName = "students.marks.data";  
  
    public CustomMetricSource(MeterRegistry registry){  
        this.registry = registry;  
        initializeMap();  
  
        gauge = Gauge.builder(metricName, () -> this.value)  
                .description("This metrics show the marks obtained by students")  
                .tags(getTags())  
                .register(registry);  
  
    }  
  
    private void initializeMap() {  
        marksData.put("Rohan","78");  
        marksData.put("Sohan","65");  
        marksData.put("Vijay","89");  
        marksData.put("Roy","91");  
        this.value.addAndGet(4);  
    }  
  
    private void addTagToExistingMetric(MeterRegistry registry, Tag tag) {  
        this.value.incrementAndGet();  
        this.gauge = Gauge.builder(metricName, () -> 0)  
                .description("This metrics show the marks obtained by students")  
                .tag(tag.getKey(),tag.getValue())  
                .register(registry);  
    }  
  
    private List<Tag> getTags() {  
        return marksData.keySet().stream().map(key -> Tag.of(key,marksData.get(key))).toList();  
    }  
  
    public void addDataToMarksMap(String name, String marks) {  
        marksData.put(name,marks);  
        addTagToExistingMetric(this.registry, Tag.of(name, marks));  
    }  
  
}
```
Service class is composed of the following:

-   **MeterRegistry**: This will be injected into class via constructor injection. Gauge is a type of meter that we have created and it will be registered with MeterRegistry. MeterRegistry will be responsible for further putting our gauge under “/actuator/metric” endpoint.
-   HashMap<String,String> : This map will hold students name and marks data in string format.
-   **Gauge**: A gauge is a type of meter that can increase or decrease. I have choosen gauge and not counter because Counter should always increase and counter will be zero only when it was initialised or application is restarted. Gauge can be incremented or decremented.
-   **AtomicInteger:** This is the value that will be represented under measurements whenever we will see our custom metrics.

Whenever new data is added in map, our AtomicInteger value will be incremented by 1 and a new tag is created. We can decrement it as well whenever an entry is removed from the map but I will leave it to you to try.

More theory can confuse it so I will execute the code and describe the output below.

**Output:**

I have started the application and without doing anything else I will simply hit “/actuator/metric” and see if the desire metric is visible.

![](https://miro.medium.com/v2/resize:fit:733/1*EALdvGmB22UTnKBrmIZNw.png)
students.marks.data

Yes, it is visible. Lets try to see what data is present under this metric.

Hit /actuator/metrics/students.marks.data and we will get below:

![](https://miro.medium.com/v2/resize:fit:733/1*XPhPI0qVx6ZFKIJEk4lFg.png)

If you see the code then inside constructor, we are initializing map and the value of the AtomicInteger variable. We can see data of the map under “availableTags” and VALUE under “measurements” shows the value of atomic integer or in simple words the size of the map.

Now I will hit the restController endpoint and I will add one record inside map: {name: Dinesh, marks: 65} and then we will this metric again to see if the metric is updating as expected.

Hit GET: [http://localhost:19000/Dinesh/65](http://localhost:19000/Dinesh/65)

https://github.com/mohit06/CustomGauge/tree/main/metrics.

---
# Top 6 features of Spring Boot 3.5

**pring Boot 3.5** will be the last version of Spring Boot 3.x before the release of **Spring Boot 4** (November 2025).

This version, released in **May 2025**, introduces several **enhancements** designed to improve the **developer experience**, **observability**, **security**, and **cloud-native** capabilities. In this article, we want to take a look at six of the top ones.

> · [Noteworthy features in Spring Boot 3.5](#068e)  
> ∘ [1- Load Properties From Environment Variables](#d727)  
> ∘ [2- SSL Support for Service Connections](#1744)  
> ∘ [3- Annotations to Register Filter and Servlet](#ca57)  
> ∘ [4- Cloud Native Buildpacks Improvements](#eb7d)  
> ∘ [5- Triggering Quartz Jobs From the Actuator](#b454)  
> ∘ [6- Customizing Structured Logging Stack Traces](#9f08)  
> · [Final Thought](#3caf)

### Noteworthy features in Spring Boot 3.5

As I mentioned earlier, this is the last minor Spring Boot version before the release of the next major Spring Boot version, Spring Boot 4.0. It seems that it is a **safe** and **smooth upgrade** that sets the stage for Spring Boot 4.0. It builds incrementally without breaking everything, while **paving the way** for future advancements.

> It’s not a groundbreaking overhaul, but rather a solid set of incremental improvements and nothing that dramatically changes how we build applications.

## 1- Load Properties From Environment Variables

Spring Boot supports loading a **single property** from an environment variable. In this version, we can now load **multiple properties** from a single environment variable.

> This is a significant enhancement that allows us to consolidate related properties into a single environment variable, rather than defining separate environment variables for each property.

The feature uses the `env:` prefix with the `spring.config.import` property to import properties from an environment variable.

If we have **multiple properties** in the `DB_CONFIG` environment variable:
```shell
export DB_CONFIG="database.host=localhost  
database.port=5432  
database.name=mydb"
```
This feature supports both `properties` and `YAML` format. We can also use `YAML` format in our environment variable:
```shell
export MY_YAML_CONFIG="  
database:  
  host: localhost  
  port: 5432  
  name: mydb  
"
```

By importing the environment variable in our Spring Boot application:

# application.properties  
```shell
spring.config.import=env:DB_CONFIG
```
Now, we access the properties in our application:
```java
@Component  
public class MyService {  
         
    @Value("${database.host}")  
    private String dbHost;  
      
    @Value("${database.port}")  
    private int dbPort;  
      
    // Properties are now available for use  
}
```

> This enhancement makes Spring Boot applications more container-friendly and simplifies configuration management in cloud environments.

Where it may be necessary to pass **complex configurations** through environment variables.

## 2- SSL Support for Service Connections

The **Service Connection** feature was introduced in Spring Boot 3.1, and I discussed in detail how to apply this great feature in **integration tests** and **development time** in these three articles:

-   🍃 [**Using Spring Boot 3.1 integration with Docker Compose**](https://itnext.io/using-spring-boot-3-1-integration-with-docker-compose-instead-of-local-k8s-f0b0037de5e7)
-   🍃 [**Using Spring Boot 3.1 integration with Testcontainers in Development time**](https://itnext.io/using-spring-boot-3-1-integration-with-testcontainers-in-development-time-899c602560c7)
-   🍃 [**Service Connection in Development time and integration tests**](https://zarinfam.medium.com/top-4-exciting-features-coming-in-spring-boot-3-2-cf198fc71965#2517)

> Now, Spring Boot 3.5 has added **client-side SSL** support for selected **service connections**, allowing us to configure SSL/TLS encryption for connections to external services.

The SSL support is available for the following service connections:

-   **Cassandra**
-   **Couchbase**
-   **Elasticsearch**
-   **Kafka**
-   **MongoDB**
-   **RabbitMQ**
-   **Redis**

The [**Testcontainers**](https://zarinfam.medium.com/top-4-exciting-features-coming-in-spring-boot-3-2-cf198fc71965#2517) integration has been updated to allow SSL configuration using new [annotations](https://docs.spring.io/spring-boot/reference/testing/testcontainers.html#testing.testcontainers.service-connections.ssl) (`[@Ssl](https://docs.spring.io/spring-boot/3.5.0/api/java/org/springframework/boot/testcontainers/service/connection/Ssl.html)`, `[@JksKeyStore](https://docs.spring.io/spring-boot/3.5.0/api/java/org/springframework/boot/testcontainers/service/connection/JksKeyStore.html)`, `[@JksTrustStore](https://docs.spring.io/spring-boot/3.5.0/api/java/org/springframework/boot/testcontainers/service/connection/JksTrustStore.html)`, `[@PemKeyStore](https://docs.spring.io/spring-boot/3.5.0/api/java/org/springframework/boot/testcontainers/service/connection/PemKeyStore.html)`, and `[@PemTrustStore](https://docs.spring.io/spring-boot/3.5.0/api/java/org/springframework/boot/testcontainers/service/connection/PemTrustStore.html)`):
```java
@Testcontainers  
@SpringBootTest  
class MyRedisWithSslIntegrationTests {  
  
    @Container  
    @ServiceConnection  
    @PemKeyStore(certificate = "classpath:client.crt", privateKey = "classpath:client.key")  
    @PemTrustStore("classpath:ca.crt")  
    static RedisContainer redis = new SecureRedisContainer("redis:latest");  
  
    @Autowired  
    private RedisOperations<Object, Object> operations;  
  
    @Test  
    void testRedis() {  
        // ...  
    }  
  
}
```
For [**Docker Compose**](https://itnext.io/using-spring-boot-3-1-integration-with-docker-compose-instead-of-local-k8s-f0b0037de5e7) integration, we can use [**labels**](https://docs.spring.io/spring-boot/reference/features/dev-services.html#features.dev-services.docker-compose.ssl) to configure SSL:

# docker-compose.yml  
```yml 
services:  
  redis:  
    image: 'redis:latest'  
    ports:  
      - '6379'  
    secrets:  
      - ssl-ca  
      - ssl-key  
      - ssl-cert  
    command: 'redis-server --tls-port 6379 --port 0 --tls-cert-file /run/secrets/ssl-cert --tls-key-file /run/secrets/ssl-key --tls-ca-cert-file /run/secrets/ssl-ca'  
    labels:  
      - 'org.springframework.boot.sslbundle.pem.keystore.certificate=client.crt'  
      - 'org.springframework.boot.sslbundle.pem.keystore.private-key=client.key'  
      - 'org.springframework.boot.sslbundle.pem.truststore.certificate=ca.crt'  
secrets:  
  ssl-ca:  
    file: 'ca.crt'  
  ssl-key:  
    file: 'server.key'  
  ssl-cert:  
    file: 'server.crt'
```
## 3- Annotations to Register Filter and Servlet

While Spring Boot has long supported servlet component registration through `@ServletComponentScan` with `@WebFilter` and `@WebServlet`:
```java
@SpringBootApplication  
@ServletComponentScan  // enables scanning for @WebFilter, @WebServlet, @WebListener  
public class MyApp {  
    public static void main(String[] args) {  
        SpringApplication.run(MyApp.class, args);  
    }  
}
```
Then define a filter class and map it to URL patterns:
```java
@WebFilter(urlPatterns = "/*")    
public class LoggingFilter implements Filter {  
    @Override  
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)  
            throws IOException, ServletException {  
        //Incoming request handling  
        chain.doFilter(request, response);  
        //Outgoing response handling  
    }  
}
```
Spring Boot 3.5 has enhanced this with more flexible **annotation-based** registration approaches and introduced `@ServletRegistration` to register `Servlet`, and `@FilterRegistration` to register `Filter`:
```java
@Configuration  
public class FilterConfig {  
  
    @Bean  
    @FilterRegistration(  
        name = "loggingFilter",  
        urlPatterns = "/*",  
        order = 0  
    )  
    public LoggingFilter loggingFilter() {  
        return new LoggingFilter();  
    }  
}
```
## 4- Cloud Native Buildpacks Improvements

Spring Boot 3.5 introduced several key improvements to [**Cloud Native Buildpacks**](https://itnext.io/how-to-config-skafold-to-use-paketo-buildpacks-as-a-builder-a54b17dc182c#566d) support, focusing on better **image optimization**, **enhanced logging**, and **updated default builders**.

The default builder has been switched to `paketobuildpacks/builder-noble-java-tiny`.

> This change significantly **reduces the final image size** by creating minimal container images.

The resulting image doesn’t have a **shell** or **other utilities**, making it more secure and lightweight for production deployments. If you need a shell, you can use `paketobuildpacks/ubuntu-noble-run-base` as the run image.

🐳 The other improvement is that the Maven and Gradle plugins will use authentication settings from the Docker `config.json` file, supporting credential helpers that manage the macOS keychain.

💡 **Logging** for Cloud Native Buildpacks integration has also been enhanced, providing improved visibility into the build process and enhanced troubleshooting capabilities.

## 5- Triggering Quartz Jobs From the Actuator

Spring Boot 3.5 has introduced a new feature that allows us to trigger **Quartz jobs** on demand via the **Actuator HTTP API**.

> This enhancement enables direct, runtime control of scheduled jobs — useful for operational tasks, testing, or manual interventions.

We can trigger a specific Quartz job by making a `POST` request to the following endpoint:
```shell
/actuator/quartz/jobs/{groupName}/{jobName}
```
Which `{groupName}` is the Quartz job group, and `{jobName}` is the name of the job we want to trigger.

A successful request returns a JSON response with details about the triggered job, for example:
```json
{  
  "group": "{groupName}",  
  "name": "{jobName}",  
  "className": "org.springframework.scheduling.quartz.DelegatingJob",  
  "triggerTime": "2025-05-22T20:03:31.949172098Z"  
}
```
## 6- Customizing Structured Logging Stack Traces

The [**Structured Logging**](https://itnext.io/deep-dive-into-the-structured-logging-in-spring-boot-3-4-89b2a5b1b75f?sk=c3d5a99f4d78ed2238e52d19bc97964d) feature was introduced in [Spring Boot 3.4](https://itnext.io/deep-dive-into-the-structured-logging-in-spring-boot-3-4-89b2a5b1b75f?sk=c3d5a99f4d78ed2238e52d19bc97964d). Spring Boot 3.5 has introduced a new feature to Structured Logging, enabling us to customize how stack traces are included in outputs.

> This customization for structured logging gives us granular control over log output, making it easier to optimize logs for our operational and analytical needs.

We can now control stack trace output in structured logs using several new configuration properties under `logging.structured.json.stacktrace.*`. These properties allow us to:

-   Change the **order** of stack frames (e.g., root first or last)
-   **Limit** the maximum length of the stack trace string
-   **Restrict** the number of frames included per stack trace
-   Decide whether to **include** or **exclude** common frames
-   Add a hash of the stack trace for easier **deduplication** or **correlation**

Here’s how we can customize the stack trace output in our `YAML` configuration:
```yaml
logging:  
  structured:  
    json:  
      stacktrace:  
        root: first  
        max-length: 1024  
        include-common-frames: true  
        include-hashes: true
```
This configuration will:

-   Print stack traces with the root cause at the top (`root: first`)
-   Limit the stack trace string to 1024 characters
-   Include common frames in the output
-   Add a hash value for each stack trace

### Final Thought

Spring Boot 3.5 is a **polished upgrade** rather than a revolution. It smooths and enhances your daily development experience with improved configuration, observability, security, and native support. Unless you’re focusing on major new APIs or frameworks, it’s safe and efficient to adopt.

You can read the complete list of New and Noteworthy features in the

---

# Building a Scalable Multi-Tenant SaaS with Spring Boot and Dynamic DataSource Routing

### Introduction

In a multi-tenant SaaS application, one of the key architectural decisions is how to manage data isolation between tenants. One common approach is the **Per Tenant Per Database** strategy, where each tenant has a dedicated database. This method ensures strong data isolation, better scalability, and security. However, configuring a Spring Boot application to dynamically switch between tenant databases requires careful implementation.

In this article, we will explore the challenges of a **Per Tenant Per Database** approach, walk through a step-by-step implementation using Spring Boot, and provide a complete working code example.

### Problem

When implementing a multi-tenant system, several challenges arise:

1.  **Dynamic DataSource Switching** — Each request must connect to the appropriate tenant database based on some identifier (e.g., a subdomain, header, or JWT claim).
2.  **Database Connection Management** — Managing multiple database connections efficiently to prevent resource exhaustion.
3.  **Transaction Handling** — Ensuring transactions are correctly handled across different databases.
4.  **Security & Isolation** — Avoiding data leakage between tenants and maintaining strict data boundaries.

Spring Boot does not provide built-in support for **Per Tenant Per Database**, so we need to configure it manually.

### Code Implementation

We will implement a **multi-tenant architecture** with a dynamic **DataSource Routing** mechanism.

### 1. Define a Tenant Context

We need a **ThreadLocal** variable to store the current tenant identifier.
```java
public class TenantContext {  
    private static final ThreadLocal<String> currentTenant = new ThreadLocal<>();  
  
public static void setCurrentTenant(String tenantId) {  
        currentTenant.set(tenantId);  
    }  
    public static String getCurrentTenant() {  
        return currentTenant.get();  
    }  
    public static void clear() {  
        currentTenant.remove();  
    }  
}
```
### 2. Create a Dynamic DataSource

We will create a `MultiTenantDataSource` that determines which database to use based on the tenant identifier.
```java
public class MultiTenantDataSource extends AbstractRoutingDataSource {  
    @Override  
    protected Object determineCurrentLookupKey() {  
        return TenantContext.getCurrentTenant();  
    }  
}
```

### 3. Configure the DataSource Bean

Spring Boot needs to know about all tenant databases. We define them in an `ApplicationConfig` class.
```java
@Configuration  
public class DataSourceConfig {  
    @Bean  
    public DataSource dataSource() {  
        Map<Object, Object> targetDataSources = new HashMap<>();  
          
        // Load tenant database configurations dynamically (from properties, DB, etc.)  
        targetDataSources.put("tenant1", createDataSource("jdbc:mysql://localhost:3306/tenant1"));  
        targetDataSources.put("tenant2", createDataSource("jdbc:mysql://localhost:3306/tenant2"));  
  
MultiTenantDataSource multiTenantDataSource = new MultiTenantDataSource();  
        multiTenantDataSource.setDefaultTargetDataSource(createDataSource("jdbc:mysql://localhost:3306/defaulttenant"));  
        multiTenantDataSource.setTargetDataSources(targetDataSources);  
        multiTenantDataSource.afterPropertiesSet();  
          
        return multiTenantDataSource;  
    }  
    private DataSource createDataSource(String url) {  
        HikariConfig config = new HikariConfig();  
        config.setJdbcUrl(url);  
        config.setUsername("root");  
        config.setPassword("password");  
        config.setDriverClassName("com.mysql.cj.jdbc.Driver");  
        return new HikariDataSource(config);  
    }  
}
```

### 4. Implement a Tenant Filter

To extract the tenant identifier from requests and set it in the `TenantContext`, we use a servlet filter.
```java
@Component  
public class TenantFilter extends OncePerRequestFilter {  
    @Override  
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)  
            throws ServletException, IOException {  
        String tenantId = request.getHeader("X-Tenant-ID");  
        if (tenantId != null) {  
            TenantContext.setCurrentTenant(tenantId);  
        }  
        try {  
            filterChain.doFilter(request, response);  
        } finally {  
            TenantContext.clear();  
        }  
    }  
}
```
### 5. Repository and Service Layer

Now that our database routing is ready, let’s define a simple repository and service to handle tenant-specific data.

### Entity
```java
@Entity  
public class Customer {  
    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    private Long id;  
    private String name;  
}
```
### Repository
```java
@Repository  
public interface CustomerRepository extends JpaRepository<Customer, Long> {  
}
```
### Service
```java
@Service  
public class CustomerService {  
    @Autowired  
    private CustomerRepository customerRepository;  
public List<Customer> getAllCustomers() {  
        return customerRepository.findAll();  
    }  
}
```
### 6. Controller

Finally, expose an API endpoint to retrieve tenant-specific data.
```java
@RestController  
@RequestMapping("/customers")  
public class CustomerController {  
    @Autowired  
    private CustomerService customerService;  
  
    @GetMapping  
    public List<Customer> getCustomers(@RequestHeader("X-Tenant-ID") String tenantId) {  
        TenantContext.setCurrentTenant(tenantId);  
        return customerService.getAllCustomers();  
    }  
}
```

### Conclusion

In this article, we have implemented a **Per Tenant Per Database** architecture in a Spring Boot application. We covered:

1.  **Dynamic DataSource Routing** — Using `AbstractRoutingDataSource` to switch between tenant databases.
2.  **Tenant Context Handling** — Using a `ThreadLocal` variable to store and retrieve tenant information.
3.  **Efficient Database Management** — Using HikariCP for connection pooling.
4.  **Security & Isolation** — Ensuring that each tenant has exclusive access to its own database.

This approach is scalable and ensures strong data isolation, making it an excellent choice for multi-tenant SaaS applications. However, keep in mind:

-   **Database provisioning**: You need to handle the creation and migration of tenant databases dynamically.
-   **Connection pooling limits**: Too many databases can cause connection exhaustion if not managed properly.
-   **Centralized metadata storage**: Storing tenant database details in a centralized metadata database can simplify management.
-   
---

# Spring Boot - ObjectMapper json handling 

If you’ve ever worked with JSON in Java, you’ve probably used **Jackson’s ObjectMapper**. And if you’re like me, at some point, you also felt like yelling at it.

I’ve been there — converting objects to JSON and back, handling weird formats, unknown fields, null values, type mismatches… sometimes it works like magic, and sometimes it feels like you’re stuck in **ObjectMapper hell**.

In this article, I’ll share some common problems I faced using `ObjectMapper`, how I solved them, and what I learned about keeping things clean when dealing with JSON in Java

# The Basics Seem Easy (At First)

When I first used `ObjectMapper`, it felt simple. I had a Java class and wanted to convert it to JSON. Easy

ObjectMapper mapper = new ObjectMapper();  
String json = mapper.writeValueAsString(myObject);

And to convert back:

MyClass obj = mapper.readValue(json, MyClass.class);

That worked fine — until real-life JSON came in. Then the problems started.

# Problem 1: Unknown or Extra Fields in JSON

One time, our backend was talking to a third-party service. They added a new field to the response, and suddenly our app started throwing exceptions

{  
  "id": 1,  
  "name": "John",  
  "newField": "unexpected"  
}

Our code broke with:

UnrecognizedPropertyException: Unrecognized field "newField"

### How I Fixed It:

I added this annotation to the class:
```java
@JsonIgnoreProperties(ignoreUnknown = true)  
public class User {  
    public int id;  
    public String name;  
}
```
Now, if the JSON contains new or extra fields, **ObjectMapper will just ignore them**. No more crashes.

**Lesson learned:** APIs change. Always prepare your code to handle unknown fields safely

# Problem 2: Null Values Showing Up Everywhere

In one project, we had a lot of null values being returned in the JSON response. The frontend team was not happy

{  
  "id": 5,  
  "name": null,  
  "email": null  
}

They wanted only the fields that had real values.

### How I Fixed It:

I changed the configuration:
```java
ObjectMapper mapper = new ObjectMapper();  
mapper.setSerializationInclusion(JsonInclude.Include.NONNULL);
```
Now, when we converted Java objects to JSON, it skipped all null fields.

{  
  "id": 5  
}

**Lesson learned:** Small config changes can make a big difference in API responses

# Problem 3: Date Format Mess

We had a date field in a response. On the backend, it was a `LocalDateTime`. But when we sent it as JSON, the frontend couldn’t read it.

They got something like:

"createdAt": "2024-12-15T17:45:30.123"

The frontend team wanted a simple format like `"2024-12-15 17:45"`.

### How I Fixed It:

We added a date format annotation:
```java
@JsonFormat(pattern = "yyyy-MM-dd HH:mm")  
public LocalDateTime createdAt;
```
Now the JSON looked like this:

"createdAt": "2024-12-15 17:45"

**Lesson learned:** Always agree on date formats early — and set them clearly in your model

# Bonus Tip: Use DTOs for Clean Mapping

Don’t mix your database entities with your API models. That’s how bugs sneak in. Create separate **DTOs (Data Transfer Objects)** for sending and receiving JSON.

This makes it easier to:

-   Control what goes in or out of the API
-   Customize JSON formats
-   Keep internal logic safe

We used tools like **MapStruct** later to handle mapping between entities and DTOs automatically

# Final Thoughts

Using `ObjectMapper` is not hard. But using it **well** takes experience.

Here’s what helped me most:

-   Use `@JsonIgnoreProperties` to handle unknown fields
-   Use `@JsonFormat` for dates and numbers
-   Set `NONNULL` to clean up your JSON
-   Always use DTOs instead of exposing entities directly
-   Keep ObjectMapper configuration in one place — don’t scatter it

Since cleaning up our JSON logic, our APIs are easier to maintain, and the frontend team no longer complains every other day.

---

# Implement API first strategy with OpenAPI generator plugin 

Everyone is talking about API first strategy nowadays, In this article I will demo how we exactly implement API first strategy with OpenAPI generator plugin in a real-world solution.

### Strategy

API-first, also called the API-first approach, prioritizes APIs at the beginning of the software development process, positioning APIs as the building blocks of software. API-first organizations develop APIs before writing other code, instead of treating them as afterthoughts. This lets teams construct applications with internal and external services that are delivered through APIs.

Advantages of the API-first approach with a common OpenAPI Specification:

-   Ensures the use of the same contracts by all the parts of the system.
-   Facilitates cooperation between the backend and the frontend, facilitating parallel development.
-   Automates generation of repeatable elements like models, services and controllers, reducing the amount of boilerplate code, organizing the structure and saving developers’ time.
-   Automatically generates and enables API documentation.

### Diagram

![API first approach](https://miro.medium.com/v2/resize:fit:875/1*7Cn0XgSh2uAVLtu73omMMg.png)

As seen from this picture, before developing the application, at the API design stage, we will create OpenAPI spec(e.g. a yaml file) and store it as a single source in the git repo. At this stage, the API designer, such as architect, BA, developer, they need to contribute to this API spec document and do a proper review, then push it to git repo and trigger the CICD process.

CICD will validate the API spec, if the spec is incompatible with the previous version then we need to create a newer version and commit again. otherwise, the spec will be uploaded to an artifact store such as Jfrog Artifactory or Nexus. In this demo, I don’t have artifactory, hence I use bitbucket as the storage instead.

At the microservice development stage, developer will use the `openapi generator plugin`(maven/gradle), to import the API spec from remote url(e.g. bitbucket or jfrog artifactort), and generate server/client code from the API spec.

We can also customize the openapi generator plugin, parse the api spec configuration to export API dependency information. such as:

-   microservice A has dependency of microservice B v1 api, microservice C v2 api
-   microservice B has dependency of microservice C v3 api

with these information we can create application catalog, inventory, … etc.

### Generate code with the OpenAPI generator plugin

When a microservice wants to create an API server/client, just needs to have this configuration in its maven POM.xml:
```xml
<build>          
    <plugins>          
        <plugin>  
            <groupId>org.openapitools</groupId>  
            <artifactId>openapi-generator-maven-plugin</artifactId>  
            <version>${openapi-generator.version}</version>  
            <executions>  
                <execution>  
                    <id>petstore-client</id>  
                    <goals>  
                        <goal>generate</goal>  
                    </goals>  
                    <configuration>  
                        <auth></auth>  
                        <!--                            <inputSpec>${project.basedir}/src/main/resources/api.yaml</inputSpec>-->  
                        <inputSpec>https://raw.githubusercontent.com/softarts/apifirst/main/apifirst-contracts/retail/petstore/v1.yaml</inputSpec>  
                        <generatorName>java</generatorName>  
                        <skipIfSpecIsUnchanged>true</skipIfSpecIsUnchanged>  
                        <generateApiTests>false</generateApiTests>  
                        <generateModelTests>false</generateModelTests>  
<!--                            <generateSupportingFiles>false</generateSupportingFiles>-->  
                        <configOptions>  
<!--                                <sourceFolder>src/gen/java/main</sourceFolder>-->  
                            <interfaceOnly>true</interfaceOnly>  
                            <dateLibrary>java8</dateLibrary>  
                            <delegatePattern>true</delegatePattern>  
                            <useTags>true</useTags>  
                            <requestMappingMode>api_interface</requestMappingMode>  
                            <library>resttemplate</library>  
                            <generateClientAsBean>true</generateClientAsBean>  
                            <useSpringBoot3>true></useSpringBoot3>  
                            <useJakartaEe>true</useJakartaEe>  
                            <apiPackage>com.zhourui.retail.petstore.consumer.api.v1</apiPackage>  
                            <modelPackage>com.zhourui.retail.petstore.model.v1</modelPackage>  
                            <serializableModel>true</serializableModel>  
                        </configOptions>  
                    </configuration>  
                </execution>  
                <execution>  
                    <id>petstore-server</id>  
                    <goals>  
                        <goal>generate</goal>  
                    </goals>  
                    <configuration>  
                        <!--                            <inputSpec>${project.basedir}/src/main/resources/api.yaml</inputSpec>-->  
                        <auth></auth>  
                        <inputSpec>https://raw.githubusercontent.com/softarts/apifirst/main/apifirst-contracts/retail/petstore/v1.yaml</inputSpec>  
                        <generatorName>spring</generatorName>  
                        <skipIfSpecIsUnchanged>true</skipIfSpecIsUnchanged>  
                        <configOptions>  
                            <!--                                <sourceFolder>src/gen/java/main</sourceFolder>-->  
                            <validateSpec>false</validateSpec>  
                            <interfaceOnly>true</interfaceOnly>  
                            <dateLibrary>java8</dateLibrary>  
                            <delegatePattern>false</delegatePattern>  
                            <useTags>true</useTags>  
                            <requestMappingMode>api_interface</requestMappingMode>  
                            <generateClientAsBean>true</generateClientAsBean>  
                            <useSpringBoot3>true></useSpringBoot3>  
                            <useJakartaEe>true</useJakartaEe>  
                            <apiPackage>com.zhourui.retail.petstore.producer.api.v1</apiPackage>  
                            <modelPackage>com.zhourui.retail.petstore.model.v1</modelPackage>  
                        </configOptions>  
                    </configuration>  
                </execution>  
            </executions>  
        </plugin>  
    </plugins>  
</build>
```

The full parameters list are at the [openapi repo](https://github.com/OpenAPITools/openapi-generator/tree/master/modules/openapi-generator-maven-plugin). here I just highlight some important stuff:

### API spec

it use github repo to store the API spec(see [here](https://raw.githubusercontent.com/softarts/apifirst/main/apifirst-contracts/retail/petstore/v1.yaml)), and this is the single source of API spec. all participants need to create their code from this spec.

<inputSpec>https://raw.githubusercontent.com/softarts/apifirst/main/apifirst-contracts/retail/petstore/v1.yaml</inputSpec>

### <auth>

This is the auth header when need to access API spec file which resides at remote url(e.g. different bitbucket repo). First of all, create a personal token at bitbucket account management; then encode it in base64.

![](https://miro.medium.com/v2/resize:fit:875/1*RPpUIbIh1vc0T2oNaecvbg.png)

bitbucket_username:bitbucket_token  
=> base64 encode  
Yml0YnVja2V0X3VzZXJuYW1lOmJpdGJ1Y2tldF90b2tlbg==

the <auth> will be:

<auth>Authorization:Basic Yml0YnVja2V0X3VzZXJuYW1lOmJpdGJ1Y2tldF90b2tlbg==</auth>

### multi languages

openapi generator supports [multiple languages](https://openapi-generator.tech/docs/generators/), usually I will use

-   `java`(generator) `resttemplate`(library) => java-client, use `resttemplate` as http client
-   `kotlin-spring`(generator) => kotlin-spring server

### Implement service with few lines of code

OpenAPI generator maven plugin will generate model, consumer, producer API files under the `target` folder.

![](https://miro.medium.com/v2/resize:fit:875/1*jyWd-xE6waGh0rlLalfCuQ.png)

### controller(server)

Just implements from the generated API(`StoreApi` ) and copy the function declaration:
```java
import com.zhourui.retail.petstore.producer.api.v1.StoreApi;  
  
@RestController  
public class StoreController implements StoreApi {  
    @Override  
    public ResponseEntity<Map<String, Integer>> getInventory() {  
        // your code  
        Map<String, Integer> m = Map.of(  
                "sugar", 1000,  
                "wheat", 250  
        );  
        return new ResponseEntity<>(m, HttpStatus.OK);  
    }  
}
```
### client

use bean configuration to set server url
```java
@Configuration  
@Import(  
        value = {StoreApi.class, com.zhourui.retail.petstore.consumer.api.ApiClient.class}  
)  
public class BaseConfiguration {  
    @Value("${ApiFirstDemo.API.PetStoreUrl}")  
    private String petStoreUrl;  
  
    @Bean  
    public RestTemplate restTemplate() {  
        return new RestTemplate();  
    }  
  
    @Bean  
    public StoreApi storeApi() {  
        StoreApi storeApi = new StoreApi();  
        storeApi.getApiClient().setBasePath(petStoreUrl);  
        return storeApi;  
    }  
}
```

the URL is in `application.yaml` (use default value, in production it can be rendered by CICD)
```yaml
ApiFirstDemo:  
  API:  
    PetStoreUrl: ${PetStoreUrlV1:http://localhost:8080/api/v3}
```
and usage
```java
@RestController  
public class DemoController {  
    @Autowired  
    private StoreApi storeApi;  
  
    @GetMapping(value = "/clientdemo")  
    public ResponseEntity<Map<String, Integer>> clientDemo() {  
        Map<String, Integer> m = storeApi.getInventory();  
        return new ResponseEntity<>(m,OK);  
    }  
}
```
### Testing
```shell
curl -X GET "http://localhost:8080/clientdemo"  
### => will hit its own endpoint "storeapi"  
{"wheat":250,"sugar":1000}
```
### Reference

-   [https://www.j-labs.pl/en/tech-blog/api-first-with-open-api-generator/](https://www.j-labs.pl/en/tech-blog/api-first-with-open-api-generator/)
-   [https://www.baeldung.com/spring-boot-openapi-api-first-development](https://www.baeldung.com/spring-boot-openapi-api-first-development)

-   https://github.com/softarts/apifirst

---
# Singleton Design Pattern: A Comprehensive Guide 

# What is the Singleton Design Pattern?

The Singleton Design Pattern is a creational design pattern that **ensures a class has only one instance and provides a global point of access to that instance.** This pattern is particularly useful when exactly one object is needed to coordinate actions across the system.

![](https://miro.medium.com/v2/resize:fit:538/0*w7vGPrRewl1PM7Tl)
Source: Refactoring Guru

Key characteristics of the Singleton pattern include:

-   **Single Instance**: Only one instance of the class is created.
-   **Global Access**: The single instance can be accessed globally.
-   **Lazy Initialization**: The instance is created only when required (if needed).

### Where Can You Use the Singleton Design Pattern?

### Real-World Scenarios

1.  **Configuration Management**:

-   Centralising configuration properties to avoid multiple instances managing the same data.
-   Example: A properties file loader.

1.  **Logging**:

-   Ensuring a single log file is used across the application.
-   Example: Logger classes like `java.util.logging.Logger`.

**2. Database Connections**:

-   Managing a single point of access to database connections.
-   Example: Database connection pools.

**3. Caching**:

-   Implementing caching mechanisms to reduce redundant operations.
-   Example: An in-memory cache like Redis.

**4. Thread Pools**:

-   Ensuring only one thread pool is active.

**5. Resource Management**:

-   Managing shared resources like network sockets or printers.

### When to Use and Avoid Singleton Design Pattern

### When to Use

-   Centralised control is needed for resource management.
-   Frequent creation and destruction of instances is expensive.
-   A single instance ensures consistency (e.g. global configuration).

### When to Avoid

**Reflection Breaking Singleton**:

-   Reflection can bypass private constructors, creating multiple instances.
-   To prevent this, throw an exception if the constructor is invoked more than once:
```java
private Singleton() {       
  if (instance != null) {           
    throw new IllegalStateException("Instance already created");       
  }   
}
```
**Serialization Breaking Singleton**:

-   During deserialization, a new instance can be created.
-   To fix this, implement the `readResolve` method in your singleton class.
-   The `readResolve` method is a mechanism provided by Java to ensure that during deserialization, the singleton property of a class is preserved. Without this method, deserialization could lead to the creation of a new instance of the Singleton class, breaking its contract of having only one instance.

### How `readResolve` Works

The `readResolve` method is part of Java's serialization mechanism. When an object is deserialized, if the class implements the `readResolve` method, this method is invoked to determine the instance that should replace the deserialized object.
```java
private Object readResolve() throws ObjectStreamException {       
  return instance;   
}
```

**Testing and Dependency Injection**:

-   Singletons can make unit testing difficult due to their global state.
-   **Use Dependency Injection to avoid tightly coupling code** to the Singleton.

**Distributed Systems**:

-   Singletons are not ideal for distributed systems as they can lead to multiple instances in a cluster.
-   Consider **distributed locking or other patterns**.

### Distributed Locking and Dependency Injection

### Distributed Locking

Distributed locking ensures that in a distributed system, only one instance of the Singleton is active at a time across all nodes. Popular tools for implementing distributed locking include:

1.  **Redis**:

-   Using `SETNX` (set if not exists) and an expiration time to create a lock.
```java
if (redis.setnx("lockkey", "value") == 1) {   
  // Acquired lock, proceed with Singleton logic   
}
```

**2. ZooKeeper**:

-   Leverages ephemeral nodes to ensure only one client holds the lock.

### Dependency Injection (DI)

**Description**:

-   Instead of hard-coding Singleton instances, provide them as dependencies to classes that need them.

**Implementation**:
```java
public class Service {       
  private final Singleton singleton;   
       
  public Service(Singleton singleton) {           
    this.singleton = singleton;       
  }   
}  

Singleton singleton = Singleton.getInstance();   
Service service = new Service(singleton);
```
**When to Use**:

-   When you need to decouple classes for better testability and maintainability.

### How to Implement Singleton in Java

### Basic Implementation
```java
public class BasicSingleton {  
    private static BasicSingleton instance;  
  
     private BasicSingleton() {  
        // private constructor to restrict instantiation  
     }  
  
     public static BasicSingleton getInstance() {  
        if (instance == null) {  
            instance = new BasicSingleton();  
        }  
        return instance;  
    }  
}
```
### Thread-Safe Implementation
```java
public class ThreadSafeSingleton {  
    private static ThreadSafeSingleton instance;  
  
    private ThreadSafeSingleton() {}  
  
    public static synchronized ThreadSafeSingleton getInstance() {  
        if (instance == null) {  
            instance = new ThreadSafeSingleton();  
        }  
        return instance;  
    }  
}
```
### Double-Checked Locking
```java
public class DoubleCheckedSingleton {  
    private static volatile DoubleCheckedSingleton instance;  
  
    private DoubleCheckedSingleton() {}  
  
    public static DoubleCheckedSingleton getInstance() {  
        if (instance == null) { // FIRST LOCK  
            synchronized (DoubleCheckedSingleton.class) {  
                if (instance == null) { // SECOND LOCK  
                    instance = new DoubleCheckedSingleton();  
                }  
            }  
        }  
        return instance;  
    }  
}
```

> **Key Points:**
> 
> **Volatile**: The `volatile` keyword ensures that the instance is always read from the main memory and **prevents thread caching issues**.
> 
> **First Check**: The first check avoids locking if the instance is already initialized, improving performance in multi-threaded scenarios.
> 
> **Second Check**: The second check ensures that only one thread initializes the resource, even if multiple threads enter the synchronized block simultaneously.
> 
> This pattern is commonly used in Singleton design to ensure thread safety while avoiding the performance cost of synchronization once the resource is initialized.

### Enum-Based Singleton
```java
public enum EnumSingleton {  
    INSTANCE;  
  
public void performAction() {  
        // action implementation  
    }  
}
```
### Which Implementation to Use and When

1.  **Basic Singleton**:

-   Use in simple applications where thread safety is not a concern.

**2. Thread-Safe Singleton**:

-   Use in multi-threaded environments to ensure only one instance is created.
-   Drawback: Synchronized methods can be slow.

**3. Double-Checked Locking**:

-   Optimal for performance in multi-threaded applications.
-   Ensures thread safety while avoiding the overhead of synchronizing every call.

**4. Enum-Based Singleton**:

-   Recommended for most use cases due to simplicity, thread safety, and protection from reflection and serialization issues.
-   Use when you need a straightforward and robust Singleton implementation.

# Class vs Enum for Singleton

### Class-Based Approach

**When to Use**:

-   Need fine-grained control over instantiation.
-   More flexibility for extensions or testing.

**When Not to Use**:

-   Increased risk of multiple instances if not implemented correctly.

### Enum-Based Approach

**When to Use**:

-   Simplifies implementation.
-   Ensures thread safety and protection from reflection/serialization.

**When Not to Use**:

-   Limited extensibility.

### Ensuring Thread Safety

-   Use **synchronized methods** for instance creation.
-   **Employ double-checked locking with** `**volatile**` **keyword.**
-   Enum-based singletons are inherently thread-safe.

### Things to Keep in Mind

-   **Ensure the constructor is private to prevent external instantiation**.
-   Consider thread safety for multi-threaded applications.
-   **Use lazy initialization only when necessary to optimise resource usage**.
-   Avoid reflection and serialization breaking the Singleton property by implementing the above safeguards.

### Pros and Cons

### Pros

-   Ensures a single instance.
-   Provides a global point of access.
-   Reduces memory usage in resource-heavy applications.

### Cons

-   Can lead to tightly coupled code.
-   Difficult to test and mock.
-   May introduce performance bottlenecks.

### Final Working Code with Class-Based Approach
```java
public class SingletonExample {  
    private static volatile SingletonExample instance;  
  
    private SingletonExample() {}  
    public static SingletonExample getInstance() {  
        if (instance == null) {  
            synchronized (SingletonExample.class) {  
                if (instance == null) {  
                    instance = new SingletonExample();  
                }  
            }  
        }  
        return instance;  
    }  
    public void showMessage() {  
        System.out.println("Singleton Instance Invoked!");  
    }  
    public static void main(String[] args) {  
        SingletonExample singleton = SingletonExample.getInstance();  
        singleton.showMessage();  
    }  
}
```
### Final Working Code with Enum-Based Approach
```java
public enum SingletonEnum {  
    INSTANCE;  
  
    // Example of a method that can be invoked on the singleton instance  
    public void showMessage() {  
        System.out.println("Singleton Instance Invoked via Enum!");  
    }  
}  
  
class EnumSingletonDemo {  
    public static void main(String[] args) {  
        // Accessing the Singleton instance  
        SingletonEnum singleton = SingletonEnum.INSTANCE;  
  
        // Calling the method on the singleton instance  
        singleton.showMessage();  
    }  
}
```

> How Enum works behind the scene — refer [**How Enum works with Singleton Design Pattern in Java!**](/how-enum-works-with-singleton-design-pattern-in-java-c7766a77592b)

### Conclusion

The Singleton Design Pattern is a powerful tool for centralising control and managing shared resources. However, it should be used judiciously, keeping thread safety, testability, and potential drawbacks in mind. While class-based approaches offer flexibility, enum-based implementations provide simplicity and robustness. Choose the right approach based on your application’s needs.


# SpringBoot3+ Lifecycle: Replace @PostConstruct and @PreDestroy with Modern Solutions

# `@PostConstruct` and `@PreDestroy`

In Spring Boot, `@PostConstruct` and `@PreDestroy` are lifecycle annotations provided by **Jakarta EE (formerly Java EE)**, specifically from the `jakarta.annotation` package. These annotations are not part of Spring Boot itself but are supported by Spring's lifecycle management.

# 1. What is `@PostConstruct`?

`@PostConstruct` is an annotation in Spring Boot that tells Spring to run a specific method **after the bean is created and dependencies are injected** but **before the bean is used**.

# When is it used?

It is used when you want to **initialize some data or perform setup tasks** before your application starts serving requests.

# Example Without `@PostConstruct` (Problem)

Imagine you have a `UserService` that loads users from a database
```java
@Service  
public class UserService {  
    private final UserRepository userRepository;  
    private Map<Long, User> userCache = new HashMap<>();  
  
    public UserService(UserRepository userRepository) {  
        this.userRepository = userRepository;  
    }  
  
    public User getUserById(Long id) {  
        return userCache.get(id); // Returns null if cache is empty  
    }  
}
```
**Problem**: The `userCache` is empty when the application starts.

# Solution With `@PostConstruct`

To **preload users into the cache**, we use `@PostConstruct`
```java
import javax.annotation.PostConstruct;  
import org.springframework.stereotype.Service;  
import java.util.HashMap;  
import java.util.Map;  
  
@Service  
public class UserService {  
    private final UserRepository userRepository;  
    private Map<Long, User> userCache = new HashMap<>();  
  
    public UserService(UserRepository userRepository) {  
        this.userRepository = userRepository;  
    }  
  
    @PostConstruct  
    public void init() {  
        System.out.println("Loading users into cache...");  
        userRepository.findAll().forEach(user -> userCache.put(user.getId(), user));  
        System.out.println("Users loaded successfully!");  
    }  
  
    public User getUserById(Long id) {  
        return userCache.get(id); // Now it works because cache is preloaded  
    }  
}
```

# How It Works?

1.  Spring Boot **creates the** `**UserService**` **bean**.
2.  It **injects** `**UserRepository**` **into** `**UserService**`.
3.  The `@PostConstruct` method `init()` runs **automatically**, loading users into the cache.
4.  Now, `getUserById(id)` can return users from the cache instead of an empty map

It’s important to note that while `@PostConstruct` was removed from the `javax.annotation` package starting with Java 9+, it has been moved to the `jakarta.annotation` package as part of the Jakarta EE transition. This means that `@PostConstruct` and `@PreDestroy` are still available in Spring Boot 3+, just under the `jakarta.annotation` namespace. Therefore, they can still be used for initialization and cleanup tasks, but now in alignment with the Jakarta EE standard As an alternative, you can use **Spring’s** `**@EventListener**` with `ApplicationReadyEvent` to achieve similar functionality

# What is `@EventListener(ApplicationReadyEvent.class)`?

-   It is a Spring-specific way to run code **after the application has fully started** and is ready to handle requests.
-   Unlike `@PostConstruct`, which runs after a single bean is initialized, `@EventListener(ApplicationReadyEvent.class)` runs **once the entire Spring application context is fully initialized**

# Why Use `@EventListener(ApplicationReadyEvent.class)`?

-   It ensures that your initialization logic runs **only after the entire application is ready**.
-   It is useful for tasks like:
-   Loading data into the database.
-   Starting background processes.
-   Validating configurations.
-   Sending startup notifications

# Example: Using `@EventListener(ApplicationReadyEvent.class)`

Here’s how you can replace `@PostConstruct` with `@EventListener(ApplicationReadyEvent.class)`
```java
import org.springframework.boot.context.event.ApplicationReadyEvent;  
import org.springframework.context.event.EventListener;  
import org.springframework.stereotype.Component;  
  
@Component  
public class MyStartupTask {  
  
    // This method will run when the application is fully started  
    @EventListener(ApplicationReadyEvent.class)  
    public void onApplicationReady() {  
        System.out.println("Application is fully started and ready!");  
        performStartupTasks();  
    }  
  
    private void performStartupTasks() {  
        System.out.println("Performing startup tasks...");  
        // Example: Load data, validate configurations, etc.  
    }  
}
```
# Example: Loading Initial Data on Startup
```java
import org.springframework.boot.context.event.ApplicationReadyEvent;  
import org.springframework.context.event.EventListener;  
import org.springframework.stereotype.Component;  
  
@Component  
public class DataLoader {  
  
    @EventListener(ApplicationReadyEvent.class)  
    public void loadData() {  
        System.out.println("Loading initial data into the database...");  
        // Logic to load data  
    }  
}
```

# Example: Sending a Startup Notification
```java
import org.springframework.boot.context.event.ApplicationReadyEvent;  
import org.springframework.context.event.EventListener;  
import org.springframework.stereotype.Component;  
  
@Component  
public class StartupNotifier {  
  
    @EventListener(ApplicationReadyEvent.class)  
    public void notifyStartup() {  
        System.out.println("Application is ready! Sending notification...");  
        // Logic to send a notification (e.g., email, Slack message)  
    }  
}
```

# 2. What is `@PreDestroy` in Spring Boot?

In Spring Boot, `@PreDestroy` is used to mark a method that should run just **before** a **bean** (an object) is removed from the Spring container, typically when the application shuts down or when the bean is no longer needed.

You can think of it as a **clean-up method** that performs necessary tasks like closing files, releasing resources, or stopping background processes before the application completely shuts down.

# Real-World Example:

Imagine you have a **coffee machine** that, after being used, needs to **clean itself**. The cleaning process must happen **before the machine is turned off**, so it doesn’t leave any coffee grounds or water inside. This clean-up happens just before you **switch off** the machine.

In Spring Boot, `@PreDestroy` is like the cleaning process that ensures things are **properly cleaned up** before shutting down the application.

# Code Example:

Let’s say we have a service that opens a file when the application starts, and we want to **close the file** before the application shuts down
```java
import javax.annotation.PreDestroy;  
import org.springframework.stereotype.Service;  
  
@Service  
public class FileService {  
  
    // This simulates opening a file  
    private String fileResource = "File opened";  
  
    // @PreDestroy method to clean up the file resource before the bean is destroyed  
    @PreDestroy  
    public void cleanUp() {  
        System.out.println("Cleaning up the resources before shutdown...");  
        // Simulating closing the file or resource  
        fileResource = null;  
    }  
}
```

# What Happens Here:

-   When the application starts, the `FileService` bean is created, and it opens the file (this is just a simulation).
-   When the application is shutting down, the `@PreDestroy` method `cleanUp()` is called, which **closes the file** (or in our case, nullifies the resource).
-   This ensures that we **don’t leave any resources open** when the application stops

> I think you have a doubt, but here @PostConstruct is deprecated.`javax.annotation` package starting with Java 9+ Why is @PreDestroy not deprecated?

You’re absolutely right about the removal of `javax.annotation.PostConstruct` in **Spring Boot 3+**, which is a consequence of the `**javax.annotation**` **package being deprecated** in Java 9 . However, `**@PreDestroy**` is still available for use in Spring Boot 3+ due to some important reasons:

### Why `@PreDestroy` Is Still Available in Spring Boot 3+:

1.  **Backward Compatibility**: Spring is designed to maintain backward compatibility with existing applications. While `@PostConstruct` is no longer recommended due to its reliance on `javax.annotation` (which is removed in Java 9+), `**@PreDestroy**` continues to work for the time being. It hasn't been deprecated or removed because:

-   It doesn’t rely on any special external package for its functionality.
-   It is still considered useful for many applications, especially for performing cleanup tasks like closing resources or shutting down threads.

1.  **Jakarta EE Transition**: With Java 9+, the `**javax.annotation**` package was moved to **Jakarta EE**. The `@PreDestroy` annotation is now part of the **Jakarta Annotations** package, which is the future standard for annotations in Java EE-based applications (like Spring).
2.  In Spring 3+, while `javax.annotation` is removed, Spring **supports Jakarta EE annotations** (such as `@PreDestroy`) and is transitioning toward them. **Spring 6** (which is aligned with Jakarta EE) is more focused on adopting **Jakarta's annotations** and libraries, which is why `@PreDestroy` can still be used in Spring Boot 3+ without issue.

### Alternative to `@PostConstruct` and `@PreDestroy` in Spring Boot 3+:

If you’re targeting **Spring Boot 3+**, and the `@PostConstruct` or `@PreDestroy` annotations are unavailable due to the Jakarta transition, you can use **Spring's own event listener mechanism**.

### For Initialization (`@PostConstruct` alternative):

Instead of `@PostConstruct`, you can use Spring's `@EventListener` with the `ApplicationReadyEvent` to trigger initialization logic
```java
import org.springframework.boot.context.event.ApplicationReadyEvent;  
import org.springframework.context.event.EventListener;  
import org.springframework.stereotype.Service;  
  
@Service  
public class MyService {  
  
    @EventListener(ApplicationReadyEvent.class)  
    public void init() {  
        System.out.println("Application is ready. Performing initialization...");  
    }  
}
```

### For Cleanup (`@PreDestroy` alternative):

If you want to replace `@PreDestroy` for cleanup logic, you can implement the `DisposableBean` interface or use the `@Bean(destroyMethod = "methodName")` approach.

1.  **Using** `**DisposableBean**`:
```java
import org.springframework.beans.factory.DisposableBean;  
import org.springframework.stereotype.Service;  
  
@Service  
public class MyService implements DisposableBean {  
  
    @Override  
    public void destroy() throws Exception {  
        System.out.println("Cleaning up resources before shutdown...");  
    }  
}
```

2. Using `@Bean(destroyMethod = "methodName")`
```java
import org.springframework.context.annotation.Bean;  
import org.springframework.context.annotation.Configuration;  
  
@Configuration  
public class AppConfig {  
  
    @Bean(destroyMethod = "close")  
    public MyService myService() {  
        return new MyService();  
    }  
}  
  
class MyService {  
  
    public void close() {  
        System.out.println("Cleaning up resources...");  
    }  
}
```

### Summary:

-   `**@PreDestroy**` is still available in Spring Boot 3+ because it remains useful for resource cleanup, and the functionality is supported by Jakarta EE annotations.
-   `**@PostConstruct**` is removed in Spring Boot 3+ due to the deprecation and removal of `javax.annotation` in Java 9+, and it's recommended to use Spring alternatives like `@EventListener(ApplicationReadyEvent.class)`

---
# 🔐Reentrant Lock vs Synchronized Keyword In Java

### Reentrant Lock

Reentrant Locks are provided in Java to provide synchronization with greater flexibility. ReentrantLock is a concrete implementation of Lock interface provided in Java concurrency package from Java 1.5 onwards.

![](https://miro.medium.com/v2/resize:fit:875/1*go67Q9tQN7PdIgYL3yzPuw.png)

### Synchronized Keyword

With synchronized keyword, we can achieve thread synchronization like this.

![](https://miro.medium.com/v2/resize:fit:875/1*wPD2dT21jLdCiBwnYrZqfg.png)

Listed below are the major differences between using **synchronized** and **ReentrantLock** :

-   **Rigidness**

While synchronized keyword provides basic synchronization, it is quite rigid in its use. For example, a thread can take a lock only once.

While in case of ReentrantLock, it allows threads to enter into the lock on a resource more than once. When the thread first enters into the lock, a hold count is set to one. Before unlocking the thread can re-enter into lock again and every time hold count is incremented by one. For every unlocks request, hold count is decremented by one and when hold count is 0, the resource is unlocked.

-   **Fairness**

Synchronized blocks don’t offer any mechanism of a waiting queue and after the exit of one thread, any thread can take the lock. This could lead to **starvation** for a thread which is waiting for a very long period of time. To avoid this a Lock should be fair.

Synchronized keyword doesn’t support fairness. Any thread can acquire lock once released and there is no mechanism to provide the preference. On the other hand, we can make a ReentrantLock fair. Fairness property provides lock to longest waiting thread. While creating an instance of ReentrantLock, we can define the fairness property.

Fair lock:

**ReentrantLock lock = new ReentrantLock(true);**

Unfair lock :

**ReentrantLock lock = new ReentrantLock();**

-   **Ability to interrupt**

In case of synchronized keyword, there is no way to control a thread which is waiting to acquire the lock for an indefinite period of time.

ReentrantLock provides a method called lockInterruptibly(), which can be used to interrupt thread when it is waiting for lock. The lockInterruptibly() method allows us to try and acquire a lock while being available for interruption. So, basically it allows the thread to immediately react to the interrupt signal sent to it from another thread. This can be helpful when we want to send a KILL signal to all the waiting locks.

-   **TryLock**

ReentrantLock provides convenient tryLock() method, which acquires lock only if its available or not held by any other thread. This reduces blocking of threads waiting to acquire the lock in application. This is not possible in case of synchronized keyword.

With tryLock() method, we can know whether we got the lock or not. If lock is not acquired then we can proceed with doing some alternate task otherwise if lock is required then we can proceed with accessing the resource as shown below.

![](https://miro.medium.com/v2/resize:fit:875/1*PAFe0hXZ5EIZBucXapiUAg.png)

So, in summary **ReentrantLock** is a better replacement for **synchronized** keyword. If you need flexibilty then you should always choose ReentrantLock !!!

---
# 🔐 Pessimistic vs Optimistic Locking: Understanding the Two Faces of Concurrency Control 

Concurrency in software systems is like traffic on a highway: the more cars (users), the more chances for collisions (conflicts). And when you’re dealing with databases or shared resources, **locking strategies** are your crash-prevention systems.

Two of the most common approaches are:

-   **Pessimistic Locking**
-   **Optimistic Locking**

And choosing the right one is not about which is “better” — it’s about **which is better for your use case**.

Let’s dive into how they work, when to use them, and what happens when they go wrong.

### 🔒 What is Pessimistic Locking?

**Pessimistic Locking** assumes the worst:

> “If two people try to change this data at the same time, it’s going to break.”

So it **locks the resource early** — when a transaction reads it — and holds that lock until the transaction completes.

### 🔧 How it works:

1.  You fetch a record for update.
2.  The system locks it (so others can’t read or write it).
3.  You make changes and commit.
4.  Lock is released.

### ✅ Pros:

-   Prevents race conditions at the source.
-   Guarantees consistency in **high-contention** scenarios.

### ❌ Cons:

-   Can cause **deadlocks** or **blocking** (slow users block fast ones).
-   Lower performance under high load.
-   Poor fit for high-concurrency systems.

### 📌 Example (SQL):

SELECT * FROM accounts WHERE id = 1 FOR UPDATE;

### 🪄 What is Optimistic Locking?

**Optimistic Locking** assumes the best:

> “Most of the time, people won’t edit the same data at the same time.”

So it **doesn’t lock the data**. Instead, it tracks whether the data has changed between read and write — and **fails** the operation if a conflict is detected.

### 🔧 How it works:

1.  You read a record along with a **version number** or **timestamp**.
2.  You update the record and send back the version you read.
3.  If the version matches the latest in the database → update proceeds.
4.  If not → update fails → you handle the conflict (e.g., retry or abort).

### ✅ Pros:

-   No blocking — great for **high concurrency** systems.
-   Better performance in **low-conflict** workloads.
-   Works well in distributed systems (like microservices or mobile sync).

### ❌ Cons:

-   Requires manual conflict resolution logic.
-   Not ideal for **high-conflict** data (e.g., financial ledgers).
-   Users might get update failures and need to retry.

### 📌 Example (SQL):

UPDATE accounts  
SET balance = 1000, version = version + 1  
WHERE id = 1 AND version = 3;

### 🧠 Real-World Analogy

> **Pessimistic Locking** is like reserving a conference room — no one else can use it until you’re done.
> 
> **Optimistic Locking** is like editing a shared doc — you save only if no one else made changes since you opened it.

### 🧾 Conclusion

-   **Pessimistic Locking**: Block others while you work — safe but slow.
-   **Optimistic Locking**: Let others work — but check before you commit.

Both strategies are valid. The right choice depends on **your system’s concurrency profile, conflict probability, and business risk tolerance !!!**

---

### 🌀 Spring Boot’s OncePerRequestFilter in Asynchronous Request Processing: What, Why, and How

Asynchronous processing is a key part of building responsive, scalable web applications. In Spring Boot, features like `@Async`, `DeferredResult`, and `Callable` allow you to handle long-running requests efficiently.

But when dealing with async requests, it’s easy to trip over subtle issues — like filters executing multiple times or unexpectedly during internal dispatches.

That’s where Spring’s `OncePerRequestFilter` really shines. It ensures your custom filter logic executes **only once**, even in **asynchronous request scenarios**.

In this article, we’ll dive into:

✅ Why `OncePerRequestFilter` matters in async  
✅ How it behaves differently from standard filters  
✅ A working Spring Boot example using `DeferredResult`

### 🧠 Why Do Filters Run Multiple Times in Async Scenarios?

When Spring MVC handles asynchronous requests, the lifecycle of a request can span multiple phases:

1.  The **initial dispatch** to the controller (sets up async processing)
2.  A **subsequent dispatch** when the result is ready (writes the response)

In a traditional `javax.servlet.Filter`, this can lead to your filter running **twice**—once in each dispatch.

> **_Problem_**_: Without proper safeguards, your filter could log, authenticate, or transform the same request_ **_multiple times_** _— leading to duplicated logs, broken logic, or security gaps._

### 💡 How `OncePerRequestFilter` Fixes This

`OncePerRequestFilter` is Spring’s elegant solution. It ensures your filter logic inside `doFilterInternal()` is called **exactly once per HTTP request**, even if the request is processed asynchronously.

It works by storing a flag(**ALREADY_FILTERED_SUFFIX**) in the `HttpServletRequest` attributes and checking it before executing. If the filter has already run for this request, it skips.

### 👏 Bonus: It Also Works Seamlessly with Spring Security and Reactive Components!

### 🔧 Let’s Build It: Logging Async Requests Once

We’ll build a Spring Boot app that:

-   Has an endpoint that returns a response **after 2 seconds**, asynchronously.
-   Uses `OncePerRequestFilter` to **log request details once**—even when the request is processed in two phases.

### 1. Project Setup

Add these dependencies (Maven):
```xml
<dependency>  
  <groupId>org.springframework.boot</groupId>  
  <artifactId>spring-boot-starter-web</artifactId>  
</dependency>
```
### 2. Async Controller with `DeferredResult`
```java
package com.example.demo.controller;  
  
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.RestController;  
import org.springframework.web.context.request.async.DeferredResult;  
  
@RestController  
public class AsyncController {  
    @GetMapping("/async")  
    public DeferredResult<String> handleAsync() {  
        DeferredResult<String> result = new DeferredResult<>();  
        new Thread(() -> {  
            try {  
                Thread.sleep(2000); // Simulate delay  
                result.setResult("Async Response after delay");  
            } catch (InterruptedException e) {  
                result.setErrorResult("Error occurred");  
            }  
        }).start();  
        return result;  
    }  
}
```
### 3. Custom `OncePerRequestFilter`
```java
package com.example.demo.filter;  
  
import jakarta.servlet.FilterChain;  
import jakarta.servlet.ServletException;  
import jakarta.servlet.http.HttpServletRequest;  
import jakarta.servlet.http.HttpServletResponse;  
import org.springframework.stereotype.Component;  
import org.springframework.web.filter.OncePerRequestFilter;  
import java.io.IOException;  
  
@Component  
public class AsyncLoggingFilter extends OncePerRequestFilter {  
    @Override  
    protected void doFilterInternal(HttpServletRequest request,  
                                    HttpServletResponse response,  
                                    FilterChain filterChain)  
            throws ServletException, IOException {  
        System.out.println("[Filter] Method: " + request.getMethod());  
        System.out.println("[Filter] URI: " + request.getRequestURI());  
        filterChain.doFilter(request, response);  
    }  
}
```

### 4. Main Application
```java
package com.example.demo;  
  
import org.springframework.boot.SpringApplication;  
import org.springframework.boot.autoconfigure.SpringBootApplication;  
  
@SpringBootApplication  
public class DemoApplication {  
    public static void main(String[] args) {  
        SpringApplication.run(DemoApplication.class, args);  
    }  
}
```

### 5. Run and Observe

1.  Start your app.
2.  Access `[http://localhost:8080/async](http://localhost:8080/async.)`[.](http://localhost:8080/async.)
3.  You’ll see a delay of 2 seconds before the response.
4.  Check the console logs:

[Filter] Method: GET  
[Filter] URI: /async

> _✅ You’ll notice the log appears_ **_only once_**_, even though the request lifecycle has two parts (initial and resumed)._

### 🚧 What Happens With a Standard Filter?

If you replace `OncePerRequestFilter` with a plain `Filter`, and don’t handle async dispatch types manually, you’ll likely see:

[Filter] Method: GET  
[Filter] URI: /async  
[Filter] Method: GET  
[Filter] URI: /async

This could lead to duplicated logging, double authentication, or even inconsistent data handling.

### 🛠 Optional:

### Customize for Async Dispatch Types

Spring also allows you to override:
```java
@Override  
protected boolean isAsyncDispatch(HttpServletRequest request) {  
    return super.isAsyncDispatch(request);  
}
```
This gives you more control if you need to inspect or handle async phases differently.

### Handling Edge Cases ⚠️

### Conditional Execution 🚦

Override **shouldNotFilter** to skip certain requests, like static resources.
```java
package com.example.demo.filter;  
  
import org.springframework.web.filter.OncePerRequestFilter;  
import javax.servlet.FilterChain;  
import javax.servlet.ServletException;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
import java.io.IOException;  
import org.slf4j.Logger;  
import org.slf4j.LoggerFactory;  
  
public class SelectiveRequestLoggingFilter extends OncePerRequestFilter {  
    private static final Logger logger = LoggerFactory.getLogger(SelectiveRequestLoggingFilter.class);  
  
    @Override  
    protected boolean shouldNotFilter(HttpServletRequest request) {  
        String path = request.getRequestURI();  
        return path.startsWith("/static/") || path.endsWith(".css") || path.endsWith(".js");  
    }  
  
    @Override  
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)  
            throws ServletException, IOException {  
        long startTime = System.currentTimeMillis();  
        String requestURI = request.getRequestURI();  
        logger.info("Processing request: {} 🚀", requestURI);  
  
        try {  
            filterChain.doFilter(request, response);  
        } finally {  
            long duration = System.currentTimeMillis() - startTime;  
            logger.info("Completed request: {} in {} ms ✅", requestURI, duration);  
        }  
    }  
}
```
### 🔚 Conclusion

`OncePerRequestFilter` is not just another filter—it’s the _right_ filter to use when building modern, async-aware Spring Boot applications. It simplifies your logic, protects against double-processing, and plays well with Spring’s async engine.

If you’re using `@Async`, `DeferredResult`, or `Callable` endpoints, **don’t leave your filters to chance.** Use `OncePerRequestFilter` and keep your middleware clean and consistent.

---
# The Problem with Distributed Locking in Spring Boot: Why Redis and DB Locks Aren’t Enough Anymore

In the world of microservices and distributed systems, **concurrency control** is one of the most critical challenges. When multiple instances of an application or multiple services attempt to modify the same resource simultaneously, data inconsistency, race conditions, or even system crashes can occur.

**Distributed locking** comes to the rescue.

In this article, we’ll dive deep into:

-   What distributed locking is
-   Why it’s crucial in distributed Spring Boot applications
-   Traditional approaches like **Redis** and **Database locks**
-   Emerging solutions you might not have heard of
-   Practical advice on when and what to choose

Let’s get started! 🚀

### 🌟 What Is Distributed Locking?

Distributed locking ensures that **only one process across multiple nodes** can access a specific resource at a time. It’s like a **mutex** but extended across multiple machines, containers, or services.

Imagine two instances of your Spring Boot application both trying to update the same user’s balance. Without a distributed lock, both could read the old balance, add funds, and save — resulting in lost or incorrect data.

Thus, **distributed locks protect critical sections** of your code across a distributed environment.

### 🛡️ Why Distributed Locks Matter in Spring Boot

Spring Boot applications often run behind:

-   Kubernetes clusters
-   AWS Elastic Beanstalk
-   Docker Swarms
-   Any load-balanced environments

In these setups:

-   Multiple instances of the same app can operate in parallel.
-   APIs, schedulers, background jobs, and event processors run concurrently.
-   Shared resources (databases, files, caches) are common.

Without proper distributed locking, even simple tasks like scheduling a job **once** instead of **multiple times** become problematic.

**Use Cases** include:

-   Scheduled tasks that must not run concurrently.
-   Payment systems that update balances.
-   Inventory management (deducting stock).
-   Preventing duplicate processing in messaging systems (Kafka, RabbitMQ).

### 🔥 The Traditional Giants: Redis and Database Locks

### 1. Redis-Based Distributed Locking

**Redis** is the most popular tool for distributed locking, thanks to:

-   Its fast in-memory architecture
-   Wide adoption
-   Libraries like Redisson and Spring Data Redis

### How Redis Lock Works

-   **SET resourcename uniquevalue NX PX timeout  
    —** `NX` ensures it only sets the key if it doesn't exist.  
    — `PX timeout` sets an expiration to prevent deadlocks.
-   Release only if the unique value matches (to avoid releasing someone else’s lock).

### Tools and Libraries

-   **Redisson**: Provides a rich API for locks, semaphores, latches.
-   **Spring Data Redis**: Lower-level, but you can build your own locks.

### Example with Redisson in Spring Boot
```java
@Autowired  
private RedissonClient redissonClient;  
  
public void criticalSection() {  
    RLock lock = redissonClient.getLock("myLock");  
    boolean acquired = lock.tryLock();  
    try {  
        if (acquired) {  
            // Critical section  
        }  
    } finally {  
        if (acquired) {  
            lock.unlock();  
        }  
    }  
}
```
### Pros

-   Blazing fast
-   Battle-tested
-   Great libraries

### Cons

-   Redis becomes a **single point of failure** if not clustered.
-   Need careful tuning of expiration timeouts.
-   Requires external infrastructure (Redis server/cluster).

### 2. Database (DB) Locks

Relational databases (MySQL, PostgreSQL) also offer locking mechanisms:

-   **Pessimistic Locks** (`SELECT ... FOR UPDATE`)
-   **Optimistic Locks** (using version numbers)

### How DB Locks Work

-   Pessimistic: The row or table is locked until the transaction commits or rolls back.
-   Optimistic: Version field is incremented and checked for changes.

### Example with JPA Optimistic Lock
```java
@Entity  
public class Inventory {  
    @Id  
    private Long id;  
  
    @Version  
    private Integer version;  
  
    private Integer quantity;  
}
```
If two transactions attempt to update the same row, one will fail due to a version mismatch.

### Pros

-   No additional infrastructure needed.
-   Strong consistency guarantees.

### Cons

-   Adds load to the database.
-   Not ideal for high-frequency locking scenarios.
-   Locks can become a bottleneck.

### 🧪 Something New: Emerging Alternatives

While Redis and Database locks are widely used, newer options are emerging, promising **better scalability, robustness, and simplicity**.

### 1. Etcd (Used by Kubernetes Internally)

-   Etcd is a distributed key-value store optimized for strong consistency.
-   Supports **compare-and-swap** operations.
-   You can implement distributed locks with high availability.
-   Libraries: Jetcd for Java.

**Pros**: Built for high availability, cluster coordination.
**Cons**: Complex to deploy and manage outside Kubernetes.

### 2. Consul
-   Originally a service discovery tool, Consul now supports distributed locks using key-value storage and sessions.
-   Spring Boot apps can use libraries like `spring-cloud-consul`.

**Pros**:
-   Easy integration if you already use Consul for service discovery.

**Cons**:

-   Not as fast as Redis.

### 3. Zookeeper

-   Apache Zookeeper is a coordination service that provides locking via ephemeral znodes.
-   Libraries like Curator simplify distributed locks with Zookeeper.

**Pros**:

-   Battle-tested (used in Kafka, Hadoop, etc.).
-   Strong consistency.

**Cons**:

-   Heavyweight for simple use cases.
-   Operational complexity.

### 4. Hazelcast

-   In-memory data grid with distributed locking support.
-   Easily embeddable in Spring Boot applications.

**Example Usage**
```java
@Autowired  
private HazelcastInstance hazelcastInstance;  
  
public void criticalSection() {  
    ILock lock = hazelcastInstance.getLock("myLock");  
    lock.lock();  
    try {  
        // Critical section  
    } finally {  
        lock.unlock();  
    }  
}
```
**Pros**:

-   No external infra needed (can run embedded).
-   Fast.

**Cons**:

-   Cluster management can be tricky at scale.

### ⚖️ So… Redis, DB Locks, or Something New?

![](https://miro.medium.com/v2/resize:fit:875/1*ldguOPadWGtleaL8N-ERMw.png)

### 🧠 Best Practices for Distributed Locking

-   **Timeouts are critical**: Always set expiration to avoid deadlocks.
-   **Idempotency is king**: Even with locks, ensure your operations are idempotent.
-   **Release locks safely**: Verify the lock is still held before releasing.
-   **Monitor** lock acquisition failures: If acquiring a lock fails too often, investigate.
-   **Avoid large critical sections**: Keep locked operations small and fast.

### 🎯 Conclusion

Distributed locking is a foundational building block for **building resilient and correct Spring Boot microservices**.

-   If you need **speed and simplicity**, Redis is often the best choice.
-   If you want **zero new infrastructure**, database locks work but must be handled carefully.
-   For **serious distributed coordination**, consider Etcd, Zookeeper, or Consul.

Remember: Distributed locking adds complexity. Use it only when **absolutely necessary**, and always prioritize **idempotent, retryable designs** when possible.

### Spring Boot Message Queues using virtual thread

The enterprise development world is experiencing a seismic shift, and most developers are missing it entirely. Spring Boot 3.5’s revolutionary Virtual Threads and enhanced reactive capabilities aren’t just incremental improvements — they’re fundamentally changing how we think about asynchronous processing, potentially making traditional message queues obsolete for many use cases.

After migrating three production systems from RabbitMQ-heavy architectures to Spring Boot 3.5’s native async patterns, I’ve witnessed performance improvements that challenge everything we thought we knew about scalable system design.

![](https://miro.medium.com/v2/resize:fit:875/1*xuxC-qbzKNArMBsXG-3jw.jpeg)

### The Message Queue Monopoly is Crumbling

For years, message queues have been the go-to solution for decoupling services and handling asynchronous processing. Redis, RabbitMQ, Apache Kafka — these tools became so entrenched in our architecture patterns that questioning their necessity felt like heresy.

But Spring Boot 3.5 changes the game entirely. With Project Loom’s Virtual Threads now production-ready and seamlessly integrated, the framework can handle millions of concurrent operations without the overhead that previously forced us into message queue patterns.
```java
@Service  
public class OrderProcessingService {  
      
    @Async("virtualThreadExecutor")  
    public CompletableFuture<OrderResult> processOrder(Order order) {  
        // This now runs on a virtual thread  
        return CompletableFuture.supplyAsync(() -> {  
            validateOrder(order);  
            calculatePricing(order);  
            reserveInventory(order);  
            processPayment(order);  
            return new OrderResult(order);  
        });  
    }  
      
    @Bean  
    public Executor virtualThreadExecutor() {  
        return Executors.newVirtualThreadPerTaskExecutor();  
    }  
}
```
### The Performance Revolution: Real Numbers

In my recent benchmark comparing a traditional Spring Boot 2.7 application with RabbitMQ against Spring Boot 3.5 with Virtual Threads, the results were staggering:

**Traditional Setup (Spring Boot 2.7 + RabbitMQ):**

-   Peak throughput: 5,000 requests/second
-   Memory usage: 2.1GB under load
-   Average latency: 250ms
-   Infrastructure complexity: 6 components

**Spring Boot 3.5 Native Async:**

-   Peak throughput: 18,000 requests/second
-   Memory usage: 850MB under load
-   Average latency: 65ms
-   Infrastructure complexity: 2 components

The elimination of message serialization, network hops, and queue management overhead created a 260% performance improvement while reducing infrastructure complexity by 67%.

### Architectural Transformation

Here’s how the architectural paradigm shifts:

Traditional Message Queue Architecture:  
┌─────────────┐    ┌──────────────┐    ┌─────────────┐    ┌──────────────┐  
│   Client    │───▶│  API Gateway │───▶│ Message Q   │───▶│   Worker     │  
└─────────────┘    └──────────────┘    └─────────────┘    └──────────────┘  
                                              │  
                                              ▼  
                                       ┌─────────────┐  
                                       │  Database   │  
                                       └─────────────┘  
  
  
Spring Boot 3.5 Native Async Architecture:  
┌─────────────┐    ┌──────────────┐    ┌─────────────┐  
│   Client    │───▶│ Spring Boot  │───▶│  Database   │  
└─────────────┘    └──────────────┘    └─────────────┘  
                    │ Virtual Thread│  
                    │ Pool (Millions)│  
                    └───────────────┘

### Real-World Implementation: E-commerce Order Processing

Let me walk you through a real implementation that replaced our entire RabbitMQ-based order processing system:
```java
@RestController  
public class OrderController {  
      
    @Autowired  
    private OrderOrchestrator orchestrator;  
      
    @PostMapping("/orders")  
    public ResponseEntity<OrderResponse> createOrder(@RequestBody OrderRequest request) {  
        // This handles the entire async pipeline without message queues  
        CompletableFuture<OrderResult> future = orchestrator.processOrderPipeline(request);  
          
        return ResponseEntity.ok(new OrderResponse(future.join()));  
    }  
}  
@Component  
public class OrderOrchestrator {  
      
    public CompletableFuture<OrderResult> processOrderPipeline(OrderRequest request) {  
        return CompletableFuture  
            .supplyAsync(() -> validateOrder(request), virtualThreadExecutor())  
            .thenComposeAsync(order -> reserveInventory(order), virtualThreadExecutor())  
            .thenComposeAsync(order -> processPayment(order), virtualThreadExecutor())  
            .thenComposeAsync(order -> updateInventory(order), virtualThreadExecutor())  
            .thenComposeAsync(order -> sendNotifications(order), virtualThreadExecutor());  
    }  
}
```
This single service replaced what previously required four separate microservices connected through RabbitMQ queues, reducing deployment complexity and eliminating multiple points of failure.

### The Counterarguments: When Message Queues Still Matter

Critics rightfully point out scenarios where message queues remain irreplaceable. Event sourcing architectures, cross-system integration, and scenarios requiring guaranteed message delivery still benefit from dedicated message brokers.

However, the scope of these use cases is shrinking rapidly. Spring Boot 3.5’s enhanced transaction management and failure recovery mechanisms handle most reliability concerns that previously required message queue guarantees.
```java
@Transactional(rollbackFor = Exception.class)  
@Retryable(value = {Exception.class}, maxAttempts = 3)  
public CompletableFuture<ProcessingResult> processWithReliability(Task task) {  
    return CompletableFuture.supplyAsync(() -> {  
        // Transactional processing with automatic retry  
        return executeBusinessLogic(task);  
    }, virtualThreadExecutor());  
}
```
### The Developer Experience Revolution

The cognitive load reduction is perhaps more significant than the performance gains. Developers no longer need to:

-   Design message schemas and serialization strategies
-   Manage queue configurations and dead letter queues
-   Handle message routing and exchange patterns
-   Debug distributed tracing across queue boundaries
-   Maintain separate consumer applications

Instead, the entire async processing pipeline exists within familiar Spring Boot patterns, making debugging, testing, and maintenance dramatically simpler.

### Production Migration Strategy

For teams considering this transition, here’s the phased approach that worked for us:

Phase 1: New Features (Low Risk)  
┌─────────────────┐  
│ Implement new   │  
│ async features  │  
│ using Virtual   │  
│ Threads         │  
└─────────────────┘  
Phase 2: Non-Critical Services (Medium Risk)  
┌─────────────────┐  
│ Migrate         │  
│ reporting and   │  
│ analytics       │  
│ services        │  
└─────────────────┘  
Phase 3: Core Services (High Risk)  
┌─────────────────┐  
│ Replace message │  
│ queue patterns  │  
│ in core business│  
│ logic           │  
└─────────────────┘

### Industry Implications and Future Predictions

Major cloud providers are already adapting. AWS recently announced enhanced support for Virtual Thread workloads in their container services, while Google Cloud is optimizing their JVM implementations specifically for Project Loom patterns.

By 2026, I predict we’ll see a 40% reduction in message queue usage for internal service communication, with queues relegated primarily to external integrations and event streaming scenarios.

### The Bottom Line: Simplicity Wins

The message queue era solved real problems, but it also introduced complexity that Spring Boot 3.5 now makes unnecessary. Virtual Threads provide the scalability benefits of async processing without the operational overhead of distributed message systems.

For greenfield projects, the choice is clear: start with Spring Boot 3.5’s native async capabilities and introduce message queues only when specific requirements demand them. For existing systems, begin experimenting with Virtual Thread patterns for new features while planning strategic migrations for core services.

The future of enterprise development is simpler, faster, and more maintainable — and it doesn’t require a message queue for every async operation.

---
# Step by step Spring boot integration with Prometheus and Grafana 
# Overview

Observability is important for applications running critical businesses. It is an ability to observe an application’s internal state from outside. As often said, logs, metrics, and traces are three pillars of observability.

-   **Logs** are chronological sequence of events. Logs are mostly recorded as plain texts (binary and structured formats are also possible) and are important for debugging and understanding system events and failures.
-   **Metrics** are aggregated data or the current status of an event or application performance. Metrics can provide real-time insights like CPU utilization, average HTTP response time, or total HTTP requests.
-   **Traces** provides detailed information regarding end-to-end flow from start to end. It tracks requests as it passes through an application’s various components or services. Traces are more complex than logs and metrics

In this blog, we will focus on metrics. Spring Boot provides auto-configuration for integration with [Micrometer](https://micrometer.io/). It is like SLF4J but for observability.

# **Steps**

We will create custom metrics and a health indicator and will follow below steps:

1.  Enable Prometheus endpoint using actuator and micrometer registry.
2.  Create an Aspect that will monitor REST API response time using [JaMon](https://jamonapi.sourceforge.net/).
3.  Create custom metrics for HTTP response time and request counts.
4.  Create a custom health indicator.
5.  Set up Prometheus to scrape metrics in frequent intervals.
6.  Set up a Grafana dashboard to visualize metrics in near real-time.

# Implementation

**1 Enable Prometheus endpoint using an actuator and micrometer registry**

Add below dependencies to pom.xml
```xml
<dependency>  
  <groupId>org.springframework.boot</groupId>  
  <artifactId>spring-boot-starter-actuator</artifactId>  
</dependency>  
  
<dependency>  
  <groupId>io.micrometer</groupId>  
  <artifactId>micrometer-registry-prometheus</artifactId>  
</dependency>
```

Endpoints can be enabled or exposed via HTTP or JMX. We will focus on HTTP only.

Enabled: By default, all endpoints are enabled except shutdown

Exposed: By default, only the health endpoint is exposed

Let us expose other endpoints too. Add the below line to your application properties:
```shell
management.endpoints.web.exposure.include=*
```
(*) will expose all the ends (not recommended). We can use comma-separated values to specify selected endpoints. Now if we go to _/actuator/metrics_, we will see a list of all metrics. Now go to _/actuator/prometheus_, and we will see similar metrics and their values in a particular format. This is what we will use while configuring Prometheus

**2 Create an Aspect that will monitor REST API response time using** [**JaMon**](https://jamonapi.sourceforge.net/)

Create an Around advice. For this, I have created an annotation. I have written an entire article on AOP [here](/@yogendra.209/custom-redis-cache-using-spring-aop-d04b49756a8f). Give it a try. JaMon is Java Application Monitoring API that allows developers to easily monitor applications. Inject JaMon dependency:
```xml
<dependency>  
   <groupId>com.jamonapi</groupId>  
   <artifactId>jamon</artifactId>  
   <version>2.82</version>  
</dependency>
```
Now we will create and configure beans for JaMon:
```java
@Configuration  
@ComponentScan(basePackages = "com.yogendra.aspect")  
@EnableAspectJAutoProxy  
public class MonitorConfig {  
    @Bean  
    MonitorFactoryInterface monitorFactory() {  
        return MonitorFactory.getFactory();  
    }  
}  
  
@Component  
@Aspect  
public class MonitorAspect {  
  
    private final MonitorFactoryInterface monitorFactoryInterface;  
  
    public MonitorAspect(MonitorFactoryInterface monitorFactoryInterface) {  
        this.monitorFactoryInterface = monitorFactoryInterface;  
    }  
  
  
    @Around("@annotation(com.yogendra.annotation.MethodMonitor)")  
    public Object monitorMethodExecution(ProceedingJoinPoint joinPoint) throws Throwable {  
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();  
        Method method = methodSignature.getMethod();  
        MethodMonitor methodMonitor = method.getAnnotation(MethodMonitor.class);  
        Monitor monitor = monitorFactoryInterface.start(methodMonitor.name());  
        try {  
            return joinPoint.proceed();  
        } finally {  
            monitor.stop();  
        }  
    }  
}  
  
@Target({ElementType.METHOD})  
@Retention(RetentionPolicy.RUNTIME)  
public @interface MethodMonitor {  
    String name() default "";  
  
    String uri() default "";  
  
    String method() default "GET";  
}
```
Now we can plug in any of our methods with `MethodMonitor` and JaMon will start monitoring it. That’s how powerful AOP is.

**3 Create custom metrics for HTTP response time and request counts**

Let’s talk about [Micrometer](https://docs.micrometer.io/micrometer/reference/concepts.html) a little bit. Micrometer is a metrics instrumentation library for JVM-based applications. The main interface in Micrometer is `Meter`. Meters are created and held in a `MeterRegistry` . The dependency which we added in Step 1 will auto-configure `PrometheusMeterRegistry` . Micrometer provides multiple types of `Meters` like `Counter` , `Guage` , `Timer` , `DistributionSummary` etc. We will implement `Counter` and `Guage` in this example. We will create two metrics **http.requests.count** and **http.response.time**:
```java
Counter.builder("http.requests.count")  
       .tag("uri", methodMonitor.uri())  
       .tag("method", methodMonitor.method())  
       .register(meterRegistry).increment();  
  
Gauge.builder("http.response.time", monitor::getLastValue)  
     .tag("uri", methodMonitor.uri())  
     .tag("method", methodMonitor.method())  
     .register(meterRegistry);
```
The first one is counting the number of HTTP requests made per URI per HTTP method (GET, PUT, etc). Later one measures the execution time of an API per URI per HTTP method (GET, PUT, etc). Add the above metrics to our `MonitorAspect` created in step 2. Our updated advice will look like this:
```java
@Component  
@Aspect  
public class MonitorAspect {  
  
    private final MonitorFactoryInterface monitorFactoryInterface;  
    private final MeterRegistry meterRegistry;  
  
    public MonitorAspect(MonitorFactoryInterface monitorFactoryInterface, MeterRegistry meterRegistry) {  
        this.monitorFactoryInterface = monitorFactoryInterface;  
        this.meterRegistry = meterRegistry;  
    }  
  
  
    @Around("@annotation(com.yogendra.annotation.MethodMonitor)")  
    public Object monitorMethodExecution(ProceedingJoinPoint joinPoint) throws Throwable {  
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();  
        Method method = methodSignature.getMethod();  
        MethodMonitor methodMonitor = method.getAnnotation(MethodMonitor.class);  
        Monitor monitor = monitorFactoryInterface.start(methodMonitor.name());  
        try {  
            return joinPoint.proceed();  
        } finally {  
            monitor.stop();  
            Counter.builder("http.requests.count")  
                    .tag("uri", methodMonitor.uri())  
                    .tag("method", methodMonitor.method())  
                    .register(meterRegistry).increment();  
            Gauge  
                    .builder("http.response.time", monitor::getLastValue)  
                    .tag("uri", methodMonitor.uri())  
                    .tag("method", methodMonitor.method())  
                    .register(meterRegistry);  
        }  
    }  
}
```

We have configured the required metrics. Now restart the server, call any API endpoint, and open _/actuator/prometheus_ in the browser. You can will find both metrics by the name of **http_requests_count** and **http_response_time**. Spring boot comes with auto-configured HTTP metrics which we can disable by adding
```shell
management.metrics.enable.http.server.requests=false
```
in `application.properties`

**4 Create a custom health indicator**

Spring Boot provides four different status codes-DOWN, OUT_OF_SERVICE, UP, UNKNOWN in the same severity order as written down. Based on the dependencies found in the classpath, Spring Boot can auto-configure several health indicators like `[JmsHealthIndicator](https://docs.spring.io/spring-boot/api/java/org/springframework/boot/actuate/jms/JmsHealthIndicator.html)`, `[DataSourceHealthIndicator](https://docs.spring.io/spring-boot/api/java/org/springframework/boot/actuate/jdbc/DataSourceHealthIndicator.html)`, `[RedisHealthIndicator](https://docs.spring.io/spring-boot/api/java/org/springframework/boot/actuate/data/redis/RedisHealthIndicator.html)`, etc which we can disable. As per business requirements, we might want to add some custom status based on something like the number of rows in a particular database table or the number of messages in a queue.

To create a health indicator we can either implement `HealthIndicator` or extend `AbstractHealthIndicator`:
```java
public class AccountHealthIndicator implements HealthIndicator {  
  
    public final JdbcTemplate jdbcTemplate;  
  
    public AccountHealthIndicator(JdbcTemplate jdbcTemplate) {  
        this.jdbcTemplate = jdbcTemplate;  
    }  
  
    @Override  
    public Health health() {  
        Long count = jdbcTemplate.queryForObject("select count(*) from account", Long.class);  
  
        if (count >= 1) {  
            return Health.up().withDetail("accounts", count).build();  
        } else {  
            return Health.status("NO_ACCOUNT").withDetail("accounts", count).build();  
        }  
    }  
}
```
Here we create a custom status-NO_ACCOUNT. To bring this into effect we will have to define its severity level:
```shell
management.endpoint.health.status.order=NO_ACCOUNT,DOWN,OUT_OF_SERVICE,UP,UNKNOWN
```
Now, let’s create a `HealthMetrics` for our newly created health Indicator. We will use `Guage` meter for this:
```java
public class HealthMetrics {  
  
    private final AccountHealthIndicator accountHealthIndicator;  
    private final MeterRegistry meterRegistry;  
  
    public HealthMetrics(AccountHealthIndicator accountHealthIndicator, MeterRegistry meterRegistry) {  
        this.accountHealthIndicator = accountHealthIndicator;  
        this.meterRegistry = meterRegistry;  
    }  
  
  
    @Scheduled(fixedRate = 15000, initialDelay = 0)  
    public void reportHealth() {  
        Gauge  
                .builder("application.health",  
                        () -> getStatus(accountHealthIndicator.getHealth(true).getStatus())  
                )  
                .register(meterRegistry);  
    }  
  
    private int getStatus(Status status) {  
       return switch (status.getCode()) {  
            case "NO_ACCOUNT" -> 0;  
            case "DOWN" -> 1;  
            case "OUT_OF_SERVICE" -> 2;  
            case "UP" -> 3;  
            default -> -1;  
        };  
    }  
}
```
Now restart your application and you will see the newly created metric **application_health**

**5 Set up Prometheus to scrape metrics in frequent intervals**

Prometheus is an open-source technology for monitoring and alerting. We can follow these [steps](https://prometheus.io/docs/introduction/first_steps/) to install Prometheus. By default Prometheus uses `prometheus.yml` as a default config file. Edit file as below:

![Prometheus configuration](https://miro.medium.com/v2/resize:fit:875/1*Ns8hWg77NKnuIpc3Xgw3QQ.png)

Here, we have kept most of the things as default. Under scrape configs, we updated the job name and target. Target is our Spring Boot application. To start the Prometheus server, we can use the below command:
```shell
./prometheus --web.listen-address=host:port
```
Go to status -> targets. We will see all active endpoints:

![Prometheus targets](https://miro.medium.com/v2/resize:fit:875/1*xw03EsRFC55EcuJgxe0MyA.png)

**6 Set up a Grafana dashboard to visualize metrics in near real-time**

To install Grafana in your local system, use [this](https://grafana.com/docs/grafana/latest/setup-grafana/installation/) link. Once Grafana is up and running we will configure a data source. Go to Home > Connections > Data sources > Add new data source. Select Prometheus and enter the Prometheus server URL which we set up in the previous step. Now go to Home > Dashboards > New dashboard and start adding visualizations. I will share the PromQL query for visualizations we will add to our dashboard:

(1) Health status (Stat) -> _application_health{application=”YOGENDRA”}_ and add below value mappings

![](https://miro.medium.com/v2/resize:fit:539/1*reDI6af_PjYH5aInNFc6Hg.png)

(2) Start time (Stat) -> _process_start_time_seconds{application=”YOGENDRA”}*1000_

(3) Uptime (Stat) -> _process_uptime_seconds{application=”YOGENDRA”}_

(4) Heap utilization (Guage) -> _sum(jvm_memory_used_bytes{application=”YOGENDRA”, area=”heap”})*100 / sum(jvm_memory_max_bytes{application=”YOGENDRA”, area=”heap”})_

(5) CPU utilization (Time series)

-   A -> _system_cpu_usage{application=”YOGENDRA”}_
-   B -> _process_cpu_usage {application=”YOGENDRA”}_

(6) HTTP response time (Time series) -> _http_response_time {application=”YOGENDRA”, uri!=”*/actuator/*”}_ Here we will transform data to show only those points where HTTP calls have been made. So go to Transform data and select Group by. In Time, select Calculate and select Stat _First*:_

![](https://miro.medium.com/v2/resize:fit:875/1*PZFFPGgABaaOutEDUOKt5g.png)

(7) HTTP request count (Time series) -> _http_requests_count_total{application=”YOGENDRA”, uri!=”*/actuator/*”}_ Here also we will transform data using reduce function which will look like:

![](https://miro.medium.com/v2/resize:fit:865/1*_HHIFWCjkJbwlvGVB-8kIA.png)

https://github.com/yogi0209/spring-aop-jamon

