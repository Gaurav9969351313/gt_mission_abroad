# Hazelcast Messaging. What is Hazelcast Messaging 

### What is Hazelcast Messaging

Hazelcast messaging provides several features that make it useful for building distributed systems, including high performance, scalability, fault tolerance, and security. Hazelcast messaging can be integrated with other systems and platforms, including Spring, JMS, and Apache Camel, which makes it easy to use in a variety of contexts. Additionally, Hazelcast provides tools for monitoring and managing the messaging system, which can help to ensure that the system is running smoothly and performing as expected.

> Features that make it useful for building distributed systems, including high performance, scalability, fault tolerance, and security.

**Building microservices architecture**: Hazelcast messaging provides a lightweight and scalable messaging system that can be used to enable communication between microservices. By using a publish-subscribe model, Hazelcast messaging can be used to broadcast messages to multiple microservices or to specific microservices that are interested in a particular event. This can help to decouple microservices and enable them to communicate in a more flexible and reliable way.

**Building distributed architecture**: Hazelcast messaging provides a distributed messaging system that can be used to enable communication between nodes in a cluster. By using a distributed in-memory data grid, Hazelcast messaging can provide high-speed, low-latency messaging that is fault-tolerant and scalable. This can be useful for building distributed architectures where nodes need to communicate with each other in a fast and reliable way.

**Building event-driven architecture**: Hazelcast messaging provides a publish-subscribe model that is well-suited for building event-driven architectures. By using topics and subscriptions, Hazelcast messaging can be used to handle events in a decoupled and asynchronous way. Hazelcast messaging also provides the ability to create custom messaging patterns, which can be useful for handling complex event-driven scenarios. Additionally, Hazelcast’s in-memory data grid can provide fast access to event data, making it a good choice for real-time event processing.

### Here is an example of Hazelcast Messaging
```java
public class Trader {  
    private HazelcastInstance hazelcast;  
    private ITopic<TradeMessage> tradeTopic;  
      
    public Trader() {  
        hazelcast = Hazelcast.newHazelcastInstance();  
        tradeTopic = hazelcast.getTopic("trades");  
    }  
      
    public void trade(String symbol, int quantity, double price) {  
        TradeMessage trade = new TradeMessage(symbol, quantity, price);  
        tradeTopic.publish(trade);  
    }  
}  

public class TradeListener implements MessageListener<TradeMessage> {  
    private HazelcastInstance hazelcast;  
    private ITopic<TradeMessage> tradeTopic;  
      
    public TradeListener() {  
        hazelcast = Hazelcast.newHazelcastInstance();  
        tradeTopic = hazelcast.getTopic("trades");  
        tradeTopic.addMessageListener(this);  
    }  
      
    public void onMessage(Message<TradeMessage> message) {  
        TradeMessage trade = message.getMessageObject();  
        System.out.println("New trade: " + trade.getSymbol() + " " + trade.getQuantity() + " @ " + trade.getPrice());  
    }  
}
```
### Kafka vs Hazelcast

Hazelcast and Apache Kafka are popular messaging systems used for building event-driven architectures and streaming applications. However, they have some differences in terms of their architecture, features, and use cases.

**Architecture**: Hazelcast’s messaging system is based on a distributed in-memory data grid, where messages are stored in memory across a cluster of nodes. Hazelcast provides a publish-subscribe mechanism for its messaging system, where publishers can publish messages to a specific topic, and subscribers can receive messages from that topic. On the other hand, Kafka is based on a distributed log architecture, where messages are stored in a distributed log across a cluster of brokers. Kafka provides a publish-subscribe mechanism and a point-to-point messaging mechanism, where messages can be delivered to a specific consumer.

**Features**: Hazelcast’s messaging system provides features such as message replication, backup nodes, and automatic failover to ensure high availability and fault tolerance. It also provides security features such as SSL/TLS encryption and authentication. Kafka provides features such as high-throughput, low-latency messaging, fault tolerance, and scalability. It also provides features such as stream processing, real-time analytics, and support for various protocols and APIs.

**Use Cases**: Hazelcast’s messaging system is well-suited for use cases where low-latency messaging and in-memory data processing are important. It can be used for building event-driven architectures, real-time analytics, and distributed caching. Kafka is well-suited for use cases where high-throughput, fault tolerance, and scalability are important. It can be used for building streaming applications, real-time data processing, and distributed messaging systems.

Overall, both Hazelcast and Kafka are powerful messaging systems that offer different features and capabilities. Hazelcast’s messaging system is focused on low-latency messaging and in-memory data processing, while Kafka is focused on high-throughput messaging and stream processing. The choice between the two depends on the specific requirements of the application and the use case.

### Hazelcast vs RabbitMQ

Hazelcast messaging and RabbitMQ are both messaging systems, but they differ in several ways. Here’s a comparison between Hazelcast messaging and RabbitMQ:

1.  Messaging Model: Hazelcast messaging uses a publish-subscribe model, where messages are sent to a topic and any nodes that have subscribed to that topic receive the message. RabbitMQ uses a message queue model, where messages are placed in a queue and consumers read messages from the queue.
2.  Architecture: Hazelcast messaging is built on top of an in-memory data grid and provides a distributed messaging system. RabbitMQ is built on top of an Erlang runtime and provides a standalone message broker that can be deployed on a server.
3.  Performance: Hazelcast messaging is designed for high performance and low-latency communication between nodes in a distributed system. RabbitMQ is designed for reliable message delivery and supports various messaging protocols.
4.  Scalability: Hazelcast messaging is designed to scale horizontally by adding more nodes to the cluster. RabbitMQ is also designed to scale horizontally, but this requires setting up a cluster of RabbitMQ brokers.
5.  Fault Tolerance: Hazelcast messaging provides fault tolerance features such as message replication, backup nodes, and automatic failover. RabbitMQ provides features such as message acknowledgements and persistent storage to ensure reliable message delivery.
6.  Integration: Hazelcast messaging can be integrated with other systems and platforms, including Spring, JMS, and Apache Camel. RabbitMQ also supports integration with various platforms and languages.

Overall, Hazelcast messaging is best suited for real-time, high-performance, and fault-tolerant messaging systems that require low-latency communication between nodes. RabbitMQ, on the other hand, is best suited for reliable message delivery and supports various messaging protocols.

### Benefits of Using Hazelcast Messaging

Hazelcast’s topic system provides a publish-subscribe mechanism, where publishers can publish messages to a specific topic, and subscribers can receive messages from that topic. Hazelcast’s queue system provides a point-to-point messaging mechanism, where messages are delivered to a specific consumer.

Here are some benefits of using Hazelcast for messaging:

1.  Scalability: Hazelcast’s messaging system can scale horizontally by adding more nodes to the cluster. This allows the system to handle a large number of messages and ensures that the messaging system is highly available and fault-tolerant.
2.  Performance: Hazelcast’s in-memory data grid provides fast access to messages, which can be important in high-volume messaging scenarios.
3.  Ease of use: Hazelcast’s messaging system is easy to use and requires minimal configuration. Developers can use Hazelcast’s Java API to send and receive messages, which makes it easy to integrate with existing Java applications.
4.  Security: Hazelcast provides security features such as SSL/TLS encryption, authentication, and authorization, which can ensure that messages are sent and received securely.
5.  Compatibility: Hazelcast’s messaging system is compatible with various messaging protocols, such as JMS, STOMP, and MQTT. This allows developers to use Hazelcast with a wide range of messaging clients and servers.
6.  Integration: Hazelcast messaging can be easily integrated with other systems and platforms, including Spring, JMS, and Apache Camel.

Overall, Hazelcast’s messaging system provides a powerful and flexible mechanism for building event-driven applications and messaging systems. Its scalability, performance, ease of use, security, and compatibility make it a popular choice for building distributed messaging systems.

### Traffoffs of Hazelcast Messaging

While Hazelcast’s messaging system offers many benefits, there are also some drawbacks that should be considered. Here are some potential drawbacks of Hazelcast messaging:

1.  Fault tolerance: While Hazelcast provides fault tolerance features for its messaging system, such as message replication and backup nodes, there is still a risk of data loss if multiple nodes fail at the same time. It’s important to design a fault-tolerant architecture that can handle node failures and data loss scenarios.
2.  Durability: Hazelcast’s messaging system is an in-memory system, which means that messages are stored in memory and may be lost if a node fails. To ensure message durability, Hazelcast provides options for persisting messages to disk, but this can add additional complexity and performance overhead.
3.  Failure handling: When a node fails, the messaging system needs to handle the failure gracefully to ensure that messages are not lost or duplicated. Hazelcast provides features such as backup nodes and automatic failover, but it’s important to design the system to handle failure scenarios.
4.  Complexity: Hazelcast’s messaging system can add complexity to the architecture, especially when integrating with existing messaging systems or clients. Developers need to understand the messaging system’s API, configuration options, and performance characteristics to ensure that it works effectively.
5.  Latency: Hazelcast’s messaging system is an in-memory system, which means that it may introduce additional latency compared to disk-based messaging systems. This may not be a significant issue for low-latency messaging scenarios, but it’s important to consider the impact on overall system performance.

Overall, while Hazelcast’s messaging system offers many benefits, it’s important to consider the potential drawbacks and design the system appropriately to ensure that it meets the requirements for fault tolerance, durability, and failure handling.

---
# Hazelcast Cache: Java Caching Framework with Spring Boot Integration

**Hazelcast** is an in-memory data grid that allows applications to share data across multiple nodes or instances in a highly distributed environment. Hazelcast provides:

-   **Distributed caching**: For scalable, fault-tolerant cache management.
-   **Data partitioning**: Efficiently spreads data across multiple nodes.
-   **Fault tolerance**: Supports automatic failover and replication to avoid data loss.
-   **Persistence**: Enables backing up cache data to persistent storage.
-   **Elastic scalability**: Automatically scales up or down to handle changing loads.

### **Access Alert 🔐**

_If you are a paid member please scroll through and continue reading, otherwise you may access this article_ [_here_](https://medium.com/@susantamon/hazelcast-cache-java-caching-framework-with-spring-boot-integration-c99abbf9e338?sk=34903a26b180a83c49a53a033d3eb543)

Hazelcast can be run in two modes:

-   **Embedded mode**: Hazelcast runs within the same JVM as your application.
-   **Client-server mode**: Hazelcast runs as a separate service, and applications connect to it via the Hazelcast client.

In this guide, we’ll focus on using **Hazelcast in embedded mode** with **Spring Boot**.

### Why Use Hazelcast for Caching?

-   **Distributed Caching**: Hazelcast scales seamlessly in a clustered environment, enabling distributed caching across multiple nodes.
-   **Elastic Scalability**: It can dynamically scale up or down, depending on the number of instances.
-   **Resilience and Fault Tolerance**: With its replication and backup capabilities, Hazelcast ensures that your cache data remains safe even if one or more nodes fail.
-   **Persistence Options**: It provides features for both in-memory and disk-based storage, offering hybrid caching capabilities.
-   **High Performance**: Hazelcast uses an in-memory approach to store data, allowing low-latency access.

### Step-by-Step Guide to Using Hazelcast with Spring Boot

Let’s walk through how to integrate **Hazelcast** with **Spring Boot** for caching purposes.

### 1. Set Up a Spring Boot Project

To get started, you can generate a **Spring Boot** project using **Spring Initializr** ([https://start.spring.io/](https://start.spring.io/)) with the following dependencies:

-   Spring Web
-   Spring Boot Starter Cache
-   Hazelcast

Alternatively, add the following dependencies manually in your `pom.xml` for a Maven-based project:
```xml
<dependency>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-starter-cache</artifactId>  
</dependency>  
<dependency>  
    <groupId>com.hazelcast</groupId>  
    <artifactId>hazelcast-spring</artifactId>  
    <version>5.4.2</version>  
</dependency>
```
This will add the necessary **Spring Boot Cache** starter and **Hazelcast** dependencies to your project.

### 2. Enable Caching in Spring Boot

Enable caching by annotating the main application class with `@EnableCaching`.
```java
@SpringBootApplication  
@EnableCaching  
public class HazelcastCacheDemoApplication {  
    public static void main(String[] args) {  
        SpringApplication.run(HazelcastCacheDemoApplication.class, args);  
    }  
}
```

This annotation tells Spring Boot to start using its caching abstraction with the configured caching provider, in this case, Hazelcast.

### 3. Configuring Hazelcast Cache

There are two main ways to configure Hazelcast: programmatically and via an XML or YAML configuration file. For simplicity, we will use a programmatic approach to configure Hazelcast in this example.

Create a `CacheConfig` class that defines the **Hazelcast** cache configuration:
```java
@Configuration  
public class CacheConfig {  
    @Bean  
    public Config hazelcastConfig() {  
        Config config = new Config();  
        config.setInstanceName("hazelcast-instance")  
              .addMapConfig(new MapConfig()  
                    .setName("productCache")  
                    .setTimeToLiveSeconds(600)  
                    .setMaxSizeConfig(new MaxSizeConfig(1000, MaxSizeConfig.MaxSizePolicy.FREE_HEAP_SIZE)));  
        return config;  
    }  
    @Bean  
    public HazelcastInstance hazelcastInstance() {  
        return Hazelcast.newHazelcastInstance(hazelcastConfig());  
    }  
    @Bean  
    public CacheManager cacheManager() {  
        return new HazelcastCacheManager(hazelcastInstance());  
    }  
}
```
In this configuration:

-   A **MapConfig** is created for the `productCache`. This defines a time-to-live (TTL) of **600 seconds** for cached items, and a maximum size of **1000 entries**.
-   The `hazelcastConfig` method creates and returns a **Hazelcast Config** object with the cache settings.
-   The `HazelcastCacheManager` integrates Hazelcast with Spring Boot’s caching abstraction.

### 4. Using Hazelcast in Spring Services

Now that Hazelcast is configured, we can use caching annotations like `@Cacheable`, `@CacheEvict`, and `@CachePut` in the service layer.

### Example: ProductService with `@Cacheable`
```java
@Service  
public class ProductService {  
    @Cacheable(value = "productCache", key = "###id")  
    public String getProductById(String id) {  
        simulateSlowService();  
        return "Product " + id;  
    }  
    // Simulate a slow database service  
    private void simulateSlowService() {  
        try {  
            Thread.sleep(3000); // Simulating a 3 second delay  
        } catch (InterruptedException e) {  
            Thread.currentThread().interrupt();  
        }  
    }  
}
```

-   **@Cacheable**: Caches the result of the `getProductById` method in the `productCache`. The first time the method is called for a specific `id`, the result is cached. For subsequent requests with the same `id`, the cached result is returned, improving performance by avoiding the need to re-run the method.

### 5. Testing the Cache with a REST Controller

To test the caching mechanism, create a REST controller that exposes the `ProductService`:
```java
@RestController  
@RequestMapping("/products")  
public class ProductController {  
    @Autowired  
    private ProductService productService;  
    @GetMapping("/{id}")  
    public Mono<String> getProduct(@PathVariable String id) {  
        return Mono.just(productService.getProductById(id));  
    }  
}
```

Now, run the application and send a GET request to test caching:
```shell
curl http://localhost:8080/products/1
```

The first request will take about 3 seconds due to the `simulateSlowService()` method. Subsequent requests for the same product ID will return instantly as the result is now cached in **Hazelcast**.

### 6. Cache Eviction with `@CacheEvict`

To remove or evict specific entries from the cache, use the `@CacheEvict` annotation. For example:
```java
@CacheEvict(value = "productCache", key = "###id")  
public void removeProductFromCache(String id) {  
    // Code to remove product data from a persistent store if needed  
}
```
This ensures that the cached entry for the specific `id` is evicted, allowing for fresh data to be retrieved when the product is next accessed.

### 7. Updating Cache with `@CachePut`

The `@CachePut` annotation is used to update the cache with a new value after executing a method:
```java
@CachePut(value = "productCache", key = "###id")  
public String updateProductInCache(String id, String newProductData) {  
    return newProductData;  
}
```

This annotation updates the cache entry for the given product ID with the new product data.

### 8. Hazelcast Management and Monitoring

Hazelcast offers built-in tools for monitoring and managing your cache. You can use **Hazelcast Management Center** to:

-   Monitor cache statistics such as hits, misses, evictions, and more.
-   Visualize cluster topology, node health, and resource usage.
-   Configure dynamic scaling and performance tuning.

To enable JMX monitoring in Hazelcast for use with tools like **JConsole**, update the configuration:
```java
config.getManagementCenterConfig()  
      .setEnabled(true)  
      .setUrl("http://localhost:8080/hazelcast-mancenter");
```
This allows you to monitor Hazelcast via its Management Center or any JMX-compliant monitoring tool.

### Summary

**Hazelcast** is a powerful, distributed caching solution ideal for modern cloud-native and microservice architectures. Its ability to scale elastically, provide fault tolerance, and offer persistence makes it a great choice for applications that need fast, reliable access to frequently used data.

With Hazelcast and Spring Boot’s caching abstraction, you can quickly optimize your application’s performance by caching frequently accessed data, reducing load on external databases, and improving overall user experience.
---

### Spring Boot with Hazelcast. 

Have you ever faced with slow performance of your application? Have you ever thought of the way to boost your Spring app? If so — then this article is definitely for you. Here we will speak about using super powerful and leading in-memory data grid that may increase your app performance! So let’s jump into this!

### **What is Hazelcast?**

**Hazelcast** is an operational, in-memory, distributed computing platform for managing data and performing parallel execution for application speed and scale.

**Good to know:**

-   It is written in Java.
-   Unlike some other in-memory databases — Hazelcast is multiple-threaded, which means it can benefit from all available CPU cores.
-   Unlike other in-memory data grids — it is designed to be used in distributed environment. It supports unlimited number of maps and caches per cluster.
-   Based on the benchmarks Hazelcast is up to 56% faster than Redis in **getting** data, and up to 44% faster than Redis in **setting** data.🚀

So it definitely makes sense to get a bit more information about this interesting technology.

And there is really low efforts needed to add it into your Spring Boot project and start using it’s advantages.
```xml
<parent>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-starter-parent</artifactId>  
    <version>2.0.0.RELEASE</version>  
</parent>  
<dependencies>  
    <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-web</artifactId>  
    </dependency>  
    <dependency>  
        <groupId>com.hazelcast</groupId>  
        <artifactId>hazelcast</artifactId>  
    </dependency>  
    <dependency>  
        <groupId>com.hazelcast</groupId>  
        <artifactId>hazelcast-spring</artifactId>  
    </dependency>  
</dependencies>
```
As you can see, to add Hazelcast to Spring Boot app we need just two dependencies. After that we need to configure Hazelcast instance. There are two ways to do that:

-   Through Java configuration.
-   Through creating hazelcast.xml configuration file.

Let’s go with the first option.
```java
package com.config;  
  
import com.hazelcast.config.Config;  
import com.hazelcast.config.EvictionPolicy;  
import com.hazelcast.config.MapConfig;  
import com.hazelcast.config.MaxSizeConfig;  
import org.springframework.context.annotation.Bean;  
import org.springframework.context.annotation.Configuration;  
  
@Configuration  
public class **HazelcastConfiguration** {  
    @Bean  
    public Config hazelCastConfig(){  
        Config config = new Config();  
        config.setInstanceName("hazelcast-instance")  
                .addMapConfig(  
                        new MapConfig()  
                                .setName("configuration")  
                                .setMaxSizeConfig(new MaxSizeConfig(200, MaxSizeConfig.MaxSizePolicy.FREEHEAPSIZE))  
                                .setEvictionPolicy(EvictionPolicy.LRU)  
                                .setTimeToLiveSeconds(-1));  
                                        return config;  
                                    }  
}
```

Since instance is configured — now we can access Hazelcast and manipulate with data.

For this example I’ll create HazelcastController that will have just 3 mappings:

-   One is for settings data;
-   One is for accessing data by key;
-   One is for getting all the data from Hazelcast map;

Here is the code for our controller:

![](https://miro.medium.com/v2/resize:fit:1250/1*rUn3gTgpdgyTz4YNnClBA.png)

You can see that we have just three java classes in our project, and this is enough to start using Hazelcast.

In the controller we autowired **HazelcastInstance** — which is the interface provided by Hazelcast library. And by using this instance we can manipulate data in the in-memory data grid. So let’s use Postman to save some records into Hazelcast.

![](https://miro.medium.com/v2/resize:fit:1250/1*ZmUmNC9xq3L2rJhQ1ZxmBg.png)

We set an object with key — Java, and it’s value — “Rules The World”. I’ll also add some other key-value pairs, to have more than just one in memory. Important thing here is the speed of writing data. It is just 4 ms!🚀 This is an extremely fast operation!!

And let’s get this data from Hazelcast back:

![](https://miro.medium.com/v2/resize:fit:1250/1*SZ1rps7GZaTTg3UUfVGoaw.png)

And again — read operation is super fast too. It took us just 5 ms to get data by provided key back from the memory.

One important thing — you can get data stored in this cache even from different application instance. To do this — I’ll change the app port to be 8081, and run another instance of the app, and then will try to fetch all the data from Hazelcast that we stored before.

![](https://miro.medium.com/v2/resize:fit:1250/1*RhcRrguRYtNVzD-WwIZwg.png)

As you can see we made a request to second instance of our server app, that we just run. It’s serving on 8081 port. And eventhough we haven’t put something to Hazelcast using this new instance, but we can fetch everything that was stored in Hazelcast using another application instance. So it’s clustered, and data may be shared among many and many application instances.

And even if we stopped our first instance, that was running on 8080 port, data is not lost. It is still available by making a request to the instance on 8081 port.

So using **Hazelcast** as an in-memory data grid is really useful and opinionated if you take care about the performance, speed of your read-write operations and you want to make sure your data is stored correctly and failing of one your standalone application or microservice will not lead to data lost.

Thank you for your time! Hope you enjoyed the reading and got some useful tips on Spring Boot with Hazelcast.

All the code available on my personal [**GitHub**](https://github.com/igorkosandyak/spring-boot-with-hazelcast) repo.

It is always fun and pleasure to write articles and help others to better understand new technologies.

Want to get updates on upcoming articles? Follow me on [**LinkedIn**](https://www.linkedin.com/in/igor-kosandyak-401333b0/) and [**Twitter**](https://twitter.com/igorkosandyak) 🙌

**If it was helpful to you, please do press the 👏 clap button and help others find this story too.**
---
# Hazelcast: In-Memory Computing to Build Scalable Auto-Complete Keyword Search Solution
Building Custom Scalable Auto-Complete Keyword Search Solution in Hazelcast

![](https://miro.medium.com/v2/resize:fit:875/1*olZolczfyFBXVEponDdMg.png)

### Introduction

In this blog, I’ll demonstrate the design and implementation of a back-end search service we’ve been using at FastPay ([gofastpay.com)](http://gofastpay.com) to power the auto-complete keyword search of all our front-end applications.

Prior to implementing such solution, we used to load all the data in our front-end applications and perform front-end filtering — a solution that quickly became non-scalable as our business grew. Building our own custom search solution on top of **Hazelcast** ([https://hazelcast.com](https://hazelcast.com/)), a powerful in-memory computing platform, provided a seamless experience to both our clients and internal users.

### Source Code

The source code of this project can be downloaded from:

https://github.com/husseinmoghnieh/hazelcast-search-service

Instructions on how to build/run a docker image of this project is provided in the README file.

### The Problem: Searching Invoices

Let’s take this simple problem of searching invoices stored in a relational DB. Figure 1. shows a simple schema to store basic invoice information. And for simplicity assume that the user of our application wants to auto-complete search on:

-   **invoice number** (invoice table)
-   **amount** (invoice table)
-   **payee name** (payee table)
-   **payor name** (payor table)

### 1- Database design

![](https://miro.medium.com/v2/resize:fit:875/1*6KLwXe7jBpuWMYruIx4vjA.jpeg)
Figure 1. Simple DB schema to store invoice and invoice related data

### 2- Sample Data

For your convenience and in order to be able to run the source code and experiment with the solution, the project uses H2 in memory database. The schema shown above is created and a sample data is loaded from **data.sql** file upon running the project.

Once you run the project, The H2 console can be accessed from the URL: [http://localhost:17600/h2-console](http://localhost:17600/h2-console)

![](https://miro.medium.com/v2/resize:fit:875/1*6u3aOeYGNehFZtJlp1-4xA.png)
Figure 2. H2 DB console

The following SQL retrieves all invoices and invoices related data from the DB.
```sql
SELECT *  
FROM   invoice   
       JOIN payor   
         ON ( invoice.payorid = payor.payorid )   
       JOIN payee   
         ON ( invoice.payeeid = payee.payeeid )
```
![](https://miro.medium.com/v2/resize:fit:875/1*H9UkZ0WrKxDLV5C67ZNulQ.png)
Figure 3. Sample Invoice data

In Hazelcast we want to cache only selected columns, mainly, columns that the user will be searching on (i.e. invoicenumber, amount, payee name, payor name). The above SQL can be re-written as:
```sql
SELECT invoiceid,   
       invoicenumber,   
       amount,   
       payor.name AS payorname,   
       payee.name AS payeename   
FROM   invoice   
       JOIN payor   
         ON ( invoice.payorid = payor.payorid )   
       JOIN payee   
         ON ( invoice.payeeid = payee.payeeid )
```
![](https://miro.medium.com/v2/resize:fit:875/1*RwwsNLD-mQHlAaUeE-C4g.png)
Figure 4. Searchable Invoice data to be cached in Hazelcast

### 3- What to cache in Hazelcast?

The invoice data selected from the DB shown above will be loaded into Hazelcast’s in memory distributed Map. Each DB row will be stored as a Map item. The key of the item is the **invoiceid** and the value is a JSON object containing the values of each field we would like to search on as shown below:
```json

{  
 “invoicenumber” : “111”,  
 “payorname” : “Sinclair"  
 “payeename” : “Sonobi”,  
 “amonut” : 100.12  
}key: 2value:  
{  
 “invoicenumber” : “222”,  
 “payorname” : “Sinclair"  
 “payeename” : “Adrenalin”,  
 “amonut” : 41.86  
}
```
When running on a cluster, Hazelcast distributes the data on multiple nodes and manages redundancy. Not only that, Hazelcast provides a powerful map/reduce operations that run on all nodes. This will be illustrated later on.

### API — Defining The Search API

Now that we have defined the structure of the data in Hazelcast’s Map, let’s define the APIs needed to **construct** (i.e. load data from DB), **search**, and **update** (i.e. keep the data in sync with the DB) of such map. I’ll first define the APIs and I’ll provide examples in the next section.

-   **DELETE** **/invoice**: Loads the data from the database into Hazelcast’s distributed map. This is usually a costly operation and usually is only needed once the cluster is launched.
-   **GET** **/invoice**: Returns all the possible search values.
-   **PUT /invoice**: Returns a subset of the possible search values based on a filter that the user of the service provides.
-   **POST** **/invoice**: This is the search API. It takes an object containing all the values of the indices you want to search on and returns the keys (invoiceids) of each Map element matching the search.
-   **PATCH** **/invoice**: This is to update the map item(s) whenever a corresponding invoice(s) has been modified in the database.

### APIs in Action — Examples

**Note**: You can experiment with the APIs by accessing the embedded swagger page: [http://localhost:17600/swagger-ui.html](http://localhost:17600/swagger-ui.html)

### DELETE /invoice : Cache searchable terms in Hazelcast

This is the API to rebuild the Map in Hazelcast and cache all the data retrieved from the DB

Request:
```shell
curl -X DELETE "[http://localhost:17600/v1/invoice](http://localhost:17600/v1/invoice)" -H  "accept: */*"
```

Response: 200 Ok

### 1 — GET /invoice: Get all unique searchable Keywords

This API returns all the searchable items and their corresponding possible values from Hazelcast. The result of this API are provided to the consumer application for the user to select from.

Request:
```shell
curl -X GET "[http://localhost:17600/v1/invoice](http://localhost:17600/v1/invoice)" -H  "accept: */*"
```
Response:

![](https://miro.medium.com/v2/resize:fit:468/1*tgUXUZQExNWBlM1bnR1Mw.png)
Figure 5. Response of GET /invoice API containing all possible search values

### 2 — PUT: Get contextual keyword search

The GET /invoice API loads all possible search terms without filter or adding a context to the result. The PUT /invoice API is to compliment the GET API and further filter the possible search values based on a filter. The filter is of the form:

{  "amount": [    **0**  ],  "invoiceNumber": [    "string"  ],  "payeeName": [    "string"  ],  "payorName": [    "string"  ]}

Let’s say the user types “A” and the UI filters on all loaded data in the previous step (i.e. GET /invoice). The choices of keywords that starts or contains “A” will be shown

![](https://miro.medium.com/v2/resize:fit:875/1*6SMoDV1IWyPGdnSPGk95YQ.png)

The user selects “Adrenalin” as Payee (shown below). Once this choice is made, subsequent auto-complete choices should only pertain to the search invoices that have Adrenalin as payee. For instance, it should NOT show an amount of 341.00, since none of the Adrenalin invoices has this amount.

![](https://miro.medium.com/v2/resize:fit:875/1*mSBWC2ZPDsPPKP0dT3rYw.png)

To get the new list of searchable values, PUT /invoice is called and the following object structure is passed on in the request body:
```json
{  
   “payeeName” :[  
     “Adrenalin”  
   ]  
}
```

The full request using swagger is shown below

![](https://miro.medium.com/v2/resize:fit:1250/1*thXNXFwrT04MEt9xZre8Xg.png)
Figure 6. PUT /invoice to retrieve possible searchable values for payeeName=Adrenalin

Request:

curl -X PUT "[http://localhost:17600/v1/invoice](http://localhost:17600/v1/invoice)" -H  "accept: */*" -H  "Content-Type: application/json" -d "{  "payeeName": [    "Adrenalin"  ]}"

Response:

As shown, the new possible search values are a subset of all the search values cached in Hazelcast obtained in the GET request.

![](https://miro.medium.com/v2/resize:fit:1250/1*6QkcPq5Uz7WXfa9OE7DNQ.png)
Figure 7. PUT /invoice response displaying possible searchable values for payeeName=Adrenalin

### What is missing? Prefix Search instead of GET / PUT above implementation

One of the limitation of the current implementation is that the GET and PUT APIs load all the search values into the UI, a solution that is not scalable. Instead, we could have used **Prefix Search** construct in Hazelcast by which the consuming application (i.e. UI) does not load all possible searchable values, but only retrieves the values as the user types. The details of such implementation will be left for another blog post.

### 3a — POST /invoice: Search example-1

Next is to show the implementation of the actual search. This search takes as input an object of the form:
```json
{  "amount": [    **0**  ],  "invoiceNumber": [    "string"  ],  "payeeName": [    "string"  ],  "payorName": [    "string"  ]}
```

The request body is similar to the one used in the PUT /invoice request. The only difference is that the search POST /invoice API returns the keys (i.e. invoiceids) of the items in the Hazelcast map. Those keys can be exchanged to get the actual invoice data from the database to be displayed in the UI.

For instance, searching for payeeName “Adrenalin” will return 4 invoices:

![](https://miro.medium.com/v2/resize:fit:1250/1*7eENJtvWgWKMuo8KKKXTqg.png)
Figure 8. POST /invoice to search for invoices with payeeName=Adrenalin

**Request:**
```shell
curl -X POST "[http://localhost:17600/v1/invoice?page=0&pageSize=10](http://localhost:17600/v1/invoice?page=0&pageSize=10)" -H  "accept: */*" -H  "Content-Type: application/json" -d "{  "payeeName": [    "Adrenalin"  ]}"
```
**Response:**
```json
{  "invoiceId": [    **2**,    **3**,    **4**,    **9**  ],  "totalAmount": **5138**.**96  
**}
```
4 invoices matches the search request. Notice how totalAmount is returned which is the sum of the amounts of all 4 invoices. Such aggregation of amount is achieved using Hazelcast’s powerful **Aggregator** construct that can carry such computation on a cluster. The code below shows the implementation of the total amount in this project
```java
Aggregator<Map.Entry<Long, InvoiceKeywordIndexEntry>, BigDecimal> invoiceUsdTotaller =  
    Aggregators.bigDecimalSum("amount");  
  ```
BigDecimal totalAmount = invoiceDataMap.aggregate(invoiceUsdTotaller, searchPredicate);

It is also possible to build a custom Aggregator class to perform more complex operations on the result set of the search predicate.

### 3b — POST /invoice: Search example-2

Let’s try another search request as shown below:
```json
{  
   
  "payeeName": [  
    "Sonobi" , "Adrenalin"  
  ],  
  "payorName": [  
    "Sinclair"  
  ]  
}
```
This search request can be translated as such:

Return all the invoice ids that have:

**PayeeName**=(“Sonobi” **OR** “Adrenalin”) **AND** **(payorName**=“Sinclair”)

From the database data, the result corresponds to invoiceids (1,2, and 3). And the total invoice amount is **2141**.**98** as shown below

{  "invoiceId": [    **1**,    **2**,    **3**  ],  "totalAmount": **2141**.**98  
**}

### 4 — PATCH: Update

The last construct is to update Hazelcast’s map entry whenever any of the cached fields changes in the DB. Let’s say that another process modified the amount of an invoice, then the process that modified the invoice should tell Hazelcast to update its items corresponding to that invoice by calling PATCH API and specifies one or many invoices ids to update. The search service will retrieve the latest requested invoice data from the DB and replace their corresponding Map entries.

The following curl shows simple call to patch multiple invoices in one command.

curl -X PATCH "[http://localhost:17600/v1/invoice](http://localhost:17600/v1/invoice)" -H  "accept: */*" -H  "Content-Type: application/json" -d "{  "invoiceIds": [    1,2,3  ]}"

The input object to the curl command

![](https://miro.medium.com/v2/resize:fit:1250/1*J3VNMSsDHZ3z1a6PJ3l0cw.png)
Figure 9. Patch /invoice to sync invoice 1,2, and 3 with the DB

### Hazelcast on AWS ECS cluster

Configuring Hazelcast to run on ECS cluster requires the cluster’s VPC subnets IP range, AWS region, and that the ECS cluster be tagged by any key-value pair. Also, the network mode of each ECS Task be set to **Host** mode instead of **Bridge** mode.

The following JAVA code creates a configuration that is passed to Hazelcast’s map configuration to allow the auto-discovery of Hazelcast tasks running on the same cluster.

![](https://miro.medium.com/v2/resize:fit:875/1*8KoijPx2lSuXXecUy-4vXg.png)
Figure 10. JAVA Hazelcast ECS cluster configuration

---
# Replicated Caching in Microservices With Hazelcast
After reading “[Software Architecture: Hard Parts](https://www.amazon.com.tr/Software-Architecture-Modern-Tradeoff-Analysis/dp/1492086894)” one of the patterns that stuck in my mind is the Replicated Caching Pattern. I have to admit, before that book, I’d never heard of it. In this article, I’ll explain the replicated caching pattern, its differences from distributed caching, and how Hazelcast manages to synchronize cached data between services.

### What is Replicated Caching Pattern?

In this pattern, each service has its own in-memory data that’s continuously synchronized. Through asynchronous synchronization, each service always has the latest data. Several products are available for replicated caching, such as Hazelcast, Apache Ignite, and Oracle Coherence. With the right product, you don’t need to worry about consistency issues. I’ll explain how this is possible by detailing Hazelcast’s data replication process.

### Distributed Caching

Before we dive into Hazelcast’s replication model, let’s talk about the differences between Distributed Caching and Replicated Caching. In a distributed cache model, data is held externally on multiple servers or nodes. Services make requests to retrieve and update cached data. This centralized caching system has its trade-offs. For instance, it introduces a dependency on the caching system, and network calls add retrieval latency. To address such latency, Pinterest implemented [TCP Fast Open (TFO)](https://datatracker.ietf.org/doc/html/rfc7413), which reduces the average TCP connection duration by saving a full round-trip time compared to the traditional three-way handshake required by TCP.

### Trade-offs

Of course, like any other architectural pattern, the Replicated Caching Pattern comes with trade-offs.. One significant limitation is data size; according to “Software Architecture: Hard Parts,” the cached data should ideally not exceed 500 MB. However, this limit varies depending on the application’s specific requirements and infrastructure capabilities. For example, a 500 MB cache for user data replicated across 5 instances will consume 2.5 GB of total memory. Second is dependency to cache owner service. If your cache owner service doesn’t start-up then your other services that depends on this cache have to wait. Third trade-off is if your data changes frequently, it would be hard to keep services in sync with replicated cache. And the last trade-off of this pattern is setup and configuration is too complex. We’re going to look at how to configure Hazelcast to use replicated caching pattern later on.

### Replicated Caching in Hazelcast

Now, we will talk about how Hazelcast replication process works. We’re going to use Replicated Map, one of the AP Data Structures, to cache data locally. Also there is a another option caches data locally, Near Cache. But near cache first fetches data from remote node and then caches locally.

There are two kind of structures in Hazelcast in the context of CAP theorem. Availability and Partition tolerance which is AP Data structures and Consistency and Partition Tolerance which is CP Data structures. For AP Data structures, Hazelcast uses combination of Primary-Copy Replica and configurable lazy replication techniques. Primary-copy replication (also known as passive replication) is one of the traditional data replication techniques. Primary copy basically is only primary server accepts and process requests and sends updates to other servers. If primary replica fails, one of the backup server is selected as primary replica. With lazy replication, when primary replica receives updates, it propagates to replicas. There are two backup options, sync and async.

### Replicated Map

We’re going to use the example from the book,“[Software Architecture: Hard Parts](https://www.amazon.com.tr/Software-Architecture-Modern-Tradeoff-Analysis/dp/1492086894)”. We need two services, Wishlist and Catalog.

### Setup in Hazelcast

First we need to configure Replicated Map in our services. We have three options: xml, yaml and programatic. We will continue with programatic configuration:
```java
    @Bean  
    public Config hazelcastConfig() {  
        Config config = new Config();  
  
        // Configure Hazelcast with TCP/IP for node discovery  
        config.getNetworkConfig().getJoin().getTcpIpConfig().setEnabled(true);  
        config.getNetworkConfig().getJoin().getTcpIpConfig().addMember("127.0.0.1");  
        // Set cluster name and instance for synchronization  
        config.setClusterName("my-hazelcast-cluster");  
        config.setInstanceName("replicated-cache-read-instance");  
  
        ReplicatedMapConfig replicatedMapConfig = new ReplicatedMapConfig("products");  
        replicatedMapConfig.setInMemoryFormat(InMemoryFormat.OBJECT);  
        config.addReplicatedMapConfig(replicatedMapConfig);  
        return config;  
    }
```
We need to find hazelcast instances each other in order to synchronize cached data. They need to have the same cluster name. So we added below code:
```java
// Configure Hazelcast with TCP/IP for node discovery  
config.getNetworkConfig().getJoin().getMulticastConfig().setEnabled(false);  
config.getNetworkConfig().getJoin().getTcpIpConfig().setEnabled(true);  
config.getNetworkConfig().getJoin().getTcpIpConfig().addMember("127.0.0.1");  
// Set cluster name and instance for synchronization  
config.setClusterName("my-hazelcast-cluster");  
config.setInstanceName("replicated-cache-read-instance");
```
If you’ve completed all the steps correctly, then you should see the members listed in the logs as follows:
```shell
Members {size:2, ver:2} [  
 Member [127.0.0.1]:5701 - 3cc2e7ac-a3b1-4420-8645-f48929202786 this  
 Member [127.0.0.1]:5702 - f086f23f-247e-4d79-8208-79d1de4e9a49  
]
```

### Using Replicated Map

After that in our product service, whenever product is updated or inserted we put the data in replicated map.

var productMap = hazelcastInstance.getReplicatedMap("products");  
productMap.put(entity.getId(), entity.getDescription());

In wishlist service, whenever we fetch the wishlist data, we’re going to get product description from hazelcast replicated map:

var productMap = hazelcastInstance.getReplicatedMap("products");  
var productDescription = productMap.getOrDefault(wishlist.getProductId(), "");

### Demo

Create Product:
```shell
curl --location 'localhost:8081/api/products'   
--header 'Content-Type: application/json'   
--data '{  
    "name":"product 1",  
    "description": "description 1"  
}'
```
Create Wishlist:
```shell
curl --location 'localhost:8082/api/wishlists'   
--header 'Content-Type: application/json'   
--data '{  
    "productId": 1  
}'
```
Retrieve wishlist:
```shell
curl --location 'localhost:8082/api/wishlists'
```
Update Product:
```shell
curl --location --request PUT 'localhost:8081/api/products/1'   
--header 'Content-Type: application/json'   
--data '{  
    "name":"product 1",  
    "description": "description 1 - 1"  
}'
```
You can find the complete code for this project on [Github.](https://github.com/OzkanOnay/replicated-cache)

### Conclusion

The Replicated Caching Pattern offers low-latency access to synchronized in-memory data across services, reducing reliance on external caches. While it has trade-offs like memory overhead and setup complexity, Hazelcast makes it manageable with features like Replicated Maps and efficient replication techniques. For systems needing quick, consistent data access, this pattern is a practical solution despite its challenges.



# Hazelcast and Topologies. Hazelcast is an open source Java-based

Hazelcast is an open source Java-based structure for data clustering and distribution. It provides high-performance and scalable data processing and storage by creating a data grid on many servers.

In this article, I will try to explain Hazelcast’s 3 different topologies and the usage areas of these topologies with spring boot examples. These are embedded, sidecar and client-server. You can implement each of them for different scenarios. It all depends on your flow.

### Embedded

Embedded topology, as the name suggests, is the way the hazelcast instance is used embedded in the application. What we mean by buried here is this. If you add hazelcast as embedded to an application, each instance that rises will be a separate client.

![](https://miro.medium.com/v2/resize:fit:500/1*gmRUAbtXcoPqDevEsK3TqQ.png)

Let’s exemplify with a scenario. Let’s say you have an application that performs complex calculations and reports these transactions hourly. You create 3 different instances and use embedded hazelcast for cache. In order to distribute the load, each incoming calculation request is distributed to one of 3 instances. After the transaction is completed, the information is saved in the hazelcast cache. A scheduler runs every hour, collecting and reporting the information in the cache. Since Hazelcast is embedded, each instance has a separate cache and each instance produces a report of the information it processes.  
In the real world, the example I gave will not appear like this. However, I gave such an example to explain embedded more clearly.  
You can configure the hazelcast embedded topology in your spring boot application as follows.
```java
import com.hazelcast.config.Config;  
import com.hazelcast.core.Hazelcast;  
import com.hazelcast.core.HazelcastInstance;  
import lombok.RequiredArgsConstructor;  
import org.springframework.beans.factory.annotation.Value;  
import org.springframework.context.annotation.Bean;  
import org.springframework.context.annotation.Configuration;  
  
@RequiredArgsConstructor  
@Configuration  
public class HazelcastConfiguration {  
  
    @Value("${hazelcast.cluster.name}")  
    private String clusterName;  
  
    @Bean  
    public HazelcastInstance hazelcastInstance() {  
        Config config = new Config();  
        config.setClusterName(clusterName);  
        return Hazelcast.newHazelcastInstance(config);  
    }  
}
```
Examples of writing to and reading from cache are below.
```java
import com.emreakin.model.TokenModel;  
  
import com.hazelcast.config.MapConfig;  
import com.hazelcast.core.HazelcastInstance;  
import com.hazelcast.map.IMap;  
import lombok.RequiredArgsConstructor;  
import org.springframework.beans.factory.InitializingBean;  
import org.springframework.stereotype.Service;  
  
import java.util.Date;  
import java.util.UUID;  
  
@Service  
@RequiredArgsConstructor  
public class HazelcastTokenService implements InitializingBean {  
  
    private final HazelcastInstance hazelcastInstance;  
    private IMap<String, TokenModel> tokenMap;  
  
    @Override  
    public void afterPropertiesSet() {  
        tokenMap = hazelcastInstance.getMap("token");  
        hazelcastInstance.getConfig().addMapConfig(new MapConfig("token")  
                .setTimeToLiveSeconds(3600));  
    }  
  
    public TokenModel getToken(String userName) {  
        TokenModel tokenModel = tokenMap.get(userName);  
        if(tokenModel != null)  
            return tokenModel;  
  
        String generatedToken = UUID.randomUUID().toString();  
        tokenModel = TokenModel.builder()  
                .token(generatedToken)  
                .creationDate(new Date())  
                .build();  
  
        tokenMap.set(userName, tokenModel);  
  
        return tokenModel;  
    }  
}
```

### Sidecar

Let’s look at a different scenario than the one above. When you perform a transaction regarding the user, you first retrieve the user’s information from the database and then continue the transaction. Let’s assume that there are many transaction requests for the same user in a short time, the database will be visited again and again for each transaction. This will cause the application to waste unnecessary time. We can avoid this situation by using cache. If we cache user information by giving 1 hour TTL, we will go to the database only once for the user during 1 hour.

Let’s assume that you have 3 instances for Embedded. You said to update the cache and this request fell on one of the instances, which went and pulled the users from the database and saved them in the cache. But he saved it in his own memory. When you start the process, it will pull the user information from the cache again. If it falls to the instance that saves it to the cache, it will continue without any problems. But if it falls into one of the other instances, you will receive a user not found error because it is not in its cache. The answer to how to solve this is sidecar.

![](https://miro.medium.com/v2/resize:fit:875/1*U7D-U-g_1o1qhukkOnGWHA.png)

Let’s assume we are running this application on Kubernetes. Each container in the running pods is called a sidecar. Hazelcast sidecar topology also tells us that the data stored in the memory of any of the 3 running instances can be read by any of the other instances. In other words, they create a synchronization between them.  
You can configure the hazelcast sidecar topology in your spring boot application as follows.
```java
import com.hazelcast.client.HazelcastClient;  
import com.hazelcast.client.config.ClientConfig;  
import com.hazelcast.core.HazelcastInstance;  
import lombok.RequiredArgsConstructor;  
import org.springframework.beans.factory.annotation.Value;  
import org.springframework.context.annotation.Bean;  
import org.springframework.context.annotation.Configuration;  
  
@RequiredArgsConstructor  
@Configuration  
public class HazelcastConfiguration {  
  
    @Value("${hazelcast.cluster.name}")  
    private String clusterName;  
  
    @Bean  
    public HazelcastInstance hazelcastInstance() {  
        ClientConfig clientConfig = new ClientConfig();  
        clientConfig.setClusterName(clusterName);  
        clientConfig.getNetworkConfig().addAddress("127.0.0.1:5701");  
        return HazelcastClient.newHazelcastClient(clientConfig);  
    }  
}
```
There will be no change in writing and reading operations to the cache.

### Client-Server

Now we come to the final topology. We change our scenario as follows. This time we have 3 different microservices. CustomerService, CompanyService and DataService. While customer and company services are performing transactions, they go to the data service and retrieve user information. If we do not use any cache mechanism, applications for the same user will go to the data service and then to the database many times. If we use the sidecar topology for customer and company services here, customer and company will go to the data service separately for the same user. We have two microservices, but if there are more of them, the cost will increase. This is where the client-server comes into play.

![](https://miro.medium.com/v2/resize:fit:625/1*sMuj4yVzN4jbW2fhkkqIYw.png)

In this topology, our cache is no longer in-memory and turns to cache use on a remote server. For our scenario, the data service leaves the user information in the cache. Customer and company services will go to the same cache independently and retrieve user information from the cache. If it cannot be found there, then the data will go to the service.  
You can configure the hazelcast client-server topology in your spring boot application as follows.
```java
import com.hazelcast.client.HazelcastClient;  
import com.hazelcast.client.config.ClientConfig;  
import com.hazelcast.core.HazelcastInstance;  
import lombok.RequiredArgsConstructor;  
import org.springframework.beans.factory.annotation.Value;  
import org.springframework.context.annotation.Bean;  
import org.springframework.context.annotation.Configuration;  
  
@RequiredArgsConstructor  
@Configuration  
public class HazelcastConfiguration {  
  
    @Value("${hazelcast.cluster.name}")  
    private String clusterName;  
  
    @Bean  
    public HazelcastInstance hazelcastInstance() {  
        ClientConfig clientConfig = new ClientConfig();  
        clientConfig.setClusterName(clusterName);  
        clientConfig.getNetworkConfig().addAddress(  
          "hazelcast-server:5701",   
          "hazelcast-server:5702");  
        return HazelcastClient.newHazelcastClient(clientConfig);  
    }  
}
```

There will be no change in writing and reading operations to the cache.

Now, in this case, the following question comes to mind. Since we are trying to reduce the network cost of traveling to and from the database or another service. But when we use remote cache, we go to the cache server instead of the database. What did we understand from this? Yes, you are right about this. When we decided to include more than one application in the same cache mechanism, we compromised on network costs. What can we do in this situation? Here too, near cache comes into play.

![](https://miro.medium.com/v2/resize:fit:875/1*QMB0rXSLbC7Vbxvpo3r-Bw.png)

Let’s explain what this near cache is. In the simplest terms, cache’s cache. Near cache is not a fourth topology, but an approach used in client-server topology. If we use near cache, the application first looks at the near cache (a second cache in the form of in-memory) for data, and if it cannot find it there, it goes to the remote cache and saves the data it receives from there to the near cache. Since it will first look at the near cache until it is expired, it will find it and retrieve it from there, thus we will avoid the network cost of going to the remote cache.  
There was a cache, another cache appeared, I was doing it if there is one, take it from the cache, if not, go and bring it and save it to the cache, you can say that I will do this again for near cache, the business has grown. Actually, no, you will not be able to make a programmatic addition to near cache. If you add near cache to your configuration, hazelcast will handle this itself. But let’s not forget that ttls are different for remote cache and near cache. In this scenario, the TTL of the remote cache is determined by the DataService that writes the data. But CustomerService and CompanyService determine the TTL of their near cache independently of the other.  
You can configure near cache in your spring boot application as follows.
```java
import com.hazelcast.client.HazelcastClient;  
import com.hazelcast.client.config.ClientConfig;  
import com.hazelcast.core.HazelcastInstance;  
import lombok.RequiredArgsConstructor;  
import org.springframework.beans.factory.annotation.Value;  
import org.springframework.context.annotation.Bean;  
import org.springframework.context.annotation.Configuration;  
  
@RequiredArgsConstructor  
@Configuration  
public class HazelcastConfiguration {  
  
    @Value("${hazelcast.cluster.name}")  
    private String clusterName;  
  
    @Bean  
    public HazelcastInstance hazelcastInstance() {  
        ClientConfig clientConfig = new ClientConfig();  
        clientConfig.setClusterName(clusterName);  
        clientConfig.getNetworkConfig().addAddress(  
          "hazelcast-server:5701",   
          "hazelcast-server:5702");  
        // You can add near cache config for each map seperatly          
        clientConfig.addNearCacheConfig(createNearCacheConfig("token"));  
        return HazelcastClient.newHazelcastClient(clientConfig);  
    }  
  
    private NearCacheConfig createNearCacheConfig(String mapKey) {  
        NearCacheConfig nearCacheConfig = new NearCacheConfig();  
        nearCacheConfig.setName(mapKey);  
        nearCacheConfig.setTimeToLiveSeconds(360);  
        nearCacheConfig.setMaxIdleSeconds(60);  
        return nearCacheConfig;  
    }  
}
```
By the way, this config will be added to the application that only reads from the cache. There is no need for an additional config for the application that writes to the cache.

We examined topologies and approaches with examples. If you noticed, there are only minor differences in terms of configuration between the 3 topologies. There is no difference in terms of writing and reading. After you choose and integrate the topology that suits your architecture, you can easily switch to different topologies in the future as needed. In fact, it will be easy for you to switch to a different product for cache integration since it is simply a write and read map process. In this respect, Hazelcast is an effective product for developers.

In this article, we only gave an example of using Hazelcast for cache. Different approaches can also be used in different scenarios.
---
# Deploy Hazelcast cluster in a replicated Swarm service
It took us a long time to figure this one out so I will share what we found, and what appears to be a good solution for this issue. The example presented here is with a Spring integration but it could work with any hazelcast integration.

### The requirement

For some business reasons that I won’t detail here, we needed to have a swarm replicated service with an Hazelcast cluster that can share the cache among replications. The idea is to make sure that a data cached in a first call to that service API is available when calling back the service later, even though we don’t know on which replica we will end up for each call.

The Hazelcast that we used is the Spring Boot standard integration.
```xml
<dependency>  
    <groupId>com.hazelcast</groupId>  
    <artifactId>hazelcast-spring</artifactId>  
</dependency>
```
### The Problem

Problem is, when configuring the cluster, you can’t really know the ip of all the instances of your service, since it will be in Swarm, and using the DNS resolution won’t work because it will return a single (I’m guessing virtual) IP for all instances of the service.

There are some other solutions but it requires to install external services (such as Hazelcast Discovery SPI**)**, that made it more complicated but confirmed that it was not a trivial problem. Since we found this solution we did not try them.

### The Solution

The solution was to use the round robin configuration of Swarm, that makes the DNS returns all the IPs of the services instead of a virtual one. This enables each Hazelcast instance to see the others and the cluster was hence working instead of having each instance creating an individual cluster. With an adequate configuration of Hazelcast, it worked like a charm.

Below is the full configuration.

In **docker-compose file**:

There are 2 important things :  
- The “endpointmode” that make the internal swarm DNS returns the actual IPs of service instances  
- The “order” that we set so the service start before stopping the old service, enabling a copy of the cache between the old & new instance.
```yaml
version: "3.7"services:  
   my-service:  
    image: ...  
    environment:  
      SPRING_PROFILES_ACTIVE: ${PROFILE}  
    deploy:  
      endpointmode: dnsrr  
      updateconfig:  
        order: start-first   
      ....  
    dependson:  
      - cache-manager ### Hazelcast cache manager
```
In **Hazelcast Java Configuration:**

We chose to configure Hazelcast through Java configuration with the @Bean annotation.
```java
@Bean  
public Config hazelCastConfig() {  
// Retrieve Instances IPs from the swarm service name  
InetAddress[] ips = {};  
try {  
   ips = InetAddress.getAllByName("my-service");  
} catch (UnknownHostException e) {  
   LOGGER.error("unable to find any my-service instance on the network");  
}  
  
Config config = new Config()  
             .setInstanceName(this.config.getCache().getInstance());  
        config.setProperty("hazelcast.rest.enabled", "true");**// Add ips to cluster**  
if (ips.length > 0) {  
   for (InetAddress ip : ips) {  
      LOGGER.info("Joining cluster with member " + ip.getHostAddress());  
      config.getNetworkConfig().getJoin()  
         .getTcpIpConfig().setEnabled(true)  
         .addMember(ip.getHostAddress());  
   }  
}
// Set interface where to communicate**  
config.getNetworkConfig()  
   .setInterfaces(  
      new InterfacesConfig().setEnabled(true)  
         .addInterface("10.0.*.*")  
         .addInterface("127.0.*.*")  
);  
  
// Some other config that make it work :)**  
config.getNetworkConfig().getJoin().getTcpIpConfig().setEnabled(true);  
        config.getNetworkConfig()  
                .getJoin().getMulticastConfig().setEnabled(false);  
  
        config.getNetworkConfig().setPort(this.config.getCache().getPort())  
                .setPortAutoIncrement(true)  
                .setPortCount(20)  
        ;...  
}
```
### Conclusion

This has been in production for a while now and it is working pretty well.  
The main limitation were that the first time, the replicas started too quickly so they created several clusters but restarting instances one by one solved the issue.  
There is always the risk of having an old version stopped before the replication is complete and hence losing data but the fact that Swarm reload containers one by one and the start-first configuration is enough for us to avoid this issue. I guess it could be managed with the health check of Swarm/docker.  
I’m not sure it is a good practice to do that since we did not find anyone having done that on internet before trying it, but it is working well in practice. Any feedback is welcomed :)

---
# Apache Ignite vs. Hazelcast: Choosing the Right In-Memory Data Grid for Your Application

-   **Hook**: Begin with a quick overview of why in-memory data grids (IMDGs) are essential for high-performance applications, where they can drastically reduce latency and boost scalability.
-   **Why Compare Apache Ignite and Hazelcast?**: Briefly introduce Apache Ignite and Hazelcast as two popular IMDG solutions with overlapping but distinct features.
-   **Objective**: Mention that the article will explore their features, strengths, and trade-offs to help readers decide which fits best with their application requirements.

### Section 1: Overview of Apache Ignite and Hazelcast

-   **Apache Ignite**: Provide a high-level summary of Apache Ignite, covering its main features like distributed data storage, SQL support, compute grid, streaming, and native persistence.
-   **Hazelcast**: Similarly, provide an overview of Hazelcast, highlighting its strengths in distributed caching, data grid functionality, and easy integration with existing applications.
-   **Similarities and Differences**: Briefly outline how both are in-memory solutions but differ in focus areas, with Ignite geared toward a broader range of data-processing tasks and Hazelcast specializing in data grid and caching.

### Section 2: Key Features Comparison

-   **Data Grid and Caching**: Describe each platform’s caching and data grid capabilities.
-   **Ignite**: Focus on distributed caching with partitioned and replicated modes, in-memory SQL grid, and flexible data storage.
-   **Hazelcast**: Emphasize ease of use in distributed caching, including its map-based data structures (`IMap`) and ability to cache frequently accessed data.
-   **Verdict**: Highlight which platform may be better for specific caching needs (e.g., Hazelcast for simpler caching use cases, Ignite for more complex data requirements).
-   **SQL and Data Processing**:
-   **Ignite**: Discuss Ignite’s strong SQL support, which enables complex querying and indexing for in-memory data, making it suitable for data-centric applications.
-   **Hazelcast**: Hazelcast also offers SQL support but is generally less mature than Ignite’s, making it better for simpler, less intensive queries.
-   **Verdict**: For applications with SQL-heavy requirements, Ignite may be preferable; Hazelcast is better for lightweight query scenarios.
-   **Compute Grid and Distributed Processing**:
-   **Ignite**: Explain Ignite’s compute grid functionality that allows users to distribute computation tasks across nodes, supporting parallel processing and aggregations.
-   **Hazelcast**: While Hazelcast offers task execution, it doesn’t match Ignite’s capabilities for complex, distributed compute tasks.
-   **Verdict**: For data-intensive processing or parallel computation, Ignite offers more robust support, whereas Hazelcast can be simpler for basic task execution.

### Section 3: Persistence and Data Durability

-   **Apache Ignite Native Persistence**: Highlight Ignite’s native persistence, which allows data to be stored on disk, surviving restarts, and integrating seamlessly with the in-memory layer.
-   **Hazelcast Persistence**: Hazelcast generally treats persistence as external (often paired with databases or file-based storage), and it is commonly used for caching rather than long-term data storage.
-   **Verdict**: For applications needing durability or a hybrid memory/persistent solution, Ignite’s native persistence is advantageous. Hazelcast works well when persistence can be handled by external databases.

### Section 4: Performance and Scalability

-   **Benchmarks and Performance**: Discuss general performance considerations, where both Ignite and Hazelcast excel in low-latency data access but may have different overhead depending on use cases.
-   **Scaling Capabilities**:
-   **Ignite**: Highlight Ignite’s scalability features, like automatic data rebalancing and support for very large clusters.
-   **Hazelcast**: Mention Hazelcast’s linear scaling for caching and straightforward cluster setup.
-   **Verdict**: Both are scalable, but Ignite tends to have more features for fine-tuning in large, distributed setups. Hazelcast may be easier for simpler scaling needs, particularly for caching.

### Section 5: Use Cases and Best Fit

-   **When to Use Apache Ignite**: Describe scenarios where Ignite’s advanced data grid, SQL capabilities, compute grid, and persistence make it an excellent choice.
-   **Example Use Cases**: Real-time analytics, IoT data processing, hybrid memory/persistent storage for high-performance applications, and parallel computation.
-   **When to Use Hazelcast**: Describe where Hazelcast excels in simplicity, ease of integration, and distributed caching.
-   **Example Use Cases**: Session caching in web applications, simple data grid for microservices, and applications with lighter data storage needs.

### Section 6: Integration and Ease of Use

-   **Setting Up and Configuring**:
-   **Ignite**: Mention that Ignite’s setup can be more involved, especially with configuration for compute grid and persistence.
-   **Hazelcast**: Highlight Hazelcast’s simpler setup and configuration, making it easier to integrate as a plug-and-play caching solution.
-   **Tooling and Management**:
-   **Ignite**: Explain Ignite’s monitoring options, including JMX and Management Center (optional) for cluster management.
-   **Hazelcast**: Discuss Hazelcast’s Management Center, which is effective for monitoring caches and cluster health in real time.
-   **Verdict**: Hazelcast’s simpler configuration may appeal to teams looking for a quick, effective caching solution, while Ignite offers more extensive tools and configuration options for complex requirements.

### Conclusion

-   **Summarize Key Differences**: Briefly recap each platform’s strengths — Ignite for comprehensive, data-intensive applications and Hazelcast for simpler caching and data grid needs.
-   **Which Should You Choose?**: Offer final guidance: Choose Ignite if your application needs complex data processing and compute capabilities; choose Hazelcast if you need straightforward caching with high availability and ease of integration.
-   **Encourage Exploration**: Recommend experimenting with both tools for a hands-on feel of how they align with specific use cases.

---
# Creating Distributed Task Scheduler using Hazelcast

A distributed task scheduler is a system that coordinates the scheduling and execution of tasks across multiple nodes in a distributed system.

Distributed task schedulers are commonly used in large-scale distributed systems, such as data centers and cloud computing environments, where tasks may need to be executed on a large number of machines simultaneously. They are typically designed to be fault-tolerant, so that if a node fails, tasks can be automatically rerouted to other nodes in the system.

Examples of distributed task schedulers include Apache Mesos, Kubernetes, and Apache Hadoop YARN. These systems provide a centralized framework for managing resources and scheduling tasks, and allow developers to focus on writing code instead of worrying about the underlying infrastructure.

For Example, running 10,000 compliance checks/policies on 500,000 machine in data center for scanning.

> How to run 5–10 Billion task daily?

In this article we are creating distributed scheduler using spring boot and hazelcast clustering.

![](https://miro.medium.com/v2/resize:fit:864/1*lwLQnWSL9I1YCaK8UNNeJw.png)

To create a distributed task scheduler using Spring Boot and Hazelcast, we can follow these general steps:

1.  Set up a Spring Boot project and add the necessary dependencies. You will need to add the Hazelcast dependency to your project, as well as any other dependencies you might need for your specific use case.
2.  Configure Hazelcast in your Spring Boot application. You will need to create a Hazelcast configuration bean and configure it to enable the distributed task scheduling feature.
```xml
 <dependency>  
     <groupId>com.hazelcast</groupId>  
     <artifactId>hazelcast-spring</artifactId>  
     <version>5.0.1</version>  
  </dependency>
```
```java
@Bean  
public Config hazelcastConfig() {  
    Config config = new Config();  
    config.getNetworkConfig().getJoin()  
          .getMulticastConfig().setEnabled(false);  
    config.getNetworkConfig().getJoin()  
           .getTcpIpConfig().setEnabled(true)  
           .setMembers(Arrays.asList("127.0.0.1"));  
    config.addExecutorConfig(new ExecutorConfig("distributed-scheduler")  
            .setPoolSize(10)  
            .setQueueCapacity(1000));  
    return config;  
}
```
3. Create Scheduler Service, here we schedule a job which will execute task on leader node and distribute the task to all members.
```java
@Service  
public class DistributedScheduler {  
    @Autowired  
    private HazelcastInstance instance;  
  
    @Scheduled(fixedDelay = 10000, initialDelay = 60000)  
    void startJob() {  
        String leaderAddress = getOldestMember().getSocketAddress().toString();  
        String currentAddress = instance.getCluster().getLocalMember().getSocketAddress().toString();  
  
            //Run the task only on leader node  
  
        if (currentAddress.equals(leaderAddress)) {  
            System.out.println("I am leader, use me to poll database, distribute task etc");  
            IScheduledExecutorService scheduler = instance.getScheduledExecutorService("distributed-scheduler");  
            scheduler.schedule(new MyScheduledTask(), 10, TimeUnit.SECONDS);  
        }  
    }  
  
    private Member getOldestMember() {  
        Cluster cluster = instance.getCluster();  
        Member oldestMember = null;  
        for (Member member : cluster.getMembers()) {  
            if (oldestMember == null || member.getUuid().compareTo(oldestMember.getUuid()) < 0) {  
                oldestMember = member;  
            }  
        }  
        return oldestMember;  
    }  
  
    static class MySchedulerJob implements Serializable, Runnable {  
        private static final long serialVersionUID = 1L;  
  
        @Override  
        public void run() {  
            System.out.println("My Task");  
        }  
    }  
}
```

The node that will execute the `Task` depends on the configuration of the Hazelcast cluster and the availability of resources at the time the task is scheduled.

In a Hazelcast cluster, all nodes are equal and any node can execute a task. When a task is scheduled using the `IScheduledExecutorService`, it is added to a queue and will be executed by the next available node in the cluster that has the resources to run the task.

Hazelcast automatically manages the distribution of tasks across the cluster, so you do not need to worry about manually assigning tasks to specific nodes.

Hazelcast is designed to be fault-tolerant and provide high availability for data and services in a distributed environment. Hazelcast uses a number of techniques to ensure fault tolerance, including:

1.  Data Replication: Hazelcast replicates data across multiple nodes in the cluster, so if a node fails, the data is still available on other nodes. Replication ensures that the data remains available even if some nodes go down.
2.  Node Clustering: Hazelcast allows multiple nodes to join together to form a cluster. If a node fails, other nodes in the cluster can take over its responsibilities and ensure that the cluster remains operational.
3.  Automatic Failover: Hazelcast automatically detects node failures and redirects requests to other available nodes in the cluster.
4.  Quorum Rule: Hazelcast allows you to define a quorum rule to ensure that a certain number of nodes are available before operations can be executed. This helps to prevent data loss or inconsistencies in case of network partitioning or other issues.

In summary, Hazelcast is designed to be fault-tolerant and provide high availability for data and services in a distributed environment. Hazelcast uses a combination of data replication, data partitioning, node clustering, automatic failover, and quorum rules to ensure that the cluster remains operational even in case of node failures or other issues.

https://docs.hazelcast.com/imdg/4.2/computing/scheduled-executor-service
---

# Hazelcast Discovery Mechanisms.
A simple guide to Hazelcast discovery mechanisms

In the midst of optimizing a Spring Boot application’s startup time, I encountered an unexpected challenge: **Hazelcast**, the distributed in-memory data grid, was causing delays during the startup process.  
It felt like we were getting ready for a speedy race, but our orchestra conductor, Hazelcast, was in no rush to start the show. The culprit, Hazelcast’s discovery mechanism, became the center of my attention as I embarked on a journey to improve the application’s efficiency.

My pursuit of faster startup times evolved into a captivating detective story. With each adjustment and tweak, I unraveled the intricacies of Hazelcast’s behavior. The experience reinforced the idea that even the smallest changes could yield significant results. In the end, it was a lesson in the art of investigation and optimization, where every millisecond saved contributed to the goal of achieving peak performance in the application startup process.

### What is Hazelcast?

Hazelcast, a powerful in-memory data grid (IMDG) and distributed computing platform is designed to handle data at scale in real-time meaning that it can be used for caching, data distribution, microservices communication, real-time analysis, distributed locks, etc.

Central to its distributed architecture are discovery mechanisms that allow nodes within a cluster to find and communicate with each other seamlessly. In this guide, we will explore Hazelcast’s various discovery mechanisms, providing an in-depth explanation of each before delving into their respective pros and cons. By the end, you’ll be well-equipped to select the optimal discovery mechanism for your distributed system.

### Understanding Hazelcast Discovery Mechanisms

Hazelcast offers multiple discovery mechanisms, each tailored to specific deployment scenarios and requirements. Let’s take a closer look at each mechanism before evaluating their pros and cons:

**1. Multicast Discovery**

Multicast discovery is a simple and automatic way for nodes in a Hazelcast cluster to discover each other within the same network segment. In Java, configuring multicast discovery is straightforward, as you only need to enable it without specifying individual IP addresses or ports.

```java
Config config = new Config();  
config.getNetworkConfig().getJoin().getMulticastConfig().setEnabled(true);  
HazelcastInstance hazelcastInstance = Hazelcast.newHazelcastInstance(config);
```
```yaml
hazelcast:  
  network:  
    join:  
      multicast:  
        enabled: true
```
**Pros**:

-   **Simplicity**: Multicast discovery is the easiest to set up in Java, requiring minimal configuration.
-   **Automatic Discovery**: Nodes in the same network segment can automatically discover each other, making it suitable for LANs.

**Cons**:

-   **Limited to LANs**: Multicast is not suitable for WANs or cloud deployments where multicast traffic may be blocked or unreliable.
-   **Security Concerns**: Lack of security features like authentication can be a concern in some environments.

**2. TCP/IP Discovery**

TCP/IP discovery involves manually specifying IP addresses and ports to allow nodes to discover each other. This method provides greater control and is suitable for WANs and cloud-based deployments.
```java
Config config = new Config();  
config.getNetworkConfig().getJoin().getTcpIpConfig().setEnabled(true)  
    .addMember("192.168.1.100")  
    .addMember("192.168.1.101");  
HazelcastInstance hazelcastInstance = Hazelcast.newHazelcastInstance(config);
```
```yaml
hazelcast:  
  network:  
    join:  
      tcp-ip:  
        enabled: true  
        members:  
          - "192.168.1.100"  
          - "192.168.1.101"
```

**Pros**:

-   **WAN-Friendly**: Suitable for WANs and cloud-based deployments.
-   **Security**: Allows Java developers to enforce security measures like authentication and encryption.

**Cons**:

-   **Manual Configuration:** Requires manual configuration of IP addresses and ports, which can be cumbersome in large clusters.
-   **Less Dynamic:** Not as dynamic as multicast for adding new nodes; configurations may need manual updates.

**3. AWS Discovery**

AWS discovery is tailored for deployments on Amazon Web Services (AWS). It leverages AWS-specific mechanisms to automatically discover Hazelcast nodes within the same AWS region.
```java
Config config = new Config();  
config.getNetworkConfig().getJoin().getAwsConfig().setEnabled(true)  
    .setAccessKey("YOUR_AWS_ACCESS_KEY")  
    .setSecretKey("YOUR_AWS_SECRET_KEY")  
    .setRegion("us-east-1");  
HazelcastInstance hazelcastInstance = Hazelcast.newHazelcastInstance(config);
```
```yml
 hazelcast:  
  network:  
    join:  
      aws:  
        enabled: true  
        access-key: "YOUR_AWS_ACCESS_KEY"  
        secret-key: "YOUR_AWS_SECRET_KEY"  
        region: "us-east-1"
```

**Pros**:

-   **Seamless AWS Integration:** Works seamlessly with AWS infrastructure, automatically discovering nodes in the same AWS region.
-   **Dynamic Scaling:** Easily accommodates changes in cluster size as AWS instances are added or removed.

**Cons**:

-   **AWS-Specific:** Limited to AWS environments; not suitable for other cloud providers or on-premises deployments.
-   **Vendor Lock-In:** This may result in vendor lock-in as it is tightly coupled with AWS services.

**4. Kubernetes Discovery**

Kubernetes discovery is designed for Kubernetes environments, where Hazelcast nodes can automatically discover each other using Kubernetes service discovery.
```java
Config config = new Config();  
config.getNetworkConfig().getJoin().getKubernetesConfig().setEnabled(true);  
HazelcastInstance hazelcastInstance = Hazelcast.newHazelcastInstance(config);
```
```yaml
hazelcast:  
  network:  
    join:  
      kubernetes:  
        enabled: true
```
**Pros**:

-   **Native Kubernetes Integration:** Natively integrates with Kubernetes service discovery.
-   **Dynamic Scaling:** The Hazelcast cluster can dynamically scale based on Kubernetes’ auto-scaling features.

**Cons**:

-   **Kubernetes-Specific:** Limited to AWS environments; not suitable for other cloud providers or on-premises deployments.
-   **Complexity**: This may result in vendor lock-in as it is tightly coupled with AWS services.

When selecting the appropriate discovery mechanism for your Java-based Hazelcast cluster, consider factors such as your deployment environment, security requirements, scalability needs, vendor affiliations, and your team’s expertise in managing complex configurations. Each mechanism has its strengths and weaknesses, and making an informed choice will ensure the reliability, security, and scalability of your distributed system.

See more 😉 [https://docs.hazelcast.com/imdg/4.2/clusters/discovery-mechanisms](https://docs.hazelcast.com/imdg/4.2/clusters/discovery-mechanisms)

---
# Spring Boot integrates Hazelcast Jet quick start Demo

### 1. What is Hazelcast Jet?

Hazelcast Jet allows you to write modern Java code focused on data transformation, while it takes care of all the heavy lifting of getting data flowing across a cluster of nodes and running computations. It supports processing both bounded (batch) and unbounded (streaming) data. Jet handles the following problems well:

-   **Scale up and scale out** : parallelize computation across all CPU cores and cluster nodes
-   **Automatic rescaling** : scaling to newly added nodes and recovering from nodes that leave or fail
-   **Correctness guarantees : At-least-once** and **exactly-once processing** in the event of node failures

Jet integrates with many popular data storage systems such as Apache Kafka, Hadoop, relational databases, message queues, and more. Jet supports a wide range of data transformations such as windowed aggregations. For example, if your data is GPS location reports from millions of users, Jet can compute the velocity vector for each user using only **a sliding window** and a few lines of code. Jet also comes with a full-featured in-memory key-value store. Use it to cache results, store reference data, or as a data source itself.

### 2. Code Engineering

### Experimental objectives

> Implement word count job

### pom.xml
```xml
<?xml version="1.0" encoding="UTF-8"?>  
<project xmlns="http://maven.apache.org/POM/4.0.0"  
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">  
    <parent>  
        <artifactId>springboot-demo</artifactId>  
        <groupId>com.et</groupId>  
        <version>1.0-SNAPSHOT</version>  
    </parent>  
    <modelVersion>4.0.0</modelVersion>  
    <artifactId>hazelcast-jet</artifactId>  
    <properties>  
        <maven.compiler.source>8</maven.compiler.source>  
        <maven.compiler.target>8</maven.compiler.target>  
    </properties>  
    <dependencies>  
        <dependency>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-starter-web</artifactId>  
        </dependency>  
        <dependency>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-autoconfigure</artifactId>  
        </dependency>  
        <dependency>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-starter-test</artifactId>  
            <scope>test</scope>  
        </dependency>  
        <dependency>  
            <groupId>com.hazelcast.jet.contrib</groupId>  
            <artifactId>hazelcast-jet-spring-boot-starter</artifactId>  
            <version>2.0.0</version>  
        </dependency>  
    </dependencies>  
</project>
```
### controller
```java
package com.et.jet.controller;  
import com.et.jet.DemoApplication;  
import com.et.jet.example.WordCount;  
import com.hazelcast.jet.JetInstance;  
import com.hazelcast.jet.config.JobConfig;  
import com.hazelcast.jet.pipeline.Pipeline;  
import com.hazelcast.jet.pipeline.Sinks;  
import com.hazelcast.jet.pipeline.test.TestSources;  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RestController;  
import java.util.HashMap;  
import java.util.Map;  
@RestController  
public class HelloWorldController {  
    @Autowired  
    JetInstance instance;  
    @RequestMapping("/hello")  
    public Map<String, Object> showHelloWorld(){  
        Map<String, Object> map = new HashMap<>();  
        map.put("msg", "HelloWorld");  
        return map;  
    }  
    @RequestMapping("/submitJob")  
    public void submitJob() {  
        Pipeline pipeline = Pipeline.create();  
        pipeline.readFrom(TestSources.items("foo", "bar"))  
                .writeTo(Sinks.logger());  
        JobConfig jobConfig = new JobConfig()  
                .addClass(HelloWorldController.class);  
        instance.newJob(pipeline, jobConfig).join();  
    }  
    @Autowired  
    WordCount wordCount;  
    @RequestMapping("/wordCount")  
    public void wordCount() {  
        wordCount.go();  
    }  
}
```
### WordCount

`Pipeline`It forms the basic structure of a Jet application. **The processing within the pipeline follows these steps:**

-   Reading data from a source
-   Transform Data
-   Writing data to the receiver

This example shows that the pipeline will read from the file, apply grouping and aggregation transformations, and finally write to the map.
```java
package com.et.jet.example;  
import com.hazelcast.jet.Jet;  
import com.hazelcast.jet.JetInstance;  
import com.hazelcast.jet.pipeline.Pipeline;  
import com.hazelcast.jet.pipeline.Sinks;  
import com.hazelcast.jet.pipeline.Sources;  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.stereotype.Component;  
import java.io.*;  
import java.util.HashMap;  
import java.util.Map;  
import java.util.concurrent.TimeUnit;  
import java.util.regex.Pattern;  
import static com.hazelcast.function.Functions.wholeItem;  
import static com.hazelcast.jet.Traversers.traverseArray;  
import static com.hazelcast.jet.aggregate.AggregateOperations.counting;  
import static java.util.Comparator.comparingLong;  
/**  
 * Demonstrates a simple Word Count job in the Pipeline API. Inserts the  
 * text of The Complete Works of William Shakespeare into a Hazelcast  
 * IMap, then lets Jet count the words in it and write its findings to  
 * another IMap. The example looks at Jet's output and prints the 100 most  
 * frequent words.  
 */  
@Component  
public class WordCount {  
    private static final String BOOKLINES = "bookLines";  
    private static final String COUNTS = "counts";  
    String filepath ="D:/tmp/shakespeare-complete-works.txt";  
    @Autowired  
    private JetInstance jet;  
    private static Pipeline buildPipeline() {  
        Pattern delimiter = Pattern.compile("W+");  
        Pipeline p = Pipeline.create();  
        p.readFrom(Sources.<Long, String>map(BOOKLINES))  
         .flatMap(e -> traverseArray(delimiter.split(e.getValue().toLowerCase())))  
         .filter(word -> !word.isEmpty())  
         .groupingKey(wholeItem())  
         .aggregate(counting())  
         .writeTo(Sinks.map(COUNTS));  
        return p;  
    }  
    public static void main(String[] args) throws Exception {  
        new WordCount().go();  
    }  
    /**  
     * This code illustrates a few more things about Jet, new in 0.5. See comments.  
     */  
    public void go() {  
        try {  
            setup();  
            System.out.println("nCounting words... ");  
            long start = System.nanoTime();  
            Pipeline p = buildPipeline();  
            jet.newJob(p).join();  
            System.out.println("done in " + TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - start) + " milliseconds.");  
            Map<String, Long> results = jet.getMap(COUNTS);  
            printResults(results);  
        } finally {  
            Jet.shutdownAll();  
        }  
    }  
    private void setup() {  
        //jet = Jet.bootstrappedInstance();  
        System.out.println("Loading The Complete Works of William Shakespeare");  
        try {  
            long[] lineNum = {0};  
            Map<Long, String> bookLines = new HashMap<>();  
            InputStream stream = new FileInputStream(filepath);  
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream))) {  
                reader.lines().forEach(line -> bookLines.put(++lineNum[0], line));  
            }  
            jet.getMap(BOOKLINES).putAll(bookLines);  
        } catch (IOException e) {  
            throw new RuntimeException(e);  
        }  
    }  
  
    private static void printResults(Map<String, Long> counts) {  
        final int limit = 100;  
        StringBuilder sb = new StringBuilder(String.format(" Top %d entries are:%n", limit));  
        sb.append("/-------+---------n");  
        sb.append("| Count | Word    |n");  
        sb.append("|-------+---------|n");  
        counts.entrySet().stream()  
                .sorted(comparingLong(Map.Entry<String, Long>::getValue).reversed())  
                .limit(limit)  
                .forEach(e -> sb.append(String.format("|%6d | %-8s|%n", e.getValue(), e.getKey())));  
        sb.append("-------+---------/n");  
        System.out.println(sb.toString());  
    }  
}
```
The above are just some key codes. For all codes, please refer to the following code repository

### Code repository

-   https://github.com/Harries/springboot-demo

### 3. Testing

1.  Start the Spring Boot application
2.  Visit [http://127.0.0.1:8088/wordCount](http://127.0.0.1:8088/wordCount)
3.  View console output log

Counting words...   
2024-09-09 13:58:23.085 INFO 22816 --- [ached.thread-12] c.h.jet.impl.JobCoordinationService : Starting job 0c49-9604-11c0-0001 based on submit request  
2024-09-09 13:58:23.094 INFO 22816 --- [ached.thread-12] com.hazelcast.jet.impl.MasterJobContext : Didn't find any snapshot to restore for job '0c49-9604-11c0-0001', execution 0c49-9604-11c1-0001  
2024-09-09 13:58:23.094 INFO 22816 --- [ached.thread-12] com.hazelcast.jet.impl.MasterJobContext : Start executing job '0c49-9604-11c0-0001', execution 0c49-9604-11c1-0001, execution graph in DOT format:  
digraph DAG {  
 "mapSource(bookLines)" [localParallelism=1];  
 "fused(flat-map, filter)" [localParallelism=12];  
 "group-and-aggregate-prepare" [localParallelism=12];  
 "group-and-aggregate" [localParallelism=12];  
 "mapSink(counts)" [localParallelism=1];  
 "mapSource(bookLines)" -> "fused(flat-map, filter)" [queueSize=1024];  
 "fused(flat-map, filter)" -> "group-and-aggregate-prepare" [label="partitioned", queueSize=1024];  
 subgraph cluster0 {  
 "group-and-aggregate-prepare" -> "group-and-aggregate" [label="distributed-partitioned", queueSize=1024];  
 }  
 "group-and-aggregate" -> "mapSink(counts)" [label="partitioned", queueSize=1024];  
}  
HINT: You can use graphviz or http://viz-js.com to visualize the printed graph.  
2024-09-09 13:58:23.158 INFO 22816 --- [ached.thread-12] c.h.jet.impl.JobExecutionService : Execution plan for jobId=0c49-9604-11c0-0001, jobName='0c49-9604-11c0-0001', executionId=0c49-9604-11c1-0001 initialized  
2024-09-09 13:58:23.161 INFO 22816 --- [ached.thread-12] c.h.jet.impl.JobExecutionService : Start execution of job '0c49-9604-11c0-0001', execution 0c49-9604-11c1-0001 from coordinator [10.11.68.77]:5701  
2024-09-09 13:58:23.250 INFO 22816 --- [ached.thread-14] com.hazelcast.jet.impl.MasterJobContext : Execution of job '0c49-9604-11c0-0001', execution 0c49-9604-11c1-0001 completed successfully  
 Start time: 2024-09-09T13:58:23.085  
 Duration: 161 ms  
 For further details enable JobConfig.storeMetricsAfterJobCompletion  
done in 272 milliseconds.  
 Top 100 entries are:  
/-------+---------  
| Count | Word |  
|-------+---------|  
| 2 | hello |  
| 2 | the |  
| 1 | world |  
| 1 | say |  
-------+---------/
---


# Multi-Pod In-Memory Runtime Feature Toggling with Togglz & Hazelcast

In our previous blog post, we demonstrated the implementation of a runtime feature toggling API. If you haven’t read it yet, click [here](/runtime-feature-toggling-with-spring-togglz-93fa2619b3f5) to check it out.

In this blog post, we will delve into how we run the aforementioned API in our backend, taking into consideration high availability and high performance.

Here is the architecture we use to achieve this:

![](https://miro.medium.com/v2/resize:fit:875/1*ElwLyqkkRFwSlxM0UVsJUQ.png)

The Feature-API is developed in Java using the Spring Framework. We incorporate Hazelcast into it. Hazelcast provides an embedded mode specifically designed for Java applications, allowing it to be added as a dependency to Java projects. In this mode, the Hazelcast cluster runs within the application itself, eliminating the need for setting up a separate Hazelcast cluster.

Hazelcast simply implements Java native data structures in a distributed manner. We are particularly interested in the Replicated Map data structure provided by Hazelcast. In this data structure, all Hazelcast members store the complete data for a given map. This allows any Hazelcast member to perform read and write operations in memory. When an update occurs, it is asynchronously propagated to other members. However, there is a drawback: due to latency, there may be instances of stale reads during updates. If having occasional stale reads is acceptable for your use case, then you can benefit from the ability to serve all reads and writes from memory. The Replicated Map should be used for data that does not change frequently, as each update needs to be propagated to other members. If there are numerous updates and a large number of members, Hazelcast will perform significant work to maintain consistency across the cluster for each member’s replicated map state.

Now let’s see how to implement:

1- Add Hazelcast dependency to pom.xml (for Maven projects)

2- Add hazelcast.yaml & configure Hazelcast cluster

By following these two steps, Spring will automatically configure and add the HazelcastInstance object to the application context.

The next question is, how will our servers discover each other? Hazelcast offers various discovery mechanisms, and for this demo, we will utilize the default mechanism, which is multicast discovery. If you are using Kubernetes, you can refer to the Hazelcast documentation to learn how to configure the YAML file for Kubernetes.

3- Implement the StateRepository Interface of Togglz by Using Hazelcast

<iframe src="https://engineering.getmidas.com/media/c35bbac415e29fe862f97284f19989dc" allowfullscreen="" frameborder="0" height="960" width="680" title="HazelcastReplicatedStateRepository.java" class="ei o hd sy bh" scrolling="no"></iframe>

This repository retrieves feature state information from the Hazelcast replicated map data structure if it is available in the cache. Otherwise, it retrieves the state from the delegate state repository, which in this architecture is the database. The feature state is promptly updated in Hazelcast after being updated in the database.

4- Configure Togglz StateRepository Bean to Use Hazelcast

<iframe src="https://engineering.getmidas.com/media/0473716824d1d0dbddbb605ce03d41ed" allowfullscreen="" frameborder="0" height="762" width="680" title="TogglzConfiguration.java" class="ei o hd sy bh" scrolling="no"></iframe>

With this configuration, Hazelcast state repository will be in front of the JDBC state repository. This means:

-> Feature read requests will be served from Hazelcast’s in-memory cache

-> Feature write request will update the Hazelcast in-memory cache for all the pods in the cluster and will update the database for persisting the state

This configuration will be enough to show the idea. Let’s see it in action.

— —

1 — Start the PostgreSQL docker instance:
```shell
docker run -e POSTGRES_PASSWORD=postgres -p 5432:5432 -d postgres
```
2 — Start a couple of Feature-API Spring Boot application
```shell
mvn spring-boot:run -Dspring-boot.run.arguments=--server.port=8081  
mvn spring-boot:run -Dspring-boot.run.arguments=--server.port=8082  
mvn spring-boot:run -Dspring-boot.run.arguments=--server.port=8083
```

3 — Enable NEW_WEBSITE feature from the Togglz panel

![](https://miro.medium.com/v2/resize:fit:875/1*0CJcc1PQX5YiLk33Tr0h1A.png)

This update will propagate the other two applications via Hazelcast Replicated Map in an async manner and the “enabled” state will be persisted in the database.

4 — Retrieve feature state from all the applications and see the logs
```shell
curl 'http://localhost:8082/is-feature-active?feature=NEW_WEBSITE'  
curl 'http://localhost:8083/is-feature-active?feature=NEW_WEBSITE'
```
You will see that applications that run on port 8082 and 8083 will serve the curl request from the Hazelcast in-memory cache:

... Tomcat started on port(s): 8082 (http) with context path ''  
... Started FeatureApiApplication in 5.04 seconds (JVM running for 5.177)  
... Feature will be served from Hazelcast: NEW_WEBSITE

... Tomcat started on port(s): 8083 (http) with context path ''  
... Started FeatureApiApplication in 4.779 seconds (JVM running for 4.92)  
... Feature will be served from Hazelcast: NEW_WEBSITE

— —

To summarize, by utilizing Hazelcast’s Replicated Map data structure, we have successfully implemented Togglz multi-pod functionality. Thanks to Hazelcast’s Replicated Map, all read and write requests are served from memory. Write requests are asynchronously propagated to other servers in the Hazelcast cluster.

— —
https://github.com/fatih-iver/feature-api

Checkout Togglz website: [https://www.togglz.org/](https://www.togglz.org/)
Checkout Hazelcast website: [https://hazelcast.com/](https://hazelcast.com/)
```xml
<dependencies>
    <dependency>
    <groupId>com.hazelcast</groupId>
    <artifactId>hazelcast-spring</artifactId>
    <version>5.2.1</version>
</dependency>

```
[view raw](https://gist.github.com/fatih-iver/9d524bb81bb8913eec70aa943efd79d5/raw/264f851f489efa24ef694fd127ec40e7e47631da/pom.xml) [pom.xml](https://gist.github.com/fatih-iver/9d524bb81bb8913eec70aa943efd79d5###file-pom-xml) hosted with ❤ by [GitHub](https://github.com)

---
```yaml
hazelcast:
cluster-name: feature-api-hazelcast-cluster
```
[view raw](https://gist.github.com/fatih-iver/bccd87f59f01bcf374e2269b52dccc37/raw/84192651dc5c82f0e5ec4da60a081367c6814294/hazelcast.yaml) [hazelcast.yaml](https://gist.github.com/fatih-iver/bccd87f59f01bcf374e2269b52dccc37###file-hazelcast-yaml) hosted with ❤ by [GitHub](https://github.com)

---
```java
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.replicatedmap.ReplicatedMap;
import org.togglz.core.Feature;
import org.togglz.core.repository.FeatureState;
import org.togglz.core.repository.StateRepository;

public class HazelcastReplicatedStateRepository implements StateRepository {
    private final StateRepository delegate;
    private final ReplicatedMap<String, FeatureState> replicatedMap;

    public HazelcastReplicatedStateRepository(StateRepository delegate, HazelcastInstance hazelcastInstance) {
        this.delegate = delegate;
        this.replicatedMap = hazelcastInstance.getReplicatedMap("togglz");
    }

    @Override
    public FeatureState getFeatureState(Feature feature) {
    String featureName = feature.name();
        FeatureState featureState = replicatedMap.get(featureName);
        if (featureState != null) {
            return featureState;
        }

        featureState = delegate.getFeatureState(feature);
        if (featureState != null) {
            replicatedMap.put(featureName, featureState.copy());
        }
        
        return featureState;
    }

    @Override
    public void setFeatureState(FeatureState featureState) {
        delegate.setFeatureState(featureState);
        replicatedMap.put(featureState.getFeature().name(), featureState.copy());
    }
}
```

[view raw](https://gist.github.com/fatih-iver/7e64fd7e874a06eca2bd5db72e62cf9a/raw/dde5ed60416c4104d66995001c72462866b56a16/HazelcastReplicatedStateRepository.java) [HazelcastReplicatedStateRepository.java](https://gist.github.com/fatih-iver/7e64fd7e874a06eca2bd5db72e62cf9a###file-hazelcastreplicatedstaterepository-java) hosted with ❤ by [GitHub](https://github.com)

---
```java

import com.hazelcast.core.HazelcastInstance;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.togglz.core.manager.EnumBasedFeatureProvider;
import org.togglz.core.repository.StateRepository;
import org.togglz.core.repository.jdbc.JDBCStateRepository;
import org.togglz.core.spi.FeatureProvider;
import org.togglz.core.user.UserProvider;
import org.togglz.core.user.thread.ThreadLocalUserProvider;
import javax.sql.DataSource;

@Configuration
public class TogglzConfiguration {

    @Bean
    FeatureProvider featureProvider() {
        return new EnumBasedFeatureProvider(Feature.class);
    }

    @Bean
    public StateRepository stateRepository(DataSource dataSource, HazelcastInstance hazelcastInstance) {
        return new HazelcastReplicatedStateRepository(
        new JDBCStateRepository(dataSource), hazelcastInstance);
    }

    @Bean
    UserProvider userProvider() {
        return new ThreadLocalUserProvider();
    }
}
```
[view raw](https://gist.github.com/fatih-iver/0dffa96a606163573725bdba08619234/raw/91bc2950fcffd885d03eed88224a3f3fc89a1731/TogglzConfiguration.java) [TogglzConfiguration.java](https://gist.github.com/fatih-iver/0dffa96a606163573725bdba08619234###file-togglzconfiguration-java) hosted with ❤ by [GitHub](https://github.com)

---
# Spring Boot Cache with Hazelcast. Hazelcast is an open-source software

Hazelcast is an open-source software program for data management and distributed computing. It offers a distributed, in-memory data grid that makes it possible to quickly analyze and cache large amounts of data across many servers or nodes. Numerous use cases, including distributed caching, real-time data processing, communications, and distributed computing, can be handled by Hazelcast. Numerous programming languages are supported, and it is written in Java. Hazelcast also provides tools for creating highly scalable and fault-tolerant distributed applications, including distributed locks, transactions, and event listeners.

### When to use Hazelcast?

There are different use cases that you can benefit from using Hazelcast in your solutions. Here are some of the common applications which Hazelcast can offer a competitive solution for:

**Streaming**

![](https://miro.medium.com/v2/resize:fit:866/1*6Vdvp3dFj2sqmoNX9IFyAw.png)

Data in motion is subject to procedures during stream processing. In contrast to batch processing, which treats the entire dataset as a single operation, this procedure often handles one data element at a time or tiny data groupings.

**Real-time analytics**

![](https://miro.medium.com/v2/resize:fit:866/1*Y250d9RbFYt7Oring8AeSA.png)

Hazelcast’s in-memory features can offer notable performance benefits over conventional disk-based databases for applications that need real-time analytics and querying of big datasets.

**Caching and session storage**

![](https://miro.medium.com/v2/resize:fit:866/1*c8arE327QXRujD3l_Valnw.png)

Hazelcast can eliminate the need to request data from slower data sources like databases by temporarily storing frequently accessed data in memory. This enhances the functionality of the application.

If you are unfamiliar with Spring Boot Cache You can read the following article to learn more about it.

[

### Spring Boot Cache

###### A cache is a high-speed data storage component that is utilized to store data quickly for fast access. The goal is to…

medium.com



](https://medium.com/codex/spring-boot-cache-dd0e2992f9b1?source=post_page-----52e70d76ca37---------------------------------------)

### Getting Start

To begin using cache features in Spring Boot you just need to add the related starter dependency to your pom.xml and most of the work will be done by framework for you.
```xml
<dependency>  
   <groupId>org.springframework.boot</groupId>  
   <artifactId>spring-boot-starter-cache</artifactId>  
</dependency>
```

This will manage all the dependencies required for adding cache to your application and to enable it you can use `@EnableCaching`. You can add it to the main class or managed configuration class like the following example:
```java
@Configuration  
@EnableCaching  
public class ApplicationConfig {  
}
```
Now let’s say we have a simple Service class that reads the data from the database and we want to enable cache for it.
```java
@Cacheable("school")  
public List<School> getSchoolList(){  
  List<School> res = educationRepository.getSchoolList();  
  return  res;  
}
```
Note that in order for your class to be able to be broadcast in the cluster you need to make it Serializable.
```java
public class School implements Serializable {  
    private String id;  
    private String name;  
}
```
The next step is to utilize Hazelcast as our Cache manager.

### 1. Embedded Cache Solution

In this approach, the application and cached data are running on the same node. Hazelcast is responsible for distributing cache entries to the other members when they are written into the cache. The outcome as you can see in the image below is you will have a Hazelcast cluster embedded in each microservice you have.

![](https://miro.medium.com/v2/resize:fit:866/1*tEvApsJN1yqNq2Ub8yWcOQ.png)

For our cache manager, Hazelcast is what we wish to use. The good news is that adding Hazelcast to your classpath is all that’s required.
```xml
<dependency>  
    <groupId>com.hazelcast</groupId>  
    <artifactId>hazelcast-all</artifactId>  
    <version>4.0.2</version>  
</dependency>
```
Now that we have the proper dependency we can do the configuration for the cache manager. This can be done via `hazelcast.yaml` file or programmatically inside the code.
```yml
hazelcast:  
  network:  
    join:  
      multicast:  
        enabled: true
```
Basically, this is all you need and you can start the app and run multiple instances to test id the cluster function as expected. The question you may have is how the Spring Boot application nodes will find each other. Hazelcast enables cluster members to connect via multicast communication thanks to the multicast auto-discovery technique. The cluster members only multicast to all the other members for listening, thus they don’t need to know the specific addresses of the other members. Keep in mind you need to make sure multicasting is accessible in your deployment environment.

After running your microservices you will notice the following logs which means that your embedded cash cluster nodes found each other.
```shell
Members {size:1, ver:1} [  
        Member [192.168.100.80]:5701 - 21dea49d-412d-40ef-a96c-e6a79f83dac8 this  
]

Members {size:2, ver:2} [  
        Member [192.168.100.80]:5701 - 21dea49d-412d-40ef-a96c-e6a79f83dac8 this  
        Member [192.168.100.80]:5702 - 4a1f4a0c-f5da-4bce-a37e-df7a4ce91661  
]
```

### Eureka for cluster discovery

You can build up your service registry if your infrastructure is based on the well-known Spring Cloud environment and you want to benefit from dynamic discovery rather than a static IP setup. So if you have an Eureka Server running you can use that as the discovery service for the Hazelcast cluster.

To Configure Hazelcast to use Eureka you need to disable multicast configuration and enable Eureka discovery in `hazelcast.yaml`
```yaml
hazelcast:  
  network:  
    join:  
      multicast:  
        enabled: false  
      eureka:  
        enabled: true  
        self-registration: true  
        namespace: hazelcast
```
In addition to that you need to add `eureka-client.properties` to register as a cluster node in Eureka. In this case, our Eureka is running on the same machine on port 8860.
```java
hazelcast.shouldUseDns=false  
hazelcast.name=hazelcast-ms  
hazelcast.serviceUrl.default=http://localhost:8860/eureka/
```
Now by running the Eureka and microservices, you will see the following logs on running microservices.
```shell
Members {size:1, ver:3} [  
        Member [192.168.100.80]:5701 - 3ba7a513-0046-4386-810b-c5b0a6d0114f this  
]

Members {size:2, ver:4} [  
        Member [192.168.100.80]:5701 - 3ba7a513-0046-4386-810b-c5b0a6d0114f this  
        Member [192.168.100.80]:5702 - f490ccb4-c1a1-4a26-94df-d36278f72eaf  
]
```
Also, you can see the registered nodes in the Eureka web view just like the following example.

![](https://miro.medium.com/v2/resize:fit:866/1*CGqY-9CACNYIgu3j-1JxIw.png)

### 2. Client-Server Mode

In this approach, you will run the Hazelcast cluster separately and applications will connect to the cluster and read and write in the cluster. There are different ways to run a Hazelcast independent cluster based on the OS you are using you can find the prepared packages, docker container or simply run using Java. For more information, you can refer to this [link](https://docs.hazelcast.com/hazelcast/5.3/getting-started/get-started-cli).

![](https://miro.medium.com/v2/resize:fit:866/1*rwqPh_OSCgZ-lg1PiKAYtw.png)

The simple way is to just create a basic Java project with Hazelcast dependency and some configuration.
```xml
<?xml version="1.0" encoding="UTF-8"?>  
<project xmlns="http://maven.apache.org/POM/4.0.0"  
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">  
    <modelVersion>4.0.0</modelVersion>  
  
    <groupId>org.example</groupId>  
    <artifactId>hazelcast</artifactId>  
    <version>0.0.1</version>  
  
    <dependencies>  
        <dependency>  
            <groupId>com.hazelcast</groupId>  
            <artifactId>hazelcast</artifactId>  
            <version>5.3.6</version>  
        </dependency>  
    </dependencies>  
  
    <properties>  
        <maven.compiler.source>17</maven.compiler.source>  
        <maven.compiler.target>17</maven.compiler.target>  
    </properties>  
  
</project>
```
```java
package org.example;  
  
import com.hazelcast.config.Config;  
import com.hazelcast.core.Hazelcast;  
import com.hazelcast.core.HazelcastInstance;  
  
public class HazelcastApplication {  
    public static void main(String[] args) {  
        Config hazConfig = new Config();  
        hazConfig.setClusterName("haz-cluster");  
  
        HazelcastInstance node1 = Hazelcast.newHazelcastInstance(hazConfig);  
        HazelcastInstance node2 = Hazelcast.newHazelcastInstance(hazConfig);  
        HazelcastInstance node3 = Hazelcast.newHazelcastInstance(hazConfig);  
    }  
}
```
After running that Java code you will get logs similar to this:
```shell
Members {size:3, ver:3} [  
 Member [192.168.100.80]:5701 - 381778b4-a23a-4f86-8a8d-f4cd9528c34f  
 Member [192.168.100.80]:5702 - e9181246-b483-40f8-bf1f-17626a27856c  
 Member [192.168.100.80]:5703 - 39d58633-c414-42af-8f95-e78a00303014 this  
]
```

Now that the 3 nodes in the cluster running you can start to connect and use the cluster in your application. Normally by calling `HazelcastClient.newHazelcastClient()` you can connect automatically to the cluster using the multicast auto-discovery technique but there are also configurations that can be done to point to the cluster as required.
```java
@Component  
class CacheClient {  
  
  private HazelcastInstance client = HazelcastClient.newHazelcastClient();  
  
  public School put(String key, School school){  
    IMap<String, School> map = client.getMap("school");  
    return map.putIfAbsent(key, car);  
  }  
  
  public School get(String key){  
    IMap<String, School > map = client.getMap("school");  
    return map.get(key);  
  }  
}
```
# Moving from Hazelcast to Redis. The benefits of a large open source

### Background

Datorama’s platform is constructed from a lot of different services and server types some of which are sharing data with the others by using a common data store.

This data store holds many types of data structures such as Queues, Maps, Multimaps, Locks, Semaphores etc. Some of the services mentioned above requires shared objects.

### A Few Use Cases

Datorama has an advanced patent pending ETL technology that processes hundreds of millions of rows per minute. These messages come from multiple sources and every message is offered into a unique message queue.  
This queue must remain consistent across the system, otherwise a message might be consumed multiple times or not at all.

Moreover, sometimes we want to restrict the number of messages being processed in parallel (for example: increase/limit processing power per client). In such cases, we will use lock objects or semaphore objects. The locking objects also must be unique across the entire system. In order to achieve this system-wide uniqueness, we use a centralized data store.

Till now, **Hazelcast** was our centralized data store technology.

### The Motivation for replacing Hazelcast

We found ourselves, time and time again, managing Hazelcast in our production environment.

![](https://miro.medium.com/v2/resize:fit:500/1*PsJGw3FidQfiyCbJhq6pw.png)

When I say managing, I mean that we experienced lots of disconnections so it was very demanding in terms of operation.  
Due to fact that Hazelcast was not handling big JVM heaps we got a lot of client’s disconnections from the cluster that we had to mitigate using code. Though these incidents were rare.

As part of our 2016 operations plan, we wanted to try and migrate maintained infrastructure into a managed service and were not able to find a managed Hazelcast service. Redis has a managed service on all cloud vendors.

Redis has been an industry standard for several years, proving superiority over existing distributed data store solutions.  
A simple lookup in Google trends visualizes the competition over time.

![](https://miro.medium.com/v2/resize:fit:875/1*zoXjQ0nj53W0xpTw5KC2g.png)

Comparison between Github search results for “Redis” vs “Hazelcast” reinforces Redis’ popularity.

![](https://miro.medium.com/v2/resize:fit:875/1*KJ5MPvkHVY24j9XJM9gg.png)

### Moving to Redis

While working on the design of the migration we knew that we don’t want to be coupled with a specific data store provider. Being decoupled from a specific vendor would allow us to make changes with much less effort in the future.  
Thus, as a first step, we centralized the entire APIs under one interface.

Here’s the code of the main java interface we created:

This concept allowed us throughout the development phase to maintain both Hazelcast and Redis implementations side-by-side while the application context defined the desired provider during application startup.

This design kept us on solid ground. It allowed us to work on the Redis implementation knowing that we can always go back to Hazelcast with zero effort and no risk.

Moreover, this also enabled the R&D department to gradually transition, since some people were in the middle of developing on feature branches and wanted to keep on working with Hazelcast.

### Development Challenges

Hazelcast has the ability to work in embedded mode in a very simple manner. The developer can configure Hazelcast to run within the application’s context so it saves the need to install a Hazelcast cluster that the application will connect to (see [example](https://hazelcast.org/getting-started/)).

Redis does not have this capability, thus, you must connect to a Redis server (remote or local), so sometimes it’s annoying during the development process and requires an installation of a Redis server on developer’s machine.

### Adding near-cache capabilities to Redis

Hazelcast has a useful feature called near-cache. Basically, it allows each application node to hold a local copy of the remote cached object (e.g. Map) without the pain of managing the relationship between the local object and the remote one.

It saves the network latency and the serialization/deserialization processing in read operations. Our application does lots of read operations.

Although Redis is considered a very efficient technology it does not offer this kind of a feature. At a very early stage of our tests, we observed a decline in the application’s performance due to this shortcoming.

Below is a benchmark we run on a set of our most common end-points in order to compare the performance of Hazelcast vs Redis.  
Hazelcast is 5 times faster than Redis in the average case (time is in milliseconds).

![](https://miro.medium.com/v2/resize:fit:875/1*FebHmeGsxw4TfldsO2hGw.png)
Time is in milliseconds

In order to cope with these problems, we had to implement the near-cache capabilities in the infrastructure of our Redis implementation.  
Here comes the [Redisson](http://redisson.org/) part.

### Enter Redisson

[Redisson](http://redisson.org/) is a very handy library that provides distributed Java objects and services on top of Redis.

It supports cluster, AWS Elasticache, Sentinel, master/slave and single connection modes. The Redisson project was created and is being maintained by [Nikita Koksharov](https://github.com/mrniko).

We’ve decided to work with this open source library for a number of reasons:

1.  It has a large set of Java data structures.
2.  It is recommended by Redis.
3.  The project is being maintained on a daily basis.

The most important thing (that we didn’t know in the first place) is that Nikita came through as a highly available project moderator allowing us to collaborate on the implementation of the near-cache capability.

Right after integrating this capability within Datorama we experienced a huge performance improvement. We used this feature for the majority of our maps in order to boost our application’s performance.

Below is a benchmark we ran on the same set of end-points using Redis with the near-cache capabilities. This time, Redis proved to be faster than Hazelcast in the average case. In cases where Hazelcast was still faster, we saw that the difference was negligible considering the fact that we now use a managed service.

![](https://miro.medium.com/v2/resize:fit:875/1*2WbYy1ZyqE5IICiSV8jvBA.png)
Time is in milliseconds

Another challenge was the serialization part. In general, all objects stored in Redis must be serialized/deserialized when they persisted into and loaded from Redis. We chose [kryo](https://github.com/EsotericSoftware/kryo) as our java serialization solution but we experienced lots of issues with the default kryo codec shipped with Redisson. we had to extend the default codec in a manner that would fit all of our object types.

Here’s a code snippet that shows what our current kryo instance looks like:

### Epilogue

Now while we are about a 4 months after the migration and our production environment uses Redis as its centralized managed data store service I can say this:

Invest time in testing! It pays off!

We invested a whole month testing our environment trying to anticipate all kinds of scenarios. But it was worth it! The migration to the production environment was smooth.  
Our production environment remained 100% stable with much less manual operation effort.


```java
public interface IDistributedInstance {

    <K, V> IDistributedMap<K, V> getMap(String name);

    <K, V> IDistributedMap<K, V> getMapWithNearCache(String name);

    <K, V> IDistributedMapWithTTL<K, V> getMapWithTTL(String name);

    <K, V> IDistributedMapWithTTL<K, V> getMapWithTTLAndNearCache(String name);

    <K, V> IDistributedMultiMap<K, V> getMultiMap(String name);

    <K, V> IDistributedMultiMap<K, V> getMultiMapWithNearCache(String name);

    <T> IDistributedQueue<T> getQueue(String name);

    IDistributedSemaphore getSemaphore(String name);

    IDistributedLock getLock(String name);

    <T> IDistributedTopic<T> getTopic(String name);

    IDistributedAtomicLong getAtomicLong(String name);

}
```
[view raw](https://gist.github.com/udikidron/7cf2a3528bb60cf00d0dc38b8102a121/raw/69a32ea4a7f57e9309ed0945e71f6d5dab13cee3/IDistributedInstance.java) [IDistributedInstance.java](https://gist.github.com/udikidron/7cf2a3528bb60cf00d0dc38b8102a121###file-idistributedinstance-java) hosted with ❤ by [GitHub](https://github.com)

---
```java
public class DatoramaRedisKryoCodec extends KryoCodec.KryoPoolImpl {

        public DatoramaRedisKryoCodec(List<Class<?>> classes) {
            super(classes, Runtime.getRuntime().getClass().getClassLoader());
        }

        @Override
        protected Kryo createInstance() {
        final Kryo instance = new KryoReflectionFactorySupport() {
            @Override
            public Serializer<?> getDefaultSerializer(final Class clazz) {
            if (EnumSet.class.isAssignableFrom(clazz)) {
                return new EnumSetSerializer();
            }
            if (EnumMap.class.isAssignableFrom(clazz)) {
                return new EnumMapSerializer();
            }
                return super.getDefaultSerializer(clazz);
            }
        };

        instance.setInstantiatorStrategy(new SerializingInstantiatorStrategy());
        instance.register(new ArrayList<String>().subList(0, 0).getClass(), 
            new SubListSerializers.ArrayListSubListSerializer());
        instance.register(Arrays.asList("").getClass(), 
            new ArraysAsListSerializer());
        instance.register(Collections.EMPTYLIST.getClass(), 
            new DefaultSerializers.CollectionsEmptyListSerializer());
        instance.register(Collections.EMPTYMAP.getClass(), 
            new DefaultSerializers.CollectionsEmptyMapSerializer());
        instance.register(Collections.EMPTYSET.getClass(), 
            new DefaultSerializers.CollectionsEmptySetSerializer());
        instance.register(Collections.singletonList("").getClass(), 
            new DefaultSerializers.CollectionsSingletonListSerializer());
        instance.register(Collections.singleton("").getClass(), 
            new DefaultSerializers.CollectionsSingletonSetSerializer());
        instance.register(Collections.singletonMap("", "").getClass(), 
            new DefaultSerializers.CollectionsSingletonMapSerializer());
        instance.register(GregorianCalendar.class, 
            new GregorianCalendarSerializer());
        instance.register(InvocationHandler.class, 
            new JdkProxySerializer());
        instance.register(PersistentSet.class, 
            new CompatibleFieldSerializer(instance, PersistentSet.class));
        UnmodifiableCollectionsSerializer.registerSerializers(instance);
        SynchronizedCollectionsSerializer.registerSerializers(instance);
        instance.register(DateTime.class,  
            new JodaDateTimeSerializer());
        instance.register(LocalDate.class, new JodaLocalDateSerializer());
        instance.register(LocalDateTime.class, new JodaLocalDateTimeSerializer());
        registerSerializers(instance);
        ImmutableSetSerializer.registerSerializers(instance);
        ImmutableMapSerializer.registerSerializers(instance);
        ImmutableMultimapSerializer.registerSerializers(instance);
        return instance;
    }
}
```

[view raw](https://gist.github.com/udikidron/a88e0315ce0aa3ad5f37dd453b324fcc/raw/5690a6676f28b942971ef710ab002216af3d4e21/DatoramaRedisKryoCodec.java) [DatoramaRedisKryoCodec.java](https://gist.github.com/udikidron/a88e0315ce0aa3ad5f37dd453b324fcc###file-datoramarediskryocodec-java) hosted with ❤ by [GitHub](https://github.com)


# Improving Distributed Caching Performance and Efficiency at Pinterest+

![Black and gray computer motherboard https://unsplash.com/photos/FZpCcPss9to](https://miro.medium.com/v2/resize:fit:800/1*iWSBMFbrF6eNDNmVAXKVaw.jpeg)

[Pinterest’s distributed caching system](https://pin.it/scaling-cache-infrastructure), built on top of open source technologies [memcached](https://github.com/memcached/memcached/) and [mcrouter](https://github.com/facebook/mcrouter), is a critical component of the production infrastructure stack. Pinterest’s cache-as-a-service platform is responsible for driving down application latency across the board, reducing the overall cloud cost footprint, and ensuring adherence to strict sitewide availability targets.

Today, Pinterest’s memcached fleet spans over 5000 EC2 instances across a variety of instance types optimized along compute, memory, and storage dimensions. Collectively, the fleet serves up to ~180 million requests per second and ~220 GB/s of network throughput over a ~460 TB active in-memory and on-disk dataset, partitioned among ~70 distinct clusters.

As a core driver of reduced sitewide latency, the distributed caching tier is subject to stringent performance and latency requirements. Additionally, a key consequence of the sheer size of the fleet is that even small efficiency optimizations have an outsized impact on the total service cost footprint. Several years of operational experience running memcached at scale in production have provided unique insight into practical optimizations for driving improved performance and efficiency across the entire caching stack.

In this article, we will share some context on the observability and performance testing tools that enable optimization exploration work, followed by a deep dive into practical optimizations currently running in our production environment along dimensions of hardware selection strategy, compute efficiency, and networking performance.

![Diagram describing the Pinterest-controlled surface area for performance optimization, including memcached, the Linux kernel, and hardware components like NICs, volatile RAM, and disks.](https://miro.medium.com/v2/resize:fit:875/0*GGwVNRmRCSmKJYgb)

High-level description of the available surface area for performance optimization for memcached running on virtual machines in public cloud environments

All performance optimization efforts start with precise quantitative measurement and a structured, reproducible mechanism for generating workloads for isolated evaluation.

Critical monitoring prerequisites for all the performance evaluation conducted over the years include:

-   Server-side metrics for request throughput, network throughput, resource utilization, and hardware-level parameters (NIC statistics like per-queue packet throughput and EC2 allowance exhaustion, disk response times and in-flight I/O requests, etc.)
-   Client-side metrics for cache request percentile latency, timeout and error rates, and per-server availability (SLIs), as well as top-level application performance indicators like service RPC P99 response time

Pinterest leverages both synthetic load generation and production shadow traffic to evaluate the impact of tuning and optimizations. Historically, synthetic benchmarking has been useful for detecting performance regressions or improvements under maximum load, while shadow traffic evaluation has been more reflective of server resource utilization and overall performance under a real workload at scale.

-   **Synthetic load generation:** memtierbenchmark is an open source tool capable of generating a synthetic load against a memcached cluster with configurable parameters for the number of concurrent clients and threads, read/write ratio, data sizes, and transport mechanism (plaintext or TLS).
-   **Production shadow traffic:** [mcrouter](https://github.com/facebook/mcrouter) is an open source memcache-protocol routing proxy deployed as a client-side sidecar in the Pinterest fleet. It provides building blocks to design transparent shadow traffic routing policies with configurable traffic percentages and source/target cluster(s), allowing for flexible dark traffic experimentation across a variety of workload classes.

Together, these tools permit high-signal performance evaluation with zero or minimal impact to critical-path production traffic.

### Cloud hardware

Distributed caching at Pinterest serves a diverse array of workloads. In general, each class of workload can be categorized along the following high-level dimensions:

-   Throughput (compute)
-   Data volume (memory and/or disk capacity)
-   Data bandwidth (network and compute)
-   Latency requirement (compute)

While memcached can be arbitrarily horizontally scaled in and out to address a particular cluster’s bottleneck, vertically scaling individual hardware dimensions allows for greater cost efficiency for specific workloads. In practice, this entails standardization on a fixed pool of EC2 instance types optimized for each workload class.

**Workload profile:** Moderate throughput, moderate data volume

**EC2 instance family:** [r5](https://aws.amazon.com/ec2/instance-types/r5/)

**Rationale:** r5 family instances offer a vCPU-DRAM ratio that works well for most vanilla cache use cases at Pinterest. This instance type is considered the “baseline” against which others are evaluated.

**Workload profile:** High throughput, low data volume

**EC2 instance family:** [c5](https://aws.amazon.com/ec2/instance-types/c5/)

**Rationale:** c5 family instances are more cost efficient for use cases that would otherwise slot into the r5 type but hold significantly less memory. Maintaining the same vCPU count as its r5 counterpart allows it to serve the same throughput volume at a lower overall cost.

**Workload profile:** High data volume, relaxed latency requirement

**EC2 instance family:** [r5d](https://aws.amazon.com/ec2/instance-types/r5/)

**Rationale:** r5d family instances are functionally equivalent to r5 family instances but with an instance-colocated NVMe SSD used by extstore for secondary storage. r5d is cost efficient for clusters with high data volume such that there are tangible improvements to hit rate as data is written to disk. Due to the slower disk (relative to i3 family instances), higher tail latency is expected.

**Workload profile:** Massive data volume, relaxed latency requirement

**EC2 instance family:** [i3](https://aws.amazon.com/ec2/instance-types/i3/) and [i3en](https://aws.amazon.com/ec2/instance-types/i3en/)

**Rationale:** i3 and i3en family instances ship with a fast and sizable instance-colocated disk, which tangibly increases extstore performance for workloads with a very high ratio of working data on disk relative to DRAM. Additionally, they offer comparable memory capacity to r5 series instances, which reduces extstore thrashing by maintaining a reasonable DRAM to disk usage ratio.

![Pie chart of the distribution of instance types in the Pinterest memcached fleet by instance count. The most popular instance types, r5.xlarge (38.5%), r5.2xlarge (31.5%), and c5.xlarge (12.8%), comprise more than 75% of the fleet.](https://miro.medium.com/v2/resize:fit:796/0*n7exBjEZh9U2B3jt)

EC2 instance type distribution for the Pinterest memcached fleet

In particular, using [extstore](https://github.com/memcached/memcached/wiki/Extstore) to expand storage capacity beyond DRAM into a local NVMe flash disk tier increases per-instance storage efficiency by up to several orders of magnitude, and it reduces the associated cluster cost footprint proportionally. EC2’s storage-optimized instance types provide locally attached solid state drives capable of high random IOPS and R/W throughput, allowing onboarding of extstore use cases with massive data volumes and high request throughput without compromising tail latency.

The introduction of different shapes of storage-optimized EC2 instance types to the fleet (in particular, the lower-tier variants of the i3en instance family containing multiple independent disks per instance) further drives down costs while offering improvements in I/O performance and cost efficiency. Pinterest configures these instances with Linux software RAID at level RAID0 to combine multiple hardware block devices into a single, logical disk for userspace consumption. By striping reads and writes fairly across two disks, RAID0 doubles maximum theoretical I/O throughput with a best-case two-fold reduction in effective disk response time at the cost of a doubled MTTF. This increased hardware performance for extstore at the expense of an increased theoretical failure rate is a highly worthwhile tradeoff. Operating workloads on a public cloud necessitates designing infrastructure to be ephemeral cattle, capable of self-healing in the event of instance failures. A topology control plane for mcrouter automatically and gracefully responds to unexpected changes in server capacity; instance loss is a non-issue.

### Compute

Approximately half of all caching workloads at Pinterest are compute-bound (i.e. purely request throughput-bound). Successful optimizations in compute efficiency translate into the ability to downsize clusters without compromising serving capacity.

More precisely, compute efficiency for memcached is defined as the additional rate of requests that can be serviced by a single instance for each percentage point increase in instance CPU usage, without increasing request latency. In simpler terms, an optimization that improves compute efficiency is one that allows memcached to serve a higher request rate at lower CPU usage, without changing request latency characteristics.

At Pinterest, most workloads (including the distributed cache fleet) run on dedicated EC2 virtual machines. Many historical efficiency improvements stem from optimizations in the hardware layer itself, like migrating to different instance families or upgrading to newer generations of existing instance types. However, operating workloads on dedicated (virtualized) machines offers unique opportunities for optimizations at the hardware-software boundary.

Memcached is somewhat unique among stateful data systems at Pinterest in that it is the exclusive primary workload, with a static set of long-lived worker threads, on every EC2 instance on which it is deployed. This is in contrast to database workloads which might have, for example, multiple colocated processes for decoupled storage and serving layers. To this end, one simple but highly effective optimization is tuning [process scheduling](https://man7.org/linux/man-pages/man7/sched.7.html) in order to request the kernel prioritize CPU time for memcached at the expense of deliberately withholding CPU time from other processes on the host, like monitoring daemons. This involves running memcached under a real-time scheduling policy, SCHEDFIFO, with a high priority — instructing the kernel to, effectively, allow memcached to monopolize the CPU by preempting (and thus deliberately starving) all non-realtime processes whenever a memcached thread becomes runnable.

### $ sudo chrt — — fifo <priority> memcached …

Example invocation of memcached under a SCHEDFIFO real-time scheduling policy

This one-line change, after rollout to all compute-bound clusters, drove client-side P99 latency down by anywhere between 10% and 40%, in addition to eliminating spurious spikes in P99 and P999 latency across the board. Additionally, it afforded the ability to raise the steady-state operation CPU usage ceiling by 20% without introducing latency regressions. Ultimately, this shaved close to 10% off memcached’s total fleet-wide cost footprint.

![Time-series graph with a week-over-week comparison indicating a 20% decrease in client-side P99 cache latency after enabling real-time scheduling.](https://miro.medium.com/v2/resize:fit:875/0*8o0cgOWcaKh9ewaY)

Week-over-week comparison of client-side P99 cache latency for one service while real-time scheduling was rolled out to its corresponding dedicated memcached cluster

![Time-series graph indicating a dramatic reduction in the ratio of time spent by the kernel waiting for execution of memcached after enabling real-time scheduling.](https://miro.medium.com/v2/resize:fit:875/0*ZAxCYdUNWhQtIjVg)

Ratio of time spent by memcached waiting for execution by the kernel versus wall clock time, before and after real-time scheduling was enabled (data is collected from schedstat in the /proc filesystem)

![Time-series graph indicating stabilization of client-side latency on a canary host with real-time scheduling enabled (experiment), relative to the rest of the cluster (control).](https://miro.medium.com/v2/resize:fit:875/0*T4vXvHAbzOiDQd59)

Stabilization of spurious latency spikes after real-time scheduling was enabled on a canary host (red-colored series)

### Networking

There are a few key dimensions when considering networking performance:

-   **Data bandwidth, packet throughput, and TCP connection limits.** EC2 imposes [hard limits](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/monitoring-network-performance-ena.html) on per-instance PPS, aggregate bandwidth, and TCP connections (though only when deployed in a security group with TCP ingress rules). Excess usage beyond these limits is reported by the [Elastic Network Adapter (ENA)](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/enhanced-networking-ena.html) driver and accessible via ethtool. Confusingly, EC2 also expresses total NIC bandwidth capabilities in terms of burst loads rather than steady-state loads, thus requiring some degree of trial-and-error to determine the practical bandwidth ceiling for workloads like memcached with predictable network characteristics.
-   **Connection latency and reliability.** Is there a way to make initial TCP connections to memcached faster and more reliable, especially under burst scenarios where thousands of clients are simultaneously establishing connections?
-   **Overhead associated with transport-layer features like TLS.** Is there a way to reduce the encryption/decryption compute overhead of TLS? Additionally, is there a way to reduce the cost of the initial setup cost (i.e. TLS handshake)?

From a cloud consumer’s perspective, EC2-enforced network limits can and should effectively be considered inherent hardware limitations. Unfortunately, there is no mechanism to work around these limits other than horizontally scaling the fleet to reduce per-instance usage.

In Pinterest’s [caching architecture](https://pin.it/scaling-cache-infrastructure), mcrouter is a universal routing proxy and the single application-facing entry point into the distributed caching tier. Each mcrouter instance (effectively, every individual host in a service cluster) creates a statically sized, long-lived TCP connection pool to every individual memcached server in a cluster. Connection pool sizes are deterministically derived from the number of logical cores available on the host system, typically ranging from 8 to 72 for canonical instance types. This results in upwards of tens of thousands of active established TCP connections per server host, and easily over a million total connections per server cluster — necessitating a strategy for maintaining minimal connection latency and connection reliability at scale.

[TCP Fast Open (TFO)](https://datatracker.ietf.org/doc/html/rfc7413) is a mechanism for reducing the latency overhead of establishing a TCP connection by optimizing away one RTT in an otherwise costly TCP 3WHS (3-way handshake), while also allowing eager transmission of early data during the handshake itself. While originally intended for end users on unreliable home and mobile networks connecting to remote edge servers, TFO has demonstrated tangible improvements in connection reliability in a closed cloud environment as well. Implementing TFO support in memcached reduced average TCP connection durations of successive sessions by ~10%, most prominently in connections established across an Availability Zone boundary.

![Diagram describing the exchanges in a TCP 3-way handshake across subsequent sessions with TFO enabled on both client and server.](https://miro.medium.com/v2/resize:fit:875/0*q8DvrZzLI0F4I0v)

Packets exchanged between client and server during TFO cookie setup and a subsequent TFO-initiated session with early data

Separately, raising the sysctl parameter value for net.core.somaxconn and associated listen backlog size in the userspace [listen(2)](https://man7.org/linux/man-pages/man2/listen.2.html) callsite in memcached improved burst connection availability for high-throughput clusters. Previously, deploying a new memcached binary would cause spikes in ECONNREFUSED server errors caused by exhausted server-side TCP accept queues driven by thundering herds of simultaneous inbound connections from thousands of client mcrouter instances. A more generous listen backlog threshold reduced per-server downtime and fixed the brief but frequent SLO violations whenever a shared tenancy cluster was deployed.

Lastly, TLS plays an important role for in-transit data encryption between memcached and mcrouter, and it is enabled for 100% of cache traffic within Pinterest in order to comply with sitewide authentication, authorization, and auditing policies. Even with hardware-accelerated cryptography, TLS adds non-trivial initial and steady-state overhead, due to a post-connect TLS handshake and application-layer encryption/decryption during network I/O, respectively. TLS session resumption, after implementation in memcached, reduced fleet-wide client-side connection timeout rates by allowing reuse of previously cached TLS sessions. One avenue for tackling steady-state overhead is [kernel TLS](https://www.kernel.org/doc/html/latest/networking/tls.html) (kTLS) — a mechanism to offload the TLS record layer from userspace to the kernel, implemented either in software or offloaded to supported dedicated NIC hardware for completely transparent inline data encryption/decryption. TLS session resumption was upstreamed by Pinterest to memcached and is available in version 1.6.3 onward; kTLS is an ongoing and relatively experimental optimization area.

Infrastructure optimization is a critical objective for Pinterest that ultimately drives a more delightful experience for Pinners while reducing our own cloud cost footprint. We look forward to continuing to explore avenues for improving cache performance and efficiency at all layers of the stack, from application clients and routing proxies to the servers themselves. In the near term, we intend to continue evaluation of software kernel TLS, explore compatibility of memcached with newer generations of EC2 instance types for improved price-to-performance characteristics, and application/proxy-side software optimizations like in-flight compression for improved storage efficiency. We hope to additionally build an end-to-end automated performance regression testing framework to track the impact of these optimizations over time.

Thanks to the entire Storage and Caching team at Pinterest for supporting this work, especially Ankita Girish Wagh and Lianghong Xu.

To learn more about engineering at Pinterest, check out the rest of our [Engineering Blog](https://medium.com/pinterest-engineering), and visit our [Pinterest Labs](https://www.pinterestlabs.com/?utmsource=medium&utmmedium=blog-article-link&utmcampaign=lin-may-12-2022) site. To view and apply to open opportunities, visit our [Careers](https://www.pinterestcareers.com/?utmsource=medium&utmmedium=blog-article-link&utmcampaign=lin-may-12-2022) page

---