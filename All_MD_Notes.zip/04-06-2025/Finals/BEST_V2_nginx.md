# Nginx Server Series — Part 1: Nginx essentials

I’**m creating a multi-part series on Nginx — check out the links to all parts at the bottom of this post.**

### What is Nginx

Think of running a website like throwing a massive event. At first, managing a handful of visitors is easy — you can greet them, answer their questions, and guide them around. But when hundreds (or thousands) show up at once, it becomes overwhelming unless you have someone to efficiently manage the flow and keep things under control.

That’s where **Nginx** steps in. Picture it as a super-organized event manager who handles huge crowds effortlessly, ensuring everyone is served quickly without delays. Designed by **Igor Sysoev in 2004**, Nginx was created to solve a key problem: how to serve many users at once without the performance bottlenecks traditional web servers faced. With its lightweight, non-blocking design, Nginx became the go-to tool for high-traffic websites that needed speed and scalability.

### Features of Nginx

### Web Server

Like any web server, **NGINX receives requests from browsers** and responds by delivering the requested web content. What sets it apart is how efficiently it does this — especially when it comes to **serving static files** such as images, HTML pages, and videos. Its performance in handling these types of content is incredibly fast, making it a top choice for high-speed content delivery.

### Reverse Proxy

**NGINX often sits in front of backend servers**, working as an intermediary that manages incoming traffic. Think of it as a smart traffic controller — it decides which server should handle each request, ensuring the workload is evenly distributed. This setup not only improves performance through **load balancing**, but also adds a layer of **security by shielding your internal servers** from direct internet access.

### Forward Proxy

When **acting as a forward proxy**, NGINX handles requests coming from the client side. However, with **HTTPS traffic**, things get a bit more complex. Since HTTPS encrypts the data using **TLS/SSL**, the proxy server can’t directly see the destination domain name in the URL. This is different from regular HTTP traffic, where the URL is visible. As a result, **special handling is needed when proxying encrypted HTTPS traffic**, often involving techniques like **SSL termination** or **SNI (Server Name Indication)** to properly manage secure connections.

### load balancing

As your website attracts more visitors, relying on just one server can cause performance issues or crashes. **NGINX alleviates this by distributing incoming requests among several servers**, ensuring that no single machine gets overwhelmed. This **load balancing** approach helps maintain smooth and reliable website performance, even when traffic spikes.

### Caching

Rather than rebuilding the same page for every visitor, **NGINX can cache the content** and serve the stored version to multiple users. This not only improves loading speed but also conserves server resources by avoiding redundant processing.

### SSL/TLS termination

One of the most important security measures is encrypting the communication between clients and your servers using SSL/TLS. This ensures that data transmitted over the network is secure and cannot be easily intercepted by attackers.

### Apache vs Nginx

[https://www.digitalocean.com/community/tutorials/apache-vs-nginx-practical-considerations](https://www.digitalocean.com/community/tutorials/apache-vs-nginx-practical-considerations)

[https://medium.com/@tahirbalarabe2/apache-vs-nginx-web-server-and-reverse-proxy-comparison-a481c40e771b](https://medium.com/@tahirbalarabe2/apache-vs-nginx-web-server-and-reverse-proxy-comparison-a481c40e771b)

### Setting Up NGINX

Now that you understand what NGINX is and the various roles it can play, it’s time to get hands-on and set it up as a web server.

![](https://miro.medium.com/v2/resize:fit:875/0*6t5XK-8XHBGJ-Ygv.png)
```shell
sudo apt update

sudo apt install nginx

sudo systemctl start nginx

sudo systemctl enable nginx
```
Check browser

http://localhost

http://publicip

![](https://miro.medium.com/v2/resize:fit:875/1*qmCtoP91j15qGOOnJguClQ.png)

---
# Nginx Server Series — Part 2: Deep Dive into Configuration

### Nginx Configuration Basics

The main configuration file for Nginx is `nginx.conf`. It's typically located in `/etc/nginx/nginx.conf`. Let's break down a simple Nginx configuration file:
```shell
user www-data;  
workerprocesses auto;  
pid /run/nginx.pid;  
include /etc/nginx/modules-enabled/*.conf;  
  
events {  
 workerconnections 768;  
 ### multiaccept on;  
}  
  
http {  
 ###  
 ### Basic Settings  
 ###  
  
 sendfile on;  
 tcpnopush on;  
 typeshashmaxsize 2048;  
 ### servertokens off;  
 ### servernameshashbucketsize 64;  
 ### servernameinredirect off;  
  
 include /etc/nginx/mime.types;  
 defaulttype application/octet-stream;  
 ###  
 ### SSL Settings  
 ###  
  
 sslprotocols TLSv1 TLSv1.1 TLSv1.2 TLSv1.3; ### Dropping SSLv3, ref: POODLE  
 sslpreferserverciphers on;  
 ###  
 ### Logging Settings  
 ###  
  
 accesslog /var/log/nginx/access.log;  
 errorlog /var/log/nginx/error.log;  
 ###  
 ### Gzip Settings  
 ###  
  
 gzip on;  
 ### gzipvary on;  
 ### gzipproxied any;  
 ### gzipcomplevel 6;  
 ### gzipbuffers 16 8k;  
 ### gziphttpversion 1.1;  
 ### gziptypes text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;  
 ###  
 ### Virtual Host Configs  
 ###  
  
 include /etc/nginx/conf.d/*.conf;  
###include /etc/nginx/sites-enabled/*;  
}  
  
  
###mail {  
### ### See sample authentication script at:  
### ### http://wiki.nginx.org/ImapAuthenticateWithApachePhpScript  
###  
### ### authhttp localhost/auth.php;  
### ### pop3capabilities "TOP" "USER";  
### ### imapcapabilities "IMAP4rev1" "UIDPLUS";  
###  
### server {  
###  listen     localhost:110;  
###  protocol   pop3;  
###  proxy      on;  
### }  
###  
### server {  
###  listen     localhost:143;  
###  protocol   imap;  
###  proxy      on;  
### }  
###}
```
### user www-data;
```shell
user www-data;
```
### Specifies the user under which the Nginx worker processes will run. www-data is a standard user for web services on Debian-based systems.

### workerprocesses auto;
```shell
workerprocesses auto;
```
### Sets how many worker processes Nginx should spawn. auto lets Nginx decide based on available CPU cores.

### **pid /run/nginx.pid;**
```shell
pid /run/nginx.pid;
```
### The file where Nginx writes its master process PID. Used for managing the service (e.g., stop/restart).

### **include /etc/nginx/modules-enabled/*.conf;**
```shell
include /etc/nginx/modules-enabled/*.conf;
```
Loads dynamic modules from that directory.

### **events Block**
```shell
events {  
workerconnections 768;  
### multiaccept on;  
}
```
### workerconnections: Max simultaneous connections per worker. This is not per client but per file descriptor.

### multiaccept: If enabled, a worker process will accept all new connections at once instead of one at a time.

### **http Block**

This is the main block that handles web traffic configuration.
```shell
**sendfile on;**
```
Enables zero-copy file transfer. Improves performance by sending files directly from disk to socket.
```shell
**tcpnopush on;**
```
Optimizes packet transmission, especially for sendfile. Sends headers in one packet and the body in another.
```shell
**typeshashmaxsize 2048;**
```
Sets maximum size of the hash table used for storing MIME types.
```shell
**include /etc/nginx/mime.types;**
```
Loads file extension to MIME type mappings.

**defaulttype application/octet-stream;**

Default MIME type if the file type is unknown.

### SSL Settings

**sslprotocols TLSv1 TLSv1.1 TLSv1.2 TLSv1.3;**

Specifies which SSL/TLS protocols to support. TLSv1.0 and 1.1 are deprecated and should be removed for security.

**sslpreferserverciphers on;**

Tells the server to prefer its cipher suite order over the client’s.

### Logging Settings

**accesslog /var/log/nginx/access.log;**

Path to access log (every HTTP request is logged here).

**errorlog /var/log/nginx/error.log;**

Path to the error log.

### Gzip Settings

gzip on;

Enables gzip compression.

**The other gzip* directives (commented out) offer fine-grained control like:**

gziptypes: Which MIME types to compress.

gzipcomplevel: Compression level (1–9).

gzipproxied: Enables gzip for proxied requests.

### **Virtual Host Configs**

**include /etc/nginx/conf.d/*.conf;**

Loads additional configuration files. Typically used for small per-site config.

**###include /etc/nginx/sites-enabled/*;**

(Commented out) Used in Debian/Ubuntu to enable sites with symlinks from sites-available. You can uncomment this if you want to follow the sites-enabled/sites-available pattern.

### mail Block (commented out)

###mail { … }

Used to configure mail proxies (SMTP, POP3, IMAP). Rarely used in modern setups but helpful in legacy enterprise deployments.

### Let’s understand some of the most used blocks of NGINX:

example conf
```shell
server {  
    listen 80;  
    listen [::]:80;  
    servername example.com www.example.com;  
  
    root /var/www/example.com/html;  
    index index.html index.htm;  
  
    ### Logging  
    accesslog /var/log/nginx/exampleaccess.log;  
    errorlog /var/log/nginx/exampleerror.log warn;  
  
    ### Custom error page  
    errorpage 404 /custom404.html;  
    location = /custom404.html {  
        root /var/www/example.com/errors;  
    }  
  
    ### Location block serving static files  
    location /static/ {  
        alias /var/www/example.com/assets/;  
        autoindex on;  
    }  
  
    ### Reverse proxy to Node.js backend  
    location /api/ {  
        proxypass http://localhost:3000/;  
        proxysetheader Host $host;  
        proxysetheader X-Real-IP $remoteaddr;  
        proxysetheader X-Forwarded-For $proxyaddxforwardedfor;  
        proxysetheader X-Forwarded-Proto $scheme;  
    }  
  
    ### PHP backend example (optional)  
    location ~ .php$ {  
        include snippets/fastcgi-php.conf;  
        fastcgipass unix:/run/php/php7.4-fpm.sock;  
    }  
  
    ### Try files strategy  
    location / {  
        tryfiles $uri $uri/ =404;  
    }  
  
    ### Redirect an old page  
    rewrite ^/old-page$ /new-page permanent;  
  
    ### Limit upload size  
    clientmaxbodysize 10M;  
  
    ### Include extra config (e.g. SSL, headers, etc.)  
    include snippets/ssl-params.conf;  
  
    ### Optional: Return redirect  
    location = /redirect-me {  
        return 301 https://example.com/;  
    }  
}
```
### Server block

The server block defines a virtual host. Nginx uses this block to handle requests for a specific domain or IP address.
```shell
server {  
    listen 80;  
    servername example.com www.example.com;  
  
    root /var/www/html;  
    index index.html index.htm;  
  
    location / {  
        tryfiles $uri $uri/ =404;  
    }  
}
```

Directive Breakdown

**listen  
Examples:**

listen 80;                    ### HTTP on all interfaces  
listen 127.0.0.1:8080;        ### Custom port on loopback  
listen [::]:443 ssl http2;    ### IPv6 with SSL and HTTP/2

### **servername**

Defines which domain names this server block responds to.  
Examples:

servername example.com www.example.com;  
servername ;

 is a catch-all value (used for default servers)

### **root**

Sets the directory from which files will be served.  
Examples:

root /var/www/html;

URI /about maps to /var/www/html/about

### **index**

Lists default files to serve if the client requests a directory  
Examples:

index index.html index.htm index.php;

### **errorpage**

Defines custom error pages.  
Examples:

errorpage 404 /404.html;  
location = /404.html {  
    root /var/www/errors;  
}

### **location block**

Defines how requests matching a certain pattern should be handled.  
Examples:

location [modifier] pattern {  
    ### directives  
}

Modifiers:

-   none → prefix match
-   = → exact match
-   ~ → case-sensitive regex
-   ~* → case-insensitive regex
-   ^~ → prefix match with regex exclusion

Examples:
```shell
location /images/ {  
    root /data;  
}  
location ~ .php$ {  
    include fastcgiparams;  
    fastcgipass unix:/run/php/php7.4-fpm.sock;  
}
```

### **tryfiles**

Tries multiple files in order and serves the first found.
```shell
tryfiles $uri $uri/ =404;
```
### **proxypass**

Sends requests to another server (used in reverse proxy setups).
```shell
location /api/ {  
    proxypass http://localhost:3000/;  
    proxysetheader Host $host;  
}
```

### **rewrite**

Used to change request URIs with regular expressions.
```shell
rewrite ^/old-page$ /new-page permanent;
```
### **return**

Returns an HTTP status code or redirects the request.
```shell
return 301 https://$host$requesturi;
```
### **alias**

Similar to root, but replaces the matched location prefix.
```shell
location /static/ {  
    alias /var/www/assets/;  
}
```

/static/js/app.js maps to /var/www/assets/js/app.js

### **accesslog and errorlog**

Custom log paths per server or location.
```shell
accesslog /var/log/nginx/siteaccess.log;  
errorlog /var/log/nginx/siteerror.log warn;
```
### **clientmaxbodysize**

Sets maximum allowed size of a client request body.
```shell
clientmaxbodysize 10M;
```
### **include**

Modularizes your config.
```shell
include /etc/nginx/snippets/ssl-params.conf;
```
https://github.com/parthraj-g0hil/static-website.git
---
# Nginx Server Series — Part 3: Proxy, Load Balancer, Logs, and Troubleshooting

### **Reverse-proxy**

> A reverse proxy acts as an intermediary between the client and the backend server. It receives incoming client requests, passes them to the appropriate backend server, and then delivers the server’s response back to the client. Below is how you can set up Nginx to function as a reverse proxy.

I deployed three separate EC2 instances on AWS for this setup:

1.  **nginx-server** — to act as the reverse proxy
2.  **node-app1** — hosting the first Node.js application
3.  **node-app2** — hosting the second Node.js application

On the **node-app1** server, I created a simple sample Node.js application, which is running on port **3000**.

![](https://miro.medium.com/v2/resize:fit:875/1*PYWikklcMiRubO0UWfMCgg.png)

On the **node-app2** server (Server 3), I set up another sample Node.js application, which is running on port **5000**.

![](https://miro.medium.com/v2/resize:fit:875/1*CeD2TCMZCt3mcE0UI8blIQ.png)

On the **nginx-server**, I installed Nginx and created a demo configuration file to set up the reverse proxy.

cd /etc/nginx/conf.d  
vim node-apps.conf

I also secured my domain using **Certbot** with **Let’s Encrypt**, which automatically configured SSL for HTTPS. That’s why my Nginx configuration includes the **port 443** block for handling secure connections.

### Redirect HTTP to HTTPS  
```shell
server {  
    listen 80;  
    servername nginx.parthraj.cloud;  
  
    ### Redirect to HTTPS  
    return 301 https://$host$requesturi;  
}  
  
### HTTPS Reverse Proxy  
server {  
    listen 443 ssl;  
    servername nginx.parthraj.cloud;  
  
    ### SSL Configuration (Managed by Certbot)  
    sslcertificate /etc/letsencrypt/live/nginx.parthraj.cloud/fullchain.pem;  
    sslcertificatekey /etc/letsencrypt/live/nginx.parthraj.cloud/privkey.pem;  
    include /etc/letsencrypt/options-ssl-nginx.conf;  
    ssldhparam /etc/letsencrypt/ssl-dhparams.pem;  
  
    ### Reverse Proxy for /app1  
    location /app1/ {  
        proxypass http://10.192.10.8:3000/;  
        proxysetheader Host $host;  
        proxysetheader X-Real-IP $remoteaddr;  
        proxysetheader X-Forwarded-For $proxyaddxforwardedfor;  
    }  
  
    ### Reverse Proxy for /app2  
    location /app2/ {  
        proxypass http://10.192.10.15:5000/;  
        proxysetheader Host $host;  
        proxysetheader X-Real-IP $remoteaddr;  
        proxysetheader X-Forwarded-For $proxyaddxforwardedfor;  
    }  
}
```
```shell
reload nginx

nginx -t  
systemctl reload nginx 
```

### Load balancing

> Nginx can efficiently distribute incoming traffic across multiple backend servers, helping to balance the load and improve reliability.

In this setup, I created **two Node.js applications** on the same server, both managed using **PM2**, a production process manager for Node.js.

-   **node-app1** runs on port **3000**
-   **node-app2** runs on port **3001**

![](https://miro.medium.com/v2/resize:fit:875/1*cXP0XsimT2DhMbYEMPGKvQ.png)

this is my nginx conf for load-balancing

### Redirect HTTP to HTTPS  
```shell
server {  
    listen 80;  
    servername nginx.parthraj.cloud;  
    return 301 https://$host$requesturi;  
}  
  
### Define Load Balancer  
upstream nodeapps {  
    server 127.0.0.1:3000;  
    server 127.0.0.1:3001;  
}  
  
### HTTPS Reverse Proxy with Load Balancing  
server {  
    listen 443 ssl;  
    servername nginx.parthraj.cloud;  
  
    sslcertificate /etc/letsencrypt/live/nginx.parthraj.cloud/fullchain.pem;  
    sslcertificatekey /etc/letsencrypt/live/nginx.parthraj.cloud/privkey.pem;  
    include /etc/letsencrypt/options-ssl-nginx.conf;  
    ssldhparam /etc/letsencrypt/ssl-dhparams.pem;  
  
    location /app/ {  
        proxypass http://nodeapps;  
        proxysetheader Host $host;  
        proxysetheader X-Real-IP $remoteaddr;  
        proxysetheader X-Forwarded-For $proxyaddxforwardedfor;  
    }  
}
```
```shell
Reload Nginx

sudo nginx -t  
sudo systemctl reload nginx
```
![](https://miro.medium.com/v2/resize:fit:873/1*s0JtLblTcm6Ra5cSf3L5qw.gif)

### Custom access log

Add a `logformat` directive in the `http` **block** of your configuration.
```shell
logformat extended '$remoteaddr - $remoteuser [$timelocal] '  
                '"$request" $status $bodybytessent '  
                '"$httpreferer" "$httpuseragent" '  
                'Request Time: $requesttime '  
                'Upstream Time: $upstreamresponsetime';
```
![](https://miro.medium.com/v2/resize:fit:875/1*ZvRwcBv9OxIVhKh4APCQmw.png)

then you have to add in your **custom .conf**

In your `server` block (or `location` block), specify the log file and format name:
```shell
    accesslog /var/log/nginx/demo-access.log jsonlog;  
    errorlog /var/log/nginx/demo-error.log;
```
![](https://miro.medium.com/v2/resize:fit:875/1*4vLIeoUsRa0ogi1PIlabYw.png)

**Check the logs now**

![](https://miro.medium.com/v2/resize:fit:875/1*GCtuQn3NxnEkoTSm1dSbQ.png)

### Monitoring

Monitoring Nginx with Tools

Monitoring your Nginx server allows you to gain real-time insights into its performance and detect issues before they escalate.

**Use** `**ngxtop**` **for Real-Time Monitoring:**

ngxtop is a command-line tool that parses NGINX access logs and provides real-time metrics on your server’s performance.

Install `ngxtop` using pip:
```shell
pip install ngxtop
```
Run `ngxtop` to start monitoring:

ngxtop

`ngxtop` will display real-time statistics, such as request counts, response times, and status codes.

![](https://miro.medium.com/v2/resize:fit:875/1*QkV7dalvbRbgLimNGQeqDA.png)

**Integrate with Monitoring Services**

For more comprehensive monitoring, consider integrating NGINX with monitoring services like Prometheus, Grafana, or Datadog

These tools can collect metrics from NGINX, visualize them in dashboards, and alert you to any issues

### Custom grep command
```shell
tail -n 500 -f /var/log/apache2/access.log | grep -E " (400|401|402|403|404|500|501|502|503|504|506) "
```
### Common errors

### `502 Bad Gateway`

**Cause**:

-   Upstream server (e.g., PHP-FPM, Node.js, or another proxy) is down or misconfigured.
-   Firewall blocking communication with upstream servers.

### `404 Not Found`

**Cause**:

-   Incorrect `root` or `alias` directory paths.
-   Missing files or incorrect permissions.

### `403 Forbidden`

**Cause**:

-   NGINX lacks read permissions for files/directories.
-   Directory index is disabled (no `index` file).

### `500 Internal Server Error`

**Cause**:

-   Syntax errors in NGINX config files.
-   Missing modules (e.g., PHP-FPM not installed).

### `SSL/TLS Errors`

-   Expired or self-signed SSL certificates.
-   Misconfigured SSL protocols.nginx.parthraj.cloud

### `Permission Denied` (Error Logs)

**Cause**:

-   NGINX runs as a user (e.g., `www-data`) without access to files.
-   SELinux/AppArmor blocking access.
---
### Nginx Server Series — Part 4: Securing Your Web Server

### Implementing Rate Limiting

Add to `nginx.conf` (HTTP block):
```shell
limitreqzone $binaryremoteaddr zone=reqlimit:10m rate=100r/m;  
limitconnzone $binaryremoteaddr zone=connlimit:10m;

Apply to specific routes in conf

location /app1 {  
    limitreq zone=reqlimit burst=5;  
    limitconn connlimit 10;  
}
```

**Send multiple requests** to test the limit:
```shell
siege -c 150 -t 1m http://yourdomain.com/login
```
**Check logs** for `503 Service Temporarily Unavailable` errors:
```shell
tail -f /var/log/nginx/access.log | grep 503
```
### Prevent Clickjacking

for Block malicious iframe embedding.

add Add the `X-Frame-Options` header to your server block
```shell
addheader X-Frame-Options "SAMEORIGIN" always;
```
check
```shell
curl -I https://nginx.parthraj.cloud | grep -i "X-Frame-Options"
```

### Security Headers

Mitigate XSS, MIME sniffing, and other attacks.  
Add these headers to your server block
```shell
addheader Strict-Transport-Security "max-age=31536000; includeSubDomains" always;  
addheader X-Content-Type-Options "nosniff" always;  
addheader X-XSS-Protection "1; mode=block" always;  
addheader Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline'; img-src 'self' data:";  
addheader Referrer-Policy "strict-origin-when-cross-origin";
```
to check
```shell
curl -I https://yourdomain.com
```
![](https://miro.medium.com/v2/resize:fit:875/1*dvJw1JNnwcgksrEs8R2YcA.png)

### Hide NGINX Version and Server Tokens

In `nginx.conf`
```shell
servertokens off;
```
Verify the `Server` header does not show the version:
```shell
curl -I http://yourdomain.com | grep "Server"
```
![](https://miro.medium.com/v2/resize:fit:875/1*6M5CAkMb86vfL869kM5qww.png)

![](https://miro.medium.com/v2/resize:fit:875/1*fncLygoK3--wmDgiDuCmEA.jpeg)

### Configure SSL/TLS Properly

Use modern protocols and ciphers in your server block:
```shell
sslprotocols TLSv1.2 TLSv1.3;  
sslciphers 'ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256';  
sslpreferserverciphers on;  
sslsessioncache shared:SSL:10m;  
sslsessiontimeout 1d;
```
Use **SSL Labs** for a detailed report

![](https://miro.medium.com/v2/resize:fit:875/1*k1wOU4JzaViGeNfWt9IxEA.png)

###### Use a Web Application Firewall (WAF)

Block SQLi, XSS, and OWASP Top 10 attacks

### Restrict Access with IP Whitelisting
```shell
    ### Reverse Proxy   
    location /app1/ {  
        allow 43.250.165.222/32;  ### Your trusted IP(s)  
        deny all;
```
**check with switching networks.**

### Protect Sensitive Files
```shell
Block access to secrets like `.env` or `.git`.

location ~* (.git|.env|.htaccess|.bak|.sql)$ {  
    deny all;  
    return 403;  
}
```
# Nginx Server Series — Part 5: Performance Tuning and Optimization

### Configure the Number of Worker Processes

The `workerprocesses` directive in the Nginx configuration specifies how many worker processes to start. Ideally, this matches the number of CPU cores.

The `workerconnections` directive controls how many simultaneous connections a worker process can handle

Edit the `nginx.conf` file:
```shell
workerprocesses auto;  ### Automatically sets workers = CPU cores  
events {  
    workerconnections 1024;  ### Connections per worker  
}
```
-   The `auto` setting automatically adjusts to the number of CPU cores.
-   When `workerprocesses` set to 4 and `workerconnections` set to 1024, NGINX can handle up to **4,096 simultaneous connections**.

### Enable Caching for Static Content

Reduce server load and speed up content delivery.
```shell
http {  
    proxycachepath /var/cache/nginx levels=1:2 keyszone=staticcache:10m maxsize=1g inactive=60m;  
      
    server {  
        location ~* .(jpg|jpeg|png|css|js|ico)$ {  
            expires 30d;  ### Browser cache  
            addheader Cache-Control "public, no-transform";  
            proxycache staticcache;  ### Server-side cache  
            proxycachevalid 200 302 10m;  
        }  
    }  
}
```
to check
```shell
curl -I http://yourdomain.com/image.jpg
```
![](https://miro.medium.com/v2/resize:fit:875/1*PRdSjFMm3ncDtLAfZJvgA.png)

### Reverse Proxy Caching

> A **reverse proxy cache** temporarily stores content retrieved from the backend server (such as a Node.js app) and serves it directly for repeated requests. This significantly reduces backend load and improves response times.

Before setting up caching, ensure the following:

-   **Nginx** is installed on your server
-   A **Node.js application** is up and running (for example, on port **3000**)
-   A **basic reverse proxy configuration** is already in place (as covered earlier)

Define a Cache Zone in `nginx.conf`
```shell
sudo nano /etc/nginx/nginx.conf
```
Inside the `http { ... }` block, add:
```shell
proxycachepath /var/cache/nginx levels=1:2 keyszone=appcache:10m maxsize=100m inactive=60m usetemppath=off;
```
-   `/var/cache/nginx`: Where cached files are stored.
-   `levels=1:2`: Directory depth for organizing cache.
-   `keyszone=appcache:10m`: Shared memory zone named `appcache` with 10MB metadata.
-   `maxsize=100m`: Max cache size.
-   `inactive=60m`: Cache items not used for 60 minutes will be purged.
-   `usetemppath=off`: Better disk performance.

Create Cache Directory and Set Permissions
```shell
sudo mkdir -p /var/cache/nginx  
sudo chown -R www-data:www-data /var/cache/nginx
```
Update Your Nginx Site Configuration
```shell
sudo vim /etc/nginx/conf.d/mysite.conf
```
```shell
### ================================================================  
### HTTP to HTTPS Redirection  
### ================================================================  

server {  
    listen 80;  
    servername nginx.parthraj.cloud;  
### Redirect all HTTP requests to HTTPS  
    return 301 https://$host$requesturi;  
}  
### ================================================================  
### HTTPS Reverse Proxy Server with Caching  
### ================================================================  
server {  
    listen 443 ssl;  
    servername nginx.parthraj.cloud;  
    ### SSL Configuration  
    sslcertificate /etc/letsencrypt/live/nginx.parthraj.cloud/fullchain.pem;  
    sslcertificatekey /etc/letsencrypt/live/nginx.parthraj.cloud/privkey.pem;  
    include /etc/letsencrypt/options-ssl-nginx.conf;  
    ssldhparam /etc/letsencrypt/ssl-dhparams.pem;  
    ### Static Site Root (Optional: if you serve any static files)  
    root /var/www/mysite;  
    index index.html;  
    ### Static file serving  
    location / {  
        tryfiles $uri $uri/ =404;  
    }  
    ### Reverse Proxy for Node.js App on Port 3000 with Caching  
    location /app/ {  
        proxypass http://127.0.0.1:3000/;  
        ### Caching settings  
        proxycache appcache;  
        proxycachevalid 200 302 10m;    ### Cache successful and redirected responses for 10 mins  
        proxycachevalid 404 1m;         ### Cache not found errors for 1 min  
        proxycacheusestale error timeout updating;  ### Serve stale content if backend fails  
        ### Forward client headers  
        proxysetheader Host $host;  
        proxysetheader X-Real-IP $remoteaddr;  
        proxysetheader X-Forwarded-For $proxyaddxforwardedfor;  
        proxysetheader X-Forwarded-Proto $scheme;  
        ### Optional: Add cache hit/miss status in response headers  
        addheader X-Cache-Status $upstreamcachestatus;  
    }  
}
```
Test and Restart Nginx
```shell
sudo nginx -t  
sudo systemctl restart nginx
```
Test the Cache
```shell
curl -I https://nginx.parthraj.cloud/app/
```
![](https://miro.medium.com/v2/resize:fit:875/1*6TZ2tJ8vvZPalud9Gemweg.png)

### Enable Gzip Compression

Nginx can gzip responses before sending them to clients.  
Compression reduces the size of HTTP responses, saving bandwidth and speeding up delivery.
```shell
http {  
    gzip on;  
    gziptypes text/plain text/css application/json application/javascript text/xml;  
    gzipminlength 1024;  
    gzipproxied any;  
    gzipcomplevel 6;  
}
```
![](https://miro.medium.com/v2/resize:fit:875/1*VkhpqfCogBgGBg50sgRovw.png)

### Keep-Alive Connections

Enabling keep-alive connections allows multiple requests to be served over a single TCP connection. This reduces the overhead of establishing new connections for each request:
```shell
http {  
    keepalivetimeout 65;  ### Timeout in seconds  
    keepaliverequests 100;  ### Max requests per connection  
}
```
This configuration sets a 65-second timeout for keep-alive connections and allows up to 100 requests per connection.

**How to Check**:
```shell
curl -I http://yourdomain.com | grep -i "Keep-Alive"
```
![](https://miro.medium.com/v2/resize:fit:875/1*q2ceMJoYI1g9UHOra7aqtg.png)

### Prevent Buffer Overflow Attacks

For high-traffic sites, tuning buffer settings can prevent slow clients from affecting performance. Prevent buffer overflow attacks and optimize memory usage.

Enable output buffering (`outputbuffering on;`) in the Nginx configuration to reduce the number of write operations to clients.

Add buffer limits to `nginx.conf`
```shell
http {  
    clientbodybuffersize 10K;  
    clientheaderbuffersize 1k;  
    clientmaxbodysize 8m;  ### Adjust based on your needs  
    largeclientheaderbuffers 4 8k;  
}
```
**Test with a large request**:
```shell
dd if=/dev/zero bs=9M count=1 | curl -X POST --data-binary @- http://yourdomain.com
```
**Expected Result**:

If `clientmaxbodysize` is set to `8m`, this should return `413 Request Entity Too Large`

### Conclusion

Throughout this Nginx Server Series, we’ve journeyed from the foundational essentials to advanced topics such as proxying, load balancing, security, and performance tuning. Whether you’re setting up a simple web server or architecting a robust, high-availability infrastructure, Nginx offers the flexibility, scalability, and power to meet your needs.

By mastering Nginx’s core concepts, configurations, security best practices, and optimization techniques, you’re now well-equipped to build and maintain efficient, secure, and high-performing web servers.

Remember, Nginx is continuously evolving, and staying updated with the latest features and security improvements is key to leveraging its full potential. Keep experimenting, exploring, and fine-tuning your setups.

Thank you for following along this series — I hope it empowered you to confidently manage your Nginx environments and scale your web applications with ease. Happy hosting!

---

# NGINX — Zero To Hero: Your Ultimate Guide from Beginner to Advanced Mastery

NGINX has become popular in modern web infrastructure. Renowned for its high performance, scalability, and low resource usage, **NGINX serves as a web server, reverse proxy,** and **load balancer**. Initially released in **2004**, NGINX now powers a significant portion of the internet, outperforming traditional web servers like Apache in key metrics.

Whether you’re a developer or a system administrator, mastering NGINX is essential to building robust and efficient web applications.

### Understanding NGINX: The Foundation

**NGINX is an open-source software** that stands out due to its event-driven, asynchronous architecture. This design allows it to handle thousands of connections simultaneously, making it ideal for handling high traffic with minimal hardware resources.

Key Features:

-   **Web Server**: Serves static and dynamic content efficiently.
-   **Reverse Proxy**: Protects and optimizes backend servers.
-   **Load Balancer**: Distributes traffic intelligently across multiple servers.
-   **HTTP Caching**: Speeds up content delivery.

Its versatility, combined with a straightforward configuration system, makes NGINX a favorite among DevOps professionals.

### Getting Started with NGINX

### Installation

To begin, you’ll need to install NGINX on your system. Here’s how to do it on popular platforms:

**For Ubuntu/Debian:**
```shell
sudo apt update    
sudo apt install nginx
```
**For CentOS/RHEL:**
```shell
sudo yum install epel-release    
sudo yum install nginx
```
**For Windows:**  
Download the pre-compiled binaries from the [official NGINX website](https://nginx.org/).

### Basic Commands

Once installed, control NGINX with these essential commands:

-   Start: `sudo systemctl start nginx`
-   Stop: `sudo systemctl stop nginx`
-   Restart: `sudo systemctl restart nginx`
-   Check Status: `sudo systemctl status nginx`

### Configuring Your First NGINX Server

To serve your first static website, follow these steps:

-   **Create the Directory Structure**:
```shell
sudo mkdir -p /var/www/example.com/html    
sudo chmod -R 755 /var/www/example.com
```
-   **Add a Simple HTML Page:**
```shell
echo "<h1>Welcome to NGINX</h1>" | sudo tee /var/www/example.com/html/index.html
```
-   **Update the Configuration File**:  
    Edit `/etc/nginx/sites-available/example.com`:
```shell
server {    
    listen 80;    
    servername example.com www.example.com;    
    root /var/www/example.com/html;    
    index index.html;    
}
```
-   **Enable the Site and Reload NGINX**:
```shell
sudo ln -s /etc/nginx/sites-available/example.com /etc/nginx/sites-enabled/    
sudo nginx -t    
sudo systemctl reload nginx
```
Visit `http://your-server-ip/` in a browser to see your website live!

### Diving Deeper: Reverse Proxy and Load Balancing

### Configuring a Reverse Proxy

A reverse proxy forwards client requests to backend servers. Add this configuration to your `server` block:
```shell
location / {    
    proxypass http://127.0.0.1:8080;    
    proxysetheader Host $host;    
    proxysetheader X-Real-IP $remoteaddr;    
}
```
### Load Balancing Configuration

Distribute traffic across servers using this example:
```shell
upstream backend {    
    server server1.example.com;    
    server server2.example.com;    
}    
    
server {    
    listen 80;    
    location / {    
        proxypass http://backend;    
    }    
}
```
You can switch between load balancing methods such as round-robin, least connections, and IP hash by updating the `upstream` block.

### Advanced Mastery: Security and Optimization

### Enabling HTTPS

Secure your site with Let’s Encrypt:

sudo apt install certbot python3-certbot-nginx    
sudo certbot --nginx -d example.com -d www.example.com

### Rate Limiting

Prevent DDoS attacks with rate limiting:
```shell
http {    
    limitreqzone $binaryremoteaddr zone=one:10m rate=5r/s;    
    
    server {    
        location / {    
            limitreq zone=one;    
        }    
    }    
}

```
### Caching for Performance

Enable caching to speed up your site:
```shell
location / {    
    proxycachepath /var/cache/nginx levels=1:2 keyszone=mycache:10m;    
    proxycache mycache;    
    proxypass http://backend;    
}
```
### Troubleshooting and Debugging NGINX

If issues arise, start with these common tools:

### **Logs**

-   Access logs: `/var/log/nginx/access.log`
-   Error logs: `/var/log/nginx/error.log`

### **Test Configurations**
```shell
sudo nginx -t
```
### **Debug with Curl**
```shell
curl -I http://your-server-ip/
```
### Conclusion: Becoming an NGINX Expert

From installation to advanced configurations, this guide equips you with the foundational and advanced knowledge needed to master NGINX. To deepen your expertise, explore the [official documentation](https://nginx.org/), experiment with real-world scenarios, and engage with the thriving NGINX community.

Master NGINX today, and unlock the power of high-performance web servers!
---
# Nginx as Reverse Proxy in Microservices 

Developers might find topics related to DevOps quite annoying, but once you master this skill, and you can be invincible. Just like we cannot skip Docker, let’s challenge Nginx heads on.

Setting up Nginx as a reserve proxy might not be that troublesome as you expect. Check below the `nginx.conf` file:

![](https://miro.medium.com/v2/resize:fit:875/1*M7LfdDCylXW8oq4N-Qhy4w.png)

It’s quite easy to understand above code. The server listens on port 8080 and proxies requests to various upstream servers based on the URL path.

### What is an upstream server?

In the context of a reverse proxy server, an upstream server is a server that the reverse proxy forwards requests to. The upstream server can be any server that can handle the request, such as a web server, application server, or microservice.

In the Nginx configuration file, the “upstream” section defines the upstream servers that the reverse proxy will forward requests to. Each upstream server is defined with a “server” directive that specifies the server’s hostname and port number. For example, the “upstream docker-baskets” directive defines an upstream server named “docker-baskets” that listens on port 8080.

When a request comes in to the reverse proxy server, the server determines which upstream server to forward the request to based on the URL path. This is typically done using the “location” directive in the Nginx configuration file. For example, the “location /api/baskets” directive proxies requests with the “/api/baskets” URL path prefix to the “docker-baskets” upstream server.

This means that when a client sends a request to the reverse proxy server with a URL path that starts with “/api/baskets”, the reverse proxy server will forward the request to the “docker-baskets” upstream server. The upstream server will then handle the request and send the response back to the reverse proxy server, which will forward the response back to the client.

Check how the API is handled:

![](https://miro.medium.com/v2/resize:fit:875/1*ctnwpwxH3h3IE2fhHVZyEA.png)

I used Swagger UI to make api calls.

### What the Nginx file means?

The “upstream” section defines the upstream servers that the reverse proxy will forward requests to. Each upstream server is defined with a “server” directive that specifies the server’s hostname and port number.

The “server” section defines the reverse proxy server itself. It listens on port 8080 and has multiple “location” directives that define how to proxy requests based on the URL path. Each “location” directive specifies a URL path prefix and the upstream server to forward requests to using the “proxypass” directive.

For example, the “location /api/baskets” directive proxies requests with the “/api/baskets” URL path prefix to the “docker-baskets” upstream server. Similarly, the “location /baskets-spec/” directive proxies requests with the “/baskets-spec/” URL path prefix to the “docker-baskets” upstream server.

The “location /” directive is a catch-all that proxies all other requests to the “docker-baskets” upstream server.

Overall, this configuration file allows the reverse proxy server to route requests to different microservices based on the URL path, making it easier to manage and scale a microservices-based application.

### How to use the Nginx Reverse Proxy?

Below is my `docker-compose.yml` file that specified nginx:

![](https://miro.medium.com/v2/resize:fit:875/1*awkcAmHdRornOuNEHvo79A.png)

Docker Compose file that defines a service named “reverse-proxy” which uses the “nginxproxy/nginx-proxy:alpine” image to create a container named “proxy”. The container is configured to listen on port 8080 and map it to the host’s port 8080.

The “volumes” section is used to mount files or directories from the host machine to the container. In this case, it mounts the “nginx.conf” file from the host machine to the container’s “/etc/nginx/nginx.conf” directory. This allows the container to use the custom Nginx configuration file instead of the default one.

The second volume “- /var/run/docker.sock:/tmp/docker.sock:ro” is used to mount the Docker socket file from the host machine to the container’s “/tmp/docker.sock” directory. This allows the container to communicate with the Docker daemon running on the host machine. The “:ro” at the end of the volume definition specifies that the Docker socket file is mounted in read-only mode.

The “profiles” section is used to assign the “microservices” profile to the “reverse-proxy” service. Profiles are used to group services together and apply common configuration to them. In this case, the “microservices” profile may contain additional configuration that applies to all services in the group.

That’s it, Nginx is no big deal. Don’t be bothered by this config file, that’s all we need to know about how to use it!

### Intelli-Mall/docker/nginx.conf at main · LordMoMA/Intelli-Mall
https://github.com/LordMoMA/Intelli-Mall/blob/main/docker/nginx.conf

---
# Using NGINX as API Gateway
Hi everyone!

If you ever need to deploy a reverse proxy, you may have heard of NGINX (engine x). In case you haven’t heard it yet, let’s talk a little about it here and how we can use it as an API Gateway.

### What is NGINX?

NGINX is an HTTP server and reverse proxy, a mail proxy server, and a generic TCP/UDP proxy server.

According to Netcraft, NGINX served or proxied [21.67% of the busiest sites in May 2022](https://news.netcraft.com/archives/2022/05/30/may-2022-web-server-survey.html).

Currently, NGINX has an open-source and commercial versions (NGINX Plus). In this post, we will try to use some of the features of the free version but also available in the paid version.

### What is an API Gateway?

An API Gateway is a traffic manager that allows developers to create, publish, maintain, monitor, and secure APIs. In resume, it interfaces between external traffic and backend services.

Using an API Gateway has several advantages, such as:

-   Make APIs more secure through a single interface.
-   Enable you to more easily enforce access control policies, rate limits, routing, mediation, etc.
-   Enables the most comprehensive collection of metrics

That said, let’s put some concepts into practice!

### What do we want?

Let’s say we have two APIs: a for products, which we call the **Products API**, and another for users, which we call the **Users API**. Initially, we will publish our APIs. Our architecture diagram starts like this:

![](https://miro.medium.com/v2/resize:fit:709/0*YLrkNAkCbMa33rz5.png)

We want to create the following routes:

-   `/api/products` -> should point to the Products API service
-   `/api/users` -> should point to the Users API service

A relevant feature in our settings is that we don’t want to expose our services publicly. Therefore, our only gateway should be the NGINX which we call API Gateway in the diagram above.

To simulate our API, we built two simple Python applications with fixed responses ([Products API](https://github.com/marcospereirampj/nginx-api-gateway/tree/master/backends/products) and [Users API](https://github.com/marcospereirampj/nginx-api-gateway/tree/master/backends/users)).

For that, let’s create a simple rule in our NGINX configuration file (`gateway.conf`):
```shell
server {  
   listen 80 defaultserver;  
   listen [::]:80 defaultserver;  
   
   ###  
   ### Products API  
   ###  
   location /api/products {  
       proxypass http://productsapi:8001;  
   }  
   
   ###  
   ### Users API  
   ###  
   location /api/users {  
       proxypass http://usersapi:8002;  
   }  
}
```
In the configuration above, notice that I created an alias for the API containers (see `docker-compose.yml` - contains spoilers).

So, the expected answers are:
```shell
GET http://localhost/api/products  
{  
  "name": "Product 1",  
  "description": "Detail about product 1"  
}

GET http://localhost/api/users  
{  
  "name": "User 1",  
  "email": "email@email.com"  
}
```
In this way, we have NGINX serving as a reverse proxy. To improve the organization of our configurations we will define `upstream` for our API instead of directly using their address (alias). So we will have:
```shell
upstream productsapiserver {  
       server productsapi:8001;  
}  
   
upstream usersapiserver {  
       server usersapi:8002;  
}
```
And after:
```shell
server {  
   listen 80 defaultserver;  
   listen [::]:80 defaultserver;  
  
   ###  
   ### Products API  
   ###  
   location /api/products {  
       proxypass http://productsapiserver;  
   }  
   
   ###  
   ### Users API  
   ###  
   location /api/users {  
       proxypass http://usersapiserver;  
   }  
}
```
The `upstream` (`ngxhttpupstreammodule`) is used to define groups of servers that can be referenced by the `proxypass`, `fastcgipass`, `uwsgipass`, `scgipass`, `memcachedpass`, and `grpcpass directives`.

After applying our basic settings, let’s increment the Gateway.

### Load Balance

In the next scenario, let’s assume that our Users API got overloaded and we decided to add a new instance (`usersapibalance`) to receive requests from end-users.

![](https://miro.medium.com/v2/resize:fit:811/0*P7o7QF6zokAHqiOf.png)

We will configure our API Gateway to do this balancing. For that, we’ll add the new server to the Users API server group.
```shell
upstream productsapiserver {  
       server productsapi:8001;  
}  
   
upstream usersapiserver {  
       server usersapi:8002;  
       server usersapibalance:8002;  
}
```
Through the container logs, you can see that the requests are distributed among the servers.

api-gateway-nginx    | 172.18.0.1 - - [07/Jul/2022:22:52:49 +0000] "GET /api/users HTTP/1.1" 200 46  
containerusersapi  | 172.18.0.5 - - [07/Jul/2022 22:52:49] "GET /api/users HTTP/1.0" 200  
api-gateway-nginx    | 172.18.0.1 - - [07/Jul/2022:22:52:49 +0000] "GET /api/users HTTP/1.1" 200 46  
containerusersapibalance | 172.18.0.5 - - [07/Jul/2022 22:52:50] "GET /api/users HTTP/1.0" 200

With these settings, the requests are distributed evenly (Round Robin) between servers. But how about we evolve our balancing rules? Now let’s define that we should direct the new request to the server with the lowest number of active connections. Again, we will only modify the Users API server group by passing the desired balancing method. In our case, it will be the `leastconn`.
```shell
upstream productsapiserver {  
       server productsapi:8001;  
}  
   
upstream usersapiserver {  
leastconn;  
       server usersapi:8002;  
       server usersapibalance:8002;  
}
```
We’ll use this setup for now, but NGINX has a few other balancing methods:

-   iphash:
-   Generic Hash
-   Random
-   Last Time (NGINX Plus only)

More details are in the [official documentation](https://docs.nginx.com/nginx/admin-guide/load-balancer/http-load-balancer/).

However, let’s assume that the `usersapi` server has a better infrastructure, and we want to prioritize requests to this server. We can do this through the `weight` parameter.
```shell
upstream productsapiserver {  
       server productsapi:8001;  
}  
   
upstream usersapiserver {  
leastconn;  
       server usersapi:8002 weight=5;  
       server usersapibalance:8002;  
}
```
With that, the `usersapi` server has a priority five times higher than the other servers.

### Cache

In this scenario, let’s assume that the Products API is not volatile, and we want to optimize for response time. For this, we will add a basic cache in API Gateway,

Only two directives are needed to enable basic caching: `proxycachepath` and `proxycache`. The `proxycachepath` directive sets the path and configuration of the cache and the `proxycache` directive activates it.
```shell
upstream productsapiserver {  
       server productsapi:8001;  
}  
   
upstream usersapiserver {  
       iphash;  
       server usersapi:8002;  
       server usersapibalance:8002;  
}  
   
   
proxycachepath /tmp/products levels=1:2 keyszone=productscache:10m maxsize=10g inactive=60m usetemppath=off;  
   
server {  
   listen 80 defaultserver;  
   listen [::]:80 defaultserver;  
   
   ###  
   ### Products API  
   ###  
   location /api/products {  
       proxycache productscache;  
       proxypass http://productsapiserver;  
   }  
   
   ###  
   ### Users API  
   ###  
   location /api/users {  
       proxypass http://usersapiserver;  
   }  
}
```
The parameters to the `proxycachepath` directive defines the following settings:

-   The local disk directory for the cache is called `/tmp/products`.
-   `levels` sets up a two‑level directory hierarchy under `/tmp/products`. If the `levels` parameter is not included, NGINX puts all files in the same directory.
-   `keyszone` sets up a shared memory zone for storing the cache keys and metadata such as usage timers.
-   `maxsize` sets the upper limit of the size of the cache (to 10 gigabytes in this example). It is optional; not specifying a value allows the cache to grow to use all available disk space.
-   `inactive` specifies how long an item can remain in the cache without being accessed. In this example, a file that has not been requested for 60 minutes is automatically deleted from the cache by the cache manager process, regardless of whether or not it has expired. The default value is 10 minutes (10m).
-   NGINX first writes files that are destined for the cache to a temporary storage area, and the `usetemppath=off` directive instructs NGINX to write them to the same directories where they will be cached.

The default form of the keys that NGINX generates is similar to an MD5 hash of the following NGINX variables: `$scheme$proxyhost$requesturi;` the actual algorithm used is slightly more complicated.

More details on caching can be seen on the NGINX Blog: [A Guide to Caching with NGINX and NGINX Plus.](https://www.nginx.com/blog/nginx-caching-guide/)

### Rate Limit

Having defined our balancing and cache rules, we can now protect our internal services from a large number of requests (DDoS attacks) by setting a rate limit for consumers.

Rate limiting is configured with two main directives, `limitreqzone` and `limitreq`. The `limitreqzone` directive defines the parameters for rate limiting while `limitreq` enables rate limiting within the context where it appears.
```shell
upstream productsapiserver {  
       server productsapi:8001;  
}  
   
upstream usersapiserver {  
       iphash;  
       server usersapi:8002;  
       server usersapibalance:8002;  
}  
   
   
proxycachepath /tmp/products levels=1:2 keyszone=productscache:10m maxsize=10g inactive=60m usetemppath=off;  
limitreqzone $binaryremoteaddr zone=productsrate:10m rate=1r/s;  
limitreqzone $binaryremoteaddr zone=userrate:10m rate=10r/s;  
   
   
server {  
   listen 80 defaultserver;  
   listen [::]:80 defaultserver;  
   
   ###  
   ### Products API  
   ###  
   location /api/products {  
       proxycache productscache;  
       limitreq zone=productsrate;  
       limitreqstatus 429;  
       proxypass http://productsapiserver;  
   }  
   
   ###  
   ### Users API  
   ###  
   location /api/users {  
       limitreq zone=userrate;  
       limitreqstatus 429;  
       proxypass http://usersapiserver;  
   }  
}
```

`limitreqzone` takes the following three parameters:

-   Key — Defines the request characteristic against which the limit is applied. In the example, it is the NGINX variable `$binaryremoteaddr`, which holds a binary representation of a client’s IP address. This means we are limiting each unique IP address to the request rate defined by the third parameter.
-   Zone — Defines the shared memory zone used to store the state of each IP address and how often it has accessed a request‑limited URL. Keeping the information in shared memory means it can be shared among the NGINX worker processes.
-   Rate — Sets the maximum request rate. In the example, the rate cannot exceed 10 requests per second for Users API and 1 request per second for Products API.

By default, NGINX will return 503 (Service Temporarily Unavailable) when the request limit is reached. To improve this, we use `limitreqstatus` to customize the response status code. In this case, we use 429 (Too Many Requests).

More details on using rate limit can be seen on the NGINX Blog: [Rate Limiting with NGINX and NGINX Plus](https://www.nginx.com/blog/rate-limiting-nginx/)

### API Key Authentication

It is unusual to publish APIs without some form of authentication to protect them. NGINX offers several approaches for protecting APIs and authenticating API clients. In our solution, we will use a simple solution to validate access to our services. We will use [API Keys Authentication](https://blog.stoplight.io/api-keys-best-practices-to-authenticate-apis).

With API key authentication, we use a map block to create an allowlist of client names that can access our services.
```shell
map $httpapikey $apiclientname {  
    default       "";  
    "KrtKNkLNGcwKQ56la4jcHwxF"  "clientone";  
    "sqj3Ye0vFW/CM/o7LTSMEMM+"  "clienttwo";  
    "diXnbzglAWMMIvyEEV3rq7Kt"  "clientten";  
}
```
The map directive takes two parameters. The first defines where to find the API key, in this case in the `apikey` HTTP header of the client request as captured in the `$httpapikey` variable. The second parameter creates a new variable (`$apiclientname`) and sets it to the value of the second parameter on the line where the first parameter matches the key.

Now enable API Key authentication on our services. Just to avoid code duplication I will separate the API Key validation into another method.

### API key validation
```shell  
location = /validateapikey {  
    internal;  
      
    if ($httpapikey = "") {  
        return 401; ### Unauthorized  
    }  
      
    if ($apiclientname = "") {  
        return 403; ### Forbidden  
    }  
      
    return 204; ### OK (no content)  
}

###  
### Products API  
###  
location /api/products {  
    authrequest /validateapikey;  
    proxycache productscache;  
    limitreq zone=productsrate;  
    limitreqstatus 429;  
    proxypass http://productsapiserver;  
}  
  
###  
### Users API  
###  
location /api/users {  
    authrequest /validateapikey;  
    limitreq zone=userrate;  
    limitreqstatus 429;  
    proxypass http://usersapiserver;  
}
```
With this configuration in place, the Products API and Users APIs now implement API key authentication.
```shell
curl -I 'http://localhost/api/products' --header 'apikey: INVALIDKEY'  
HTTP/1.1 403 Forbidden  
Server: nginx/1.21.5  
Date: Sat, 09 Jul 2022 02:24:03 GMT  
Content-Type: text/html  
Content-Length: 153  
Connection: keep-alive

curl -I 'http://localhost/api/products' --header 'apikey: diXnbzglAWMMIvyEEV3rq7Kt'  
HTTP/1.1 200 OK  
Server: nginx/1.21.5  
Date: Sat, 09 Jul 2022 02:25:03 GMT  
Content-Type: text/html; charset=utf-8  
Content-Length: 62  
Connection: keep-alive
```
Note that the above solution is quite limited, but it is possible to [authenticate using JWT](https://www.nginx.com/blog/authenticating-api-clients-jwt-nginx-plus/). However, this functionality is natively only available in NGINX Plus. For NGINX open source, an introspection endpoint is required to perform the validation.

Other more robust solutions are using that can be used for authentication, are: [OAuth Proxy Module](https://curity.io/resources/learn/nginx-oauth-proxy-module/) or [Phantom Token Module](https://curity.io/resources/learn/nginx-phantom-token-module/).

### Conclusion

Finally, our final architecture is shown in the diagram below. [Here](https://github.com/marcospereirampj/nginx-api-gateway) you can find all the codes we developed.

![](https://miro.medium.com/v2/resize:fit:810/0*InPjUrH8WGBnxxip.png)

---
### NGINX with Self-Signed Certificate on Docker 

While working with our code, we often need to quickly check if something works under HTTPS — or more importantly, how it behaves under HTTPS. There are plenty of guides online showing you how to create a Certificate Sign Request (CSR), how to self-sign that CSR, and how to manually modify your web server’s configuration to make it use that certificate.

In this article, I will present a fully-automated process using Docker to quickly spin up an NGINX container with a self-signed certificate — all without having to generate or manually edit anything at all!

### Security note and warning

1.  A self-signed certificate can only be trusted by… you. It is not a means to serve data in a production environment; use a proper certificate in such cases.
2.  The NGINX configuration to serve content under HTTPS presented in this article is the bare minimum to get the job done. If you want to modify a production NGINX with TLS, please consult the [official guide](https://docs.nginx.com/nginx/admin-guide/security-controls/terminating-ssl-http/).

If you are just starting with Public Key Cryptography, I have [written an introduction article](https://betterprogramming.pub/an-introduction-to-public-key-cryptography-3ea0cf7bf4ba) you might find useful.

### Build design

The build is designed as a 2-stage Docker build:

![](https://miro.medium.com/v2/resize:fit:875/1*uohQc3mlsF8cAs41j3jfQ.png)
The 2-stages of our Docker build (image by author)

For the first stage, I use an Alpine Linux image. I start using Alpine’s Package Keeper (or manager…), APK, to install OpenSSL. For the next step, I use OpenSSL to generate the self-signed certificate and the accompanying private key.

For the second stage, I use an NGINX image. The build modifies the image to include the certificate and the private key generated on the previous stage and writes a, simplistic, NGINX configuration to enable HTTPS.

### The Dockerfile

### syntax=docker/dockerfile:1  
### You need Docker BuildKit enabled to build this Dockerfile.  
```dockerfile
### Define Alpine and NGINX versions to use.  
ARG ALPINEVERSION=3.17.3  
ARG NGINXVERSION=1.23.4  
  
### Prepare an Alpine-based image with OpenSSL.  
FROM alpine:${ALPINEVERSION} as alpine  
ARG DOMAINNAME=localhost  
ARG DAYSVALID=30  
  
RUN apk add --no-cache openssl  
RUN echo "Creating self-signed certificate valid for ${DAYSVALID} days for domain ${DOMAINNAME}" &&   
    openssl   
    req -x509   
    -nodes   
    -subj "/CN=${DOMAINNAME}}"   
    -addext "subjectAltName=DNS:${DOMAINNAME}"   
    -days ${DAYSVALID}   
    -newkey rsa:2048 -keyout /tmp/self-signed.key   
    -out /tmp/self-signed.crt  
  
### Prepare an NGINX-based image with the certificate created above.  
FROM nginx:${NGINXVERSION} as nginx  
COPY --from=alpine /tmp/self-signed.key /etc/ssl/private  
COPY --from=alpine /tmp/self-signed.crt /etc/ssl/certs  
COPY <<EOF /etc/nginx/conf.d/default.conf  
server {  
    listen 80;  
    listen [::]:80;  
    listen 443 ssl;  
    listen [::]:443 ssl;  
    sslcertificate /etc/ssl/certs/self-signed.crt;  
    sslcertificatekey /etc/ssl/private/self-signed.key;  
    location / {  
        root   /usr/share/nginx/html;  
        index  index.html index.htm;  
    }  
    errorpage   500 502 503 504  /50x.html;  
    location = /50x.html {  
        root   /usr/share/nginx/html;  
    }  
}  
EOF
```

👉 Before you try out this Dockerfile, make sure you have Docker BuildKit enabled. [BuildKit](https://github.com/moby/buildkit) is an improved backend to replace the legacy builder and it is the default builder for users on Docker Desktop, and Docker Engine as of version 23.0.

### Stage 1: Generating the certificate

I use OpenSSL to generate the certificate and the private key passing all necessary information as arguments, so the command runs in non-interactive mode. You can tune this stage to your own requirements by specifying the following [Docker ARGs](https://docs.docker.com/engine/reference/builder/###arg):

-   `DOMAINNAME`: This is the domain the certificate will be valid for. As this is a self-signed certificate, the domain name you specify here plays not an important role, however, if you have an application that needs to do something with that certificate you may need to change it to match the domain name you will be accessing your resources from.  
    The default domain used in the build is `localhost`.
-   `DAYSVALID`: The number of days the certificate is valid for. Just use a number large enough to allow you to conclude your tests.  
    The default validity period in the build is 30 days.

### Stage 2: Generating the modified NGINX image

During this stage, I take the certificate and the private key generated in the previous stage and copy them to the newly generated image. I also use a [heredoc](https://en.wikipedia.org/wiki/Heredocument) to generate a simple NGINX configuration to enable HTTPS.

If you want to use a different configuration for your own image, you can either replace the heredoc with our own content, or extend the resulting image in your own image. If you extend the image with your own configuration files, you should placed them in:  
`/etc/nginx/conf.d/default.conf`.

### Building the image

Both Alpine and NGINX images are very small, so building is really quick. Start your build with:

`docker build . -t nginx-self-signed`

![](https://miro.medium.com/v2/resize:fit:875/1*Q8UcBryxNTBMf1T44tVTA.png)
Docker build with BuildKit enabled (image by author)

### Running the image

You can run the image exposing the default ports of 80 for HTTP, and 443 for HTTPS; just make sure these are available on the machine running your Docker Engine. Start your container with:

`docker run -p 80:80 -p 443:443 nginx-self-signed`

![](https://miro.medium.com/v2/resize:fit:875/1*RTJey65-3c5UtRnnb5gVAQ.png)
Running the custom NGINX image (image by author)

### Testing the image

Let us take trusty `curl` and do some tests. If your Docker Engine does not run on your local host, you need to replace `localhost` with the appropriate address.

### HTTP access

`**curl localhost**`

![](https://miro.medium.com/v2/resize:fit:875/1*TdbGssXGq8Vzx8CxXuSdsg.png)
HTTP access working (image by author)

Nothing to really see here, HTTP access works as expected.

### HTTPS access

`**curl https://localhost**`

![](https://miro.medium.com/v2/resize:fit:875/1*HrZF5iKnYKdFVvQ-tmkuzA.png)
HTTPS access generating errors (image by author)

Here, although NGINX replied to the HTTPS request, `curl` denied to process that answer with:

`curl: (60) SSL certificate problem: self signed certificate`

The reason for that is that the self-signed certificated used to establish the underlying TLS for HTTPS is not trusted by your computer. So, what can you do? There are a few different options here:

-   You can import the self-signed certificate into your OS’ trust/certificate store.
-   You can instruct `curl` to accept insecure certificates.

Let us try with asking `curl` to accept insecure certificates:

`**curl** [**https://localhost**](https://localhost) **--insecure**`

![](https://miro.medium.com/v2/resize:fit:875/1*YEWguqDfEPLRJnKZmbqkKQ.png)
HTTPS access succeeding (image by author)

`curl` now happily outputs the content of the underlying resource.

Similarly, if you try to open the HTTPS URL with your Internet browser, you will be greeted with a security warning. The actual warning message, as well as your options on how to proceed, vary between different Internet browsers. Here is how it looks on Chrome:

![](https://miro.medium.com/v2/resize:fit:809/1*j1QARnPWasKAfbK9qw1HkQ.png)
Chrome blocking access to an HTTPS URL using an invalid certificate (image by author)

On Chrome, you can click on the ‘Advanced’ button and then click on ‘Proceed to localhost (unsafe)’ option:

![](https://miro.medium.com/v2/resize:fit:751/1*SpRQc6zePfsZ0ty320dkA.png)
Chrome ignores the invalid certificate and displays the page (image by author)

### Bonus content

Before I go, a couple of extra tips on how you can use the image we created here with your own content.

### 1. Serving your own content

I guess serving the default NGINX welcome page is not much of a value to anyone. You can point the custom NGINX image we created above to your own content by mounting a local folder to the container:
```shell
docker run   
  -p 80:80 -p 443:443   
  -v {YOUR-PATH}:/usr/share/nginx/html   
nginx-self-signed
```
### 2. Reverse proxying to your own content

If you do not want to mount your content inside the container, you can configure NGINGX to act as a reverse proxy to another server you have already running. The following code extract allows to set up such a configuration, however, be aware that reverse proxying is infinitely more complicated than the simplistic example below and you may face many different issues depending on what is actually being proxied:

Define the upstream server on top of your NGINX configuration:
```shell
upstream api-gateway {  
  server http://some-server:80;  
}
```
Enhance the `server` block of your NGINX configuration with:
```shell
location /api/ {  
    proxypass                http://api-gateway;  
    proxyredirect            off;  
    proxysetheader          X-Real-IP $remoteaddr;  
    proxysetheader          X-Forwarded-For $proxyaddxforwardedfor;  
    proxysetheader          X-NginX-Proxy true;  
    proxysslsessionreuse   off;  
    proxysetheader Host     $httphost;  
    proxycachebypass        $httpupgrade;  
  }
```
### Conclusion

In this article, I presented a quick way to get up and running with an NGINX Docker container featuring a self-signed certificate. No need to install OpenSSL on your machine, and no need to run `openssl` commands to create certificates; everything runs as part of your Docker build.

I also provided two examples of how to integrate your own content into the resulting NGINX image, by mounting your content inside the container or by reverse proxying to another already running server.

Thank you for reading this piece. I hope to see you in the next one.
---

# Hardening an NGINX server

Nginx is a popular open-source web server that is commonly used to serve static content or act as a reverse proxy for dynamic web applications. As with any server, it is crucial to harden Nginx to prevent unauthorized access and reduce the risk of attacks. In this article, we will discuss some best practices for hardening an Nginx server.

-   Keep Nginx up to date One of the most important steps in securing your Nginx server is to keep it up to date. This includes both the Nginx software itself and any third-party modules that you have installed. Updates often contain security fixes, so regularly checking for and installing updates is critical to maintaining server security.
-   Secure Nginx Configuration Files It’s important to secure your Nginx configuration files by giving them restrictive file permissions. The Nginx configuration files should only be accessible by the root user or the Nginx user. This will help prevent unauthorized access or tampering with the configuration files.
-   Implement SSL/TLS Secure Sockets Layer (SSL) and Transport Layer Security (TLS) protocols provide secure communication between client and server. By implementing SSL/TLS on your Nginx server, you can ensure that data transmitted over the network is encrypted and cannot be intercepted by attackers. To implement SSL/TLS on your Nginx server, you will need to generate an SSL/TLS certificate, configure Nginx to use the certificate, and enforce HTTPS traffic. You can obtain an SSL/TLS certificate from a trusted Certificate Authority (CA) or generate a self-signed certificate.
-   Limit Access to Nginx Limiting access to your Nginx server is an effective way to prevent unauthorized access. You can restrict access to the server by using IP-based access controls or configuring a firewall. You can also implement two-factor authentication to require users to provide a second form of authentication before accessing the server.
-   Implement Security Headers HTTP headers provide additional information to the browser and server about the request and response. By implementing security headers, you can add an extra layer of protection to your Nginx server. Some of the commonly used security headers are:

> X-Frame-Options: prevents clickjacking attacks by preventing the site from being embedded in an iframe
> 
> Content-Security-Policy: restricts the types of content that can be loaded on a web page
> 
> X-XSS-Protection: prevents cross-site scripting attacks
> 
> X-Content-Type-Options: prevents MIME sniffing attacks by forcing the browser to use the declared content type.

-   Monitor Nginx Logs Monitoring Nginx logs is an essential part of server hardening. Nginx logs record all requests and responses made to the server. By monitoring these logs, you can detect and investigate potential attacks on your server.
-   Enable Security Modules Nginx has several security modules that can help harden your server. Some of these modules include:

> ngxhttplimitreqmodule: limits the number of requests that can be made to the server in a given time period
> 
> ngxhttplimitconnmodule: limits the number of connections that can be made to the server in a given time period
> 
> ngxhttpsslmodule: enables SSL/TLS encryption on the server
> 
> ngxhttpsecurelinkmodule: adds an extra layer of protection to your content by requiring a secure link to access it.

In conclusion, hardening an Nginx server is crucial to prevent unauthorized access and reduce the risk of attacks. By following the best practices outlined in this article, you can secure your Nginx server and maintain the integrity of your data.

---
# Dockerize an Angular application with nginx 

Docker is a software platform for building, running, managing, shipping containers on the server and the Cloud platform. Docker enables to separate the application from the infrastructure so the we can quickly deliver the software.

### **What is nginx?**

nginx is an open source, free high performance HTTP webserver used for website hosting, reverse proxying, caching, load balancing. Initially it was designed as we webserver in addition to it’s HTTP server capabilities it can perform as a proxy server for email(IMAP,POP3 and SMTP) and a reverse proxy and load balancer for HTTP, TCP and UDP protocol.

### **Prerequisite**

1. Node.js  
2. Angular CLI  
3. Docker

### **Creating an Angular application**

We need **Angular CLI**, **Node JS** installed in local environment to create an Angular application in local environment.  
If all the pre-requisite are installed you can proceed with below command to create an Angular application.
Creating an new Angular project

### **Creating a docker file:**

We need to create a docker file, which will be used to dockerize the Angular application with NGINX server. We have segregated the docker build into following stages .  
1. Building the angular source code in production mode to generate the compiled dist folder.  
2. Serving/hosting the angular application with nginx web server.  
Below is the code snippet for the docker file:

Docker file for an Angular application

### **Stage 1: Building the angular source code in production mode:**

**FROM:** The stage is arbitrarily named as build, to reference this stage in the nginx configuration stage. Below listed work will be performed during this stage :1. It initializes a new build  
2. It set the latest node image from DockerHub registry as the base image for executing subsequent instructions relevant to the angular app’s configuration**WORKDIR:** Below listed work will be performed during this stage:  
1. Set the default working directory in which the subsequent instructions are executed.  
2. The directory is created, if the path is not found. In the above snippet, an arbitrary path of usr/local/app is chosen as the directory to move the angular  
source code into.

**COPY:** This steps copies files from project root directory on the host machine to the container working directory path which has been specified on the command.**RUN:** This command the angular build top of the base node image and it will generate an dist folder, which contains compiled files. After build command is executed, the build output is stored under **usr/local/app/dist/sample-angular-app**. The compiled image will be used for the subsequent steps in the Dockerfile.

### **Stage 2:Serving/hosting the angular application with nginx web server:**

**FROM:** This command initializes a secondary build stage and sets the latest nginx image from docker hub registry as the base image for executing subsequent instructions relevant to nginx configuration.**COPY:** This command copies the build output generated in stage 1 (- -from=build) to replace the default nginx contents.**EXPOSE:** This command informs Docker that the nginx container listens on network port 80 at runtime. By default, the nginx server runs on port 80, hence we are exposing that specific port.

### **Create .dockerignore**

We can specify the files, which we want to ignore while we are creating a docker image for an example nodemodules,

### **Running Docker Container:**

To build and run the docker container, Please follow the below steps:  
**Step 1:** Open up the command prompt.  
**Step 2:** Navigate to the location of docker file in your project’s directory.  
**Step 3:** Execute the below command

building the docker image

**Step 4: Check docker container successfully build or not**

Please execute the below command to check the container is running successfully or not

**Step 5 : If the container is in the list, we can run the docker image using below command**

run command for docker

**Step 6: Checking status of a docker container**

Please execute the below command to check the status of the container

checking docker container status

Please follow the above steps to implement an Angular application with docker and let me know your thoughts in the comment.

**Dear readers, thank you for your support and your precious time. I hope this was useful and helpful to discover basics of Angular application. Please clap, if you like the article and leave your thought in comment.**

**Please follow me and become a member on** [**medium**](/@technicadil001/membership) **for more articles. Cheers!!**



ng new <projectname>

[view raw](https://gist.github.com/Technicoryx/7ddabfefb7588aff8b1bc4512e251d74/raw/edaeeaa48ea53116648935834389a94e5d86ccb5/docer01.ts) [docer01.ts](https://gist.github.com/Technicoryx/7ddabfefb7588aff8b1bc4512e251d74###file-docer01-ts) hosted with ❤ by [GitHub](https://github.com)

---

### Stage 1: Compile and Build angular codebase
```Dockerfile
FROM node:latest as build
WORKDIR /usr/local/app
COPY ./ /usr/local/app/
RUN npm install

RUN npm run build

FROM nginx:latest

COPY --from=build /usr/local/app/dist/sample-angular-app /usr/share/nginx/html

EXPOSE 80
```
[view raw](https://gist.github.com/Technicoryx/437958886cf086e65bf81542dcb42d4e/raw/821668293422f2762aa285be1d081304041b8c69/docker02.ts) [docker02.ts](https://gist.github.com/Technicoryx/437958886cf086e65bf81542dcb42d4e###file-docker02-ts) hosted with ❤ by [GitHub](https://github.com)

---
```shell
docker build -t techinocoryx/sample-angular-app-image:latest
```
[view raw](https://gist.github.com/Technicoryx/0c27a4053119111bd000cb7db7478a21/raw/0f4011b1e7731176fd244c0dd3f6ee75681b5d53/docker03.txt) [docker03.txt](https://gist.github.com/Technicoryx/0c27a4053119111bd000cb7db7478a21###file-docker03-txt) hosted with ❤ by [GitHub](https://github.com)

---
```shell
docker image ls
```
[view raw](https://gist.github.com/Technicoryx/5c9c183736cbf9d5b6408fbbac99b7a8/raw/4a12334a0f4a307ac96296aaa247f4ce97df21f5/docker06.txt) [docker06.txt](https://gist.github.com/Technicoryx/5c9c183736cbf9d5b6408fbbac99b7a8###file-docker06-txt) hosted with ❤ by [GitHub](https://github.com)

---
```shell
docker run -d -p 8080:80 technicoryx/app-docker-image:latest
```
[view raw](https://gist.github.com/Technicoryx/f586a1db62dc0a43ce4a111917877d56/raw/ba8f8fef884da89fdbde6905d09f5d10d64f8a22/docker08.txt) [docker08.txt](https://gist.github.com/Technicoryx/f586a1db62dc0a43ce4a111917877d56###file-docker08-txt) hosted with ❤ by [GitHub](https://github.com)

---
```shell
docker ps
```
[view raw](https://gist.github.com/Technicoryx/fdf56c972244bfb6f9a5807702d69171/raw/b7925677109b0b64c9b7fe8143509dda5887a1aa/docker09) [docker09](https://gist.github.com/Technicoryx/fdf56c972244bfb6f9a5807702d69171###file-docker09) hosted with ❤ by [GitHub](https://github.com)

---
### Using Docker to Set up Nginx Reverse Proxy With Auto SSL Generation 

### What is reverse proxy? What are its advantages?

What is a reverse proxy? Reverse proxy is kind of a server that sits in the front of many other servers, and forwards the client requests to the appropriate servers. The response from the server is then also received and forwarded by the proxy server to the client.

![](https://miro.medium.com/v2/resize:fit:875/0*xX8JmEIOVX6kQHmZ.png)

Why would you use such a setup? There are several good reasons for that. This setup can be used to set up a load balancer, caching or for protection from attacks.

I am not going into the details here. Instead, I’ll show you how you can utilize the concept of reverse proxy to set up multiple services on the same server.

Take the same image as the one you saw above. What you can do is to run an Ngnix server in a docker container in reverse proxy mode. Other web services can also be run in their own respective containers.

Nginx container will be configured in a way that it knows which web service is running in which container.

![](https://miro.medium.com/v2/resize:fit:875/0*4aqj9lI8x-9NJYGk.png)

This is a good way to save cost of hosting each service in a different server. You can have multiple services running in the same Linux server thanks to the reverse proxy server.

### Setting up Nginx as reverse proxy to deploy multiple services on the same server using Docker

Let me show you how to go about configuring the above mentioned setup.

With these steps, you can install multiple web-based application containers running under Nginx with each standalone container corresponding to its own respective domain or subdomain.

First, let’s see what you need in order to follow this tutorial.

### Prerequisites

You’ll be needing the following knowledge to get started with this tutorial easily. Althogh, you can get by without them as well.

-   A Linux system/server. You can easily deploy a Linux server in minutes using [Linode cloud service](https://www.linode.com/?r=19db9d1ce8c1c91023c7afef87a28ce8c8c067bd).
-   Familiarity with Linux commands and terminal.
-   Basic knowledge of Docker.
-   You should have Docker and Docker Compose installed on your Linux server. Please read our guide on [installing Docker](https://linuxhandbook.com/install-docker-centos/) and [Docker Compose on CentOS](https://linuxhandbook.com/install-docker-compose-centos/).
-   You should also own a domain (so that you can set up services on sub-domains).

I have used domain.com as an example domain name in the tutorial. Please make sure you change it according to your own domains or subdomains.

Other than the above, please also make sure of the following things:

Change your domain’s DNS records

In your domain name provider’s A/AAAA or CNAME record panel, make sure that both the domain and subdomains (including www) point to your server’s IP address.

This is an example for your reference:

HostnameIP AddressTTLdomain.com172.105.50.178Default*172.105.50.178Defaultsub0.domain.com172.105.50.178Defaultsub1.domain.com172.105.50.178Default

Swap space

To make sure all your container apps are at ease and never run out of memory after you deploy them, you must have the necessary swap space on your system.

You can always [adjust swap](https://linuxhandbook.com/increase-swap-ubuntu/) according to the available RAM on your system. You can decide the swap space based on the bundle of app containers on the single server and estimating their cumulative RAM usage.

**Before we start, please follow our channel and do not forget to clap. 👏 this is really help to promote our content**

### Step 1: Set up Nginx reverse proxy container

Start with setting up your nginx reverse proxy. Create a directory named “reverse-proxy” and switch to it:

mkdir reverse-proxy && cd reverse-proxy

Create a file named `docker-compose.yml`, open it in your favourite terminal-based text editor like [Vim](https://linuxhandbook.com/basic-vim-commands/) or [Nano](https://www.nano-editor.org/).

For the nginx reverse proxy, I’ll be using [jwilder/nginx-proxy](https://hub.docker.com/r/jwilder/nginx-proxy) image. Copy and paste the following in the docker-compose.yml file:

```yaml
version: "3.7"
  services:    
    reverse-proxy:  
      image: "jwilder/nginx-proxy:latest"  
      containername: "reverse-proxy"  
      volumes:  
        - "html:/usr/share/nginx/html"  
        - "dhparam:/etc/nginx/dhparam"  
        - "vhost:/etc/nginx/vhost.d"  
        - "certs:/etc/nginx/certs"  
        - "/run/docker.sock:/tmp/docker.sock:ro"  
      restart: "always"  
      networks:   
        - "net"  
      ports:  
        - "80:80"  
        - "443:443"
```

Now let’s go through the important parts of the compose file:

-   You have declared four volumes, html, dhparam, vhost and certs. They’re persistent data that you’d definitely want to keep even after the container’s been down. The `html` & `vhost` volumes will be very important in the next [Let's Encrypt](https://letsencrypt.org/) container deployment. They're designed to work together.
-   The docker socker is mounted read-only inside the container. This one’s necessary for the reverse proxy container to generate nginx’s configuration files, detect other containers with a specific environment variable.
-   [Docker restart policy](https://linuxhandbook.com/docker-restart-policy/) is set to `always`. Other options include `on-failure` and `unless-stopped`. In this case, always seemed more appropriate.
-   The ports 80 and 443 are bound to the host for http and https respectively.
-   Finally, it uses a different network, not the default bridge network.

> Using a user defined network is very important. This will help in isolating all the containers that are to be proxied, along with enabling the reverse proxy container to forward the clients to their desired/intended containers and also let the containers communicate with each other (Which is not possible with the default bridge network unless `icc` is set to `true` for the daemon).

Keep in mind that YML is very finicky about tabs and indention.

### Step 2: Set up a container for automatic SSL certificate generation

For this, you can using [jrcs/letsencrypt-nginx-proxy-companion](https://hub.docker.com/r/jrcs/letsencrypt-nginx-proxy-companion) container image.

On the same `docker-compose.yml` file that you used before, add the following lines:
```yaml
letsencrypt:  
  image: "jrcs/letsencrypt-nginx-proxy-companion:latest"  
  containername: "letsencrypt-helper"  
  volumes:  
    - "html:/usr/share/nginx/html"  
    - "dhparam:/etc/nginx/dhparam"  
    - "vhost:/etc/nginx/vhost.d"  
    - "certs:/etc/nginx/certs"  
    - "/run/docker.sock:/var/run/docker.sock:ro"  
  environment:  
    NGINXPROXYCONTAINER: "reverse-proxy"  
    DEFAULTEMAIL: "user@domain.com"  
  restart: "always"  
  dependson:  
    - "reverse-proxy"  
  networks:   
    - "net"
```
In this service definition:

-   You’re using the same exact volumes as you used for the reverse-proxy container. The `html` and `vhost` volumes sharing are necessary for the [ACME Challenge of letsencrypt](https://letsencrypt.org/docs/challenge-types/) to be successful. This container will generate the certificates inside `/etc/nginx/certs`, in the container. This is why you are sharing this volume with your reverse proxy container. The `dhparam` volume will contain the dhparam file. The socket is mounted to detect other containers with a specific environment variable.
-   Here you have defined two environment variables. The `NGINXPROXYCONTAINER` variable points to the reverse proxy container. Set it to the name of the container. The `DEFAULTEMAIL` is the email that'll be used while generating the certificates for each domain/subdomain.
-   The `dependson` option is set so that this service waits for the reverse proxy to start first, then and only then, this'll start.
-   Finally, this container also shares the same network. This is necessary for the two containers to communicate.

### Step 3: Finalize the docker compose file

Once the service definitions are done, complete the docker-compose file with the following lines:
```yaml
volumes:  
  certs:  
  html:  
  vhost:  
  dhparam:networks:  
  net:  
    external: true
```
The network `net` is set to external because the proxied containers will also have to use this network. And if we leave the network to get created by `docker-comspose`, the network name will depend on the current directory. This will create a weirdly named network.

Other than that, other containers will have to set that network to be external anyway, otherwise those compose files will also have to reside in this same directory, none of which is ideal.

Therefore, create the network using

docker network create net

The following is the whole content of the `docker-compose.yml` file.
```yaml
version: "3.7"
  services:    
    reverse-proxy:  
        image: "jwilder/nginx-proxy:latest"  
        containername: "reverse-proxy"  
        volumes:  
          - "html:/usr/share/nginx/html"  
          - "dhparam:/etc/nginx/dhparam"  
          - "vhost:/etc/nginx/vhost.d"  
          - "certs:/etc/nginx/certs"  
          - "/run/docker.sock:/tmp/docker.sock:ro"  
        restart: "always"  
        networks:   
          - "net"  
        ports:  
          - "80:80"  
          - "443:443"  
    letsencrypt:  
        image: "jrcs/letsencrypt-nginx-proxy-companion:latest"  
        containername: "letsencrypt-helper"  
        volumes:  
          - "html:/usr/share/nginx/html"  
          - "dhparam:/etc/nginx/dhparam"  
          - "vhost:/etc/nginx/vhost.d"  
          - "certs:/etc/nginx/certs"  
          - "/run/docker.sock:/var/run/docker.sock:ro"  
        environment:  
          NGINXPROXYCONTAINER: "reverse-proxy"  
          DEFAULTEMAIL: "user@domain.com"  
        restart: "always"  
        dependson:  
          - "reverse-proxy"  
        networks:   
          - "net"  
volumes:  
  certs:  
  html:  
  vhost:  
  dhparam:networks:  
  net:  
    external: true
```
Finally, you can deploy these two containers (Ngnix and Let’s Encrypt) using the following command:
```shell
docker-compose up -d
```
### Step 4: Verify that Ngnix reverse proxy is working

The container that’ll serve the frontend will need to define two environment variables.

`VIRTUALHOST`: for generating the reverse proxy config

`LETSENCRYPTHOST`: for generating the necessary certificates

Make sure that you have correct values for these two variables. You can run nginx-dummy image with reverse proxy like this:
```shell
docker run --rm --name nginx-dummy -e VIRTUALHOST=sub.domain.com -e LETSENCRYPTHOST=sub.domain.com -e VIRTUALPORT=80 --network net -d nginx:latest
```
Now if you go to your sub-domain used in the previous command, you should see a message from Ngnix server.

![](https://miro.medium.com/v2/resize:fit:875/0*Hrd3JX5a3BZc-F-g.png)

Once you have successfully tested it, you can [stop the running docker container](https://linuxhandbook.com/docker-stop-container/):

docker stop nginx-dummy

You may also stop the Ngnix reverse proxy if you are not going to use it:

docker-compose down

### Step 5: Run other service containers with reverse proxy

The process of setting up other containers so that they can be proxied is VERY simple.

I’ll show it with two instances of [Nextcloud](https://nextcloud.com/) deployment in a moment. Let me first tell you what you are doing here.

###### Do not bind to any port

The container can leave out the port that serves the frontend. The reverse proxy container will automatically detect that.

###### (OPTIONAL) Define VIRTUALPORT

If the reverse proxy container fails to detect the port, you can define another environment variable named `VIRTUALPORT` with the port serving the frontend or whichever service you want to get proxied, like "80" or "7765".

###### Set Let’s Encrypt email specific to a container

You can override the `DEFAULTEMAIL` variable and set a specific email address for a specific container/web service's domain/subdomain certificate(s), by setting the email id to the environment variable `LETSENCRYPTEMAIL`. This works on a per-container basis.

Now that you know all those stuff, let me show you the command that deploys a Nextcloud instance that’ll be proxied using the nginx proxy container, and will have TLS(SSL/HTTPS) enabled.

> This is NOT AN IDEAL deployment. The following command is used for demonstrative purpose only.
```shell
docker run --name nextcloud --network net -e VIRTUALHOST="sub0.domain.com" -e LETSENCRYPTHOST="sub0.domain.com" -d nextcloud:19.0.2
```
In the example, you used the same network as the reverse proxy containers, defined the two environment variables, with the appropriate subdomains (Set yours accordingly). After a couple of minutes, you should see Nextcloud running on sub0.domain.com. Open it in a browser to verify.

You can deploy another Nextcloud instance just like this one, on a different subdomain, like the following:
```shell
docker run --name anothernextcloud --network net -e VIRTUALHOST="sub1.domain.com" -e LETSENCRYPTHOST="sub1.domain.com" -d nextcloud:19.0.2
```
Now you should see a different Nextcloud instance running on a different subdomain on the same server.

With this method, you can deploy different web apps on the same server served under different subdomains, which is pretty handy.

---