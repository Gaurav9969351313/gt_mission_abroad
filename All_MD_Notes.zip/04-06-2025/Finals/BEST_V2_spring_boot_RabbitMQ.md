# RabbitMQ Exchanges Explained.

**Note: For non-members, this article is also available at** [https://progressstory.com/tech/python/deep-dive-into-rabbitmq-exchange/](https://progressstory.com/tech/python/deep-dive-into-rabbitmq-exchange/)

Before going ahead with this blog, we should understand the Queuing Systems, RabbitMQ. But if you don't have it, then it's not the end of the world, let me summarize the whole RabbitMQ and Queuing system by taking a simple example.

## Treat RabbitMQ as a Post Office

![](https://miro.medium.com/v2/resize:fit:875/1*qM4ncssBYsVEpiaJlAnHqw.png)
Rabbitmq relation with Post Office

Treat RabbitMQ as a Post Office.

**Producers** in real life are just the end-users who are sending their mails to the Post Office and here in Rabbitmq world they are processes that send the task to RabbitMQ

**Exchange** in real life is the postman that just routes the mail to specific postboxes and here in RabbitMQ exchanges are just routing the tasks to specific queues.

**The task** in real life is the mail that the postman sends to the postbox and in RabbitMQ world it's the technical information that sends to exchange.

**Queue** in real life is the Postbox that is having all the mails and here in RabbitMQ queue has all the tasks in it and they are processed in a **first-in-first-out** manner.

Now let’s directly jump into what exchanges are in RabbitMQ. In RabbitMQ, when the producer creates a message that will not directly be sent to a queue, instead first the message will be sent to exchanges, then after that, a routing agent reads it and sends it to the appropriate queue with help of header attributes, bindings, and routing keys.

# RabbitMQ Exchange Types

In RabbitMQ, we have four types of Exchanges are available to route the message in different ways.

Following are the different types of exchanges available in RabbitMQ.

-   Direct
-   Fanout
-   Topic
-   Headers

# Direct Exchange

The routing in “Direct Exchange” is simple, a message goes to the queues whose binding key exactly matches the routing key of the message.

The direct exchange type is useful to distinguish messages published to the same exchange using a simple string identifier.

Let’s say we create a direct exchange ‘color’ in RabbitMQ Management Console

![](https://miro.medium.com/v2/resize:fit:875/1*b19Q5ry2dz0oeAujekNu8Q.png)

And two queues with routing key ‘orange’ and ‘blue’ respectively.

![](https://miro.medium.com/v2/resize:fit:875/1*qPgop_hd94Cozm98Q7KGZg.png)
Orange Queue with binding orange as a routing key

![](https://miro.medium.com/v2/resize:fit:875/1*As4XD8XoLASlWj_uHAK29g.png)
Blue Queue with binding blue as a routing key

Now the exchange **color** will route the task to the **orange** **queue** that is having **orange(exact match)** as a **routing key** and it will route the task to the blue queue that is having a blue(exact match) as a routing key

![](https://miro.medium.com/v2/resize:fit:875/1*cIOYL0Y_WoLC53okysO6jw.png)

If the routing key does not match any binding key, the message is discarded. If more than one queue is bound to exchange with the same binding key, the direct exchange will broadcast the message to all matching queues.

# Fanout Exchange

A fanout exchange routes a message to all queues that are bound to it regardless of the routing keys. The keys provided will simply be ignored.

Fanout exchanges can be useful when the same message would be consumed by two or more different queues. For example, when the user account is created, it should send a welcome email to the end-user and a text message to the end-user about the successful registration. This can be done using Fanout exchange that will send the message to two different queues is for Email and another one for SMS

![](https://miro.medium.com/v2/resize:fit:875/1*ic3r_sw34ThVc-0qrtJMZQ.png)
Fanout exchange will broadcast the message to all the queues connected

# Topic Exchange

Topic exchange is similar to direct exchange, but the routing is done according to the routing pattern and the wildcard. Instead of using a fixed routing key, it uses wildcards. Messages are routed to one or many queues based on a matching between a message routing key and pattern.

The routing key should be delimited by **“.”.** And the binding key will follow the same fashion however it can use the following wildcards as well

-   * (star) can substitute for exactly one word.
-   # (hash) can substitute for zero or more words.

Let’s say, we have two queues with binding key ***.orange.***, ***.*.rabbit** and **lazy.#**

![](https://miro.medium.com/v2/resize:fit:530/1*CZKqKFQgpxYLed8VJTsAzQ.png)

These findings can be summarised as:

-   Q1 is interested in all the orange animals.
-   Q2 wants to hear everything about rabbits, and everything about lazy animals.

**Now the messages like below will go to Q1**

-   fast.**orange**.fox
-   crazy.**orange**.**rabbit**(will go to Q2 as well)
-   **lazy**.**orange**.elephant(will go to Q2 as well)

**The messages like below will go to Q2**

-   crazy.**orange**.**rabbit**(will go to Q1 as well)
-   **lazy**
-   test.test.rabbit
-   lazy.test.test.test

**quickly.orange.male.rabbit** will not go to any of the Queue.

# Header Exchange

A headers exchange is an exchange that routes messages to queues based on message header values instead of routing key. The producer adds some values in a form of key-value pair in the message header and sends it to the headers exchange. After receiving a message, the exchange tries to match all or any (based on the value of “**x-match**”) header value with the binding value of all the queues bound to it.

The producer can add one special value in the header of the message called “**x-match**“, The “**x-match**” can have two different values, “**any**” or “**all**“, where “**all**” is the default value. “**all**” means all the header key-value pairs must match while “**any**” means at least one of the headers key-value pairs must match with the binding value of the queue. The value in header key-value pairs can be of any data type like integer, string, or even hash.

Let’s say we have two queues with binding values as

(‘x-match’, ‘all’), (‘channel’, ‘google’), (‘first-time-logged-in’, ‘yes’)

and

(‘x-match’, ‘any’), (‘channel’, ‘email’), (‘phone-available’, ‘yes’)

![](https://miro.medium.com/v2/resize:fit:875/1*6eicXZ9QHk-H3h-DI3-daA.png)
Header Exchange route message with the headers bindings

Messages with headers like [(‘channel’, ‘email’)(‘phone-available’, ‘no’)] and [(‘phone-available’, ‘yes’)] will be routed to SMS Queue as the x-match property is **any** so any value that is matching the binding will be routed to **SMS Queue**. In the first case channel matched and in the other case phone-available matched.

Messages with headers like [(‘channel’, ‘google’)(‘first-time-logged-in’, ‘yes’), (‘phone-available’, ‘yes’)] [(‘channel’, ‘google’)(‘first-time-logged-in’, ‘yes’)] will route to EMAIL Queue as the x-match property is **all** so all the header values should match with the queue bindings.

# Conclusion

Use the exchange according to your case. A direct/topic exchange can work as a fanout exchange if the binding key of all queues is the same. Using Exchanges extensively and appropriately can simplify/improve your Queuing architecture to a great extent.

Help keep the caffeine levels high and my keyboard awake! Buy me a [coffee](https://www.buymeacoffee.com/progressstory), because my words are fueled by beans, not just dreams. Let’s turn coffee into content together!


### Getting started with RabbitMQ in Spring Boot
RabbitMQ is the most widely deployed open source message broker. It gives you some nice features to help you make your application asynchronous and off-load some crux logic so that you can focus on your business code. In this article I’ve demonstrated the easiest way to get started with RabbitMQ in [spring boot projects](/javarevisited/10-best-java-microservices-courses-with-spring-boot-and-spring-cloud-6d04556bdfed?utm_source=dlvr.it&utm_medium=linkedin), automate queue and exchange creation, configure retry-ability on consumer, handle errors and distributed tracing.

Let me share a funny incident. When I first started working with rabbitMQ I went to the website and found that [tutorial](https://www.rabbitmq.com/getstarted.html) page. On that page there were 6 tutorials of some common scenarios in different languages. And hey! Java tutorials are just under python. It kinda still looks the same…

![](https://miro.medium.com/v2/resize:fit:875/0*SvCZA53AJkkYysrj)

Then I skimmed through a few java tutorial pages and was amazed with how easy it is to use it. Just need to create a connection factory, declare channels, publish with channels basicPublish method, and receive with delivery callbacks.

Yeah, those steps helped me to stitch together my use case and even deploy my app into production. Then during another project I also started that way and somewhere in my mind I kept hearing a voice.. “There should be a cleaner way!, there should be a better way!!”. And trust me, that better way was always in front of my eye but I was blind to see it. In the same tutorial page there was…

![](https://miro.medium.com/v2/resize:fit:875/0*Lywixs1ydMhucNEj)

**Spring AMQP** version for each tutorial which was exactly what I needed, but never knew it existed.

[Spring AMQP](https://spring.io/projects/spring-amqp) makes development with RabbitMQ more springy. It provides listener containers, rabbitTemplate and rabbitAdmin. So let’s see some actions!

### Set up RabbitMQ

So before everything we need to have a RabbitMQ instance running to interact with if you don’t have one at your disposal. You can use following docker compose to get one quickly.
```yaml
version: '3.1'  
  
services:  
 rabbitmq:  
   image: rabbitmq:management  
   restart: no  
   ports:  
     - "5672:5672"  
     - "15672:15672"
```
Here 5672 port is used by applications, and on 15672 we get a web interface for management.

Open your browser and hit into localhost:15672, you’ll see the following page:

![](https://miro.medium.com/v2/resize:fit:875/0*t_OcFbxhYUOdHkJV)

Use guest/guest as username and password. If you are deploying rabbitmq into production, it’s always a good idea to change that default credential. But for now it should be fine.

### Add dependency in Spring boot app

To use rabbitMQ we need to add the **spring-boot-starter-amqp** dependency. As I am using maven, I’ll add the following in my pom.xml:
```xml
<dependency>  
   <groupId>org.springframework.boot</groupId>  
   <artifactId>spring-boot-starter-amqp</artifactId>  
</dependency>
```
I also need add the following configuration in the profile:
```yaml
spring:  
 rabbitmq:  
   host: localhost  
   port: 5672  
   username: guest  
   password: guest
```
Now spring amqp knows where our rabbitMQ is and which credential to use to connect with it.

To make the examples I’ve shown here relatable, here is what we’ll do. We’ll expose a **user-registration** [controller](https://javarevisited.blogspot.com/2021/09/how-to-return-different-http-status-from-sprnig-mvc-controller.html), receive a payload containing name, email etc then publish in a queue. We assume that registering a user requires calling some other services and [APIs](https://javarevisited.blogspot.com/2018/01/top-20-libraries-and-apis-for-java-programmers.html), so we are making this asynchronous, and a consumer will do all this.

### Publish messages to queue

Now I’ve created a controller class, and also added other relevant classes for this. This is how the controller looks like:

![](https://miro.medium.com/v2/resize:fit:875/0*BEaUjcXaL7EKBP-B)

Notice that I’ve added RabbitTemplate in the controller and used that in the createUser method to publish the message. Now we need to create a queue. For that I’ve logged in into the rabbitMQ management console. Navigate to the Queue tab , there is an **Add a new Queue** option.

![](https://miro.medium.com/v2/resize:fit:875/0*VcXg09TeO6q_DhEV)

Just keep other fields as default and set the name as **user-registration**.

Now spin up the application and hit the api with appropriate payload. For me it looks like this:
```shell
curl --location --request POST 'http://localhost:8091/api/user' --header 'Content-Type: application/json' --data-raw '{"username":"Johnson","email":"johnsn@mail.com","mobileNumber": "017000000111"}'
```
If everything works correctly we’ll be able to see 1 ready message in the queue:

![](https://miro.medium.com/v2/resize:fit:875/0*_DLNXE7AH4HUtcO3)

To see the message, click on the queue name and hit the Get **Message(s)** option, uh oh! The payload is not readable. It’s in [base64 forma](https://javarevisited.blogspot.com/2012/02/how-to-encode-decode-string-in-java.html###axzz54LFhfNxy)t. We’ll take care of this later I promise. Now head back to coding. Using this line I’ve published my message:

rabbitTemplate.convertAndSend(“”, “user-registration”, request);

Here first argument is **exchange**, second one is **routing key** and last one is the payload. But where is the queue?

In the rabbitMQ universe, an exchange is like a post office, a queue is like the physical location, and the routing key is the address of that location. When we created the queue and didn’t bound with any exchange, the default exchange automatically got bound with it and took the routing key as the queue’s name. This using empty string and queue name as routing key got the message published to the queue. A producer never directly sends messages to the queue.

### Create queue automatically

Creating and configuring the queue through the management console works fine for now. But in the real world, this is not ideal. Imagine there are not one 10 different queues.

Everytime a new team mate gets onboard, or you change your device you need to create the queues. App goes from dev environment to test environment, you need to create the queues. App goes to production, someone needs to create them. This will get tedious and error-prone as well. Spring AMQP provides us rabbitMQ admin to automate these tasks.

Best part is, you just need to create a [Bean](https://javarevisited.blogspot.com/2022/03/how-autowiring-of-beans-works-in-spring.html) that returns a Queue object containing the queue’s name. It is a good practice to keep all rabbitMQ related beans in the same configuration file. Right now my RabbitMQConfig looks like this:
```java
@Configuration  
public class RabbitMQConfig {  
    @Bean  
    public Queue createUserRegistrationQueue() {  
        return new Queue("q.user-registration");  
    }  
}
```
It’s a convention in rabbitMQ to name the queue’s starting with **q.** .

Go ahead and delete any previous queues from the management portal, then restart your application and hit the api, the queue should get created and messages will be delivered.

### Add consumer to process messages

It’s only half the fun to have only a publisher if there is no consumer for the published messages. Having a consumer is as simple as annotating a method with _@RabbitListener_ annotation and mentioning the queue. My consumer for user registration request looks like this:
```java
@Service  
@Slf4j  
public class UserRegistrationListener {  
          @RabbitListener(queues = {"q.user-registration"})  
    public void onUserRegistration(UserRegistrationRequest event) {  
            log.info("User Registration Event Received: {}", event);  
    }  
}
```

If you hit the api endpoint for registration and then check the logs you’’ll be able to see this:

![](https://miro.medium.com/v2/resize:fit:875/0*6qv2Nx7X556iI6bo)

Looks nice! I’m receiving the expected payload in the consumer, and rabbitMQ internally handles serialization and deserialization so that I’m getting a pretty java object to work with. Though if we want to check the message directly from the management portal we’ll still see the message as base64. This is not ideal for development and troubleshooting. We want to see the messages in a readable format for us humans.

To achieve that, we need to declare a **Jackson2JsonMessageConverter** bean and set it as our desired message converted in rabbitTemplate. Need to add these beans in our RabitMQConfig file:

![](https://miro.medium.com/v2/resize:fit:875/0*HiGLQbBaHxbgtCMf)

Note that, we used the default cachingConnectionFactory in constructing rabbitTemplate. To do that we need to inject the cachingConnectionFactory through the constructor. After that, comment out the listener to check the message in the portal. Otherwise, it will get delivered in the consumer method before we had a chance to have a peek.

If we hit the api now, and check the queue we’ll be able to see the text of the payload from the management portal.

![](https://miro.medium.com/v2/resize:fit:875/0*xmwX3IsJ5KrDoVYn)

### Notify by email and sms to users after registration

Let’s say after completing registration of an user we want to notify the user by email and sms. Sure we can write the corresponding services and call them after registration. Then our code might look like this:
```java
@RabbitListener(queues = {"q.user-registration"})  
public void onUserRegistration(UserRegistrationRequest event) {  
  
    log.info("User Registration Event Received: {}", event);  

    emailService.sendEmail(event.getEmail());  
    smsService.sendSms(event.getMobileNumber());  
}
```

But there is some issue with this approach. Your notification system got tightly coupled with the registration system. If not handled properly, exceptions in the senEmail method might disrupt sms delivery too. You might not want to spend compute resources of the same application that’s doing a heavy task like user registration to do a lightweight task like sending email. What can we do here? RabbitMQ to the rescue.

We will create two queues, annotate our methods with RabbitListener mentioning the designated queues. Then we will create a special type of exchange called FanOut exchange to bound the queues. Speciality of this exchange is: regardless of the routing key, every queue bound to this exchange receives the message.

We need to add the following Bean in our rabbitMQ config.
```java
@Bean  
public Declarables createPostRegistartionSchema(){  
          
    return new Declarables(  
            new FanoutExchange("x.post-registration"),  
            new Queue("q.send-email" ),  
            new Queue("q.send-sms"),  
            new Binding("q.send-email", Binding.DestinationType.QUEUE, "x.post-registration", "send-email", null),  
            new Binding("q.send-sms", Binding.DestinationType.QUEUE, "x.post-registration", "send-sms", null)
        );  
      
}
```

Here in the first line, we declare the exchange, by convention name of exchanges starts with x.

In the next two lines we declared the queues. Then in the last two lines we declared the binding of the queues with this _x.post-registration_ exchange.

After restarting the application go to the **Exchanges** tab of the management portal, you’ll see there is an exchange created with our given name along with the other exchanges.

![](https://miro.medium.com/v2/resize:fit:875/0*kVl8hGR7WvOnI9m2)

Click on that and you’ll see the binding:

![](https://miro.medium.com/v2/resize:fit:875/0*cZaDclUvLCPATG36)

Now I have added two consumers, one for sms and one for email:
```java
@Service  
@Slf4j  
public class SendSmsService {  
    @RabbitListener(queues = "q.send-sms")  
    public void sendSms(UserRegistrationRequest request) {  
        log.info("Sending sms to {} ", request.getMobileNumber());  
    }  
}  
  
@Service  
@Slf4j  
public class SendEmailService {  
  
    @RabbitListener(queues = "q.send-email")  
    public void sendEmail(UserRegistrationRequest request) {  
          
        log.info("Sending email to {}", request.getEmail());  
    }  
}
```
Finally add the following line in the userRegistrationListener:
```java
rabbitTemplate.convertAndSend(“x.post-registration”,””, event);
```
Then restart the application and hit the api, following log should be visible:

![](https://miro.medium.com/v2/resize:fit:875/0*73CFmrD5SKVWWpxc)

Cool right? Submit once and receive in multiple consumers. Now these look properly decoupled.

### Enable graceful retry mechanism

As stated before, registering a user is an extremely complex process. There might raise some exceptions for some cases, and retrying might be a good option for these exceptions. You can give the headache of retrying to rabbitMQ just by throwing that exception. Let’s simulate the scenario:
```java
@RabbitListener(queues = {"q.user-registration"})  
public void onUserRegistration(UserRegistrationRequest event)  {  
    log.info("User Registration Event Received: {}", event);  
    executeRegistration(event);  
    rabbitTemplate.convertAndSend("x.post-registration","", event);  
}  
  
private void executeRegistration(UserRegistrationRequest event) {  
    log.info("Executing User Registration Event: {}", event);  
    throw new RuntimeException("Registration Failed");  
}
```

We are calling the **executeRegistration** method from our listener, and inside this method we are generating a RunTimeException. Now restart the application and hit the api. Wow! Its retrying… problem solved! But wait….. How long will it retry? Well, until the exception goes away. In this case we can change the code and restart, but in the real world this won’t be possible. If the exception keeps occurring we need to stop at some point and also wait between attempts. You did notice that right now it’s retrying too fast right?

To solve that we need to declare two beans. One **SimpleRabbitListenerContainerFactory** and another **RetryOperationsInterceptor** . Then add this interceptor to the listenerContainerFactory’s advice chain.
```java
@Bean  
public RetryOperationsInterceptor retryInterceptor(){  
    return RetryInterceptorBuilder.stateless().maxAttempts(3)  
            .backOffOptions(2000, 2.0, 100000)  
            .build();  
}  
  
@Bean  
public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory(SimpleRabbitListenerContainerFactoryConfigurer configurer) {  
    SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();  
    configurer.configure(factory, cachingConnectionFactory);  
    factory.setAcknowledgeMode(AcknowledgeMode.AUTO);  
    factory.setAdviceChain(retryInterceptor());  
    return factory;  
}
```

Now restart the application and hit the api. It should retry 2 times only after the initial attempt. First after two seconds, second after four seconds.

Here is a catch, naming the bean **rabbitListenerContainerFactory** overrides the default listener container factory. Thus this retry mechanism will get activated for all the listeners. If you don’t want this and want this mechanism only for UserRegistrationListener, do the following. Rename the factory something else.. Like: registrationListenerContainerFactory then mention it in the RabbitListener annotation line this:
```java
@RabbitListener(queues = {"q.user-registration"}, containerFactory = "registrationListenerContainerFactory")
```
Notice that, after the retryer getting exhausted messages are being dropped. Thus, messages will be lost if exceptions keep occurring during retry. This might not be the ideal scenario for many cases. We may want to keep track of the failures for further processing or investigations in the future.

### Add dead letter queue for failed registrations

Dead letter queue is just another queue, what makes it special is when or how we use it. At first we’ll declare a schema for this.
```java
@Bean  
public Declarables createDeadLetterSchema(){  
    return new Declarables(  
        new DirectExchange("x.registration-failure"),  
        new Queue("q.fall-back-registration"),  
        new Binding("q.fall-back-registration", Binding.DestinationType.QUEUE,"x.registration-failure", "fall-back", null)  
    );  
}
```

Just a normal exchange , queue and their binding. I’ve set the routing key as “fall-back” which will be required later.

Now we will configure our **q.user-registration** so that it knows it has a dead letter queue. It’s best to delete the previous queue. Otherwise updated configuration might not reflect.
```java
@Bean  
public Queue createUserRegistrationQueue() {  
  
    return QueueBuilder.durable("q.user-registration")  
        .withArgument("x-dead-letter-exchange","x.registration-failure")  
        .withArgument("x-dead-letter-routing-key","fall-back")  
        .build();  
}
```
Here we declared the queue with dead letter configuration. Arguments are self explanatory here.

One last piece of the puzzle. To make sure rabbitMQ conveys the message to DLX we need to throw an **AmqpRejectAndDontRequeueException** from the listener. But we cannot just throw that now as we are using a retry interceptor. Instead we will tell the retry interceptor to throw this exception when it exhausts. Like this:
```java
@Bean  
public RetryOperationsInterceptor retryInterceptor(){  
    return RetryInterceptorBuilder.stateless().maxAttempts(3)  
            .backOffOptions(2000, 2.0, 100000)  
            .recoverer(new RejectAndDontRequeueRecoverer())  
            .build();  
}
```

Now, we have to add a listener that will receive message to the queue:
```java
@Service  
@Slf4j  
public class FallBackRegistrationService {  
  
    @RabbitListener(queues = {"q.fall-back-registration"})  
    public void onRegistrationFailure(UserRegistrationRequest failedRegistration){  
        log.info("Executing fallback for failed registration {}", failedRegistration);  
  }  
  
}
```
Now restart the application and check the logs. After the entries of retry attempt there will be new line like this:

![](https://miro.medium.com/v2/resize:fit:875/0*7Lx8yV2GbnWMqxy6)

Now it’s up to you what you want to do here. Either you may save it in a db, call some other service, or requeue in another queue.

### Add distributed tracing

That’s the easiest part. Just add sleuth in your dependency and you’ll see trace ids are propagating in all logs.
```xml
<dependency>  
    <groupId>org.springframework.cloud</groupId>  
    <artifactId>spring-cloud-starter-sleuth</artifactId>  
</dependency>
```
This is particularly helpful if different application or micro services are involved.

That’s it for today.

https://github.com/Ruhshan/rabbitmq-spring-demo

---
# RabbitMQ Best Practices. RabbitMQ is an open-source message
[RabbitMQ](https://www.rabbitmq.com/) is an open-source message broker that originally implemented AMQP(Advanced Message Queueing Protocol). Message brokers adhere to protocols for communicating between software systems using well-defined messages.

# WHY use RabbitMQ?

Message queueing enables software applications to connect and scale. Applications can connect and communicate with each other. Messaging is asynchronous, decouple applications by separating sending and receiving data. Message queueing is the embodiment of various software practices to publish/subscribe, asynchronous processing or work queues. It also acts as a temporary message storage until received. RabbitMQ is a message-broker and comes with its pros and cons.

-   **Reliability:** RabbitMQ can be configured to trade-off performance for reliability (Persistence, Acknowledgements, Publisher Confirms and HA). This point can be taken in for both pro and con as there is a trade-off between throughput and reliability.
-   **Flexible** **Routing:** Any message before reaching the queue goes through exchange. Exchanges are responsible for handling the routing of messages and comes in several types (Fanout, Direct, Topic, and Custom Implementation)
-   **Clustering:** RabbitMQ servers on the local network can be clustered together, forming a single logical broker. And many [more . . .](https://www.rabbitmq.com/features.html)

RabbiMQ comes with its advantages and disadvantages. RabbitMQ provides multiple fine-tuning options for best results. While working on it recently, I came across a few which I want to share here and are as follows —

## Connections

RabbitMQ connections require at least 7 TCP packets for handshake. Channels can be opened and closed more frequently if needed. Best practice is to reuse connections and multiplex a connection between threads with channels.

-   AMQP connections: 7 TCP packages
-   AMQP channel: 2 TCP packages
-   AMQP publish: 1 TCP package (more for larger messages)
-   AMQP close channel: 2 TCP packages
-   AMQP close connection: 2 TCP packages
-   Total 14–19 packages (+ Acks)

## **Heartbeat Timeout**

Heartbeats defend against certain network equipment which may terminate ‘_idle’_ TCP connection when there is no activity on them for a certain period of time. The **_heartbeat_timeout_** value defines after what period of time the peer TCP connection should be considered unreachable(down) by RabbitMQ and client libraries. Default value for **_heartbeat_timeout_** is **60 seconds**. The value is negotiated between the client and RabbitMQ server at the time of connection. When both values are non-zero, the lower of the requested values is used.  
Clients send heartbeat frame every **_(heartbeat_timeout / 2)_ seconds**. If two consecutive frames are missed, the peer is considered to be unreachable and the TCP connection is closed. Clients will have to re-connect afterward. A good practice is to keep **_heartbeat_timeout_** between **5 to 20 seconds**. Setting low value can lead to false positives due to transient network congestion, short-lived server flow control, etc.

## **Blocked Connection Timeout**

Blocked connection notifications are sent when the broker is running low on resources(memory or disk). A connection.blocked notification is sent to publishing connections the first time RabbitMQ is low on resources.  
**_blocked_connection_timeout_** value defines after what period of time the peer TCP connection is interrupted and dropped.  
A blocked connection may last for an indefinite period of time, stalling the connection and possibly resulting in hang until the connection is unblocked. **_blocked_connection_timeout_** is intended to interrupt a connection that has been blocked longer than the given timeout value. Best practice is to keep the value between **150 to 300 seconds**.

## **Message Persistence**

The persistence layer has two components: **Queue Index** and **Message Store**. The queue index is responsible for maintaining knowledge about where a given message is in a queue, along with whether it has been delivered and acknowledged. Therefore there is _one queue index per queue_. The message store is a _key-value store_ for messages, shared among all queues in the server. Messages can either be stored directly in the queue index, or written to the message store.  
Under memory pressure, the persistence layer tries to write as much out to disk as possible, and remove as much from memory. Following must remain memory:

-   Each queue maintains metadata for each unacknowledged message. The message itself can be removed from memory if its destination is the message store.
-   The message store needs an index. The default message store index uses a small amount of memory for every message in the store.

If messages are written to queue indices:

-   Messages can be written to disk in one operation rather than two; for small messages, this can be substantial gains. The queue index keeps blocks of a fixed number of records in memory; for not-so-small messages, memory consumption can be substantial. Generally, messages with size **~4096 bytes**(inclusive of headers) are optimum to store in queue indices. RabbitMQ configuration variable to define the size of messages to be written in queue indices is **_queue_index_embed_msgs_below._**
-   Messages stored in queue indices do not require entry in the message store, thus do not have memory cost on that front. Although, unacknowledged messages with destination queue index, are always kept in memory.
-   If a message is routed to multiple queues through an exchange, the message will be written to each queue indices. If such a message is written to the message store, only one copy needs to be written.

If there are any more ways to fine-tune RabbitMQ with better performance and reliability, please reach out. Also please refer to this very helpful blog on [RabbitMQ Common Mistakes](https://www.cloudamqp.com/blog/2018-01-19-part4-rabbitmq-13-common-errors.html).

**Any suggestions or thoughts, let me know:**  
[Insta](https://www.instagram.com/shivama205/) + [Twitter](https://twitter.com/shivama205) + [LinkedIn](https://www.linkedin.com/in/shivama205/) + [Medium](https://medium.com/@shivama205) | [Shivam Aggarwal](https://medium.com/u/6e322c075d30)










# Implementing RabbitMQ HA Cluster on Docker Swarm using Consul-based Discovery

![](https://miro.medium.com/v2/resize:fit:875/1*-gAK0fG63XGl-4-rhmLfuw.png)

Recently, we’ve re-written [_Hepsiburada_](https://www.hepsiburada.com) _BuyBox_ Application, which is receiving high-traffic and concurrent access, in Golang and re-platformed the whole system, including the [RabbitMQ](https://www.rabbitmq.com/) cluster, to [Docker Swarm](https://docs.docker.com/engine/swarm/). After the successful roll out, we applied the same solution to our _Marketplace Order Management System_, as well. We used this infrastructure during this year’s Black Friday, and had zero problems.

In this article, I’ll try to explain how we setup the RabbitMQ cluster inside Docker Swarm, drill down the technical challenges and the solutions we’ve provided to them.

Deploying cluster-based applications (such as RabbitMQ, MongoDB, Elasticsearch), to a container-orchestrating environment, like Docker Swarm, has its unique challenges. There are several [ways](https://www.rabbitmq.com/clustering.html#cluster-formation-options) to set up a RabbitMQ Cluster. But, we will focus on [Consul-based RabbitMQ clustering](https://www.rabbitmq.com/cluster-formation.html#peer-discovery-consul). We will also add [HAProxy](http://www.haproxy.org/) farm to load balance AMQP requests, and to increase the overall availability of the cluster.

In the below diagram, you can see the final logical topology.

![](https://miro.medium.com/v2/resize:fit:875/1*blfjK6gNwZKG3_EKZTd_Dg.png)

So, Let’s get started! 👊

# Step 1: Install Docker and Setup Docker Swarm Cluster

## Installing Docker
```shell
curl -fsSL [https://get.docker.com/](https://get.docker.com/) | sh#Check Version  
docker -v#Expected Output  
Docker version 18.09.0, build 4d60db4
```
## Initializing Docker Swarm Cluster
```shell
#Init Docker Swarm - run on node-1  
docker swarm init --advertise-addr 192.168.0.1#Join Cluster - run on node-2, node-3  
docker swarm join --token SWMTKN-1-dfhjdsgfjkhuiy 192.168.0.1:2377#Promote nodes as manager  
docker node promote node-1  
docker node promote node-2#Check nodes  
docker node ls

#Expected Output  
ID       HOSTNAME STATUS AVAILABILITY MANAGER STATUS  ENGINE VERSION  
te0620 * node1    Ready  Active       Leader          18.09.0  
j0sbfn   node2    Ready  Active       Reachable       18.09.0  
ty9hrq   node3    Ready  Active       Reachable       18.09.0#Create a overlay network  

docker network create --driver=overlay --attachable prod#Check network  
docker network ls

#Expected Output  

NETWORK ID          NAME                DRIVER              SCOPE  
140490c6297a        bridge              bridge              local  
631ac138c4f5        docker_gwbridge     bridge              local  
a28dc1c47bac        host                host                local  
awn0wd58g0nw        ingress             overlay             swarm  
a19559fae5bb        none                null                local  
we17lyjmbpem        **prod**                overlay             swarm
```
# Step 2: Deploy Consul Cluster

## Important notes:

-   Map consul-data to volume, in order to not lose the data.
-   Deploy the Consul service in`global` mode, and manage service-scheduling via node labels
-   _Use two separate networks, one for internal consul traffic, and one for the traffic between RabbitMQ and the Consul services._

## [docker-compose.yml](https://github.com/olgac/consul/blob/master/docker-compose.yml)
```yaml
version: '3.6'  
services:  
  consul:  
    image: consul:1.4.0  
    hostname: "{{.Node.Hostname}}"  
    networks:  
      - consul  
      - prod  
    ports:  
      - 8400:8400  
      - 8500:8500  
      - 8600:53  
    volumes:  
      - consul-data:/consul/data  
    deploy:  
      mode: global  
      placement:  
        constraints: [node.labels.consul == true]  
    command: [ "agent", "-server", "-bootstrap-expect=3", "-retry-max=3", "-retry-interval=10s", "-datacenter=prod", "-join=consul", "-retry-join=consul", "-bind={{ GetInterfaceIP "eth0" }}", "-client=0.0.0.0", "-ui"]  
networks:  
  consul:  
  prod:  
    external: true  
volumes:  
  consul-data:
```
## Initialization script
```shell
wget [https://raw.githubusercontent.com/olgac/consul/master/docker-compose.yml](https://raw.githubusercontent.com/olgac/consul/master/docker-compose.yml)  

docker node update --label-add consul=true node-1  
docker stack deploy -c docker-compose.yml consul#Wait to electing as Consul Leader  

sleep 10
#Then, wake-up Consul on node-2 and node-3  
docker node update --label-add consul=true node-2  
docker node update --label-add consul=true node-3#Check Consul Leader  
curl 192.168.0.1:8500/v1/status/leader#Expected Output  
"10.0.1.9:8300"#Check Consul Peers  
curl 192.168.0.1:8500/v1/status/peers#Expected Output  
[  
  "10.0.1.8:8300",  
  "10.0.1.9:8300",  
  "10.0.1.10:8300"  
]
```

Navigate to [http://192.168.0.1:8500](http://192.168.0.1:8500), to see the **Consul UI** and verify the installation.

![](https://miro.medium.com/v2/resize:fit:875/1*5U43SPCFA2nSm1I5ALfLSA.png)

# Step 3: Deploy RabbitMQ Cluster

## Important Notes:

-   Volume mapping to rabbitmq-data to protect persistent data.
-   Deploy RabbitMQ service in`global` mode, and manage service-scheduling via node labels
-   Use one network (prod) for the internal/external RabbitMQ traffic
-   Don’t share your `RABBITMQ_ERLANG_COOKIE` and `RABBITMQ_DEFAULT_PASS`
-   _Hostname is important, since RabbitMQ uses hostnames as data directories_

## [docker-compose.yml](https://github.com/olgac/rabbitmq/blob/master/docker-compose.yml)
```yaml
version: "3.6"  
services:  
  rabbitmq-01:  
    image: olgac/rabbitmq:3.7.8-management  
    hostname: rabbitmq-01  
    environment:  
      - RABBITMQ_DEFAULT_USER=admin  
      - RABBITMQ_DEFAULT_PASS=Passw0rd  
      - RABBITMQ_ERLANG_COOKIE="MY-SECRET-KEY-123"  
    networks:  
      - prod  
    volumes:  
      - rabbitmq-01-data:/var/lib/rabbitmq  
    deploy:  
      mode: global  
      placement:  
        constraints: [node.labels.rabbitmq1 == true]rabbitmq-02:  
    image: olgac/rabbitmq:3.7.8-management  
    hostname: rabbitmq-02  
    environment:  
      - RABBITMQ_DEFAULT_USER=admin  
      - RABBITMQ_DEFAULT_PASS=Passw0rd  
      - RABBITMQ_ERLANG_COOKIE="MY-SECRET-KEY-123"  
    networks:  
      - prod  
    volumes:  
      - rabbitmq-02-data:/var/lib/rabbitmq  
    deploy:  
      mode: global  
      placement:  
        constraints: [node.labels.rabbitmq2 == true]rabbitmq-03:  
    image: olgac/rabbitmq:3.7.8-management  
    hostname: rabbitmq-03  
    environment:  
      - RABBITMQ_DEFAULT_USER=admin  
      - RABBITMQ_DEFAULT_PASS=Passw0rd  
      - RABBITMQ_ERLANG_COOKIE="MY-SECRET-KEY-123"  
    networks:  
      - prod  
    volumes:  
      - rabbitmq-03-data:/var/lib/rabbitmq  
    deploy:  
      mode: global  
      placement:  
        constraints: [node.labels.rabbitmq3 == true]networks:  
  prod:  
    external: true  
volumes:  
  rabbitmq-01-data:  
  rabbitmq-02-data:  
  rabbitmq-03-data:
```
## [config/enabled_plugins](https://github.com/olgac/rabbitmq/blob/master/config/enabled_plugins)
```shell
[rabbitmq_management,  
rabbitmq_peer_discovery_consul,  
rabbitmq_federation,  
rabbitmq_federation_management,  
rabbitmq_shovel,  
rabbitmq_shovel_management].
```
## [config/rabbitmq.conf](https://github.com/olgac/rabbitmq/blob/master/config/rabbitmq.conf) (by [RabbitMQ Configuration Guide](https://www.rabbitmq.com/configure.html))
```shell
loopback_users.admin = false  
cluster_formation.peer_discovery_backend = rabbit_peer_discovery_consul  
cluster_formation.consul.host = consul  
cluster_formation.node_cleanup.only_log_warning = true  
cluster_formation.consul.svc_addr_auto = true  
cluster_partition_handling = autoheal#Flow Control is triggered if memory usage above %80.  
vm_memory_high_watermark.relative = 0.8#Flow Control is triggered if free disk size below 5GB.  
disk_free_limit.absolute = 5GB
```
## Initialization script
```shell
wget [https://raw.githubusercontent.com/olgac/rabbitmq/master/docker-compose.yml](https://raw.githubusercontent.com/olgac/rabbitmq/master/docker-compose.yml)  
docker node update --label-add rabbitmq1=true node-1  
docker node update --label-add rabbitmq2=true node-2  
docker node update --label-add rabbitmq3=true node-3  
docker stack deploy -c docker-compose.yml rabbitmq
```
## Additional Note

We prefer to reference docker images stored in our private registry instead of the public Docker Hub. You can take the following steps to add the config files to your RabbitMQ image and store it in your own registry.
```shell
git clone [https://github.com/olgac/rabbitmq.git](https://github.com/olgac/rabbitmq.git)  
cd rabbitmqdocker login  
docker image build -t <your-registry>/rabbitmq:3.7.8-management .  
docker push <your-registry>/rabbitmq:3.7.8-management
```
You can write your own docker registry before docker image name and use this image in the docker-compose.yml lines 4, 19 and 36.

# Step 4: Expose RabbitMQ with Deploy HAProxy

## [docker-compose.yml](https://github.com/olgac/rabbitmq/blob/master/docker-compose.yml)
```yaml
version: "3.6"  
services:  
  haproxy:  
    image: olgac/haproxy-for-rabbitmq:1.8.14-alpine  
    ports:  
      - 15672:15672  
      - 5672:5672  
      - 1936:1936  
    networks:  
      - prod  
    deploy:  
      mode: global  
networks:  
  prod:  
    external: true
```
## [config/haproxy.cfg](https://github.com/olgac/haproxy-for-rabbitmq/blob/master/config/haproxy.cfg)
```shell
global  
    log 127.0.0.1   local0  
    log 127.0.0.1   local1 notice  
    maxconn 4096  
   
defaults  
    log     global  
    option  tcplog  
    option  dontlognull  
    timeout connect 6s  
    timeout client 60s  
    timeout server 60s  
   
listen  stats  
    bind *:1936  
    mode http  
    stats enable  
    stats hide-version  
    stats realm Haproxy Statistics  
    stats uri /listen rabbitmq  
    bind   *:5672  
    mode   **tcp**  
    server rabbitmq-01 rabbitmq-01:5672 check  
    server rabbitmq-02 rabbitmq-02:5672 check  
    server rabbitmq-03 rabbitmq-03:5672 checklisten rabbitmq-ui  
    bind   *:15672  
    mode   **http**  
    server rabbitmq-01 rabbitmq-01:15672 check  
    server rabbitmq-02 rabbitmq-02:15672 check  
    server rabbitmq-03 rabbitmq-03:15672 check
```
## Additional Note

Similar to RabbitMQ image, you can add the HAProxy configs to your image, and publish it to your own private registry
```shell
git clone [https://github.com/olgac/haproxy-for-rabbitmq.git](https://github.com/olgac/haproxy-for-rabbitmq.git)  
cd [haproxy-for-rabbitmq](https://github.com/olgac/haproxy-for-rabbitmq.git)docker login  
docker image build -t <your-registry>/haproxy-for-rabbitmq:1.8.14-alpine .  
docker push <your-registry>/haproxy-for-rabbitmq:1.8.14-alpine
```
# Final Step: Verify your RabbitMQ Cluster

Navigate to [http://192.168.0.1:15672](http://192.168.0.1:15672), and enter the predefined credentials (sa and Passw0rd in this tutorial), then you should see the **RabbitMQ Management UI**.

![](https://miro.medium.com/v2/resize:fit:875/1*ZPidzjOzJZ-xb6_PvvBiQQ.png)

And, we should see all HAProxy backend services UP and Running.

-   Check [http://192.168.0.1:1936](http://192.168.0.1:1936)

![](https://miro.medium.com/v2/resize:fit:875/1*tft6ptkLFDeJ32u3qpTWyg.png)

Enjoy!!

---
# Simple Pub-Sub implementation with Spring Boot, Docker, and RabbitMQ

In this tutorial, I want to show you how you can easily set up [RabbitMQ](https://www.rabbitmq.com/) with [docker](https://www.docker.com/) and integrate it into your [Spring application](https://spring.io) to easily implement a pub-sub procedure.

> **Note**: In order to follow this tutorial, you should have some basic knowledge in setting up a Spring Boot application and know how to run a Docker container.

# Publish-Subscribe-Pattern

First, let’s start with some quick fundamentals about the **Publish-Subscribe-Pattern.** The pattern is very simple but powerful. The following image shows the main concept:

![](https://miro.medium.com/v2/resize:fit:875/1*7YOVx_EEdwFbPSqeCAcNsw.png)
Publish-Subscribe-Pattern

We have two actors in this pattern:

-   **Publisher**: Asynchronously sends messages to the queue without worrying about who exactly processes the respective message.
-   **Subscriber**: Subscribes to specific topics or a specific queue and consumes incoming messages.

## Acknowledgment

We don’t care who exactly processes the message but that somebody does it. Therefore we make use of acknowledgment. If you have a use-case where you don’t need every message to be processed, you can skip this and go for a fire-and-forget approach.

**Acknowledgment** in this case means that a subscriber tells the incoming channel that he received the message and processed it. The providing queue therefore no longer needs to send it to other subscribers.

# RabbitMQ setup

Make sure you have Docker installed. If that is the case just open your terminal and type in the following command:

After the [image](https://hub.docker.com/_/rabbitmq) has been successfully started you will be able to communicate with the **RabbitMQ** via standard port **5672**. To access the RabbitMQ management console visit port [**15672**](http://localhost:15672). The default user and password is **guest** for _user_ and also **guest** as the _password_.

# Publisher Spring Boot Application

To set up our project we will be using [**spring initializr**](https://start.spring.io/). Just go for the same setting as I did (see the screenshot below) or use your custom own to fulfill your personal requirements. For this tutorial, we will only need the **Spring for RabbitMQ** and **Spring Web** dependency.

![](https://miro.medium.com/v2/resize:fit:875/1*av6jQiVQwz8Szs_oza0YCQ.png)
Spring initializr screenshot

## Manually adding the dependencies

If you want to use **RabbitMQ** in an already existing Spring Boot application, for [**Gradle**](https://gradle.org/) open up your **build.gradle** and add the following to your dependencies:

**AMQP (Advanced Messaging Query Protocol):**

implementation 'org.springframework.boot:spring-boot-starter-amqp:2.4.2'

**Spring Web**

implementation 'org.springframework.boot:spring-boot-starter-web:2.4.2'

If you are using [**Maven**](https://maven.apache.org/), add the following to your **pom.xml** instead:

**AMQP (Advanced Messaging Query Protocol):**
```xml
<dependency>  
 <groupId>org.springframework.boot</groupId>  
 <artifactId>spring-boot-starter-amqp</artifactId>  
 <version>2.4.2</version>  
</dependency>
```
**Spring Web:**
```xml
<dependency>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-starter-web</artifactId>  
    <version>2.4.2</version>  
</dependency>
```
> **Note**: At the point in time I am writing this tutorial, **2.4.2** is the latest version. There will be probably a newer one available if you are reading this later in time. Just [check](https://mvnrepository.com/artifact/org.springframework.boot) it.

## Adding the configuration

As a real first step for the project, we want to add a decent configuration. Therefore just create a new folder and call it **config**. Inside of this folder create a new **Java** file and call it **RabbitMQConfig:**

As you can see, the configuration is quite simple. We have the identifier **QK_EXAMPLE_QUEUE** which is not more than a key for referencing the respective queue we are setting up starting from **line 28**. Next, the Bean for the `RabbitRemplate`gets defined. It uses the `Jackson2JsonMessageConverter`which provides basic serialization / deserialization of Java objects.

Like already mentioned, the `Queue`object is initialized with a respective key. We can use this key as a reference to publish or subscribe to this specific queue.

## Example Controller

Add a new folder and call it **event**. Next, add a new Java class and call it **DemoEventController**. Add the following code:

The controller implements only one **REST** endpoint _“/event”_. This endpoints just calculates the current time as a String by the `getTimeNowRepresentation` method and combines it with a prefix text to our message to be delivered. We then log this text message to be able to see that the endpoint has been called from our terminal and then call the `RabbitTemplate`. The RabbitTemplate provides us various methods to send messages to our queue. In this case, we want to send out `timeNowRepresentation`message.

The called `convertAndSend`message internally converts our transmitted object to an `Message`object which is then delivered to our queue, referenced by the key we previously defined in our **RabbitMQConfig**. Instead of a String we therefore also could have used another class with multiple variables for example.

## Run the application

Execute the **bootRun** task. Your application should startup. Assuming you are running the Spring Boot application on port 8080, post the following command into your terminal:

Now open your [RabbitMQ management console](http://loacalhost:15672/). Go to the **Queues** tab and click on the **exampleQueue**. If the publishing succeeded you now should see the following:

![](https://miro.medium.com/v2/resize:fit:789/1*9bbhexwvw0iBQT2OiiBXcw.png)
Screenshot of the RabbitMQ manager after publishing the example message

As you can see there is one message ready to be consumed and one in total. But there are zero unacknowledged messages. That’s why be default a “fire and forget” mechanism is implemented where RabbitMQ acknowledges messages as soon as a message gets published into a queue.

## Manual acknowledgment

To make sure that a message gets processed by a consumer we want to set the queue to manual acknowledgment mode.

Therefore open your **application.properties** file and add the following setting:

Delete the queue (**delete -> purge**) in the RabbitMQ management console and restart your spring application.

# Subscriber Spring Boot Application

Just clone the Publisher project we just set up. Delete the **DemoEventController** and add a new class **DemoEventConsumer**:

We define a method to listen for our queue with the `@RabbitListener` tag. Within this tag, we declare our queue identifier. Besides the message that we receive when the method gets invoked, we also get the respective channel and a delivery tag.

## Acknowledgment

Both parameters in combination can be used to manually acknowledge the message. As you can see we first print out the received message. Next, we try to acknowledge the message by using the delivery tag. If the `basicAck`call succeeds the message is set to acknowledged in the RabbitMQ management console. If the method fails and throws an exception the `basicNack` method gets called which rejects the message. Nack is the abbreviation for _negative acknowledgment._

If you’d set the second parameter of both these methods to true, not only the current but all messages up to and including the delivery tag would get acknowledged.

If you’d comment out the try-catch block, you go into your management console and could see that the sent message is unacknowledged:

![](https://miro.medium.com/v2/resize:fit:705/1*sf45nl4yWwvdPzr79dgoOA.png)
RabbitMQ management console Unacknowledged message screenshot

# Result

If everything works as expected, after calling our endpoint from the Publisher endpoint, you now should see an output in the following format in your Consumer application log:

![](https://miro.medium.com/v2/resize:fit:620/1*kkEudbITTk0o6Ps1EhGuNg.png)
Received message in the consumer application

Congratulations! 👏

# Conclusion

In this tutorial, I showed you how to set up a simple publisher-subscriber pattern with RabbitMQ, Spring Boot, and Docker.

I hope you learned something new! If you like, write in the comments what kind of applications you already built with this pattern.

## Embedded Content

docker run --rm -it --hostname demo-tutorial-rabbit -p 15672:15672 -p 5672:5672 rabbitmq:3-management

[view raw](https://gist.github.com/Kaspic/b6c91a71a1fcbaef24134bc71e1d3146/raw/eed1183aeff4d206a183541a3c50d4d5c11e2b0a/docker-command) [docker-command](https://gist.github.com/Kaspic/b6c91a71a1fcbaef24134bc71e1d3146#file-docker-command) hosted with ❤ by [GitHub](https://github.com)

<iframe height="1" width="1" style="position: absolute; top: 0px; left: 0px; border: none; visibility: hidden;"></iframe>

---
```java
package com.example.publisher.config;

import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {

    public static final String QK_EXAMPLE_QUEUE = "exampleQueue";

    @Bean
    public RabbitTemplate jsonRabbitTemplate(ConnectionFactory connectionFactory) {
        RabbitTemplate template = new RabbitTemplate(connectionFactory);
        template.setMessageConverter(jsonConverter());
        return template;
    }

    @Bean
    public MessageConverter jsonConverter() {
        return new Jackson2JsonMessageConverter();
    }

    @Bean
    public Queue exampleQueue() {
        return new Queue(QK_EXAMPLE_QUEUE);
    }
}
```

[view raw](https://gist.github.com/Kaspic/b6c91a71a1fcbaef24134bc71e1d3146/raw/eed1183aeff4d206a183541a3c50d4d5c11e2b0a/RabbitMQConfig.java) [RabbitMQConfig.java](https://gist.github.com/Kaspic/b6c91a71a1fcbaef24134bc71e1d3146#file-rabbitmqconfig-java) hosted with ❤ by [GitHub](https://github.com)

---
```java
package com.example.publisher.event;

import com.example.publisher.config.RabbitMQConfig;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import java.text.SimpleDateFormat;

@Controller
public class DemoEventController {

    private final RabbitTemplate rabbitTemplate;

    public DemoEventController(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    @PostMapping("/event")
    ResponseEntity<Void> postEventMessage() {
        final String timeNowMessage = String.format("%s - %s", "ExampleMessage", getTimeNowRepresentation());
        rabbitTemplate.convertAndSend(RabbitMQConfig.QK_EXAMPLE_QUEUE, timeNowMessage);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    private String getTimeNowRepresentation() {
        long now = System.currentTimeMillis();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("hh:mm:ss");
        return simpleDateFormat.format(now);
    }
}
```

[view raw](https://gist.github.com/Kaspic/b6c91a71a1fcbaef24134bc71e1d3146/raw/eed1183aeff4d206a183541a3c50d4d5c11e2b0a/DemoEventController.java) [DemoEventController.java](https://gist.github.com/Kaspic/b6c91a71a1fcbaef24134bc71e1d3146#file-demoeventcontroller-java) hosted with ❤ by [GitHub](https://github.com)

---

curl -X POST http://localhost:8080/event

[view raw](https://gist.github.com/Kaspic/b6c91a71a1fcbaef24134bc71e1d3146/raw/eed1183aeff4d206a183541a3c50d4d5c11e2b0a/terminal-test-post) [terminal-test-post](https://gist.github.com/Kaspic/b6c91a71a1fcbaef24134bc71e1d3146#file-terminal-test-post) hosted with ❤ by [GitHub](https://github.com)

---
```shell
spring.rabbitmq.listener.simple.acknowledge-mode=manual
```
[view raw](https://gist.github.com/Kaspic/b6c91a71a1fcbaef24134bc71e1d3146/raw/eed1183aeff4d206a183541a3c50d4d5c11e2b0a/application.properties) [application.properties](https://gist.github.com/Kaspic/b6c91a71a1fcbaef24134bc71e1d3146#file-application-properties) hosted with ❤ by [GitHub](https://github.com)

---
```java
package com.example.consumer.event;

import com.example.publisher.config.RabbitMQConfig;
import com.rabbitmq.client.Channel;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;
import java.io.IOException;

@Component
public class DemoEventConsumer {
    @RabbitListener(queues = RabbitMQConfig.QK_EXAMPLE_QUEUE)
    public void onMessageReceived(String message, Channel channel, @Header(AmqpHeaders.DELIVERY_TAG) long tag) throws IOException {
        System.out.println("Message received!: " + message);
        try{
            channel.basicAck(tag, false);
        }catch (Exception e) {
            channel.basicNack(tag, false, true);
        }
    }
}
```
https://gist.github.com/Kaspic
https://gist.github.com/Kaspic/b6c91a71a1fcbaef24134bc71e1d3146/raw/eed1183aeff4d206a183541a3c50d4d5c11e2b0a/DemoEventConsumer.java

[DemoEventConsumer.java](https://gist.github.com/Kaspic/b6c91a71a1fcbaef24134bc71e1d3146#file-demoeventconsumer-java) hosted with ❤ by [GitHub](https://github.com)

---

# RabbitMQ vs kafka: Spring Microservices | Medium

### Introduction

In the realm of distributed systems, the role of message brokers is paramount. They ensure that messages are sent and received between components, enhancing the system’s resilience, decoupling, and scalability. Two of the most popular message brokers in the industry are Kafka and RabbitMQ. If you’re using the Spring ecosystem to build microservices, you may wonder which of these two fits best. In this article, we’ll dive into Kafka and RabbitMQ, compare their features, and see how they integrate with Spring.

### The Role and Significance of Message Brokers in Microservices

### The Essence of Message Brokers

In the digital age, applications are more interconnected than ever. Yet, as systems grow in complexity, ensuring reliable communication between their disparate parts becomes increasingly challenging. This is where message brokers come into play.

A message broker acts as a mediator for various microservices, applications, or systems. Instead of direct point-to-point communication, components transmit messages to the broker, which then routes these messages to their intended recipients. This design ensures that if one part of the system fails, it doesn’t necessarily bring down others. Moreover, it promotes decoupling, wherein components can evolve independently without needing changes to their communication partners. The result? Systems are more resilient, scalable, and maintainable.

### Kafka and RabbitMQ: Titans of the Message Broking World

While there are dozens of message brokers available, Kafka and RabbitMQ have risen to prominence. But why? Simply put, they cater to a broad range of use cases, from simple task distribution to real-time data streaming at scale. Their popularity can be attributed not only to their robust set of features but also to the vast community support and integrations they offer.

### Spring Microservices: The Modern Development Paradigm

The world of software development has seen a significant shift in recent years with the advent of the microservices architecture. Rather than building a monolithic application, developers are now designing systems as a collection of loosely coupled, independently deployable services. The Spring framework, known for its versatility and developer-friendliness, has been at the forefront of this transformation with its Spring Boot and Spring Cloud projects. However, as microservices proliferate, so does the need for effective communication mechanisms between them — hence the relevance of brokers like Kafka and RabbitMQ in the Spring ecosystem.

### Setting the Stage for Comparison

Given their significance in the realm of Spring microservices, it becomes imperative to understand the strengths, weaknesses, and ideal use-cases for Kafka and RabbitMQ. Through this comparison, we aim to equip you with the knowledge to make an informed decision tailored to your specific application needs.

### Kafka Overview

### Birth and Evolution of Kafka

Kafka was born at LinkedIn in 2011 to handle the company’s growing data and activity stream. With the sheer volume of data generated by the platform, LinkedIn required a system that could handle real-time data feeds efficiently. Recognizing its potential beyond LinkedIn’s walls, the company open-sourced Kafka. Since then, Kafka has been handed over to the Apache Software Foundation and has grown exponentially in its capabilities and adoption. It’s not just a message broker anymore; it’s an entire ecosystem dedicated to stream-processing.

### Kafka’s Core Concepts

At its heart, Kafka is built around a few core concepts:

-   **Producers and Consumers:** Producers publish data to topics. Consumers then subscribe to these topics to retrieve this data.
-   **Topics and Partitions:** A topic is a category or feed name to which records are published. Topics in Kafka are split into partitions, which is how Kafka achieves its scalability. Each partition can be hosted on a different server.
-   **Brokers:** A single Kafka server is called a broker. A Kafka cluster is made up of multiple brokers. The distributed nature of these brokers is what gives Kafka its fault-tolerance and reliability.
-   **Logs:** Every partition in Kafka is a log. Messages sent to the partition are appended to the end of these logs. Every message within a partition has an associated unique ID called the offset.

### Kafka’s Strengths in Spring Microservices

-   **High Throughput:** Kafka is designed to handle millions of events per second, catering to systems that require rapid data transmission and processing.
-   **Durability and Reliability:** Messages in Kafka are persisted on disk and can be replicated across multiple brokers. This ensures that data isn’t lost if a broker fails.
-   **Distributed Nature:** Kafka’s architecture is inherently distributed, allowing it to scale horizontally by adding more machines to the cluster.
-   **Stream Processing:** With platforms like Kafka Streams and KSQL, real-time stream processing becomes a breeze, enabling powerful use cases such as real-time analytics.
-   **Spring Integration:** Spring offers the Spring Kafka library, making it incredibly simple to integrate Kafka into Spring Boot applications. This library abstracts much of the complexity, allowing developers to focus on building their microservices without deep-diving into Kafka’s intricate details.

### Popular Use Cases

Given its features, Kafka finds its place in a plethora of applications:

-   **Activity Tracking:** Kafka’s origin at LinkedIn was for activity tracking. It can efficiently track activities of users in real-time.
-   **Real-time Analytics:** Companies use Kafka to gather insights from their data as it’s generated.
-   **Log Aggregation:** By centralizing logs from different sources, system diagnosis and debugging become significantly more manageable.
-   **Stream Processing:** Transforming or reacting to data in real-time is a significant use case for Kafka, especially in environments like financial services.

### RabbitMQ Overview

### The Origins and Growth of RabbitMQ

RabbitMQ, developed in 2007, was created to implement the Advanced Message Queuing Protocol (AMQP). Erlang, a programming language designed for robustness and concurrency, serves as its backbone. RabbitMQ’s mission from the outset was to offer a dependable yet highly interoperable messaging solution. While it has undergone several iterations and improvements over the years, it has always remained true to this goal. The project was eventually acquired by VMware, which further solidified its position in the messaging world.

### Core Concepts of RabbitMQ

RabbitMQ is rich in features and operates on several foundational concepts:

-   **Producers and Consumers:** Similar to Kafka, in RabbitMQ, producers send messages, and consumers receive them. However, RabbitMQ often uses more diverse routing mechanisms.
-   **Exchanges:** Before messages reach queues, they are sent to exchanges. Exchanges are responsible for routing the messages to different queues based on rules and bindings.
-   **Queues:** A queue in RabbitMQ holds the messages sent by producers, awaiting consumption by consumers.
-   **Bindings:** A binding determines how messages are routed from exchanges to queues.
-   **Durable, Temporary, and Auto-delete Queues:** RabbitMQ supports various types of queues to cater to different needs. Durable queues survive server restarts, temporary ones exist until RabbitMQ shuts down, and auto-delete queues are removed once the last consumer unsubscribes.

### RabbitMQ’s Strengths in Spring Microservices

-   **Routing Flexibility:** One of RabbitMQ’s standout features is its extensive routing capabilities. With various exchange types like direct, topic, fanout, and headers, RabbitMQ can handle a multitude of complex routing scenarios.
-   **Reliability:** Features like message acknowledgments, publisher confirms, and message durability ensure that no message is lost in the communication process.
-   **Clustering and High Availability:** RabbitMQ supports clustering out-of-the-box, which facilitates better load distribution and redundancy. With mirrored queues, RabbitMQ can offer high availability.
-   **Management and Monitoring:** RabbitMQ comes with a built-in management UI, allowing for easy monitoring and management of nodes, connections, channels, exchanges, and queues.
-   **Spring Integration:** RabbitMQ’s integration with Spring Boot is smooth, thanks to the Spring AMQP project. This makes implementing RabbitMQ-based solutions in Spring microservices straightforward and efficient.

### Prime Use Cases

Given its unique set of features, RabbitMQ finds its niche in various applications:

-   **Task Distribution:** RabbitMQ is commonly used in scenarios where tasks need to be distributed among multiple workers, ensuring load balancing.
-   **RPC Operations:** Remote Procedure Call (RPC) operations, where a client sends a request and waits for a response, can be efficiently implemented using RabbitMQ.
-   **Complex Routing:** Systems that require elaborate message routing mechanisms heavily benefit from RabbitMQ’s flexible exchange and binding system.
-   **Multi-protocol Support:** RabbitMQ supports a plethora of messaging protocols, not just AMQP, making it suitable for diverse environments.

### Kafka vs. RabbitMQ in Spring Microservices: A Comparison

### Data Throughput and Volume

-   **Kafka:** Designed for high throughput, Kafka handles massive data streams adeptly. When dealing with large-scale data streams, Kafka stands out.
-   **RabbitMQ:** While competent, RabbitMQ caters better to moderate message rates, providing versatility for a mix of throughputs.

### Integration Ease with Spring

-   **Kafka:** Integrating Kafka with Spring Boot is facilitated by the Spring Kafka library. For instance, to produce a message:
```java
@Autowired  
private KafkaTemplate<String, String> kafkaTemplate;  
  
public void sendMessage(String message) {  
    kafkaTemplate.send("topicName", message);  
}
```
And for consuming:
```java
@KafkaListener(topics = "topicName")  
public void listen(String message) {  
    // Handle the message  
}
```
-   **RabbitMQ:** Spring Boot’s integration with RabbitMQ is via the Spring AMQP project. Sending and receiving messages is straightforward:

To send a message:
```java
@Autowired  
private RabbitTemplate rabbitTemplate;  
  
public void sendMsg(String message) {  
    rabbitTemplate.convertAndSend("exchangeName", "routingKey", message);  
}
```
And to consume:
```java
@RabbitListener(queues = "queueName")  
public void consumeMsg(String receivedMsg) {  
    // Process received message  
}
```

### Scalability and Fault Tolerance

-   **Kafka:** Kafka scales horizontally with ease due to its distributed architecture. It also offers high fault tolerance through data replication.
-   **RabbitMQ:** RabbitMQ’s clustering provides good scalability. With mirrored queues, fault tolerance and high availability are assured.

### Routing and Flexibility

-   **Kafka:** Kafka primarily uses a pub-sub model, focusing on topics and partitions.
-   **RabbitMQ:** RabbitMQ’s multiple exchange types and intricate binding options grant it a significant edge in message routing flexibility.

### Ideal Use Cases in Spring Microservices

-   **Kafka:** Best suited for real-time analytics, event sourcing, or high-frequency data streams. Given its real-time processing strengths, Kafka is excellent for dashboards or real-time log monitoring in Spring microservices.
-   **RabbitMQ:** RabbitMQ is ideal for complex routing scenarios, task distribution, or systems with variable message rates. In Spring microservices where tasks need even distribution or involve complicated workflows, RabbitMQ is beneficial.

### Conclusion

The decision between Kafka and RabbitMQ is not a matter of one being universally better than the other. Instead, it comes down to the specific requirements of your Spring microservices application. Both are powerful in their rights, and the best choice depends on your application’s scale, real-time needs, and message routing complexities.

---
# Messaging in a Spring Boot Application with RabbitMQ

### Introduction

In the world of distributed systems and complex software architectures, communication between different components and services is a critical aspect. **Messaging plays a pivotal role in facilitating seamless and asynchronous communication, enabling decoupling between components and ensuring scalability and flexibility.**

Messaging is a communication pattern where applications exchange information through messages, rather than direct method calls or REST API requests. It allows systems to interact and share data in a loosely coupled manner, reducing dependencies and promoting better separation of concerns. In such a system, each application or service acts as both a producer, which sends messages, and a consumer, which receives and processes messages.

[RabbitMQ](https://www.rabbitmq.com/) is a powerful and widely used message broker that serves as a mediator for message communication between applications and services. It implements the _Advanced Message Queuing Protocol_ (AMQP), which is an open-standard application layer protocol for messaging. RabbitMQ efficiently routes messages to the appropriate destinations, decoupling the sender and receiver, and ensuring reliable delivery of messages even in complex and distributed systems.

### Direct Exchange

Direct Exchange is one of the four exchange types (the others are Topic Exchange, Fanout Exchange, and Headers Exchange) provided by RabbitMQ, which is a powerful _message broker_. An _exchange_ in RabbitMQ is responsible for receiving messages from producers and routing them to queues based on certain rules and bindings. The Direct Exchange type, in particular, routes messages to queues based on the exact matching of the _routing key_ specified by the producer when sending the message.

### Key Concepts

1.  **Exchange**: An exchange is a routing component in RabbitMQ that receives messages from producers and routes them to queues based on routing keys.
2.  **Queue**: A queue is a buffer that stores messages until they are consumed by consumers.
3.  **Routing Key**: A routing key is a string attached to the message by the producer. The Direct Exchange uses this routing key to decide which queue(s) should receive the message.

### How Direct Exchange Works

1.  **Binding**: A binding is a link between an exchange and a queue. It specifies a routing key that the exchange will use to determine which queue the message should be routed to.
2.  **Message Routing**: When a producer sends a message to the Direct Exchange, it includes a routing key. The exchange then uses this routing key to look up its bindings and forward the message to the queue(s) that are bound with the matching routing key.
3.  **Exact Matching**: The Direct Exchange performs an exact match between the routing key and the binding key. If there is a binding with a matching routing key, the message is routed to the corresponding queue(s).

### Common Use Cases

The Direct Exchange is commonly used in scenarios where messages need to be selectively delivered to queues based on specific criteria. Some common use cases for Direct Exchange include:

1.  **Task Queues**: Different tasks can be routed to different queues based on their type or priority, allowing different workers to handle specific tasks.
2.  **Point-to-Point Communication**: When multiple consumers compete to process the same type of message, the Direct Exchange ensures that each message is consumed by only one consumer.
3.  **Distributed Systems**: In a distributed system, services can communicate with each other using Direct Exchange to route messages to the appropriate consumers based on the message content.

### Setup RabbitMQ

Setting up and configuring RabbitMQ involves several steps, including installing RabbitMQ, running the server, and setting up exchanges, queues, and bindings. In this section, we will go through the process step by step, along with code examples using Spring Boot.

### RabbitMQ Installation

To get started, you need to install RabbitMQ on your machine. You can download the installation package from the official website ([https://www.rabbitmq.com/download.html](https://www.rabbitmq.com/download.html)) and follow the installation instructions for your operating system.

After installing RabbitMQ, you can start the server. If you installed RabbitMQ via package managers like Homebrew (for macOS) or apt (for Linux), the server will automatically start as a background service.

If you are using Docker, you can run RabbitMQ in a container with the following command:

docker run -d -p 5672:5672 -p 15672:15672 --name rabbitmq rabbitmq:management

The management plugin (enabled with `-p 15672:15672`) provides a web-based UI that allows you to monitor and manage RabbitMQ.

![](https://miro.medium.com/v2/resize:fit:875/0*lC9430RYsxaeZEPu.png)

### Spring Boot Project Setup

Create a new Spring Boot project or use an existing one. Ensure you have the necessary dependencies in your `pom.xml` (if using Maven) or `build.gradle` (if using Gradle) file:

For Maven:
```xml
<dependencies>  
    <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-amqp</artifactId>  
    </dependency>  
    <!-- Add other dependencies as needed -->  
</dependencies>
```
For Gradle:
```xml
dependencies {  
    implementation 'org.springframework.boot:spring-boot-starter-amqp'  
    // Add other dependencies as needed  
}
```

### Implementing Direct Exchange

Let’s begin by creating the configuration class to set up the Direct Exchange, queues, and bindings.
```java
@Configuration  
public class RabbitMQConfig {  
    public static final String DIRECT_EXCHANGE_NAME = "direct-exchange";  
    public static final String QUEUE_1_NAME = "queue-1";  
    public static final String QUEUE_2_NAME = "queue-2";  
    public static final String ROUTING_KEY_1 = "routing-key-1";  
    public static final String ROUTING_KEY_2 = "routing-key-2";  
  
    @Bean  
    DirectExchange directExchange() {  
        return new DirectExchange(DIRECT_EXCHANGE_NAME);  
    }  
  
    @Bean  
    Queue queue1() {  
        return new Queue(QUEUE_1_NAME);  
    }  
  
    @Bean  
    Queue queue2() {  
        return new Queue(QUEUE_2_NAME);  
    }  
  
    @Bean  
    Binding binding1(Queue queue1, DirectExchange directExchange) {  
        return BindingBuilder.bind(queue1).to(directExchange).with(ROUTING_KEY_1);  
    }  
  
    @Bean  
    Binding binding2(Queue queue2, DirectExchange directExchange) {  
        return BindingBuilder.bind(queue2).to(directExchange).with(ROUTING_KEY_2);  
    }  
}
```

In this configuration class, we define the Direct Exchange named “direct-exchange” and two queues named “queue-1” and “queue-2”. We also create bindings between the queues and the exchange with the routing keys “routing-key-1” and “routing-key-2” respectively.

> In RabbitMQ, a binding represents a relationship between an exchange and a queue. It specifies the criteria for routing messages from the exchange to the queue. When a message is sent to an exchange, the exchange uses the routing key and the bindings to determine which queue(s) the message should be routed to. The binding key is matched with the routing key of the message to determine the appropriate destination queue.
> 
> BindingBuilder is a utility class provided by Spring AMQP, which simplifies the process of creating bindings between exchanges and queues. It offers static factory methods to create different types of bindings (direct, topic, headers, and fanout) and associate them with exchanges and queues.

Next, let’s create the message producer component that sends messages to the Direct Exchange with specific routing keys.
```java
@Component  
public class MessageProducer {  
  
    private final RabbitTemplate rabbitTemplate;  
  
    public MessageProducer(RabbitTemplate rabbitTemplate) {  
        this.rabbitTemplate = rabbitTemplate;  
    }  
  
    public void sendMessageToQueue1(String message) {  
        rabbitTemplate.convertAndSend(RabbitMQConfig.DIRECT_EXCHANGE_NAME, RabbitMQConfig.ROUTING_KEY_1, message);  
        System.out.println("Message sent to Queue 1: " + message);  
    }  
  
    public void sendMessageToQueue2(String message) {  
        rabbitTemplate.convertAndSend(RabbitMQConfig.DIRECT_EXCHANGE_NAME, RabbitMQConfig.ROUTING_KEY_2, message);  
        System.out.println("Message sent to Queue 2: " + message);  
    }  
}
```

The `MessageProducer` class uses `RabbitTemplate` to send messages to the Direct Exchange. The method `sendMessageToQueue1` sends a message to "queue-1" with routing key "routing-key-1", while the method `sendMessageToQueue2` sends a message to "queue-2" with routing key "routing-key-2".

Now, let’s create the message consumer component that receives messages from the queues.
```java
@Component  
public class MessageConsumer {  
  
    @RabbitListener(queues = RabbitMQConfig.QUEUE_1_NAME)  
    public void receiveFromQueue1(String message) {  
        System.out.println("Received from Queue 1: " + message);  
    }  
  
    @RabbitListener(queues = RabbitMQConfig.QUEUE_2_NAME)  
    public void receiveFromQueue2(String message) {  
        System.out.println("Received from Queue 2: " + message);  
    }  
}
```

The `MessageConsumer` class uses `@RabbitListener` annotation to listen for messages from "queue-1" and "queue-2". The methods `receiveFromQueue1` and `receiveFromQueue2` receive and process messages from their respective queues.

Let’s test our implementation by sending messages to the Direct Exchange.
```java
@SpringBootApplication  
public class MessagingApplication {  
  
    public static void main(String[] args) {  
        SpringApplication.run(MessagingApplication.class, args);  
    }  
  
    @Bean  
    CommandLineRunner demo(MessageProducer messageProducer) {  
        return args -> {  
            messageProducer.sendMessageToQueue1("Hello from Queue 1!");  
            messageProducer.sendMessageToQueue2("Greetings from Queue 2!");  
        };  
    }  
}
```
In the main Spring Boot application class, we use a `CommandLineRunner` to send messages to the Direct Exchange during application startup.

### Implementing Topic Exchange

In RabbitMQ, a Topic Exchange is a versatile type of exchange that allows for more flexible routing of messages based on the routing key pattern. Messages are routed to queues based on the pattern specified in the binding key. A binding key can contain wildcards (`*` and `###`) to match one or multiple words in the routing key. In this section, we will elaborate on how to implement a Topic Exchange with code examples using Spring Boot.

> A Topic Exchange routes messages to queues based on a pattern in the message’s routing key. The routing key is a string that is attached to the message by the producer.
> 
> Topic Exchange supports two wildcards:
> 
> `*`: It matches exactly one word (a sequence of characters not separated by dots) in the routing key.
> 
> `###`: It matches zero or more words in the routing key.

Let’s start by creating the configuration class to set up the Topic Exchange, queues, and bindings.
```java
@Configuration  
public class RabbitMQConfig {  
    public static final String TOPIC_EXCHANGE_NAME = "topic-exchange";  
    public static final String QUEUE_1_NAME = "queue-1";  
    public static final String QUEUE_2_NAME = "queue-2";  
    public static final String BINDING_KEY_1 = "topic.key.*";  
    public static final String BINDING_KEY_2 = "topic.key.###";  
  
    @Bean  
    TopicExchange topicExchange() {  
        return new TopicExchange(TOPIC_EXCHANGE_NAME);  
    }  
  
    @Bean  
    Queue queue1() {  
        return new Queue(QUEUE_1_NAME);  
    }  
  
    @Bean  
    Queue queue2() {  
        return new Queue(QUEUE_2_NAME);  
    }  
  
    @Bean  
    Binding binding1(Queue queue1, TopicExchange topicExchange) {  
        return BindingBuilder.bind(queue1).to(topicExchange).with(BINDING_KEY_1);  
    }  
  
    @Bean  
    Binding binding2(Queue queue2, TopicExchange topicExchange) {  
        return BindingBuilder.bind(queue2).to(topicExchange).with(BINDING_KEY_2);  
    }  
}
```
Next, let’s create the message producer component that sends messages to the Topic Exchange with different routing keys.
```java
@Component  
public class MessageProducer {  
  
    private final RabbitTemplate rabbitTemplate;  
  
    public MessageProducer(RabbitTemplate rabbitTemplate) {  
        this.rabbitTemplate = rabbitTemplate;  
    }  
  
    public void sendMessageWithBindingKey1(String message) {  
        rabbitTemplate.convertAndSend(RabbitMQConfig.TOPIC_EXCHANGE_NAME, "topic.key.one", message);  
        System.out.println("Message sent with Binding Key 1: " + message);  
    }  
  
    public void sendMessageWithBindingKey2(String message) {  
        rabbitTemplate.convertAndSend(RabbitMQConfig.TOPIC_EXCHANGE_NAME, "topic.key.two.test", message);  
        System.out.println("Message sent with Binding Key 2: " + message);  
    }  
}
```
The `MessageProducer` class uses `RabbitTemplate` to send messages to the Topic Exchange. The method `sendMessageWithBindingKey1` sends a message with routing key "topic.key.one", and the method `sendMessageWithBindingKey2` sends a message with routing key "topic.key.two.test".

Now, let’s create the message consumer component that receives messages from the queues.
```java
@Component  
public class MessageConsumer {  
  
    @RabbitListener(queues = RabbitMQConfig.QUEUE_1_NAME)  
    public void receiveFromQueue1(String message) {  
        System.out.println("Received from Queue 1: " + message);  
    }  
  
    @RabbitListener(queues = RabbitMQConfig.QUEUE_2_NAME)  
    public void receiveFromQueue2(String message) {  
        System.out.println("Received from Queue 2: " + message);  
    }  
}
```
### Message Acknowledgement

In RabbitMQ, message acknowledgment (ack) is an essential mechanism to ensure the reliable delivery of messages to consumers. When a consumer receives a message and successfully processes it, it sends an acknowledgment back to the broker. **If the acknowledgment is not received by the broker, the message will be redelivered to another consumer or requeued.**

To configure message acknowledgment in Spring Boot with RabbitMQ, we need to enable manual acknowledgment mode. This means that the consumer will explicitly acknowledge the message after processing it.
```java
@Component  
public class MessageConsumer {  
  
    @RabbitListener(queues = RabbitMQConfig.QUEUE_NAME)  
    public void receiveMessage(Message message, Channel channel) throws IOException {  
        try {  
            // Process the message  
            System.out.println("Received message: " + new String(message.getBody()));  
  
            // Manually acknowledge the message  
            channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);  
        } catch (Exception ex) {  
            // Log the exception  
            ex.printStackTrace();  
  
            // Reject the message and request requeue  
            channel.basicNack(message.getMessageProperties().getDeliveryTag(), false, true);  
        }  
    }  
}
```
In this example, the `receiveMessage` method receives the message and the `Channel` object from RabbitMQ. We manually acknowledge the message using `channel.basicAck()` after processing it successfully. If an exception occurs during message processing, we reject the message using `channel.basicNack()` and request requeue.

### Handling Message Rejection and Requeue

When a message cannot be processed successfully, the consumer can reject the message and request requeueing. **Requeueing means that the message will be placed back in the queue and will be delivered to another consumer again.** This can lead to an infinite loop if there is a persistent error in message processing.
```java
// Reject the message and request requeue  
channel.basicNack(message.getMessageProperties().getDeliveryTag(), false, true);
```
### Managing Message Persistence

By default, messages in RabbitMQ are _transient_, which means they will be lost if the RabbitMQ server restarts. To ensure message persistence, we can configure the messages to be durable and save them to disk. Durable messages survive server restarts and ensure that important messages are not lost.

To make messages persistent, we need to set the `durable` flag to `true` when defining the queue.
```java
@Configuration  
public class RabbitMQConfig {  
    public static final String QUEUE_NAME = "queue-name";  
  
    // Other bean definitions for exchanges, queues, and bindings  
  
    @Bean  
    public Queue queue() {  
        return new Queue(QUEUE_NAME, true); // Set durable flag to true  
    }  
}
```
In this example, we set the queue “queue-name” to be durable by passing `true` as the second argument to the `Queue` constructor. This ensures that messages in this queue will survive server restarts.

### Configuring Message Time-to-Live (TTL)

Message Time-to-Live (TTL) is a feature in RabbitMQ that allows you to specify a duration for which a message is considered valid before it expires. Once a message’s TTL expires, RabbitMQ will remove the message from the queue, and it will not be delivered to any consumer. This is useful for scenarios where messages have a limited lifespan, and you want to prevent stale messages from being processed.

To configure message TTL in Spring Boot with RabbitMQ, we can set the `expiration` property when publishing a message using the `RabbitTemplate`.
```java
@Component  
public class MessageProducer {  
  
    private final RabbitTemplate rabbitTemplate;  
  
    public MessageProducer(RabbitTemplate rabbitTemplate) {  
        this.rabbitTemplate = rabbitTemplate;  
    }  
  
    public void sendMessageWithTTL(String message, int ttlInMilliseconds) {  
        MessageProperties messageProperties = new MessageProperties();  
        messageProperties.setExpiration(String.valueOf(ttlInMilliseconds));  
  
        rabbitTemplate.convertAndSend(RabbitMQConfig.DIRECT_EXCHANGE_NAME, RabbitMQConfig.ROUTING_KEY, message, messageProperties);  
        System.out.println("Message sent with TTL: " + message);  
    }  
}
```
In this example, the `sendMessageWithTTL` method sets the `expiration` property of `MessageProperties` to the specified TTL value in milliseconds. When we use `rabbitTemplate.convertAndSend()` to publish the message, it will include the TTL value in the message properties.
```java
@Component  
public class MessageConsumer {  
  
    @RabbitListener(queues = RabbitMQConfig.QUEUE_NAME)  
    public void receiveMessage(Message message) {  
        System.out.println("Received message: " + new String(message.getBody()));  
    }  
}
```
n this example, the `MessageConsumer` class simply receives the message and prints its content. The actual TTL processing happens on the broker side.

### Understanding Dead Letter Exchange (DLX)

A Dead Letter Exchange (DLX) is an exchange where messages are sent if they meet certain criteria and are rejected, expired, or unacknowledged by consumers. **DLX provides a way to handle messages that cannot be delivered to their original destination queues**. By redirecting these messages to a DLX, you can implement custom handling for such messages.

To use a Dead Letter Exchange, you need to configure a DLX and a Dead Letter Queue (DLQ) that will receive the rejected or expired messages.
```java
@Configuration  
public class RabbitMQConfig {  
    public static final String DIRECT_EXCHANGE_NAME = "direct-exchange";  
    public static final String QUEUE_NAME = "queue-name";  
    public static final String DLX_NAME = "dlx";  
    public static final String DLQ_NAME = "dlq";  
    public static final String ROUTING_KEY = "routing-key";  
  
    @Bean  
    DirectExchange directExchange() {  
        return new DirectExchange(DIRECT_EXCHANGE_NAME);  
    }  
  
    @Bean  
    Queue queue() {  
        return QueueBuilder.durable(QUEUE_NAME)  
                .withArgument("x-dead-letter-exchange", DLX_NAME)  
                .withArgument("x-dead-letter-routing-key", "")  
                .build();  
    }  
  
    @Bean  
    Queue dlq() {  
        return new Queue(DLQ_NAME);  
    }  
  
    @Bean  
    DirectExchange dlx() {  
        return new DirectExchange(DLX_NAME);  
    }  
  
    @Bean  
    Binding binding() {  
        return BindingBuilder.bind(queue()).to(directExchange()).with(ROUTING_KEY);  
    }  
  
    @Bean  
    Binding dlqBinding() {  
        return BindingBuilder.bind(dlq()).to(dlx()).with("");  
    }  
}
```
In this example, we define a Direct Exchange named “direct-exchange”, a queue named “queue-name”, a Dead Letter Exchange (DLX) named “dlx”, and a Dead Letter Queue (DLQ) named “dlq”. We configure the “queue-name” to have the DLX and DLQ properties using the `withArgument()` method. Messages that are rejected or expire in "queue-name" will be routed to "dlx", and the routing key is empty ("") so that the DLX can route the messages to "dlq".
```java
@Component  
public class MessageConsumer {  
  
    @RabbitListener(queues = RabbitMQConfig.QUEUE_NAME)  
    public void receiveMessage(Message message, Channel channel) throws IOException {  
        try {  
            // Process the message  
            System.out.println("Received message: " + new String(message.getBody()));  
  
            // Manually acknowledge the message  
            channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);  
        } catch (Exception ex) {  
            // Log the exception  
            ex.printStackTrace();  
  
            // Reject the message and send it to DLX  
            channel.basicNack(message.getMessageProperties().getDeliveryTag(), false, false);  
        }  
    }  
}
```
In this example, when an exception occurs during message processing, we reject the message using `channel.basicNack()` without requesting requeue (the third parameter is `false`). This means the message will be routed to the DLX and then to the DLQ for further processing.

### Implementing Fanout Exchange

A Fanout Exchange is a type of exchange that routes messages to all queues bound to it, regardless of the routing key. This means that messages sent to a fanout exchange will be delivered to all connected queues, making it useful for broadcasting messages to multiple consumers.
```java
@Configuration  
public class RabbitMQConfig {  
    public static final String FANOUT_EXCHANGE_NAME = "fanout-exchange";  
    public static final String QUEUE_1_NAME = "queue-1";  
    public static final String QUEUE_2_NAME = "queue-2";  
  
    @Bean  
    FanoutExchange fanoutExchange() {  
        return new FanoutExchange(FANOUT_EXCHANGE_NAME);  
    }  
  
    @Bean  
    Queue queue1() {  
        return new Queue(QUEUE_1_NAME);  
    }  
  
    @Bean  
    Queue queue2() {  
        return new Queue(QUEUE_2_NAME);  
    }  
  
    @Bean  
    Binding binding1(Queue queue1, FanoutExchange fanoutExchange) {  
        return BindingBuilder.bind(queue1).to(fanoutExchange);  
    }  
  
    @Bean  
    Binding binding2(Queue queue2, FanoutExchange fanoutExchange) {  
        return BindingBuilder.bind(queue2).to(fanoutExchange);  
    }  
}
```
In this example, we define a Fanout Exchange named “fanout-exchange” and two queues named “queue-1” and “queue-2”. We create bindings between the queues and the exchange using `BindingBuilder`, without specifying any routing key. This means that all messages sent to the fanout exchange will be delivered to both "queue-1" and "queue-2".
```java
@Component  
public class MessageProducer {  
  
    private final RabbitTemplate rabbitTemplate;  
  
    public MessageProducer(RabbitTemplate rabbitTemplate) {  
        this.rabbitTemplate = rabbitTemplate;  
    }  
  
    public void sendMessageToFanoutExchange(String message) {  
        rabbitTemplate.convertAndSend(RabbitMQConfig.FANOUT_EXCHANGE_NAME, "", message);  
        System.out.println("Message sent to Fanout Exchange: " + message);  
    }  
}
```
In this example, the `sendMessageToFanoutExchange` method sends a message to the Fanout Exchange using `rabbitTemplate.convertAndSend()`. Since we don't specify any routing key (empty string ""), the message will be delivered to all connected queues.
```java
@Component  
public class MessageConsumer {  
  
    @RabbitListener(queues = RabbitMQConfig.QUEUE_1_NAME)  
    public void receiveFromQueue1(String message) {  
        System.out.println("Received from Queue 1: " + message);  
    }  
  
    @RabbitListener(queues = RabbitMQConfig.QUEUE_2_NAME)  
    public void receiveFromQueue2(String message) {  
        System.out.println("Received from Queue 2: " + message);  
    }  
}
```
In this example, the `MessageConsumer` class receives and processes messages from "queue-1" and "queue-2". Since both queues are bound to the Fanout Exchange, they will receive all messages sent to the exchange.

### Monitoring RabbitMQ Metrics

Monitoring RabbitMQ metrics is crucial for gaining insights into the health and performance of your RabbitMQ instance. RabbitMQ provides various metrics related to _message rates_, _queue lengths_, _connection and channel statistics_, etc. Monitoring these metrics can help detect bottlenecks, identify potential issues, and optimize the messaging system.

> RabbitMQ provides a management plugin that exposes an HTTP-based API for retrieving various metrics and managing the RabbitMQ server.
> 
> RabbitMQ metrics include message rates, queue lengths, connection and channel statistics, memory usage, node status, and many more.

First, we need to enable the RabbitMQ management plugin. This can be done by running the following command in the RabbitMQ server:

rabbitmq-plugins enable rabbitmq_management

### Monitoring with Prometheus and Grafana

We can use Prometheus to scrape the RabbitMQ metrics exposed by the management plugin and store them for further analysis. Grafana can be used to visualize and create dashboards for these metrics.

Restart the RabbitMQ server:

```shell
rabbitmq-server restart
```
Access the RabbitMQ management interface by visiting `http://localhost:15672/` in your web browser. The default username and password are both `guest`, but you should change them for production use.

Now that the RabbitMQ management plugin is enabled, we need to configure Prometheus to scrape the exposed metrics. Follow these steps:

-   Open the Prometheus configuration file `prometheus.yml` in a text editor. The default location for this file is usually `/etc/prometheus/prometheus.yml` on Linux systems.
-   Add a new scrape job for RabbitMQ metrics. This involves specifying the RabbitMQ management endpoint and the scrape interval. Insert the following configuration into the `scrape_configs` section of the `prometheus.yml` file:
```yaml
scrape_configs:  
  - job_name: 'rabbitmq'  
    scrape_interval: 15s  
    static_configs:  
      - targets: ['localhost:15672'] ### Replace 'localhost' with the RabbitMQ server's hostname if it's on a different machine.  
    metrics_path: '/api/metrics'  
    params:  
      vhost: ['/'] ### Scrape metrics for all virtual hosts, you can specify specific virtual hosts if needed.  
    scheme: 'http'  
    basic_auth:  
      username: 'your_username' ### Replace with your RabbitMQ management username.  
      password: 'your_password' ### Replace with your RabbitMQ management password.
```
Save the `prometheus.yml` file. Restart Prometheus for the changes to take effect.

### **Verify Metrics Collection**

Once Prometheus is up and running with the new configuration, it will start scraping RabbitMQ metrics at the specified interval. To verify that metrics are being collected, follow these steps:

-   Access the Prometheus web interface by visiting `http://localhost:9090/` in your web browser.
-   In the query box, you can start exploring RabbitMQ metrics. For example, to get the total number of messages published, you can use the following query:

rabbitmq_messages_published_total

Execute the query, and Prometheus will show you the result graph.

### Set Up Grafana for Data Visualization (Optional)

If you want to visualize the metrics collected by Prometheus, you can use Grafana, another popular open-source tool for data visualization and dashboarding. To set up Grafana, follow these steps:

1.  Install Grafana on your system. You can download it from the official website: [https://grafana.com/get](https://grafana.com/get)

2. Access the Grafana web interface by visiting `http://localhost:3000/` in your web browser.

3. Log in using the default credentials (admin/admin), and change the password when prompted.

4. Add Prometheus as a data source in Grafana:

-   Click on “Configuration” in the left-hand sidebar, then “Data Sources.”
-   Click “Add data source.”
-   Select “Prometheus” as the data source type.
-   Enter the URL of your Prometheus server (e.g., `http://localhost:9090/`) and click "Save & Test."

5. Create a dashboard and add panels to visualize the RabbitMQ metrics.

### Configuring Health Indicators for RabbitMQ

Health indicators are essential for monitoring the health of applications and their dependencies. In Spring Boot, we can configure health indicators for RabbitMQ to provide information about the RabbitMQ connection status.

> In Spring Boot, a health indicator is a component that provides information about the health of an application or its dependencies. It returns a status indicating whether the component is up, down, or in an unknown state.

To configure health indicators for RabbitMQ in Spring Boot, we can use the `RabbitHealthIndicator` provided by Spring Boot Actuator.
```java
@Configuration  
public class RabbitMQConfig {  
    // RabbitMQ configuration beans  
}

@Configuration  
public class HealthIndicatorConfig {  
      
    @Bean  
    public RabbitHealthIndicator rabbitHealthIndicator(ConnectionFactory connectionFactory) {  
        return new RabbitHealthIndicator(connectionFactory);  
    }  
}
```
In this example, we create a `RabbitHealthIndicator` bean that takes the RabbitMQ `ConnectionFactory` as a parameter. This health indicator will check the RabbitMQ connection and report its status in the health endpoint.

### Handling Message Retry and DLQ

Handling message retry and Dead Letter Queues (DLQ) is essential for building resilient messaging systems. Message retry allows us to automatically retry processing failed messages, while DLQ provides a way to handle messages that cannot be processed after multiple retries.

To implement message retry and DLQ handling in RabbitMQ, we need to configure retry mechanisms and set up a DLQ.
```java
@Configuration  
public class RabbitMQConfig {  
    public static final String DIRECT_EXCHANGE_NAME = "direct-exchange";  
    public static final String QUEUE_NAME = "queue-name";  
    public static final String DLQ_NAME = "dlq";  
    public static final String ROUTING_KEY = "routing-key";  
  
    @Bean  
    DirectExchange directExchange() {  
        return new DirectExchange(DIRECT_EXCHANGE_NAME);  
    }  
  
    @Bean  
    Queue queue() {  
        return QueueBuilder.durable(QUEUE_NAME)  
                .withArgument("x-dead-letter-exchange", "")  
                .withArgument("x-dead-letter-routing-key", DLQ_NAME)  
                .withArgument("x-message-ttl", 5000) // Set a 5-second TTL for messages in the queue  
                .withArgument("x-max-retries", 3) // Set maximum retry attempts  
                .build();  
    }  
  
    @Bean  
    Queue dlq() {  
        return new Queue(DLQ_NAME);  
    }  
  
    @Bean  
    Binding binding() {  
        return BindingBuilder.bind(queue()).to(directExchange()).with(ROUTING_KEY);  
    }  
}
```

In this example, we define a Direct Exchange named “direct-exchange”, a queue named “queue-name”, and a Dead Letter Queue (DLQ) named “dlq”. We set up the “queue-name” to have a Dead Letter Exchange (empty string “”) and a routing key pointing to the “dlq”. We also set a Time-to-Live (TTL) of 5 seconds for messages in the queue and a maximum of 3 retry attempts.
```java
@Component  
public class MessageConsumer {  
  
    @RabbitListener(queues = RabbitMQConfig.QUEUE_NAME)  
    public void receiveMessage(Message message, Channel channel) throws IOException {  
        try {  
            // Process the message  
            System.out.println("Received message: " + new String(message.getBody()));  
  
            // Manually acknowledge the message  
            channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);  
        } catch (Exception ex) {  
            // Log the exception  
            ex.printStackTrace();  
  
            int retryCount = message.getMessageProperties().getHeader("x-death") == null ? 1 :  
                    (int) message.getMessageProperties().getHeader("x-death").get(0).get("count");  
  
            if (retryCount <= 3) {  
                // Retry the message by rejecting and requeueing  
                channel.basicNack(message.getMessageProperties().getDeliveryTag(), false, true);  
            } else {  
                // Send the message to the Dead Letter Queue (DLQ)  
                channel.basicReject(message.getMessageProperties().getDeliveryTag(), false);  
            }  
        }  
    }  
}
```
In this example, the `MessageConsumer` class receives the message and processes it. If an exception occurs during message processing, we check the number of retry attempts using the "x-death" header. If the retry count is less than or equal to 3, we reject the message and request requeueing (retry). If the retry count exceeds 3, we reject the message without requeueing, and it will be routed to the Dead Letter Queue (DLQ).

### Implementing DLQ for Failed Messages

Implementing a DLQ is essential for handling failed messages gracefully and providing a way to analyze and process them separately from the main queue.

> To implement a Dead Letter Queue for failed messages, we can configure the main queue with DLQ properties using the `x-dead-letter-exchange` and `x-dead-letter-routing-key` arguments. When a message in the main queue is rejected, expired, or fails to be processed after retries, RabbitMQ will move it to the configured Dead Letter Queue.
```java
@Component  
public class MessageConsumer {  
  
    @RabbitListener(queues = RabbitMQConfig.MAIN_QUEUE_NAME)  
    public void receiveMessage(Message message, Channel channel) throws IOException {  
        try {  
            // Process the message  
            System.out.println("Received message: " + new String(message.getBody()));  
  
            // Manually acknowledge the message  
            channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);  
        } catch (Exception ex) {  
            // Log the exception  
            ex.printStackTrace();  
  
            // Reject the message and send it to DLQ  
            channel.basicReject(message.getMessageProperties().getDeliveryTag(), false);  
        }  
    }  
}
```
In this example, the `MessageConsumer` class receives the message and processes it. If an exception occurs during message processing, we reject the message without requeueing, and it will be routed to the Dead Letter Queue (DLQ).

### Retrying Messages with Backoff Strategies

Retrying messages with backoff strategies is a technique used to retry processing failed messages with **increasing delays** between retries. The purpose of using backoff strategies is to prevent excessive retries in case of temporary failures, such as network issues or service unavailability, and to avoid overloading the system with frequent retries.

> A common backoff strategy is **exponential backoff**, where the delay between retries increases exponentially with each retry attempt. This allows the system to recover gradually from failures and eventually gives up retrying if the message cannot be processed successfully.

To implement message retry with exponential backoff strategy, we can use a retry template and customize the retry settings.
```java
@Configuration  
public class RetryConfig {  
  
    @Bean  
    public RetryTemplate retryTemplate() {  
        RetryTemplate retryTemplate = new RetryTemplate();  
  
        // Configure retry policy with exponential backoff  
        ExponentialBackOffPolicy backOffPolicy = new ExponentialBackOffPolicy();  
        backOffPolicy.setInitialInterval(1000); // 1 second initial delay  
        backOffPolicy.setMaxInterval(30000); // 30 seconds maximum delay  
        backOffPolicy.setMultiplier(2); // Exponential factor  
        retryTemplate.setBackOffPolicy(backOffPolicy);  
  
        // Retry up to 5 times  
        retryTemplate.setRetryPolicy(new SimpleRetryPolicy(5));  
  
        return retryTemplate;  
    }  
}
```
In this example, we configure a `RetryTemplate` with an exponential backoff policy using the `ExponentialBackOffPolicy` class. We set the initial interval to 1 second, the maximum interval to 30 seconds, and the multiplier to 2. This means the delay between retries will start at 1 second and double with each retry, up to a maximum of 30 seconds.
```java
@Component  
public class MessageConsumer {  
  
    private final RetryTemplate retryTemplate;  
  
    public MessageConsumer(RetryTemplate retryTemplate) {  
        this.retryTemplate = retryTemplate;  
    }  
  
    @RabbitListener(queues = RabbitMQConfig.MAIN_QUEUE_NAME)  
    public void receiveMessage(Message message, Channel channel) throws IOException {  
        try {  
            // Process the message  
            System.out.println("Received message: " + new String(message.getBody()));  
  
            // Manually acknowledge the message  
            channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);  
        } catch (Exception ex) {  
            // Log the exception  
            ex.printStackTrace();  
  
            // Retry the message with backoff strategy  
            retryTemplate.execute(context -> {  
                channel.basicNack(message.getMessageProperties().getDeliveryTag(), false, true);  
                return null;  
            });  
        }  
    }  
}
```

In this example, the `MessageConsumer` class receives the message and processes it. If an exception occurs during message processing, we use the `retryTemplate` to retry the message using the backoff strategy. The `retryTemplate.execute()` method takes a `RetryCallback` lambda that retries the message by rejecting and requeueing it.

### Message Serialization and Deserialization

Message serialization and deserialization are crucial when sending and receiving messages in a messaging system like RabbitMQ. Messages are usually serialized into a specific format before being sent and deserialized back into objects when received. This allows different applications or services to communicate effectively, even if they use different programming languages or data formats.

To implement message serialization and deserialization, we can use a message converter in Spring Boot with RabbitMQ.
```java
@Configuration  
public class RabbitMQConfig {  
  
    @Bean  
    public MessageConverter messageConverter() {  
        return new Jackson2JsonMessageConverter();  
    }  
}
```
In this example, we configure a `MessageConverter` bean using the `Jackson2JsonMessageConverter`. This converter will serialize Java objects to JSON format when sending messages and deserialize JSON back to Java objects when receiving messages.
```java
@Component  
public class MessageProducer {  
  
    private final RabbitTemplate rabbitTemplate;  
  
    public MessageProducer(RabbitTemplate rabbitTemplate) {  
        this.rabbitTemplate = rabbitTemplate;  
    }  
  
    public void sendMessage(String message) {  
        rabbitTemplate.convertAndSend("direct-exchange", "routing-key", message);  
        System.out.println("Sent message: " + message);  
    }  
}
```
In this example, the `MessageProducer` class sends a message using the `rabbitTemplate.convertAndSend()` method. The message will be serialized to JSON format before sending.
```java
@Component  
public class MessageConsumer {  
  
    @RabbitListener(queues = "main-queue")  
    public void receiveMessage(String message) {  
        System.out.println("Received message: " + message);  
    }  
}
```

In this example, the `MessageConsumer` class receives the message as a string. The `Jackson2JsonMessageConverter` configured in the `RabbitMQConfig` will automatically deserialize the JSON message to a string object.

### Configuring Custom Message Converters

In some scenarios, the default message converters provided by Spring may not be suitable for specific data formats or serialization requirements. In such cases, we can configure custom message converters to handle message serialization and deserialization.

To configure custom message converters, we can implement the `MessageConverter` interface and provide our own logic for converting between messages and objects.
```java
public class CustomMessageConverter implements MessageConverter {  
  
    @Override  
    public Message toMessage(Object object, MessageProperties messageProperties) throws MessageConversionException {  
        // Implement serialization logic here  
        // Convert the object to a message and set message properties  
        return null;  
    }  
  
    @Override  
    public Object fromMessage(Message message) throws MessageConversionException {  
        // Implement deserialization logic here  
        // Convert the message to an object and return it  
        return null;  
    }  
}
```
In this example, we define a custom message converter by implementing the `MessageConverter` interface. We need to provide logic in the `toMessage()` method to convert an object to a message and set message properties, and in the `fromMessage()` method to convert a message back to an object.
```java
@Configuration  
public class RabbitMQConfig {  
  
    @Bean  
    public MessageConverter messageConverter() {  
        return new CustomMessageConverter();  
    }  
}
```
In this example, we configure the custom message converter in the `RabbitMQConfig` class. By defining the `messageConverter()` bean, Spring will use our custom converter for message serialization and deserialization.

### Using Protobuf for Efficient Serialization

[Protocol Buffers](https://protobuf.dev/) (protobuf) is a language-agnostic, efficient, and compact data serialization format developed by Google. It allows for easy and fast serialization of structured data, making it an excellent choice for communication between microservices and systems with strict performance requirements.

To use Protobuf for message serialization and deserialization, we need to define a `.proto` file that describes the data structure and use a protobuf library to generate Java classes based on the `.proto` file.
```shell
syntax = "proto3";  
  
message Person {  
    string name = 1;  
    int32 age = 2;  
}
```
In this example, we define a simple protobuf message `Person` with two fields: `name` of type string and `age` of type int32.

After defining the `.proto` file, we need to use the protobuf compiler (`protoc`) to generate Java classes for the defined message.

> To generate Java classes from the defined protobuf message, you need Install Protobuf Compiler (protoc). You can download the protoc compiler from the official protobuf GitHub repository ([https://github.com/protocolbuffers/protobuf](https://github.com/protocolbuffers/protobuf)) or use package managers like Homebrew on macOS or apt on Linux to install it.

Open a terminal/command prompt and run the following command:
```shell
protoc --java_out=output_directory person.proto
```
Replace `output_directory` with the path where you want the generated Java classes to be stored. The protoc compiler will generate the Java classes based on the defined `Person` message in the `person.proto` file. You should see the generated Java files in the specified output directory.
```shell
`- output_directory  
    - Person.java  
    - PersonOrBuilder.java
```
Now you can use these generated Java classes in your application to serialize and deserialize `Person` messages in Protobuf format.
```java
@Configuration  
public class RabbitMQConfig {  
  
    @Bean  
    public MessageConverter messageConverter() {  
        return new ProtobufMessageConverter();  
    }  
}
```
In this example, we configure the Protobuf message converter in the `RabbitMQConfig` class. The `ProtobufMessageConverter` is provided by the Spring AMQP Protobuf extension, which handles the serialization and deserialization of protobuf messages.
```java
@Component  
public class MessageProducer {  
  
    private final RabbitTemplate rabbitTemplate;  
  
    public MessageProducer(RabbitTemplate rabbitTemplate) {  
        this.rabbitTemplate = rabbitTemplate;  
    }  
  
    public void sendMessage(Person person) {  
        rabbitTemplate.convertAndSend("direct-exchange", "routing-key", person);  
        System.out.println("Sent message: " + person);  
    }  
}
```
In this example, the `MessageProducer` class sends a protobuf message using the `rabbitTemplate.convertAndSend()` method. The Protobuf message converter will automatically serialize the `Person` object to protobuf format before sending.
```java
@Component  
public class MessageConsumer {  
  
    @RabbitListener(queues = "main-queue")  
    public void receiveMessage(Person person) {  
        System.out.println("Received message: " + person);  
    }  
}
```
In this example, the `MessageConsumer` class receives the protobuf message as a `Person` object. The Protobuf message converter will automatically deserialize the protobuf message to a `Person` object.

### Handling Message Versioning and Compatibility

Message versioning and compatibility are crucial when dealing with message-driven systems that involve multiple microservices or components. As the application evolves, changes to message structures may occur, and we need to handle backward and forward compatibility to ensure smooth communication between different versions of services.

> To handle message versioning and compatibility, we can use the following strategies:
> 
> **Versioned Protobuf Messages**: If using protobuf for serialization, we can use versioned `.proto` files and specify fields as optional to maintain backward compatibility.
> 
> **Custom Message Converters**: Implement custom message converters to handle different message versions and adapt them to the current data model.
> 
> **Message Headers**: Include version information in message headers to allow consumers to identify the message version and process it accordingly.
> 
> **Conditional Processing**: Implement conditional processing in message consumers based on the message version.

### **Versioned Protobuf Messages**

To handle versioned Protobuf messages, we can use optional fields in the `.proto` file. This allows us to add new fields to the message without breaking backward compatibility with older versions.
```shell
// person.proto  
syntax = "proto3";  
  
message Person {  
    string name = 1;  
    int32 age = 2;  
    // Optional fields for version 2  
    string address = 3;  
}
```
In this example, we added an optional `address` field to the `Person` message for version 2. Older clients that do not include this field when sending messages will not cause errors since the field is optional.

### Custom Message Converters

Implementing custom message converters allows us to handle different message versions and adapt them to the current data model.
```java
public class CustomMessageConverter implements MessageConverter {  
  
    @Override  
    public Message toMessage(Object object, MessageProperties messageProperties) throws MessageConversionException {  
        // Implement serialization logic for different message versions  
        // Convert the object to a message and set message properties  
        return null;  
    }  
  
    @Override  
    public Object fromMessage(Message message) throws MessageConversionException {  
        // Implement deserialization logic for different message versions  
        // Convert the message to an object and return it  
        return null;  
    }  
}
```
In this example, we implement the `MessageConverter` interface to create a custom message converter. Inside the `toMessage()` and `fromMessage()` methods, we can handle serialization and deserialization of different message versions based on their content and message properties.

### Message Headers

Including version information in message headers allows consumers to identify the message version and process it accordingly.
```java
public void sendMessage(Person person) {  
    MessageHeaders headers = new MessageHeaders(Collections.singletonMap("version", 2));  
    Message<Person> message = new GenericMessage<>(person, headers);  
    rabbitTemplate.convertAndSend("direct-exchange", "routing-key", message);  
    System.out.println("Sent message: " + person);  
}
```
In this example, we use Spring’s `MessageHeaders` to include the version information (in this case, version 2) when sending a message. Consumers can then read the version information from the message headers and handle the message accordingly.

### Conditional Processing

Implementing conditional processing in message consumers based on the message version allows us to handle different versions of the message appropriately.
```java
@Component  
public class MessageConsumer {  
  
    @RabbitListener(queues = "main-queue")  
    public void receiveMessage(Message<Person> message) {  
        MessageHeaders headers = message.getHeaders();  
        int version = (int) headers.getOrDefault("version", 1);  
  
        if (version == 1) {  
            // Handle message for version 1  
            Person person = message.getPayload();  
            System.out.println("Received message (Version 1): " + person);  
        } else if (version == 2) {  
            // Handle message for version 2  
            PersonV2 personV2 = (PersonV2) message.getPayload();  
            System.out.println("Received message (Version 2): " + personV2);  
        }  
    }  
}
```
In this example, the `MessageConsumer` class receives a message and extracts the version information from the message headers. Based on the version, it conditionally processes the message using different classes (`Person` for version 1 and `PersonV2` for version 2) to handle different versions of the message.

### Load Balancing and Message Partitioning

Load balancing and message partitioning are important strategies used in messaging systems to distribute message processing among multiple consumers and achieve better scalability and performance. These techniques ensure that messages are efficiently handled by consumers, especially in _high-load scenarios,_ preventing any single consumer from becoming a bottleneck.

> Load balancing is the process of distributing incoming messages across multiple consumers. It aims to ensure that each consumer in the system gets a fair share of messages to process, thereby utilizing the available resources efficiently.
> 
> Message partitioning involves dividing messages into multiple partitions based on certain criteria. Each partition is then processed by a specific consumer or a group of consumers. This helps improve parallelism and allows for efficient message processing in distributed systems.

To implement load balancing, we can use a Fanout Exchange in RabbitMQ. A Fanout Exchange routes messages to all bound queues, ensuring that each consumer receives a copy of every message published to the exchange. (see example provided earlier)

To implement message partitioning, we can use a Direct Exchange in RabbitMQ. A Direct Exchange routes messages to queues based on the exact match of the routing key.
```java
@Component  
public class MessageProducer {  
  
    private final RabbitTemplate rabbitTemplate;  
  
    public MessageProducer(RabbitTemplate rabbitTemplate) {  
        this.rabbitTemplate = rabbitTemplate;  
    }  
  
    public void sendMessage(String message, String partitionKey) {  
        rabbitTemplate.convertAndSend("direct-exchange", partitionKey, message);  
        System.out.println("Sent message: " + message + " with partition key: " + partitionKey);  
    }  
}
```

In this example, the `MessageProducer` class sends a message using the `rabbitTemplate.convertAndSend()` method with a specific partition key. The Direct Exchange will route the message to the queue that is bound with the matching routing key.
```java
@Component  
public class MessageConsumer1 {  
  
    @RabbitListener(queues = "partition-queue1")  
    public void receiveMessage(String message) {  
        System.out.println("Consumer 1 Received message: " + message);  
    }  
}

@Component  
public class MessageConsumer2 {  
  
    @RabbitListener(queues = "partition-queue2")  
    public void receiveMessage(String message) {  
        System.out.println("Consumer 2 Received message: " + message);  
    }  
}
```
In this example, we have two consumers (`MessageConsumer1` and `MessageConsumer2`) listening to different queues (`partition-queue1` and `partition-queue2`) with different routing keys. The `sendMessage()` method in `MessageProducer` allows us to specify the partition key, which determines which queue will receive the message, effectively achieving message partitioning.

### Load Balancing Strategies

In the context of messaging systems, load balancing is particularly important when dealing with high message volumes or a large number of consumers. Efficient load balancing helps maintain system performance, scalability, and responsiveness.

There are several load balancing strategies commonly used in messaging systems:

### Fanout Exchange

The Fanout Exchange is one of the simplest load balancing strategies. It broadcasts incoming messages to all bound queues. This means that each consumer will receive a copy of every message published to the exchange. The Fanout Exchange is useful when you want to distribute the workload across multiple consumers, and each consumer needs to process all messages.

### Direct Exchange

The Direct Exchange routes messages to queues based on exact matches of the routing key. Each message is sent to the queue that has a binding with the same routing key as the message’s routing key. This allows for more fine-grained control over message routing and enables load balancing based on specific message characteristics.

### Consistent Hash Exchange

The Consistent Hash Exchange routes messages to queues based on a hash value calculated from the message properties or content. Messages with the same properties or content will always be routed to the same queue. This strategy allows for sticky message routing, ensuring that related messages are consistently handled by the same consumer.

### Round-Robin

In a Round-Robin load balancing strategy, each message or request is sequentially distributed to the next available consumer in a circular manner. This ensures that all consumers get an equal share of the workload over time. Round-Robin is straightforward to implement and can be effective for scenarios where all consumers have similar processing capabilities.

### Weighted Load Balancing

Weighted Load Balancing assigns a weight or priority to each consumer, indicating its processing capacity or capability. Messages are then distributed to consumers based on their assigned weights. This strategy allows for fine-tuning the distribution of the workload based on the performance characteristics of individual consumers.

### Least Connections

In a Least Connections load balancing strategy, messages are directed to the consumer with the fewest active connections. This helps in distributing the load evenly based on the current utilization of each consumer.

Choosing the appropriate load balancing strategy depends on the specific requirements of your messaging system. Factors such as the number of consumers, message volume, processing capabilities of consumers, and the nature of message processing all play a role in determining the most suitable load balancing strategy.

### Implementing Consumer Load Balancing

Consumer load balancing involves distributing incoming messages among multiple consumers to achieve better scalability and efficient message processing. The goal is to prevent any single consumer from becoming overwhelmed with messages while ensuring that all consumers share the message processing workload.

To implement consumer load balancing with Spring AMQP, we can use the Direct Exchange and have multiple consumers listening to the same queue. The Direct Exchange will then distribute messages among these consumers in a round-robin manner.
```java
@Component  
public class LoadBalancedMessageConsumer1 {  
  
    @RabbitListener(queues = "queue.load.balanced")  
    public void receiveMessage(String message) {  
        System.out.println("Consumer 1 Received message: " + message);  
    }  
}

@Component  
public class LoadBalancedMessageConsumer2 {  
  
    @RabbitListener(queues = "queue.load.balanced")  
    public void receiveMessage(String message) {  
        System.out.println("Consumer 2 Received message: " + message);  
    }  
}
```

In this example, both `LoadBalancedMessageConsumer1` and `LoadBalancedMessageConsumer2` are listening to the same queue named "queue.load.balanced." The Direct Exchange will distribute incoming messages to these consumers in a round-robin manner, ensuring a balanced workload.

### Message Deduplication and Idempotence

Message deduplication and idempotence are techniques used to ensure that messages are not processed _multiple times_, even if they are delivered more than once.

> Message deduplication involves identifying duplicate messages and preventing their reprocessing. This is important to maintain data integrity and prevent redundant operations.
> 
> Idempotence ensures that processing a message multiple times has the same effect as processing it once. Even if a message is delivered more than once, the resulting state or outcome remains the same.

Implementing message deduplication and idempotence can involve different strategies depending on the messaging system and requirements. Some techniques include using **unique message IDs**, **maintaining message processing state**, or using **idempotent processing logic**.

Here’s a simple example of handling idempotent processing using a cache to track processed message IDs:
```java
@Component  
public class IdempotentMessageConsumer {  
  
    private Set<String> processedMessageIds = new HashSet<>();  
  
    @RabbitListener(queues = "queue.idempotent")  
    public void receiveMessage(String message, @Header(AmqpHeaders.MESSAGE_ID) String messageId) {  
        if (!processedMessageIds.contains(messageId)) {  
            // Process the message  
            System.out.println("Received message: " + message);  
  
            // Mark message as processed  
            processedMessageIds.add(messageId);  
        } else {  
            // Message already processed  
            System.out.println("Skipping duplicate message: " + message);  
        }  
    }  
}
```

In this example, the `IdempotentMessageConsumer` maintains a set of processed message IDs. When a new message is received, it checks if the message ID is already in the set. If it's not, the message is processed, and its ID is added to the set to track that it has been processed. If the message ID is already in the set, it means the message is a duplicate, and it is skipped to ensure idempotent processing.

### Best Practices and Common Pitfalls

### Avoiding Message Loss

Message loss can occur if messages are not durable or if there are issues with message acknowledgments. To avoid message loss, consider the following best practices:

-   Use _durable queues_ and exchanges to ensure messages survive server restarts.
-   Configure the appropriate message _acknowledgment_ mode (auto, manual, or none) based on the required reliability.
-   Implement _retry_ mechanisms for failed message processing to prevent message loss due to transient errors.

### Configuring Proper Queue Settings

Proper queue settings are crucial for the performance and behavior of message processing. Some best practices include:

-   Set appropriate queue properties like `durable`, `exclusive`, `auto-delete` based on the queue's use case and requirements.
-   Configure message TTL (Time-To-Live) to automatically remove stale messages from the queue.
-   Define appropriate queue size limits and implement message purging strategies to prevent queue overflow.

### Handling Backpressure and Throttling

Backpressure and throttling mechanisms are essential to handle message overload and prevent system overload. Consider these best practices:

-   Implement _rate limiting_ and _message batching_ to control the message flow.
-   Monitor _queue length_ and _consumer processing rates_ to detect and handle backpressure situations.
-   Implement _circuit breakers_ or _retry_ strategies to gracefully handle message overload and prevent system crashes.

### Microservices Communication with RabbitMQ

RabbitMQ plays a significant role in microservices communication. Best practices include:

-   Use RabbitMQ for asynchronous communication between microservices to decouple components and improve scalability.
-   Define clear message _schemas_ and _versioning_ strategies to ensure backward compatibility.
-   Consider using direct or topic exchanges to route messages between microservices based on specific routing keys or patterns.

### Event-Driven Architecture with RabbitMQ

Event-driven architecture is well-suited for RabbitMQ. Best practices include:

-   Use RabbitMQ as an _event bus_ to publish and subscribe to events across the system.
-   Implement _event sourcing_ and _CQRS_ (Command Query Responsibility Segregation) patterns for data consistency.
-   Apply durable and idempotent event processing to maintain system integrity.

### Handling High-Volume Message Streams

For systems dealing with high message volumes, consider the following practices:

-   Use RabbitMQ’s _clustering_ and _load balancing_ capabilities to distribute the message processing load.
-   Optimize network settings and system resources to handle high message throughput.
-   Implement message _sharding_ or _partitioning_ to parallelize message processing.

### Troubleshooting and Debugging

When troubleshooting RabbitMQ issues, consider the following techniques:

-   Enable RabbitMQ server logs and monitor for errors or warnings. To enable logs rdit the RabbitMQ configuration file (`rabbitmq.conf`) and set the log level:

log.level = debug  
  
// Restart the RabbitMQ server to apply the changes.

-   Use tools like _Wireshark_ to inspect network traffic between clients and the broker.
-   Enable RabbitMQ Management Plugin to view queue _statistics_ and monitor message flow.

To debug message flow and routing in RabbitMQ, consider the following:

-   Use RabbitMQ’s _tracing_ feature to log messages at different points in the broker.
-   Inspect the message _headers_ and _routing keys_ to understand how messages are routed between exchanges and queues.

### Performance Optimization

To optimize RabbitMQ performance, consider the following practices:

-   Configure _connection pooling_ to efficiently manage connections to the broker.
-   Fine-tune consumer settings, such as _prefetch count_ and _concurrency_, for optimal message processing.
-   Benchmark and profile the RabbitMQ system to identify bottlenecks and areas for improvement.

### Configuring Connection Pooling

Using connection pooling can significantly improve RabbitMQ performance. Consider using libraries like `spring-rabbit` in Spring Boot to manage connections effectively.

### Fine-Tuning Consumer Settings

Fine-tune consumer settings, such as `prefetch count` and `concurrency`, based on the message processing requirements and system resources.

### Benchmarking and Profiling

Perform benchmarking and profiling to identify performance bottlenecks in the RabbitMQ system. Tools like JProfiler or [VisualVM](https://visualvm.github.io/) can be used for profiling Java applications using RabbitMQ.

### Conclusion

In this comprehensive article, we explored the world of messaging with RabbitMQ and how it can be seamlessly integrated with Spring Boot applications. RabbitMQ, an AMQP-based message broker, offers a robust and flexible solution for decoupling components and enabling efficient communication between different parts of a distributed system.

As learners continue their exploration of RabbitMQ, they will discover its vast capabilities and how it serves as a key player in the messaging landscape. With its rich documentation, active community, and extensive resources available, RabbitMQ continues to be a go-to solution for developers looking to harness the power of messaging in their applications.

Happy messaging with RabbitMQ and Spring Boot!

### Further Learning

Here are some links to further reading, documentation, and relevant tools to continue exploring RabbitMQ and messaging concepts:

### RabbitMQ Official Website

-   Website: [https://www.rabbitmq.com/](https://www.rabbitmq.com/)
-   RabbitMQ is the official messaging broker that provides in-depth documentation, tutorials, and guides.

### Spring AMQP Documentation

-   Website: [https://docs.spring.io/spring-amqp/docs/current/reference/html/](https://docs.spring.io/spring-amqp/docs/current/reference/html/)
-   Spring AMQP is the Spring project that provides integration with RabbitMQ. The documentation offers detailed information on using RabbitMQ with Spring.

### RabbitMQ Management Plugin

-   Website: [https://www.rabbitmq.com/management.html](https://www.rabbitmq.com/management.html)
-   The RabbitMQ Management Plugin provides a web-based interface to monitor and manage RabbitMQ. It offers valuable insights into queues, exchanges, and message rates.

### AMQP 0–9–1 Model Explained

-   Website: [https://www.rabbitmq.com/tutorials/amqp-concepts.html](https://www.rabbitmq.com/tutorials/amqp-concepts.html)
-   This tutorial explains the AMQP 0–9–1 model, which is the protocol used by RabbitMQ.

### RabbitMQ Tutorials

-   Website: [https://www.rabbitmq.com/getstarted.html](https://www.rabbitmq.com/getstarted.html)
-   RabbitMQ offers a series of well-explained tutorials to get started with RabbitMQ, covering different use cases and concepts.

### RabbitMQ GitHub Repository

-   GitHub: [https://github.com/rabbitmq/rabbitmq-server](https://github.com/rabbitmq/rabbitmq-server)
-   The RabbitMQ GitHub repository contains the source code for RabbitMQ. It can be helpful for exploring the inner workings of the broker.

### RabbitMQ Best Practices

-   Website: [https://www.rabbitmq.com/blog/2017/11/29/when-to-use-rabbitmq-or-apache-kafka/](https://www.rabbitmq.com/blog/2017/11/29/when-to-use-rabbitmq-or-apache-kafka/)
-   This blog post compares RabbitMQ with Apache Kafka and provides insights on when to use each messaging system.

### RabbitMQ and Spring Boot Example Project

-   GitHub: [https://github.com/spring-guides/gs-messaging-rabbitmq](https://github.com/spring-guides/gs-messaging-rabbitmq)
-   This GitHub repository contains a Spring Boot example project demonstrating RabbitMQ integration.

### RabbitMQ Community Mailing List

-   Website: [https://groups.google.com/g/rabbitmq-users](https://groups.google.com/g/rabbitmq-users)
-   The RabbitMQ community mailing list is an active forum where users can ask questions, seek help, and share their experiences with RabbitMQ.

### Monitoring RabbitMQ with Prometheus and Grafana

-   Website: [https://www.rabbitmq.com/prometheus.html](https://www.rabbitmq.com/prometheus.html)
-   This tutorial explains how to monitor RabbitMQ using Prometheus and Grafana, providing insights into broker performance.

### RabbitMQ on Docker Hub

-   Docker Hub: [https://hub.docker.com/_/rabbitmq](https://hub.docker.com/_/rabbitmq)
-   RabbitMQ is available as a Docker image. This link provides details on how to run RabbitMQ using Docker containers.

These resources will help learners deepen their understanding of RabbitMQ, messaging concepts, and best practices for building robust and scalable messaging systems. Happy learning!

---
# Mastering Microservices: Integrating RabbitMQ with Spring Boot for Seamless Communication 

### Introduction:

Microservices architecture has become a cornerstone in modern software development due to its agility and scalability. In this tutorial, we’ll delve into a detailed example of a Spring Boot application illustrating the advantages of utilizing RabbitMQ as a message broker for asynchronous communication between microservices. Additionally, we’ll explore how to store data in a PostgreSQL database and containerize the entire setup using Docker.

### Why RabbitMQ in Microservices?

Microservices often need to communicate asynchronously to ensure loose coupling between components. Message brokers, like RabbitMQ, provide a reliable and scalable solution for managing communication between microservices. RabbitMQ supports the Advanced Message Queuing Protocol (AMQP) and offers features such as message acknowledgment, routing, and publish/subscribe mechanisms.

### Sample Spring Boot Application (Producer):

Let’s start by creating a Spring Boot application that acts as a producer. This application exposes a REST endpoint to receive product data and sends it to RabbitMQ.

### 1. Spring Boot Application (Producer):
```java
// Product.java  
public class Product {  
    private Long id;  
    private String name;  
    private LocalDate date;  
    private BigDecimal price;  
  
    // Getters and setters  
}  
  
// ProductController.java  
@RestController  
@RequestMapping("/products")  
public class ProductController {  
    private final RabbitTemplate rabbitTemplate;  
  
    @Autowired  
    public ProductController(RabbitTemplate rabbitTemplate) {  
        this.rabbitTemplate = rabbitTemplate;  
    }  
  
    @PostMapping  
    public ResponseEntity<String> createProduct(@RequestBody Product product) {  
        rabbitTemplate.convertAndSend("product-exchange", "product", product);  
        return ResponseEntity.ok("Product sent to RabbitMQ");  
    }  
}
```
### 2. Spring Boot Application (Consumer):
```java
// ProductConsumer.java  
@Service  
public class ProductConsumer {  
    private final ProductService productService;  
  
    @Autowired  
    public ProductConsumer(ProductService productService) {  
        this.productService = productService;  
    }  
  
    @RabbitListener(queues = "product-queue")  
    public void receiveProduct(Product product) {  
        productService.saveProduct(product);  
    }  
}  
  
// ProductService.java  
@Service  
public class ProductService {  
    private final ProductRepository productRepository;  
  
    @Autowired  
    public ProductService(ProductRepository productRepository) {  
        this.productRepository = productRepository;  
    }  
  
    public void saveProduct(Product product) {  
        productRepository.save(product);  
    }  
}
```
### 3. Dockerfiles:
```Dockerfile
### Dockerfile.rabbitmq  
FROM rabbitmq:management  
### Additional configurations if needed  
  
### Dockerfile.postgres  
FROM postgres:latest  
### Additional configurations if needed
```
### 4. Docker Compose File (`docker-compose.yml`):
```yaml
version: '3.8'  
  
services:  
  rabbitmq:  
    build:  
      context: .  
      dockerfile: Dockerfile.rabbitmq  
    ports:  
      - "5672:5672"  
      - "15672:15672"  
    networks:  
      - my_network  
  
  postgres:  
    build:  
      context: .  
      dockerfile: Dockerfile.postgres  
    environment:  
      POSTGRES_DB: my_database  
      POSTGRES_USER: my_user  
      POSTGRES_PASSWORD: my_password  
    ports:  
      - "5432:5432"  
    networks:  
      - my_network  
  
networks:  
  my_network:
```
### 5. Creating a queue on RabbitMQ

###!/bin/bash  
```shell
RABBITMQ_USERNAME="guest"  
RABBITMQ_PASSWORD="guest"  
RABBITMQ_HOST="localhost"  
RABBITMQ_PORT="15672"  
QUEUE_NAME="product-queue"  
  
### Function to create a RabbitMQ queue using Management HTTP API  
create_queue() {  
  curl -i -u "$RABBITMQ_USERNAME:$RABBITMQ_PASSWORD"   
    -H "content-type:application/json"   
    -X PUT   
    -d '{"auto_delete":false,"durable":true}'   
    "http://$RABBITMQ_HOST:$RABBITMQ_PORT/api/queues/%2F/$1"  
}  
  
### Call the function with the desired queue name  
create_queue "$QUEUE_NAME"
```
### 5. Run the Applications:

-   Build and run the Spring Boot applications.
-   Build Docker images and run containers using `docker-compose up`.

### Advantages of Using RabbitMQ in Microservices:

1.  Decoupling: RabbitMQ facilitates loose coupling between microservices by enabling asynchronous communication. Microservices can communicate without being directly dependent on each other’s availability.
2.  Scalability: As the number of microservices grows, RabbitMQ can efficiently handle a large volume of messages, ensuring scalability in a distributed environment.
3.  Reliability: RabbitMQ provides features like message acknowledgment and persistence, ensuring reliable message delivery even in the face of failures.
4.  Flexibility: The publish/subscribe model and routing mechanisms in RabbitMQ offer flexibility in designing communication patterns tailored to specific microservices’ needs.
5.  Containerization with Docker: Dockerizing RabbitMQ and PostgreSQL simplify deployment, ensures consistency across environments and facilitates scalability.

### Conclusion:

RabbitMQ proves to be a robust choice for enabling communication in microservices architectures. By adopting RabbitMQ and PostgreSQL, developers can design scalable, flexible, and reliable systems that effectively handle asynchronous communication between microservices. Docker further enhances deployment and scalability, making it easier to manage the entire ecosystem.

---
# Spring Integration, Messaging and Integration Patterns

Hey there! Welcome to our programming guide on Spring Integration, Messaging, and Integration Patterns. As a developer, you know that integrating different systems and services can be a challenging task. That’s where Spring Integration comes in. In this article, we’ll explore the basics of Spring Integration, messaging, and integration patterns to help you build more robust and efficient applications.

What is Spring Integration?  
Spring Integration is a module of the Spring framework that provides a powerful way to integrate different systems and services into your application. It allows you to decouple the various parts of your system and make them communicate with each other through messaging. With Spring Integration, you can easily build message-driven applications using a variety of protocols such as JMS (Java Message Service), AMQP (Advanced Message Queuing Protocol), and more.

Spring Integration provides several benefits over traditional integration methods:

1.  Decoupling: Spring Integration allows you to decouple the various parts of your system, making it easier to change or replace individual components without affecting the rest of the application.
2.  Scalability: With Spring Integration, you can easily scale your application by adding more nodes to your integration infrastructure.
3.  Flexibility: Spring Integration supports a wide range of messaging protocols and technologies, making it easy to integrate with different systems and services.
4.  Ease of use: Spring Integration provides a simple and intuitive API that makes it easy to build and maintain message-driven applications.

Messaging in Spring Integration  
Messaging is a fundamental concept in Spring Integration. It allows you to send and receive messages between different parts of your application, making it easier to integrate with other systems and services. In Spring Integration, messaging is built on top of the JMS (Java Message Service) specification, which provides a standard way to send and receive messages.

There are several types of messaging in Spring Integration:

1.  Point-to-Point Messaging: This type of messaging involves sending a message from one component to another. It’s useful for building applications that require real-time communication between different parts of the system.
2.  Publish-Subscribe Messaging: This type of messaging involves publishing messages to multiple subscribers. It’s useful for building applications that require broadcasting messages to multiple components.
3.  Request-Reply Messaging: This type of messaging involves sending a request message from one component and receiving a reply message from another component. It’s useful for building applications that require synchronous communication between different parts of the system.

Integration Patterns in Spring Integration  
Spring Integration provides several integration patterns to help you build more robust and efficient applications. These patterns are based on the principles of messaging and decoupling, making it easier to integrate with other systems and services.

1.  Gateway: A gateway is a component that acts as an entry point for incoming messages. It’s useful for building applications that require filtering or routing incoming messages.
2.  Channel: A channel is a component that acts as a buffer between different parts of your application. It’s useful for building applications that require message processing and transformation.
3.  Filter: A filter is a component that allows you to apply rules to incoming messages. It’s useful for building applications that require filtering or validation of incoming messages.
4.  Router: A router is a component that allows you to route incoming messages to different channels based on certain criteria. It’s useful for building applications that require routing or dispatching of incoming messages.
5.  Transformer: A transformer is a component that allows you to modify the content of incoming messages. It’s useful for building applications that require message transformation or enrichment.
6.  Splitter: A splitter is a component that allows you to split incoming messages into multiple parts. It’s useful for building applications that require message splitting or fragmentation.
7.  Aggregator: An aggregator is a component that allows you to combine multiple messages into one. It’s useful for building applications that require message aggregation or joining of incoming messages.

Code Examples  
Now that you have a good understanding of Spring Integration, messaging, and integration patterns, let’s dive into some code examples to help you get started with building your own message-driven applications.

### Example 1: Point-to-Point Messaging

In this example, we’ll build a simple point-to-point messaging application using Spring Integration. We’ll create two components: a sender and a receiver. The sender will send a message to the receiver, which will then print the message to the console.

First, let’s create a Spring Boot project with Maven as our build tool. We’ll add the `spring-integration` dependency to our `pom.xml` file:
```xml
<dependency>  
  <groupId>org.springframework.integration</groupId>  
  <artifactId>spring-integration-core</artifactId>  
  <version>5.4.3</version>  
</dependency>
```
Next, we’ll create a `Sender` class that will send a message to the receiver:
```java
@Component  
public class Sender {  
    
  @Autowired  
  private MessageChannel output;  
    
  public void sendMessage() {  
    String message = "Hello, world!";  
    output.send(new GenericMessage<>(message));  
  }  
}
```

In this example, we’re using the `@Component` annotation to make our `Sender` class a Spring bean. We’re also autowiring the `output` field with the `MessageChannel` interface, which will allow us to send messages to other components in our application.

Now let’s create a `Receiver` class that will receive the message from the sender:
```java
@Component  
public class Receiver {  
    
  @Autowired  
  private MessageChannel input;  
    
  public void receiveMessage() {  
    String message = (String) input.receive().getPayload();  
    System.out.println(message);  
  }  
}
```

In this example, we’re using the `@Component` annotation to make our `Receiver` class a Spring bean. We’re also autowiring the `input` field with the `MessageChannel` interface, which will allow us to receive messages from other components in our application.

Finally, let’s create a `Main` class that will start our Spring Boot application:
```java
@SpringBootApplication  
public class Main {  
    
  public static void main(String[] args) {  
    SpringApplication.run(Main.class, args);  
  }  
}
```

In this example, we’re using the `@SpringBootApplication` annotation to make our `Main` class a Spring Boot application. We’re also starting our application by calling the `SpringApplication.run()` method with the `Main` class and an array of command-line arguments.

That’s it! Now let’s run our Spring Boot application and see what happens:
```shell
$ mvn spring-boot:run
```
When we run our application, we should see the following output in the console:

Hello, world!

Congratulations! You have just built a simple point-to-point messaging application using Spring Integration.

### Example 2: Publish-Subscribe Messaging

In this example, we’ll build a simple publish-subscribe messaging application using Spring Integration. We’ll create two components: a publisher and a subscriber. The publisher will send messages to the subscriber, which will then print the message to the console.

First, let’s create a Spring Boot project with Maven as our build tool. We’ll add the `spring-integration` dependency to our `pom.xml` file:
```xml
<dependency>  
  <groupId>org.springframework.integration</groupId>  
  <artifactId>spring-integration-core</artifactId>  
  <version>5.4.3</version>  
</dependency>
```
Next, we’ll create a `Publisher` class that will send messages to the subscriber:
```java
@Component  
public class Publisher {  
    
  @Autowired  
  private MessageChannel output;  
    
  public void publishMessage() {  
    String message = "Hello, world!";  
    output.send(new GenericMessage<>(message));  
  }  
}
```
In this example, we’re using the `@Component` annotation to make our `Publisher` class a Spring bean. We’re also autowiring the `output` field with the `MessageChannel` interface, which will allow us to send messages to other components in our application.

Now let’s create a `Subscriber` class that will receive the message from the publisher:
```java
@Component  
public class Subscriber {  
    
  @Autowired  
  private MessageChannel input;  
    
  public void subscribe() {  
    String message = (String) input.receive().getPayload();  
    System.out.println(message);  
  }  
}
```
In this example, we’re using the `@Component` annotation to make our `Subscriber` class a Spring bean. We’re also autowiring the `input` field with the `MessageChannel` interface, which will allow us to receive messages from other components in our application.

Finally, let’s create a `Main` class that will start our Spring Boot application:
```java
@SpringBootApplication  
public class Main {  
    
  public static void main(String[] args) {  
    SpringApplication.run(Main.class, args);  
  }  
}
```
In this example, we’re using the `@SpringBootApplication` annotation to make our `Main` class a Spring Boot application. We’re also starting our application by calling the `SpringApplication.run()` method with the `Main` class and an array of command-line arguments.

That’s it! Now let’s run our Spring Boot application and see what happens:
```shell
$ mvn spring-boot:run
```
When we run our application, we should see the following output in the console:

Hello, world!

Congratulations! You have just built a simple publish-subscribe messaging application using Spring Integration.

###### Conclusion: 
In this guide, we’ve covered the basics of Spring Integration, messaging, and integration patterns. We’ve also seen some code examples to help you get started with building your own message-driven applications. Whether you’re a seasoned developer or just starting out, I hope this guide has provided you with valuable insights and practical tips for building more robust and efficient applications using Spring Integration.

If you have any questions or need further clarification on any of the topics covered in this guide, please don’t hesitate to ask in the comments section below. Happy coding! 😊

---
# Pipe and Filter Architecture with Spring Integration

In a Pipe and Filter Architecture, the system is structured into modular components known as filters, which are responsible for performing specific processing tasks on data. These filters are connected through channels called pipes, forming a processing pipeline where data flows sequentially from one filter to another.

Filters in this architecture are designed to be independent and reusable, each focusing on a single aspect of data processing such as transformation, validation, or formatting. By breaking down the system into smaller, specialized filters, developers can easily add, remove, or modify filters without impacting the overall system functionality.

Pipes act as the communication channels between filters, ensuring that data is passed from one filter to the next in an organized and controlled manner. This sequential data flow allows for a clear processing path and makes it easier to understand and maintain the system.

One of the key benefits of the Pipe and Filter Architecture is its flexibility. Developers can rearrange filters or add new ones to adapt to changing requirements or scale the system as needed. Additionally, the modular nature of this architecture promotes code reusability, as filters can be used in different pipelines or systems without modification.

Scalability is another advantage of this architecture. Developers can distribute filters across multiple nodes to handle larger volumes of data or increase processing speed. This distributed approach allows for better performance and resource utilization in data-intensive applications.

Spring Integration is a component of the Spring Framework aimed at facilitating enterprise integration through message-driven applications. Built on Enterprise Integration Patterns (EIP), it implements various messaging patterns. Key features include message handling, adapters for system connection, message channels, processing endpoints, routing based on criteria, message transformation, error management, support for complex workflows, and testing utilities. It integrates seamlessly with other Spring technologies like Spring Boot and supports both traditional and cloud-based messaging systems, providing a flexible and scalable solution for integration needs.

The following section showcases a non-trivial pipeline that will be developed using the Spring Integration framework.

The use case is based on the customer direct marketing opt-in, which involves obtaining customer consent to receive marketing communications, ensuring legal compliance, building trust, and enhancing engagement. This pipeline will generate a list of opt-in customers together with their addresses.

![](https://miro.medium.com/v2/resize:fit:875/0*SdsXZl0svunDMfjZ)

The pipeline consists of the following processes:

1.  HTTP Inbound Gateway will provide an API endpoint “/myflow” to trigger the pipeline.
2.  Customer Service will provide a list of customers stored in a database.
3.  Customer List Splitter will split the list of customers into individual messages for processing.
4.  Transform toMap will transform a POJO to a map structure to enable data enrichment processing.
5.  OptIn Enricher will enrich the message with the customer’s OptIn indicator.
6.  Message Router and Content Enricher will enrich the message with the customer’s address if the OptIn is enabled.
7.  Aggregator will consolidate the split messages into a single payload.

### Dependencies

Hereunder the dependencies:
```xml
<dependencies>  
  <dependency>  
   <groupId>org.springframework.integration</groupId>  
   <artifactId>spring-integration-core</artifactId>  
   <version>6.3.2</version>  
  </dependency>  
  
  <dependency>  
   <groupId>org.springframework.integration</groupId>  
   <artifactId>spring-integration-http</artifactId>  
   <version>6.3.2</version>  
  </dependency>  
  
  <dependency>  
   <groupId>org.springframework.integration</groupId>  
   <artifactId>spring-integration-http</artifactId>  
   <version>6.3.2</version>  
  </dependency>  
  
  <dependency>  
   <groupId>org.springframework.boot</groupId>  
   <artifactId>spring-boot-starter</artifactId>  
   <version>3.3.2</version>  
  </dependency>  
  
  <dependency>  
   <groupId>org.springframework.boot</groupId>  
   <artifactId>spring-boot-starter-web</artifactId>  
   <version>3.3.2</version>  
  </dependency>  
  
  <dependency>  
   <groupId>org.springframework.boot</groupId>  
   <artifactId>spring-boot-starter-data-jpa</artifactId>  
   <version>3.3.2</version>  
  </dependency>  
  
  <dependency>  
   <groupId>org.springframework.boot</groupId>  
   <artifactId>spring-boot-starter-log4j2</artifactId>  
   <version>3.2.2</version>  
  </dependency>  
  
  <dependency>  
   <groupId>com.h2database</groupId>  
   <artifactId>h2</artifactId>  
   <version>2.3.230</version>  
   <scope>runtime</scope>  
  </dependency>  
  
  <dependency>  
   <groupId>org.projectlombok</groupId>  
   <artifactId>lombok</artifactId>  
   <version>1.18.30</version>  
   <scope>provided</scope>  
  </dependency>  
</dependencies>
```

### Configurations

**Spring Configuration**

The following are the key configurations:
```yaml
spring:  
  jpa:  
    defer-datasource-initialization: true  
    show-sql: true
```
### Define HTTP Inbound Gateway

Spring Integration provides an HTTP Inbound Gateway component that allows you to create a web interface for your application. It listens for HTTP requests, processes them, and returns responses.
```java
@Bean(name = "myFlow.outChannel")  
DirectChannelSpec myFlowOutChannel() {  
  return MessageChannels.direct();  
}

@Bean  
IntegrationFlow myflow() {  
  return IntegrationFlow.from(Http.inboundGateway("/myflow")  
    .requestMapping(r -> r.methods(HttpMethod.GET))  
    .replyChannel("myFlow.outChannel"))  
    .channel("myFlow.outChannel")  
    .get();  
}
```
In this step, there are no processors hence an empty payload is returned.

![](https://miro.medium.com/v2/resize:fit:875/1*ZDX-yM5cZkFYnTxLh81jkQ.png)

### Define Customer Service

In Spring Integration, a Service Activator is a component that serves as an endpoint for handling messages. It is primarily used to call a service method (for example, a business service) in response to an incoming message. The Service Activator takes the message payload and passes it to a specified service method, which then processes the data and can return a response.

The customer service will fetch customer records from a database.
```java
import static jakarta.persistence.GenerationType.UUID;  
import java.util.UUID;  
import jakarta.persistence.Column;  
import jakarta.persistence.Entity;  
import jakarta.persistence.GeneratedValue;  
import jakarta.persistence.Id;  
import lombok.Data;  
import lombok.ToString;  
  
@Entity(name = "CUSTOMERS")  
@Data  
@ToString  
public class Customer {  
  
 @Id  
 @Column(name = "CUSTOMER_ID")  
 @GeneratedValue(strategy = UUID)  
 UUID id;  
  
 @Column(name = "FIRSTNAME",  
   length = 50)  
 String firstName;  
  
 @Column(name = "LASTNAME",  
   length = 50)  
 String lastName;  
}

import java.util.List;  
  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.integration.annotation.ServiceActivator;  
import org.springframework.messaging.Message;  
import org.springframework.stereotype.Component;  
  
import lombok.extern.log4j.Log4j2;  
  
@Component  
@Log4j2  
public class CustomerServiceActivator {  
  
 @Autowired(required = true)  
 CustomerH2Repository repository;  
  
 @ServiceActivator  
 List<Customer> getCustomers(Message<?> message) {  
  List<Customer> customers = this.repository.findAll();  
  
  log.info("Customer list record retrieved [size={}]", customers.size());  
  
  return customers;  
 }  
}

@Bean  
IntegrationFlow acme(@Autowired(required = true) CustomerServiceActivator customerListServiceActivator) {  
  return IntegrationFlow.from(Http.inboundGateway("/myflow")  
    .requestMapping(r -> r.methods(HttpMethod.GET))  
    .replyChannel("myFlow.outChannel"))  
    .handle(customerListServiceActivator)  
    .channel("myFlow.outChannel")  
    .get();  
 }
```
The database will be seeded with the following data:

insert into CUSTOMERS(CUSTOMER_ID, FIRSTNAME, LASTNAME) values ('c725f120-5e66-4613-a2f8-8f0e4fbccf46', 'Fred', 'Flinstone');  
insert into CUSTOMERS(CUSTOMER_ID, FIRSTNAME, LASTNAME) values ('1f153dd8-dbf6-4e33-a30f-1beeb3ac13bd', 'Barney', 'Rubble');

In this step, the customer records will be included in the payload.

![](https://miro.medium.com/v2/resize:fit:875/1*0JudlbrJgMOpG17L8SXiKw.png)

### Define Customer List Splitter and Aggregator

In Spring Integration, a splitter is a component that divides a message into multiple messages, which can then be processed independently. This is useful when handling different parts of a message separately, enabling parallel processing and enhancing system efficiency.

In this case the `payload` , which holds a list of customers will be separated into individual messages.
```java
@Bean  
IntegrationFlow acme(@Autowired(required = true) CustomerServiceActivator customerListServiceActivator) {  
  return IntegrationFlow.from(Http.inboundGateway("/myflow")  
    .requestMapping(r -> r.methods(HttpMethod.GET))  
    .replyChannel("myFlow.outChannel"))  
    .handle(customerListServiceActivator)  
    .split("payload")  
    .aggregate()  
    .channel("myFlow.outChannel")  
    .get();  
 }
```
### Defined Transformer toMap

In Spring Integration, a transformer takes incoming messages, processes / transforms them, and then produces an output message, which can either be sent to another channel or further processed in the integration flow.
```java
@Bean  
IntegrationFlow acme(@Autowired(required = true) CustomerServiceActivator customerListServiceActivator) {  
  return IntegrationFlow.from(Http.inboundGateway("/myflow")  
    .requestMapping(r -> r.methods(HttpMethod.GET))  
    .replyChannel("myFlow.outChannel"))  
    .handle(customerListServiceActivator)  
    .split("payload")  
    .transform(Transformers.toMap())  
    .aggregate()  
    .channel("myFlow.outChannel")  
    .get();  
}
```
### Defined OptIn Enricher

In Spring Integration, an Enricher enriches an existing message by augmenting it with additional information from another source. This is particularly useful for adding contextual data to a message, such as retrieving additional details from a database, a service, or another system before further processing.

The OptIn Enricher will fetch the OptIn indicator from a database.
```java
import java.util.UUID;  
  
import jakarta.persistence.CascadeType;  
import jakarta.persistence.Column;  
import jakarta.persistence.Entity;  
import jakarta.persistence.Id;  
import jakarta.persistence.JoinColumn;  
import jakarta.persistence.ManyToOne;  
import lombok.Data;  
import lombok.ToString;  
  
@Entity(name = "CONSENTS")  
@Data  
@ToString  
public class Consents {  
  
 @Id  
 @Column(name="CONSENT_ID")  
 UUID id;  
   
 @ManyToOne(cascade = CascadeType.ALL)  
 @JoinColumn(name = "CUSTOMER_ID", referencedColumnName = "CUSTOMER_ID")  
 Customer customer;  
   
 ConsentType consentType;  
}

import java.util.UUID;  
  
import org.springframework.data.jpa.repository.JpaRepository;  
import org.springframework.data.jpa.repository.Query;  
  
public interface ConsentsH2Repository extends JpaRepository<Consents, UUID> {  
  
 @Query  
 Consents findByCustomerIdAndConsentType(UUID customerId, ConsentType consentType);  
}

import java.util.Optional;  
import java.util.UUID;  
import java.util.function.Function;  
  
import org.springframework.integration.annotation.Transformer;  
import org.springframework.messaging.handler.annotation.Payload;  
import org.springframework.stereotype.Component;  
  
import lombok.NonNull;  
import lombok.RequiredArgsConstructor;  
import lombok.extern.log4j.Log4j2;  
  
@Component  
@RequiredArgsConstructor  
@Log4j2  
public class OptInEnricher {  
  
 @NonNull  
 ConsentsH2Repository repository;  
  
 @Transformer( inputChannel = "OptInEnricher.inChannel",  
     outputChannel = "OptInEnricher.outChannel")  
 public OptInFlag enrich(@Payload("id") UUID userId) {  
  Consents consent = this.repository.findByCustomerIdAndConsentType(userId, ConsentType.OPT_IN);  
  
  log.info("Find user and consent result [userId={}, consent={}]", userId, consent);  
    
  return Optional.ofNullable(consent)  
    .map(consentToOptIn)  
    .orElse(new OptInFlag());  
 }  
  
 Function<Consents, OptInFlag> consentToOptIn = c -> new OptInFlag()  
   .setOptIn(ConsentType.OPT_IN.equals(c.getConsentType()));  
}

@Bean(name = "OptInEnricher.inChannel")  
DirectChannelSpec d() {  
  return MessageChannels.direct();  
}  
  
@Bean(name = "OptInEnricher.outChannel")  
DirectChannelSpec e() {  
  return MessageChannels.direct();  
}

 @Bean  
 IntegrationFlow acme(@Autowired(required = true) CustomerServiceActivator customerListServiceActivator) {  
  return IntegrationFlow.from(Http.inboundGateway("/myflow")  
    .requestMapping(r -> r.methods(HttpMethod.GET))  
    .replyChannel("myFlow.outChannel"))  
    .handle(customerListServiceActivator)  
    .split("payload")  
    .transform(Transformers.toMap())  
    .enrich(e -> e.requestChannel("OptInEnricher.inChannel")  
      .replyChannel("OptInEnricher.outChannel")  
      .propertyExpression("['OptIn']", "payload.optIn"))  
    .aggregate()  
    .channel("myFlow.outChannel")  
    .get();  
 }
```
The database will be seeded with the following data:

insert into CONSENTS(CONSENT_ID, CUSTOMER_ID, CONSENT_TYPE) values('d8f2e1d6-da75-4509-b9eb-e3a233011791', 'c725f120-5e66-4613-a2f8-8f0e4fbccf46', 0)

In this step, the payload will include the additional `OptIn` flat.

![](https://miro.medium.com/v2/resize:fit:875/1*-oJZz5E32gHdVm1hYr8GGA.png)

### Define Address Enricher

The Address Enricher will fetch the customer’s address from a database.
```java
import java.util.UUID;  
  
import jakarta.persistence.Column;  
import jakarta.persistence.Entity;  
import jakarta.persistence.GeneratedValue;  
import jakarta.persistence.GenerationType;  
import jakarta.persistence.Id;  
import lombok.Data;  
import lombok.NoArgsConstructor;  
import lombok.ToString;  
  
@Entity(name = "ADDRESSES")  
@NoArgsConstructor  
@Data  
@ToString  
public class Address {  
  
 @Id  
 @GeneratedValue(strategy = GenerationType.UUID)  
 @Column(name = "ADDRESS_ID")  
 UUID addressId;  
   
 @Column(name = "CUSTOMER_ID")  
 UUID customerId;  
  
 @Column(name = "STREET")  
 String street;  
}

import java.util.Optional;  
import java.util.UUID;  
  
import org.springframework.data.jpa.repository.JpaRepository;  
  
public interface AddressesH2Repository extends JpaRepository<Address, UUID> {  
  
 Optional<Address> findByCustomerId(UUID userId);  
  
}

import java.util.Optional;  
import java.util.UUID;  
  
import org.springframework.integration.annotation.Transformer;  
import org.springframework.messaging.handler.annotation.Payload;  
import org.springframework.stereotype.Component;  
  
import lombok.NonNull;  
import lombok.RequiredArgsConstructor;  
import lombok.extern.log4j.Log4j2;  
  
@Component  
@RequiredArgsConstructor  
@Log4j2  
public class AddressEnricher {  
  
 @NonNull  
 AddressesH2Repository repository;  
  
 @Transformer(inputChannel = "AddressEnricher.inChannel")  
 public Optional<Address> enrich(@Payload("id") UUID userId) {  
  
  log.info("Searching user [userId={}]", userId);  
  
  Optional<Address> customer = repository.findByCustomerId(userId);  
  
  log.info("Customer search result [userId={}, record={}]", userId, customer.get());  
  
  return customer;  
 }  
}

 @Bean  
 IntegrationFlow optInFlow() {  
  return f -> f.enrich(e -> e.requestChannel("AddressEnricher.inChannel")  
    .propertyExpression("['Address']", "payload"));  
 }  
  
 @Bean  
 IntegrationFlow optOutFlow() {  
  return f -> f.bridge();  
 }

@Bean  
IntegrationFlow acme(@Autowired(required = true) CustomerServiceActivator customerListServiceActivator) {  
  return IntegrationFlow.from(Http.inboundGateway("/myflow")  
    .requestMapping(r -> r.methods(HttpMethod.GET))  
    .replyChannel("myFlow.outChannel"))  
    .handle(customerListServiceActivator)  
    .split("payload")  
    .transform(Transformers.toMap())  
    .enrich(e -> e.requestChannel("OptInEnricher.inChannel")  
      .replyChannel("OptInEnricher.outChannel")  
      .propertyExpression("['OptIn']", "payload.optIn"))  
    .route("payload['OptIn']",  
      r -> r.subFlowMapping(true, s -> s.gateway(optInFlow()))  
        .subFlowMapping(false, s -> s.gateway(optOutFlow())))  
    .log(Level.INFO, Application.class.getCanonicalName(), m -> String.format("Payload [%s]", m))  
    .aggregate()  
    .channel("myFlow.outChannel")  
    .get();  
 }
```
The database will be seeded with the following data:

insert into ADDRESSES(ADDRESS_ID, CUSTOMER_ID, STREET) values('40c0f3ed-fded-48fe-90ae-f1d6b00b8147', 'c725f120-5e66-4613-a2f8-8f0e4fbccf46', '1313 Cobblestone Way, Bedrock, 70777');  
insert into ADDRESSES(ADDRESS_ID, CUSTOMER_ID, STREET) values('ea205292-100b-4664-b356-507965c51b93', '1f153dd8-dbf6-4e33-a30f-1beeb3ac13bd', '303 Cobblestone Way, Bedrock, 70777');

In this step, the customer’s record will be enriched with their addresses if `OptIn` is enabled.

![](https://miro.medium.com/v2/resize:fit:875/1*_0iFc6dm7l56azKPEtny6Q.png)

### Conclusion

The pipe and filter architecture provides an elegant solution for building complex data processing systems by promoting modularity, reusability, and scalability. It helps developers construct applications that can adapt to changing requirements and integrate with other systems efficiently.
---
# Spring Boot and Redis Cluster Integration

Greetings. I will talk about the Redis Cluster in this article.

# What is Redis?

Redis is an open-source, in-memory data structure store. It is often referred to as a “data structure server” because it enables developers to store various types of data structures such as strings, lists, sets, hashes, and more, in memory. This design allows for exceptionally fast read and write operations, making Redis an excellent choice for use cases that require low-latency and high-throughput data access.

1.  **In-Memory Data Storage:** Redis primarily stores data in system memory, which allows for rapid data access and retrieval. This makes it well-suited for use cases where speed is crucial.
2.  **Caching:** One of the most common use cases for Redis is caching. Since data access from memory is much faster than reading from disk or a database, Redis can be used to cache frequently accessed data, reducing the load on backend databases and improving overall application performance.
3.  **Pub/Sub Messaging:** Redis includes a publish/subscribe (pub/sub) messaging system. This allows different parts of an application or different applications altogether to communicate asynchronously through the Redis server.
4.  **Cluster Support:** Redis can be configured to work in a clustered mode, distributing data across multiple nodes for improved scalability and fault tolerance.

![](https://miro.medium.com/v2/resize:fit:875/1*1Cxol9rruIqtbeB5h_craQ.png)
https://cdn-3.backendless.com/wp-content/uploads/2022/12/How-Redis-typically-works.png

# What is the Redis Cluster?

A Redis Cluster is a distributed implementation of Redis that allows you to partition and distribute your data across multiple Redis nodes while maintaining high availability and fault tolerance. It’s designed to address the scalability limitations of a single Redis instance by allowing you to create a cluster of nodes that work together to handle larger datasets and higher loads.

![](https://miro.medium.com/v2/resize:fit:875/1*xMW1rBwPxehKOEbJTIKjVQ.png)
https://velog.velcdn.com/images/ekxk1234/post/f2ce167b-2496-4a94-94f7-3c26ffffd60f/image.png

1.  **Partitioning:** Redis Cluster uses a concept called sharding to partition the data across multiple nodes. Each key is assigned to a specific node, and the cluster manages the distribution of keys and their values across the nodes.
2.  **High Availability:** Redis Cluster offers built-in high availability. It automatically detects node failures and can promote slave nodes to masters in case of a failure. This ensures that the cluster continues to operate even if some nodes are unavailable.
3.  **Data Replication:** Redis Cluster employs data replication to ensure data durability and availability. Each master node can have one or more replica nodes, which maintain a copy of the data. If a master node fails, one of its replicas can be promoted to become the new master.
4.  **Automatic Failover:** When a master node fails, Redis Cluster automatically triggers a failover process by promoting one of its replica nodes to be the new master. This helps minimize downtime and maintain data consistency.

# What is Master-Slave model?

The master-slave model is a data replication architecture commonly used in distributed systems to ensure data availability, redundancy, and fault tolerance. It’s used in various types of databases and data stores, including Redis, relational databases, and more.

In the context of Redis and similar systems, the master-slave model works as follows:

## **Master Node:**

The master node is the primary node that handles read and write operations. It’s responsible for processing write requests and updating the data in its storage.

## **Slave Nodes:**

Slave nodes are secondary nodes that replicate data from the master node. They receive a copy of the data stored on the master node and are primarily used for read operations. Slave nodes don’t handle write requests directly, which helps distribute the load and prevent write-related bottlenecks on the master node.

# What is a Hash Slot in Redis?

![](https://miro.medium.com/v2/resize:fit:875/1*gFESF58a6lub8EbD7yyS7Q.png)
https://redis.com/blog/redis-clustering-best-practices-with-keys/#:~:text=Redis%20Cluster%20is%20a%20distributed,of%20the%20total%20data%20set.

Hash slot refers to a mechanism used in Redis Cluster, a distributed and fault-tolerant mode of Redis deployment. Redis Cluster divides the key space into a fixed number of hash slots, typically 16384 slots. Each key in the dataset is associated with one of these hash slots through a hashing function. The division of keys into hash slots allows Redis to distribute the keys and data across multiple nodes in the cluster while providing horizontal scalability and fault tolerance.

![](https://miro.medium.com/v2/resize:fit:875/1*2rXaL3PAe6BI-Zper8PVHA.png)
https://redis.com/blog/redis-clustering-best-practices-with-keys/#:~:text=Redis%20Cluster%20is%20a%20distributed,of%20the%20total%20data%20set.

# What is Redis TTL?

In Redis, “TTL” stands for “Time To Live.” TTL is a feature that allows you to set an expiration time for a key-value pair in the Redis database. Once the TTL for a key expires, Redis automatically removes that key-value pair from the database, making space for new data.

## Use cases for TTL in Redis:

-   **Cache Expiration:** Redis is often used as a cache. By setting a TTL on cached data, you can ensure that stale or outdated data is automatically removed from the cache, promoting data freshness.
-   **Session Management:** You can use TTL to manage user sessions. When a user logs in, you can create a key-value pair with a TTL, and as long as the user is active, you can periodically extend the TTL to keep the session alive. If the user logs out or becomes inactive, the session data will automatically expire.
-   **Rate Limiting:** TTL can be used to implement rate limiting mechanisms. For example, you can set a TTL on a key associated with a user’s request counter. Once the TTL expires, the user’s request counter resets.

TTL is a powerful feature in Redis that helps manage data lifecycle and ensures that the database remains efficient by automatically removing expired data.

# Redis Cluster installation on Docker

**1) Create redis.conf file.**
```shell
port 6379  
cluster-enabled yes  
cluster-config-file nodes.conf  
cluster-node-timeout 5000  
appendonly yes
```
**2) Create a Docker-Compose file like the following:**
```yml
version: '3'  
services:  
  
  spring-app:  
    container_name: spring-app  
    image: spring-app  
    restart: always  
    ports:  
      - "8080:8080"  
  
  redis1:  
    container_name: redis1  
    image: redis:7.0.5  
    ports:  
      - "6379:6379"  
    volumes:  
      - ./redis/redis.conf:/usr/local/etc/redis/redis.conf  
    command: ["redis-server", "/usr/local/etc/redis/redis.conf"]  
  
  redis2:  
    container_name: redis2  
    image: redis:7.0.5  
    ports:  
      - "6380:6379"  
    volumes:  
      - ./redis/redis.conf:/usr/local/etc/redis/redis.conf  
    command: ["redis-server", "/usr/local/etc/redis/redis.conf"]  
  
  redis3:  
    container_name: redis3  
    image: redis:7.0.5  
    ports:  
      - "6381:6379"  
    volumes:  
      - ./redis/redis.conf:/usr/local/etc/redis/redis.conf  
    command: ["redis-server", "/usr/local/etc/redis/redis.conf"]  
  
  redis4:  
    container_name: redis4  
    image: redis:7.0.5  
    ports:  
      - "6382:6379"  
    volumes:  
      - ./redis/redis.conf:/usr/local/etc/redis/redis.conf  
    command: ["redis-server", "/usr/local/etc/redis/redis.conf"]  
  
  redis5:  
    container_name: redis5  
    image: redis:7.0.5  
    ports:  
      - "6383:6379"  
    volumes:  
      - ./redis/redis.conf:/usr/local/etc/redis/redis.conf  
    command: ["redis-server", "/usr/local/etc/redis/redis.conf"]  
  
  redis6:  
    container_name: redis6  
    image: redis:7.0.5  
    ports:  
      - "6384:6379"  
    volumes:  
      - ./redis/redis.conf:/usr/local/etc/redis/redis.conf  
    command: ["redis-server", "/usr/local/etc/redis/redis.conf"]
```

Run following command.
```shell
docker-compose up -d redis1 redis2 redis3 redis4 redis5 redis6
```
**3) Create Redis Cluster on Docker.**

Enter Into a Docker Container’s Shell with docker exec command.
```shell
docker exec -it redis1 bash
```
Create redis cluster with following command.
```shell
redis-cli --cluster create redis1:6379 redis2:6379 redis3:6379 redis4:6379 redis5:6379 redis6:6379 --cluster-replicas 1
```
After running the above command you will see like following output.

![](https://miro.medium.com/v2/resize:fit:875/1*zDa7ab5Ite78B_gfMi1Wwg.png)

**4) Our Master Slave model in Docker.**

![](https://miro.medium.com/v2/resize:fit:875/1*xP89Jv55XycO4oKVRH-JVw.png)

# Integration in Spring Boot

**1) application.properties file**
```shell
server.port=8080  
redis.nodes=redis1:6379,redis2:6379,redis3:6379,redis4:6379,redis5:6379,redis6:6379
```
**2) Dockerfile**
```Dockerfile
FROM maven:3.8.7-openjdk-18-slim AS build  
COPY ./src /usr/src/app/src  
COPY ./pom.xml /usr/src/app  
RUN mvn -f /usr/src/app/pom.xml clean package -D skipTests  
  
FROM adoptopenjdk/openjdk11:x86_64-alpine-jdk-11.0.11_9-slim  
COPY --from=build /usr/src/app/target/*.jar /usr/local/lib/spring-app.jar  
EXPOSE 8080  
ENTRYPOINT ["java","-jar","/usr/local/lib/spring-app.jar"]
```
**3) RedisClusterConfig file**
```java
@Configuration  
@EnableCaching  
public class RedisClusterConfig {  
  
    @Value("${redis.nodes}")  
    private String[] redisNodes;  
  
    @Bean  
    LettuceConnectionFactory redisConnectionFactory(RedisClusterConfiguration redisConfiguration) {  
        LettuceClientConfiguration clientConfig = LettuceClientConfiguration.builder()  
                .readFrom(ReadFrom.REPLICA_PREFERRED)  
                .commandTimeout(Duration.ofSeconds(120))  
                .build();  
        return new LettuceConnectionFactory(redisConfiguration, clientConfig);  
    }  
  
    @Bean  
    RedisClusterConfiguration redisConfiguration() {  
        List<String> clusterNodes = Arrays.asList(redisNodes);  
        RedisClusterConfiguration redisClusterConfiguration = new RedisClusterConfiguration(clusterNodes);  
        redisClusterConfiguration.setMaxRedirects(5);  
        return redisClusterConfiguration;  
    }  
  
    @Bean  
    public RedisTemplate<String, Object> template(RedisConnectionFactory connectionFactory) {  
        RedisTemplate<String, Object> template = new RedisTemplate<>();  
        template.setConnectionFactory(connectionFactory);  
        template.setKeySerializer(new StringRedisSerializer());  
        template.setHashKeySerializer(new StringRedisSerializer());  
        template.setHashKeySerializer(new JdkSerializationRedisSerializer());  
        template.setValueSerializer(new JdkSerializationRedisSerializer());  
        template.setEnableTransactionSupport(true);  
        template.afterPropertiesSet();  
        return template;  
    }  
}
```

-   `readFrom(ReadFrom.REPLICA_PREFERRED)`: This sets the client to read data primarily from replica (secondary) nodes, which is useful for distributing read traffic and reducing the load on the primary node.
-   `commandTimeout(Duration.ofSeconds(120))`: This sets the command timeout to 120 seconds, meaning that Redis commands will time out if they take longer than this duration.

**4) CacheService file**
```java
@Service  
public class CacheService {  
  
    private final RedisTemplate<String, Object> redisTemplate;  
  
    @Autowired  
    public CacheService(RedisTemplate<String, Object> redisTemplate) {  
        this.redisTemplate = redisTemplate;  
    }  
  
    public User cacheUser(User user){  
        redisTemplate.opsForValue().set(user.getName(), user, Duration.ofMinutes(2L));  
        return user;  
    }  
  
    public User getCachedUserByName(String name){  
        var user = redisTemplate.opsForValue().get(name);  
        return (User) user;  
    }  
}
```
`Duration.ofMinutes(2L))`: We set the TTL. Data will store 2 minutes in Redis.

**3) CacheController file**
```java
@RestController  
@RequestMapping("/api/v1/users/cache")  
public class CacheController {  
  
    private final CacheService cacheService;  
  
    @Autowired  
    public CacheController(CacheService cacheService) {  
        this.cacheService = cacheService;  
    }  
  
  
    @PostMapping(path = "")  
    public User cacheUser(@RequestBody User user) {  
      return cacheService.cacheUser(user);  
    }  
  
    @GetMapping(path = "/{name}")  
    public User getCachedUserByName(@PathVariable String name) {  
        return cacheService.getCachedUserByName(name);  
    }  
}
```
**6) Dockerizing a Spring Boot application.**

docker build -t spring-app .  
  
docker-compose up -d spring-app

**7) Send HTTP requests for storing data to Redis Cluster.**
```shell
curl --location 'localhost:8080/api/v1/users/cache'   
--header 'Content-Type: application/json'   
--data '{  
    "name":"Mert",  
    "city":"Eskisehir"  
}'  
  
curl --location 'localhost:8080/api/v1/users/cache'   
--header 'Content-Type: application/json'   
--data '{  
    "name":"Ali",  
    "city":"Trabzon"  
}'  
  
curl --location 'localhost:8080/api/v1/users/cache'   
--header 'Content-Type: application/json'   
--data '{  
    "name":"Mustafa",  
    "city":"Sivas"  
}'  
  
curl --location 'localhost:8080/api/v1/users/cache'   
--header 'Content-Type: application/json'   
--data '{  
    "name":"Veli",  
    "city":"Ankara"  
}'
```

**8) Run following command and show nodes data.**
```shell
 docker exec -it <coontainer_name> redis-cli keys "*"
```
![](https://miro.medium.com/v2/resize:fit:875/1*NisUuzjexYE4oIlXqWqLsg.png)

After running the command, we observe that the data is distributed based on the key values and copied to the slave nodes.

## Github Repository:

https://github.com/mertcakmak2/Medium-Projects/tree/master/spring-boot-redis-cluster
