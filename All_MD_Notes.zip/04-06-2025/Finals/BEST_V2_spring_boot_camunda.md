# Introducing Camunda: A Comprehensive Guide for Beginners

### 1. What is Camunda?

Camunda is an open-source platform for workflow and decision automation. At its core, Camunda is a platform designed for automating, deploying, and scaling business processes. This is done by designing process flows using a standardized notation called BPMN 2.0. Once your flow is designed, Camunda’s engine brings it to life, ensuring each step, decision, and task is executed as per the model. But wait, what’s BPMN 2.0?

**Understanding BPMN 2.0**: Think of BPMN 2.0 as a flowchart on steroids. It’s a way to visually map out business processes using a set of standard symbols and shapes. So, whether you’re planning a complex business operation or just organizing a party, BPMN can help you lay out who does what, when, and under what conditions. Camunda uses this language to let you design and run these processes.

### 2. When to use Camunda: Use Cases

-   **Complex Business Workflows**: Automate multi-step, branching business processes that involve various stakeholders.
-   **Decision Automation**: Utilize DMN (Decision Model and Notation) to make automated decisions based on predefined logic.
-   **Integration with Other Systems**: Seamlessly connect various systems and microservices using BPMN.
-   **Monitoring and Reporting**: Gain insights into ongoing processes, completed tasks, and potential bottlenecks.

### 3. How to Utilize Camunda in a Project

-   **Modeling**: Begin by visually designing your process using BPMN notation with tools like Camunda Modeler.
-   **Deployment**: Deploy the designed process to the Camunda engine.
-   **API Integration**: Integrate with your existing systems using Camunda’s REST API.
-   **Execution**: Run instances of your process, which can be triggered manually, by an API call, or by other events.

### 4. Camunda Glossary

-   **BPMN**: Stands for “Business Process Model and Notation.” It’s a standard for visualizing business processes.  
    - **Example**: Consider a business process for onboarding a new employee. This process might include tasks like setting up IT accoutns, orientation meetings, and assigning a mentor. With BPMN, you’d create a diagram to visually represent this sequence of tasks, making it clear for everyone involved.
-   **DMN**: Short for “Decision Model and Notation.” It’s used for defining and executing decision logic.  
    - **Example**: If an employee’s role is ‘_developer_’, then assign them to the ‘_IT Department_.’ If their role is ‘_sales_’, assign them to the ‘_Sales Department_.’
-   **Process Instance**: An individual run or execution of a modeled process.  
    - **Example**: If you have a process for handling customer complaints, each time a customer files a complaint and the process starts, that’s a new process instance.
-   **Task & User Task**: A piece of work or activity within a process. While tasks can be automatic, user tasks require human intervention.  
    - **Example**: In a loan approval process, au automated task might be “Check Credit Score”, while a user task could be “Review and Approve Loan Application by Manager”.
-   **Service Task**: Represents an automated step in the process that often involves calls to external systems.  
    - **Example**: Automatically sending an email confirmation once an order is placed.
-   **Gateways**: BPMN elements used to control the flow of a process. They handle branching and merging of paths based on conditions or events.  
    - **Example**: In a product return process, a gateway might check if the returned item is damaged. If it is, one path leads to ‘Issue Refund’; if not, another path leads to ‘Restock Item’.
-   **Variables**: Data or values associated with a process instance. They can store information or help in decision-making.  
    - **Example**: In a flight booking process, variables might include `flightDate`, `destination`, `numberOfPassengers`.

### 5. Listenrs in Camunda

Listeners in Camunda can be seen as ‘triggers’ or ‘hooks’ that allow developers to inject custom behavior at specific points within a process. Two prominent types are Execution Listeners and Task Listeners.

### **Execution Listeners**

**What are they?** Execution Listeners are classes or scripts that you can configure to listen to specific events during the execution of a business process. Essentially, they’re like observers waiting for particular moments in the flow to carry out predefined actions.

**When can you use them?** Execution Listeners can be attached to:

-   Start and end events of a process.
-   Entering and leaving nodes (like gateways, activities, and events).
-   Taking sequence flows.

**Common Use-Cases**:

-   Initializing or cleaning up resources.
-   Logging process execution details.
-   Business logic like modifying process variables.

**Types of Events for Execution Listeners:**

-   **start**: Triggered when an activity is started.
-   **end**: Triggered when an activity ends.
-   **take**: For sequence flows; triggered when the flow is taken.

**Example**: Imagine you want to log each time an activity starts in your process. You’d attach an execution listener to the ‘start’ event of that activity and write the logging logic inside it.

### Task Listeners

**What are they?** Task Listeners, as the name suggests, are hooked to user tasks. They allow developers to react to events related to user tasks, like when a task is created, assigned, or completed.

**When can use them?** You can attach task listeners to user tasks within your BPMN process.

**Common Use-Cases:**

-   Sending notifications (e.g., email to a user when a task is assigned to them).
-   Logging task lifecycle events.
-   Adjusting task attributes dynamically.

**Types of Events for Task Listeners:**

-   **create**: When a task instance is created.
-   **assignment**: When a task is assigned to a user or group.
-   **complete**: When a task is completed.
-   **delete**: When a task instance is deleted.

**Example:** Suppose you want to send an email to a user when a task is assigned to them. You’d use a task listener on the ‘assignment’ event, and within the listener, you’d implement the email-sending logic.

### **Configuring Listeners in Camunda:**

There are multiple ways to add listeners:

1.  **Camunda Modeler:** Using the graphical interface, you can add listeners to activities and tasks.
2.  **BPMN XML:** Directly in the BPMN XML, you can specify listeners using the respective tags.
3.  **Java API:** Programmatically using Camunda’s Java API.

### Conclusion

Camunda stands out as a powerful tool in the landscape of business process automation. Whether you’re looking to streamline multi-faced workflows, integrate disparate systems, or gain clearer visibility into your operations, Camunda might just be the solution you need.

---

### 12 Essential Questions for a Successful Camunda Developer Interview

Camunda BPM (Business Process Management) is a powerful tool used for orchestrating and automating business processes. As organizations increasingly adopt Camunda for their workflow management needs, the demand for skilled Camunda developers continues to rise. Whether you’re a seasoned Camunda developer or aspiring to become one, preparing for a Camunda developer interview is crucial to showcasing your expertise and securing your desired role. To help you ace your interview, we’ve compiled a list of 12 essential questions covering various aspects of Camunda BPM.

### What Are Common Questions for a Job Interview for a Consultant in Camunda?

Consultants play a vital role in advising organizations on the implementation and optimization of Camunda BPM solutions. Understanding common interview questions for Camunda consultants can help you demonstrate your expertise in consulting, business process management, and Camunda technology.

### 1. What Type of Gateways Are on a BPMN Diagram?

BPMN (Business Process Model and Notation) diagrams use gateways to control the flow of processes based on specific conditions. Familiarizing yourself with different types of gateways in BPMN diagrams and their functionalities is essential for effectively modeling business processes in Camunda.

In BPMN (Business Process Model and Notation), gateways are used to control the flow of a process based on certain conditions. There are several types of gateways in a BPMN diagram:

1.  **Exclusive Gateway (XOR Gateway):**

![](https://miro.medium.com/v2/resize:fit:59/1*xsOgavjMULa3TzQDHusz9g.png)

-   Symbol: Diamond shape with an “X” inside.
-   Function: It represents a decision point where only one of the outgoing paths will be taken, based on a condition.

**2. Inclusive Gateway (+ Gateway):**

![](https://miro.medium.com/v2/resize:fit:59/1*DUhElxgCe3wraGdhvTS7ZA.png)

-   Symbol: Diamond shape with a circle inside.
-   Function: It allows multiple outgoing paths to be taken based on conditions. It is more flexible than the exclusive gateway as it enables parallel flows.

**3. Parallel Gateway (AND Gateway):**

![](https://miro.medium.com/v2/resize:fit:59/1*8U660OgxHmUIXU99LppRbQ.png)

-   Symbol: Diamond shape with a “+” inside.
-   Function: It signifies that all outgoing paths will be taken simultaneously. It represents a synchronization point where multiple activities can occur concurrently.

**4. Event-Based Gateway:**

![](https://miro.medium.com/v2/resize:fit:59/1*_21B5b7JvDkiGwuFqZVkkw.png)

-   Symbol: Diamond shape with a circle inside and an asterisk (*) in the center.
-   Function: It is used to model complex event handling scenarios. Depending on the events that occur, different paths can be taken.

**6. Complex Gateway:**

![](https://miro.medium.com/v2/resize:fit:59/1*x4psMPjP39LjUgO4PNd3ag.png)

-   Symbol: Diamond shape with no specific inside symbol.
-   Function: It represents a more complex decision-making situation where conditions involve multiple factors or rules.

### 2. What Are New Features in Camunda 8?

Staying updated with the latest features and enhancements in Camunda 8 demonstrates your commitment to continuous learning and staying abreast of advancements in BPM technology. Knowledge of new features can also help you leverage Camunda’s capabilities to solve complex business challenges more effectively.

Some of the new features are:

**Web Modeler**: Web Modeler allows you to create, model, and store processes, decisions, and forms in easy-to-navigate online folders. It also provides collaboration features like comments, and milestones with visual diffing of versions and projects. It enables you to make the processes and decisions executable directly — including deployment and the start of new process instances.

**Token Simulation:** Token Simulation allows you to quickly understand how your model will be executed with the help of visual tokens. This is a powerful feature, especially for larger diagrams — you can simulate the process flow and set conditions to evaluate all the parts of your process.

**Desktop Modeler:**

-   Support for Camunda Platform 8, including DMN.
-   A completely new look and feel — allowing you to focus on the important things when designing processes.
-   Updated process debugging capabilities with intuitive helpers to resolve issues faster.
-   A redesigned properties panel for easier navigation and fast access to contextual documentation.
-   Support for element templates and plugins to extend Modeler

**Workflow Engine — Powered by Zeebe:** Camunda’s next-generation, cloud-native workflow engine, provides organizations with speed, scalability, security, and resiliency, without the overhead of building and maintaining infrastructure. Zeebe can scale throughput linearly by adding cluster nodes, allowing unlimited transactions to be processed with consistently low latencies. To ensure resilience, Zeebe comes with a new, fail-over architecture that also supports geo-replication across data centers to provide enterprise-grade availability.

### 3. What Is DMN?

DMN (Decision Model and Notation) is a standard for modeling and executing decision logic within business processes. Understanding DMN allows Camunda developers to incorporate decision automation into their BPM solutions, improving process efficiency and agility.

Key components of DMN include:

1.  **Decision Requirements Diagram (DRD)**: The DRD provides a high-level view of the decision-making structure. It shows the relationships and dependencies between different decisions and their input data.
2.  **Decision Tables:** Decision tables are a fundamental part of DMN. They provide a concise way to describe decision logic, showing the possible input combinations and the corresponding outcomes or actions.
3.  **Input Data**: Input data represents the information or variables that are used as input for decisions. It could include data from external sources, other decisions, or business knowledge.
4.  **Decision Logic**: This is the logic that defines how decisions are made based on the input data. Decision tables, if-then rules, and other constructs can be used to express this logic.
5.  **Business Knowledge Model (BKM):** BKMs represent reusable components of business logic that can be referenced by decisions. They allow for the modularization and reuse of decision-making logic.

DMN is often used in conjunction with BPMN (Business Process Model and Notation), another standard for modeling business processes. While BPMN focuses on the sequence of activities in a process, DMN is specifically designed for modeling the decision logic within those processes.

The goal of DMN is to bridge the communication gap between business analysts who understand the business logic and decision-makers and technical developers who implement the decisions in software systems. It provides a standardized way to document and communicate decision-making processes in a visually intuitive manner.

### 4. What Are Camunda Batches?

Camunda Batches facilitate the efficient processing of large sets of data or tasks in batch-oriented workflows. Knowledge of Camunda Batches enables developers to optimize performance and scalability in BPM solutions handling significant volumes of data or tasks.

Here are some key aspects of Camunda Batches:

1.  **Bulk Operations:** Camunda Batches are designed to handle bulk operations, such as updating, deleting, or processing a large number of process instances, tasks, or variables.
2.  **Asynchronous Processing:** Batches enable asynchronous processing, allowing you to submit a large number of operations and have them executed in the background. This helps improve performance and responsiveness.
3.  **Error Handling:** Batches provide mechanisms for handling errors that may occur during the processing of individual items within the batch. This includes options for handling errors gracefully and logging relevant information.
4.  **Monitoring and Management:** Camunda provides monitoring and management capabilities for batches. You can track the progress of batches, view execution details, and manage the overall lifecycle of batch operations.
5.  **Use Cases:** Common use cases for Camunda Batches include data migration, mass updates to process instances or variables, and any scenario where dealing with large sets of data or tasks is required.
6.  **API and Configuration:** Camunda provides a Batch API and configuration options that allow developers to define and control batch operations programmatically.

### 5. What Is a Message Event in Camunda?

Understanding message events in Camunda BPM is essential for implementing communication between different parts of a process or between different processes. Familiarity with slash message events and their use cases demonstrates proficiency in Camunda’s event-based messaging capabilities.

Here are some key points related to message events in Camunda:

1.  **Message Start Event:** This is used to start a process instance based on the receipt of a specific message.

![](https://miro.medium.com/v2/resize:fit:58/1*WZOYl399cKXThLT6GKioEw.png)

**2. Message Intermediate Catch Event:** This event is used to wait for a specific message during the execution of a process.

![](https://miro.medium.com/v2/resize:fit:58/1*rPdeS88bwsk4JDk47_zZ7Q.png)

**3. Message Intermediate Throw Event:** This event is used to send a message during the execution of a process.

![](https://miro.medium.com/v2/resize:fit:58/1*zW7W-2QLRvpfmJWWQcOKeA.png)

**4. Message End Event:** This event is used to end a process instance and send a message as a result.

![](https://miro.medium.com/v2/resize:fit:58/1*krxt-Ef9uQYrOWMyzc_7rw.png)

These events allow for decoupling different parts of a process, making it easier to model and manage complex workflows.

### 6. What Types of Timer Events Are There in Camunda?

Timer events in Camunda allow developers to schedule activities at specific points in time during process execution. Knowing the various types of timer events and their configurations empowers developers to design time-sensitive workflows with precision and accuracy.

There are several types of timer events in Camunda, allowing for different ways to define and trigger time-based events. Here are the main types:

1.  **Timer Start Event:**

![](https://miro.medium.com/v2/resize:fit:58/1*ghklNkHO3k5TlMqxNABJtg.png)

-   Usage: Initiates a process instance based on a time schedule or a specific timer configuration.
-   Configuration: You can define a time duration, date, or a cron expression to trigger the start of the process.

**2. Timer Boundary Event:**

![](https://miro.medium.com/v2/resize:fit:168/1*QCDrdBZUFft3mdjMjg0wTQ.png)

-   Usage: Attached to a user task, service task, or other activities to interrupt or escalate when a specified time is reached.
-   Configuration: Similar to the timer start event, you can use a time duration, date, or a cron expression to define when the timer boundary event should trigger.

3. **Timer Intermediate Catch Event:**

![](https://miro.medium.com/v2/resize:fit:53/1*nPeDmahONxciISizopl6Iw.png)

-   Usage: Pauses the process execution until a specified time is reached.
-   Configuration: Similar to the timer boundary event, you can use a time duration, date, or a cron expression to specify when the intermediate timer event should trigger.

4. **Timer Intermediate Throw Event:**

![](https://miro.medium.com/v2/resize:fit:756/1*kC-lERzc14jxgHf6p3a33Q.png)

-   Usage: Allows a process to throw an event at a specific time, which can be caught by a catching event elsewhere in the process.
-   Configuration: You define a time duration, date, or a cron expression to specify when the intermediate throw event should trigger.

5. **Escalation Timer Event:**

![](https://miro.medium.com/v2/resize:fit:63/1*WadvL8J3WxcyCczhoxQhYw.png)

-   Usage: Similar to the timer boundary event, it is used to escalate a task when a specified time is reached.
-   Configuration: You can define a time duration, date, or a cron expression to trigger the escalation.

6. **Cycle Timer Event:**

![](https://miro.medium.com/v2/resize:fit:330/1*D7OsfX3eo65umTEHGIZ92w.png)

-   Usage: Used in a recurring manner to repeat or cycle a task or event at specified intervals.
-   Configuration: You define a time duration and a repetition pattern to specify the cycle.

Each type of timer event serves a specific purpose in the context of process modeling, allowing for the automation of time-related behaviors within business processes. The configuration options for timer events provide flexibility in expressing time conditions, whether it’s a one-time occurrence, a recurring pattern, or an escalation trigger.

### 7. How Do You Configure LDAP with Camunda?

LDAP (Lightweight Directory Access Protocol) integration is crucial for authenticating and authorizing users in Camunda BPM. Understanding how to configure LDAP with Camunda ensures seamless integration with existing identity management systems, enhancing security and user management capabilities.

LDAP integration allows Camunda to leverage existing user accounts and groups managed by an LDAP server. Here are the general steps to configure LDAP with Camunda:

### 1. Open `application.yml` or `application.properties`:

-   Locate and open the `application.yml` or `application.properties` file in your Camunda web application's configuration directory.

### 2. Add LDAP Configuration:

Example for `application.yml`:
```yml
camunda:  
  bpm:  
    admin-user:  
      id: demo  
      password: demo  
    filter:  
      createAdminUser: false  
  webapp:  
    security:  
      ldap:  
        server-url: ldap://your-ldap-server:389  
        manager-dn: cn=admin,dc=example,dc=com  
        manager-password: secret  
        user-search-base: ou=users,dc=example,dc=com  
        user-search-filter: (sAMAccountName={0})  
        group-search-base: ou=groups,dc=example,dc=com  
        group-search-filter: (member={0})
```
Example for `application.properties`:
```shell
camunda.bpm.admin-user.id=demo  
camunda.bpm.admin-user.password=demo  
camunda.bpm.filter.createAdminUser=false  
camunda.webapp.security.ldap.server-url=ldap://your-ldap-server:389  
camunda.webapp.security.ldap.manager-dn=cn=admin,dc=example,dc=com  
camunda.webapp.security.ldap.manager-password=secret  
camunda.webapp.security.ldap.user-search-base=ou=users,dc=example,dc=com  
camunda.webapp.security.ldap.user-search-filter=(sAMAccountName={0})  
camunda.webapp.security.ldap.group-search-base=ou=groups,dc=example,dc=com  
camunda.webapp.security.ldap.group-search-filter=(member={0})
```
### 3. Modify LDAP Configuration Parameters:

-   Adjust the LDAP configuration parameters according to your LDAP server setup. Key parameters include `server-url`, `manager-dn`, `manager-password`, `user-search-base`, `user-search-filter`, `group-search-base`, and `group-search-filter`.

### 4. Enable LDAP Authentication in Identity Service:

-   Ensure that LDAP authentication is enabled in the Camunda Identity Service. You may need to set the `camunda.bpm.identity-service.enabled` property to `true`.

### 5. Restart Camunda:

-   After making the necessary changes, restart your Camunda web application to apply the LDAP configuration.

### 6. Test LDAP Integration:

-   Log in to the Camunda web application using LDAP credentials to verify that the integration is successful.

### Additional Notes:

-   The provided examples assume an LDAP server using the standard port 389. Adjust the `server-url` accordingly if your LDAP server uses a different port or protocol (e.g., LDAPS on port 636).
-   The `user-search-filter` and `group-search-filter` values may need adjustments based on the LDAP schema and structure used in your organization.

### 8. What Is a System Task?

System tasks in Camunda BPM are automated tasks executed by the engine without manual intervention. Knowledge of system tasks, including service tasks, script tasks, and external system integrations, enables developers to automate business processes effectively.

Here are some key points about system tasks in Camunda:

1.  **Automated Execution**: System tasks are executed automatically by the Camunda engine. They do not require manual interaction from users; instead, the engine takes care of their execution as part of the process flow.
2.  **Built-in Functionality:** Camunda provides various built-in system tasks for common functionalities, such as service tasks for invoking external services, script tasks for executing scripts, and more.
3.  **Service Task:** The most common type of system task is the service task. It is used to invoke external services, connectors, or delegate expressions, allowing for integration with external systems.
4.  **Script Task:** Another type of system task is the script task, which allows you to execute scripts (e.g., JavaScript, Groovy) directly within the BPMN process.
5.  **External System Integration:** System tasks are often used to model interactions with external systems, such as calling a web service, executing a script, or performing some automated action.

Here’s a simple example of a service task in BPMN:
```xml
<serviceTask id="externalServiceTask" name="Invoke External Service"  
             camunda:class="com.example.ExternalServiceTaskHandler" />
```
In this example, the `serviceTask` element represents a system task, and the `camunda:class` attribute specifies the Java class (`com.example.ExternalServiceTaskHandler`) responsible for executing the task.

It’s important to note that while system tasks are automated and do not require user interaction, they play a crucial role in orchestrating the execution of a business process by integrating with external systems and services.

### 9. What Types of Tasks Are Available in Camunda?

Camunda offers various types of tasks for modeling different activities within business processes, such as user tasks, service tasks, script tasks, and more. Understanding the different task types and their use cases equips developers with the tools to design robust and efficient BPM solutions.

Here are some common types of tasks in Camunda:

1.  **User Task:**

![](https://miro.medium.com/v2/resize:fit:175/1*oQmFtOYcx9LjZmIpMwGplw.png)

-   Description: Represents a task that needs to be performed by a human user.
-   Usage: Used for activities that require manual interaction, such as approvals, reviews, or data entry.

2. **Service Task:**

![](https://miro.medium.com/v2/resize:fit:164/1*V3B2JE0xiknDmALqM6BSVA.png)

-   Description: Represents a task that invokes a service or an external system.
-   Usage: Used for integrating with external systems, calling APIs, or executing custom business logic.

**3. Script Task:**

![](https://miro.medium.com/v2/resize:fit:149/1*QZZaE3qT_7XZ7iGmRejGqg.png)

-   Description: Represents a task that executes a script (e.g., JavaScript, Groovy).
-   Usage: Used for custom scripting and calculations within the process.

4. **Business Rule Task:**

![](https://miro.medium.com/v2/resize:fit:149/1*jfvnvlap1Drfg6BAQCAIEg.png)

-   Description: Represents a task that executes a business rule.
-   Usage: Used for applying business rules defined in decision tables.

5. **Send Task:**

![](https://miro.medium.com/v2/resize:fit:148/1*M9lCPyxcvC74GmLBtJuMbw.png)

-   Description: Represents a task that sends a message to an external system.
-   Usage: Used for sending messages to external systems or messaging queues.

6. **Receive Task:**

![](https://miro.medium.com/v2/resize:fit:146/1*grr_du7OtXc51h1s9tubkQ.png)

-   Description: Represents a task that waits for a message from an external system.
-   Usage: Used for receiving messages from external systems.

7. **Manual Task:**

![](https://miro.medium.com/v2/resize:fit:150/1*ws6uBXlwZtjxkgOU5zuNvg.png)

-   Description: Represents a generic task that requires manual intervention.
-   Usage: Similar to a user task but can be used for non-user activities that still require manual attention.

**8. Subprocess:**

![](https://miro.medium.com/v2/resize:fit:158/1*u0MdYvrgprPYCsdwsapfWQ.png)

-   Description: Represents a subprocess, which is a self-contained sequence of activities.
-   Usage: Used for modularizing and organizing complex processes.

9. **Call Activity:**

![](https://miro.medium.com/v2/resize:fit:154/1*k6h45j2tcbwnJfBxmA7xTw.png)

-   Description: Represents a task that calls another process (subprocess or global process).
-   Usage: Used for reusing and integrating external processes within the current process.

10. **Event Subprocess:**

![](https://miro.medium.com/v2/resize:fit:875/1*BKBfcgvibc2q_FMkzBTskA.png)

-   Description: Represents a subprocess that is triggered by an event.
-   Usage: Used for handling specific events within the process.

11. **Transaction:**

![](https://miro.medium.com/v2/resize:fit:875/1*gJfac2QEyGd7pX-nL45MhQ.png)

-   Description: Represents a grouping of activities that are treated as a single transaction.
-   Usage: Used for defining transactional behavior within the process.

### 10. How Do I Migrate to a New Version of a BPM Process in Camunda?

Migrating to a new version of a BPMN process in Camunda requires careful planning and execution to ensure a smooth transition of existing process instances and data. Understanding the migration process and tools available in Camunda enables developers to seamlessly upgrade process versions while minimizing disruptions to ongoing workflows.

Here is a general guide on how you can approach the migration process:

### 1. Prepare the New Process Version:

-   Make necessary changes to your BPMN process model using Camunda Modeler or other BPMN modeling tools.
-   Increment the process version number or define a new version identifier.

### 2. Deploy the New Process Version:

-   Deploy the updated BPMN process to your Camunda BPM engine. This can be done using the Camunda Modeler or by deploying the updated BPMN file through the Camunda REST API, Cockpit, or other deployment methods.

### 3. Handle Process Instance Migration:

-   Consider how you want to handle existing process instances that are currently running based on the old process version.
-   Camunda provides the Process Instance Migration feature, which allows you to migrate running process instances from one version to another. This can be done manually or programmatically using the Camunda Java API.

### 4. Use Process Definition Key and Version Tagging:

-   Maintain consistency in process definition keys across versions to facilitate easier querying.
-   Consider using version tagging or labels to associate versions with specific releases or changes.

### 5. Update External References:

-   If your process interacts with external systems or services, ensure that the changes in the new process version are compatible with the existing integrations.

### 6. Testing:

-   Thoroughly test the new process version in a development or testing environment to identify any issues or unexpected behavior.
-   Consider using the Camunda Test Scenarios feature to automate testing.

### 7. Communicate Changes:

-   Communicate the changes to stakeholders, including process participants, administrators, and developers, to ensure awareness of the updates.

### 8. Execute the Migration:

-   If you decide to perform a manual migration of process instances, ensure that you have a clear plan and follow the Camunda documentation for manual migration steps.
-   If you choose to use the Camunda Java API for programmatic migration, implement the necessary logic for migrating process instances.

### 9. Monitor and Optimize:

-   Monitor the execution of the new process version in production to identify any issues that may arise.
-   Optimize the process based on performance metrics and user feedback.

### Additional Considerations:

-   Camunda provides the “Migration” feature in Camunda Modeler, which allows you to graphically define migration paths for process instances transitioning from one version to another.
-   Consider using the Camunda Cockpit tool to monitor and analyze the execution of process instances during and after the migration.

### 11. What Is the Difference Between a Message Event and a Signal Event?

Message events and signal events in BPMN serve as mechanisms for communication between different parts of a process or between processes. Understanding the differences between these event types, including their use cases and functionalities, empowers developers to design event-driven workflows effectively in Camunda BPM.

While message events and signal events in Camunda BPM share similarities in terms of facilitating communication between different parts of a process or between different processes, they serve distinct purposes and have some key differences:

**Message Events:**

1.  **Specific Message Identification:** Message events are associated with specific message names. A sender sends a message with a particular name, and a receiver waits for a message with that specific name.
2.  **Payloads:** Message events can include optional payloads, allowing data to be transmitted along with the message.
3.  **Point-to-Point Communication:** Message events are suitable for point-to-point communication, where a specific sender communicates with a specific receiver based on the defined message name.

### Signal Events:

1.  **Global Signaling:** Signal events, on the other hand, are more like global signals that can be caught by any process or activity that is configured to catch that signal.
2.  **No Specific Message Name:** Unlike message events, signal events do not require a specific message name. Instead, they are associated with a global signal name.
3.  **Broadcast Communication:** Signal events allow for broadcast communication, where a signal can be caught by multiple processes or activities that are configured to catch that signal.
4.  **No Payloads:** Unlike message events, signal events do not carry payloads. They are more about notifying that a particular event or condition has occurred.

### Choosing Between Message Events and Signal Events:

-   **Use Message Events When:**
-   _You need point-to-point communication with a specific message name._
-   _There is a need for sending data (payload) along with the message._
-   **Use Signal Events When:**
-   _You want to broadcast a signal that can be caught by any process or activity interested in that signal._
-   _You don’t need to associate a specific message name, and no payload data is required._

In summary, while both message events and signal events enable communication between different parts of a process or between processes, the choice between them depends on whether you need specific point-to-point communication (message events) or a more global, broadcast-style notification (signal events).

### 12. What are different types of start events in Camunda?

In Camunda BPM (Business Process Management), start events are used to indicate how a process instance is initiated. There are several types of start events in Camunda, each serving a different purpose. Here are the main types:

1.  **Start Event (None):**

![](https://miro.medium.com/v2/resize:fit:70/1*UhE4DmO3Fp9tl95SQtdZ8g.png)

-   Usage: This is a default start event that doesn’t have any specific trigger. It initiates a process when no other specific trigger condition is needed.
-   Configuration: No additional configuration is required for this start event.

2. **Message Start Event:**

![](https://miro.medium.com/v2/resize:fit:74/1*Juh9jcOImWbBVcdM4BzqaQ.png)

-   Usage: Initiates a process instance when a specific message is received.
-   Configuration: You specify the name of the message that triggers the start of the process.

3. **Timer Start Event:**

![](https://miro.medium.com/v2/resize:fit:63/1*HKDmJXbbhlHZzMTAgV869Q.png)

-   Usage: Initiates a process instance based on a time schedule or a specific timer configuration.
-   Configuration: You can define a time duration, date, or a cron expression to trigger the start of the process.

4. **Signal Start Event:**

![](https://miro.medium.com/v2/resize:fit:68/1*uxRM1I4niX7iX4XJ63ypCg.png)

-   Usage: Initiates a process instance when a specific signal is received.
-   Configuration: You specify the name of the signal that triggers the start of the process.

5. **Conditional Start Event:**

![](https://miro.medium.com/v2/resize:fit:65/1*OuVQbXxQXvkh1Ks7UWIMcA.png)

-   Usage: Initiates a process instance based on a specified condition.
-   Configuration: You define a condition expression, and the process starts when the condition is satisfied.

6. **Multiple Start Event:**

![](https://miro.medium.com/v2/resize:fit:863/0*Fhm_9RqaJ7_JBctw.png)

-   Usage: Allows for multiple start events within a process, and the process instance can be initiated by any of them.
-   Configuration: Each start event within the multiple start event can have its own configuration.

7. **Signal Start Event (Interrupting):**

![](https://miro.medium.com/v2/resize:fit:760/1*Tw6Hm_-g64DeXxPwrn6RUg.png)

-   Usage: Similar to the regular signal start event but with the ability to interrupt an ongoing process instance when the signal is received.
-   Configuration: You specify the name of the signal that triggers the start of the process, and it can interrupt an existing process instance if configured to do so.

These start events provide flexibility in how a process instance can be initiated, whether it’s based on messages, timers, signals, conditions, or a combination of these triggers. The appropriate start event depends on the specific requirements and workflow of the business process being modeled.

By mastering these essential questions, you’ll be well-prepared to demonstrate your expertise and excel in your Camunda developer interview. Whether you’re a seasoned professional or new to Camunda BPM, continuous learning and practice are key to success in the dynamic field of business process management.

---

# Automating Workflows with BPMN, Camunda, and Spring Boot

Efficient workflow automation is a critical need for modern enterprises, and tools like BPMN, Camunda, and Spring Boot provide a seamless way to achieve this. This article explores these technologies, their integration, and how they can revolutionize business process management.

### What is BPMN?

**Business Process Model and Notation (BPMN)** is a graphical representation standard for modeling business processes. BPMN provides a shared language for both technical developers and business stakeholders to design and understand workflows effectively.

### Key Features of BPMN:

-   **Visual Notation**: BPMN diagrams use standardized symbols such as tasks, events, gateways, and flows, making them universally understandable.
-   **Executable**: Designed to be executed by workflow engines, enabling automated process management.
-   **Flexible**: Supports simple and complex workflows, decision points, and loops.

### What is Camunda?

**Camunda** is an open-source platform that facilitates workflow and decision automation. It enables the execution of BPMN processes and provides tools for process design, monitoring, and management.

### Core Components of Camunda:

### **1. Camunda Engine**:

Executes BPMN workflows and DMN (Decision Model and Notation) decision tables. The Camunda Engine serves as the heart of the platform, responsible for managing and executing business processes defined in BPMN diagrams. It interprets the process definitions, ensuring tasks are carried out in the defined sequence.

### Key Functionalities:

-   **Workflow Orchestration**: Coordinates tasks, decision points, and events according to the BPMN model.
-   **Task Assignment**: Allocates tasks to users or systems based on predefined rules.
-   **Transaction Management**: Ensures reliability through robust error handling and transaction boundaries.

### 2. **Camunda Modeler**:

A desktop application for designing BPMN and DMN diagrams. Compared to other BPMN modeling tools like Signavio or Bizagi, Camunda Modeler stands out for its simplicity, open-source nature, and direct integration with the Camunda Engine. While tools like Signavio focus heavily on collaborative features and advanced analytics, Camunda Modeler is lightweight, making it ideal for developers who prioritize seamless deployment and execution.

### 3. **Tasklist**:

A web-based tool for managing user tasks. For example, in a customer support workflow, Tasklist can assign and track tasks for support agents. When a support ticket is created, it appears in the Tasklist for the responsible agent, who can then mark it as “in progress” or “resolved.” This ensures that all tasks are accounted for and completed efficiently, improving overall process transparency and accountability.

### 4. **Cockpit**:

Camunda Cockpit is a web-based tool for monitoring and managing business processes and workflows in the Camunda BPM (Business Process Management) platform. It provides an intuitive interface that allows users to view and manage the execution of processes, decisions, and cases in real time.

### Some key features of Camunda Cockpit include:

1.  **Process Monitoring**: It allows users to track the progress of process instances, view task lists, and monitor process flows.
2.  **Task Management**: Users can manage human tasks, assign tasks to users, and observe the status of task execution.
3.  **Process Analysis**: Provides insights into the performance of processes, such as historical data, task completion times, and bottlenecks.
4.  **Error Handling**: It can display failed or suspended processes, giving administrators the tools to resolve issues.
5.  **Process Definition and Version Management**: It helps users to view and deploy different versions of process definitions, ensuring that the most current version is being executed.

Overall, Camunda Cockpit is essential for administrators and business process managers to effectively monitor and optimize business processes in a Camunda-powered system.

### 4. Camunda Tasklist

**Camunda Tasklist** is a web-based application that allows users to manage and complete their tasks within the process. These tasks can be user tasks, approval steps, or any other work that requires human intervention.

**Key responsibilities**:

-   View and manage personal tasks assigned to a user.
-   Complete tasks and move the process forward.
-   Attach documents or data relevant to tasks.
-   Delegate or escalate tasks as needed.

### 5. REST API (External Interfaces)

The **REST API** provides an interface for integrating Camunda with external systems, applications, or services. It allows for process initiation, task management, event subscription, and more.

**Key responsibilities**:

-   **Process Interaction**: Trigger processes or process instances via HTTP calls.
-   **Task Interaction**: Claim, complete, or update tasks from external systems.
-   **Event Interaction**: Send or receive events via external systems.
-   **Query Operations**: Query the status, history, or other metrics of processes and tasks.

### 6. External Services and Connectors

Camunda integrates easily with external systems, including databases, external APIs, and other services. These integrations typically occur through **Connectors** or **Service Tasks** within BPMN processes. Service tasks invoke external systems or microservices during process execution.

**Key responsibilities**:

-   Invoke REST APIs, web services, or other external systems.
-   Perform activities like sending an email, calling a database, or executing business logic in an external service.

### 7. Database (Persistent Storage)

Camunda uses a relational database to store the persistent state of processes, tasks, and decision tables. The **database** stores process instances, task assignments, and audit information (logs and history). Camunda can be configured to use a variety of relational databases such as MySQL, PostgreSQL, Oracle, etc.

**Key responsibilities**:

-   Store process instance state, task data, and execution history.
-   Handle transactional consistency for long-running processes.
-   Provide historical data for monitoring and reporting.

### 8. Camunda History and Analytics

Camunda allows for the storage of historical data related to process instances, task completions, errors, and more. Analytics can be used to track performance, optimize processes, and ensure compliance.

**Key responsibilities**:

-   Track and store historical data on processes and tasks.
-   Provide reporting tools for analyzing workflow efficiency and bottlenecks.
-   Offer insights into task durations, process performance, and other metrics.

### Understanding Camunda Events, Service Tasks, and Gateways

### A. Events in Camunda

In Camunda, **events** refer to specific occurrences or triggers within a business process or workflow. These events can be used to react to certain conditions, control the flow of the process, or capture specific actions during the execution of a process.

Camunda defines events in the context of BPMN (Business Process Model and Notation) and CMMN (Case Management Model and Notation), which are used to model business processes and cases, respectively.

### Types of Events in Camunda

1.  **Start Events**:

-   **Trigger the start of a process**.
-   A process can start due to various conditions such as a timer, message, or a specific signal.
-   Examples: **Message Start Event**, **Timer Start Event**, **Signal Start Event**.

**2. Intermediate Events**:

-   **Occur during the execution of a process**.
-   These events are used to interrupt or continue the flow of a process based on certain conditions, like receiving a message or reaching a specific time.
-   Examples: **Message Intermediate Event**, **Timer Intermediate Event**, **Signal Intermediate Event**.

**3. Boundary Events**:

-   These are attached to an activity (like a task) and are used to **handle events that occur during the execution of that activity**.
-   Boundary events can interrupt or escalate the execution of an activity depending on the event.
-   Examples: **Timer Boundary Event**, **Message Boundary Event**, **Error Boundary Event**.

**4. End Events**:

-   **Mark the conclusion of a process**.
-   End events are used to finalize a process and may handle specific actions when a process ends, such as sending a signal or a message.
-   Examples: **Message End Event**, **Error End Event**, **Terminate End Event**.

**5. Catch Events**:

-   These events “catch” an event and wait for a specific condition to occur.
-   Common examples include **Message Catch Event**, **Signal Catch Event**, and **Timer Catch Event**.

**6. Throw Events**:

-   These events “throw” an event to signal or trigger other parts of a process.
-   Example: **Message Throw Event**, **Signal Throw Event**.

**7. Event Subprocesses**:

-   These are subprocesses that are triggered by specific events (such as a message or signal).
-   Event subprocesses run in parallel with the main process and can handle exceptional or interruptive events.

### Key Categories of Events in Camunda:

-   **Message Events**: Used when a message is sent or received, which can trigger actions or cause interruptions.
-   **Timer Events**: Used to trigger actions based on time-related conditions, such as timeouts or scheduled executions.
-   **Signal Events**: Used to broadcast a signal across different processes or instances.
-   **Error Events**: Triggered when an error occurs, often used to manage fault handling or exception flows.
-   **Compensation Events**: Used to invoke compensation logic to revert previous actions (e.g., undoing a task that was completed).

### Event Handling in Camunda

-   **Event Listeners**: Camunda allows for custom event listeners to be added to monitor or react to specific events. These listeners can be implemented using Java, REST APIs, or other integration methods.
-   **Event Subscriptions**: Some events may require processes to subscribe to certain events (e.g., a process subscribing to a message event). These subscriptions ensure that the process can handle and react to the event when it occurs.

In summary, events in Camunda allow you to control the flow of processes and respond dynamically to different situations, such as user actions, external messages, or system failures. They help define the behavior of processes in response to various conditions or triggers.

### B. Service Tasks in Camunda

Service tasks are automated activities that perform specific logic. These tasks are often integrated with external systems or custom business logic implemented in Java classes or REST APIs.

### Key Features:

-   **Custom Logic**: Execute Java delegates or invoke REST services.
-   **Integration**: Seamlessly interact with external APIs or databases.

### Example Implementation:

In a payment processing workflow, a service task could handle payment validation by invoking a third-party API.

### C. Gateways in Camunda

Gateways control the flow of execution within a process. They enable decision-making and parallel processing.

### Types of Gateways:

-   **Exclusive Gateway**: Routes the flow based on conditions, ensuring only one path is taken.
-   Example: Approve or reject a loan application based on credit score.
-   **Parallel Gateway**: Splits the process into multiple paths that execute simultaneously.
-   Example: Notify customer and update database concurrently.
-   **Inclusive Gateway**: Allows one or more paths to be taken based on conditions.
-   Example: In a refund process, process refunds for multiple products.

### Why Use Camunda with Spring Boot?

Combining **Camunda** with **Spring Boot** brings several benefits:

1.  **Ease of Integration**: The Camunda Spring Boot Starter simplifies embedding Camunda into Spring Boot applications.
2.  **Workflow Automation**: Enables automation of business processes through BPMN diagrams.
3.  **Scalability**: Spring Boot’s robust architecture supports enterprise-scale workflow automation.
4.  **Monitoring and Control**: Camunda’s Cockpit and Tasklist provide real-time monitoring and management.
5.  **Open Source**: Cost-effective and backed by an active community.

### Step-by-Step Guide: Camunda BPMN with Spring Boot

### 1. Create a Spring Boot Project

Use [Spring Initializr](https://start.spring.io/) to generate a Spring Boot project. Add the following dependencies:
```xml
<dependency>  
    <groupId>org.camunda.bpm.springboot</groupId>  
    <artifactId>camunda-bpm-spring-boot-starter</artifactId>  
    <version>7.18.0</version> <!-- Replace with the correct version -->  
</dependency>  
<dependency>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-starter-web</artifactId>  
</dependency>
```

### 2. Configure Camunda

Add the following configurations in `application.properties` to set up the Camunda engine:

### Camunda Configuration  
```shell
camunda.bpm.admin-user.id=admin  
camunda.bpm.admin-user.password=admin  
camunda.bpm.admin-user.firstName=Admin  
  
### H2 database for development  
spring.datasource.url=jdbc:h2:mem:camunda;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE  
spring.datasource.driver-class-name=org.h2.Driver  
spring.datasource.username=sa  
spring.datasource.password=  
spring.h2.console.enabled=true
```
### 3. Design a BPMN Process

Use the **Camunda Modeler** to create a BPMN diagram and save it as `process.bpmn` in `src/main/resources`.

Example BPMN Process:

-   **Start Event**: Marks the process initiation.
-   **Service Task**: Executes a specific business logic (e.g., “Process Order”).
-   **Exclusive Gateway**: Adds decision logic (e.g., valid or invalid order).
-   **End Event**: Ends the workflow with appropriate outcomes.

Sample BPMN XML:
```xml
<?xml version="1.0" encoding="UTF-8"?>  
<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" id="Definitions_1">  
  <bpmn:process id="exampleProcess" isExecutable="true">  
    <bpmn:startEvent id="StartEvent_1" name="Start">  
      <bpmn:outgoing>Flow_1</bpmn:outgoing>  
    </bpmn:startEvent>  
    <bpmn:sequenceFlow id="Flow_1" sourceRef="StartEvent_1" targetRef="Task_1" />  
    <bpmn:serviceTask id="Task_1" name="Service Task" camunda:class="com.example.ServiceTaskDelegate">  
      <bpmn:incoming>Flow_1</bpmn:incoming>  
      <bpmn:outgoing>Flow_2</bpmn:outgoing>  
    </bpmn:serviceTask>  
    <bpmn:sequenceFlow id="Flow_2" sourceRef="Task_1" targetRef="EndEvent_1" />  
    <bpmn:endEvent id="EndEvent_1" name="End">  
      <bpmn:incoming>Flow_2</bpmn:incoming>  
    </bpmn:endEvent>  
  </bpmn:process>  
</bpmn:definitions>
```
### **4. Create a Spring Boot application class to run the application**
```java
@SpringBootApplication  
public class CamundaApplication {  
  
    public static void main(String[] args) {  
        SpringApplication.run(CamundaApplication.class, args);  
    }  
}
```

### **5. Create a REST Controller to Start the Workflow Process**

-   Next, create a `RestController` to expose an endpoint to start the workflow process. You can use `RuntimeService` to start the process instance.
```java
import org.camunda.bpm.engine.RuntimeService;  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RestController;  
  
@RestController  
@RequestMapping("/workflow")  
public class WorkflowController {  
  
    @Autowired  
    private RuntimeService runtimeService;  
  
    @GetMapping("/start")  
    public String startProcess() {  
        // Starting the process instance  
        runtimeService.startProcessInstanceByKey("sampleProcess");  
        return "Process started successfully!";  
    }  
}
```

In the above code:

-   The `RuntimeService` is used to start the workflow process.
-   The `startProcessInstanceByKey()` method is used to start the process with the given process key (which is `sampleProcess` as defined in the BPMN file).

### 6. Start the Process Instance Using Java Code:
```java
@Autowired  
private RuntimeService runtimeService;  
  
public void startProcess() {  
    runtimeService.startProcessInstanceByKey("exampleProcess");  
}
```
### 7. Implement a Service Task Delegate

Create a Java class to handle service tasks:
```java
package com.example;  
  
import org.camunda.bpm.engine.delegate.DelegateExecution;  
import org.camunda.bpm.engine.delegate.JavaDelegate;  
import org.springframework.stereotype.Component;  
@Component  
public class ServiceTaskDelegate implements JavaDelegate {  
    @Override  
    public void execute(DelegateExecution execution) {  
        System.out.println("Executing Service Task...");  
        // Add business logic here  
    }  
}
```

### 7. Run the Application

Start your Spring Boot application. The Camunda web interface will be available at [http://localhost:8080](http://localhost:8080/).

-   Default credentials: `admin/admin`.
-   BPMN files in `src/main/resources` will be deployed automatically.

### 8. Trigger the BPMN Process

You can start the process using the REST API or programmatically:

Using REST API:
```shell
POST http://localhost:8080/engine-rest/process-definition/key/exampleProcess/start
```

### Camunda 7 vs Camunda 8: A Detailed Comparison

Camunda is a powerful workflow and decision automation platform, but with the introduction of Camunda 8, significant differences have emerged compared to its predecessor, Camunda 7. This article explores these differences, including architecture, deployment, features, and use cases, while also examining Zeebe’s role in microservices-based orchestration.

### 1. Architecture & Engine

-   **Camunda 7**: Uses a monolithic, Java-based BPMN process engine, relying on relational databases for persistence.
-   **Camunda 8**: Built around **Zeebe**, a cloud-native, event-driven process engine designed for high scalability.

### 2. Deployment & Scalability

-   **Camunda 7**: Designed for traditional deployments on **Tomcat, WildFly, and Spring Boot**. Suitable for on-premises setups.
-   **Camunda 8**: Kubernetes-native, enabling **horizontal scaling** with microservices.

### 3. BPMN Execution & Persistence

-   **Camunda 7**: Executes BPMN workflows using a relational database with full ACID transactions.
-   **Camunda 8**: Uses an **event-sourcing model** and append-only logs, relying on **Elasticsearch** instead of relational databases.

### 4. Features & Tooling

![](https://miro.medium.com/v2/resize:fit:875/1*1964WkqZMfsVvcgQQ9kkeg.png)

### 5. Integration & API Support

-   **Camunda 7**: Supports **REST and Java APIs** for process execution.
-   **Camunda 8**: Uses **gRPC and GraphQL**, optimized for microservices and event-driven architectures.

### 6. Open-Source vs Enterprise Edition

Camunda 8 follows a hybrid open-source model:

-   **Open-Source Components**:
-   Zeebe (Workflow Engine, Apache 2.0 License)
-   Zeebe Client Libraries (Java, Go, Node.js, etc.)
-   BPMN Modeler
-   **Enterprise-Only Components**:
-   **Camunda Operate** — Workflow monitoring & troubleshooting
-   **Camunda Tasklist** — User task management
-   **Camunda Optimize** — Advanced analytics and reporting
-   **Clustered Deployments & HA** — For large-scale production environments

### 7. Zeebe as a Microservices Orchestrator — How Zeebe Supports Microservices

1.  **Decentralized Execution**: Unlike traditional BPMN engines, Zeebe does not execute service tasks directly. Instead, it uses **external workers** for task execution.
2.  **Event-Driven**: Zeebe operates on a **log-based, event-driven** model, making it ideal for microservices architectures.
3.  **Asynchronous Communication**: It integrates with **Kafka, RabbitMQ, and gRPC** for messaging.
4.  **Stateless Scalability**: Since Zeebe is **database-free**, it scales horizontally across distributed systems.
5.  **Deployment Options**:

-   Standalone Zeebe cluster with external workers
-   Embedded Zeebe engine within microservices
-   Kubernetes-based deployment

### Zeebe vs Traditional BPMN Engines for Microservices

![](https://miro.medium.com/v2/resize:fit:875/1*lTkr1CO3iatSy3mCyuDD0A.png)

Feature Zeebe (Camunda 8) Traditional BPMN (Camunda 7) Execution Model **Event-driven** Database transaction-based Scalability **Horizontally scalable** Limited scalability Task Handling **External Workers (gRPC, Kafka, REST)** Direct Java execution State Management **Log-based, NoSQL** Relational database Microservices Integration **Decoupled, async** Tightly coupled

### 8. Which One Should You Choose?

-   **Choose Camunda 7** if you need a **traditional BPMN workflow engine** with **relational database support** and enterprise process automation.
-   **Choose Camunda 8** if you need a **cloud-native, microservices-oriented** solution with high scalability and event-driven architecture.

Camunda 8, powered by Zeebe, is an ideal choice for **modern, scalable, event-driven** microservices-based workflows. However, for organizations relying on **transactional integrity and traditional Java-based BPMN execution**, Camunda 7 remains a solid option. Choosing the right version depends on your **architecture, scalability needs, and enterprise requirements**.

---
# Why we need Camunda and when we have to use ?(Part 1)
> In this part I will explain what is BPMN ,CMMN and DMN and their benefits

![](https://miro.medium.com/v2/resize:fit:875/1*oxf9tnLyadiTLZX1dXIRYg.jpeg)
Camunda

_Imagine building an onboarding flow that requires verifying documents, waiting for approvals, integrating with external APIs, and handling different outcomes. You could write this all in code — or you could model and automate it cleanly using Camunda._

Briefly define what Camunda is:

> Camunda is a lightweight, open-source process automation platform that helps developers and business teams model, execute, and monitor complex workflows using standards like BPMN, CMMN, and DMN.

**What is BPMN ?**

**Business Process Model and Notation (BPMN)** is a **visual modeling language** used to represent business process workflows in the form of flowcharts. It is an **open standard** designed to be easily understood by all stakeholders — including business users, analysts, developers, and data architects. BPMN provides a common language that bridges the gap between business process design and technical implementation, making it easier to analyze, automate, and improve complex workflows.

![](https://miro.medium.com/v2/resize:fit:875/0*G9wTxooo0MSA5XLM.jpg)
example elements of Camunda

> Why we need BPMN ?

In modern software development and business operations, teams often struggle with **miscommunication between business stakeholders and developers**, **hardcoded workflows**, and **poor visibility into processes**. BPMN solves these challenges by providing a **shared visual language** for defining, discussing, and automating business workflows.

### Use BPMN when :

1.  **Improves Communication Between Business and IT**
2.  Visualizes Complex Workflows Clearly
3.  Supports Process Automation
4.  Enables Monitoring and Optimization
5.  Handles Changes Easily

_Core Concepts of BPMN :_

### 1. Flow Objects

These define the main logic of the process.

**1.1)Events** (Circles): Something that happens.

-   **Start Event** (e.g., new order received)
-   **Intermediate Event** (e.g., wait for signal, timer)
-   **End Event** (e.g., process completed)

![](https://miro.medium.com/v2/resize:fit:875/0*N45ObzBjIIkkrp2R.png)

**1.2)Activities** (Rounded rectangles): Work that needs to be done.

-   **Tasks** (e.g., “Send Email”)
-   **Sub-processes** (can be expanded)

![](https://miro.medium.com/v2/resize:fit:603/0*tuC1dWLTHMv72te7.jpg)

**1.3)Gateways** (Diamonds): Represent decision points or merging paths.

-   **Exclusive (XOR)**: Only one path proceeds
-   **Parallel (AND)**: All paths proceed
-   **Inclusive (OR)**: One or more paths proceed

![](https://miro.medium.com/v2/resize:fit:875/0*d4z3nCTeiu0J-90A.png)

### 2. Connecting Objects

These connect the flow elements.

-   **Sequence Flows** (solid arrows): Define the order of activities.
-   **Message Flows** (dashed arrows): Represent communication between participants.
-   **Associations** (dotted lines): Connect artifacts like data or annotations.

![](https://miro.medium.com/v2/resize:fit:875/0*XkvJ858MHr_8pMFn.gif)

### 3. Swimlanes

Used to show **responsibility** within the process.

![](https://miro.medium.com/v2/resize:fit:875/0*yxxw9fNbv1KSH86Y)

-   **Pools**: Represent different participants (e.g., departments, systems).
-   **Lanes**: Subdivisions within pools (e.g., roles, users).

### 4. Artifacts

Provide supporting information.

-   **Data Objects**: Input/output data
-   **Groups**: Informal grouping of tasks
-   **Text Annotations**: Notes or descriptions

**What is CMMN ?**

Organizations are constantly seeking ways to improve how they work — aiming to boost efficiency and minimize errors. This involves analyzing and continuously refining their work methods. While some processes follow **highly structured workflows** (which are ideal for BPMN), others deal with **unpredictable, dynamic situations** that don’t follow a fixed sequence of steps.

**Case Management Model and Notation (CMMN)** is a **graphical notation** designed to model such **flexible, case-driven work**. It is particularly useful for scenarios where the path of execution depends on evolving conditions, events, or decisions made by human actors. CMMN introduces the concept of a **case file** and focuses on an **event-centric approach**, allowing for a broader representation of less structured processes — often handled by **knowledge workers**.

By combining **BPMN** for structured workflows and **CMMN** for unstructured or semi-structured cases, organizations can model and automate a much wider range of business scenarios.

if you are still think about why we need CMMN there is a short answer: _CMMN is ideal when the exact sequence of steps_ **_cannot be defined in advance_**_. Instead, users (often called knowledge workers) decide what to do next based on case context._

![](https://miro.medium.com/v2/resize:fit:680/0*pKZwmcclhYAUg1dT.png)
example of CMMN

### Use CMMN when :

1) **The process is unpredictable or varies per cases** : for example A customer complaint may require investigation, refunds, escalation , or legal action — depending on what’s discovered during the case.

2)**Tasks are triggered by events or decisions**: You can’t define a linear path. Steps depend on user input documents or external events.

3)**User need autonomy** : Knowledge workers need to pick which steps to take and when

4) **The process has optional , repeatable, or ad-hoc tasks**: Unlike BPMN,CMMN allows tasks that may or may not be executed depending on the situation.

5)**You are dealing with case files or case data**: You need to manage evolving information (documents, forms, evidence) tied to a single case.

**Real-World Examples:**

-   **Healthcare treatment plans** (doctors react based on test results)
-   **Legal case management**
-   **Customer support issue handling**
-   **Incident or crisis response**
-   **Insurance claim assessment**
---
# Use Camunda With Docker

Hello Everyone,

Today we gonna learn how to use camunda with docker, first of all we need to go to docker hub and choose camunda-bpm-platform :

[https://hub.docker.com/u/camunda](https://hub.docker.com/u/camunda) [https://hub.docker.com/r/camunda/camunda-bpm-platform](https://hub.docker.com/r/camunda/camunda-bpm-platform)

![](https://miro.medium.com/v2/resize:fit:875/1*qz2cXT9mT844DIKTkxDNiQ.png)

or using the official site of camunda: [https://docs.camunda.org/manual/latest/installation/docker/](https://docs.camunda.org/manual/latest/installation/docker/)

lets go to docker terminal: then run to pull the last version of camunda from docker hub: docker pull camunda/camunda-bpm-platform:run-latest now in images we can see the camunda image added:

![](https://miro.medium.com/v2/resize:fit:875/1*7NWOVxBVaKUW78v5X3E2Sg.png)

and let’s run it : docker run -d — name camunda -p 8080:8080 camunda/camunda-bpm-platform:run-latest

![](https://miro.medium.com/v2/resize:fit:875/1*1iAj_Je8J23H6r-b95WGIg.png)

and let check using “docker container ls” and as we can see the container is up with container id : b06076730aaa

now the tasklist ,admin, cockpit, rest api… will be up using this link:

[http://localhost:8080/camunda-welcome/index.html](http://localhost:8080/camunda-welcome/index.html)

the default username:password are => demo:demo

![](https://miro.medium.com/v2/resize:fit:875/1*xqsWRuezES3AexS8uqZtiA.png)

to check the runned instance use this curl:

curl — location ‘[http://localhost:8080/engine-rest/process-instance](http://localhost:8080/engine-rest/process-instance)'  
— header ‘Authorization: Basic ZGVtbzpkZW1v’

![](https://miro.medium.com/v2/resize:fit:875/1*sO6FOXlBf7vj_GKiArcuqQ.png)

to see the count:

![](https://miro.medium.com/v2/resize:fit:875/1*tE5uRcXqV4lAMa2lh4OhmA.png)

to see the process definition:

![](https://miro.medium.com/v2/resize:fit:875/1*N0WNTSFON7q9QizNsT7EIg.png)

now let’s access the camunda folder content: use : docker exec -it {{instanceCamundaContainer}} bash

![](https://miro.medium.com/v2/resize:fit:559/1*gUkhRfX0HQdcN8iD723Kjw.png)

![](https://miro.medium.com/v2/resize:fit:875/1*th7eT9UvO_ZBANwiv4VIyA.png)

we can see already the h2 database folder, now go to interncal/webapps in order to see the bpm platform jars:

![](https://miro.medium.com/v2/resize:fit:875/1*QnZNkaNbFjAr8nLTkPIiJw.png)

we can also go to the configuration folder: and cat the default.yml

![](https://miro.medium.com/v2/resize:fit:875/1*ofPtTW0CPIZlnaev-_DQVQ.png)

-For the sql folder we can check the different folder create , drop, upgrade and even liquibase exist in this version:

![](https://miro.medium.com/v2/resize:fit:773/1*vp88OFpXaGi4GNexZMsGKg.png)

to see the camunda container log use this commaand:

docker logs {{containerId}};

![](https://miro.medium.com/v2/resize:fit:875/1*cqjlyA7x0ixOJ8YU106kfg.png)

All is good now.

-In order to delete the container first we need to stop it. Now lets stop the container using :

docker stop {{containerId}}

![](https://miro.medium.com/v2/resize:fit:875/1*fFcYTgILGgepIDbouqMKRA.png)

-“docker ps” command we will see that there is no instance.

![](https://miro.medium.com/v2/resize:fit:659/1*Cjbwe3fUhywYJMJLRmLVRg.png)

-lets delete it using : docker rm {{containerId}}

![](https://miro.medium.com/v2/resize:fit:875/1*D8mrItk5taV6pWxT9YXa3Q.png)

-The image of Camunda still exist:

![](https://miro.medium.com/v2/resize:fit:875/1*i4JWSE6_vos5oeocfx9BIQ.png)

-delete it using this command : docker image rm {{imageId}}

![](https://miro.medium.com/v2/resize:fit:875/1*vZ0Esn4BlZ6iNnYHugLKEQ.png)

-as we can see there is no more camunda image here:

![](https://miro.medium.com/v2/resize:fit:875/1*rXTStXY5Nxz6kY1jxa2P6w.png)

---

### Camunda 8 & Zeebe — Meeting the new kids in town

> With the rollout of Camunda 8, the newest product of Camunda, there are many new concepts to get familiar with. In this post you’ll find a high-level explanation of some of the core concepts of Camunda 8, so that your organization can make an informed decision when choosing an automation stack.

If you are new to the automation world and want to put in practice, one of the first things you do is, choosing an automation tool. Making this decision is no easy task, there are many tools and concepts that need to be clarified and understood in order to choose the proper tool for your requirements. If you are:

-   working with automation and hyper-automation
-   looking for high-performance & scalability
-   in need of a cloud solution either SaaS or On-premise
-   working with Microservices

Camunda 8 and its engine Zeebe might have all you need. So lets clarify some concepts and prepare the field so you see how this tool can help you with the points above.

### **Automation & Orchestration**

Automation is a big topic for companies no matter the industry. A word related to automation is orchestration, many times both are used as synonyms. There are many definitions out there, I personally use the word orchestration as in: orchestration is enabled by automation, to be precise, **orchestration takes advantage of tasks that are automated in order to automatically execute business processes or workflows.**

### **Workflow Engine**

Automation requires an automation tool, which is normally called workflow engine, no more than a software application. A workflow engine manages business processes. It controls what activities should take place after the completion of other activities i.e. sequential flow of activities. This applies not only to activities but to conditions and messages that may occur inside or outside the process being managed, in a sentence, it controls the flow of information, activities and events. A workflow is then a sequence of tasks that accomplish one goal. **A workflow is a process, and with a workflow engine then business processes can be orchestrated.**

### **Microservices orchestration**

Well, the concept of microservice orchestration has to do with how microservices interact with each other. It is a design pattern where you have one microservice through which every other microservice communicates. Like a conductor in the opera. Every microservice communicates with this “conductor” microservice. E.g. If microservice “A” needs something from “B”, A asks the “conductor/orchestrator” service: Get me some info from “B”. **Orchestration uses a centralized approach to execute the decisions, this centralization makes the process clear and has better control.**

### **Where do the concepts meet?**

If you have the following goals in mind:

-   A centralized controller for processes with mostly activities in a sequential fashion
-   Having the ability to see the process end-to-end flow in both, design and run time
-   Using a standard way to describe those processes i.e. using a notation to model how microservices are orchestrated

These goals are totally in sync with what a workflow does, therefore a workflow engine is your best candidate, and now lets say, you have identified the type of tool you need, and you want some (or all) of the following characteristics:

-   Enabling your organization to do more by providing a cloud tool with collaboration features
-   Almost unlimited software scalability
-   A tool offering a variety of ways to integrate existing systems
-   A tool that can be used for business people, technical people and everyone else in between
-   A trusted company that can offer you support

The tool that can deliver all of that is Camunda 8. It is a **cloud based solution that orchestrates business processes that span people, systems, and devices. It uses the notation BPMN to help business users collaborate with developers to model and automate end-to-end processes**. Camunda 8 was designed as a powerful workflow with the following features in mind:

-   Horizontal scalability
-   Fault tolerance
-   Message-driven architecture
-   Publish-subscribe interaction model
-   Visual workflows modeled in BPMN 2.0

In order to imagine and visualize the dimension of an application of this kind, let’s say that, Microservice orchestration through a workflow is done already by big players in different industries, examples are: Netflix and its conductor tool, LinkedIn, and so on. Camunda 8 has at its core Zeebe, which is one of the main components of the solution.

### **What exactly does Zeebe solve?**

A common concept in a microservices architecture is that each microservice should be responsible for only one business capability. We can see this as, workers that are allowed to do one and only one thing, once they are done, they wait until they are told to do the same thing again. We can infer that each worker contributes with one step to a broader process.

The following question comes up: who can see where we are at in the broader process? In this case none of the workers. Because of it, the type of architecture described in the example lacks visibility of the process sequence. What is more, if a single worker has a problem, there is no way the other workers know about it, and the process as a whole might be compromised.

This architectural design has very good workers but a troublesome process overview. Now let’s rephrase it: **Microservices architectures produce very good software at the microservice level, but they lack visibility at a process level, impacting the business outcome. This is clearly a problem and that’s what Zeebe solves**.

### **How does Zeebe solve the problem?**

To understand how Zeebe tackles the problem, we have to see some of its characteristics.

-   Designed as a distributed system with no central component
-   Using BPMN to explicitly define sequences that span multiple microservices
-   Having event sourcing instead of a central database.
-   Having event streaming for communication between microservices

Let’s see the last two points in detail; normally a workflow stores process states inside a database, with event sourcing process states are seen as “events“. Events are saved inside an append-only log, instead of a database. This log is called a topic, the state of the workflow can be derived or sourced from the logs of a topic.

A traditional workflow has an engine model, Zeebe follows a client/server model. The server is a broker that saves topics and distributes work items to the clients. The clients are embedded in the actual microservices in order to connect with the broker. The communication happens through a stream. This is event streaming. Through event streaming the broker orchestrates the rest of the microservices.

This concept should be a familiar topic for people with experience on Apache Kafka or Apache Pulsar for example. Indeed Zeebe can be integrated into existing microservices solutions already using those tools or similar ones. It can subscribe to existing streaming or messaging platforms, then it can correlate the events/messages to predefined sequences modeled with BPMN 2.0 and deployed to the broker(s). We can see in this example that Zeebe can somehow act as a descriptive workflow, meaning, it describes the steps that happened instead of dictating the steps to happen, and that is a highlight of the platform.

### **In what aspects is Zeebe/Camunda 8 similar or different to Camunda 7?**

For the ones familiar with the previous version of Camunda, i.e. Camunda7, and after explaining fundamental concepts we know a great deal of Zeebe, we can now stop here for a moment and compare the two solutions:

![](https://miro.medium.com/v2/resize:fit:875/1*WAJpQO0UVVRocBjcef41hg.png)

As we see the two products have noticeable differences, which may be few but they set the two products clearly apart. One can of course find uses cases where the two pretty much solve a specific problem but that depends on opinions, circumstances and decisions. We can say that choosing Camunda 8 and the innovative Zeebe requires serious consideration; Zeebe features and the fact that microservices are a very popular way of developing software, makes us think that this tool might have as well all you need. Lets now talk about pricing, because Camunda 8 is not for free.

### Is there a plan to production with Camunda 8 for free?

Camunda 7 and Camunda 8 represent significant shifts, not just technologically. They also differ in their commercialization strategies.

Camunda 8 offers a Software as a Service (SaaS) solution. With this approach, you gain access to the platform without the hassle of installation, deployment, or managing infrastructure. This cloud-based model allows your team to focus more on developing the desired logic, rather than dealing with operational tasks. Things you are are used to if you have ever worked with any other SaaS solution.

On the other hand, the product Camunda 7 is an open-source workflow platform packaged as a Java library. By default, it’s not cloud-based and is typically deployed on-premise. However, organizations can opt to deploy it on cloud infrastructure if they choose to do so, by setting up their own cloud environments.

One of the significant distinctions between Camunda 7 and 8 lies in their components. While Camunda 7 is entirely open-source, Camunda 8 comprises both closed and proprietary components alongside open-source ones.

You might be wondering: Is there an open-source version of Camunda 8? The answer is no. So, how can you leverage Camunda 8 to create and implement solutions without acquiring a license? Is it possible to utilize its open components to build robust solutions?

Exploring this further, this official Camunda [blog](https://camunda.com/blog/2022/05/how-open-is-camunda-platform-8/) helps identify the open components of Camunda 8. While there isn’t an entirely open-source version, understanding which components are accessible can guide us in developing industry-grade solutions using Camunda 8. In our subsequent discussion, we’ll delve into this topic, highlighting explicit points to help make informed decisions.

Our starting point is reviewing the open parts of Camunda 8:

![](https://miro.medium.com/v2/resize:fit:875/0*VaTA3xCzOP3dcMmm.png)
Image taken from this blog https://camunda.com/blog/2022/05/how-open-is-camunda-platform-8/

**Green and green with stripes:** Open source license and Source-available license, basically you can work with these 2.

**Red:** This software is only available within Camunda Platform 8 — SaaS and **can’t be run self-managed**.

**Blue:** This software is available but only free for non-production use, If you want to put these components into production, you will need to buy a license from Camunda.

Why do the blue parts are the most important to understand? Because they are the bridge between Zeebe, Camunda 8 core, and any other application on top for visualization, control, monitoring. In the image, the obvious part is they are applications, but something no that obvious is that there is an API behind each application, so what we have is:

-   Tasklist App & Tasklist API (GraphQL)
-   Operate App & Operate API (REST)
-   Optimize App & Optimize API (REST)

**Without API no communication with Zeebe is possible.** The API is important as you need query capabilities**, Camunda 8 does not provide query capabilities directly on the event log.** The events are projected to a more suitable component where the focus is to make queries.

With that information in mind, we now can devise a MVP:

![](https://miro.medium.com/v2/resize:fit:776/1*-RiPml_KsVmT42OdSLwMag.png)

-   Tasklist Application: App for starting processes and completing user tasks. A replacement for Tasklist
-   Engine Room Application: App for monitoring and controlling processes. A replacement for Operate
-   API Persistence layer: to get data from historical and running processes. A replacement for the APIs (Tasklist & Operate) querying information

Tasklist and Engine Room in our MVP can be developed as Single-Page applications for which a number of frameworks are available, so assuming this is something very common, there should be no major complications as other than defining what each of these two applications should do. The complicated part is, they depend on an API, so the main focus for the MVP is to define an evaluate the feasibility of developing our own API. This is a key point in answering our main question.

Developing an API, requires 2 thing:

-   Understand how the internals of Zeebe work, and
-   Evaluating if the cost to develop a custom API can be more expensive than paying for Camunda SaaS.

In regard to the the internals of Zeebe and the data, the main point of contention is that the Elastic structure (Index) and the event log structure can change over time, therefore any custom API developed on top has to be adjusted accordingly, and that ties you to always be in maintenance mode.

The other consideration is, do you have a team with the capabilities, time and will to develop an API from scratch. So back to the main question of this last section: **Is there a plan to production with Camunda 8 for free? Yes** definitely, you have to consider everything discussed in the article, and if you choose to take that path, this is no minimal effort but **a fairly large software project**.

---

# Camunda process orchestration with external Java tasks.

In this article, we will learn how to use the Camunda platform and achieve end-to-end automation using external Java tasks.

How about we start with what Camunda is? Camunda is software designed for process orchestration and aims to achieve end-to-end automation. It allows us to visualize and create business process flows called BPMN diagrams.

Camunda can be used in a few different ways, but one of the most popular ways is by using external tasks. The benefit of using external tasks is that the workers that do the work are separated from the Camunda engine and make use of Camunda’s REST API to fetch instances to process. This results in a true decoupled microservice architecture.

A few of the benefits of using external tasks include but is not limited to independent maintenance, independent scaling, being able to use different programming language per individual task, etc.

Next, we will get some hands-on experience by making a simple application called ‘let’s fly’.

Here are my Git repositories for the Camunda Engine and the let’s fly Spring Boot application. Please follow along and refer to it when you are stuck :



https://github.com/hannovdw/Camunda-Engine


### GitHub - hannovdw/Lets-Fly: Lets fly external task Spring Boot application for Camunda
https://github.com/hannovdw/Lets-Fly

You can start by cloning the Camunda-Engine Git repository and have a look at the lets_go_fly.bpmn file under the resources folder. We can open and edit BPMN files using Camunda Modeler, which you can download [here](https://camunda.com/download/modeler/).

![](https://miro.medium.com/v2/resize:fit:875/1*-alJePIrA2RKoUyZbehcoA.png)

On a high level overview, the application is for deciding whether you will be going on a flight or not. We will decide if we go for a flight or not by checking if the weather is good enough to go flying and if the aircraft passes the preflight inspection and is safe to fly. We first try to check the weather via an API service and set the isGoodWeather Camunda variable according to the weather. If the weather is good we proceed to do the preflight inspection. If the weather is bad, we cancel our flight and end the process. Then we do the preflight inspection which is also an external task and set the isPassedPFI variable to true or false depending on whether it passed or not. If it passed, we take off, if it failed, we cancel the flight. The weather API can be down from time to time, so if an error is thrown, we can manually approve the weather.

### Setup

In the Lets-Fly Spring Boot project, under the camundaworkers folder, we will find the CheckWeather Java class, which is used for the checkWeather external task. The class uses the service called WeatherService, which generates a random integer and sets the Camunda variables based on the value :
```java
@Component  
@ExternalTaskSubscription("checkWeather") // create a subscription for this topic name  
public class CheckWeather implements ExternalTaskHandler {  
  
    private final WeatherService weatherService;  
  
    @Autowired  
    public CheckWeather( WeatherService weatherService) {  
        this.weatherService = weatherService;  
    }  
  
    @Override  
    public void execute(ExternalTask externalTask, ExternalTaskService externalTaskService) {  
  
        Weather weather = weatherService.getWeather();  
        boolean isGoodWeather;  
        isGoodWeather = ((weather.getWindSpeed() > 10) ? false : true);  
        VariableMap variables = Variables.createVariables();  
        variables.put("isGoodWeather", isGoodWeather);  
        if(weather.getWindSpeed() > 14){  
            externalTaskService.handleBpmnError(externalTask , "Simulated_Error");  
        }  
        externalTaskService.complete(externalTask,variables);  
    }  
}
```
To enable the external task to poll the Camunda engine for process instances, there are a few things we have to do :

1.) When clicking on the task block, make sure to choose External under the Implementation dropdown, and choose a topic (in our case checkWeather). Make sure to change the task to a service task by clicking on the wrench icon.

![](https://miro.medium.com/v2/resize:fit:805/1*vjlk1UVhacEGcPPo6p474A.png)

2.) Next, we add the topic we chose in the Camunda modeler to the Java external task class in the @ExternalTaskSubscription as shown in the above CheckWeather Java class.

3.) Update the application.yml file to configure the external workers like in the following code. You have to configure Camunda variable names (that the external task will fetch) isGoodWeather and isPassedPFI, your process definition key (lets_go_fly), and the topic names of the external workers (checkWeather and isPassedPFI).

```yaml
camunda.bpm.client:  
  base-url: http://localhost:8080/engine-rest ### the URL pointing to the Camunda Platform Runtime REST API  
  lock-duration: 10000 ### defines how many milliseconds the External Tasks are locked until they can be fetched again  
  subscriptions:  
    checkWeather: ### topic name of the External Service Task  
      variable-names: [isGoodWeather] ### our business logic doesn't require any variables, so don't fetch them  
      process-definition-key: lets_go_fly ### only filter for External Tasks with this process definition key  
    preFlightInspection: ### topic name of the External Service Task  
      variable-names: [isGoodWeather, isPassedPFI] ### our business logic doesn't require any variables, so don't fetch them  
      process-definition-key: lets_go_fly ### only filter for External Tasks with this process definition key  
  
logging.level.org.camunda.bpm.client: DEBUG ### increase the log level of the application  
  
server.port: 8181
```

### Error Handling

Next, we will look at how to handle any errors that occur in the checkWeather external worker. To do this, we need to add an error boundary event to our BPMN diagram :

![](https://miro.medium.com/v2/resize:fit:875/1*rqw5UTWFhtFcVOuZMszqOA.png)

This allows us to catch any BPMN errors thrown from within our external tasks. We used the following code to throw a BPMN error from within our external Java task:

externalTaskService.handleBpmnError(externalTask , "Simulated_Error");

The thrown BPMN error then gets caught by the boundary error event and passes it to the user task where we can manually approve the weather.

Next, we have the preflight inspection external task. It works similar to the CheckWeather worker. Note we also create a subscription using the ExternalTaskSubscription decorator which should align with the application.yml file and the topic name in the BPMN file.
```java
@Component  
@ExternalTaskSubscription("preFlightInspection") // create a subscription for this topic name  
public class PreFlightInspection implements ExternalTaskHandler {  
  
    @Override  
    public void execute(ExternalTask externalTask, ExternalTaskService externalTaskService) {  
  
        boolean isPassedPreFlightInspection;  
        Random randomNum = new Random();  
        int randomNumber = randomNum.nextInt(20);  
  
        isPassedPreFlightInspection = ((randomNumber > 10) ? false : true);  

        VariableMap variables = Variables.createVariables();  
        variables.put("isPassedPFI", isPassedPreFlightInspection);  
  
        externalTaskService.complete(externalTask,variables);    
    }  
}
```
### Starting a process

Now that we have a high-level and technical understanding of the application, let’s start a process. To do this we will use Postman to make an HTTP POST request to the Camunda engine like the following :

![](https://miro.medium.com/v2/resize:fit:875/1*8CTKLkHf-vC6g4agAusjVw.png)
```shell
URL: localhost:8080/engine-rest/process-definition/key/lets_go_fly/submit-form 
(make sure to use the port where your Camunda engine is running on)

{  
  "variables": {  
      "isGoodWeather" : {"value":false}  
  },  
   "businessKey" : "TestFlight_2"  
}
```

After sending the request, go to Camunda cockpit on [http://localhost:18080/](http://localhost:18080/). Go into the Let’s Go Fly process definition and you will see your process token on the checkWeather task like below.

![](https://miro.medium.com/v2/resize:fit:751/1*UWJCCJcV73t9S1tuDmqXZg.png)

Let’s start a few processes using postman and investigate the different paths it can take.

![](https://miro.medium.com/v2/resize:fit:875/1*o_-56yjhRf6vvhV0VOdu-A.png)

As you can see, the processes can follow multiple paths based on the variables, let’s look at a few scenarios:

1.  ) the isWeatherGood and isPassedPFI Camunda variables are true and we will take off :

![](https://miro.medium.com/v2/resize:fit:875/1*LCPjs8sJUyuks12twi5BCg.png)

2.) The isGoodWeather Camunda variable is false, and we cancel the flight :

![](https://miro.medium.com/v2/resize:fit:875/1*bfqhCOJU-rypclz3wDhqig.png)

3.) Something went wrong while checking the weather and we have to approve manually :

![](https://miro.medium.com/v2/resize:fit:670/1*ZAYmwHBwoBjL-4Ua3cKffA.png)

We can claim the user task and set the isGoodWeather variable manually :

![](https://miro.medium.com/v2/resize:fit:875/1*672s4nS80lS_H66abPR9QA.png)

As we can see Camunda is a very powerful tool and the implementations are endless. If you would like to learn more I recommend you go check out the official [Camunda](https://camunda.com/) courses and documentation.

---
# Camunda Api rest wrapper. Today we gonna use the api rest

so instead of passing by the defaut api rest endpoints offered by Camunda (localhost8080/engine-rest/process-definition/key/{processdefinitionkey}/start)

we gonna use a class wrapper that will contain code that will call the process engine and create a bpm process instance and this class will be called by an api rest.

Our process :

![](https://miro.medium.com/v2/resize:fit:875/1*V9p3oa71crG47o1UyKFwLQ.png)

the api endpoint is : localhost:8080/student

Here the class :

![](https://miro.medium.com/v2/resize:fit:875/1*y9ZT0m8LmfaGtdAVnrBR5g.png)

![](https://miro.medium.com/v2/resize:fit:875/1*ueuNys9sKzGuJxbh5tbFiw.png)

we gonna create a process instance and set the variable related to the student.(when calling the api , we gonna add in the body the different variables content)

here we go : let s run the api:

![](https://miro.medium.com/v2/resize:fit:875/1*y9Mg2WT1w9eO1P8cVCHRuQ.png)

a new instance is created : and the variable is added to the process

![](https://miro.medium.com/v2/resize:fit:875/1*LLAYNbSwV_Wvkg_vnB3HGw.png)

Every time we call the api, another instance will be created:

![](https://miro.medium.com/v2/resize:fit:875/1*Ut7k3H_L_iC9JLVZciy_9w.png)

github repo: [https://github.com/ghailen/camunda-rest-api-wrapper](https://github.com/ghailen/camunda-rest-api-wrapper)

Thank you for reading my article, please contact me for any further information.

Other Camunda topics:

[camunda task events notifier](/@ghailenemark/camunda-task-events-notifier-3f3c3c825556)  
[camunda genericuser task](/@ghailenemark/camunda-generic-user-task-c2071c56e755)  
[listener in camunda](/@ghailenemark/listener-in-camunda-e44c89930d8)  
[task marker multi-instance](/@ghailenemark/task-marker-multi-instance-869872bde60)  
[taskmarker loop in camunda](/@ghailenemark/task-marker-loop-in-camunda-e6bbca5e05f4)  
[feel language camunda](/@ghailenemark/feel-language-camunda-61532b9e7402)  
[how to work with dmn](/@ghailenemark/how-to-work-with-dmn-d73d535f7f66)  
[how-to-use-embedded-task-form-in-camunda](/@ghailenemark/how-to-use-embedded-task-form-in-camunda-1f672ec47499)  
[all-about-camunda-database](/@ghailenemark/all-about-camunda-database-82604b561d84)  
[error-handling-in-camunda](/@ghailenemark/error-handling-in-camunda-412cbf41fac8)  
s[ub-process-in-camunda](/@ghailenemark/sub-process-in-camunda-ffc9c78bf5f3)  
[gateways-in-camunda](/@ghailenemark/gateways-in-camunda-d5cf9eeb3db5)  
[camunda-with-spring-boot-example](/@ghailenemark/camunda-with-spring-boot-example-e8277f17d7bf)  
[task-in-camunda](/@ghailenemark/task-in-camunda-44a617fc21cc)  
[events-in-camunda](/@ghailenemark/events-in-camunda-eb9050f5213e)

[working-with-http-connectors-in-camunda](/@ghailenemark/working-with-http-connectors-in-camunda-724b9e10bb79)

---
# Business Process Automation with Spring Boot and Camunda

### **Introduction**

### What is BPMN and why it matters

![](https://miro.medium.com/v2/resize:fit:875/1*0vMnfRHSUf_YabDPInEbwQ.jpeg)
BPMN schema example

When we build business applications, we often deal with processes — things like user registration, invoice approvals, order fulfillment, or support ticket resolution. These processes typically involve multiple steps, decision points, and interactions between systems or people. But how do we model and automate these workflows in a way that both developers and business stakeholders can understand?

That’s where BPMN (Business Process Model and Notation) comes in.

_BPMN is a graphical language for representing business processes. It gives us a standardized way to visualize how a process flows — from the first trigger to the final outcome._ Instead of describing processes in plain text or code, we can draw diagrams that include tasks, gateways (decisions), events, and flows. These diagrams are not just for documentation — they’re executable.

**With BPMN, we can:**

-   Collaborate better with non-technical stakeholders by speaking a shared visual language.
-   Clearly define complex logic without burying it in code.
-   Automate workflows with BPMN engines, which can execute BPMN diagrams directly.

### What is Camunda?

When we aim to automate business processes, we need a platform that can model, execute, and monitor workflows efficiently. Camunda serves this purpose as a robust, open-source process automation platform that supports BPMN for workflow automation, DMN for decision automation, and CMMN for case management.

Founded in 2008 in Berlin, Germany, by Jakob Freund and Bernd Ruecker, Camunda has evolved from a BPM consulting company into a leading provider of process orchestration software. The platform is designed to help organizations automate complex business processes, ensuring scalability, transparency, and efficiency.

**Camunda offers two main versions:**

-   **Camund**a 7: A Java-based, monolithic architecture suitable for on-premises deployments. It integrates seamlessly with Java applications and provides tools like Cockpit for monitoring and Tasklist for managing user tasks (Use when we want embedded, on-premise engine with open-source licensing)
-   **Camunda 8:** Introduced in 2022, this version is cloud-native, leveraging the Zeebe workflow engine for distributed processing. It offers enhanced scalability and resilience, making it ideal for modern, cloud-based infrastructures (Use when we need cloud-based or microservices-oriented solution with higher throughput and scalability).

**Key functionalities of Camunda include:**

-   **Process Modeling:** Design BPMN diagrams using the Camunda Modeler, facilitating collaboration between technical and business teams.
-   **Workflow Execution:** Automate processes with the Camunda engine, handling tasks, events, and gateways as defined in BPMN models.
-   **Decision Automation:** Utilize DMN to model and execute business rules, allowing for dynamic decision-making within processes.
-   **Monitoring and Optimization:** Tools like Operate and Optimize provide insights into process performance, enabling continuous improvement.

By integrating Camunda into our applications, we can achieve efficient and transparent process automation, bridging the gap between business requirements and technical implementation.

Official website of Camunda: [https://camunda.com/](https://camunda.com/)

### Our Scenario: Automating User Registration for a Trading Platform

Let’s implement a business process using Camunda and Spring Boot. Imagine we’re building a user registration pipeline for a trading platform. We want the onboarding to be seamless but compliant with regulatory requirements.

Here’s what the process looks like:

1.  **Gather user information** — We collect personal details from the user: name, country, email, and identification documents.
2.  **Check if the user is from a “white-listed” country** — This is an automated step where we verify if the user’s country is allowed to register based on our internal policies or legal regulations.
3.  **Manual verification** — If the user passes the country check, we send the collected information for manual review by our compliance team to verify document authenticity and validate the registration.

This is a classic use case where a BPMN-powered workflow shines. We can model the decision points, assign human tasks, and monitor the entire flow — all with built-in Camunda features.

Next, let’s dive into the dependencies and configuration needed to start building this process.

### **Setting Up**

![](https://miro.medium.com/v2/resize:fit:875/1*6-TIanrATNgonvWV4oiCFw.png)
Bootstrap picture of the empty Camunda Spring Boot Project

### Maven Dependencies

To get started with Camunda 7 in a Spring Boot project, we need to add a few essential dependencies to our `pom.xml`. These will enable us to:

-   Use the Camunda BPM engine
-   Integrate it with Spring Boot
-   Deploy BPMN process definitions
-   Create service tasks using Java delegates

Here’s a list of dependencies:
```xml
<dependencies>  
    <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-web</artifactId>  
    </dependency>  
  
    <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-jdbc</artifactId>  
    </dependency>  
  
    <dependency>  
        <groupId>org.camunda.bpm.springboot</groupId>  
        <artifactId>camunda-bpm-spring-boot-starter</artifactId>  
        <version>${camunda.version}</version>  
    </dependency>  
  
    <dependency>  
        <groupId>org.camunda.spin</groupId>  
        <artifactId>camunda-spin-dataformat-json-jackson</artifactId>  
        <version>${camunda.version}</version>  
    </dependency>  
  
    <dependency>  
       <groupId>org.camunda.bpm.model</groupId>  
       <artifactId>camunda-bpmn-model</artifactId>  
       <version>${camunda.version}</version>  
    </dependency>  
  
    <dependency>  
        <groupId>org.camunda.bpm.springboot</groupId>  
        <artifactId>camunda-bpm-spring-boot-starter-webapp</artifactId>  
        <version>${camunda.version}</version>  
    </dependency>  
  
    <dependency>  
        <groupId>com.h2database</groupId>  
        <artifactId>h2</artifactId>  
        <version>${h2.version}</version>  
    </dependency>  
</dependencies>
```
### Configuration

Now that we have all the necessary dependencies in place, let’s configure Camunda in our Spring Boot project: using **application.yml**:
```yml
spring:  
  datasource:  
    url: jdbc:h2:mem:testdb  
    username: sa  
    password:  
    driver-class-name: org.h2.Driver  
  
camunda:  
  bpm:  
    admin-user:  
      id: demo  
      password: demo  
      first-name: Demo  
    authorization:  
      enabled: true  
    filter:  
      create: All tasks  
    default-serialization-format: application/json
```

**datasource properties:** Camunda uses this to persist data like process instances and user tasks.

**admin-user:** Defines the default admin user that will be created on startup. Lets you log into Camunda **Cockpit** and **Tasklist**.

> **Cockpit** is Camunda’s web-based operations tool that lets us monitor, inspect, and troubleshoot running and completed process instances in real time.
> 
> **Tasklist** is Camunda’s web application that allows users to view and complete their assigned human tasks within a business process.

### **Designing and Implementing the Business Process**

### Creating the BPMN process diagram

![](https://miro.medium.com/v2/resize:fit:875/1*0oAjLpsweOrlezj2yAWEeQ.png)

To define our business process — user registration for a trading platform — we’ll use **Camunda Modeler**, a free desktop application provided by Camunda. It allows us to visually design BPMN diagrams and export them for use in our Spring Boot application.

**Download Camunda Modeler**

Let’s start by downloading the modeler. You can get the latest version from the official website: [https://camunda.com/download/modeler/](https://camunda.com/download/modeler/)

Camunda Modeler is available for **Windows**, **macOS**, and **Linux**. Once installed, you can immediately start modeling your processes with a simple drag-and-drop interface.

**Make Sure to Select Camunda Platform 7**

When creating a new BPMN diagram, **make sure to select “Camunda Platform 7”** as the execution platform. This ensures compatibility with our Spring Boot backend using Camunda 7 runtime. You’ll find this option in the diagram’s properties panel under the “Execution Platform” dropdown.

> Alternatively we can use IDE BPMN plugins or even create the BPMN XML file manually =)

**Model the Registration Process**

We’re designing a process that looks like this:

1.  Start event.
2.  Service task to gather user information (_com.demos.camunda_demo.delegates.GatherUserInfoDelegate_)
3.  Service task to check if the country is present in the white list (_com.demos.camunda_demo.delegates.CheckCountryInWhiteListDelegate_)
4.  Exclusive gateway
5.  User task with manual verification (_Generated Task Form with Boolean field_)
6.  Service task to save registration results (_com.demos.camunda_demo.delegates.SaveRegistrationResultDelegate_)
7.  End event.
8.  Set 1d TTL for the process

> _Save the file with a_ `_.bpmn_` _extension (e.g.,_ `_user-registration.bpmn_`_) and place it under_ `_src/main/resources/processes_` _so Camunda automatically deploys it._

### Writing Java delegate classes implementation

Now that we’ve modeled our BPMN process and configured the user task, it’s time to implement the business logic behind the service tasks. In Camunda 7, we do this by creating **Java Delegate** classes that Camunda will invoke during process execution.

**What’s a Java Delegate?**

A **Java Delegate** is a class that implements Camunda’s `JavaDelegate` interface. It contains a single method:

void execute(DelegateExecution execution) throws Exception;

Camunda calls this method when it reaches the corresponding service task in your BPMN diagram.

For the **user registration** process, we’ll implement the following delegate classes: `GatherUserInfoDelegate`:
```java
@Component("gatherUserInfoDelegate")  
public class GatherUserInfoDelegate implements JavaDelegate {  
    private static final Logger log = LoggerFactory.getLogger(GatherUserInfoDelegate.class);  
  
    @Override  
    public void execute(DelegateExecution execution) {  
  
        String userName = (String) execution.getVariable("username");  
        String userCountry = (String) execution.getVariable("userCountry");  
  
        execution.setVariable("user.name", userName);  
        execution.setVariable("user.country", userCountry);  
        //additional user info fathering logic  
        log.info("User info gathered: username=" + userName + ", country=" + userCountry);  
    }  
}
```

This delegate simulates the collection of user data. In a real system, this logic could collect user input from a frontend, or read from an API or database. Next, let’s implement `CheckCountryInWhiteListDelegate`:
```java
@Component("checkWhiteListDelegate")  
public class CheckCountryInWhiteListDelegate implements JavaDelegate {  
    private static final Logger log = LoggerFactory.getLogger(GatherUserInfoDelegate.class);  
    private static final List<String> whiteListedCountries = List.of("Country1", "Country2");  
    @Override  
    public void execute(DelegateExecution execution) {  
        String country = (String) execution.getVariable("user.country");  
        boolean isWhiteListed = whiteListedCountries.contains(country);  
        execution.setVariable("isWhiteListed", isWhiteListed);  
        log.info("Country " + country + " is white-listed: " + isWhiteListed);  
    }  
}
```

Here we validate if the user is from a white-listed country. For the demonstration purposes the list will be hardcoded in the delegate class. Finally, let’s add the `SaveRegistrationResultDelegate`:
```java
@Component("saveRegistrationResultDelegate")  
public class SaveRegistrationResultDelegate implements JavaDelegate {  
    private static final Logger log = LoggerFactory.getLogger(SaveRegistrationResultDelegate.class);  
  
    @Override  
    public void execute(DelegateExecution execution) {  
        Boolean verificationPassed = (Boolean) execution.getVariable("verificationPassed");  
        String userName = (String) execution.getVariable("user.name");  
  
        log.info("User <" + userName + "> registration result: " + BooleanUtils.isTrue(verificationPassed));  
    }  
}
```

Here we just logging the registration result. Now, let’s implement the HTTP endpoint to trigger our process:
```java
@RestController  
@RequestMapping("/api/registration")  
public class RegistrationController {  
  
    private final RuntimeService runtimeService;  
  
    @Autowired  
    public RegistrationController(RuntimeService runtimeService) {  
        this.runtimeService = runtimeService;  
    }  
  
    @PostMapping("/start")  
    public ResponseEntity<String> startRegistrationProcess(@RequestBody RegistrationRequest request) {  
        Map<String, Object> variables = new HashMap<>();  
        variables.put("username", request.getUsername());  
        variables.put("userCountry", request.getCountry());  
  
        ProcessInstance processInstance = runtimeService.startProcessInstanceByKey("userRegistrationProcess", variables);  
        return ResponseEntity.ok("Started process with ID: " + processInstance.getProcessInstanceId());  
    }  
}
```

Here we’re getting the user properties from the request body and calling our process (by id of the Camunda process) using them.

### **Monitoring and Tracking Processes**

Once we’ve deployed our BPMN model and implemented the necessary delegates and endpoints, it’s time to observe the process in action. Camunda offers powerful tools out of the box to help us monitor, track, and interact with running process instances.

### Starting the Processes

We start our user registration process by calling the custom REST endpoint we created:
```shell
curl --location '.../api/registration/start'   
--header 'Content-Type: application/json'   
--data '{  
    "username": "user1",  
    "country": "Country1"  
}'  
  
curl --location '.../api/registration/start'   
--header 'Content-Type: application/json'   
--data '{  
    "username": "user2",  
    "country": "Country2"  
}'  
  
curl --location '.../api/registration/start'   
--header 'Content-Type: application/json'   
--data '{  
    "username": "user3",  
    "country": "Country404"  
}'
```

Each request carries different parameters (e.g., user country and name) which will affect the path the process takes — for example, failing on verification for white-listed countries or triggering a manual review for others.

### Tracking Progress with Cockpit

To inspect and monitor running process instances, we use **Camunda Cockpit** at:

http://localhost:8080/camunda/app/cockpit

Inside the cockpit we can see all the running processes and the current status of each of them:

![](https://miro.medium.com/v2/resize:fit:875/1*wmNgaVzGbhHPXLZOWDUAhA.png)

### Manual Progressing with Tasklist

As we can see, all the processes are at the ‘Manual Verification’ step. We can go to the Camunda Tasklist to complete them. Let’s open:

http://localhost:8080/camunda/app/tasklist

On the main screen, we’ll see all the uncompleted tasks:

![](https://miro.medium.com/v2/resize:fit:814/1*b37Xso0dUCMAIwAXVC1ALA.png)

To finish a task, we need to select it, click the **“Claim”** link, optionally provide the verification result, and then press the **“Complete”** button:

![](https://miro.medium.com/v2/resize:fit:875/1*0g-FgjcO951FovTHyE6VLQ.png)

In the application logs, we can observe different outcomes: some users were white-listed automatically, while others received different verification results based on the manual task completion:

![](https://miro.medium.com/v2/resize:fit:875/1*x5a7U1T_nvjdlxCJf9xUJQ.png)

### **Summary**

In this article, we built a complete demo application to showcase how Camunda 7 can help automate business processes using BPMN. We implemented a **user registration flow** for a trading platform, which included both **automated service tasks** (like country validation) and **manual user tasks** (like manual verification).

We walked through:

-   Setting up **Camunda 7 with Spring Boot**
-   Designing the BPMN process using **Camunda Modeler**
-   Writing **Java delegate classes**
-   Starting the process via a **REST API**
-   Monitoring progress using Camunda’s **Cockpit** and completing the manual tasks using **Tasklist** web applications

We’ve seen how easy it is to model, execute, and track business processes with Camunda’s built-in tools, making it a powerful engine for our workflows.

📦 You can find the full source code of the project on GitHub:  

https://github.com/sIvanovKonstantyn/camunda-demo
---

# Spring Boot + Camunda BPMN Script Task Example

Camunda BPM (Business Process Management) is a lightweight, open-source platform for workflow and process automation. In previous [tutorial we implemented Spring Boot 3 + Camunda BPM Hello World Example](https://www.javainuse.com/boot/camunda/1). In the tutorial we had implemented a simple bpmn script task that output some text to the console. In this tutorial we will be looking at the script task in more detail. We will be creating script tasks of more practical scenario like an order and payment workflow.

![](https://miro.medium.com/v2/resize:fit:726/0*s7aZtenXEULHEBST.jpg)

Video

This tutorial is explained in the below Youtube Video.

A script task in Camunda is a type of task in a business process model that allows you to execute a piece of code or script directly within the process flow. It’s a way to add custom logic or perform specific operations without needing to create a separate Java class or service. Script tasks can be written in various scripting languages supported by Camunda, such as JavaScript, Groovy, or Python. They are useful for simple operations like data manipulation, calculations, or making decisions based on process variables. When the process reaches a script task, it executes the script and then moves on to the next task. You can use script tasks to:

-   Modify process variables
-   Perform calculations
-   Make decisions based on conditions
-   Interact with external systems
-   Log information

### Implementation

Download the source code we had implemented in [Spring Boot 3 + Camunda BPMN hello world example tutorial](https://www.javainuse.com/boot/camunda/1). So previous we had created a bpmn diagram as follows-

![](https://miro.medium.com/v2/resize:fit:875/0*244WYX3dLLJiJx1d.jpg)

Also the script task it made use of inline javascript. Here the script task it printed some text to the console.

![](https://miro.medium.com/v2/resize:fit:875/0*I2-1wQmDD0LhxN7h.jpg)

Next instead of inline script we will make use of external script. For this in resource folder create a new javascript file named test.js as follows -

print("Hello JavaInUse");

Then in the bpmn diagram select the script task -> In script type select External Resource -> Name the resource as test.js.

![](https://miro.medium.com/v2/resize:fit:875/0*orvawYoZ1IeHzlf-.jpg)

Start the spring boot application and then go to the url — [http://localhost:8080/executetask.](http://localhost:8080/executetask.) If we now run the program we get the output as follows.

![](https://miro.medium.com/v2/resize:fit:748/0*EJ9CPHL7d4OIjR9M.jpg)

![](https://miro.medium.com/v2/resize:fit:875/0*wMAuuvlERUmy3mVb.jpg)

### Global Variables

Global variables in a script task in Camunda refer to variables that are accessible throughout the entire process instance. These variables can be read and modified by different tasks within the process, including script tasks. Sometimes we may need to pass information between 2 script tasks. This is done using global variables. We will create a new bpmn diagram named second.bpmn having id as second-javainuse which will have 2 script tasks as follows-

![](https://miro.medium.com/v2/resize:fit:875/0*oRImLWRdtjScwzGT.jpg)

-   Calculate Order Total(Task 1) — The first task calculates the total amount of an order, applies a discount if applicable, and stores the result in a global variable called “orderTotal”.
-   Process Payment (Task 2) — The second task retrieves the “orderTotal” global variable, simulates a payment process, and sets another global variable “paymentStatus” based on the result.

**Order Task script -**

![](https://miro.medium.com/v2/resize:fit:875/0*9yh8AQNTR2wtt7IC.jpg)
```java
var System = Java.type('java.lang.System');  
  
var orderItems = [  
    { name: "Laptop", price: 1000 },  
    { name: "Mouse", price: 20 },  
    { name: "Keyboard", price: 50 }  
];  
  
var totalAmount = 0;  
for (var i = 0; i < orderItems.length; i++) {  
    totalAmount += orderItems[i].price;  
}  
  
if (totalAmount > 1000) {  
    totalAmount *= 0.9;  // 10% discount  
}  
  
execution.setVariable("orderTotal", totalAmount);  
  
System.out.println("Order total calculated: $" + totalAmount);
```
**Payment Task script-**

![](https://miro.medium.com/v2/resize:fit:875/0*m_rHQpSOh0_cG3yb.jpg)
```java
var System = Java.type('java.lang.System');  
  
var orderTotal = execution.getVariable("orderTotal");  
  
var paymentSuccessful = (Math.random() < 0.8);  // 80% chance of success  
  
if (paymentSuccessful) {  
    System.out.println("Payment of $" + orderTotal + " processed successfully.");  
    execution.setVariable("paymentStatus", "SUCCESS");  
} else {  
    System.out.println("Payment of $" + orderTotal + " failed. Please try again.");  
    execution.setVariable("paymentStatus", "FAILED");  
}
```
In the TestController specify the bpmn id as second-javainuse
```java
package com.example.workflow;  
  
import org.camunda.bpm.engine.ProcessEngine;  
import org.camunda.bpm.engine.ProcessEngines;  
import org.camunda.bpm.engine.runtime.ProcessInstantiationBuilder;  
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.RestController;  
  
@RestController  
public class TestController {  
  
	@GetMapping("/executetask")  
	public String execute() {  
  
		ProcessEngine engine = ProcessEngines.getDefaultProcessEngine();  
		ProcessInstantiationBuilder instance = engine.getRuntimeService().createProcessInstanceByKey("second-javainuse");  
		instance.executeWithVariablesInReturn();  
		return "Executed Camunda BPMN";  
	}  
}
```
Start the spring boot application and then go to the url — [http://localhost:8080/executetask.](http://localhost:8080/executetask.) If we now run the program we get the output as follows.

![](https://miro.medium.com/v2/resize:fit:875/0*Oiy9xGrkGxPI-2Az.jpg)
---
# Camunda 8 Tutorial: Building a Simple Workflow to Interact with REST APIs 

In this tutorial, I’ll guide you through creating a basic BPMN (Business Process Model and Notation) using Camunda 8. This BPMN model will interact with the popular JSON Placeholder API and demonstrate how to create a simple flow that processes data and handles different error conditions. We’ll also integrate it with a Spring Boot backend. Follow along as we dive into Camunda 8, Zeebe, and Spring Boot!

### BPMN Model Overview

The BPMN diagram we’re working on is designed to perform the following tasks:

1. Fetch data from an API using an HTTP connector.  
2. Print the results.  
3. Handle possible errors such as bad requests, pre-conditions not met, and service unavailability.

![](https://miro.medium.com/v2/resize:fit:875/1*x2E7jtAMt6lqlnIlHrnOIA.png)

The diagram above shows the workflow. It starts with a Rest outbound named “Get Data from JSON Placeholder,” which can branch into various error events if the data retrieval fails. Otherwise, it proceeds to “print results.”

### Prerequisites

- Camunda 8 Platform installed and running.  
- Java 17+  
- Spring Boot  
- Maven  
- An IDE of your choice (IntelliJ, Eclipse, VS Code, etc.)

### Setting Up Your Spring Boot Project

First, let’s set up the Spring Boot project to connect and interact with Camunda 8. Here’s a brief overview of the components you’ll need:

1. Controller Class: This class defines REST endpoints to start the workflow.  
2. Job Worker Class: This class processes the task steps in the workflow.  
3. Main Application Class: The entry point of our Spring Boot application.

Let’s go through each one by one.

### 1. Creating the Controller — Start.java
```java
package com.tutoria.camunda101.controller;  
  
  
import java.util.Map;  
  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RestController;  
  
import io.camunda.zeebe.client.ZeebeClient;  
import io.camunda.zeebe.client.api.response.ProcessInstanceEvent;  
import org.springframework.web.bind.annotation.RequestParam;  
  
  
  
@RestController  
@RequestMapping("/api/camunda/")  
public class Start {  
    @Autowired  
 private ZeebeClient client;  
    @GetMapping("start")  
    public String getMethodName()   
    {  
        Map<String,String> variables = Map.of("camunda","is fun");  
        @SuppressWarnings("unused")  
        final ProcessInstanceEvent processInstanceResults = client  
                .newCreateInstanceCommand()  
                .bpmnProcessId("camunda-8-tutorial")  
                .latestVersion()  
                .variables(variables)  
                .send()  
                .join();  
          
        return "camunda has started yey!!!";  
    }  
    @GetMapping("fun")  
    public String getfreeapi() {  
        return "done";  
    }  
}
```

In this **Start** class, we’re defining an endpoint (`/api/camunda/start`) that triggers the BPMN process using the Zeebe client. The workflow ID (bpmnProcessId) matches the one you deployed in Camunda.

### 2. Implementing Workers — RobinWood.java
```java
package com.tutoria.camunda101.Workers;  
  
import io.camunda.zeebe.client.api.response.ActivatedJob;  
import io.camunda.zeebe.spring.client.annotation.JobWorker;  
import lombok.extern.slf4j.Slf4j;  
  
import java.util.Map;  
  
import org.springframework.stereotype.Component;  
@Slf4j  
@Component  
public class RobinWood {  
  
    // This method extracts variables from zeebe  
    @JobWorker(type = "hello", autoComplete = true)  
    public void sendFinalNotifica(final ActivatedJob job) {  
        log.info("welcome");  
    }  
  
    @JobWorker(type = "printout", autoComplete = true)  
    public void sendFinalNotification(final ActivatedJob job) {  
        log.info("rest out bound finished");  
        Map<String, Object> variables = job.getVariablesAsMap();  
        log.info("========================");  
        log.info(variables.toString());  
          
    }   
}
```

In this worker class, we’ve implemented a job worker that will be triggered when the BPMN reaches the “print results” service task. This will log the output variables, and the job is automatically completed after processing.

### 3. Main Application — Camunda101Application.java
```java
package com.tutoria.camunda101;  
  
import org.springframework.boot.SpringApplication;  
import org.springframework.boot.autoconfigure.SpringBootApplication;  
  
import io.camunda.zeebe.spring.client.annotation.Deployment;  
  
@SpringBootApplication  
@Deployment(resources = "classpath*:/process/**/*.bpmn")  
public class Camunda101Application {  
    public static void main(String[] args) {  
    SpringApplication.run(Camunda101Application.class, args);  
    }  
}
```
This is the entry point of your Spring Boot application. The annotation `[@Deployment](http://twitter.com/Deployment)` ensures that the BPMN process is deployed to Zeebe when the application starts.

### Connectors

Make sure you download rest connector template on this link [connectors](https://github.com/camunda/connectors/tree/main/connectors/http/rest). The running project part has a github repo that shows where to place the files. But for rest element-template place it inside camunda-modeler/resource/element-template.

### BPMN Workflow Details

In Camunda Modeler, create a new BPMN diagram with the following components:

1. Start Event: Represents the beginning of the process.  
2. Service Task: This task is labeled “Get Data from JSON Placeholder” and is configured to fetch data using the HTTP connector. Configure it with the appropriate type and endpoint.  
3. Boundary Error Events: Attach boundary error events to handle situations like “Bad Request Error” or “Service Unavailable.”  
4. End Event: Represents the successful end of the workflow.

### Running the Project

File io is needed in this process and must be placed inside the folder of the main Java file. Additionally, a `.camunda` configuration file is required to run the REST outbound connectors.

- Step 1: Clone the project from [GitHub repository](https://github.com/Xlt3h/camunda101).  
- Step 2: Configure `application.properties` to point to your Camunda 8 Zeebe gateway.  
- Step 3: Start your Spring Boot application.  
- Step 4: Access the endpoint `/api/camunda/start` to initiate the workflow.

After triggering, you should see the workflow executing in the Camunda Operate interface. Logs will display the details of the variables fetched from JSON Placeholder.
---
# Creating a Workflow with Spring Boot and Camunda

In this article, we will develop a simple Spring Boot application in which we embed the Camunda Engine. By the end of this article, we will learn how to call Spring Boot services via Camunda and fill in their parameters.

Prerequisites:

-   IntelliJ IDEA
-   Maven
-   Java 8
-   Camunda Modeler

I’ve suggested IntelliJ IDEA since I will be using it throughout this article. Otherwise, you are free to use an IDE of your preference.

You can skip the step-by-step tutorial and directly import the code from the following link:

[Github](https://github.com/Bjornikof/camunda-spring-boot-demo)

Firstly, let’s create an empty Spring Boot project in Camunda Engine via [Camunda Automation Platform 7 Initializr](https://start.camunda.com/). After filling in the required fields, click on the “Generate Project” button.

![](https://miro.medium.com/v2/resize:fit:836/1*mqwykjcgzkv2c1dYvTPTkw.png)

Transfer the contents of the downloaded zip file to your desktop or any other file you see fit. Then, open the unzipped project in IntelliJ IDEA. Your project structure should be similar to this:

![](https://miro.medium.com/v2/resize:fit:565/1*TpHCdCsruhvdOCvV_Xt-Pg.png)

After checking your project structure, open the “pom.xml” file. Add “camunda-connect-core” and “camunda-engine-plugin-connect” requirements inside the “dependencies” tag, which has other camunda dependencies listed. We will use “Connector” to fill in the service parameters later in the article. With the help of these requirements, Camunda Engine will be able to successfully parse our bpmn file containing the “Connector”.
```xml
  <dependency>  
    <groupId>org.camunda.connect</groupId>  
    <artifactId>camunda-connect-core</artifactId>  
  </dependency>  

  <dependency>  
    <groupId>org.camunda.bpm</groupId>  
    <artifactId>camunda-engine-plugin-connect</artifactId>  
  </dependency>
```
Since we are using Java 8, we need to update the Spring Boot and Camunda versions imported in the “pom.xml”. If you want to use the latest versions of both, you need to use Java 17.
```xml
  <dependencyManagement>  
    <dependencies>  
      <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-dependencies</artifactId>  
        <version>2.6.4</version>  
        <type>pom</type>  
        <scope>import</scope>  
      </dependency>  
  
      <dependency>  
        <groupId>org.camunda.bpm</groupId>  
        <artifactId>camunda-bom</artifactId>  
        <version>7.15.0</version>  
        <scope>import</scope>  
        <type>pom</type>  
      </dependency>  
    </dependencies>  
  </dependencyManagement>
```
Once you have completed the requirements, check your “application.yaml” file. You can update your login credentials by altering “id” and “password” fields. Also, you can set a username which will appear in the interface by adding “first-name” and “last-name” variables.
```yaml
spring.datasource.url: jdbc:h2:file:./camunda-h2-database  
  
camunda.bpm.admin-user:  
  id: camundademo  
  password: camundademo  
  first-name: Camunda  
  last-name: Demo
```
Before we start coding, let’s briefly talk about the workflow diagram we have in mind. In the first step, we will request two inputs from the user, which are name and message. In the second step, we will pass these inputs to our service to create a message output. To create this workflow, we first need an object consisting of a name and a message.

To code our object, let’s open a class named “model” under “com.example.workflow”. Within the class, define two String type variables “name” and “message” respectively. Then, create Getter and Setter methods for the variables. Finally, define an empty Constructor and create a simple toString method to properly display our object.
```java
public class model {  
      
    private String message;  
    private String name;  
      
    public model() { }  
      
    public String getMessage() {  
        return message;  
    }  
      
    public void setMessage(String message) {  
        this.message = message;  
    }  
      
    public String getName() {  
        return name;  
    }  
      
    public void setName(String name) {  
        this.name = name;  
    }  
      
    @Override  
    public String toString() {  
        return "" + message + ", " + name;  
    }  
}
```
Before moving on to the workflow, let’s code the service which will be responsible for our message output. Open a class named “controller” under “com.example.workflow”. Specify the extension of the service and the data it will receive by adding Spring annotations. Then, create a new model named “m” and save the model data received by the service. Finally, add a logger in the class to make sure that the service is running and receiving the data sent from Camunda.
```java
@RequestMapping("/")  
@RestController  
public class controller {  
    java.util.logging.Logger logger =   
    java.util.logging.Logger.getLogger(this.getClass().getName());  
  
    @PostMapping("/message")  
    public model createMessage(@RequestBody model model) {  
        logger.info("-------Message Creator Initialized-------");  
  
        model m = new model();  
        m.setMessage(model.getMessage());  
        m.setName(model.getName());  
  
        logger.info("Message created --> " + m.toString());  
        return m;  
    }  
}
```
This concludes the Spring Boot side of our project. Now, we can start creating our workflow diagram. Open the “process.bpmn” which is under “resources” in our project in the [Camunda Modeler](https://camunda.com/download/modeler/) Application. Make sure you open the bpmn file located in your project. In the opened bpmn file, you will see a “User Task” shown with a human icon.

![](https://miro.medium.com/v2/resize:fit:460/1*GCdRzmcTQ_d1QU0etxvDYw.png)

User Tasks are the steps where user-related operations are carried out. As mentioned in the previous sections, in the first step of our workflow, we will request two inputs from the user: name and message. Instead of adding a new task, updating the existing “User Task” will do the trick.

Click on the “User Task” and then open the “Properties Panel”. Define an identity and a name suitable for our case in the opened panel.

![](https://miro.medium.com/v2/resize:fit:595/1*SHiceWEK1GrkZU-CSz5vYA.png)

After finishing the general information, move on to the “Forms” tab. This is the tab where, the form presented to the user is defined. Since we need name and message inputs from the user, let’s define two form fields named “name” and “message”. To define a form field, click on the plus icon next to the “Form Fields”. In the opened form, fill in the ID, type and label fields accordingly. Repeat the same steps for each form field.

![](https://miro.medium.com/v2/resize:fit:595/1*VJNUxKjMtfzDqo4gRaYG6Q.png)

This concludes the first step of our workflow. Let’s move on to the second step, where we call our service. To add a “Service Task”, click on the “Create Task” icon from the menu on the left and drop the task to a random location. After clicking on the task, click on the “Change Type” icon and select “Service Task” from the menu.

![](https://miro.medium.com/v2/resize:fit:393/1*IUuwLfHd7vx_flfyG9Jqhw.png)

For the general information, repeat the previous steps. Additionally, select the “Connector” option from the “Implementation” menu.

![](https://miro.medium.com/v2/resize:fit:751/1*AVfIYsiVyCNLBjNulJnSvQ.png)

After selecting an implementation, switch to the “Connector” tab. This is the tab where HTTP information and the data regarding the service is defined. Firstly, click on the plus icon next to the “Input Parameters” heading. Fill in the Name and Type fields as “headers” and “Map” respectively. From the “Add Entry” option that opens, add an entry with the key “Content-Type” and the value “application/json”. With these entries, we indicate that the data is in JSON format. Create and fill in the remaining input parameters like “payload”, “method” and “url” based on the screenshots given below:

![](https://miro.medium.com/v2/resize:fit:586/1*AYlS_LK-Dvl6WaSLk4X90g.png)

![](https://miro.medium.com/v2/resize:fit:589/1*7lndEawvpB3U8yEE0a7kDQ.png)

By using the “${}” format in the payload, the “message” and “name” inputs received in the previous step will be passed on to the service.

![](https://miro.medium.com/v2/resize:fit:591/1*8QzBaDJx-BCALjLcljUxsA.png)

Writing “POST” in the method indicates that the service makes a HTTP POST request.

![](https://miro.medium.com/v2/resize:fit:589/1*gGtRgaU24aZvFzqtZuelqg.png)

Finally, with the url parameter, we give the proper address to reach our service. Make sure that the port you enter the url matches the port your project is running on.

To connect the “Service Task” to the workflow, delete the existing arrow between the “User Task” and the “End Event”. Then, click on the “User Task” and select the arrow icons from the menu. Connect the arrow to the “Service Task”. Lastly, repeat the same steps for the “Service Task” and the “End Event”. Verify that your workflow looks similar to the one provided below and save your workflow diagram. You will see that the code inside the “process.bpmn” file will be updated on the IntelliJ IDEA.

![](https://miro.medium.com/v2/resize:fit:643/1*fREFr7o_FGTCkovLR7-uBQ.png)

With the completion of the workflow, we are ready to run the project in the debug mode. After you run the project and see a text similar to “Started Application in 8.096 seconds” in the console, go to the address [http://localhost:8080/](http://localhost:8080/) on your browser. When you access the page, you will see the Camunda login page. Enter the login credentials you provided in “application.yaml” to log in successfully.

![](https://miro.medium.com/v2/resize:fit:660/1*BXmTfnh0_6OXto6Li4xKVw.png)

Select “Tasklist” from the main page of applications and on the tasklist page click on the “Add a simple filter” option. After clicking, you will see that a filter named “All Tasks (0)” has been added to the list. Then, click on the “Start process” option to run the workflow we have prepared.

![](https://miro.medium.com/v2/resize:fit:875/1*3YqfW4-26640PmXAmJAHeA.png)

![](https://miro.medium.com/v2/resize:fit:875/1*2jIhiW6nMkAP77qz8hRO8Q.png)

Select the process named “camunda-spring-demo-process” and click on the “Start button” without providing any additional information. Finally, click on the “Get Input” task listed under “Created”. If you don’t see the task, refresh the page.

![](https://miro.medium.com/v2/resize:fit:875/1*vwO5-49Mt1ZhbWCzyNawJQ.png)

![](https://miro.medium.com/v2/resize:fit:724/1*odZkby4MAycIUXszXphG9w.png)

You will see the form we defined in the first step. To fill out the form, click on the “Claim” option at the top right corner. Then, fill out the form to your liking and click the “Complete” button.

![](https://miro.medium.com/v2/resize:fit:875/1*4hrA5yeSmcDX3AMVgrPRYw.png)

As the workflow executes the “Service Task” and the service runs, you’ll see that the list becomes empty again. If the workflow successfully executed the second step, we should be able to see the output in our console, which we printed with the help of a Logger. The output should include the inputs you, as the user, provided.

![](https://miro.medium.com/v2/resize:fit:875/1*9CmxaF57EN-6-s3oVNEnzw.png)
---

# Building Resilient and Scalable Systems with Spring Boot Camunda Kafka

Building Resilient and Scalable Systems with Spring Boot, Camunda , and Kafka

Hi All , This story is open to everyone; non-member readers can [click this link](/building-resilient-and-scalable-systems-with-spring-boot-camunda-and-kafka-baa16075beb8?sk=8138fa7b38957a13f5ff0e2a539fb3e7) to read the story.

Welcome , Building Resilient and Scalable Systems have been one of the most interesting areas of Application Development. There are several ways to achieve it .

Today, We will go through an Overview of Building Resilient and Scalable Systems with Spring Boot, Camunda , and Kafka and the benefits it brings to Application Developers.

Let’s Get Started …

### Introduction

In the rapidly evolving landscape of enterprise applications, the demand for architectures that not only stand up to rigorous standards but are also adaptable and responsive is paramount. This comprehensive blog post seeks to serve as a guide for hands-on architects and developers, immersing them in the intricacies of constructing a highly scalable and responsive event-driven Spring Boot application. By harnessing the capabilities of Camunda BPM for workflow orchestration and Kafka as the underlying message broker, we aim to delve into the depths of microservices architecture to meet the challenges posed by enterprise-grade demands.

### Overview

### Event-Driven Architecture

Event-driven architectures have emerged as a linchpin in modern software development. This section will not only explore the theoretical foundations but will also delve into the historical context of the evolution of event-driven architectures. It will highlight their role in promoting loose coupling, scalability, and resilience, and showcase how these architectures have evolved to meet the demands of contemporary applications.

![](https://miro.medium.com/v2/resize:fit:850/1*i9jZ6WPsCvg2gmGikBBifQ.png)

### Technologies in Focus

1.  Spring Boot: A Symphony of Microservices
2.  Take an extensive dive into Spring Boot, exploring its journey from a simple microservices framework to a symphony orchestrating complex distributed systems. Topics will include advanced reactive programming patterns, cloud-native development, and real-world applications of Spring Boot in mission-critical scenarios.
3.  Camunda BPM: Architecting Workflows with Simple Steps

![](https://miro.medium.com/v2/resize:fit:668/1*1BLDte5e2NGZKUdTRwCykA.png)

We will also explore Camunda BPM features and its use cases. It will shed light on how Camunda BPM can serve as a strategic tool in orchestrating complex business processes, managing human tasks, and adapting to dynamic business requirements.

4. Kafka : The Reliable Message Broker

![](https://miro.medium.com/v2/resize:fit:591/0*bQjFlUtEaZrKRP1R.png)

We will implement Event Driven solution with help of the conventional role of Kafka as a message broker . Topics will provide support for real-time data processing and Kafka’s role in event driven architectures.

### Use Case Discussion

### Order Fulfillment Reimagined: A Holistic View

This section will elevate the use case discussion by examining each microservice in the order fulfillment process in greater detail. It will explore how each microservice communicates asynchronously through events, the impact on the overall system’s responsiveness, and how the architecture adapts to variations in demand.

### Implementation: Coding Examples

### Version Information

-   Spring Boot Version: 2.6.3 (or the latest stable version)
-   Camunda BPM Version: 7.16.0 (or the latest stable version)
-   Kafka Version: 2.8.0 (or the latest stable version)

### IDE Used for Development

Any Integrated Development Environment (IDE) that supports Java and Spring Boot development can be used. Common choices include:

-   IntelliJ IDEA
-   Eclipse with Spring Tools Suite (STS) plugin
-   Visual Studio Code with appropriate extensions for Java and Spring Boot

Ensure that your chosen IDE is configured with the appropriate plugins and tools to facilitate development with Spring Boot, Camunda BPM, and Kafka.

### Maven Dependencies
```xml
<!-- Spring Boot Starter Dependencies -->  
<dependencies>  
    <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-web</artifactId>  
    </dependency>  
    <!-- Add other Spring Boot starters based on your requirements -->  
</dependencies>  
  
<!-- Camunda BPM Starter Dependencies -->  
<dependencies>  
    <dependency>  
        <groupId>org.camunda.bpm.springboot</groupId>  
        <artifactId>camunda-bpm-spring-boot-starter</artifactId>  
        <version>7.16.0</version> <!-- Replace with the latest Camunda BPM version -->  
    </dependency>  
    <!-- Add other Camunda BPM dependencies based on your workflow requirements -->  
</dependencies>  
  
<!-- Kafka Dependencies -->  
<dependencies>  
    <dependency>  
        <groupId>org.springframework.kafka</groupId>  
        <artifactId>spring-kafka</artifactId>  
        <version>2.8.0</version> <!-- Replace with the latest Spring Kafka version -->  
    </dependency>  
    <!-- Add other Kafka dependencies based on your messaging requirements -->  
</dependencies>
```
### Maven Plugins
```xml
<!-- Maven Plugins for Spring Boot and Docker -->  
<build>  
    <plugins>  
        <plugin>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-maven-plugin</artifactId>  
        </plugin>  
        <plugin>  
            <groupId>com.spotify</groupId>  
            <artifactId>dockerfile-maven-plugin</artifactId>  
            <version>1.4.9</version> <!-- Replace with the latest Dockerfile Maven Plugin version -->  
            <executions>  
                <execution>  
                    <id>default</id>  
                    <goals>  
                        <goal>build</goal>  
                    </goals>  
                </execution>  
            </executions>  
            <configuration>  
                <useMavenSettingsForAuth>true</useMavenSettingsForAuth>  
                <imageName>your-docker-image-name</imageName>  
                <!-- Additional Dockerfile configuration -->  
            </configuration>  
        </plugin>  
    </plugins>  
</build>
```
### POM
```xml
<!-- Maven POM Configuration -->  
<properties>  
    <java.version>11</java.version> <!-- Specify the Java version used in your application -->  
    <spring.boot.version>2.6.3</spring.boot.version>  
    <camunda.bpm.version>7.16.0</camunda.bpm.version>  
    <spring.kafka.version>2.8.0</spring.kafka.version>  
</properties>  
  
<!-- Spring Boot Starter Dependencies -->  
<dependencies>  
    <dependency>  
        <groupId>org.springframework.boot</groupId>  
        <artifactId>spring-boot-starter-web</artifactId>  
    </dependency>  
    <!-- Add other Spring Boot starters based on your requirements -->  
</dependencies>  
  
<!-- Camunda BPM Starter Dependencies -->  
<dependencies>  
    <dependency>  
        <groupId>org.camunda.bpm.springboot</groupId>  
        <artifactId>camunda-bpm-spring-boot-starter</artifactId>  
        <version>${camunda.bpm.version}</version>  
    </dependency>  
    <!-- Add other Camunda BPM dependencies based on your workflow requirements -->  
</dependencies>  
  
<!-- Kafka Dependencies -->  
<dependencies>  
    <dependency>  
        <groupId>org.springframework.kafka</groupId>  
        <artifactId>spring-kafka</artifactId>  
        <version>${spring.kafka.version}</version>  
    </dependency>  
    <!-- Add other Kafka dependencies based on your messaging requirements -->  
</dependencies>  
  
<!-- Maven Build Plugins -->  
<build>  
    <plugins>  
        <plugin>  
            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-maven-plugin</artifactId>  
        </plugin>  
        <plugin>  
            <groupId>com.spotify</groupId>  
            <artifactId>dockerfile-maven-plugin</artifactId>  
            <version>1.4.9</version>  
            <!-- Replace with the latest Dockerfile Maven Plugin version -->  
            <executions>  
                <execution>  
                    <id>default</id>  
                    <goals>  
                        <goal>build</goal>  
                    </goals>  
                </execution>  
            </executions>  
            <configuration>  
                <useMavenSettingsForAuth>true</useMavenSettingsForAuth>  
                <imageName>your-docker-image-name</imageName>  
                <!-- Additional Dockerfile configuration -->  
            </configuration>  
        </plugin>  
    </plugins>  
</build>
```
### Setting Up the Project

// Build upon the project setup by including more detailed insights into choosing the right build tools, setting up continuous integration pipelines, and integrating with popular DevOps practices for streamlined deployment.  
  
// Extended project setup with Spring Boot, including additional build tool configurations and continuous integration setup using tools like Maven or Gradle.  
```shell
// Sample application.properties for configuring microservices  
server.port=8080  
spring.application.name=order-fulfillment  
```
```dockerfile
// Sample Dockerfile for containerization  
FROM openjdk:11-jre-slim  
COPY target/order-fulfillment.jar /app.jar  
CMD ["java", "-jar", "/app.jar"]
```
### Integrating Camunda BPM

![](https://miro.medium.com/v2/resize:fit:875/1*VW-DtvGiCwsDEYGwXMDu9Q.png)

// Enhanced Camunda configuration with additional settings for handling complex workflows and external system integrations.  
  
// Sample BPMN process definition  
```xml
<?xml version="1.0" encoding="UTF-8"?>  
<definitions xmlns="http://www.omg.org/spec/BPMN/20100524/MODEL"  
             xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  
             xmlns:camunda="http://camunda.org/schema/1.0/bpmn"  
             targetNamespace="http://bpmn.io/schema/bpmn">  
    
  <process id="order-fulfillment" name="Order Fulfillment Process">  
    <!-- BPMN process elements go here -->  
  </process>  
  
</definitions>  
```
```java
// Sample Java class to start a process instance  
@Service  
public class OrderFulfillmentService {  
  
    @Autowired  
    private RuntimeService runtimeService;  
  
    public void startOrderFulfillmentProcess(String orderId) {  
        runtimeService.startProcessInstanceByKey("order-fulfillment", orderId);  
    }  
}
```
![](https://miro.medium.com/v2/resize:fit:875/1*NzNX6SLAh2IhUdam0w7zjQ.png)

Below are examples of controller, service, DAO (Data Access Object), configuration, and repository classes. Please note that these are simplified examples, and you may need to adapt them based on your specific application requirements.

### Controller Class
```java
@RestController  
@RequestMapping("/api/orders")  
public class OrderController {  
@Autowired  
    private OrderService orderService;  
    @PostMapping("/create")  
    public ResponseEntity<String> createOrder(@RequestBody OrderDto orderDto) {  
        String orderId = orderService.createOrder(orderDto);  
        return ResponseEntity.ok("Order created with ID: " + orderId);  
    }  
    @GetMapping("/{orderId}")  
    public ResponseEntity<OrderDto> getOrder(@PathVariable String orderId) {  
        OrderDto orderDto = orderService.getOrder(orderId);  
        return ResponseEntity.ok(orderDto);  
    }  
}
```
### Service Class
```java
@Service  
public class OrderService {  
@Autowired  
    private OrderRepository orderRepository;  
    @Autowired  
    private KafkaEventProducer kafkaEventProducer;  
    public String createOrder(OrderDto orderDto) {  
        // Business logic for creating an order  
        Order order = orderRepository.save(new Order(orderDto));  
          
        // Publish an event to Kafka  
        kafkaEventProducer.produceEvent("order-events", "OrderCreatedEvent: " + order.getId());  
        return order.getId();  
    }  
    public OrderDto getOrder(String orderId) {  
        // Business logic for retrieving an order  
        Order order = orderRepository.findById(orderId)  
                .orElseThrow(() -> new NotFoundException("Order not found with ID: " + orderId));  
        return new OrderDto(order);  
    }  
}
```

### DAO (Data Access Object) / Repository Class
```java
@Repository  
public interface OrderRepository extends JpaRepository<Order, String> {  
    // Custom query methods if needed  
}
```

### Configuration Class
```java
@Configuration  
public class KafkaConfig {  
@Value("${spring.kafka.bootstrap-servers}")  
    private String bootstrapServers;  
    @Bean  
    public ProducerFactory<String, String> producerFactory() {  
        Map<String, Object> configProps = new HashMap<>();  
        configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);  
        // Add additional Kafka producer configurations if needed  
        return new DefaultKafkaProducerFactory<>(configProps);  
    }  
    @Bean  
    public KafkaTemplate<String, String> kafkaTemplate() {  
        return new KafkaTemplate<>(producerFactory());  
    }  
}
```

### Model Class
```java 
@Entity  
public class Order {  
@Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    private String id;  
    // Other fields, getters, setters, and constructors  
    public Order() {  
        // Default constructor for JPA  
    }  
    public Order(OrderDto orderDto) {  
        // Map OrderDto to Order entity  
    }  
    // Additional business logic or methods if needed  
}
```
### DTO (Data Transfer Object) Class
```java
public class OrderDto {  
private String id;  
    // Other fields, getters, setters, and constructors  
    public OrderDto() {  
        // Default constructor  
    }  
    public OrderDto(Order order) {  
        // Map Order entity to OrderDto  
    }  
}
```
These examples provide a basic structure for a Spring Boot application with Kafka integration. Adjustments and additional features can be made based on your specific requirements. Additionally, ensure to set up the necessary configurations in your `application.properties` or `application.yml` file, including Kafka configuration properties and database connection details.

### Connecting with Kafka

// Enriched Kafka code examples covering advanced scenarios for transactional messaging and topic management.  
 ```java 
// Sample Kafka Producer with transactional messaging  
@Service  
public class KafkaEventProducer {  
  
    @Autowired  
    private KafkaTemplate<String, String> kafkaTemplate;  
  
    @Transactional  
    public void produceTransactionalEvent(String topic, String message) {  
        kafkaTemplate.executeInTransaction(kafkaOperations -> {  
            kafkaOperations.send(topic, message);  
            // Additional Kafka operations within the transaction  
            return null;  
        });  
    }  
}  
 
// Sample Kafka Consumer with advanced topic management  
@Service  
public class KafkaEventConsumer {  
  
    @KafkaListener(topics = "order-events")  
    public void consumeOrderEvent(String message) {  
        // Process the received order event  
    }  
}
```

In the above mentioned use case of building an event-driven Spring Boot application with Camunda BPM workflow orchestration and Kafka as a message broker, various capabilities can be identified.

Below, I’ll define microservices for each of these capabilities:

### 1. Order Management Microservice

This microservice is responsible for handling order-related operations, including order creation, retrieval, and management.

Microservice Definition:

-   Name: Order Management Microservice

**Responsibilities**:

-   Create orders based on incoming requests.
-   Retrieve order details.
-   Update order status.

**Technology Stack:**

-   Spring Boot for the microservice framework.
-   Camunda BPM for workflow orchestration related to order processing.
-   Kafka for event-driven communication.

### 2. Inventory Management Microservice

This microservice is responsible for managing the inventory and ensuring that products are available for order fulfillment.

Microservice Definition:

-   Name: Inventory Management Microservice

**Responsibilities**:

-   Track product availability.
-   Update inventory levels upon order creation.
-   Notify other microservices of inventory changes.

**Technology Stack:**

-   Spring Boot for the microservice framework.
-   Kafka for event-driven communication.

### 3. Payment Processing Microservice

This microservice handles payment-related operations, ensuring that payments are processed securely.

Microservice Definition:

-   Name: Payment Processing Microservice

**Responsibilities**:

-   Authorize and process payments.
-   Handle payment confirmations.
-   Notify other microservices of payment status.

**Technology Stack:**

-   Spring Boot for the microservice framework.
-   Kafka for event-driven communication.

### 4. Shipping Microservice

The shipping microservice manages the process of packaging and delivering orders to customers.

Microservice Definition:

-   Name: Shipping Microservice

**Responsibilities**:

-   Generate shipping labels.
-   Coordinate with logistics for order delivery.
-   Notify other microservices of shipping status.

**Technology Stack:**

-   Spring Boot for the microservice framework.
-   Kafka for event-driven communication.

### 5. Workflow Orchestration Microservice

This microservice is dedicated to orchestrating the overall workflow using Camunda BPM, coordinating the interaction between different microservices.

Microservice Definition:

-   Name: Workflow Orchestration Microservice

**Responsibilities:**

-   Define and execute business processes using Camunda BPM.
-   Coordinate the flow of events between microservices.
-   Manage long-running processes.

**Technology Stack:**

-   Spring Boot for the microservice framework.
-   Camunda BPM for workflow orchestration.
-   Kafka for event-driven communication.

### 6. Event Communication Microservice

This microservice acts as a central hub for managing and coordinating events between different microservices.

Microservice Definition:

-   Name: Event Communication Microservice

**Responsibilities:**

-   Publish events to Kafka topics.
-   Subscribe to relevant Kafka topics for event processing.
-   Ensure reliable and asynchronous communication between microservices.

**Technology Stack:**

-   Spring Boot for the microservice framework.
-   Kafka for event-driven communication.

These microservices encapsulate specific business capabilities and interact with each other through well-defined APIs and event-driven communication. Each microservice is designed to be independent, scalable, and focused on a specific set of responsibilities, adhering to the principles of microservices architecture.

### Error Handling and Retry Mechanism

In any distributed system, error handling and retries play a crucial role in ensuring the resilience and reliability of the overall solution. In the context of the event-driven Spring Boot application with Camunda BPM workflow orchestration and Kafka as a message broker, implementing robust error handling and retry mechanisms is essential. Let’s explore how these aspects can be addressed in various components of the solution.

### 1. Order Management Microservice

Error Handling:

-   Handle exceptions thrown during order creation, ensuring that the system gracefully responds to issues such as invalid input or database errors.
-   Log relevant error details for later analysis.

Retry Mechanism:

-   Implement a retry mechanism for database operations, considering transient failures.
-   Utilize Spring Retry annotations or custom retry logic to reattempt order creation in case of database-related failures.

### 2. Inventory Management Microservice

Error Handling:

-   Capture errors related to inventory updates, such as insufficient stock or database errors.
-   Log error details and trigger appropriate compensating actions.

Retry Mechanism:

-   Implement retries for inventory update operations, especially when facing temporary unavailability of the inventory database.
-   Consider exponential backoff strategies to avoid overwhelming the system during transient issues.

### 3. Payment Processing Microservice

Error Handling:

-   Address errors during payment authorization or processing, including network issues or payment gateway failures.
-   Log error details and, if necessary, trigger compensation mechanisms.

Retry Mechanism:

-   Apply retries for payment processing operations, considering scenarios where temporary connectivity issues with payment gateways may occur.
-   Implement configurable retry policies based on the type of payment failure.

### 4. Shipping Microservice

Error Handling:

-   Manage errors related to shipping label generation, logistics coordination, or delivery failures.
-   Log error details and initiate compensating actions when required.

Retry Mechanism:

-   Introduce retries for shipping-related operations, acknowledging that external logistics systems or label generation services may experience intermittent issues.
-   Implement backoff strategies to avoid overloading external services.

### 5. Workflow Orchestration Microservice

Error Handling:

-   Handle errors arising from the execution of business processes using Camunda BPM, such as task failures or external system integration issues.
-   Log errors and initiate appropriate compensating actions or workflow modifications.

Retry Mechanism:

-   Configure retries for Camunda BPM tasks that interact with external systems or services.
-   Leverage Camunda BPM’s built-in retry mechanisms for activities within a workflow.

### 6. Event Communication Microservice

Error Handling:

-   Address errors related to event publication or subscription, such as Kafka connection issues or serialization problems.
-   Log errors and consider notifying administrators for critical issues.

Retry Mechanism:

-   Implement retries for publishing events to Kafka topics, especially during transient issues with the Kafka broker.
-   Configure Kafka consumers to handle message processing errors and attempt reprocessing.

### Cross-Cutting Concerns

**Logging and Monitoring:**

-   Integrate comprehensive logging mechanisms throughout the microservices to capture errors, warnings, and relevant information.
-   Implement centralized monitoring using tools like Prometheus, Grafana, or ELK Stack to track error rates, retries, and system health.

**Circuit Breakers:**

-   Introduce circuit breakers to prevent continuous retries in case of persistent failures.
-   Open circuits for affected microservices and employ fallback mechanisms or alternative paths.

**Dead Letter Queues (DLQ):**

-   Utilize Dead Letter Queues to capture messages that repeatedly fail processing.
-   Analyze messages in the DLQ to identify and address root causes.

By implementing these error handling and retry mechanisms, the event-driven Spring Boot application can enhance its resilience in the face of transient failures, contributing to a more reliable and robust system. Regular testing and monitoring of these mechanisms ensure their effectiveness in real-world scenarios.

### Non-Functional Requirements

Non-functional requirements define the aspects of a system’s behavior that are not related to its specific functionalities but rather focus on the system’s qualities, such as performance, reliability, security, and maintainability. Here are some non-functional requirements for the use case mentioned in the blog post, along with strategies on how to address them:

### 1. Performance

### Requirement:

-   Response Time: The system should respond to user requests within an acceptable timeframe.

### Addressing Strategy:

-   Optimize database queries and indexing for efficient data retrieval.
-   Implement caching mechanisms for frequently accessed data.
-   Utilize asynchronous processing to improve responsiveness.

### 2. Scalability

### Requirement:

-   Horizontal Scalability: The system should be able to handle an increasing number of users and transactions by adding more instances.

### Addressing Strategy:

-   Design microservices to be stateless for easy horizontal scaling.
-   Use container orchestration tools like Kubernetes for dynamic scaling.
-   Distribute the load evenly across microservices.

### 3. Reliability and Availability

### Requirement:

-   High Availability: The system should be available and operational with minimal downtime.

### Addressing Strategy:

-   Implement redundancy and failover mechanisms for critical components.
-   Utilize load balancing to distribute traffic evenly across multiple instances.
-   Set up monitoring and alerting to proactively address issues.

### 4. Security

### Requirement:

-   Data Encryption: Ensure sensitive data, especially during communication, is encrypted.

### Addressing Strategy:

-   Use HTTPS for secure communication between microservices.
-   Employ OAuth or JWT for secure authentication and authorization.
-   Regularly update dependencies and libraries to address security vulnerabilities.

### 5. Maintainability

### Requirement:

-   Code Maintainability: The codebase should be easy to understand, modify, and extend.

### Addressing Strategy:

-   Follow best practices in coding standards and documentation.
-   Implement continuous integration and continuous deployment (CI/CD) for automated testing and deployment.
-   Encourage modular design and clean code principles.

### 6. Monitoring and Logging

### Requirement:

-   Real-time Monitoring: The system should provide real-time insights into its performance and health.

### Addressing Strategy:

-   Integrate monitoring tools such as Prometheus, Grafana, or ELK Stack.
-   Implement centralized logging for easy issue identification and debugging.
-   Set up alerts for critical events to enable proactive response.

### 7. Compliance and Regulation

### Requirement:

-   Regulatory Compliance: Ensure the system adheres to relevant industry regulations and compliance standards.

### Addressing Strategy:

-   Stay informed about industry-specific regulations.
-   Implement security measures to protect user data and privacy.
-   Regularly audit the system to ensure compliance.

### 8. Cost Efficiency

### Requirement:

-   Cost-Effective Scaling: Ensure the system can scale efficiently without incurring unnecessary costs.

### Addressing Strategy:

-   Optimize resource utilization through efficient coding and infrastructure management.
-   Leverage cloud provider services that offer cost-effective scaling options.
-   Implement cost monitoring to identify and address potential bottlenecks.

### 9. Scalability — Vertical Scalability

### Requirement:

-   Vertical Scalability: The system should be able to handle increased load on a single microservice by vertically scaling resources.

### Addressing Strategy:

-   Optimize microservices for vertical scaling by selecting appropriate cloud instance types.
-   Utilize containerization to ensure consistent deployment across various environments.

### 10. Reliability — Fault Tolerance

### Requirement:

-   Fault Tolerance: The system should gracefully handle and recover from component failures.

### Addressing Strategy:

-   Implement circuit breakers to prevent cascading failures during high traffic.
-   Use retry mechanisms for critical operations to handle transient failures.
-   Employ stateless microservices to facilitate easier recovery.

### 11. Security — Data Masking

### Requirement:

-   Data Masking: Sensitive data in logs and responses should be masked to protect user privacy.

### Addressing Strategy:

-   Apply data masking techniques to conceal sensitive information in logs.
-   Use secure logging practices to prevent exposure of sensitive data.

### 12. Maintainability — Documentation

### Requirement:

-   Comprehensive Documentation: Maintain detailed documentation for code, APIs, and system architecture.

### Addressing Strategy:

-   Generate API documentation using tools like Swagger for easy consumption.
-   Keep system architecture diagrams and design documentation up to date.
-   Document coding standards and guidelines for developers.

### 13. Monitoring and Logging — Tracing

### Requirement:

-   Distributed Tracing: Enable tracing to monitor and analyze the flow of requests across microservices.

### Addressing Strategy:

-   Use distributed tracing tools like Jaeger or Zipkin.
-   Implement correlation IDs to trace requests as they traverse through microservices.

### 14. Operational Excellence — DevOps Practices

### Requirement:

-   DevOps Practices: Adopt DevOps principles for seamless collaboration between development and operations teams.

### Addressing Strategy:

-   Implement CI/CD pipelines for automated testing and deployment.
-   Use infrastructure as code (IaC) for consistent and reproducible deployments.
-   Foster a culture of collaboration, communication, and shared responsibility.

### 15. Performance — Load Testing

### Requirement:

-   Load Testing: Validate system performance under different load scenarios.

### Addressing Strategy:

-   Conduct regular load testing to identify performance bottlenecks.
-   Optimize database queries, indexing, and caching based on load test results.

### 16. Security — API Security

### Requirement:

-   API Security: Ensure secure communication and data integrity for all APIs.

### Addressing Strategy:

-   Implement secure authentication mechanisms (OAuth, JWT) for API access.
-   Enforce proper authorization checks within microservices.

### 17. Compliance and Regulation — Data Retention Policies

### Requirement:

-   Data Retention Policies: Adhere to data retention regulations by defining and implementing data expiration policies.

### Addressing Strategy:

-   Regularly review and update data retention policies.
-   Implement mechanisms to automatically purge or archive data based on policies.

These non-functional requirements cover aspects like vertical scalability, fault tolerance, data masking, documentation, distributed tracing, DevOps practices, load testing, API security, and data retention policies. Addressing these requirements ensures a comprehensive approach to building a robust, secure, and scalable microservices architecture.

### Tools and softwares:

Below are some tools and software that can be used to implement and address the non-functional requirements mentioned earlier:

### 1. Performance Testing and Monitoring:

-   Tool: Apache JMeter, Gatling, Locust
-   Monitoring Tools: Prometheus, Grafana, New Relic, Datadog

### 2. Scalability and Container Orchestration:

-   Tools: Kubernetes, Docker, Docker Compose
-   Cloud Providers: Amazon ECS, Google Kubernetes Engine (GKE), Azure Kubernetes Service (AKS)

### 3. Reliability and Fault Tolerance:

-   Tools: Hystrix (for circuit breakers), Resilience4j, Istio
-   Service Mesh: Istio, Linkerd

### 4. Security — Encryption and Authentication:

-   Tools: Keycloak, OAuth 2.0 providers (e.g., Auth0, Okta)
-   API Security: Spring Security, Apigee, AWS WAF (Web Application Firewall)

### 5. Logging and Monitoring — Tracing:

-   Tracing Tools: Jaeger, Zipkin, OpenTelemetry
-   Logging: ELK Stack (Elasticsearch, Logstash, Kibana), Fluentd

### 6. Maintainability — Documentation:

-   Documentation Tools: Swagger, AsciiDoc, Confluence
-   Version Control: Git, GitHub, GitLab

### 7. Operational Excellence — CI/CD:

-   CI/CD Tools: Jenkins, GitLab CI, Travis CI, CircleCI
-   Infrastructure as Code (IaC): Terraform, AWS CloudFormation, Ansible

### 8. Performance — Load Testing:

-   Load Testing Tools: Apache JMeter, Gatling, Locust
-   Application Performance Monitoring (APM): New Relic, AppDynamics

### 9. Security — API Security:

-   API Security Tools: OWASP ZAP, Postman, API Gateways (e.g., Kong, Apigee)
-   Identity and Access Management (IAM): Keycloak, Auth0, Okta

### 10. Compliance and Regulation — Data Retention:

-   Data Management Tools: Apache Kafka (for event streaming), Apache Flink (for stream processing)
-   Data Encryption: TLS/SSL for secure communication

### 11. Monitoring and Logging — Centralized Logging:

-   Centralized Logging Tools: ELK Stack (Elasticsearch, Logstash, Kibana), Splunk, Graylog

### 12. Security — JWT Token Handling:

-   Libraries: Nimbus, Auth0 Java JWT
-   API Gateways: Apigee, AWS API Gateway

These tools cover a wide range of functionalities, from performance testing to monitoring, logging, security, and compliance. The selection of specific tools can depend on the specific requirements, the technology stack used, and the preferences of the development and operations teams. It’s important to choose tools that seamlessly integrate into the existing development and deployment workflows

### Pros and Cons

### Pros

1.  Scalability Beyond Limits: A Comprehensive Guide
2.  Explore in detail the scalability options available in event-driven architectures, including vertical and horizontal scaling, and provide a guide on selecting the right strategy based on the application’s characteristics.
3.  Flexibility Redefined: Adapting to Change
4.  Delve into advanced flexibility topics, including dynamic service discovery, API governance strategies, and practical examples of feature toggles. Showcase how an event-driven architecture promotes adaptability in a rapidly changing business landscape.
5.  Fault Tolerance Strategies: Navigating Through Challenges
6.  Extend the discussion on fault tolerance by exploring advanced strategies such as graceful degradation, automated healing mechanisms, and chaos engineering. Real-world case studies will illustrate the successful implementation of these strategies in complex event-driven systems.

### Cons

1.  Mastering Complexity: Advanced Debugging Techniques

We need to provide an exhaustive guide on debugging event-driven systems, covering advanced tools, methodologies, and real-world case studies. also , We need to highlight the role of observability, logging, and distributed tracing in simplifying the complexity associated with large-scale event-driven architectures. This activity needs dedicated time and efforts and has learning curves involved.

2.Consistency Challenges Explored in Depth

We need to have the clear understanding of the data consistency challenges and ways of resolution by providing a comprehensive detailed runbook to investigate and troubleshoot distributed transactions, compensating transactions, and advanced patterns for achieving eventual consistency in a distributed microservices environment. This activity needs dedicated time and efforts and has learning curves involved.
---
# Listener in Camunda. A Listener in Camunda

A Listener in Camunda can be Execution Listener or Task Listener, it will trigger when an event start or stop.

For the User task : the Listener can be triggred when :

![](https://miro.medium.com/v2/resize:fit:328/1*uyjvBiZaD2m0PmaS24ahhA.png)

create : when creating a userTask

assignment: when assign a userTask to a user, or claming it

complete: when the userTask is completed

delete: when the userTask is deleted

> **_Execution Listener:_**

Execution Listener can be used in the end or the start of a task, or in the start event or in the start of the process:

we gonna create a bmpn file, in main process we gonna set in the start an event, this event is of type start. it will be implemtented by a java class.

The class which will be called by an event listener must implement the internface ‘ExecutionListener’ and override the method notify.

First of all we gonna create a event lister with type “start” when starting the process:

![](https://miro.medium.com/v2/resize:fit:875/1*nL2B3cXoHdzzlWL2P4Z-CA.png)

This is the implementation in java class:

we gonna create a todayDate variable with the date of today

![](https://miro.medium.com/v2/resize:fit:875/1*Y7iGfkkc5CiAKDfpYFLxvg.png)

The serviceTask Print today date will call a java class in which we gonna retreive the value of the todayDate inserted from the start event listener:

![](https://miro.medium.com/v2/resize:fit:875/1*nFbK72Rbzlv0_EQtb9ECqg.png)

![](https://miro.medium.com/v2/resize:fit:875/1*GDYvn2VCTDcwpuPfvdSOhQ.png)

finally when the service task completed (the execution of task is completed) we gonna, call an event listener (end event listener) in which we gonna create another variable date.

![](https://miro.medium.com/v2/resize:fit:875/1*AHOC40ChHomAf-Ye095syA.png)

![](https://miro.medium.com/v2/resize:fit:875/1*oZMsYikjm7A3lOhbi3pXMQ.png)

Let s run the process:

as we can see the process is execution and the order of the execution is well displayed:

1.  the start event listener
2.  the service task
3.  the end event listener of the service task

![](https://miro.medium.com/v2/resize:fit:875/1*FLkf6qwlFGEGaQdErPrX6A.png)

in cockpit:

![](https://miro.medium.com/v2/resize:fit:875/1*K5a3PZhy4v6oLsLc3bzMuw.png)

Github repo: [https://github.com/ghailen/execution-event-listener-camunda](https://github.com/ghailen/execution-event-listener-camunda)

> **_Task Listener_**

Now we gonna talk about task listener. when using a user task we can trigger a listener this listener can be triggred, when creating,deleting,claming or completing a user task.

a class which present a listener must implement the TaskListener interface and override the notify method.

For the bpmn file: we create two usertasks, we putted a task listener in the first one, and another one when completing the second task.

The first task:

![](https://miro.medium.com/v2/resize:fit:875/1*BVBVhiJ_XRPFAoNBBFig_A.png)

![](https://miro.medium.com/v2/resize:fit:875/1*OfEUUBvwDWT-7PxDuSH8GQ.png)

The second task : we gonna try to inject ‘using the interface TASKLIST” a variable named ghailene in the first task and get it in the completion of the second task

![](https://miro.medium.com/v2/resize:fit:875/1*9kqSSV7FLEoqMbwbhE2E8g.png)

![](https://miro.medium.com/v2/resize:fit:875/1*yRJqpq2Gl4lyYhx7t_FXXg.png)

let s start the process:

as we can see in the console : we printed the event of tasklistener when triggred (in our case is : create )

the variables (no variable yet)

the task name: Set variable

![](https://miro.medium.com/v2/resize:fit:875/1*EqV3tOTAhVS0pxNvZq2IDQ.png)

Now let fill the variable ghailene to read it in the next task.

![](https://miro.medium.com/v2/resize:fit:875/1*2szfi8QGJOjSui-M5-zCBA.png)

lets complete it.

now nothing is printed in the console. and the new task “check data” is displayed. lets complete it

after the completion of the “check data” we can see in the log:

![](https://miro.medium.com/v2/resize:fit:875/1*rHVIS4LovI2mmYAyWEtHiw.png)

=> the variable is successfully loaded after the completion of the second task “check data”.

Git repo:

[

### GitHub - ghailen/execution-event-listener-camunda at task-listener
https://github.com/ghailen/execution-event-listener-camunda/tree/task-listenern.
---
# Camunda Service Tasks: A Step-by-Step Guide To External Tasks (Topics)

In this article, we’ll explore the concept of external tasks, their benefits, and how to configure a service task implementation as an external task, also known as topics, within Camunda. Using a simple example, we’ll walk through the process step-by-step, including how to set up retry attempts on periodic intervals.

![](https://miro.medium.com/v2/resize:fit:875/0*kf-cLIVdE8YnX1pS)
Photo by Callum Shaw on Unsplash

Version used: **Camunda 7.0**

**Camunda Service Tasks: Workflow Automation and Integration**

A service task in Camunda allows us to seamlessly integrate and execute business logic within the same application or from a remote system, providing flexibility and scalability in our workflow automation.

![](https://miro.medium.com/v2/resize:fit:875/1*BLWFdZDxui9hHljS1QXnWw.png)

1.  Java Delegate (Java class)
2.  Delegate Expression
3.  Connectors
4.  **External Task**
5.  Expression

After reading this article, you’ll have a comprehensive understanding of external tasks, their advantages, and how to configure them in Camunda to optimize your workflow management.

**What is an External Task?**

As the name suggests, the process engine publishes work to an external system, which is then executed by a worker and completed as a task. The invoked business service can be local or remote, and the remote system can be implemented in any programming language, using REST or SOAP web services for invocation. This allows for flexibility and scalability in integrating with external systems.

Example:

![](https://miro.medium.com/v2/resize:fit:875/1*skTmgQiN2vdWiFsPo7Q.png)

**How it works?**

As we’re aware, the process engine governs the workflow. When a service task with an external task implementation is encountered, the process engine generates an external task instance (as illustrated in steps 1 and 2) and adds it to the external task list, enabling seamless integration with external systems.

![](https://miro.medium.com/v2/resize:fit:1250/1*GqzBLDvMOV8VOBeJlfkwUQ.png)
How External Task Works in Camunda

Each external task instance is assigned a distinct topic, which specifies the particular work to be executed by the corresponding external worker. As illustrated in the diagram, an external task instance with a matching colour to an external worker represents the system responsible for executing the actual business logic, such as External Worker 1, 2, or 3. Once the task is complete, the external worker sends a confirmation back to the process engine, enabling the engine to proceed with the workflow (step 3).

External workers retrieve and lock external tasks associated with a specific topic, using a timestamp-based locking mechanism that prevents multiple workers from accessing the same task simultaneously. This ensures that each task is processed exclusively by a single worker, avoiding potential conflicts and ensuring efficient workflow execution.

**When to Use External Workers and when to use Connectors**

1.  **Is low-level API access needed?**  
    Use job workers for tasks that demand direct access to Camunda’s low-level API, enabling precise control and customization.
2.  **Non-Java worker logic?**  
    Job workers provide the flexibility to implement logic in any programming language of your choice, enabling language-independent development and integration.
3.  **Reusable worker logic?**  
    Develop a Connector to encapsulate reusable logic, enabling seamless deployment and integration across various environments, promoting scalability and flexibility.
4.  **Focus on worker logic only?**  
    Use Connectors to abstract away low-level Camunda API details.
5.  **Standardized modelling experience?**  
    Develop a Connector to integrate a standardized modelling experience with runtime behaviour, ensuring consistency and alignment between design and execution, and streamlining the workflow development process.

**Let’s understand external tasks with an example:**

Consider a typical business scenario: a customer places an order for coffee and completes the payment process, expecting to receive their coffee delivery. This everyday use case illustrates a straightforward workflow, where the customer’s order and payment trigger a series of processes that ultimately lead to the delivery of their coffee

**Example: Coffee Order Process flow**

![](https://miro.medium.com/v2/resize:fit:1250/1*lM37ITXyHi1x9ymCV0lm5w.png)

**Step 1: Let’s configure the External task for “Order Coffee” as below**

![](https://miro.medium.com/v2/resize:fit:1250/1*SJwErKO2kh7m41X8zuJ82w.png)

**Step 2: Configure “Payment Success” as an external task**

![](https://miro.medium.com/v2/resize:fit:1250/1*gkT33NApiSDCGSaEaGEkTg.png)

**Token Simulation across the workflow with parallel gateway**

![](https://miro.medium.com/v2/resize:fit:1250/1*f7jENNeccJy2ZwRDsdEjdQ.png)

In this scenario, the ‘Order Coffee’ and ‘Payment Success’ external task services are implemented in a remote system, requiring subscription and configuration of external task handler properties. This can be achieved through either a property/yml file or Java annotations, as shown below.

Two ways to subscribe to a Camunda topic

Properties:

-   **camunda.bpm.client.base-url** → **to configure the URL pointing to the Camunda Platform Runtime REST API**
-   **camunda.bpm.client.lock-duration → defines how many milliseconds the External Tasks are locked until they can be fetched again**

1.  **@ExternalTaskSubscription — Camunda Topic subscription on Java class**
```java
@Component  
@ExternalTaskSubscription(  
        topicName = "payment-success-topic",  
        processDefinitionKey = "coffee-order-process",  
        lockDuration = 10000,  
        includeExtensionProperties = true,  
        variableNames = "price"  
)  
public class PaymentSuccessExternalHandler implements ExternalTaskHandler {  
  ...  
  ...  
}
```

application.yml:
```yaml
camunda.bpm.client:  
  base-url: http://localhost:9991/engine-rest
```

2. **Topic subscription from application.yml file**
```java
@Component  
@ExternalTaskSubscription("order-coffee-topic")   
public class OrderCoffeeExternalHandler implements ExternalTaskHandler {  
  ...  
  ...  
}
```
```yaml
camunda.bpm.client:  
  base-url: http://localhost:9991/engine-rest ###   
  lock-duration: 10000  
  subscriptions:  
    order-coffee-topic:  
      variable-names: []  
      process-definition-key: coffee-order-process
```

Below we can find the heatmap representing traffic across the workflow.

![](https://miro.medium.com/v2/resize:fit:875/1*TYkO0VGzFfaONpBhoKRDA.png)

**Testing — Coffee Order process from Postman: Trigger a request as below to start the process.**

**Note**: The message name is the name of the message start event (global message reference).

![](https://miro.medium.com/v2/resize:fit:1250/1*zHlF1mAeU8RFp7CJDyYhlw.png)

Post API: [http://localhost:9991/engine-rest/message](http://localhost:9991/engine-rest/message)

![](https://miro.medium.com/v2/resize:fit:1250/1*ItdL4YsPQaFaO8Pa38jQ.png)

**Enabling Automated Retry Mechanism for External Tasks: A Guide to Configuring Retry Intervals for Failures**
```java
@Component  
@ExternalTaskSubscription(  
        topicName = "payment-success-topic",  
        processDefinitionKey = "coffee-order-process",  
        lockDuration = 10000,  
        includeExtensionProperties = true,  
        variableNames = "price"  
)  
public class PaymentSuccessExternalHandler implements ExternalTaskHandler {  
  
    private final static int DEFAULTRETRIESNO = 3;  
    private final static int RETRYTIMEOUT = 30000; // retry every 30 seconds  
  
    @Override  
    public void execute(ExternalTask externalTask, ExternalTaskService externalTaskService) {  
        System.out.println("PaymentSuccessExternalHandler :: STARTED");  
        ....  
        ....  
        try{  
            ... BUSINESS LOGIC: THROWS EXCEPTION - if PRICE is EVEN  
            externalTaskService.complete(externalTask, variableMap);  
        }catch (Exception exception) {  
            System.out.println("PaymentSuccessExternalHandler :: EXCEPTION - "+price);  
            externalTaskService.handleFailure(  
                    externalTask,  
                    exception.getMessage(),  
                    exception.getStackTrace().toString(),  
                    retryCount(externalTask.getRetries()),  
                    RETRYTIMEOUT);  
        }  
  
        System.out.println("PaymentSuccessExternalHandler :: END");  
    }  
  
    private int retryCount(Integer taskRetries) {  
        Logger.getLogger("Payment Success")  
                .log(Level.INFO, "RETRY-COUNT::: " + taskRetries);  
        if (taskRetries == null) { // initially task.retries is null  
            return DEFAULTRETRIESNO;  
        }  
        return taskRetries - 1;  
    }  
}
```
Following three retry attempts, as configured, incidents are generated post 30-second intervals, as seen in the system.

![](https://miro.medium.com/v2/resize:fit:1250/1*UdfRz9I0-wzMTfLYcMFzIg.png)

![](https://miro.medium.com/v2/resize:fit:875/1*VThb3iIZIxzMxl40rjIM6A.png)

Given that the provided value for the ‘price’ variable is an even number, an exception will be thrown, triggering a retry mechanism that will attempt to resolve the issue up to three times before exhausting the attempts and resulting in an incident being logged in the cockpit.

![](https://miro.medium.com/v2/resize:fit:875/1*n9e9MXo2RpeKaZY1SiTnw.png)

![](https://miro.medium.com/v2/resize:fit:1250/1*FgWeTtGpPSpU85fH03RbRA.png)

I hope this article has helped explain the fundamental configurations for external tasks, also known as Camunda topics, using a coffee shop process as an example. We explored the various configuration properties and their purposes, leveraging annotation levels and property configurations provided by the Camunda library. This knowledge should help you set up and manage external tasks efficiently in your Camunda workflows.
---

# Batch Processing with Camunda. During the implementation of Enterprise


During the implementation of Enterprise Systems the requirements of batch processing needs to be met regularly. This article discusses possibilities of implementation Batch Processing using Camunda process engine.

Camunda BPM Engine is a developer-friendly, modern, light-weight BPMN 2.x process engine written in Java. It allows for efficient and effective implementation of the orchestration layer in business process automation systems by embedding the process engine into the application. In doing so, it provides not only the execution engine for BPMN 2.x, but a couple of very useful facilities and components which can be used in the resulting system.

Image, you are implementing a system which need some kind of notification capabilities on the execution of certain steps in your business process. For example, you may wish to send text messages or emails based on some conditions. In order to do so, the recipient address, the subject and the message body needs to be passed to the corresponding service implementation which is responsible for the transmission of the message. This transmission service is out of scope of this discussion, but as every communication component, there can be errors during transmission.

In the following sections, three approaches are discussed and some code examples are provided. In doing so, I focus on a SpringBoot stack, but similar can be done in JEE or other compatible frameworks.

### The Java way

Batch processing is an old topic well implemented in most ecosystems. Java provides multiple frameworks for implementation of the aspects of batch processing. First of all, the execution of some functionality asynchronous to the main program execution is provided by the Java Concurrency framework, which is a part of the Java SDK. This is very low-level, but sometimes already sufficient to implement the required use case. In enterprise systems frameworks like JEE or Spring are used which both provides solution for running jobs in a background.

In SpringBoot, you can utilize the `spring-boot-starter-batch`, create an item processor and configure a job for execution of tasks. In our example, the item processor will call the transmission service and pass the required information to it.

The disadvantage of this approach is that you have to take care of the jobs if they fail and implement the failure-handling and recovery yourself. The same argument holds for the operation and management of jobs, their statuses and retries. Those can be pretty time-consuming and error-prone to implement.

For more details, how to implement a batch service in Spring Boot see [https://spring.io/guides/gs/batch-processing/](https://spring.io/guides/gs/batch-processing/)

Another approach is to integrate a batch processing framework, like Apache Camel. The resulting solution might get much more powerful and comprehensive, but this is a much bigger effort then. For details on that please refer to [https://www.baeldung.com/apache-camel-spring-boot](https://www.baeldung.com/apache-camel-spring-boot)

### The Camunda way

### The BPMN way

One of the naive things to do is to use the core capability of the process engine and create a BPMN process model for the execution of the batch. This process is then used as a “technical” support-process which can be called from any business process in the engine. It can be started by a message or by a call-activity, depending on the use case.

One could argue that encapsulating a simple service call into a business process just for making it executable asynchronous and fault-tolerant is to much of effort. From the operations and management point of view, the implementation as a business process advantages from the uniformity of error-handling and other standard operations which can be applied to a business process.

In our example, the process contains a service task to render the message and send notifications (see example implementation of such a process below). If the notifying process is interested in the status of the execution of the notification, a call activity can be used.

![](https://miro.medium.com/v2/resize:fit:865/1*6Hx9ku_Clu_btdYO4F6TCg.png)
Sample implementation of a notification sending BPMN 2.x process

In addition, more business requirements can be implemented in the notification process, for example, delayed notification or notification retry during a certain period of time.

The main advantage of this approach is that the batch process becomes a first-class citizen in the Camunda process engine. The process has a persistent instance, encapsulating the execution and state. It can be accessed via Camunda API or interact with other running process instances. In addition, this means that it can be handled by the standard tooling of the business process engine and is visible in the operations tool Camunda Cockpit.

### The Job Executor way

Another approach of implementing batch tasks based on Camunda process engine is utilization of the [Camunda Job Executor](https://docs.camunda.org/manual/7.9/user-guide/process-engine/the-job-executor/). This facility is a part of Camunda BPM engine and is used internally by the engine every time, some tasks needs to be executed asynchronously. The job executor can be tuned and configured using standard Camunda configuration mechanism in order setup many parameters to fulfill your requirements. In doing so, the custom jobs get executed along with Camunda jobs. Its execution is available using the Camunda API.

Apparently, the **creation of a custom job** is not a part of official Camunda API, but still can be executed from the application code. The implementation itself is a subject of a separate post.

### Summary

Batch processing functionality in a project using Camunda process engine can be implemented in several ways.

A pure Java approach seems to be very low-level and error-prone and lacks management and operation functionality. Try to avoid this… Introduction of a specific Batch Processing framework is advisable, but adds complexity to the overall solution.

Camunda provides two alternatives to those approaches. Implementation of a support process allows for handling of Batch Processing steps as first-class citizen with all full-featured functionality in management and operations. Even if a little costly from the implementation point of view, it may be worth to invest in it, especially if some business logic regarding the execution or failure compensation needs to be implemented.

Another powerful tool for implementation of Batch Processing is Camunda’s Job Executor. Even not accessible over the public API of Camunda a job can be easily created as described in this article. The downside of direct programmatic Job creation is that the management and operation steps are available over the Management and Runtime Java and REST API only. By default, there is no support for them in Camunda Cockpit, as it is the case if implementing a support BPMN process, but it can be developed as a Cockpit plugin, if needed.

### References
-  https://github.com/holunda-io/holunda-spike/tree/master/custom-job-handler
---
# Extending JUEL with custom functions in Camunda DMN engine

A few weeks ago I was trying to implement custom functions in Camunda DMN engine. I wanted to extend the expression language **Java Unified Expression Language (JUEL),** which is supported in Camunda. Here’s how I did it.

### Implementation

In this example I used Camunda in Spring Boot application [(Spring Boot Starter for Camunda](https://github.com/camunda/camunda-bpm-spring-boot-starter)).

**Core Java classes of EL engine in Camunda are:**

-   `FunctionMapper` — interface to a map between EL function names and methods. A `FunctionMapper` maps `${prefix:name()}`style functions to a static method that can execute that function ([source](https://docs.camunda.org/javadoc/camunda-bpm-platform/7.3/org/camunda/bpm/engine/impl/javax/el/FunctionMapper.html)).
-   `ExpressionManager` — central manager for all expressions. Process parsers will use this to build expression objects that are stored in the process definitions. This class is also used as an entry point for runtime evaluation of the expressions ([source](https://docs.camunda.org/javadoc/camunda-bpm-platform/7.3/org/camunda/bpm/engine/impl/el/ExpressionManager.html)).
-   `SpringExpressionManager` — ExpressionManager that exposes the full application-context or a limited set of beans in expressions ([source](https://docs.camunda.org/javadoc/camunda-bpm-platform/7.8/org/camunda/bpm/engine/spring/SpringExpressionManager.html)).

**But how can this method can be implemented in Java and called in DMN using expression language? There are two ways to do it:**

1.  **Spring beans** — they are registered as expression language extensions in `SpringExpressionManager` by default. It allows for calling methods from beans in DMN.
2.  **Function mappers** — they are registered in `ExpressionManager` manually and they map EL functions into static Java methods.

### First solution

The business logic of the custom function needs to be implemented first:

Then register Spring bean with the name `transactionService`:

Now the function can be called in DMN:

![](https://miro.medium.com/v2/resize:fit:875/1*NwzikwFwQnCqbiFSwgJcuw.png)

### Second solution

As before, business logic implementation goes first:

`ComplicanceFunctions` class is used as a domain methods aggregator:

Next step is implementation of `FunctionMapper` which maps string expression of JUEL into Java static method:

The last step is registering the function mapper in `ExpressionManager`. In this case I’m using Camunda DMN in Spring Boot application, so the basic `ExpressionManager` is `SpringExpressionManager`:


Now the function can be called in DMN:

![](https://miro.medium.com/v2/resize:fit:875/1*UpcfEfnU-V13Ifpi6MIQqQ.png)

### Summary

This idea for extending expression language can solve a lot of problems. It helps to hide complex business logic under functions and makes the logic easier to maintain. All new functions should be described in documentation so that other developers know they exist and can use them if needed.

While the proposed solution is helpful in many cases, it should be deployed with care. If a custom function uses external service to get data, e.g by API calls, there is a danger that something will break and decision evaluation will fail. Therefore it’s best to carefully test any third party integrations at regular intervals.

You can find an example of the project on [Github](https://github.com/AzimoLabs/extend-camunda-dmn-juel-with-java-functions).

### AzimoLabs/extend-camunda-dmn-juel-with-java-functions

https://github.com/AzimoLabs/extend-camunda-dmn-juel-with-java-functions

<iframe src="https://medium.com/media/b518dfbb781b0e3adce893a715c029a8" allowfullscreen="" frameborder="0" height="0" width="0" title="CamundaConfiguration.java" class="ei o hc vi bh" scrolling="no"></iframe>


```java
public class TransactionService {
    private final static Logger LOGGER = LoggerFactory.getLogger(TransactionService.class);
    public Integer getSuccessfulTransactionCount(Integer userId) {
        LOGGER.info("Get successful transaction count for user with id '{}'", userId);
        int count = 0;
        return count;
    }
}
```

[view raw](https://gist.github.com/jlegowik/4204556489b92a1345ad575457d550a1/raw/93be1fbc7582a22f5322e48b4e290f44e1c261fb/TransactionService.java) [TransactionService.java](https://gist.github.com/jlegowik/4204556489b92a1345ad575457d550a1###file-transactionservice-java) hosted with ❤ by [GitHub](https://github.com)

---
```java
@Configuration
public class RootConfiguration {

    @Bean("transactionService")
    public TransactionService transactionService() {
        return new TransactionService();
    }
}
```

[view raw](https://gist.github.com/jlegowik/d1caec875c74a52688dcf5d8b09fa70d/raw/9c73e1d253918da9894a1ecfe41231e068939eda/RootConfiguration.java) [RootConfiguration.java](https://gist.github.com/jlegowik/d1caec875c74a52688dcf5d8b09fa70d###file-rootconfiguration-java) hosted with ❤ by [GitHub](https://github.com)

---
```java
public class DocumentService {

    private final static Logger LOGGER = LoggerFactory.getLogger(DocumentService.class);

    private static DocumentService documentServiceInstance;

    public boolean userHasVerifiedAndAcceptedDocument(Integer userId, String documentType) {
        return userHasVerifiedAndAcceptedDocument(userId, DocumentType.of(documentType));
    }

    private boolean userHasVerifiedAndAcceptedDocument(Integer userId, DocumentType documentType) {
        LOGGER.info("Verify if user with id '{}' has verified and required document '{}'", userId, documentType.name());

        boolean userHasVerifiedAndAcceptedDocument = false;
        return userHasVerifiedAndAcceptedDocument;
    }

    public static DocumentService get() {

        if (documentServiceInstance == null) {
            documentServiceInstance = new DocumentService();
        }
        return documentServiceInstance;
    }
}
```
[view raw](https://gist.github.com/jlegowik/384306010b02557cbc10f38692e2cf3c/raw/79207b9f171a1da024fdc4ac093ca6285aa46edc/DocumentService.java) [DocumentService.java](https://gist.github.com/jlegowik/384306010b02557cbc10f38692e2cf3c###file-documentservice-java) hosted with ❤ by [GitHub](https://github.com)

---
```java
public class ComplianceFunctions {

    private static final DocumentService documentService;

    static {
        documentService = DocumentService.get();
    }

    public static boolean userHasVerifiedAndAcceptedDocument(Integer userId, String documentType) {
        return documentService.userHasVerifiedAndAcceptedDocument(userId, documentType);
    }
}
```
[view raw](https://gist.github.com/jlegowik/f2a42a3f34cff9b3f09a208bf40752e4/raw/6d8bafe471337d927d17f2487d44aefc0ffae850/ComplianceFunctions.java) [ComplianceFunctions.java](https://gist.github.com/jlegowik/f2a42a3f34cff9b3f09a208bf40752e4###file-compliancefunctions-java) hosted with ❤ by [GitHub](https://github.com)

---
```java
public class ComplianceFunctionsMapper extends FunctionMapper {

    private final static String PREFIX = "compliance";

    private static Map<String, Method> functionCache = null;

    public Method resolveFunction(String prefix, String localName) {
        ensureFunctionMapInitialized();
        return functionCache.get(getFullFunctionName(prefix, localName));
    }

    private String getFullFunctionName(String prefix, String localName) {
        return prefix + ":" + localName;
    }

    private void ensureFunctionMapInitialized() {
        if (functionCache == null) {
            synchronized (ComplianceFunctionsMapper.class) {
                if (functionCache == null) {
                    functionCache = new HashMap<>();

                createMethodBindings();
                }
            }
        }
    }

    private void createMethodBindings() {
        try {
            functionCache.put(
                getFullFunctionName(PREFIX, "userHasVerifiedAndAcceptedDocument"),
                ComplianceFunctions.class.getMethod("userHasVerifiedAndAcceptedDocument", Integer.class, String.class)
            );

        } catch (Exception ex) {
            throw new FunctionRegistrationFailedException(ex);
        }
    }
}
```
[view raw](https://gist.github.com/jlegowik/9011b1bbdbdb66ad46e1cef2baf42497/raw/7aa97dfb8435a27ab60dc48513b218ab7c88f0b1/ComplianceFunctionsMapper.java) [ComplianceFunctionsMapper.java](https://gist.github.com/jlegowik/9011b1bbdbdb66ad46e1cef2baf42497###file-compliancefunctionsmapper-java) hosted with ❤ by [GitHub](https://github.com)

---
```java
@Configuration
public class CamundaConfiguration {

    private ApplicationContext appContext;

    public CamundaConfiguration(ApplicationContext appContext) {
        this.appContext = appContext;
    }

    @Bean
    public ProcessEngineConfigurationImpl processEngineConfigurationImpl(List<ProcessEnginePlugin> processEnginePlugins) {
        SpringProcessEngineConfiguration configuration = CamundaSpringBootUtil.springProcessEngineConfiguration();
        configuration.getProcessEnginePlugins().add(new CompositeProcessEnginePlugin(processEnginePlugins));
        SpringExpressionManager expressionManager = new SpringExpressionManager(appContext, configuration.getBeans());
        //register compliance functions mapper
        expressionManager.addFunctionMapper(new ComplianceFunctionsMapper());
        configuration.setExpressionManager(expressionManager);
        return configuration;
    }
}
```
[view raw](https://gist.github.com/jlegowik/5abc29e872ed389883a773a31b0a6b6c/raw/6262ffd5e51a450e344f1b613eee8b30eff959b3/CamundaConfiguration.java) [CamundaConfiguration.java](https://gist.github.com/jlegowik/5abc29e872ed389883a773a31b0a6b6c###file-camundaconfiguration-java) hosted with ❤ by [GitHub](https://github.com)


---
# Implementing the Loan Broker with Camunda 7 

### Intro

**Camunda Platform** is a lightweight, open-source platform for Business Process Management and automation. It can perform orchestrations and also has a UI BPMN modeler.

It has been on my to-do list for quite some time to check and experiment.

Let’s put it to the test on how it can handle an integration/orchestration problem. Yet, we don’t want to create a Java application; We could do this without Camunda. So we will set the following c**onstraints:**

-   No Java code for integration
-   Use expressions and scripting
-   We should be able to export the BPMN model and run it on any other Camunda or BPMN runtime.
-   We will use Camunda 7

The Loan Broker is an excellent use case for our exercise. It can show how to compose routing and transformation patterns into a more comprehensive solution—used [by Gregor Hohpe](https://www.enterpriseintegrationpatterns.com/patterns/messaging/ComposedMessagingExample.htm) in Enterprise Integration Patterns bestseller. Another interesting read is its [implementation with AWS Step Functions.](https://www.enterpriseintegrationpatterns.com/ramblings/loanbroker_stepfunctions.html)

![](https://miro.medium.com/v2/resize:fit:491/0*qKkdS_tCPmbuYDcb.gif)
The Loan Broker

1.  Receive the consumer’s loan quote request
2.  Get a credit score and history from a credit agency
3.  Determine the most appropriate banks to contact
4.  Send a request to each selected bank
5.  Collect responses from each selected bank
6.  Determine the best response
7.  Pass the result back to the consumer

We will create a BPMN obtaining the list of Banks through an external service and implementing the **Recipient List** pattern. Then we will test Camunda’s dynamic capabilities

-   **split**
-   retrieve the quotes from the banks with **parallel execution**
-   **aggregate** the results.

### Setup

There are many ways to run Camunda. We are going to use Spring Boot. Although this is no longer the [recommended way to run Camunda](https://blog.bernd-ruecker.com/moving-from-embedded-to-remote-workflow-engines-8472992cc371), it can help start our use case immediately.

Both the Credit Bureau and the Banks are external services our workflow needs to reach. Yet, we will implement them as different **RestControllers** to save us some effort.

Following the Getting Started guide for [Spring Boot](https://docs.camunda.org/get-started/spring-boot), I have added the Camunda Spring Boot Starter dependency. The Camunda Runtime is ready for a spin.

Camunda Spring Boot dependencies for Rest Engine, Cockpit & HTTP Connector

### The Credit Bureau

First, let’s create the service with a simple RestController.


Get Credit Score

The CreditBureauController will return a random credit Score, and the response should be like the following:

{"taxNumber": 131830309,"creditScore": 161,"history": 2}

Our flow will immediately go to The Credit Bureau, so we are going to create the first activity in our BPMN as a Service Task

![](https://miro.medium.com/v2/resize:fit:410/1*XtcLVQXeaW6Q9Ke69UeJ0g.png)
Get Credit Score Activity

The input to our workflow is the following the original Loan Broker use case:

-   Tax Number: Identifier of the loan requestor
-   Amount: The amount requested
-   Term: The payment period

The Service Task needs to request our Get Credit Score Controller to retrieve the credit score. As we have stated at the start, we don’t use Delegates and Java. The [Camunda Connect](https://github.com/camunda/camunda-connect) library and an [HTTP Connector](https://docs.camunda.org/manual/latest/reference/connect/http-connector/) can help us implement this in the BPMN. Let’s set it up below:

![](https://miro.medium.com/v2/resize:fit:765/1*jM1rasdfwMnXjfmAwrHVcg.png)
Get Credit Score HTTP Connector

Ok, here come some opinions. I found it annoying to write Javascript code of more than 1 line in the Modeler UI. I was even more annoyed when working with String literals, like constructing a JSON.

For that reason, we have made a small compromise and externalized some scripts to js files. We must extend our _plug and play_ principle to include the **BPMN and its extra script resources.**

Submit Credit Score Request

The connector retrieves input from the process instance (execution). Then it transforms it s into a stringified JSON and provides it as output.

Parse Credit Score Response

On the response handling, we did a small trick. The connector does not have any logic based on the result by default. A 4XX is another response that the workflow needs to handle. Yet, for our use case, it is a blocker. Implementing the error handling in the script isn’t nice, but it does the trick.

https://github.com/camunda/camunda-spin 

is the data formatting tool for Camunda 7, and S() is the primary method to handle JSON and XML. As we only want to use scripts, it is one way to handle the payloads from the responses.

Ok, time to test our first draft of the process. We can do this through an HTTP request to the Camunda Rest Engine. An API call can trigger any deployed process if the engine is active.

**Request**

curl --location --request POST 'http://localhost:8080/engine-rest/process-definition/key/loan_broker/start' --header 'Content-Type: application/json' --data-raw '{"variables": {"taxNumber": {"value": 131830309,"type": "integer"},"amount": {"value": 50000,"type": "integer"},"term": {"value": 30,"type": "integer"}}}'

**Response**

{"links": [{"method": "GET","href": "http://localhost:8080/engine-rest/process-instance/83954128-d566-11ec-985f-d4d2524a91a7","rel": "self"}],"id": "83954128-d566-11ec-985f-d4d2524a91a7","definitionId": "loan_broker:1:b2ffd807-d564-11ec-985f-d4d2524a91a7","businessKey": null,"caseInstanceId": null,"ended": true,"suspended": false,"tenantId": null}

Although the process is synchronous, it does not return the outcome, in our case, the variables. We need to use the history service and fetch the variables associated with the given process instance id to achieve this.

**Request**

curl --location --request GET 'http://localhost:8080/engine-rest/history/variable-instance?processInstanceId=83eb9e93-d566-11ec-985f-d4d2524a91a7' --header 'Accept: application/json

**Response**

...  
{"type":"Integer","value":503,"valueInfo":{},"id":"83eb9e93-d566-11ec-985f-d4d2524a91a7","name":"creditScore","processDefinitionKey":"loan_broker","processDefinitionId":"loan_broker:1:b2ffd807-d564-11ec-985f-d4d2524a91a7","processInstanceId":"83954128-d566-11ec-985f-d4d2524a91a7","executionId":"83954128-d566-11ec-985f-d4d2524a91a7","activityInstanceId":"83954128-d566-11ec-985f-d4d2524a91a7","caseDefinitionKey":null,"caseDefinitionId":null,"caseInstanceId":null,"caseExecutionId":null,"taskId":null,"errorMessage":null,"tenantId":null,"state":"CREATED","createTime":"2022-05-17T01:21:21.828+0300","removalTime":null,"rootProcessInstanceId":"83954128-d566-11ec-985f-d4d2524a91a7"}  
...

### The Bank Recipient List

Now that we have created the first part of our flow, let's go to the juicy part. First, we will need to define a set of Banks and feed it to the workflow.

I would not like to waste any time on either, as long as we don’t hard-code them in the workflow. The BPMN needs to be dynamic. An old friend, the _Enum with values,_ can be handy to store the information in memory.

Available Banks Enum

Now that we have our Banks, we need to expose them with a similar RestController:

Get Available Banks

The response should be the following:

  
[{"maxLoanAmount": 70000,"minCreditScore": 500,"bankId": UNIVERSAL","baseRate": 4},  
{"maxLoanAmount": 50000,"minCreditScore":400,"bankId": "PAWNSHOP","baseRate": 5},  
{"maxLoanAmount": 900000,"minCreditScore": 600,"bankId": "PREMIUM","baseRate": 3}]

We need to create a service for each bank that will take the credit score and return a quote for a loan (if any). Let’s also implement this. The bank id will be a path param in our endpoint for simplicity. According to this param, the controller will make the equivalent calculation for each bank.

Get Quote from Bank

The response for Universal bank

{"rate":5.450147899000825,"bankId":"UNIVERSAL"}

Ok, enough with Java; we should now have all the pieces our BPMN will use to fulfill its purpose.

To create the actual recipient list workflow, we need to:

1.  Retrieve the list of Banks
2.  Create a task

The first one is pretty straightforward and, like the previous task.

![](https://miro.medium.com/v2/resize:fit:670/1*5c4Ez3naEoKZGpHj49Xyiw.png)
Get Bank List Activity

![](https://miro.medium.com/v2/resize:fit:791/1*StS-Hr0DVWzacgu-ZjCRJg.png)
Get Bank List HTTP Connector

Parse Bank List Response

The list of banks is in an array of strings, and we need to create a service task for each element, feeding the value to an HTTP request.

Camunda provides the Multi-Instance Service task for such purposes, in parallel or sequential. In our case, of course, it will be parallel.

![](https://miro.medium.com/v2/resize:fit:875/1*l6LJW4Hd26TRIBhTQ40dfw.png)
Get Quotes from Banks

Setting up the multi-instance service task:

![](https://miro.medium.com/v2/resize:fit:789/1*GoAk9uny2iOdNpozGm0bHQ.png)
Multi-Instance Service task

Following the documentation, we have filled the _Collection_ option, which is the list the service task will iterate. The value will be the bankList JSON array retrieved from the previous Activity.

The HTTP connector does not accept the Spin JSON Array, but the input must be a **Java Collection.** However, there was no mention of this in the modeler or the Camunda documentation. By trial and error, I used Spin's [elements()](https://javadoc.io/doc/org.camunda.spin/camunda-spin-core/1.5.6/org/camunda/spin/json/SpinJsonNode.html###elements()) method. Subsequently, the Element Variable we have sent as “bank” will hold a _SpinJsonNode_ with each item of the response payload.

![](https://miro.medium.com/v2/resize:fit:774/1*LGsHH_xvd-2OPZ6JlnAyyA.png)
Get Quote from Bank

Similarly, with other requests, we will use JavaScript files to submit the request and parse the response. Notice how the element variable “bank is feeding the bank Id.”

<iframe src="https://medium.com/media/f74c795bb6988ee75bf6873ad658ac96" allowfullscreen="" frameborder="0" height="0" width="0" title="submit quote request" class="ei o fd ub bh" scrolling="no"></iframe>

Submit Quote Request

Let’s gather the responses and agree… WHAT???

![](https://miro.medium.com/v2/resize:fit:794/1*-gMVsppsHT_zqBZ_ohspRA.png)
Multi-instance mapping I/O in Camunda 7

Camunda 7 cannot differentiate the output of each iteration of the multi-instance. Although this is a bummer, and [fortunately, it is one of the things fixed in Camunda 8](https://docs.camunda.io/docs/components/modeler/bpmn/multi-instance/), we can implement a workaround. We can set a different variable when parsing the response based on the _element_ value.

Parse Bank Quote

We will set a different variable on each loop with the bankId of the bank holding the array. A bit hacky, but it will do the trick.

Afterward, Camunda can quickly gather the results and pick the best option.

### Conclusion

_Disclaimer:_ This article is my first impression of the engine, and by no means should the content be considered best practices. I am learning Camunda and would love feedback from other new or experienced users.

-   Excellent Modelling capabilities and state monitoring through the UI
-   Relatively fast setup
-   BPMN2 requires some proper studying. Another certification to get.
-   We implemented the use case with accuracy.
-   Integration with HTTP Connector and SPIN data formating is messy.
-   Writing code in the Modeler or external scripts is challenging to test.
-   Spin documentation is short.
-   Javascript and working with strings, backslashes, and other special characters is a nightmare. Camunda uses Nashorn and _engine.eval(),_ which the script as string input. String inception.
-   The main principle that the BPMN can be plug and play seems to fall short under the weight of development difficulty. Maybe Groovy is the answer to make it work.

Complete Source Code available @ [https://github.com/Gorosc/camunda_loan_broker](https://github.com/Gorosc/camunda_loan_broker)


```xml
<!-- Camunda BPMN -->

<!--REST ENGINE-->
<dependency>
    <groupId>org.camunda.bpm.springboot</groupId>
    <artifactId>camunda-bpm-spring-boot-starter-rest</artifactId>
    <version>${camunda.spring-boot.version}</version>
</dependency>

<!--Cockpit-->
<dependency>
    <groupId>org.camunda.bpm.springboot</groupId>
    <artifactId>camunda-bpm-spring-boot-starter-webapp</artifactId>
    <version>${camunda.spring-boot.version}</version>
</dependency>

<!-- HTTP Connector -->
<dependency>
    <groupId>org.camunda.bpm</groupId>
    <artifactId>camunda-engine-plugin-connect</artifactId>
    <version>${camunda.spring-boot.version}</version>
</dependency>

<dependency>
    <groupId>org.camunda.connect</groupId>
    <artifactId>camunda-connect-http-client</artifactId>
    <version>${camunda-connect-http-client.version}</version>
</dependency>

<dependency>
    <groupId>org.camunda.bpm</groupId>
    <artifactId>camunda-engine-plugin-spin</artifactId>
    <version>${camunda.spring-boot.version}</version>
</dependency>
```
[view raw](https://gist.github.com/christosgkoros/320766ac41e3cdf5247a3082b27f0690/raw/2724df883a0985bae0502a95e57c3293931b1814/pom.xml) [pom.xml](https://gist.github.com/christosgkoros/320766ac41e3cdf5247a3082b27f0690###file-pom-xml) hosted with ❤ by [GitHub](https://github.com)

<iframe height="1" width="1" style="position: absolute; top: 0px; left: 0px; border: none; visibility: hidden;"></iframe>

---
```java
@PostMapping("/credit")
public CreditScore getCreditScore(@RequestBody CreditScoreRequest creditScoreRequest) throws NoSuchAlgorithmException {
    int min = 100;
    int max = 900;
    Random r = SecureRandom.getInstanceStrong();
    return new CreditScore(
        creditScoreRequest.getTaxNumber(),
        r.nextInt(max - min) + min,
        r.nextInt(9) + 1
    );
}
```

[view raw](https://gist.github.com/christosgkoros/059c75f62e937ce504b317dcd6c8c956/raw/289002b16c3d52f1531d51f0239acba571859d3b/CreditBureauController.java) [CreditBureauController.java](https://gist.github.com/christosgkoros/059c75f62e937ce504b317dcd6c8c956###file-creditbureaucontroller-java) hosted with ❤ by [GitHub](https://github.com)

<iframe height="1" width="1" style="position: absolute; top: 0px; left: 0px; border: none; visibility: hidden;"></iframe>

---
```java
var taxNumber = execution.getVariable("taxNumber");
var amount = execution.getVariable("amount");
var term = execution.getVariable("term");
'{"taxNumber":' + taxNumber + ',"amount":' + amount + ',"term":' + term + '}';
```

[view raw](https://gist.github.com/christosgkoros/696aea4f45f38154a65a46ec458f383e/raw/f7312a3815af4b294eb5939b165f4e9fd074b81f/submitCreditScore.js) [submitCreditScore.js](https://gist.github.com/christosgkoros/696aea4f45f38154a65a46ec458f383e###file-submitcreditscore-js) hosted with ❤ by [GitHub](https://github.com)

---
```java
var response = connector.getVariable("response");
var status = connector.getVariable("statusCode");
if (status < 200 || status > 299) {
    throw new org.camunda.bpm.engine.delegate.BpmnError("Credit Score Request Failed");
}

S(response).prop("creditScore").value();
```
[view raw](https://gist.github.com/christosgkoros/3949dd47e9e36ae6f392f7b62759c11d/raw/cd112a2d3db666c060cf9b1660741ce0d0af9cda/parseCreditScore.js) [parseCreditScore.js](https://gist.github.com/christosgkoros/3949dd47e9e36ae6f392f7b62759c11d###file-parsecreditscore-js) hosted with ❤ by [GitHub](https://github.com)

---

```java
public enum AvailableBanks {

    UNIVERSAL( new Bank(70000, 500, "UNIVERSAL", 4)),
    PAWNSHOP(new Bank(50000, 400, "PAWNSHOP", 5)),
    PREMIUM(new Bank(900000, 600, "PREMIUM", 3));
    Bank bank;

    AvailableBanks(Bank bank) {
        this.bank = bank;
    }

    Bank getBank() {
        return bank;
    }
}
```
[view raw](https://gist.github.com/christosgkoros/384af00cda2d8038434580d102934bbf/raw/0f67649adff7d8f542340f6b5376cd66fab681b7/AvailableBanks.java) [AvailableBanks.java](https://gist.github.com/christosgkoros/384af00cda2d8038434580d102934bbf###file-availablebanks-java) hosted with ❤ by [GitHub](https://github.com)

---
```java
@GetMapping("/bank")
public List<Bank> getBanks() {
    return Arrays.stream(AvailableBanks.values()).map(AvailableBanks::getBank).collect(java.util.stream.Collectors.toList());
}
```
[view raw](https://gist.github.com/christosgkoros/1869a16524a36bf3ae2e85eb4d4fd741/raw/710c4cc8881204bd46e30f9aa472fd79e00ad43b/BankController.java) [BankController.java](https://gist.github.com/christosgkoros/1869a16524a36bf3ae2e85eb4d4fd741###file-bankcontroller-java) hosted with ❤ by [GitHub](https://github.com)

---

```java
@PostMapping("/bank/quote/{bank}")
public Quote getQuote(@RequestBody QuoteRequest quoteRequest, @PathVariable AvailableBanks bank) {
    double rate = calcRate(bank, quoteRequest.getAmount(), quoteRequest.getCreditScore());
    return new Quote(bank.getBank().getBankId(), rate);
}

private double calcRate(AvailableBanks bank, int amount,int score) {
    if (amount <= bank.getBank().getMaxLoanAmount() && score >= bank.getBank().getMinCreditScore()) {
        return bank.getBank().getBaseRate() + Math.random() * ((1000 - score) / 100.0);
    } else 
        return -1.0; //Negative rate indicates that the loan cannot be approved
}
```

[view raw](https://gist.github.com/christosgkoros/b36bd7acb96fbe4f25415d68e295f0d5/raw/b56784eaddc04e91a8a97e36259a2473f6d6a2d7/BankController.java) [BankController.java](https://gist.github.com/christosgkoros/b36bd7acb96fbe4f25415d68e295f0d5###file-bankcontroller-java) hosted with ❤ by [GitHub](https://github.com)

---
```java
var response = connector.getVariable("response");
var status = connector.getVariable("statusCode");
if (status < 200 || status > 299) {
    throw new org.camunda.bpm.engine.delegate.BpmnError("Bank List Request Failed");
}
S(response);
```
[view raw](https://gist.github.com/christosgkoros/4f93d29c7c87e272610edb20657a66e3/raw/da6fd2e7450714f7425ba9e75db8cffad174cc3a/parseBankList.js) [parseBankList.js](https://gist.github.com/christosgkoros/4f93d29c7c87e272610edb20657a66e3###file-parsebanklist-js) hosted with ❤ by [GitHub](https://github.com)

---

---
```java
var response = connector.getVariable("response");
var status = connector.getVariable("statusCode");
var bank = connector.getVariable("bank");
var bankId = bank.prop("bankId").value()

if (status < 200 || status > 299) {
    throw new org.camunda.bpm.engine.delegate.BpmnError("Bank " + bankId + " Request Failed");
}

var rate = S(response).prop("rate").value();
connector.setVariable(S('{"rate":' + rate + '}'));
```
rate;

[view raw](https://gist.github.com/christosgkoros/9f67de83febe3d60f5a5d01ed38a5e31/raw/dfff12693ef2142a31469b74888a3f8e609cb8a4/parseQuote.js) [parseQuote.js](https://gist.github.com/christosgkoros/9f67de83febe3d60f5a5d01ed38a5e31###file-parsequote-js) hosted with ❤ by [GitHub](https://github.com)



