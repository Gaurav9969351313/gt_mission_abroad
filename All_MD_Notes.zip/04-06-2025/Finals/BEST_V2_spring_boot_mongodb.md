# 🧠 MongoDB Basics Explained with Real-Life Analogies

### 📦 What is MongoDB?

MongoDB is a **NoSQL** database that stores data in **JSON-like documents**. Unlike traditional relational databases that use rows and tables, MongoDB uses **collections and documents**.

Unlike traditional relational databases that use tables and rows, MongoDB uses collections and documents. This approach allows for variable structures among documents within the same collection, making it ideal for applications with evolving data requirements.

### Key Features

-   **Document-Oriented**: Stores data in flexible, JSON-like BSON (Binary JSON) documents
-   **Schema-less**: No predefined schema required; fields can vary from document to document
-   **Horizontal Scalability**: Designed to scale out using sharding (distributing data across multiple machines)
-   **High Performance**: Supports indexing, replication, and aggregation pipelines
-   **Rich Query Language**: Comprehensive query capabilities for complex data retrieval

### Common Aggregation Stages

-   **$match**: Filters documents (similar to find)
-   **$group**: Groups documents by a specified expression
-   **$project**: Reshapes documents (includes, excludes, or transforms fields)
-   **$sort**: Sorts documents
-   **$limit**: Limits the number of documents
-   **$skip**: Skips a specified number of documents
-   **$unwind**: Deconstructs an array field to create a document for each element
-   **$lookup**: Performs a left outer join with another collection

### Data Modeling in MongoDB

Since MongoDB is schema-less, data modeling is more flexible but requires careful consideration to ensure optimal performance and maintainability.

### Embedding vs. Referencing

MongoDB offers two main approaches to modeling relationships:

###### Embedding (Denormalization)

Embedding involves storing related data within a single document:

### When to Embed vs. Reference

**Embed when:**

-   One-to-few relationships exist
-   The embedded data is small and doesn’t change frequently
-   The embedded data is always accessed together with the parent document

**Reference when:**

-   One-to-many or many-to-many relationships exist
-   The referenced data is large
-   The referenced data changes frequently
-   The referenced data needs to be accessed independently

### 🏠 Real-Life Analogy: MongoDB as a Digital Locker System

Imagine a **digital locker room**:

-   The **locker room** is the **database**
-   Each **locker** is a **collection**
-   Inside each locker, you store **documents** (like files, photos, notes)
-   Each document is **self-contained**, has its own format, and stores all related data together

In contrast, relational databases would need you to store your name in one file, your address in another, and link them via IDs (like a library system).

### MongoDB as a Recipe Organizer

**Analogy:**

-   **Recipe Box** → Represents the **MongoDB Database**.
-   **Recipe Categories (e.g., Desserts, Main Courses)** → Represent **Collections**.
-   **Individual Recipe Cards** → Represent **Documents**.

**Explanation:**

Imagine you have a recipe box where you store various recipes categorized by type. In this scenario:

-   The **database** is the recipe box containing all your recipes.
-   Each **collection** is a category divider (like “Desserts” or “Main Courses”) organizing the recipes.
-   Each **document** is an individual recipe card detailing ingredients and instructions.

This setup allows you to easily add new recipes without adhering to a strict format, reflecting MongoDB’s flexible schema design.

### MongoDB as a Digital Photo Album

**Analogy:**

-   **Photo Album App** → Represents the **MongoDB Database**.
-   **Photo Albums within the App** → Represent **Collections**.
-   **Individual Photos** → Represent **Documents**.

**Explanation:**

Consider a digital photo album application where you organize your photos into different albums:

-   The **database** is the entire photo album application.
-   Each **collection** is a specific album (like “Vacation 2025” or “Family Events”).
-   Each **document** is an individual photo with metadata like date, location, and tags.

This structure allows you to store diverse information for each photo, such as varying metadata fields, without a predefined schema, showcasing MongoDB’s flexibility.

### MongoDB as a Notebook Collection

Imagine a student with multiple **notebooks**:

-   All notebooks together form the **database**
-   Each individual **notebook** is a **collection** (Math, Science, History)
-   **Pages** in the notebooks are **documents**
-   On each page, you can write anything — diagrams, text, equations (**flexible schema**)
-   You can quickly add a new page or a whole new notebook when needed (**scalability**)

SQL databases would be like standardized forms where every page must follow the same strict template.

![](https://miro.medium.com/v2/resize:fit:875/1*0XSQJftEo3dc50jJHJjA.png)

### 🧱 MongoDB Core Concepts

### 1. Database

A container for collections (just like a database in SQL).  
🧠 Think of it as a folder containing many lockers.

### 2. Collection

A group of MongoDB documents.  
🧠 Like a locker containing similar types of files.

### 3. Document

The basic unit of data in MongoDB, stored in **BSON** (Binary JSON) format.  
🧠 Like a Word file that holds a resume with name, skills, and experience in one place.

![](https://miro.medium.com/v2/resize:fit:829/1*Ol9svNOxxmQ5S0MjNJ43w.png)

### 📊 Why MongoDB?

-   **Flexible Schema**: Add fields anytime, no strict schema.
-   **Scalable**: Handles large volumes of data easily.
-   **Faster Development**: JSON-like documents match frontend structure.
-   **Great for Real-Time Apps**: Ideal for chat apps, IoT, e-commerce, etc.

### 💡 When to Use MongoDB?

✅ Use MongoDB when:

-   You have **rapidly changing schemas**
-   You need to store **nested or hierarchical data**
-   You’re building **real-time apps** (e.g., chat, live tracking)

❌ Avoid if:

-   You heavily rely on **multi-table JOINs**
-   Your data model is strictly relational and consistent

### 🛠 Real Project Use Case: Online Food Ordering App

-   📦 **Collections**: `users`, `restaurants`, `orders`, `dishes`
-   📄 A document in `orders` may look like:

![](https://miro.medium.com/v2/resize:fit:738/1*szMSbBSAMVjdGkdHoZ7uA.png)

Notice how everything related to the order is in **one document**. That’s MongoDB’s beauty!

### Performance Optimization Tips

1.  **Use appropriate indexes** based on your query patterns
2.  **Limit the size of your documents** to reduce memory usage
3.  **Use projection** to return only the fields you need
4.  **Consider compound indexes** for queries with multiple filter conditions
5.  **Avoid using skip() for large offsets** in pagination
6.  **Use covered queries** where possible (queries that can be satisfied entirely by indexes)
7.  **Monitor and analyze query performance** using `explain()`
8.  **Consider data sharding** for horizontal scaling

### MongoDB in Production

### Replication

Replication provides high availability and data redundancy:

![](https://miro.medium.com/v2/resize:fit:770/1*GG3RGNJW9NVQg2P61v5XQ.png)

### Sharding

Sharding distributes data across multiple machines for horizontal scaling:

![](https://miro.medium.com/v2/resize:fit:750/1*6HLrC8PJHy5ZFGVDfLLFA.png)

### Backup and Restore

Regular backups are essential for data protection:

![](https://miro.medium.com/v2/resize:fit:716/1*F6F408KlunCoUhw-BIaVUQ.png)

### Conclusion

MongoDB’s flexible document model, powerful query capabilities, and scalable architecture make it an excellent choice for modern applications. Whether you’re building a small prototype or a large-scale distributed system, MongoDB provides the tools and features to meet your data storage and retrieval needs.

As you continue your MongoDB journey, explore the official documentation, community forums, and online courses to deepen your understanding of this powerful database system. Remember that the best data model and database configuration will depend on your specific application requirements, so always consider your use case when making design decisions.

---

# Fun Mongo 1: ObjectId. How Primary Key works

After working with relational SQL databases for a long time, switching to the document base MongoDB is not as easy as it seems.

You have to rebuild your mentality. It’s like with PHP or Python and Node.js programming languages. Switching to Node.js won’t be easy at first. You’ll have to get used to asynchronous code. A lot of code requires calback functions.

It’s the same with MongoDB. For example, you have to get used to the idea that there’s always a primary key and it’s different from an auto increment as a number like Int or Unsigned Int.

Mongodb has unusual IDs. This is not autoincrement as in other databases. Moreover, Mongodb has no autoincrement of int type at all, and you have to implement it yourself if you need it.

Let’s start with ObjectId. It seems to be a hash and how to do lookups:
```sql
SELECT * FROM t WHERE id > 1234
```
In fact, in MongoDB you can also build queries by id (id — autoincrement in Mongo)
```js
db.t.find({ id: { $gt: ObjectId('5e1b270142dcae0010186f02') } })
```
And you can also sort by this field.

Not everyone knows, but it’s not just a hash, it’s a function of time, and the hash can be cast to DateTime. And it’s done quite simply (example in JS):

**function** 
```js
objectIdToDateTime(objectId) {  
    return new Date(parseInt(objectId.substring(0,8),16)*1e3)  
}
objectIdToDateTime('5e1b270142dcae0010186f02')  
// Sun Jan 12 2020 17:02:41 GMT+0300
```
But you don’t need to write your own function, mongodb already has a built-in function
```js
ObjectId("5e1b270142dcae0010186f02").getTimestamp()  
// ISODate("2020-01-12T17:02:41.000+03:00")
```
If you want to generate an ObjectId, you have to do the reverse conversion:
```js
const generateObjectId =>  
              **Math**.floor((**new** Date).getTime()/1e3)  
                        .**toString**(16) + '0'.**repeat**(16)
```
Here we generate the first part of the hash, but the end of the hash consists of zeros. The original ObjectId in the second part contains some random hash. We can use the algorithm to generate the UID:
```js
**const** generateObjectId = ()=>  
         **Math**.floor((**new** Date).getTime()/1e3).**toString**(16) +  
         ('x'.**repeat**(16).replace(  
               /x/g,  
               =>(**Math**.random()*16|0).**toString**(16)  
         ))
```
[Обсуждение](https://t.me/hackdevclub)
---
# Explaining Aggregation Pipelines. The MongoDB find() 

The MongoDB `find()` command is versatile and easy to use, but the aggregation framework allows you to take it to the next level. Aggregation pipelines can do anything a `find()` operation can do and much, much more.

Aggregation pipelines also allow you to simplify your application code by reducing logic that might otherwise require multiple find operations and complex data manipulation. When leveraged correctly, a single aggregation can replace many queries and their associated network round trip times.

However, with all the added benefits that using aggregations brings, it also creates a new set of tuning challenges. The most important thing when tuning aggregation pipelines is to know how to interpret Aggregation `explain()` output.

### Tuning aggregation pipelines

If you are not familiar with using explain() with simple `find()` queries, see [this post](/mongodb-performance-tuning/getting-started-with-mongodb-explain-8a3d0c6c7e68) or check out the [MongoDB documentation](https://docs.mongodb.com/manual/reference/command/explain/).

To use explain, we add the `.explain()` method after the collection name:

The `explain()` output for an aggregation pipeline a bit different from that generated for a `find()`. Firstly, aggregation explain output is organized as a series of `stages`. The stages array contains each of the aggregation stages as individual objects. For example, here’s simplified output from the above explain():

The `stages` array contains each step of the aggregation. `$cursor` is a special step that contains the initial `find()` operation that feeds into each subsequent stage. It has an execution plan similar to that for a normal `explain()`.

We can feed the ‘`executionStats`’ argument to explain() which then executes the statement and collects timings and other super-helpful statistics. Let’s grab the output of executionStats into an object we can play with. This aggregation is part of some experiments I’m doing with time-series collections and Window functions:

The explainOut object has a lot of data and can be quite confronting. But if we simply want to get each stage and an idea of how long it took to execute, we can use this simple function — stageTimes — to print an estimate of the time spent in each stage.

Note carefully that the times ascribed to each stage appear to be estimates — hence the name `executionTimeMillisEstimate`. In at least some cases, we’ve seen these timings to be a bit dubious. In particular, the time for each subsequent stage appears to include the timings for the previous stage — you are looking at cumulative execution times, so the function subtracts the previous cumulative time to reveal the delta for each step.

For our MongoDB tuning book, we wrote a helper function that can give you even more insight. You can get our tuning scripts at [https://github.com/gharriso/MongoDBPerformanceTuningBook](https://github.com/gharriso/MongoDBPerformanceTuningBook).

The `aggregationExecutionStats` function from our tuning script, prints what we think is a handy summary of the execution steps in the aggregation pipeline. It shows each stage as well as the sub-steps within the cursor step; this is where you can see (for instance) if you’ve used an index or a collection scan to drive your aggregation:

What we see here, is that the initial $CURSOR stage used an index to retrieve documents — taking about 4.5 seconds. The $GROUP stage added another 1.2 seconds. The sort added no time to the overall execution.

There’s more detail in the `explain()` output that you can leverage — the amount of memory required for each stage and the presence of a disk sort for instance. This will come in handy in the next blog post when we’ll look in-depth at some complex aggregations.

Aggregation functions are incredibly powerful, but knowing how to tune them is essential. Our book [MongoDB Performance Tuning](https://www.amazon.com/MongoDB-Performance-Tuning-Optimizing-Applications/dp/1484268784) has some tips and tricks that you might be able to leverage to make the most of your Aggregation functions — see chapter 7 in particular.

Guy Harrison and Michael Harrison are authors of [MongoDB Performance Tuning](https://www.amazon.com/MongoDB-Performance-Tuning-Optimizing-Applications/dp/1484268784) (Apress, 2021). They both work at [ProvenDB](http://provendb.com/) which, amongst other things, brings the immutability and trust of public Blockchains to the power and productivity of MongoDB.


```js
db.customers.explain().aggregate([
    { $match: {
        Country: 'Japan',
        LastName: 'Smith',
    } },
    { $project: {
        id: 0,
        FirstName: 1,
        LastName: 1,
    } },
    { 
        $sort: {
        FirstName: -1,
    } },
    { $limit: 3 } 
]);
```

```js
var explainOut=db.iotNoTimeSeries.explain('executionStats').aggregate([
    { $match:{ "deviceData":{ $gt:5 } } } ,
    { $group:{ id:{ "deviceData":"$deviceData" },
        "measureMent-avg":{$avg:"$measureMent"}
    } },
    { $sort:{ "measureMent-avg":-1 }},
    ]);
```
[view raw](https://gist.github.com/gharriso/7714245ad65f4843cb334a7cdd10b8c5/raw/91075334c70c4738bab52197fd01ef27ac12cf0d/explainOut.js) [explainOut.js](https://gist.github.com/gharriso/7714245ad65f4843cb334a7cdd10b8c5###file-explainout-js) hosted with ❤ by [GitHub](https://github.com)

---
```js
mongo> function stageTimes(explan) {

        var prevMS=0;
        explan.stages.forEach(stg => {
        print(Object.keys(stg)[0], stg.executionTimeMillisEstimate + 0-prevMS);
        prevMS=stg.executionTimeMillisEstimate;
    });
}
```
```js
mongol> stageTimes(explainOut);
$cursor 3505
$group 1224
$sort 0
```

[view raw](https://gist.github.com/gharriso/b652961b3431fee8d5ba4786f671942d/raw/b4605978e78f94cfd8508643d1cc38ef376b23b8/mongoOut.js) [mongoOut.js](https://gist.github.com/gharriso/b652961b3431fee8d5ba4786f671942d###file-mongoout-js) hosted with ❤ by [GitHub](https://github.com)

---

mongo> mongoTuning.aggregationExecutionStats(explainOut);

1 $CURSOR ( ms 3505 returned:1183307)

2 IXSCAN ( iottsix ms:85 keys:1183307 nReturned:1183307)

3 PROJECTIONCOVERED ( ms:115 nReturned:1183307)

4 $GROUP ( ms 1224 returned:5)

5 $SORT ( ms 0 returned:5)

Totals: ms: 4736 keys: 1183307 Docs: 0

[view raw](https://gist.github.com/gharriso/6b6ecb90eea40267fad25f5d23c864b0/raw/849252aebf961562ea778177e08fe6fbd1092b21/mongoExplainOut2.js) [mongoExplainOut2.js](https://gist.github.com/gharriso/6b6ecb90eea40267fad25f5d23c864b0###file-mongoexplainout2-js) hosted with ❤ by [GitHub](https://github.com)

---
# Querying MongoDB Like an SQL DB Using Aggregation Pipeline

### What Are Aggregations?

Aggregation operations process data records and return computed results. Aggregation operations group values from multiple documents together and can perform a variety of operations on the grouped data to return a single result.

In the `db.collection.aggregate` method and `[db.aggregate](https://docs.mongodb.com/manual/reference/method/db.aggregate/###db.aggregate)` method, [pipeline](https://docs.mongodb.com/manual/core/aggregation-pipeline/) stages appear in an array. Documents pass through the stages in sequence. We will go through some of the stages to achieve a relational DB like results.

### $match (WHERE)

Filters the documents to pass only the documents that match the specified condition(s) to the next pipeline stage.

It has the following prototype:
```js
{ $match: { <query> } }
```
It is the equivalent of WHERE in SQL queries. Let us take an example to make things clear. This example uses a collection named `articles` with the following documents:
```js
{ "id" : ObjectId("512bc95fe835e68f199c8686"), "author" : "dave", "score" : 80, "views" : 100 }  
{ "id" : ObjectId("512bc962e835e68f199c8687"), "author" : "dave", "score" : 85, "views" : 521 }  
{ "id" : ObjectId("55f5a192d4bede9ac365b257"), "author" : "ahn", "score" : 60, "views" : 1000 }  
{ "id" : ObjectId("55f5a192d4bede9ac365b258"), "author" : "li", "score" : 55, "views" : 5000 }  
{ "id" : ObjectId("55f5a1d3d4bede9ac365b259"), "author" : "annT", "score" : 60, "views" : 50 }  
{ "id" : ObjectId("55f5a1d3d4bede9ac365b25a"), "author" : "li", "score" : 94, "views" : 999 }  
{ "id" : ObjectId("55f5a1d3d4bede9ac365b25b"), "author" : "ty", "score" : 95, "views" : 1000 }
```
Equality match.
```js
db.articles.aggregate(  
    [ { $match : { author : "dave" } } ]  
);
// Result  
{ "id" : ObjectId("512bc95fe835e68f199c8686"), "author" : "dave", "score" : 80, "views" : 100 }  
{ "id" : ObjectId("512bc962e835e68f199c8687"), "author" : "dave", "score" : 85, "views" : 521 }
```
We can have multiple constraints inside `$match`, like `$or`, `$and`, etc. according to our requirements, although it has some limitations as well. You can read about it in the [Mongo docs](https://docs.mongodb.com/manual/reference/operator/aggregation/match/).

### $skip (OFFSET)

Skips over the specified number of [documents](https://docs.mongodb.com/manual/reference/glossary/###term-document) that pass into the stage and passes the remaining documents to the next stage in the [pipeline](https://docs.mongodb.com/manual/reference/glossary/###term-pipeline). It has the following prototype:
```js
{ $skip: <positive integer> }
```
In the above example, we were able to match the records related to `dave`. If we want to skip the few results from the beginning we would write the query as:
```js
db.articles.aggregate([   
    { $match : { author : "dave" } },  
    { $skip: 1 }   
]);
// We are skipping 1 result and we should get just this{ "id" : ObjectId("5dc1d22f24a8e913bfcf4f60"), "author" : "dave", "score" : 85, "views" : 521 }
```js
We generally use `$skip` with `$limit` to paginate the data, let’s insert few more records into our collection and see how `$skip` and `$limit` work together in the next section.

### $limit (LIMIT)

Limits the number of documents passed to the next stage in the [pipeline](https://docs.mongodb.com/manual/reference/glossary/###term-pipeline). It has the following prototype:
```js
{ $limit: <positive integer> }
```
We have added new records for `dave`, let’s see how the collections look with a simple `$match`:
```js
db.articles.aggregate(  
    [ { $match : { author : "dave" } } ]  
);

{ "id" : ObjectId("5dc1d22124a8e913bfcf4f5f"), "author" : "dave", "score" : 80, "views" : 100 }  
{ "id" : ObjectId("5dc1d22f24a8e913bfcf4f60"), "author" : "dave", "score" : 85, "views" : 521 }  
{ "id" : ObjectId("5dc1d53924a8e913bfcf4f65"), "author" : "dave", "score" : 185, "views" : 1521 }  
{ "id" : ObjectId("5dc1d54f24a8e913bfcf4f66"), "author" : "dave", "score" : 15, "views" : 21 }
```
We have four matching records in the example collection. Suppose you are asked to paginate the results to show two at a time, how would you go about it? Let’s see.
```js
db.articles.aggregate([   
    { $match : { author : "dave" } },  
    { $skip: 0},  
    { $limit: 2}  
]);

// We are not skipping any records and but limiting the records to 2{ "id" : ObjectId("5dc1d22124a8e913bfcf4f5f"), "author" : "dave", "score" : 80, "views" : 100 }  
{ "id" : ObjectId("5dc1d22f24a8e913bfcf4f60"), "author" : "dave", "score" : 85, "views" : 521 }// We got the first two results, to get the next two results just update the $skipdb.articles.aggregate([   
    { $match : { author : "dave" } },  
    { $skip: 2},  
    { $limit: 2}  
]);// This should give two records after skipping the first two.{ "id" : ObjectId("5dc1d53924a8e913bfcf4f65"), "author" : "dave", "score" : 185, "views" : 1521 }  
{ "id" : ObjectId("5dc1d54f24a8e913bfcf4f66"), "author" : "dave", "score" : 15, "views" : 21 }
```

We are doing good so far, but suppose your manager comes up to you and asks you to sort the result by views. What are you going to do? We have `$sort` for that.

### $sort (ORDER BY)

Sorts all input documents and returns them to the pipeline in sorted order. It has the following prototype:
```js
{ $sort: { <field1>: <sort order>, <field2>: <sort order> ... } }
```

Let us use the `$sort` stage in our pipeline.

1 to specify ascending order  
-1 to specify descending 
```js
orderdb.articles.aggregate([   

    { $match : { author : "dave" } },  
    { $sort: { views: 1}}  
]);// Result{ "id" : ObjectId("5dc1d54f24a8e913bfcf4f66"), "author" : "dave", "score" : 15, "views" : 21 }  
{ "id" : ObjectId("5dc1d22124a8e913bfcf4f5f"), "author" : "dave", "score" : 80, "views" : 100 }  
{ "id" : ObjectId("5dc1d22f24a8e913bfcf4f60"), "author" : "dave", "score" : 85, "views" : 521 }  
{ "id" : ObjectId("5dc1d53924a8e913bfcf4f65"), "author" : "dave", "score" : 185, "views" : 1521 }
```
Voilà ! The results are sorted now.

Place the `$match` as early in the aggregation [pipeline](https://docs.mongodb.com/manual/reference/glossary/###term-pipeline) as possible. Because `$match` limits the total number of documents in the aggregation pipeline, earlier `$match` operations minimize the amount of processing down the pipe.

### $group

Groups input documents by the specified `id` expression and, for each distinct grouping, outputs a document.

The `id` field of each output document contains the unique group by value. The output documents can also contain computed fields that hold the values of an [accumulator expression](https://docs.mongodb.com/manual/reference/operator/aggregation/group/###accumulators-group). It has the following prototype:
```js
{  
  $group:  
    {  
      id: <expression>, // Group By Expression  
      <field1>: { <accumulator1> : <expression1> },  
      ...  
    }  
}
```
Suppose we want to group the articles by author, in other words, the number of articles by each author, we can make use of the group stage in the pipeline. So, let’s see it live:
```js
db.articles.aggregate([   
    { $group : { id: "$author", count: { $sum: 1 }}},  
    { $sort: { count: 1 }}  
]);
// We have grouped the articles by author ann getting the count and sorting it by count{ "id" : "annT", "count" : 1 }  
{ "id" : "ahn", "count" : 1 }  
{ "id" : "li", "count" : 2 }  
{ "id" : "dave", "count" : 4 }

// We can have more constraints like if we want only the results whose count is greater than 1, then we can add a $match stage in the pipeline after $group

db.articles.aggregate([   
    { $group : { id: "$author", count: { $sum: 1 }}},  
    { $sort: { count: 1 }},  
    { $match: { count : { $gt: 1 }}}  
]);{ "id" : "li", "count" : 2 }  
{ "id" : "dave", "count" : 4 }
```

Let us take this grouping up a notch. Suppose we want to group by values stored in an array structure. We have something called `$unwind`. Let’s see how it works.

### $unwind

Deconstructs an array field from the input documents to output a document for each element. Each output document is the input document with the value of the array field replaced by the element.

You can pass the array field path to `$unwind`. When using this syntax, `$unwind` does not output a document if the field value is null, missing, or an empty array. It has the following prototype:
```js
{ $unwind: <field path> }
```
Let us take a new collection `inventory` and a new record to it with the following command:
```js
db.inventory.insertOne({ "id" : 1, "item" : "ABC1", sizes: [ "S", "M", "L"] })
```

That’s the beauty of MongoDB, you can create a new collection and each document is identical to the input document, except for the value of the `sizes` field which now holds a value from the original `sizes` array. Add a record to it without any setup.

Let us `$unwind` this by the sizes.
```js
db.inventory.aggregate( [ { $unwind : "$sizes" } ] )
// Result  
{ "id" : 1, "item" : "ABC1", "sizes" : "S" }  
{ "id" : 1, "item" : "ABC1", "sizes" : "M" }  
{ "id" : 1, "item" : "ABC1", "sizes" : "L" }
```
Each document is identical to the input document except for the value of the `sizes` field which now holds a value from the original `sizes` array.

Let us take a new collection `inventory2` and do a group by the size, use this command to insert more records:
```js
db.inventory2.insertMany([  
  { "id" : 1, "item" : "ABC", price: NumberDecimal("80"), "sizes": [ "S", "M", "L"] },  
  { "id" : 2, "item" : "EFG", price: NumberDecimal("120"), "sizes" : [ ] },  
  { "id" : 3, "item" : "IJK", price: NumberDecimal("160"), "sizes": "M" },  
  { "id" : 4, "item" : "LMN" , price: NumberDecimal("10") },  
  { "id" : 5, "item" : "XYZ", price: NumberDecimal("5.75"), "sizes" : null }  
])
```
If we unwind this, we would get something like this:
```js
db.inventory2.aggregate( [ { $unwind: "$sizes" } ] )
// Results{ "id" : 1, "item" : "ABC", "price" : NumberDecimal("80"), "sizes" : "S" }  
{ "id" : 1, "item" : "ABC", "price" : NumberDecimal("80"), "sizes" : "M" }  
{ "id" : 1, "item" : "ABC", "price" : NumberDecimal("80"), "sizes" : "L" }  
{ "id" : 3, "item" : "IJK", "price" : NumberDecimal("160"), "sizes" : "M" }// Notice it ignores the null and undefined values

db.articles.aggregate([   
    { $unwind: { path: "$sizes" } },  
    { $group: { id: "$sizes", count: { $sum: 1 }}}  
]);// Results{ "id" : "M", "count" : 2 }  
{ "id" : "L", "count" : 1 }  
{ "id" : "S", "count" : 1 }
```
We can apply different stages to this like `$match`, `$sort`, `$skip`, `$limit`, etc. to get the desired results.

Now, let’s move on to SQL JOINS, to achieve joins in MongoDB we have `$lookup`.

### $lookup

New in version 3.2.

Performs a left outer join to an unsharded collection in the same database to filter in documents from the “joined” collection for processing.

To each input document, the `$lookup` stage adds a new array field whose elements are the matching documents from the “joined” collection. The `$lookup` stage passes these reshaped documents to the next stage.

There can be different join conditions but we will be looking into the most basic one, which is an equality match.

###### Equality match

To perform uncorrelated subqueries between two collections as well as allow other join conditions besides a single equality match. The `[$lookup](https://docs.mongodb.com/manual/reference/operator/aggregation/lookup/###pipe.Slookup)` stage has the following syntax:
```js
{  
   $lookup:  
     {  
       from: <collection to join>,  
       let: { <var1>: <expression>, …, <varn>: <expression> },  
       pipeline: [ <pipeline to execute on the collection to join> ],  
       as: <output array field>  
     }
      
}

```
**from:** Specifies the collection in the same database to perform the join with.**let:** Optional. Specifies variables to use in the pipeline field stages. Use the variable expressions to access the fields from the documents input to the $lookup stage.**pipeline:** Specifies the pipeline to run on the joined collection. The pipeline determines the resulting documents from the joined collection. To return all documents, specify an empty pipeline [].**as**: Specifies the name of the new array field to add to the input documents. The new array field contains the matching documents from the from collection. If the specified name already exists in the input document, the existing field is overwritten.

Let us look at some examples to better understand the terminologies:

###### Perform a single equality join with $lookup

Create a collection `orders` with the following documents:
```js
db.orders.insert([  
   { "id" : 1, "item" : "almonds", "price" : 12, "quantity" : 2 },  
   { "id" : 2, "item" : "pecans", "price" : 20, "quantity" : 1 },  
   { "id" : 3  }  
])
```
Create another collection `inventory` with the following documents:
```js
db.inventory.insert([  
   { "id" : 1, "sku" : "almonds", description: "product 1", "instock" : 120 },  
   { "id" : 2, "sku" : "bread", description: "product 2", "instock" : 80 },  
   { "id" : 3, "sku" : "cashews", description: "product 3", "instock" : 60 },  
   { "id" : 4, "sku" : "pecans", description: "product 4", "instock" : 70 },  
   { "id" : 5, "sku": null, description: "Incomplete" },  
   { "id" : 6 }  
])
```

The following aggregation operation on the `orders` collection joins the documents from `orders` with the documents from the `inventory` collection using the fields `item` from the `orders` collection and the `sku` field from the `inventory` collection:
```js
db.orders.aggregate([  
   {  
     $lookup:  
       {  
         from: "inventory",  
         localField: "item",  
         foreignField: "sku",  
         as: "inventorydocs"  
       }  
  }  
]);
```
The operation returns the following documents:
```js
{  
   "id" : 1,  
   "item" : "almonds",  
   "price" : 12,  
   "quantity" : 2,  
   "inventorydocs" : [  
      { "id" : 1, "sku" : "almonds", "description" : "product 1", "instock" : 120 }  
   ]  
}  
{  
   "id" : 2,  
   "item" : "pecans",  
   "price" : 20,  
   "quantity" : 1,  
   "inventorydocs" : [  
      { "id" : 4, "sku" : "pecans", "description" : "product 4", "instock" : 70 }  
   ]  
}  
{  
   "id" : 3,  
   "inventorydocs" : [  
      { "id" : 5, "sku" : null, "description" : "Incomplete" },  
      { "id" : 6 }  
   ]  
}
```
---
# How to Perform JOIN in MongoDB Using $lookup 

MongoDB is a NoSQL document-oriented database, which means it stores data in a flexible format called BSON (a binary JSON format). Unlike relational databases like MySQL or PostgreSQL, MongoDB doesn’t have native relationships between collections, such as JOINs.

However, starting with version 3.2, MongoDB introduced the $lookup operator, which allows for join operations between collections, enabling you to combine data from two or more collections in a way similar to SQL JOINs. In this article, we’ll explore how $lookup works and how to use it to join data.

**Collection Structure**

For this example, let’s consider two collections:

1. customers — Contains customer information.

2. orders — Contains information on orders placed by these customers.

The structure of the documents in each collection might look like this:

![](https://miro.medium.com/v2/resize:fit:875/1*p5mVL3OuOSbSD7NajU6I8A.png)

Each document in the orders collection includes a customerId field, which is a reference to the corresponding customer in the customers collection.

**Using $lookup to Perform the JOIN**

Let’s use the $lookup operator to join these collections and list all orders along with customer information.

**Basic $lookup Example**

To perform a query where we want to list all orders with customer information, we can use $lookup as follows:

![](https://miro.medium.com/v2/resize:fit:875/1*rK7fJP8r--Bt0Bw9IRjdjg.png)

**Explanation of the Fields**

• from: Specifies the name of the collection to join with. In this case, we are relating orders with customers.

• localField: Field in the current collection (orders) that will be used for matching.

• foreignField: Field in the other collection (customers) that will be matched.

• as: Name of the new field where the joined data will be stored.

The result will look something like this:

![](https://miro.medium.com/v2/resize:fit:875/1*CEWthiAKw69vOEFXnnmdgw.png)

Here, the customerData field is an array containing the matching customer data.

**Flattening Results with $unwind**

In some cases, we may want the results to be in a flat format (without arrays like customerData). We can use the $unwind operator to flatten the array, creating a separate document for each list element.

![](https://miro.medium.com/v2/resize:fit:875/1*wMw5ytW6PoOfPQSC6JTR8w.png)

The result will now look like this:

![](https://miro.medium.com/v2/resize:fit:875/1*Di0u17DRho4lZwsNExVjyA.png)

**Using $lookup with Additional Filters**

We can also combine $lookup with other MongoDB operators to apply additional filters. For example, let’s list only orders with a total amount above 100.

![](https://miro.medium.com/v2/resize:fit:875/1*19qgCGkxvu6Ra60n8QB2dA.png)

This query will return only orders where totalAmount is greater than 100.

**Conclusion**

The $lookup operator in MongoDB is a powerful tool for performing join-like operations between collections. It allows you to combine data from different collections without needing to completely denormalize your database. This feature is especially useful when you need to bring related data together for reporting or specific queries.

We hope this guide has helped you understand how to use $lookup in MongoDB.

---
# MongoDB Left Anti-Join. Suppose you have two Collections 

Suppose you have two Collections (A and B) in a MongoDB Database, and you want to find all Documents in A whose certain field does not exist in any of the Documents in B. In SQL, you would use some thing like this:
```sql
SELECT  *  
FROM    A  
WHERE   NOT EXISTS ( SELECT 1  
                     FROM   B  
                     WHERE  A.field = B.field );
```
or, by exploiting the nature of outer joins:
```sql
SELECT  A.*  
FROM    A LEFT OUTER JOIN B ON A.field = B.field  
WHERE   B.field IS NULL;
```
Such queries are called left anti joins. It is a such popular receipe that many data-processing platforms offer a direct method for calling this operation. For example, in Spark (in PySpark flavor):
```sql
A.join(B, A.field == B.field, "leftanti")
```
Now you probably can understand why I was surprised that no snippet was on the first page of Google results when I searched “MongoDB left anti join”.

Therefore, here you are, the handy piece of code for doing a left anti join in MongoDB (`pymongo`-flavored):
```js
db.A.aggregate([  
    // Find Documents in B that has the same value for the field of 
    // interest with each of the Document in A:  
    {'$lookup' : {'from'        : "B",  
                  'localField'  : "field",  
                  'foreignField': "field",  
                  'as'          : "P5hrj4w75"}},  
    // Drop any Document in A that actually had a match in B:  
    {'$match'  : {'P5hrj4w75' : { '$size': 0 } }},  
    // Drop this meaningless, must-be-empty field:  
    {'$project': {'P5hrj4w75' : 0}}])
```  
### this will return a cursor for all remaining Documents in A.

(I’m naming the temporary field `P5hrj4w75` so that it is least likely to coincide with any of your meaningful fields already existing in A or B.)

A side note: Often when you want to perform a left anti join, you merely cares about “what **values of the field** appeared in A but not in B”, in which case having the complete Documents returned isn’t so ideal. The next version does the work:
```js
res = db.A.aggregate([  
    // We may as well explicitly filter for the field of interest from the very beginning:  
    {'$project': {'field': 1} },  
    // Find Documents in B that has the same value for the field of interest with each of the Document in A (same as before):  
    {'$lookup' : ...},  
    //  Drop any Document in A that actually had a match in B (same as before):  
    {'$match'  : ...},  
    {'$facet'  : {  
        'cnt': [{'$count': 'value'}],  
        'ids': [{'$group': {'id': 'Dummy', 'values': {'$addToSet': '$field'} }}]  
    }},  
    {'$project': {'cnt': {'$arrayElemAt': ['$cnt.value', 0]},   
                  'ids': {'$arrayElemAt': ['$ids.values', 0]}}} ]) ;

assert res is not None  
res = list(res)[0]  
listofexclusivevaluesusedinAbutnotinB = res['ids']  
numberofDocumentsinAhavingthefieldinthesevalues = res['cnt']
```
That’s it. I hope this stub can be helpful. Cheers!

---
# MongoDB Joins 

SQL is the standard way of querying relational databases.

It has become the common way of talking about querying data that we can generally understand.

It isn’t intended for document databases, and it isn’t always appropriate. It has, for example, great difficulty with embedded arrays and other non-relational devices.

> **However, a SQL query is quite often a good way to start working on a MongoDB query**.

It gets you started, and it is much easier to criticize and alter something already drafted than to create it from scratch.

In this article, I’ll show you various types of SQL join queries that benefit from this sort of approach and how you can fine-tune the automatically-generated MongoDB queries for better performance, or to get the output closer to what you need.

We’ll demonstrate this approach with INNER JOIN, queries with several JOINS, the IN clause, GROUP BY, and finally LEFT OUTER JOINS.

### Talking to MongoDB with SQL

![](https://miro.medium.com/v2/resize:fit:875/1*WtXrZBzZyWGKxBa3gylQig.png)
Source: https://rickosborne.org/download/SQL-to-MongoDB.pdf

If you can talk SQL, there are several third-party tools that allow you to use SQL to query and manipulate MongoDB databases.

From an application, you can use SQL as an alternative to shell queries if you use ODBC.

Any certified ODBC interface is obliged to have [a pretty decent public standard](https://docs.microsoft.com/en-us/sql/odbc/reference/odbc-and-the-standard-cli?view=sql-server-2017) subset of SQL implemented called ISO/IEC 9075–3:1995 (E) Call-Level Interface (SQL/CLI).

You can, with the ODBC text driver, even use SQL queries to interrogate or write to CSV or tab-delimited text files as if they were a database.

With an ODBC MongoDB driver from a reputable source, you can do the same thing: talk in SQL.

There is a handy chart provided by MongoDB that shows the equivalence between the two query languages, the [SQL to MongoDB Mapping Chart](https://docs.mongodb.com/manual/reference/sql-comparison/).

There are also utilities for translation for queries that don’t involve joins, such as QueryMongo.

### Reservations to SQL and joins

Although I’ve more years of experience of SQL than I like to admit publicly, I am worried about using a relational language for a document database.

XML and JSON are uneasy fits into the relational model because there are different ways of joining document collections, particularly when there are embedded lists and objects.

There is no SQL equivalent, for example, to the request to search through a collection, to look through an array of objects within each document, and, if you get a match, return just the items of the list that match, and whatever other items you specify within the documents as part of the returned collection.

However, it is very convenient to use SQL occasionally to avoid the drudgery of keying in the basic aggregation, and then taking the resulting mongo shell code and altering it to your requirements.

### SQL and Studio 3T

Studio 3T has [a SQL Query feature](https://studio3t.com/knowledge-base/articles/sql-query/) that allows you to execute SQL in MongoDB.

![](https://miro.medium.com/v2/resize:fit:875/1*kYJh9fI5HjpswD036YvLcA.gif)

It is interpreted directly into the mongo shell language equivalent, with variants for [commonly-used languages like JavaScript (Node.js), Java, Python, and C###](https://studio3t.com/knowledge-base/articles/query-code/), so you can cut and paste the results directly into code.

It used to just interpret a very small number of simple queries, but it now does joins.

I generally use it to get started with an aggregate query that I can then transfer to the Aggregation Editor to fine-tune.

In this article, just to provide a SQL playground for MongoDB, I’ll be using an old Sybase relational database from the eighties, called Pubs.

Because it originally had very little data in it, it isn’t much used now but a large number of queries have been written using it. I’ve not used the original data, but instead created a much larger volume of spoof data and added a few things to exercise a database.

I’ve added a download link for the Pubs database at the end of this article, as a zipped directory of JSON files. Here it is, installed.

![](https://miro.medium.com/v2/resize:fit:288/0*cbX-e-9DR6juuXew.png)

The tables in the original relational form have been imported using [Studio 3T’s Import Wizard](https://studio3t.com/knowledge-base/articles/mongodb-import-export/###import-to-mongodb).

Each table appears as a collection in the Pubs database. This means, for instance, that data about publishers and titles are now separate, in two collections, requiring a JOIN to get at the full data.

The import routine does not convert primary keys to the MongoDB equivalent so we’ll need a few unique indexes to get this working properly.

Rather than just reproduce the original keys and references, we’ll start without them and add them to taste.

Why? **Because we can see the improvement that comes from using the index**, and may be able to provide covering queries that allow us to avoid accessing the actual document entirely.

### Getting started with the SQL Query feature

We have a quick look at the **titles** collection in the collection view of Studio 3T.

![](https://miro.medium.com/v2/resize:fit:875/0*lFVkwVFpp0noJ5KU.png)

There is some interesting info to explore here.

What titles, and of which type, start with the word ‘Secret’?

SELECT title  
FROM titles WHERE title LIKE 'Secret%';

![](https://miro.medium.com/v2/resize:fit:450/0*GR4FLU7QM3U4jJS.png)

Please ignore the silly titles. I didn’t want to spend too much time to get ten thousand spoof titles.

The **.find()** method code that was actually executed was
```js
use Pubs;  
db.getCollection("titles").find(  
    {   
        "title" : /^Secret.*$/i  
    },   
    {   
        "title" : "$title",   
        "type" : "$type"  
    }  
);
```

### SQL INNER JOIN in MongoDB

Now for a join. What books are being published by one particular publisher?

In SQL-speak, we need to join the two ‘tables’ (collections) with an inner join to find out.

We select our Pubs database in the browser pane and click on the SQL menu item in Studio 3T’s global toolbar.

Then we tap in some SQL.
```sql
SELECT titles.title  
  FROM publishers  
    INNER JOIN titles  
      ON titles.pubid = publishers.pubid  
  WHERE publishers.pubname = 'Cavendish Academic Trust';
```

We get a result!
```json
{   
    "titles" : {  
        "title" : "Truvenaquan Volume 1"  
    }  
}  
{   
    "titles" : {  
        "title" : "Klihupex Bedside Book"  
    }  
}  
{   
    "titles" : {  
        "title" : "Tupzapar Bedside Book"  
    }  
}  
{   
    "titles" : {  
        "title" : "Grozapinentor Bedside Book"  
    }  
}  
{   
    "titles" : {  
        "title" : "Klipickover Horrors"  
    }  
}
```

We can see from the ‘Explain’ tab that it had to do a collection scan (COLLSCAN) of the publishers table, all two thousand of them, to get the result.

Simply by changing the SQL a bit, we can make it go slower, and scan ten thousand documents to get the same result:
```sql
SELECT titles.title  
  FROM titles  
    INNER JOIN publishers  
      ON titles.pubid = publishers.pubid  
  WHERE publishers.pubname = 'Cavendish Academic Trust';
```
There are more titles than there are publishers, so if each publisher has, say, five titles, then the **publishers** table will have five times as many documents as the **titles** collection.

Doing a lookup for every title is five times as many lookups as doing a lookup for every publisher. What we’ve done suggests that, when using this utility, **it pays to put the smaller collection first**.

In most relational databases, the order in which you specify the tables will make no difference because the query optimiser will work out the best way of doing it.

However, the optimiser has the advantage that it has a lot of extra information that it can use to make choices: any SQL interpreter can only translate literally from SQL to Javascript. **We will need an index**.

In the relational original of this database, the `pubid` field was a primary key for the publishers and the foreign key for the titles.

All MongoDB collections have an`id` key that corresponds to a relational key. Unfortunately, our transfer of the PUBS database didn’t assign the primary key to the `id`.

MongoDB aggregations generally can use just one index, **but MongoDB can use a separate index under the covers for the** `$lookup` **stage. We can, and should, index the foreign key in a lookup,** but we would do a lot better by drastically reducing the amount of data being accessed, and supporting that operation with an index.

When looking at the query, it is obvious that the best strategy is to locate the document in the **publishers** collection for the ‘Cavendish Academic Trust’ and get the `pubid` value to get the titles that have that same value.

To help achieve that, we put the `pubname` and `pubid` in the index, in that order. This means that MongoDB can get the `pubname` out of the index and altogether avoid pulling the publisher collection into memory.
```js
db.publishers.createIndex(  
   { 'pubname': 1,'pubid': 1 },  
   { name: 'PublishersPubNamePubid' }  
)
```
We run the query again and we can see from the profiler that it refuses to use the index. This is because we still have work to do. (See ‘[How to Investigate MongoDB Query Performance](https://studio3t.com/knowledge-base/articles/mongodb-query-performance/)’ on how to use the profiler to do this.)

To do a join, we have to use an aggregate.

An aggregate can only use an index [if the filtering (**$match** stage) is done first](https://docs.mongodb.com/manual/reference/operator/aggregation/match/). This makes lots of sense when you think of the mechanics of implementing the query.

To do this, we get the mongo shell source code from the [Query Code](https://studio3t.com/knowledge-base/articles/query-code/) pane, and put it on the clipboard (Ctrl + A followed by Ctrl + C; or using the copy icon as shown below)

![](https://miro.medium.com/v2/resize:fit:776/0*4rzpAmBgnsalhFBa.png)

Now we open up [Aggregation Editor](https://studio3t.com/knowledge-base/articles/build-mongodb-aggregation-queries/) and click on the paste button on the right.

![](https://miro.medium.com/v2/resize:fit:559/0*1O7zNLLfGsKb4gvX.png)

Now the whole aggregation query appears as a list of stages.

![](https://miro.medium.com/v2/resize:fit:805/0*JebjrbkXdC4S4i.png)

I’ve highlighted the match stage and I’m moving it up the sequence by clicking the up-arrow.

It should be the first thing that mongo does when executing the aggregate query, so we can move it with the ordering arrows.

![](https://miro.medium.com/v2/resize:fit:555/0*KF70YJCNWx6qrMMm.png)

Click, click, click. Now we need to edit this stage that we’ve just moved.

{  
    "publishers.pubname" : "Cavendish Academic Trust"  
}

Needs to be …

{  
    "pubname" : "Cavendish Academic Trust"  
}

…because the **publishers** object is now created later in the **$project** stage.

![](https://miro.medium.com/v2/resize:fit:800/0*Z6-jNhRqImVqY1w2.png)

So we now do that by clicking on the tab where you see the mouse-pointer and editing the stage.

We now run it from the aggregation window and check the profile to see if it now uses an index scan (IXSCAN) rather than a collection scan (COLLSCAN). Yes, the query is now lightning fast, and uses our index. From the `system.profile`:

   "millis" : 0,  
   "planSummary" : "IXSCAN { pubname: 1, pubid: 1 "},

For the result, I would like something nearer what a relational database would do: provide a list of documents providing a title. In real life, we’d probably want more than the title. I’d rewrite stage 5 to add the fields we want in the result with an alias (**BookName** in this example) and add a new projection to take out the two objects containing the joins.

![](https://miro.medium.com/v2/resize:fit:875/0*7OLfdYpf8jPK-y.png)

This gives the result …

{   
    "BookTitle" : "Truvenaquan Volume 1"  
}  
{   
    "BookTitle" : "Klihupex Bedside Book"  
}  
{   
    "BookTitle" : "Tupzapar Bedside Book"  
}  
{   
    "BookTitle" : "Grozapinentor Bedside Book"  
}  
{   
    "BookTitle" : "Klipickover Horrors"  
}

This is a much neater result that has eliminated the embedded array that is created by the ‘lookup’ stage.

### Queries with several joins

At this stage, we’ve achieved a reasonable result quickly, but we’re not satisfied. Who wrote the books, for example? What are their subject categories?

Authors, of course, can write several books, and books can have several authors, who share royalties. More than one author can have a particular name.

To keep things neat, and allow you to calculate royalties, revenue and author popularity, they have to have a separate collection and another collection that relates author to title.

Quickly, we tap in a SQL query:
```sql
SELECT titles.title, titles.type, authors.aufname, authors.aulname  
  FROM dbo.publishers  
    INNER JOIN dbo.titles  
      ON titles.pubid = publishers.pubid  
    INNER JOIN dbo.titleauthor  
      ON titleauthor.titleid = titles.titleid  
    INNER JOIN dbo.authors  
      ON authors.auid = titleauthor.auid  
  WHERE publishers.pubname = 'Cavendish Academic Trust';
```

Here are the first two results.
```json
{   
    "titles" : {  
        "title" : "Truvenaquan Volume 1",   
        "type" : "Military"  
    },   
    "authors" : {  
        "aufname" : "Wanda",   
        "aulname" : "Solomon"  
    }  
}  
{   
    "titles" : {  
        "title" : "Klihupex Bedside Book",   
        "type" : "Mystery"  
    },   
    "authors" : {  
        "aufname" : "Norman",   
        "aulname" : "Morton"  
    }  
}
```
Now this may be enough for you. It is pretty fast, but I’m not easily satisfied.

Unless you are desperate for the last smidgen of performance, the existing indexes will do.

We can avoid a COLLSCAN by moving the **$match** stage up as before, and iron out those “authors” and “titles” objects since we don’t need them. (If we find a title with more than one author, we will need an embedded array.)

![](https://miro.medium.com/v2/resize:fit:551/0*FRX80tBlOm8cz8t.png)

A quick check with the profiler shows that we are examining fewer documents and using the index.

The overall time hasn’t changed much because of all the unindexed joins going on — **we can, and should, index a lookup with indexes on the foreign keys** `auid` **and** `titleid`. However, we have already tweaked the result to give us a more readable output.

### The IN clause

There are some more SQL features that are supported.

You can provide a list with an IN clause within the WHERE filter.

This is used in SQL instead of giving a whole lot of OR conditions:
```sql
SELECT titles.title, publishers.pubname  
  FROM publishers  
    INNER JOIN titles  
      ON titles.pubid = publishers.pubid  
  WHERE publishers.pubname in   
  ('Cavendish Academic Trust','Notley Academic Press','Abridge  House')  
  ORDER BY titles.title  
  LIMIT 5  
  OFFSET 5
```
Which provides the result (in JSON):

{   
    "publishers" : {  
        "pubname" : "Abridge  House"  
    },   
    "titles" : {  
        "title" : "Healing Fromunover"  
    }  
}  
{   
    "publishers" : {  
        "pubname" : "Cavendish Academic Trust"  
    },   
    "titles" : {  
        "title" : "Klihupex Bedside Book"  
    }  
}  
{   
    "publishers" : {  
        "pubname" : "Cavendish Academic Trust"  
    },   
    "titles" : {  
        "title" : "Klipickover Horrors"  
    }  
}  
{   
    "publishers" : {  
        "pubname" : "Notley Academic Press"  
    },   
    "titles" : {  
        "title" : "Legends of Sursapex"  
    }  
}  
{   
    "publishers" : {  
        "pubname" : "Abridge  House"  
    },   
    "titles" : {  
        "title" : "Moral Uperiman"  
    }  
}

### GROUP BY and reporting

The use of aggregation functions with GROUP BY is likely to be the most useful. Which, for example, are the top ten most profitable topics or types?
```sql
SELECT Sum(ytdsales), type  
  FROM titles  
  GROUP BY type  
  ORDER BY Sum(ytdsales) DESC  
  LIMIT 10  
  ;
```

Slightly changing the field names by changing the generated code slightly gives us…

![](https://miro.medium.com/v2/resize:fit:418/0*DHFEEGU-P4SxS9PW.png)

Which are the top twenty most profitable publishers in the year to date?
```sql
SELECT Sum(titles.ytdsales), publishers.pubname    
  FROM titles  
    INNER JOIN publishers  
      ON titles.pubid = publishers.pubid  
GROUP BY publishers.pubname   
ORDER BY Sum(titles.ytdsales) desc  
LIMIT 20
```
With a bit of tweaking of field names, we can make it a bit pretty.

![](https://miro.medium.com/v2/resize:fit:589/0*pfmIAObYUS5f237.png)

### LEFT OUTER JOINs

We can do outer joins. These are handy where we want to find out what isn’t part of a relationship between documents.

To give a practical example, how many of our titles don’t have a publisher? (Probably self-published!)
```sql
SELECT Count(*)  
  FROM titles  
    LEFT OUTER JOIN publishers  
      ON titles.pubid = publishers.pubid  
  WHERE publishers.pubid IS NULL
```
The answer is 105.

{   
    "COUNT(*)" : NumberInt(105)  
}

OK. What sort of titles are they without publishers, and who wrote them?

The query is this, but please don’t try executing it. It will take a very long time without modification.
```sql
SELECT titles.title, titles.type, authors.aufname, authors.aulname  
  FROM dbo.titles  
    INNER JOIN dbo.titleauthor  
      ON titleauthor.titleid = titles.titleid  
    INNER JOIN dbo.authors  
      ON authors.auid = titleauthor.auid  
    LEFT OUTER JOIN publishers  
      ON titles.pubid = publishers.pubid  
    WHERE publishers.pubid IS NULL
```
It produces code that isn’t in the best order for performance.

The first join must always do the most filtering. We just copy the code and paste it into an aggregation window for coarse tuning.

![](https://miro.medium.com/v2/resize:fit:875/0*DRBAPjz1KdSgJfw.png)

Stages 6, 7 and 8 need to be moved up the order to be straight after the first projection.

![](https://miro.medium.com/v2/resize:fit:875/0*lMFHXlucI9fKyZ1W.png)

This gets the query working in around 2.6 seconds on our test server. Can we do any fine tuning?

The titles that have no publisher have nulls in them. We could cut out the outer join entirely and just filter via an initial indexed **$match**.

However, we’re trying to illustrate an outer join and so we won’t do that. This optimisation will not apply to many outer join queries.

We can get it down to 2.2 seconds by reducing what is passed down the pipeline to just the data we want. That first **$project** stage can be reduced from taking the entire document down the pipeline
```json
{  
    "id" : NumberInt(0),   
    "titles" : "$$ROOT"  
}
```
…to just the data we actually need.
```json
{  
    "id" : NumberInt(0),   
    "titles.title" :  "$title",  
    "titles.titleid" :  "$titleid",  
    "titles.type" :  "$type",  
    "titles.pubid" :  "$pubid"  
}
```
So you can see that the SQL Query feature can get you started, but there is generally more work to be done to get the query exactly as you want it.

### Using SQL Query to get a head start

Even when the SQL window can’t give us the entire query in the form we want, it can give us a really good start. It is far quicker for someone with SQL skills than hand-cutting mongo shell aggregate queries.

Imagine we want a list of the number of titles published by year ordered by year.

We can’t group by year from the SQL window, but we can tap in a rough query that we can tidy up to our requirement

![](https://miro.medium.com/v2/resize:fit:553/0*0QRHrYFhDq1oqkC.png)

Yes, it isn’t what we want, because each title was published at a different date so the **$count** value will always be 1.

We put that mongo shell code in the [Aggregation Editor](https://studio3t.com/knowledge-base/articles/aggregation-editor/) as I’ve already demonstrated, and fix things, testing as we go, to produce this.
```js
use Pubs;  
db.getCollection("titles").aggregate(  
    [  
        {   
            "$group" : {  
                "id" : {  
                    "Year" : {  
                        "$year" : "$pubdate"  
                    }  
                },   
                "NumberPublished" : {  
                    "$sum" : NumberInt(1)  
                }  
            }  
        },   
        {   
            "$addFields" : {  
                "Year" : "$id.Year"  
            }  
        },   
        {   
            "$project" : {  
                "id" : NumberInt(0)  
            }  
        },   
        {   
            "$sort" : {  
                "Year" : 1.0  
            }  
        }  
    ],   
    {   
        "allowDiskUse" : false  
    }  
);

```
This code then gives us what we want in a simple form

![](https://miro.medium.com/v2/resize:fit:304/0*BbKIbXRwfv3PpXB7.png)

### Conclusions

The idea of longing for SQL when using MongoDB seems absurd, like longing for nice pots of tea with cream buns when in Italy.

After having used [various approaches with MongoDB](https://studio3t.com/knowledge-base/categories/mongodb-tutorials/), I can agree that there is a certain tedium in getting started with a complex MongoDB aggregation.

There are two facilities in Studio 3T that turn it into a pleasure: Firstly, using the [SQL Query feature](https://studio3t.com/knowledge-base/articles/sql-query/) to rough out a working query via GROUP BY and JOIN, and secondly, fine tuning the resulting mongo shell query in a controlled way using the [Aggregation Editor](https://studio3t.com/knowledge-base/articles/aggregation-editor/), where you can test every stage independently and change the order for best performance.

That way, you can get aggregations that perform well, and do it quickly.

---
# MongoDB in production: How connection pool size can bottleneck application scale

> Understanding how MongoDB connection pools and pool sizing works is a fundamental part of running an effective MongoDB client application at global scale.
> 
> This article looks at what connection pool size is in MongoDB and how we can test the effect the pool size setting has on the time taken to complete queries, where if set incorrectly, can lead to hidden application bottlenecks by complex queries slowing down simple ones.

As your application needs to scale, the number of queries to MongoDB increases. The complexity of your application also grows, so query requirements become larger — so do potentially hidden bottlenecks.

Let’s say you’re working on an application with two types of users:

1 ) General users of the application, who expect fast loading times. These users account for the majority of application traffic.

2 ) Administrators of the system who need to perform tasks which can span across thousands of users and their related items — administration actions which are usage intensive and resource heavy.

The first user set(general users) are paying customers, of which there are thousands at any point in time. Any actions these users do in the application needs to be extremely fast — such as a logging in, viewing pages, and other application features. The database queries required for these features are very small, and should be very fast.

The application features used by the second user set(administrators) will generally be very working with large amounts of data, which in turn requires large and complex database queries.

After reports from users that the application has become slower, you start looking at application metrics. You find that MongoDB queries have suddenly become very slow — even for indexed `findOne` queries which use to be extremely fast.

To work out what’s happened here, we need to understand MongoDB pool sizing.

**Example:**

https://github.com/js-kyle/mongodb-pooling
This article’s code samples focus on the Node.js MongoDB driver, however the underlying concepts remain the same across the various MongoDB drivers.

In the above code sample, we have a minimal [Express.js](https://expressjs.com/) server with two endpoints, `/slow` and `/fast` . One database connection is created, which is then shared for all MongoDB queries — this is much more performant than opening and closing TCP connections for each and every query the application makes to the database.

As we are now sharing the database connection across the application, we need to understand how the pool size option of this connection comes into play. The pool size is the option which determines how many queries may be run using the same connection in parallel, similar to the number of lanes in a tunnel. An incorrectly set value for this connection can bottleneck the whole application.

The `/slow` route uses an example query which will take 5 seconds to return a result — this is designed to emulate a slow query in your application such as an administrator loading every user, or a todo list application loading a large number of items.

The `/fast` route is an example query that should return within a small number of milliseconds — this is designed to emulate a very simple, yet critical user facing query in your application, for example, a general user logging in.

In the code sample, the environment variable `MONGOPOOLSIZE` can be used to dynamically change the pool size on application start. With this, we can begin to benchmark our application with various pool sizes configurations. To accurately test this, we can use the application load testing tool [artillery.io](https://artillery.io).

The above yaml configuration file can be used with the artillery.io cli to run a performance test. This performance test will target our running application at `http://localhost:3000` and emulate a new user arriving at the application every second, for 5 seconds. Each user will visit both the `/slow` and `/fast` endpoint and wait for a response from the server.

First, let’s run the loadtest using a pool size of 3. This means that our database connection will be able to run a maximum of three queries to MongoDB at one time.
```shell
`$ MONGOPOOLSIZE=3 node index` (Starts the application, with a pool size of 3)

`$ artillery run loadtest.yaml`
```
![](https://miro.medium.com/v2/resize:fit:429/1*LylRdmi3JQJyoS2OrKBTOg.png)

With the pool size set to three, all of the tests completed successfully, with a maximum response time of 9017ms (our slow query emulates one which takes 5000ms).

What happens when we lower our pool size to 1? This means that our database connection will only be able to run one MongoDB query at one time.
```shell
`$ MONGOPOOLSIZE=1 node index`

`$ artillery run loadtest.yaml`
```
![](https://miro.medium.com/v2/resize:fit:411/1*IkgHAECWeqAm-A8OVodoA.png)

Though every request succeeded, the maximum response time increased from 9017ms to 21142.7ms. Why? **Our concurrent requests were now blocked by the first slow query, so all of our fast queries have suffered as a result.**

What happens if we increase the pool size to 10? This means that our database connection will be able to run up to ten MongoDB queries at one time.
```shell
`$ MONGOPOOLSIZE=10 node index`

`$ artillery run loadtest.yaml`
```
![](https://miro.medium.com/v2/resize:fit:389/1*0bZ7W7LWg4XxJk5gRI9zA.png)

Our maximum response time is now 5019ms — the time required to run our example slow query. This shows that no other queries were blocking the database connection during this test, meaning that our `/slow` and `/fast` endpoints provided the expected result to the user without being bottlenecked.

So, what is this pool size setting, and why is it stalling my application scale?

Picture the MongoDB connection as a tunnel. The pool size determines how many lanes of traffic can enter the tunnel at a time. If you have a one-lane tunnel with a bus and a Ferrari, the Ferrari can’t get through the tunnel until the bus has. This means that sometimes, a slow bus can make even a Ferrari slow right down if there aren’t enough lanes.

When we add extra lanes, i.e. increasing our connection pool size, we can make room for the Ferrari to speed through and not get held up by the slow bus.

**What should I do about it?**

If you expect your application to require long running queries, or many concurrent queries you should benchmark your application by simulating expected production load with a tool such a [JMeter](https://jmeter.apache.org/) or [artillery.io](https://artillery.io/) to investigate the impact of increasing the pool size for the MongoDB connection. The optimal pool size for your application will also need to take into account other clients which are sharing the same MongoDB server — as resource usage on the MongoDB server should also be monitored.

Tools such as Azure Application Insights can be used to instrument the MongoDB query performance in your application as detailed in [this blog post](/@yoad/auto-mongodb-telemetry-in-application-insights-too-verbose-quick-note-fb4af3470ff0).


```js
const mongodb = require('mongodb');
const express = require('express');
const app = express();

let db;

const connectionOptions = { poolSize: process.env.MONGOPOOLSIZE || 1 };

mongodb.MongoClient.connect('mongodb://localhost:27017/test', connectionOptions, 
    function(err, database) {

        if (err) throw err;
            db = database.db('test');

            // create some documents required for demonstration

        db.collection('test').insertOne();

        app.listen(process.env.PORT || 3000, function() {
            console.log(`Express.js server up.`);
        });
});
```


/*

For demonstration purposes, this route will always return slowly due to an intentionally slow query (5seconds per document)

*/

```js
    app.get('/slow', function (req, res) {

        db.collection('test').find({'$where': 'sleep(5000) || true'}).toArray(function(err, cursor) {
            return res.json({"docCount": 'docs'});
        });
    });
```
/*

This route should always return quickly
```js
app.get('/fast', function (req, res) {
        db.collection('test').countDocuments({}, function(err, count) {
        return res.json({'documentCount': count});
    });
});
```
[view raw](https://gist.github.com/js-kyle/7891fff4d04d0f65d1ce0f4a4d57d349/raw/069d823549068c49075380e75ea8d227c356eb80/index.js) [index.js](https://gist.github.com/js-kyle/7891fff4d04d0f65d1ce0f4a4d57d349###file-index-js) hosted with ❤ by [GitHub](https://github.com)

---
```yaml
config:
target: "http://localhost:3000"
phases:
- duration: 5
arrivalRate: 1
scenarios:
- flow:
- get:
url: "/slow"
- get:
url: "/fast"
```
[view raw](https://gist.github.com/js-kyle/5c2d0cd2a658913abea78fd55511f2f1/raw/b26a04ffabe4b4d97eb505edb6669bd8cd1ae4a3/loadtest.yaml) 
https://gist.github.com/js-kyle/5c2d0cd2a658913abea78fd55511f2f1###file-loadtest-yaml


# Using @DocumentReference for relations in Spring Boot MongoDB

To establish relations between documents, MongoDB recommends the use of **manual references**. Using `@DocumentReference` we can follow this recommendation in our Spring Boot application and at the same time **resolve the linked document without any additional code**.

Before version 3.3.0 of Spring Data MongoDB, a manual reference could only be established by storing the plain ID of a linked document. Determining the target document then had to be done **additionally in the code** by starting an explicit query.
```java
private Address getPrimaryAddress(final Customer customer) {  
    return addressRepository.findById(customer.getPrimaryAddressId()).get();  
}
```

▴ Resolving a manual reference before

Nowadays the new annotation `@DocumentReference` is available. This falls back on the fast manual reference and only stores the ID of the linked document in MongoDB. At the same time, we can **transparently access the target document in the code** without having to worry about the additional query.
```java
@Document  
public class Customer {  
  
    @Id  
    private Long id;  
  
    // ...  
  
    @DocumentReference(lazy = true)  
    private Address primaryAddress;  
  
}
```

▴ Linking another Document transparently with a manual reference

`@DocumentReference` can be specified on both sides of a relation. For this one side must be extended with `@ReadOnlyProperty` as well as a **lookup query to resolve the reference via the source document**. All common types like One-to-One, Many-to-one and Many-to-many are supported. With Many-to-many a list of IDs of the target document is stored in the database - no intermediate table / collection is created.
```java
@Document  
public class Address {  
  
    @Id  
    private Long id;  
  
    // ...  
  
    @DocumentReference(lazy = true, lookup = "{ 'primaryAddress' : ?###{###self.id} }")  
    @ReadOnlyProperty  
    private Customer primaryAddress;  
  
}
```

▴ Parent side of our One-to-one relation

Setting `lazy = true` can be **recommended for the vast majority of cases**. Unlike JPA, where the initial data is loaded with a join, a new query against MongoDB is always necessary to resolve the relation. This can be done only when the linked document is actually accessed.

Bootify can be used to **define a Spring Boot application for MongoDB with custom documents and relations**. For this purpose `@DocumentReference` is generated automatically including the lookup query, and the runnable application is available for download.

[**» Learn more**](https://bootify.io/quickstart.html)

---
### Spring Boot - Mongo DB Rest API 

**Part 2**

1.  What is MongoDB?
2.  How to Integrate MongoDB into Spring Boot Project?
3.  **Creating Services, Saving and Reading Data to Mongo**

Hello, in the first part, I tried to explain these titles: What is MongoDB? and How to Integrate MongoDB into Spring Boot Project?

In this article, I will continue on the last title above.

To read the first part:

### Spring Boot, MongoDB and Aggregation Framework

### Part-1

**3. Creating Services and Saving/Reading Data to/from MongoDB**

The last thing we did in the previous section was to access the mongodb, which we raised in the docker environment, from a web interface via mongo-express. We also ran mongo-express as a docker container. When we access the mongo-express interface running on port 8081, we will see a screen like this:

![](https://miro.medium.com/v2/resize:fit:788/0*9VB48uibCIMao8fB)
Mongo-express

Here, we see the databases that are already in when the mongo service is created. Now let’s create a new database to connect from our spring boot application. Let’s write the new database name in the part that says “Database Name” in the upper right corner and create it.

![](https://miro.medium.com/v2/resize:fit:788/0*iifa7za5h0VbhhMb)
database name

In the previous section, we set the database name to be connected to **springbootmongo** in the **application.yml** file. So I created a database named **springbootmongo** as above. The database is ready to store data. Now let’s go back to our project and do the necessary coding.

-   **Lets create Student document class**
```java
@SuperBuilder  
@Getter  
@Setter  
@AllArgsConstructor  
@NoArgsConstructor  
@Document  
public class Student {  
    @Id  
    private String id;  
    private String name;  
    private String lastName;  
    private int age;  
    private String email;  
}
```


We created a Student class with the above properties and marked the class with the **@Document** annotation. Now our Spring Boot project knows that this class will be used as a mongo document, we have added **@Id** annotation to the id variable, so we have specified that the student number will be used as the ID of this document.

-   **Lets create Repository**
```java
@Repository  
public interface IStudentRepository extends MongoRepository<Long,Student> {}
```
We created the Student Repository as an interface and extended this interface to the MongoRepository interface. In this way, we will be able to use all the methods offered by the mongo library in our own repository. (Let’s not forget to mark this interface with @Repository annotation.)

-   **Lets create StudentDto and Mapper**

StudentDto class will be the data transport object between database and client for us. We will not directly use the **Student** document class for these tasks. For the conversion of Student and **StudentDto** objects between each other, we will create the **IStudentMapper** interface.
```java
@AllArgsConstructor  
@NoArgsConstructor  
@SuperBuilder  
@Getter  
@Setter  
public class StudentDto {  
  private Long id;  
  private String name;  
  private String lastName;  
  private int age;  
  private String email;  
}

@Mapper(componentModel = "spring")  
public interface IStudentMapper {  
  Student toStudent(StudentDto studentDto);  
  StudentDto fromStudent(Student student);  
}
```

For Mapper you must add the following dependencies to the pom.xml file:
```xml
<!-- Mapstruct -->  
<dependency>  
    <groupId>org.mapstruct</groupId>  
    <artifactId>mapstruct</artifactId>  
    <version>1.4.2.Final</version>  
</dependency>  
<dependency>  
    <groupId>org.mapstruct</groupId>  
    <artifactId>mapstruct-processor</artifactId>  
 <version>1.4.2.Final</version>  
</dependency>
```

-   **Lets create StudentService interface and class**
```java
public interface IStudentService {  
    List<Student> findAllStudents();  
    Student findStudentById(Long id);  
    Student insertStudent(Student student);  
}
```

Our student service will consist of the above 3 methods. The implementation of these methods is shown below.
```java
@Service  
public class StudentService implements IStudentService {  
  
    private final IStudentRepository studentRepository;  
    public StudentService(IStudentRepository studentRepository) {  
        this.studentRepository = studentRepository;  
    }  
  
    @Override  
    public List<Student> findAllStudents() {  
        return studentRepository.findAll();  
    }  
  
    @Override  
    public Student findStudentById(String id) {  
        return studentRepository.findById(id).orElse(null);  
    }  
  
    @Override  
    public Student insertStudent(Student student) {  
        return studentRepository.insert(student);  
    }  
}
```
-   **Lets create StudentController**
```java
@RestController  
@AllArgsConstructor  
@RequestMapping("/api")  
public class StudentController {  
  
    private final IStudentService studentService;  
    private final IStudentMapper studentMapper;  
  
    @GetMapping("/student/all")  
    public List<StudentDto> findAllStudents() {  
        return studentService.findAllStudents().stream()  
                .map(studentMapper::fromStudent).collect(Collectors.toList());  
    }  
  
    @GetMapping("/student/id/{id}")  
    public ResponseEntity<StudentDto> findStudentById(@PathVariable String id) {  
        var student = studentService.findStudentById(id);  
        if(student == null) {  
            return ResponseEntity.notFound().build();  
        }  
        var foundStudent = studentMapper.fromStudent(student);  
        return ResponseEntity.ok(foundStudent);  
    }  
  
    @PostMapping("/student")  
    public ResponseEntity<StudentDto> insertStudent(@RequestBody StudentDto studentDto) {  
        var studentToInsert = studentMapper.toStudent(studentDto);  
        var insertedStudent = studentService.insertStudent(studentToInsert);  
        var insertedStudentDto = studentMapper.fromStudent(insertedStudent);  
        return ResponseEntity.ok(insertedStudentDto);  
    }  
}
```

Together with **StudentController**, we created all the necessary classes and interfaces for the rest api. Basically, the actions that this rest api can perform will be:

> Query all students in the database and return it as a list.
> 
> Finding and returning the student with a certain id in the database.
> 
> Saving a student in the database.

Now, to test these methods, let’s run our application and make sure that it starts serving services on port 8080, then let’s open **postman**. In this case, there are no records in the database. The first thing we will do is to save a student in the database. For this job, we need to send a **POST** request. While writing the Controller class, we stated that we would assign this request to the /**student** endpoint. Now let’s create **body** json:

![](https://miro.medium.com/v2/resize:fit:708/0*305V6cGVnZkUhUf)
POST Request

When a post request is sent to the url specified in the body above, the registration process will be completed in the mongo database. Let’s open the mongo-express interface and check:

![](https://miro.medium.com/v2/resize:fit:788/0*T8SC-1MJApl6SCE-)
mongo-express

Now let’s continue with the other methods of the service and make a request to fetch all students:

![](https://miro.medium.com/v2/resize:fit:533/0*87L8pscNfVhXOTbD)
Get Request — All Students

Response:

![](https://miro.medium.com/v2/resize:fit:533/0*eJaGsQC4lGvDVYHm)

Note that the above answer is a 1-element list. Now let’s query according to the student id:

![](https://miro.medium.com/v2/resize:fit:478/0*8worZ3kRunzxVMI)
Get Request — By Id

Response:

![](https://miro.medium.com/v2/resize:fit:478/0*SYppboVJkkshyQ0)

We tested all 3 methods we developed in Controller and confirmed that it works. You can add your own document classes and services on this basically built project. You can access the source code from the link below:

### training/Springbootmongodb at main · aedemirsen/training

### training studies and projects. Contribute to aedemirsen/training development by creating an account on GitHub.
https://github.com/aedemirsen/training/tree/main/Springbootmongodb
---

###  Spring Boot and MongoDB Quartz Scheduler using Rest API


This article demonstrates how to implement and manage Quartz Scheduler using Rest API with Spring Boot and MongoDB

### Introduction

[Quartz](http://www.quartz-scheduler.org/) is a job scheduling library that can be integrated into a wide variety of Java applications. Quartz is generally used for enterprise-class applications to support process workflow, system management actions and to provide timely services within the applications And quartz supports clustering.

[MongoDB](https://www.mongodb.com/) is a cross-platform document-oriented database program. Classified as a NoSQL database program, MongoDB uses JSON-like documents with optional schemas. MongoDB is developed by MongoDB Inc. and licensed under the Server Side Public License.

### Step 1 — Create a Spring boot project with the required dependencies.

Imitate spring boot project we can user [Spring Initializr](https://start.spring.io/). I’m using IntelliJ Idea to create the project.

I’m using Java 11 Gradle project.

![](https://miro.medium.com/v2/resize:fit:875/0*hAQa0ZNkqWn1sPgE.png)

Use below dependencies
```java
dependencies {  
    implementation 'org.springframework.boot:spring-boot-starter-data-mongodb'  
    implementation 'org.springframework.boot:spring-boot-starter-quartz'  
    implementation 'org.springframework.boot:spring-boot-starter-web'  
    implementation("org.mongodb:mongodb-driver-sync:4.0.5")  
    compile "com.novemberain:quartz-mongodb:2.2.0-rc2"  
    implementation 'com.github.lalyos:jfiglet:0.0.3'  
    compileOnly 'org.projectlombok:lombok'  
    compile 'org.springdoc:springdoc-openapi-ui:1.2.32'  
    developmentOnly 'org.springframework.boot:spring-boot-devtools'  
    annotationProcessor 'org.projectlombok:lombok'  
    testImplementation 'org.springframework.boot:spring-boot-starter-test'  
    testImplementation 'io.projectreactor:reactor-test'  
}
```
### Step 2 — Create quartz properties file with MongoDB configurations.

Create new property `quartz.properties` file inside the resources folder. And add the below configuration. Please make sure to change the mongo database URL and the database name.
```shell
### ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  
### Quartz Job Scheduling  
### ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  
###org.quartz.scheduler.instanceName=springboot-quartz-mongodb  
###org.quartz.scheduler.instanceId=AUTO  
### Use the MongoDB store  
org.quartz.jobStore.class=com.novemberain.quartz.mongodb.MongoDBJobStore  
### MongoDB URI (optional if 'org.quartz.jobStore.addresses' is set)  
org.quartz.jobStore.mongoUri=mongodb://user:password@databaseIP:port/DATABASENAME?authSource=admin  
### MongoDB Database name  
org.quartz.jobStore.dbName=DATABASENAME  
### Will be used to create collections like quartzjobs, quartztriggers, quartzcalendars, quartzlocks  
org.quartz.jobStore.collectionPrefix=onloadquartz  
### Thread count setting is ignored by the MongoDB store but Quartz requires it  
org.quartz.threadPool.threadCount=1  
### Skip running a web request to determine if there is an updated version of Quartz available for download  
org.quartz.scheduler.skipUpdateCheck=true  
### Register Quartz plugins to be executed  
### turn clustering on:  
###org.quartz.jobStore.isClustered=true  
### Must be unique for each node or AUTO to use autogenerated:  
org.quartz.scheduler.instanceId=onloadcode  
### org.quartz.scheduler.instanceId=node1  
### The same cluster name on each node:  
org.quartz.scheduler.instanceName=onloadcode  
### To setup other clusters use different collection prefix  
org.quartz.scheduler.collectionPrefix=onloadcodequartz  
### Frequency (in milliseconds) at which this instance checks-in to cluster.  
### Affects the rate of detecting failed instances.  
### Defaults to 7500 ms.  
org.quartz.scheduler.clusterCheckinInterval=10000  
### Time in millis after which a trigger can be considered as expired.  
### Defaults to 10 minutes:  
org.quartz.scheduler.triggerTimeoutMillis=1200000  
### Time in millis after which a job can be considered as expired.  
### Defaults to 10 minutes:  
org.quartz.scheduler.jobTimeoutMillis=1200000  
### Time limit in millis after which a trigger should be treated as misfired.  
### Defaults to 5000 ms.  
org.quartz.scheduler.misfireThreshold=10000  
### WriteConcern timeout in millis when writing in Replica Set.  
### Defaults to 5000 ms.  
org.quartz.scheduler.mongoOptionWriteConcernTimeoutMillis=10000
```
### Step 3 — Create configuration classes to access MongoDB from Spring Boot.

First, we have to create a config file for SpringBeanJobFactory.

`AutowiringSpringBeanJobFactory.java`
```java
package com.onloadcode.quartz.lesson.config;  
  
import org.quartz.spi.TriggerFiredBundle;  
import org.springframework.beans.BeansException;  
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;  
import org.springframework.context.ApplicationContext;  
import org.springframework.context.ApplicationContextAware;  
import org.springframework.scheduling.quartz.SpringBeanJobFactory;  
import org.springframework.stereotype.Component;  
  
@Component  
public class AutowiringSpringBeanJobFactory extends SpringBeanJobFactory  
        implements ApplicationContextAware {  
    private transient AutowireCapableBeanFactory beanFactory;  
  
    @Override  
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {  
        beanFactory = applicationContext.getAutowireCapableBeanFactory();  
    }  
  
    @Override  
    protected Object createJobInstance(TriggerFiredBundle bundle) throws Exception {  
        final Object job = super.createJobInstance(bundle);  
        beanFactory.autowireBean(job);  
        return job;  
    }  
}
```
Next, we have to create JobConfigaration class for load properties and create SchedulerFactoryBean.

`JobConfiguration.java`
```java
package com.onloadcode.quartz.lesson.config;  
  
import lombok.extern.slf4j.Slf4j;  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.beans.factory.config.PropertiesFactoryBean;  
import org.springframework.context.ApplicationContext;  
import org.springframework.context.annotation.Bean;  
import org.springframework.context.annotation.Configuration;  
import org.springframework.core.io.ClassPathResource;  
import org.springframework.scheduling.quartz.SchedulerFactoryBean;  
  
import java.io.IOException;  
import java.util.Properties;  
  
@Slf4j  
@Configuration  
public class JobConfiguration {  
    @Autowired  
    AutowiringSpringBeanJobFactory jobFactory;  
  
    @Bean  
    public SchedulerFactoryBean schedulerFactory(ApplicationContext applicationContext) {  
        try {  
            SchedulerFactoryBean factoryBean = new SchedulerFactoryBean();  
            factoryBean.setQuartzProperties(quartzProperties());  
            jobFactory.setApplicationContext(applicationContext);  
            factoryBean.setJobFactory(jobFactory);  
            factoryBean.setOverwriteExistingJobs(true);  
            factoryBean.setSchedulerName("onloadcode-job-scheduler");  
            log.info("onloadcode Quartz Scheduler initialized");  
            return factoryBean;  
        } catch (Exception e) {  
            log.error(  
                    "onloadcode Scheduler can not be initialized, the error is "  
                            + e.getMessage());  
            return null;  
        }  
    }  
  
    @Bean  
    public Properties quartzProperties() throws IOException {  
        PropertiesFactoryBean propertiesFactoryBean = new PropertiesFactoryBean();  
        propertiesFactoryBean.setLocation(new ClassPathResource("/quartz.properties"));  
        propertiesFactoryBean.afterPropertiesSet();  
        return propertiesFactoryBean.getObject();  
    }  
}
```

### Step 4 — Create a Sample Job class for testing.

Next, we have to create a sample Job class to execute a quartz job. Here we print the content of the context

`SampleJob.java`
```java
package com.onloadcode.quartz.lesson.job;  
  
import lombok.extern.slf4j.Slf4j;  
import org.quartz.Job;  
import org.quartz.JobDataMap;  
import org.quartz.JobExecutionContext;  
import org.quartz.JobExecutionException;  
  
@Slf4j  
public class SampleJob implements Job {  
    /**  
     * <p>  
     * Called by the <code>{@link Scheduler}</code> when a <code>{@link Trigger}</code>  
     * fires that is associated with the <code>Job</code>.  
     * </p>  
     *  
     * <p>  
     * The implementation may wish to set a  
     * {@link JobExecutionContext###setResult(Object) result} object on the  
     * {@link JobExecutionContext} before this method exits.  The result itself  
     * is meaningless to Quartz, but may be informative to  
     * <code>{@link JobListener}s</code> or  
     * <code>{@link TriggerListener}s</code> that are watching the job's  
     * execution.  
     * </p>  
     *  
     * @param context  
     * @throws JobExecutionException if there is an exception while executing the job.  
     */  
    @Override  
    public void execute(JobExecutionContext context) throws JobExecutionException {  
        log.info("Job triggered - Sample Job");  
        JobDataMap map = context.getMergedJobDataMap();  
        printData(map);  
        log.info("Job completed");  
    }  
  
    private void printData(JobDataMap map) {  
        log.info(">>>>>>>>>>>>>>>>>>> START: ");  
        map.entrySet().forEach(entry -> {  
            log.info(entry.getKey() + " " + entry.getValue());  
        });  
        log.info(">>>>>>>>>>>>>>>>>>> END: ");  
    }  
}
```

### Step 5 — Create Rest endpoints for operating Quartz scheduler via rest APIs.

Let’s create a rest controller class and supporting requests and response bean classes to access and operate quartz jobs.

### Controller Classes

`SchedulerManagementController.java`
```java
package com.onloadcode.quartz.lesson.controller;  
  
import com.onloadcode.quartz.lesson.bean.request.JobDetailRequestBean;  
import com.onloadcode.quartz.lesson.bean.response.SchedulerResponseBean;  
import com.onloadcode.quartz.lesson.service.SchedulerService;  
import io.swagger.v3.oas.annotations.Operation;  
import io.swagger.v3.oas.annotations.media.Content;  
import io.swagger.v3.oas.annotations.media.Schema;  
import io.swagger.v3.oas.annotations.responses.ApiResponse;  
import io.swagger.v3.oas.annotations.responses.ApiResponses;  
import io.swagger.v3.oas.annotations.tags.Tag;  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.http.ResponseEntity;  
import org.springframework.web.bind.annotation.*;  
  
import static org.springframework.http.HttpStatus.CREATED;  
import static org.springframework.http.HttpStatus.OK;  
  
@RestController  
@RequestMapping("/api/v1/scheduler")  
@Tag(  
        name = "SchedulerManagementController",  
        description = "MongoDB Quartz | Scheduler Management API")  
public class SchedulerManagementController {  
  
    public static final String JOBS = "/job-group/{jobGroup}/jobs";  
    public static final String JOBSBYNAME = "/job-group/{jobGroup}/jobs/{jobName}";  
    public static final String JOBSPAUSE = "/job-group/{jobGroup}/jobs/{jobName}/pause";  
    public static final String JOBSRESUME = "/job-group/{jobGroup}/jobs/{jobName}/resume";  
    @Autowired  
    private SchedulerService schedulerService;  
  
    @Operation(  
            summary = "MongoDB Quartz | Scheduler create a new Job",  
            description = "",  
            tags = {"SchedulerManagementController"})  
    @ApiResponses(  
            value = {  
                    @ApiResponse(  
                            responseCode = "200",  
                            description = "successful operation",  
                            content = @Content(schema = @Schema(implementation = SchedulerResponseBean.class))),  
                    @ApiResponse(  
                            responseCode = "404",  
                            description = "Scheduler Job Creation API not found",  
                            content = @Content(schema = @Schema(implementation = SchedulerResponseBean.class))),  
                    @ApiResponse(  
                            responseCode = "400",  
                            description = "Bad Request,Scheduler Job Creation type not supported",  
                            content = @Content(schema = @Schema(implementation = SchedulerResponseBean.class))),  
                    @ApiResponse(  
                            responseCode = "500",  
                            description = "Failure",  
                            content = @Content(schema = @Schema(implementation = SchedulerResponseBean.class)))  
            })  
    @PostMapping(path = JOBS)  
    public ResponseEntity<SchedulerResponseBean> createJob(  
            @PathVariable String jobGroup, @RequestBody JobDetailRequestBean jobDetailRequestBean) {  
        return new ResponseEntity<SchedulerResponseBean>(  
                schedulerService.createJob(jobGroup, jobDetailRequestBean), CREATED);  
    }  
  
    @Operation(  
            summary = "MongoDB Quartz | Scheduler find a Job",  
            description = "",  
            tags = {"SchedulerManagementController"})  
    @ApiResponses(  
            value = {  
                    @ApiResponse(  
                            responseCode = "200",  
                            description = "successful operation",  
                            content = @Content(schema = @Schema(implementation = SchedulerResponseBean.class))),  
                    @ApiResponse(  
                            responseCode = "404",  
                            description = "Scheduler Job find API not found",  
                            content = @Content(schema = @Schema(implementation = SchedulerResponseBean.class))),  
                    @ApiResponse(  
                            responseCode = "400",  
                            description = "Bad Request,Scheduler Job find type not supported",  
                            content = @Content(schema = @Schema(implementation = SchedulerResponseBean.class))),  
                    @ApiResponse(  
                            responseCode = "500",  
                            description = "Failure",  
                            content = @Content(schema = @Schema(implementation = SchedulerResponseBean.class)))  
            })  
    @GetMapping(path = JOBSBYNAME)  
    public ResponseEntity<SchedulerResponseBean> findJob(  
            @PathVariable String jobGroup, @PathVariable String jobName) {  
        return new ResponseEntity<>(schedulerService.findJob(jobGroup, jobName), OK);  
    }  
  
    @Operation(  
            summary = "MongoDB Quartz | Scheduler update an existing Job",  
            description = "",  
            tags = {"SchedulerManagementController"})  
    @ApiResponses(  
            value = {  
                    @ApiResponse(  
                            responseCode = "200",  
                            description = "successful operation",  
                            content = @Content(schema = @Schema(implementation = SchedulerResponseBean.class))),  
                    @ApiResponse(  
                            responseCode = "404",  
                            description = "Scheduler Job update API not found",  
                            content = @Content(schema = @Schema(implementation = SchedulerResponseBean.class))),  
                    @ApiResponse(  
                            responseCode = "400",  
                            description = "Bad Request,Scheduler Job update type not supported",  
                            content = @Content(schema = @Schema(implementation = SchedulerResponseBean.class))),  
                    @ApiResponse(  
                            responseCode = "500",  
                            description = "Failure",  
                            content = @Content(schema = @Schema(implementation = SchedulerResponseBean.class)))  
            })  
    @PutMapping(path = JOBSBYNAME)  
    public ResponseEntity<SchedulerResponseBean> updateJob(  
            @PathVariable String jobGroup,  
            @PathVariable String jobName,  
            @RequestBody JobDetailRequestBean jobDetailRequestBean) {  
        return new ResponseEntity<>(schedulerService.updateJob(jobGroup, jobName, jobDetailRequestBean), OK);  
    }  
  
    @Operation(  
            summary = "MongoDB Quartz | Scheduler delete Job",  
            description = "",  
            tags = {"SchedulerManagementController"})  
    @ApiResponses(  
            value = {  
                    @ApiResponse(  
                            responseCode = "200",  
                            description = "successful operation",  
                            content = @Content(schema = @Schema(implementation = SchedulerResponseBean.class))),  
                    @ApiResponse(  
                            responseCode = "404",  
                            description = "Scheduler Job delete API not found",  
                            content = @Content(schema = @Schema(implementation = SchedulerResponseBean.class))),  
                    @ApiResponse(  
                            responseCode = "400",  
                            description = "Bad Request,Scheduler Job delete type not supported",  
                            content = @Content(schema = @Schema(implementation = SchedulerResponseBean.class))),  
                    @ApiResponse(  
                            responseCode = "500",  
                            description = "Failure",  
                            content = @Content(schema = @Schema(implementation = SchedulerResponseBean.class)))  
            })  
    @DeleteMapping(path = JOBSBYNAME)  
    public ResponseEntity<SchedulerResponseBean> deleteJob(  
            @PathVariable String jobGroup, @PathVariable String jobName) {  
        return new ResponseEntity<>(schedulerService.deleteJob(jobGroup, jobName), OK);  
    }  
  
    @Operation(  
            summary = "MongoDB Quartz | Scheduler pause Job",  
            description = "",  
            tags = {"SchedulerManagementController"})  
    @ApiResponses(  
            value = {  
                    @ApiResponse(  
                            responseCode = "200",  
                            description = "successful operation",  
                            content = @Content(schema = @Schema(implementation = SchedulerResponseBean.class))),  
                    @ApiResponse(  
                            responseCode = "404",  
                            description = "Scheduler Job pause API not found",  
                            content = @Content(schema = @Schema(implementation = SchedulerResponseBean.class))),  
                    @ApiResponse(  
                            responseCode = "400",  
                            description = "Bad Request,Scheduler Job pause type not supported",  
                            content = @Content(schema = @Schema(implementation = SchedulerResponseBean.class))),  
                    @ApiResponse(  
                            responseCode = "500",  
                            description = "Failure",  
                            content = @Content(schema = @Schema(implementation = SchedulerResponseBean.class)))  
            })  
    @PatchMapping(path = JOBSPAUSE)  
    public ResponseEntity<SchedulerResponseBean> pauseJob(  
            @PathVariable String jobGroup, @PathVariable String jobName) {  
        return new ResponseEntity<>(schedulerService.pauseJob(jobGroup, jobName), OK);  
    }  
  
    @Operation(  
            summary = "MongoDB Quartz | Scheduler resume Job",  
            description = "",  
            tags = {"SchedulerManagementController"})  
    @ApiResponses(  
            value = {  
                    @ApiResponse(  
                            responseCode = "200",  
                            description = "successful operation",  
                            content = @Content(schema = @Schema(implementation = SchedulerResponseBean.class))),  
                    @ApiResponse(  
                            responseCode = "404",  
                            description = "Scheduler Job resume API not found",  
                            content = @Content(schema = @Schema(implementation = SchedulerResponseBean.class))),  
                    @ApiResponse(  
                            responseCode = "400",  
                            description = "Bad Request,Scheduler Job resume type not supported",  
                            content = @Content(schema = @Schema(implementation = SchedulerResponseBean.class))),  
                    @ApiResponse(  
                            responseCode = "500",  
                            description = "Failure",  
                            content = @Content(schema = @Schema(implementation = SchedulerResponseBean.class)))  
            })  
    @PatchMapping(path = JOBSRESUME)  
    public ResponseEntity<SchedulerResponseBean> resumeJob(  
            @PathVariable String jobGroup, @PathVariable String jobName) {  
        return new ResponseEntity<>(schedulerService.resumeJob(jobGroup, jobName), OK);  
    }  
}
```
### Request Bean Classes

JobDetailRequestBean.java
```java
package com.onloadcode.quartz.lesson.bean.request;  
  
import com.fasterxml.jackson.annotation.JsonIgnore;  
import com.fasterxml.jackson.annotation.JsonProperty;  
import com.onloadcode.quartz.lesson.job.SampleJob;  
import lombok.Data;  
import org.quartz.JobDataMap;  
import org.quartz.JobDetail;  
import org.quartz.Trigger;  
  
import javax.validation.constraints.NotBlank;  
import javax.validation.constraints.NotEmpty;  
import java.io.Serializable;  
import java.util.*;  
import java.util.stream.Collectors;  
  
import static org.quartz.JobBuilder.newJob;  
  
@Data  
public class JobDetailRequestBean implements Serializable {  
    @NotBlank  
    private String name;  
    private String group;  
    @JsonProperty("triggers")  
    private List<TriggerDetailsRequestBean> triggerDetails = new ArrayList<>();  
    @NotEmpty  
    private String orgCode;  
    @NotEmpty  
    private String jobType;  
    @NotEmpty  
    private String uniqueKey;  
    private Map<String, Object> data = new LinkedHashMap<>();  
  
    public static JobDetailRequestBean buildJobDetail(JobDetail jobDetail, List<? extends Trigger> triggersOfJob) {  
        List<TriggerDetailsRequestBean> triggerDetailsRequestBeanList = triggersOfJob.stream()  
                .map(TriggerDetailsRequestBean::buildTriggerDetails)  
                .collect(Collectors.toList());  
  
        return new JobDetailRequestBean()  
                .setName(jobDetail.getKey().getName())  
                .setGroup(jobDetail.getKey().getGroup())  
                .setOrgCode(jobDetail.getJobDataMap().getString("orgCode"))  
                .setJobType(jobDetail.getJobDataMap().getString("jobType"))  
                .setUniqueKey(jobDetail.getJobDataMap().getString("uniqueKey"))  
                .setData((Map<String, Object>) jobDetail.getJobDataMap().get("data"))  
                .setTriggerDetails(triggerDetailsRequestBeanList);  
    }  
  
    public JobDetailRequestBean setTriggerDetails(final List<TriggerDetailsRequestBean> triggerDetails) {  
        this.triggerDetails = triggerDetails;  
        return this;  
    }  
  
    public JobDetailRequestBean setData(final Map<String, Object> data) {  
        this.data = data;  
        return this;  
    }  
  
    public JobDetailRequestBean setUniqueKey(String uniqueKey) {  
        this.uniqueKey = uniqueKey;  
        return this;  
    }  
  
    public JobDetailRequestBean setJobType(String jobType) {  
        this.jobType = jobType;  
        return this;  
    }  
  
    public JobDetailRequestBean setOrgCode(String orgCode) {  
        this.orgCode = orgCode;  
        return this;  
    }  
  
    public JobDetailRequestBean setGroup(final String group) {  
        this.group = group;  
        return this;  
    }  
  
    public JobDetailRequestBean setName(final String name) {  
        this.name = name;  
        return this;  
    }  
  
    public JobDetail buildJobDetail() {  
        JobDataMap jobDataMap = new JobDataMap(getData());  
        jobDataMap.put("orgCode", orgCode);  
        jobDataMap.put("jobType", jobType);  
        jobDataMap.put("uniqueKey", uniqueKey);  
        jobDataMap.put("data", data);  
        return newJob(SampleJob.class)  
                .withIdentity(getName(), getGroup())  
                .usingJobData(jobDataMap)  
                .build();  
    }  
  
    @JsonIgnore  
    public Set<Trigger> buildTriggers() {  
        return triggerDetails.stream()  
                .map(TriggerDetailsRequestBean::buildTrigger)  
                .collect(Collectors.toCollection(LinkedHashSet::new));  
    }  
}
```
TriggerDetailsRequestBean.java
```java
package com.onloadcode.quartz.lesson.bean.request;  
  
import lombok.Data;  
import org.quartz.JobDataMap;  
import org.quartz.Trigger;  
  
import javax.validation.constraints.NotBlank;  
import java.io.Serializable;  
import java.sql.Date;  
import java.time.LocalDateTime;  
import java.util.TimeZone;  
  
import static java.time.ZoneId.systemDefault;  
import static java.util.UUID.randomUUID;  
import static org.quartz.CronExpression.isValidExpression;  
import static org.quartz.CronScheduleBuilder.cronSchedule;  
import static org.quartz.SimpleScheduleBuilder.simpleSchedule;  
import static org.quartz.TriggerBuilder.newTrigger;  
import static org.springframework.util.StringUtils.isEmpty;  
  
@Data  
public class TriggerDetailsRequestBean implements Serializable {  
    @NotBlank  
    private String name;  
    private String group;  
    private LocalDateTime fireTime;  
    private String cron;  
  
    /**  
     * Build trigger details trigger details request bean.  
     *  
     * @param trigger the trigger  
     * @return the trigger details request bean  
     */  
    public static TriggerDetailsRequestBean buildTriggerDetails(Trigger trigger) {  
        return new TriggerDetailsRequestBean()  
                .setName(trigger.getKey().getName())  
                .setGroup(trigger.getKey().getGroup())  
                .setFireTime((LocalDateTime) trigger.getJobDataMap().get("fireTime"))  
                .setCron(trigger.getJobDataMap().getString("cron"));  
    }  
  
    /**  
     * Sets cron.  
     *  
     * @param cron the cron  
     * @return the cron  
     */  
    public TriggerDetailsRequestBean setCron(final String cron) {  
        this.cron = cron;  
        return this;  
    }  
  
    /**  
     * Sets fire time.  
     *  
     * @param fireTime the fire time  
     * @return the fire time  
     */  
    public TriggerDetailsRequestBean setFireTime(final LocalDateTime fireTime) {  
        this.fireTime = fireTime;  
        return this;  
    }  
  
    /**  
     * Sets group.  
     *  
     * @param group the group  
     * @return the group  
     */  
    public TriggerDetailsRequestBean setGroup(final String group) {  
        this.group = group;  
        return this;  
    }  
  
    /**  
     * Sets name.  
     *  
     * @param name the name  
     * @return the name  
     */  
    public TriggerDetailsRequestBean setName(final String name) {  
        this.name = name;  
        return this;  
    }  
  
    /**  
     * Build trigger trigger.  
     *  
     * @return the trigger  
     */  
    public Trigger buildTrigger() {  
        if (!isEmpty(cron)) {  
            if (!isValidExpression(cron))  
                throw new IllegalArgumentException(  
                        "Provided expression " + cron + " is not a valid cron expression");  
            return newTrigger()  
                    .withIdentity(buildName(), group)  
                    .withSchedule(  
                            cronSchedule(cron)  
                                    .withMisfireHandlingInstructionFireAndProceed()  
                                    .inTimeZone(TimeZone.getTimeZone(systemDefault())))  
                    .usingJobData("cron", cron)  
                    .build();  
        } else if (!isEmpty(fireTime)) {  
            JobDataMap jobDataMap = new JobDataMap();  
            jobDataMap.put("fireTime", fireTime);  
            return newTrigger()  
                    .withIdentity(buildName(), group)  
                    .withSchedule(simpleSchedule().withMisfireHandlingInstructionNextWithExistingCount())  
                    .startAt(Date.from(fireTime.atZone(systemDefault()).toInstant()))  
                    .usingJobData(jobDataMap)  
                    .build();  
        }  
        throw new IllegalStateException("unsupported trigger details " + this);  
    }  
  
    private String buildName() {  
        return isEmpty(name) ? randomUUID().toString() : name;  
    }  
}
```
### Response Bean Classes

`SchedulerResponseBean.java`
```java
package com.onloadcode.quartz.lesson.bean.response;  
  
import lombok.AllArgsConstructor;  
import lombok.Builder;  
import lombok.Data;  
import lombok.NoArgsConstructor;  
import org.springframework.http.HttpStatus;  
  
@Data  
@AllArgsConstructor  
@NoArgsConstructor  
@Builder  
public class SchedulerResponseBean {  
    private Object result;  
    private HttpStatus resultCode;  
}
```
### Step 6 — Create a Services class for change quartz scheduler operations.

Let’s create a service class to operate quartz scheduler basic operations.

`SchedulerService.java`
```java
package com.onloadcode.quartz.lesson.service;  
  
import com.onloadcode.quartz.lesson.bean.request.JobDetailRequestBean;  
import com.onloadcode.quartz.lesson.bean.response.SchedulerResponseBean;  
import lombok.RequiredArgsConstructor;  
import lombok.extern.slf4j.Slf4j;  
import org.quartz.*;  
import org.springframework.http.HttpStatus;  
import org.springframework.stereotype.Service;  
  
import java.util.Objects;  
import java.util.Optional;  
import java.util.Set;  
  
import static org.quartz.JobKey.jobKey;  
  
@Slf4j  
@Service  
@RequiredArgsConstructor  
public class SchedulerService {  
  
    private final Scheduler scheduler;  
  
    /**  
     * Create job scheduler response bean.  
     *  
     * @param jobGroup             the job group  
     * @param jobDetailRequestBean the job detail request bean  
     * @return the scheduler response bean  
     */  
    public SchedulerResponseBean createJob(  
            String jobGroup, JobDetailRequestBean jobDetailRequestBean) {  
        SchedulerResponseBean responseBean = new SchedulerResponseBean();  
        jobDetailRequestBean.setGroup(jobGroup);  
        JobDetail jobDetail = jobDetailRequestBean.buildJobDetail();  
        Set<Trigger> triggersForJob = jobDetailRequestBean.buildTriggers();  
        log.info("About to save job with key - {}", jobDetail.getKey());  
        try {  
            scheduler.scheduleJob(jobDetail, triggersForJob, false);  
            log.info("Job with key - {} saved sucessfully", jobDetail.getKey());  
            responseBean.setResult(jobDetailRequestBean);  
            responseBean.setResultCode(HttpStatus.CREATED);  
        } catch (SchedulerException e) {  
            log.error(  
                    "Could not save job with key - {} due to error - {}",  
                    jobDetail.getKey(),  
                    e.getLocalizedMessage());  
            throw new IllegalArgumentException(e.getLocalizedMessage());  
        }  
        return responseBean;  
    }  
  
    /**  
     * Find job scheduler response bean.  
     *  
     * @param jobGroup the job group  
     * @param jobName  the job name  
     * @return the scheduler response bean  
     */  
    public SchedulerResponseBean findJob(String jobGroup, String jobName) {  
        SchedulerResponseBean responseBean = new SchedulerResponseBean();  
        try {  
            JobDetail jobDetail = scheduler.getJobDetail(jobKey(jobName, jobGroup));  
            if (Objects.nonNull(jobDetail))  
                responseBean.setResult(  
                        Optional.of(  
                                JobDetailRequestBean.buildJobDetail(  
                                        jobDetail, scheduler.getTriggersOfJob(jobKey(jobName, jobGroup)))));  
            responseBean.setResultCode(HttpStatus.OK);  
  
        } catch (SchedulerException e) {  
            String errorMsg =  
                    String.format(  
                            "Could not find job with key - %s.%s  due to error -  %s",  
                            jobGroup, jobName, e.getLocalizedMessage());  
            log.error(errorMsg);  
            responseBean.setResultCode(HttpStatus.INTERNALSERVERERROR);  
            responseBean.setResult(errorMsg);  
        }  
        log.warn("Could not find job with key - {}.{}", jobGroup, jobName);  
        return responseBean;  
    }  
  
    /**  
     * Update job scheduler response bean.  
     *  
     * @param jobGroup             the job group  
     * @param jobName              the job name  
     * @param jobDetailRequestBean the job detail request bean  
     * @return the scheduler response bean  
     */  
    public SchedulerResponseBean updateJob(  
            String jobGroup, String jobName, JobDetailRequestBean jobDetailRequestBean) {  
        SchedulerResponseBean responseBean = new SchedulerResponseBean();  
        try {  
            JobDetail oldJobDetail = scheduler.getJobDetail(jobKey(jobName, jobGroup));  
            if (Objects.nonNull(oldJobDetail)) {  
                JobDataMap jobDataMap = oldJobDetail.getJobDataMap();  
                jobDataMap.put("orgCode", jobDetailRequestBean.getOrgCode());  
                jobDataMap.put("jobType", jobDetailRequestBean.getJobType());  
                jobDataMap.put("uniqueKey", jobDetailRequestBean.getUniqueKey());  
                jobDataMap.put("data", jobDetailRequestBean.getData());  
                JobBuilder jb = oldJobDetail.getJobBuilder();  
                JobDetail newJobDetail = jb.usingJobData(jobDataMap).storeDurably().build();  
                scheduler.addJob(newJobDetail, true);  
                log.info("Updated job with key - {}", newJobDetail.getKey());  
                responseBean.setResult(jobDetailRequestBean);  
                responseBean.setResultCode(HttpStatus.CREATED);  
            }  
            log.warn("Could not find job with key - {}.{} to update", jobGroup, jobName);  
        } catch (SchedulerException e) {  
            String errorMsg =  
                    String.format(  
                            "Could not find job with key - %s.%s to update due to error -  %s",  
                            jobGroup, jobName, e.getLocalizedMessage());  
            log.error(errorMsg);  
            responseBean.setResultCode(HttpStatus.INTERNALSERVERERROR);  
            responseBean.setResult(errorMsg);  
        }  
        return responseBean;  
    }  
  
    /**  
     * Delete job scheduler response bean.  
     *  
     * @param jobGroup the job group  
     * @param jobName  the job name  
     * @return the scheduler response bean  
     */  
    public SchedulerResponseBean deleteJob(String jobGroup, String jobName) {  
        SchedulerResponseBean responseBean = new SchedulerResponseBean();  
        try {  
            scheduler.deleteJob(jobKey(jobName, jobGroup));  
            String msg = "Deleted job with key - " + jobGroup + "." + jobName;  
            responseBean.setResult(msg);  
            responseBean.setResultCode(HttpStatus.OK);  
            log.info(msg);  
        } catch (SchedulerException e) {  
            String errorMsg =  
                    String.format(  
                            "Could not find job with key - %s.%s to Delete due to error -  %s",  
                            jobGroup, jobName, e.getLocalizedMessage());  
            log.error(errorMsg);  
            responseBean.setResultCode(HttpStatus.INTERNALSERVERERROR);  
            responseBean.setResult(errorMsg);  
        }  
        return responseBean;  
    }  
  
    /**  
     * Pause job scheduler response bean.  
     *  
     * @param jobGroup the job group  
     * @param jobName  the job name  
     * @return the scheduler response bean  
     */  
    public SchedulerResponseBean pauseJob(String jobGroup, String jobName) {  
        SchedulerResponseBean responseBean = new SchedulerResponseBean();  
        try {  
            scheduler.pauseJob(jobKey(jobName, jobGroup));  
            String msg = "Paused job with key - " + jobGroup + "." + jobName;  
            responseBean.setResult(msg);  
            responseBean.setResultCode(HttpStatus.OK);  
        } catch (SchedulerException e) {  
            String errorMsg =  
                    String.format(  
                            "Could not find job with key - %s.%s  due to error -  %s",  
                            jobGroup, jobName, e.getLocalizedMessage());  
            log.error(errorMsg);  
            responseBean.setResultCode(HttpStatus.INTERNALSERVERERROR);  
            responseBean.setResult(errorMsg);  
        }  
        return responseBean;  
    }  
  
    /**  
     * Resume job scheduler response bean.  
     *  
     * @param jobGroup the job group  
     * @param jobName  the job name  
     * @return the scheduler response bean  
     */  
    public SchedulerResponseBean resumeJob(String jobGroup, String jobName) {  
        SchedulerResponseBean responseBean = new SchedulerResponseBean();  
        try {  
            scheduler.resumeJob(jobKey(jobName, jobGroup));  
            String msg = "Resumed job with key - " + jobGroup + "." + jobName;  
            responseBean.setResult(msg);  
            responseBean.setResultCode(HttpStatus.OK);  
        } catch (SchedulerException e) {  
            String errorMsg =  
                    String.format(  
                            "Could not find job with key - %s.%s  due to error -  %s",  
                            jobGroup, jobName, e.getLocalizedMessage());  
            log.error(errorMsg);  
            responseBean.setResultCode(HttpStatus.INTERNALSERVERERROR);  
            responseBean.setResult(errorMsg);  
        }  
        return responseBean;  
    }  
}
```

### Step 7 — Create Open API configurations.

Let’s Configure open API configurations for swagger documentations

Create OpenApiConfig class file

`OpenApiConfig.java`
```java
package com.onloadcode.quartz.lesson.config;  
  
import io.swagger.v3.oas.models.Components;  
import io.swagger.v3.oas.models.OpenAPI;  
import io.swagger.v3.oas.models.info.Contact;  
import io.swagger.v3.oas.models.info.Info;  
import io.swagger.v3.oas.models.info.License;  
import org.springframework.beans.factory.annotation.Value;  
import org.springframework.context.annotation.Bean;  
import org.springframework.context.annotation.Configuration;  
  
import java.util.Arrays;  
import java.util.HashSet;  
import java.util.Set;  
  
@Configuration  
public class OpenApiConfig {  
    /**  
     * The constant DEFAULTCONTACT.  
     */  
    public static final Contact DEFAULTCONTACT =  
            new Contact()  
                    .name("Onload Code")  
                    .email("author@onloadcode.com")  
                    .url("www.onloadcode.com");  
  
    /**  
     * The constant LICENSE.  
     */  
    public static final License LICENSE =  
            new License().name("Apache 2.0").url("http://www.apache.org/licenses/LICENSE-2.0.html");  
  
    private static final Set<String> DEFAULTPRODUCESANDCONSUMES =  
            new HashSet<>(Arrays.asList("application/json", "application/xml"));  
    /**  
     * The Api controller package.  
     */  
    @Value("${api-package}")  
    public String APICONTROLLERPACKAGE;  
    /**  
     * The Application name.  
     */  
    @Value("${application.name}")  
    public String APPLICATIONNAME;  
    /**  
     * The Application description.  
     */  
    @Value("${application.description}")  
    public String APPLICATIONDESCRIPTION;  
  
    /**  
     * Custom open api open api.  
     *  
     * @return the open api  
     */  
    @Bean  
    public OpenAPI customOpenAPI() {  
        return new OpenAPI().components(new Components()).info(apiEndPointsInfo());  
    }  
  
    private Info apiEndPointsInfo() {  
        return new Info()  
                .title(APPLICATIONNAME)  
                .description(APPLICATIONDESCRIPTION)  
                .contact(DEFAULTCONTACT)  
                .license(LICENSE)  
                .version("1.0.0");  
    }  
}
```
Add properties to the `application.properties` file.
```shell
api-package=com.onloadcode.quartz.lesson.controller  
application.name=quarts-scheduling-spring-boot-mongodb  
application.description=Quartz Scheduler using Rest API with Spring Boot and MongoDB
```
### Step 8 -Test the application.

Let’s run the application and verify its run without any issues

After successfully application up we can check the mongo database and see 4 quartz collection on there with our given prefix.

![](https://miro.medium.com/v2/resize:fit:521/0*bq-BK1ttvuRG3us6.png)
quartz collections

We can see all rest endpoints from open api documentation

[http://localhost:8080/swagger-ui/index.html?configUrl=/v3/api-docs/](http://localhost:8080/swagger-ui/index.html?configUrl=%2Fv3%2Fapi-docs%2F)

![](https://miro.medium.com/v2/resize:fit:875/0*SpuBivBxJozO6REI.png)
Open API documentations

### Demo — Create a Job

Let’s try to create a new job using the rest of API.

request cURL
```shell
curl --location --request POST 'http://localhost:8080/api/v1/scheduler/job-group/TESTTEMPLATE/jobs'   
--header 'Content-Type: application/json'   
--data-raw '{  
    "name": "testJ1",  
    "orgCode": "SIN",  
    "uniqueKey": "uniqueKey",  
    "jobType": "QUERYTEMPLATE",  
    "jobProperties": [  
        {  
            "propertyKey": "template-name",  
            "propertyValue": "temp-1"  
        }  
    ],  
    "triggers": [  
        {  
            "name": "testJ1",  
            "group": "QUERYTEMPLATE",  
            "cron": "0/30 0/1 * 1/1 * ? *"  
        }  
    ]  
}'
```
the result will be `201 Created`
```json
{  
    "result": {  
        "name": "testJ1",  
        "group": "TESTTEMPLATE",  
        "orgCode": "SIN",  
        "jobType": "QUERYTEMPLATE",  
        "uniqueKey": "uniqueKey",  
        "data": {},  
        "triggers": [  
            {  
                "name": "testJ1",  
                "group": "QUERYTEMPLATE",  
                "fireTime": null,  
                "cron": "0/30 0/1 * 1/1 * ? *"  
            }  
        ]  
    },  
    "resultCode": "CREATED"  
}
```
According to this given parameters every 30 second this job will trigger and we can see on the logs

2020-12-06 20:23:00.034  INFO 33552 --- [edulerWorker-1] c.o.quartz.lesson.job.SampleJob          : Job triggered - Sample Job  
2020-12-06 20:23:00.034  INFO 33552 --- [edulerWorker-1] c.o.quartz.lesson.job.SampleJob          : >>>>>>>>>>>>>>>>>>> START:   
2020-12-06 20:23:00.034  INFO 33552 --- [edulerWorker-1] c.o.quartz.lesson.job.SampleJob          : cron 0/30 0/1 * 1/1 * ? *  
2020-12-06 20:23:00.034  INFO 33552 --- [edulerWorker-1] c.o.quartz.lesson.job.SampleJob          : data {}  
2020-12-06 20:23:00.034  INFO 33552 --- [edulerWorker-1] c.o.quartz.lesson.job.SampleJob          : orgCode SIN  
2020-12-06 20:23:00.034  INFO 33552 --- [edulerWorker-1] c.o.quartz.lesson.job.SampleJob          : uniqueKey uniqueKey  
2020-12-06 20:23:00.034  INFO 33552 --- [edulerWorker-1] c.o.quartz.lesson.job.SampleJob          : jobType QUERYTEMPLATE  
2020-12-06 20:23:00.034  INFO 33552 --- [edulerWorker-1] c.o.quartz.lesson.job.SampleJob          : >>>>>>>>>>>>>>>>>>> END:   
2020-12-06 20:23:00.034  INFO 33552 --- [edulerWorker-1] c.o.quartz.lesson.job.SampleJob          : Job completed  
2020-12-06 20:23:00.043  INFO 33552 --- [edulerWorker-1] c.n.quartz.mongodb.dao.LocksDao          : Removing trigger lock QUERYTEMPLATE.testJ1.onloadcode  
2020-12-06 20:23:00.050  INFO 33552 --- [edulerWorker-1] c.n.quartz.mongodb.dao.LocksDao          : Trigger lock QUERYTEMPLATE.testJ1.onloadcode removed.  
2020-12-06 20:23:00.067  INFO 33552 --- [SchedulerThread] c.n.quartz.mongodb.dao.LocksDao          : Inserting lock for trigger QUERYTEMPLATE.testJ1  
2020-12-06 20:23:00.079  INFO 33552 --- [SchedulerThread] c.n.quartz.mongodb.TriggerRunner         : Acquired trigger: QUERYTEMPLATE.testJ1

### Demo — Find a Job

Let us use the rest API to search for a job we created.

request cURL
```shell
curl --location --request GET 'http://localhost:8080/api/v1/scheduler/job-group/TESTTEMPLATE/jobs/testJ1'   
--data-raw ''
```
the result will be `200 OK`
```json
{  
    "result": {  
        "name": "testJ1",  
        "group": "TESTTEMPLATE",  
        "orgCode": "SIN",  
        "jobType": "QUERYTEMPLATE",  
        "uniqueKey": "uniqueKey",  
        "data": {},  
        "triggers": [  
            {  
                "name": "testJ1",  
                "group": "QUERYTEMPLATE",  
                "fireTime": null,  
                "cron": "0/30 0/1 * 1/1 * ? *"  
            }  
        ]  
    },  
    "resultCode": "OK"  
}
```
### Demo — Update a Job

Let’s update the existing job we created.

request cURL
```shell
curl --location --request PUT 'http://localhost:8080/api/v1/scheduler/job-group/TESTTEMPLATE/jobs/testJ1'   
--header 'Content-Type: application/json'   
--data-raw '{  
    "name": "testJ1",  
    "orgCode": "SIN",  
    "uniqueKey": "uniqueKey",  
    "jobType": "QUERYTEMPLATE",  
    "data":   
        {  
            "propertyKey": "template-name",  
            "propertyValue": "temp-1"  
        }  
    ,  
    "triggers": [  
        {  
            "name": "testJ1",  
            "group": "QUERYTEMPLATE",  
            "cron": "0/30 0/1 * 1/1 * ? *"  
        }  
    ]  
}'
```
the result will be `200 OK`
```json
{  
    "result": {  
        "name": "testJ1",  
        "group": null,  
        "orgCode": "SIN",  
        "jobType": "QUERYTEMPLATE",  
        "uniqueKey": "uniqueKey",  
        "data": {  
            "propertyKey": "template-name",  
            "propertyValue": "temp-1"  
        },  
        "triggers": [  
            {  
                "name": "testJ1",  
                "group": "QUERYTEMPLATE",  
                "fireTime": null,  
                "cron": "0/30 0/1 * 1/1 * ? *"  
            }  
        ]  
    },  
    "resultCode": "CREATED"  
}
```
You can try to do pause, resume, and delete operations as well.

### Conclusion

Thanks for reading the article how to implement and manage Quartz Scheduler using Rest API with Spring Boot and MongoDB

https://github.com/authoronloadcode/Quarts-Scheduling-using-Rest-API-with-Spring-Boot-and-MongoDB
---

# Spring batch job as Spring cloud task

[**Spring Cloud Task**](https://docs.spring.io/spring-cloud-task/docs/current/reference/html/) is a framework for creating and orchestrating short-lived microservices. So It’s a good fit for Spring Batch Jobs as the JVM persists until the job is completed and subsequently exits, freeing up resources.

![Spring batch cloud task](https://miro.medium.com/v2/resize:fit:589/1*O8Qa7wglc0l85KjToljnmA.jpeg)

### Introduction

This project is a simple example of how to implement a Spring Batch Job as a Spring Cloud Task. It implements a hypothetical use case to generate Credit card statements containing aggregate daily transaction amounts date-wise for a particular month.

-   Reads Credit card accounts from a MongoDB collection `accounts` in database `accountdb` and partition on these account numbers for high performance.
-   Reads transactions from MongoDB collection `transactions` in database `transactiondb` using pagination. Aggregates transaction amounts per day.
-   Processes the date-wise transaction amount and writes the output to MongoDB collection `statements` in database `statementdb`.
-   It is fault-tolerant i.e. try to recover from transient failures and skip bad records.
-   It supports restartability from last failure point.

### Installation

Clone git repository and import in your favourite IDE as either Maven or Gradle project. Requires Java 21, Spring boot 3.2.0+ and Spring batch 5.1.0+.

> Source code available on Github [**spring-boot-batch-cloud-task**](https://github.com/officiallysingh/spring-boot-batch-cloud-task)

### Docker compose

Application is bundled with `[**Spring boot Docker compose**](https://docs.spring.io/spring-boot/docs/current/reference/htmlsingle/###features.docker-compose)`.

-   If you have docker installed, then simply run the application in `docker` profile by passing `spring.profiles.active=docker` as program argument from your IDE.
-   Depending on your current working directory in IDE, you may need to change `spring.docker.compose.file=spring-boot-mongodb-auditing/compose.yml` to`spring.docker.compose.file=compose.yml` in `[**application-docker.yml**](https://github.com/officiallysingh/spring-boot-batch-cloud-task/blob/main/src/main/resources/config/application-docker.yml)`
-   Make sure the host ports mapped in `[**Docker compose file**](https://github.com/officiallysingh/spring-boot-batch-cloud-task/blob/main/compose.yml)` are available or change the ports and do the respective changes in database configurations`[**application-docker.yml**](https://github.com/officiallysingh/spring-boot-batch-cloud-task/blob/main/src/main/resources/config/application-docker.yml)`

### Explicit MongoDB and Postgres installation

Change to your MongoDB URI in `[**application.yml**](https://github.com/officiallysingh/spring-boot-batch-cloud-task/blob/main/src/main/resources/config/application.yml)` file as follows.

spring:  
  datasource:  
    url: <Your Postgres Database URL>/<Your Database name>  
    username: <Your Database username>  
    password: <Your Database password>  
  data:  
    mongodb:  
      uri: <Your MongoDB URI>

> Make sure **flyway** is enabled as Spring Batch and Spring Cloud Task needs their `[schema](https://github.com/officiallysingh/spring-boot-batch-cloud-task/blob/main/src/main/resources/db/migration/V1.1scdfschema.sql)` to be created. Used internally by the framework to persist and retrieve metadata about the jobs and tasks.

### Sample Data

On first run, it creates schema and populates sample data for past three months into MongoDB collections. For details refer to `[DataPopulator](https://github.com/officiallysingh/spring-boot-batch-cloud-task/blob/main/src/main/java/com/ksoot/batch/DataPopulator.java)`. Depending on dataset size to be created the application may take a while to start, the first time. In subsequent runs, it will start quickly. You can change the number of accounts to be created as follows.

// Total number of Credit card accounts to be created  
// For each account upto 10 transactions are created for each day of last 3 months  
private static final int ACCOUNTSCOUNT = 1000;  
// Number of records to be created in a batch  
private static final int BATCHSIZE = 1000;

### Job Parameters

Job may take following optional parameters, defaults are taken if not specified. Refer to `[StatementJobTask](https://github.com/officiallysingh/spring-boot-batch-cloud-task/blob/main/src/main/java/com/ksoot/batch/StatementJobTask.java)` for more details.

-   `cardNumbers` - Comma separated list of Credit card numbers to process. If not specified, all accounts are processed. Example:`cardNumbers=5038-1972-4899-4180,5752-0862-5835-3760`
-   `month` - Month (IST) in ISO format yyyy-MM, for which statement is to be generated. If not specified, last month is taken. Example:`month=2023-11`
-   `forceRestart` - If set to true, job is restarted even if its last execution with same parameters was successful. If not specified`false` is taken as default, in this case if its last execution with same parameters was successful then Job would not execute again. Example:`forceRestart=true`

> These parameters can be passed as program arguments from your IDE as follows.

--cardNumbers=5038-1972-4899-4180,5752-0862-5835-3760 --month=2023-11 --forceRestart=true

![](https://miro.medium.com/v2/resize:fit:875/1*zsrnf43ZhcyNbHSUkhODQQ.png)

### Implementation

The application uses `[**spring-batch-commons**](https://github.com/officiallysingh/spring-batch-commons)` to avail common Spring Batch components, out of box. Maven

<dependency>  
    <groupId>io.github.officiallysingh</groupId>  
    <artifactId>spring-batch-commons</artifactId>  
    <version>1.0</version>  
</dependency>

Or Gradle

implementation 'io.github.officiallysingh:spring-batch-commons:1.0'

### Job Configuration

Defines a Partitioned Job with a single step as follows. For details, refer to `[StatementJobConfiguration](https://github.com/officiallysingh/spring-boot-batch-cloud-task/blob/main/src/main/java/com/ksoot/batch/job/StatementJobConfiguration.java)`. Reader and Writer are self-explanatory. Processor should contain all business logic and Multiple processors can be chained together using`[CompositeItemProcessor](https://docs.spring.io/spring-batch/docs/current/api/org/springframework/batch/item/support/CompositeItemProcessor.html)`.`[BeanValidatingItemProcessor](https://docs.spring.io/spring-batch/docs/current/api/org/springframework/batch/item/validator/BeanValidatingItemProcessor.html)` is used to validate the input data.

```java
@Configuration  
@AutoConfigureAfter(value = {BatchConfiguration.class})  
class StatementJobConfiguration extends JobConfigurationSupport<DailyTransaction, Statement> {  
  
  @Bean  
  Job statementJob(  
      @Qualifier("statementJobPartitioner") final AccountsPartitioner statementJobPartitioner,  
      final ItemReader<DailyTransaction> transactionReader,  
      final ItemProcessor<DailyTransaction, Statement> statementProcessor,  
      final ItemWriter<Statement> statementWriter)  
      throws Exception {  
    return newPartitionedJob(  
        AppConstants.STATEMENTJOBNAME,  
        statementJobPartitioner,  
        transactionReader,  
        statementProcessor,  
        statementWriter);  
  }  
  
  @Bean  
  @StepScope  
  AccountsPartitioner statementJobPartitioner(  
      @Qualifier("accountMongoTemplate") final MongoTemplate accountMongoTemplate,  
      @Value("###{jobParameters['" + AppConstants.JOBPARAMNAMECARDNUMBERS + "']}")  
          final List<String> cardNumbers) {  
    return new AccountsPartitioner(accountMongoTemplate, this.batchProperties, cardNumbers);  
  }  
  
  @Bean  
  @StepScope  
  MongoAggregationPagingItemReader<DailyTransaction> transactionReader(  
      @Qualifier("transactionMongoTemplate") final MongoTemplate transactionMongoTemplate,  
      @Value("###{jobParameters['" + AppConstants.JOBPARAMNAMESTATEMENTMONTH + "']}")  
          final String month,  
      @Value("###{stepExecutionContext['" + AppConstants.CARDNUMBERSKEY + "']}")  
          final String cardNumbers) {  
  
    final YearMonth statementMonth = YearMonth.parse(month);  
    List<String> cardNumbersList =  
        StringUtils.isNotBlank(cardNumbers)  
            ? Arrays.asList(cardNumbers.split(PARTITIONDATAVALUESEPARATOR))  
            : Collections.emptyList();  
  
    OffsetDateTime fromDateTime =  
        statementMonth.atDay(1).atStartOfDay().atOffset(DateTimeUtils.ZONEOFFSETIST);  
    OffsetDateTime tillDateTime =  
        statementMonth  
            .atEndOfMonth()  
            .plusDays(1)  
            .atStartOfDay()  
            .atOffset(DateTimeUtils.ZONEOFFSETIST);  
    Criteria condition = null;  
    if (CollectionUtils.isNotEmpty(cardNumbersList)) {  
      condition =  
          Criteria.where("cardnumber")  
              .in(cardNumbersList)  
              .and("datetime")  
              .gte(fromDateTime)  
              .lt(tillDateTime);  
    } else {  
      condition = Criteria.where("datetime").gte(fromDateTime).lt(tillDateTime);  
    }  
  
    final AggregationOperation[] aggregationOperations =  
        new AggregationOperation[] {  
          match(condition),  
          project("cardnumber", "amount", "datetime")  
              .andExpression("{$toDate: '$datetime'}")  
              .as("date"),  
          group("cardnumber", "date").sum("amount").as("amount"),  
          project("cardnumber", "date", "amount").andExclude("id"),  
          sort(Sort.Direction.ASC, "cardnumber", "date")  
        };  
  
    MongoAggregationPagingItemReader<DailyTransaction> itemReader =  
        new MongoAggregationPagingItemReader<>();  
    itemReader.setName("transactionsReader");  
    itemReader.setTemplate(transactionMongoTemplate);  
    itemReader.setCollection("transactions");  
    itemReader.setTargetType(DailyTransaction.class);  
    itemReader.setAggregationOperation(aggregationOperations);  
    itemReader.setPageSize(this.batchProperties.getPageSize());  
    return itemReader;  
  }  
  
  @Bean  
  CompositeItemProcessor<DailyTransaction, Statement> statementProcessor(  
      final BeanValidatingItemProcessor<DailyTransaction> beanValidatingDailyTransactionProcessor) {  
    final CompositeItemProcessor<DailyTransaction, Statement> compositeProcessor =  
        new CompositeItemProcessor<>();  
    compositeProcessor.setDelegates(  
        Arrays.asList(beanValidatingDailyTransactionProcessor, new StatementProcessor()));  
    return compositeProcessor;  
  }  
  
  @Bean  
  BeanValidatingItemProcessor<DailyTransaction> beanValidatingDailyTransactionProcessor(  
      final LocalValidatorFactoryBean validatorFactory) {  
    return new BeanValidatingItemProcessor<>(validatorFactory);  
  }  
  
  // Idempotent upsert  
  @Bean  
  MongoItemWriter<Statement> statementWriter(  
      @Qualifier("mongoTemplate") final MongoTemplate statementMongoTemplate) {  
    return MongoItemWriters.<Statement>template(statementMongoTemplate)  
        .collection("statements")  
        .idGenerator(  
            (Statement item) ->  
                MongoIdGenerator.compositeIdGenerator(item.cardNumber(), item.transactionDate()))  
        .build();  
  }  
}
```

> Any component needing access to `stepExecutionContext` must be defined as `@StepScope` bean and to access `jobParameters` or `jobExecutionContext` must be defined as `@JobScope` bean

### Job Partitioning

If specific `cardNumbers` are passed as job parameters, then the job is partitioned on these account numbers only. Otherwise, all accounts are processed in parallel by partitioning on account numbers. For details refer to`[AccountsPartitioner](https://github.com/officiallysingh/spring-boot-batch-cloud-task/blob/main/src/main/java/com/ksoot/batch/job/AccountsPartitioner.java)`.
```java
@Slf4j  
public class AccountsPartitioner extends AbstractPartitioner {  
  
  private final MongoTemplate accountMongoTemplate;  
  
  private final List<String> cardNumbers;  
  
  AccountsPartitioner(  
      @Qualifier("accountMongoTemplate") final MongoTemplate accountMongoTemplate,  
      final BatchProperties batchProperties,  
      final List<String> cardNumbers) {  
    super(batchProperties, AppConstants.CARDNUMBERSKEY);  
    this.accountMongoTemplate = accountMongoTemplate;  
    this.cardNumbers = cardNumbers;  
  }  
  
  @Override  
  public List<String> partitioningList() {  
    final Bson condition =  
        CollectionUtils.isNotEmpty(this.cardNumbers)  
            ? in("cardnumber", this.cardNumbers)  
            : Filters.empty();  
    return this.accountMongoTemplate  
        .getCollection("accounts")  
        .find(condition)  
        .projection(fields(excludeId(), include("cardnumber")))  
        .sort(ascending("cardnumber"))  
        .map(doc -> doc.getString("cardnumber"))  
        .into(new ArrayList<>());  
  }  
}
```

### Data Sources configurations

Different databases can be configured for `statementdb`, `accountdb` and `transactiondb` or all can be set to same database URI as follows. **Converters** and **Codecs** are registered to support `OffsetDateTime` and `ZonedDateTime` types in `MongoTemplate`. Refer to`[MongoDBConfig](https://github.com/officiallysingh/spring-boot-batch-cloud-task/blob/main/src/main/java/com/ksoot/batch/config/MongoDBConfig.java)` for details.
```yml
spring:  
  data:  
    mongodb:  
      uri: <Statement DB URI>  
      database: statementdb  
      account:  
        uri: <Account DB URI>  
        database: accountdb  
      transaction:  
        uri: <Transaction DB URI>  
        database: transactiondb
```
### Configurations

Following are the configuration properties to customize default Spring batch behaviour.
```yml
batch:  
  chunk-size: 100  
  skip-limit: 10  
  max-retries: 3  
  backoff-initial-delay: PT3S  
  backoff-multiplier: 2  
  page-size: 300  
  partition-size: 16  
  trigger-partitioning-threshold: 100  
###  task-executor: applicationTaskExecutor  
###  run-id-sequence: runidsequence
```

-   `**batch.chunk-size**` : Number of items that are processed in a single transaction by a chunk-oriented step, Default: 100.
-   `**batch.skip-limit**` : Maximum number of items to skip as per configured Skip policy, exceeding which fails the job, Default: 10.
-   `**batch.max-retries**` : Maximum number of retry attempts as per configured Retry policy, exceeding which fails the job, Default: 3.
-   `**batch.backoff-initial-delay**` : Time duration (in java.time.Duration format) to wait before the first retry attempt is made after a failure, Default: false.
-   `**batch.backoff-multiplier**` : Factor by which the delay between consecutive retries is multiplied, Default: 3.
-   `**batch.page-size**` : Number of records to be read in each page by Paging Item readers, Default: 100.
-   `**batch.partition-size**` : Number of partitions that will be used to process the data concurrently. Should be optimized as per available machine resources, Default: 8.
-   `**batch.trigger-partitioning-threshold**` : Minimum number of records to trigger partitioning otherwise it could be counter productive to do partitioning, Default: 100.
-   `**batch.task-executor**` : Bean name of the Task Executor to be used for executing the jobs. By default `SyncTaskExecutor` is used. Set to`applicationTaskExecutor` to use `SimpleAsyncTaskExecutor` provided by Spring. Or use any other custom`TaskExecutor` and set the bean name here. Don't set this property in Spring cloud task but Spring Rest applications.
-   `**batch.run-id-sequence**` : Run Id database sequence name, Default: `runidsequence`.

> It is recommended not to set `batch.task-executor` to `AsyncTaskExecutor` as the application may not exit because of that. Spring cloud task should be executed synchronously.


---
# MongoDB map keys with dots in Spring Data 
![](https://miro.medium.com/v2/resize:fit:875/1*xIaW3XsJ90GoEoi2EZzGOA.jpeg)

I recently had the need to store historical events in a MongoDB document. The requirement was to do this via a [Map](https://docs.oracle.com/javase/8/docs/api/java/util/Map.html) having an [Instant](https://docs.oracle.com/javase/8/docs/api/java/time/Instant.html) as a key and some data as its value. Naively setting this up in a Spring Data MongoDB document would look like this:
```java
@Data  
@Document  
public class MyDocument {  
  
    @Id  
    private String id;  
    private Map<Instant, String> map;  
}
```
Having implemented the corresponding test, I promptly encountered something unexpected:

org.springframework.data.mapping.MappingException: Map key 2019-11-16T18:56:35.823Z contains dots but no replacement was configured! Make sure map keys don't contain dots in the first place or configure an appropriate replacement!at org.springframework.data.mongodb.core.convert.MappingMongoConverter.potentiallyEscapeMapKey(MappingMongoConverter.java:865)  
 at org.springframework.data.mongodb.core.convert.MappingMongoConverter.prepareMapKey(MappingMongoConverter.java:847)  
 at   
[...]

Of course, if you think about it, that makes perfect sense. Since paths within documents are separated by dots, having dots in a map might obviously clash. Think about the following invalid non-time-based example document using a map:
```json
{  
    "id" : "507f191e810c19729de860ea"  
    "fileMap" : {  
        "application.yml" : "available"  
    }   
}
```
If you now wanted to know what the application.yml’s value is, you would probably think of the following path:

fileMap.application.yml

However, Mongo would expect a value to be present as in the following example:
```java
{  
    "id" : "507f191e810c19729de860ea"  
    "fileMap" : {  
        "application" : {  
            "yml" : "available"  
        }  
    }   
}
```
So, that’s why you simply cannot model a map key containing dots.

Coming back to my original requirement of using Java’s Instant, you see why a default conversion to the ISO format containing dots as a separator for milliseconds will not work. Luckily, Spring Data gives you a decent exception message leading you towards the right path.

Spring Data converts Java types using the [MappingMongoConverter](https://docs.spring.io/spring-data/mongodb/docs/current/api/org/springframework/data/mongodb/core/convert/MappingMongoConverter.html) which out of the box comes with a great variety of converters including those for the [JSR-310](https://jcp.org/en/jsr/detail?id=310) time API types. The one for Instants converts to ISO format. That’s, of course, no issue when converting plain fields. Only in the context of maps a clash occurs. One option would be to write a custom converter that maps Instants to something other than ISO format. However, there’s an easier option that comes with the above mentioned MappingMongoConverter. You can simply tell it what you want to use as a replacement for potentially occurring dots in map keys. This can easily be configured, for example like this:
```java
@Configuration  
public class MongoMapKeyDotReplacementConfiguration {  
  
    @Autowired  
    public void setMapKeyDotReplacement(MappingMongoConverter mongoConverter) {  
        mongoConverter.setMapKeyDotReplacement("#");  
    }  
}
```

That’s pretty much it. You should probably choose your replacement wisely in order to not get into another conflict and also maintain readability. You may find a working test case [here](https://github.com/marcus-j/spring-examples/blob/master/spring-data-mongodb/src/test/java/com/marcusjanke/examples/MongoMapKeyDotReplacementTest.java).
---
# A Deep Dive into Change Data Capture and Auditing with MongoDB in Spring Boot

### First I want you to know what’s Change data capture and why we need this

Change data capture is short know as CDC, A process of tracking the changes in the data of a particular Database and logging those changes.

We need CDC for audit purposes to track. the Audit might help us to understand the changes like who, when, and what were made change on the specific record. we can use this log to recover or triage the flow of edits made to the data.

There are several ways to achieve CDC. like in the application layer which is writing the records or capturing the changes directly on the database layer like [Debezium](https://debezium.io/)

We are taking the approach to track changes made to the documents directly on the database. with the help of the change stream provided by the Mongo DB.

Assume we have an application that does the CRUD operations which is written in spring boot.

Or in existing spring boot application which writes data, You can capture Mongo Events before saving . below example snippet i am updating the trace id to track horizontal and vertical changes.

![](https://miro.medium.com/v2/resize:fit:875/1*nxwaJ8PpG1Bm86Kpfmncpw.png)
This is just a snapshot of class @EventListener

To capture data before make change for update or delete:
```java
@EventListener  
public void onAfterConvert(AfterConvertEvent<T> event) {  
    try {  
        Document source = event.getDocument();  
        if (Boolean.TRUE.equals(MongoAuditTrailService.isAudited(event.getSource().getClass())) && Objects.nonNull(source)) {  
            String identityKey = MongoAuditTrailService.getIdentityKey(event.getSource());  
            InheritableContextHolder.setObject(identityKey, source);  
        }  
    } catch (Exception e) {  
        log.error(ERRORMESSAGE, e.getMessage(), e);  
    }  
}
```

Note: class MongoAuditTrailService and InheritableContextHolder will provide or detail later…

To get data after save change:
```java
@EventListener  
public void onAfterSave(AfterSaveEvent<T> event) {  
    try {  
        Document newSource = event.getDocument();  
        if (Objects.nonNull(newSource)) {  
            String identityKey = MongoAuditTrailService.getIdentityKey(event.getSource());  
            Document oldSource = InheritableContextHolder.getObject(identityKey, Document.class);  
            doAudit(oldSource, event);  
            InheritableContextHolder.remove(identityKey);  
        }  
    } catch (Exception e) {  
        log.error(ERRORMESSAGE, e.getMessage(), e);  
    }  
}
```
doAudit function to make logic and check what ever data has been change or not in each fields
```java
private void doAudit(Document oldSource, AfterSaveEvent<T> event) {  
    Document newSource = event.getDocument();  
    T source = event.getSource();  
    try {  
        if (Boolean.TRUE.equals(MongoAuditTrailService.isAudited(source.getClass())) && Objects.nonNull(newSource)) {  
            AuditTrailDto auditTableDto = MongoAuditTrailService.getCreatedData(source);  
            if ("NA".equalsIgnoreCase(auditTableDto.getTableName()))  
                auditTableDto.setTableName(event.getCollectionName());  
            if (Objects.nonNull(oldSource)) {  
                List<AuditTrailFieldDto> changedFields = MongoAuditTrailService.getChangedFields(source.getClass(), oldSource, newSource);  
                if (ObjectUtils.isNotEmpty(changedFields)) {  
                    auditTableDto.setFields(changedFields);  
                    if (!String.valueOf(ActionStatus.DELETED).equalsIgnoreCase(auditTableDto.getAction()))  
                        auditTableDto.setAction(String.valueOf(ActionStatus.MODIFIED));  
                    MongoAuditTrailService.generateLog(auditTableDto);  
                }  
            } else {  
                MongoAuditTrailService.generateLog(auditTableDto);  
            }  
        }  
    } catch (Exception e) {  
        log.error(ERRORMESSAGE, e.getMessage(), e);  
    }  
}
```
Here is my DTO classes:
```java
@Data  
@ToString  
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)  
public class AuditTrailDto {  
    private String tableName;  
    private String action;  
    private List<AuditTrailFieldDto> fields;  
    private List<AuditTrailPrimaryKeyDto> primaryKeys;  
}

@Data  
@AllArgsConstructor  
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)  
public class AuditTrailFieldDto {  
    private String fieldName;  
    private String currentValue;  
    private String previousValue;  
}

@Data  
@AllArgsConstructor  
@NoArgsConstructor  
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)  
public class AuditTrailPrimaryKeyDto {  
    private String fieldName;  
    private String fieldValue;  
}

@Getter  
@Setter  
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)  
public class AuditTrailTableDto {  
    private String traceId;  
    private String tableName;  
    private List<AuditTrailPrimaryKeyDto> primaryKeys;  
}
```
And here is my MongoAuditTrailService class and I will explain each function detail:

![](https://miro.medium.com/v2/resize:fit:875/1*eJhBXjGJ-ZCknJ0q1Wa9jg.png)
This is just a snapshot of class

1.  getTableName: a static function to get collection name of each entity.
```java
public static String getTableName(Class<?> clazz) {  
    Optional<org.springframework.data.mongodb.core.mapping.Document> optionalDocument = Optional.ofNullable(clazz.getAnnotation(org.springframework.data.mongodb.core.mapping.Document.class));  
    return optionalDocument.map(document -> ObjectUtils.isNotEmpty(document.collection()) ? document.collection() : document.value()).orElse("NA").replace("`", "");  
}
```
2. generateLog: a static function to generate log and you also can doing produce a messaging(kafka) or save in database.
```java
@SneakyThrows  
public static void generateLog(AuditTrailDto dto) {  
    log.info("here is data logn {}", new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(dto));  
}
```
3. isAudited: a static method to check the entity or collection need to capture or make audit or not.
```java
public static boolean isAudited(Class<?> clazz) {  
    String tableName = getTableName(clazz);  
    if (TABLEIGNORES.contains(tableName))  
        return Boolean.FALSE;  
    String[] tables = {"*"};  
    for (String table : tables) {  
        if (tableName.equalsIgnoreCase(table) || ALL.equals(table))  
            return Boolean.TRUE;  
    }  
    return Boolean.FALSE;  
}
```
4. getIdentityKey: a static function to get the identity of each request.
```java
public static String getIdentityKey(Object object) {  
    return String.format("%s(%s)", getTableName(object.getClass()).toUpperCase(), org.springframework.util.ObjectUtils.getIdentityHexString(object));  
}
```
5. isModified: a static function to each field has been modified or not.
```java
static boolean isModified(Object currentValue, Object previousValue) {  
    return Objects.isNull(currentValue) ? !Objects.isNull(previousValue) : ClassUtil.isJavaLangType(previousValue) && !currentValue.equals(previousValue);  
}
```
6. getPrimaryKeyValues: a static function to get list of primary key dto of each collection or entity.
```java
public static List<AuditTrailPrimaryKeyDto> getPrimaryKeyValues(Object object) {  
    List<Field> primaryKeyFields = getPrimaryKeyFields(object);  
    List<AuditTrailPrimaryKeyDto> primaryKeyValues = new ArrayList<>();  
    for (Object propNameObject : new BeanMap(object).keySet()) {  
        String fieldName = (String) propNameObject;  
        Object value = new BeanMap(object).get(fieldName);  
        primaryKeyFields.forEach(item -> {  
            if (item.getName().equalsIgnoreCase(fieldName))  
                primaryKeyValues.add(new AuditTrailPrimaryKeyDto(caseFieldName(fieldName), String.valueOf(value)));  
        });  
    }  
    return primaryKeyValues;  
}
```
7. getPrimaryKeyFields: a static function to get list of primary key of each collection or entity.
```java
public static List<Field> getPrimaryKeyFields(Object entity) {  
    List<Field> primaryFields = new ArrayList<>();  
    Class<?> current = entity.getClass();  
    while (current != null && current != Object.class) {  
        List<Field> ids = Arrays.stream(current.getDeclaredFields()).filter(field -> Objects.nonNull(field.getAnnotation(org.springframework.data.annotation.Id.class))).collect(Collectors.toList());  
        primaryFields.addAll(ids);  
        current = current.getSuperclass();  
    }  
    return primaryFields;  
}
```
8. getAllFields: a static function to get all fields from collection or entity.
```java
public static List<Field> getAllFields(Class<?> clazz) {  
    Set<Field> fields = new HashSet<>();  
    Class<?> current = clazz;  
    while (ObjectUtils.isNotEmpty(current) && !("java.lang.Object".equalsIgnoreCase(current.getName()))) {  
        List<Field> auditFields = Arrays.stream(current.getDeclaredFields()).collect(Collectors.toList());  
        if (!auditFields.isEmpty()) {  
            fields.addAll(auditFields);  
        } else {  
            fields.addAll(Arrays.asList(current.getDeclaredFields()));  
        }  
        current = current.getSuperclass();  
    }  
    return new ArrayList<>(fields);  
}
```
9. getChangedFields: a static function to get all fields changed after save change.
```java
public static List<AuditTrailFieldDto> getChangedFields(Class<?> entity, Document oldSource, Document newSource) {  
    List<AuditTrailFieldDto> changedFields = new ArrayList<>();  
    List<Field> fields = getAllFields(entity);  
    for (Field field : fields) {  
        org.springframework.data.mongodb.core.mapping.Field col = field.getAnnotation(org.springframework.data.mongodb.core.mapping.Field.class);  
        String fieldName = Objects.nonNull(col) && StringUtils.isNoneBlank(col.value()) ? col.value() : caseFieldName(field.getName());  
        if (!FIELDIGNORES.contains(fieldName)) {  
            if (Objects.nonNull(oldSource)) {  
                Object oldValue = oldSource.get(fieldName);  
                Object newValue = newSource.get(fieldName);  
                boolean modified = isModified(newValue, oldValue);  
                if (modified)  
                    changedFields.add(new AuditTrailFieldDto(caseFieldName(fieldName), String.valueOf(newValue), String.valueOf(oldValue)));  
            } else {  
                Object newValue = newSource.get(fieldName);  
                changedFields.add(new AuditTrailFieldDto(fieldName, String.valueOf(newValue), StringUtils.EMPTY));  
            }  
        }  
    }  
    return changedFields;  
}
```

10. caseFieldName: case to snake case
```java
private static String caseFieldName(String fieldName) {  
    return StringUtil.camelCaseToSnakeCase(fieldName);  
}

```
11. isDeleted: a static function to check soft delete.
```java
public static boolean isDeleted(Object object) {  
    List<Field> fields = getAllFields(object.getClass());  
    for (Field field : fields) {  
        String fieldName = field.getName();  
        if (fieldName.equalsIgnoreCase("status") && List.of(String.valueOf(ActionStatus.DELETED), "DELETE").contains(String.valueOf(new BeanMap(object).get(fieldName)))) {  
            return Boolean.TRUE;  
        }  
    }  
    return Boolean.FALSE;  
}
```
12. getCreatedData: a static function to generate data of audit.
```java
public static AuditTrailDto getCreatedData(Object object) {  
    AuditTrailDto table = new AuditTrailDto();  
    List<AuditTrailFieldDto> fields = new ArrayList<>();  
    List<AuditTrailPrimaryKeyDto> primaryKeyValues = getPrimaryKeyValues(object);  
    List<String> primaryKeyFields = primaryKeyValues.stream().map(AuditTrailPrimaryKeyDto::getFieldName).collect(Collectors.toList());  
    AtomicReference<BeanMap> map = new AtomicReference<>(new BeanMap(object));  
    map.get().keySet().stream().map(String.class::cast).forEach(fieldName -> {  
        Object currentValue = map.get().get(fieldName);  
        if (!FIELDIGNORES.contains(fieldName) && ObjectUtils.isNotEmpty(currentValue) && ClassUtil.isJavaLangType(currentValue.getClass()) && !primaryKeyFields.contains(caseFieldName(fieldName)))  
            fields.add(new AuditTrailFieldDto(caseFieldName(fieldName), String.valueOf(currentValue), StringUtils.EMPTY));  
    });  
    table.setTableName(getTableName(object.getClass()));  
    table.setFields(fields);  
    table.setPrimaryKeys(primaryKeyValues);  
    if (isDeleted(object))  
        table.setAction(String.valueOf(ActionStatus.DELETED));  
    else  
        table.setAction(String.valueOf(ActionStatus.CREATED));  
    return table;  
}
```
### InheritableContextHolder
```java
public final class InheritableContextHolder {  
    private static final InheritableThreadLocal<Map<String, Object>> THREADLOCAL = new InheritableThreadLocal() {  
        @Override  
        protected Map<String, Object> initialValue() {  
            return new ConcurrentHashMap<>();  
        }  
    };  
  
    private InheritableContextHolder() {  
    }  
  
    public static void setObject(final String key, final Object value) {  
        if (StringUtils.isEmpty(key) || Objects.isNull(value)) {  
            log.debug("Key {} or value {} is empty cannot put into inheritable thread local", key, value);  
            return;  
        }  
        THREADLOCAL.get().put(key, value);  
    }  
    public static <T> T getObject(final String key, final Class<T> class) {  
        return ObjectUtils.cast(getObject(key), class);  
    }  
  
    public static Object getObject(final String key) {  
        return THREADLOCAL.get().get(key);  
    }  
  
    public static Object remove(final String key) {  
        return THREADLOCAL.get().remove(key);  
    }  
}
```
To test this I made a simple api to create and update and the result:

![](https://miro.medium.com/v2/resize:fit:1250/1*yiEkU5FZuDY4X-PXLptt5A.png)
Sample Audit log for create record

![](https://miro.medium.com/v2/resize:fit:1250/1*0I7vJSpF8JS8zCmFEDmmTg.png)
Sample Audit log for update record

https://github.com/phsophea101/poc-spring/tree/poc-mongodb-audit?source=postpage-----f5dfd34e68ef---------------------------------------

---
# Mastering Data Evolution with Change Data Capture in Spring Boot and Spring Data JPA 


1.  onSave: is Override function to get data on save record and work only when new record only.  
    org.hibernate.Interceptor Called before an object is saved. The interceptor may modify the state, which will be used for the SQL INSERT and propagated to the persistent object
```java
@Override  
public boolean onSave(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {  
    try {  
        this.onSaveAction(entity, ActionStatus.CREATED);  
    } catch (Exception e) {  
        log.error("Audit onSave error occurred {}", e.getMessage(), e);  
    }  
    return super.onSave(entity, id, state, propertyNames, types);  
}
```
2. onDelete: is Override function to get data on delete hard record only.Called before an object is deleted. It is not recommended that the interceptor modify the state.
```java
@Override  
public void onDelete(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {  
    try {  
        this.onSaveAction(entity, ActionStatus.DELETED);  
    } catch (Exception e) {  
        log.error("Audit onDelete error occurred {}", e.getMessage(), e);  
    } finally {  
        super.onDelete(entity, id, state, propertyNames, types);  
    }  
}
```
3. onSaveAction: a function to save current thread or state for save or delete record
```java
private void onSaveAction(Object entity, ActionStatus action) {  
    boolean audited = HibernateAuditTrailService.isAudited(entity.getClass());  
    if (audited) {  
        AuditTrailDto audit = new AuditTrailDto();  
        String tableName = HibernateAuditTrailService.getTableName(entity.getClass());  
        audit.setTableName(tableName);  
        audit.setAction(String.valueOf(action));  
        String key = HibernateAuditTrailService.getIdentityKey(entity);  
        InheritableContextHolder.setObject(key, audit);  
    }  
}
```
4. postFlush: is Override function work or fire after trasantional that actually ends in execution of the SQL statements required. we override this because on save or delete their is no current data.Called after a flush that actually ends in execution of the SQL statements required to synchronize in-memory state with the database.
```java
@Override  
public void postFlush(Iterator entities) {  
    try {  
        while (entities.hasNext()) {  
            this.postData(entities.next());  
        }  
    } catch (Exception e) {  
        log.error("Audit postFlush error occurred {}", e.getMessage(), e);  
    }  
    super.postFlush(entities);  
}
```
5. postData: a function to produce data for save or delete…
```java
private void postData(Object object) {  
    if (HibernateAuditTrailService.isAudited(object.getClass())) {  
        String key = HibernateAuditTrailService.getIdentityKey(object);  
        AuditTrailDto table = InheritableContextHolder.getObject(key, AuditTrailDto.class);  
        if (ObjectUtils.isNotEmpty(table)) {  
            String action = table.getAction();  
            table = HibernateAuditTrailService.getCreatedData(object);  
            if (ObjectUtils.isNotEmpty(action))  
                table.setAction(action);  
            if (ObjectUtils.isNotEmpty(table.getFields())) {  
                HibernateAuditTrailService.generateLog(table);  
                InheritableContextHolder.remove(key);  
            }  
        }  
    }  
}
```
6. onFlushDirty: a Override function work or fire on something change,Called when an object is detected to be dirty, during a flush. The interceptor may modify the detected currentState, which will be propagated to both the database and the persistent object. Note that not all flushes end in actual synchronization with the database, in which case the new currentState will be propagated to the object, but not necessarily (immediately) to the database. It is strongly recommended that the interceptor not modify the previousState.
```java
@Override  
public boolean onFlushDirty(Object entity, Serializable id, Object[] currentState, Object[] previousState, String[] propertyNames, Type[] types) {  
    try {  
        boolean audited = HibernateAuditTrailService.isAudited(entity.getClass());  
        if (audited) {  
            AuditTrailDto audit = HibernateAuditTrailService.makeAuditData(entity, propertyNames, currentState, previousState);  
            if (ObjectUtils.isNotEmpty(audit.getFields())) {  
                if (ObjectUtils.isEmpty(audit.getAction()))  
                    audit.setAction(String.valueOf(ActionStatus.MODIFIED));  
                HibernateAuditTrailService.generateLog(audit);  
            }  
        }  
    } catch (Exception e) {  
        log.error("Audit onFlushDirty error occurred {}", e.getMessage(), e);  
    }  
    return super.onFlushDirty(entity, id, currentState, previousState, propertyNames, types);  
}
```
**To register the extended class to bean interceptor**
```java
@Component  
@ConditionalOnClass(value = {EntityManagerFactory.class, SessionFactory.class})  
public class BeanHibernateAuditInterceptor implements HibernatePropertiesCustomizer {  
    private static final String HIBERNATESESSIONFACTORYINTERCEPTOR = "hibernate.sessionfactory.interceptor";  
  
    @Override  
    public void customize(Map<String, Object> hibernateProperties) {  
        hibernateProperties.put(HIBERNATESESSIONFACTORYINTERCEPTOR, new HibernateAuditInterceptor());  
    }  
}
```
To test this I used a same simple api to create and update and the result:

![](https://miro.medium.com/v2/resize:fit:875/1*bIbEAWj0-BEchm-DR6gCjw.png)
Sample Audit log for create record

![](https://miro.medium.com/v2/resize:fit:875/1*uVajb97XeYTJrJcqChToBg.png)
Sample Audit log for update record

[

### GitHub - phsophea101/poc-spring at poc-hibernate-audit
https://github.com/phsophea101/poc-spring/tree/poc-hibernate-audit
---
# Solving the Mystery of Date and Timezone Issues in Spring Boot with MongoDB

### The Problem

It all started when I was building a **Spring Boot REST API** backed by **MongoDB**.  
The task was simple: create, update, and retrieve records with `createdDate` fields.

But somewhere between creating a new record and fetching it back, **the date seemed to shift** — hours mysteriously added or subtracted, depending on who and where you were accessing the data from.

In India (IST), the date looked one way.  
In a Docker container set to UTC, it looked another.  
Even between my local machine and Postman, results were inconsistent.  
**Dates were losing their meaning.**

What Was Happening?

After some digging, I realized several hidden layers were playing with my timestamps:

-   **MongoDB** stores dates in **UTC** by default.
-   **Spring Boot** serializes dates based on the server’s **local timezone** unless configured.
-   **Java’s** `**Date**` class has no timezone — it's just a point in time.
-   **Browsers** show dates in **user’s local timezone**, creating even more confusion.

In short:  
**The same Date** was being seen **differently** depending on how/where it was interpreted

### The Solution

After a few late nights and a lot of coffee ☕, I found a way to fix it — once and for all.

![](https://miro.medium.com/v2/resize:fit:875/1*lhSc-yvWzrlJVyKVzGTVdA.png)
Set Default timezone at the application startup

### 1. Use Timezone-Aware Classes

Instead of `java.util.Date`, I started using `ZonedDateTime`:

**private ZonedDateTime createdAt;**

This way, time **and** timezone travel together.

### 2. Configure Jackson (JSON Mapper)

To make sure Spring Boot serializes dates consistently, I added this to application.properties

![](https://miro.medium.com/v2/resize:fit:875/1*oCfSgnOlyJWHizir12v5mQ.png)
Declare in properties

**spring.jackson.time-zone=UTC  
**Now, all dates are serialized and deserialized in UTC by default.

### 3. Format Dates Explicitly

When formatting dates manually, I always set the timezone:

![](https://miro.medium.com/v2/resize:fit:875/1*h1ySYaUsRFnhghcI9yyYQ.png)
Use of code with timezone
```java
SimpleDateFormat sdf = new SimpleDateFormat(“yyyy-MM-dd”);  
sdf.setTimeZone(TimeZone.getTimeZone(“UTC”));  
String formattedDate = sdf.format(new Date());
```
No more “oops” moments when displaying dates.

### 4. Make the Database and Backend Speak the Same Language

MongoDB stores timestamps in UTC, so now my application also **writes and reads** dates in UTC.

No guessing games, no surprises.

### Lessons Learned

-   **Never trust your local machine’s timezone** when working on backend systems.
-   **Always use ISO-8601 format** (`yyyy-MM-dd'T'HH:mm:ssXXX`) when sending dates over APIs.
-   **Be explicit** about timezones everywhere — in code, in configs, and in the database.
-   **Frontend should handle** any timezone conversion needed for users’ local view.
---
### Spring boot MongoDB Audit logging and Full-text search

### Introduction

[**Hibernate Envers**](https://hibernate.org/orm/envers) provides Auditing of JPA entities, but no such library provides out of box support for Auditing MongoDB entities.  
Auditing is a cross-cutting concern, should be kept separate from business logic and available to be applied declaratively.  
This project provides a simple solution to Audit MongoDB entities.

Requires Java 21, Spring boot 3.2.0+ and MongoDB 4.2+.

### Implementation

-   `[**Auditable**](https://github.com/officiallysingh/spring-boot-mongodb-auditing/blob/main/src/main/java/com/ksoot/mongodb/Auditable.java)` is an `Annotation` to be used to make MongoDB entity classes eligible for Auditing. The entity classes not annotated with`Auditable` will not be audited.
-   `[**AuditingMongoEventListener**](https://github.com/officiallysingh/spring-boot-mongodb-auditing/blob/main/src/main/java/com/ksoot/mongodb/AuditingMongoEventListener.java)` is the main class responsible for auditing. While application startup it finds all collections enabled for Auditing and creates Audit collections for same and prepare Audit metadata for each collection such as Version field name, Audit collection name, etc. Then it listens to eligible Entity object changes and creates Audit records.
-   `[**MongoDBConfig**](https://github.com/officiallysingh/spring-boot-mongodb-auditing/blob/main/src/main/java/com/ksoot/mongodb/MongoDBConfig.java)` is custom configuration class for MongoDB.
-   `[**AuditEvent**](https://github.com/officiallysingh/spring-boot-mongodb-auditing/blob/main/src/main/java/com/ksoot/mongodb/AuditEvent.java)` is class to persist and retrieve Audit records. It defines following fields.  
    - `**id**` : Unique identifier for Audit record.  
    - `**OffsetDateTime**` : When the change happened.  
    - `**actor**` : Audit Username if available in `SecurityContextHolder`, otherwise it will be set as `SYSTEM`.  
    - `**revision**` : Auto-increment numeric value for each change to a particular record.  
    - `**type**` : Type of change to a record such as `CREATED`, `UPDATED`, `DELETED`.  
    - `**collectionName**` : Source MongoDB collection name.  
    - `**source**` : Snapshot of Audited record.
-   `[**MongoDBModule**](https://github.com/officiallysingh/spring-boot-mongodb-auditing/blob/main/src/main/java/com/ksoot/mongodb/MongoDBModule.java)` registers custom serializer for MongoDB ObjectId, otherwise the`id` attribute is not properly serialized.
-   `[**MongoAuditProperties**](https://github.com/officiallysingh/spring-boot-mongodb-auditing/blob/main/src/main/java/com/ksoot/mongodb/MongoAuditProperties.java)` maps to configuration properties defined in `application.properties` or `application.yml`.
-   `[**AuditHistoryRepository**](https://github.com/officiallysingh/spring-boot-mongodb-auditing/blob/main/src/main/java/com/ksoot/product/adapter/repository/AuditHistoryRepository.java)` provides implementation of repository method to fetch a Page of Audit history.
-   `[**AuditHistoryController**](https://github.com/officiallysingh/spring-boot-mongodb-auditing/blob/main/src/main/java/com/ksoot/product/adapter/controller/AuditHistoryController.java)` provides implementation of API to get a Page of Audit history

### Configurations

Following are the configuration properties to customize MongoDB Auditing behaviour.
```yml
application:  
  mongodb:  
    entity-base-packages:  
      - com.ksoot  
      - com.org  
    auditing:  
      enabled: true  
      without-transaction: false  
      prefix:  
      suffix: aud
```

-   `**application.mongodb.entity-base-packages**` - List of packages to scan for MongoDB entities, Default: `Main class package name`.
-   `**application.mongodb.auditing.enabled**` - Whether or not to enable MongoDB Auditing, Default: `true`. If required Auditing can be disabled by setting it to `false`.
-   `**application.mongodb.auditing.without-transaction**` - Whether or not to do Auditing without Transactions, Default: `false`,
-   `**application.mongodb.auditing.prefix**` - Audit collection name prefix, Default: .
-   `**application.mongodb.auditing.suffix**` - Audit collection name suffix, Default: `aud`.

### How it works

-   Only the entity classes annotated with `Auditable` will be audited.
-   Audit collection name can either be specified in `Auditable` annotation (e.g. `@Auditable(name = "auditlogs")`) or it will be derived from source collection name, prefixed and suffixed with values defined in`application.mongodb.auditing.prefix` and `application.mongodb.auditing.suffix` respectively.
-   If it is required to Audit all collections in a single Audit collection then `Auditable` annotation can be used with same `name` attribute value for all entity classes.
-   On application startup it scans all the packages defined in `application.mongodb.entity-base-packages` for MongoDB entities annotated with `Auditable`.
-   For each such entity class it creates Audit collection with name as per settings and prepares Audit metadata.
-   It listens to all changes to eligible entity classes and creates Audit records, whenever new records are created, existing records are updated or deleted.
-   For newly created records `type` attribute of Audit record will be `CREATED`, for updated records `type` attribute will be `UPDATED` and for deleted records `type` attribute will be `DELETED`.
-   `source` attribute of Audit record will contain the snapshot of the record after update. While deleting the record, the `source` will only contain `id` of deleted record.
-   It is recommended to use a version field annotated with `@Version` in entity classes to avoid concurrent updates. It expects a`Long` version field to differentiates between newly created records and already existing updated record. In absence of version field`type` attribute of Audit record will be `UPDATED` for newly created and updated records as well.
-   Eligible Entity class object’s changes are detected in listeners defined in `[**AuditingMongoEventListener**](https://github.com/officiallysingh/spring-boot-mongodb-auditing/blob/main/src/main/java/com/ksoot/mongodb/AuditingMongoEventListener.java)` and Audit records are created as per the change type. On creation or updation of Entity objects
```java
@EventListener(condition = "@auditMetaData.isPresent(###event.getCollectionName())")  
public void onAfterSave(final AfterSaveEvent<?> event) {  
    
}
```
On deletion of Entity objects
```java
@EventListener(condition = "@auditMetaData.isPresent(###event.getCollectionName())")  
public void onAfterDelete(final AfterDeleteEvent<?> event) {  
      
}
```

-   The Audit Username is retrieved from `SecurityContextHolder` if available, otherwise it will be set as `SYSTEM`.
-   It is highly recommended to put the CRUD operation in a **Transaction** using Spring’s `@Transactional` (Refer to`[**Service**](https://github.com/officiallysingh/spring-boot-mongodb-auditing/blob/main/src/main/java/com/ksoot/product/domain/service/ProductServiceImpl.java)`) to update source collection and create audit entry atomically. But If required `application.mongodb.auditing.without-transaction` can be set to `true` then Auditing will be done without Transactions.
-   Spring uses `ApplicationEventMulticaster` internally to publish Entity change events. With Transactions, make sure `ApplicationEventMulticaster` is not configured to use `AsyncTaskExecutor` to publish events asynchronously, because the Transaction would not be propagated to Entity change listeners and Auditing would fail in this case.
-   It is recommended to use `OffsetDateTime` or `ZonedDateTime` for `datetime` attribute of Audit record to avoid any timezone related issues. Custom converters and Codecs are configured for the same in `[**MongoDBConfig**](https://github.com/officiallysingh/spring-boot-mongodb-auditing/blob/main/src/main/java/com/ksoot/mongodb/MongoDBConfig.java)`.
-   **Audit history is logged as follows.**

![](https://miro.medium.com/v2/resize:fit:875/1*Za4HF7HRYvYLrHLxiE6g0Q.png)
Audit Data

### Usage

You can copy the classes from [com.ksoot.mongodb](https://github.com/officiallysingh/spring-boot-mongodb-auditing/tree/main/src/main/java/com/ksoot/mongodb) package to your project and use them as it is or do any changes as per your requirements. Though application is built using Requires Java 21, Spring boot 3.2.0, but you can update Java version to Java 17 also in maven or gradle as follows.

### Demo

https://github.com/officiallysingh/spring-boot-mongodb-auditing
```xml
<properties>  
    <java.version>17</java.version>  
</properties>
```

**Docker compose**

-   If you have docker installed, then simply run the application in `docker` profile by passing `spring.profiles.active=docker` as program argument from your IDE.
-   Depending on your current working directory in IDE, you may need to change `spring.docker.compose.file=spring-boot-mongodb-auditing/compose.yml` to`spring.docker.compose.file=compose.yml` in `[**application-docker.yml**](https://github.com/officiallysingh/spring-boot-mongodb-auditing/blob/main/src/main/resources/config/application-docker.yml)`
-   Make sure the host ports mapped in `[**Docker compose file**](https://github.com/officiallysingh/spring-boot-mongodb-auditing/blob/main/compose.yml)` are available or change the ports and do the respective changes in database configurations`[**application-docker.yml**](https://github.com/officiallysingh/spring-boot-mongodb-auditing/blob/main/src/main/resources/config/application-docker.yml)`

**Explicit MongoDB installation**

Change to your MongoDB URI in `[**application.yml**](https://github.com/officiallysingh/spring-boot-mongodb-auditing/blob/main/src/main/resources/config/application.yml)` file as follows.
```yml
spring:  
  data:  
    mongodb:  
      uri: <Your MongoDB URI>
```

> MongoDB replica set is required for Transactions to work. Refer to `[**MongoDB Replica Set**](https://medium.com/workleap/the-only-local-mongodb-replica-set-with-docker-compose-guide-youll-ever-need-2f0b74dd8384)` for more details.

### APIs

-   Access **Swagger** at [http://localhost:8080/swagger-ui.html](http://localhost:8080/swagger-ui.html)
-   Access Demo CRUD APIs at [http://localhost:8080/swagger-ui/index.html?urls.primaryName=Product](http://localhost:8080/swagger-ui/index.html?urls.primaryName=Product)  
    - Create a new Product
```shell
curl -X 'POST'   
  'http://localhost:8080/v1/products'   
  -H 'accept: application/json'   
  -H 'Content-Type: application/json'   
  -d '{  
  "name": "iPhone 15 mini",  
  "description": "iPhone",  
  "tags": [  
    "mobile"  
  ],  
  "attributes": {  
    "size": "mini",  
    "color": "black"  
  }  
}'
```
- Update existing Product, replace 60f0b0b0e3b9a91e8c7b0b0b with your Product id
```shell
curl -X 'PATCH'   
'http://localhost:8080/v1/products/60f0b0b0e3b9a91e8c7b0b0b'   
  -H 'accept: application/json'   
  -H 'Content-Type: application/json'   
  -d '{  
  "description": "iPhone Handset"  
}'
```
- Delete existing Product, replace 60f0b0b0e3b9a91e8c7b0b0b with your Product id
```shell
curl -X 'DELETE'   
  'http://localhost:8080/v1/products/60f0b0b0e3b9a91e8c7b0b0b'   
  -H 'accept: application/json'
```
-   Access Audit History APIs at [http://localhost:8080/swagger-ui/index.html?urls.primaryName=Audit](http://localhost:8080/swagger-ui/index.html?urls.primaryName=Audit) to fetch Audit history of any Product. Records can be filtered by Collection Name, Audit event type, Revisions, Audit Username and Datetime range.
```shell
curl -X 'GET'   
  'http://localhost:8080/v1/audit-history?collectionName=products&page=0&size=16'   
  -H 'accept: */*'
```
### Spring Data MongoDB Full-Text search

### Introduction

Text search refers to the ability to perform [**Full-text searches**](https://docs.spring.io/spring-data/mongodb/docs/current-SNAPSHOT/reference/html/###mongodb.repositories.queries.full-text) on string content in your documents. MongoDB provides a text search feature that allows to search for documents that contain a specified sequence of words or phrases.

### Implementation

**Entity**

-   `TextIndexed`: The candidate fields for text search should be annotated with `@TextIndexed` as defined in`[**Product**](https://github.com/officiallysingh/spring-boot-mongodb-auditing/blob/main/src/main/java/com/ksoot/product/domain/model/Product.java)` entity class as follows.`@TextIndexed` marks a field to be part of the text index. `weight` attribute defines the significance of the filed relative to other indexed fields. The value directly influences the documents score. As there can be only one text index per collection all fields marked with`@TextIndexed` are combined into one single index.
-   `TextScore`: A field marked with`@TextScore` is also required, to map the text score that MongoDB assigns to documents during a text search. The text score represents the relevance of a document to a given text search query.
```java
@Document(collection = "products")  
public class Product extends AbstractEntity {  
  
  @TextIndexed(weight = 3)  
  private String name;  
  
  @TextIndexed(weight = 1)  
  private String description;  
  
  @TextIndexed(weight = 2)  
  private List<String> tags;  
  
  private Map<String, String>  
      attributes;  
  
  @TextScore  
  @Getter(AccessLevel.PACKAGE)  
  @Setter(AccessLevel.PACKAGE)  
  private Float score;  
}
```
**Repository**

`[**ProductRepository**](https://github.com/officiallysingh/spring-boot-mongodb-auditing/blob/main/src/main/java/com/ksoot/product/adapter/repository/ProductRepositoryImpl.java)` provides implementation for Full-text search as follows.
```java
public Page<Product> findPage(final List<String> phrases, final Pageable pageRequest) {  
  Query query = new Query();  
  if (CollectionUtils.isNotEmpty(phrases)) {  
    TextCriteria criteria = TextCriteria.forDefaultLanguage();  
    criteria.matchingAny(phrases.toArray(new String[phrases.size()]));  
    query = TextQuery.queryText(criteria).sortByScore();  
  }  
  
  final long totalRecords = this.mongoOperations.count(query, Product.class);  
  if (totalRecords == 0) {  
    return Page.empty();  
  } else {  
    final Pageable pageable =  
        totalRecords <= pageRequest.getPageSize()  
            ? PageRequest.of(0, pageRequest.getPageSize(), pageRequest.getSort())  
            : pageRequest;  
    final List<Product> products = this.mongoOperations.find(query.with(pageable), Product.class);  
    return new PageImpl<>(products, pageable, totalRecords);  
  }  
}
```

**API**

Access Demo Full-text search API at [http://localhost:8080/swagger-ui/index.html?urls.primaryName=Product](http://localhost:8080/swagger-ui/index.html?urls.primaryName=Product) to search for Products.
```shell
curl -X 'GET'   
  'http://localhost:8080/v1/products?phrases=mobile&page=0&size=16'   
  -H 'accept: */*'
```

### Author

[**Rajveer Singh**](https://www.linkedin.com/in/rajveer-singh-589b3950/), In case you find any issues or need any support, please email me at [raj14.1984@gmail.com](mailto:raj14.1984@gmail.com)

### **References**

-   For exception handling refer to [**spring-boot-problem-handler**](https://medium.com/@raj14.1984/exception-handling-in-spring-boot-applications-3d57c9b63e57)**.**
-   Spring batch common components for partitioned jobs [**spring-batch-commons**](https://medium.com/@raj14.1984/spring-batch-common-components-for-partitioned-jobs-c26edc189d5d)
-   Refer to Spring Batch Job implemented as Spring Cloud Task `[**spring-boot-batch-cloud-task**](https://medium.com/@raj14.1984/spring-spring-batch-job-as-spring-cloud-task-769b4ec458d8)`.
-   Refer to Spring Batch Job implemented as Spring Rest application `[**spring-boot-batch-web**](https://medium.com/@raj14.1984/spring-batch-job-as-spring-rest-service-13d9f5634e52)`.



# Creating Custom MongoDB Spring Data Repository

Spring Data Mongo repositories offer a powerful tool for developers to build the majority of their features using query methods. However, there are occasions when the autogenerated query methods may not suffice, necessitating the development of custom implementations. This article explores the process of creating custom Spring Data Mongo repositories, allowing you to personally implement your data access methods.

### Prerequisites

Before we get started, make sure you have the following prerequisites in place:

1.  Java Development Kit (JDK): Ensure you have JDK 8 or higher installed on your system.
2.  Spring Boot: You should have Spring Boot set up in your development environment. You can do this by using Spring Initializer or your preferred method.
3.  MongoDB: MongoDB should be installed and running locally or on a remote server.

### Setting Up the Project

Let’s start by creating a new Spring Boot project. You can use Spring Initializer or your preferred method to create a basic Spring Boot application. Make sure to include the necessary dependencies, such as “Spring Web” and “Spring Data MongoDB.”

### Creating the Entity Class

In MongoDB, data is stored in collections, which are analogous to tables in relational databases. Each document in a collection represents an instance of an entity. To create a custom MongoDB data repository, we need an entity class. Here’s an example of an entity class for a simple “Book” entity:
```java
import lombok.Data;  
import org.springframework.data.annotation.Id;  
import org.springframework.data.mongodb.core.mapping.Document;  
  
@Data  
@Document(collection = "books")  
public class Book {  
  
    @Id  
    private String id;  
    private String title;  
    private String author;  
    private LocalDate startdate;  
    private LocalDate endDate;  
}
```

In above example, we annotate the class with `@Document` to specify the MongoDB collection name, and we use `@Id` to mark the field as the document's primary key.

### Creating Standard Spring Mongo Repository

To create a custom MongoDB repository, we need to define an interface that extends `MongoRepository` and add custom query methods to it. Defining a Mongo Repository is very easy. You can create a new interface and extend **Repository<T, ID>** or an interface that extends it, such as **CrudRepository<T, ID>**. To access Mongo-specific features, you can extend **MongoRepository<T, ID>**. After that, you can add query method signatures to the interface, and Spring will take care of the rest. Here's an example of a custom repository interface for the "Book" entity:
```java
import org.springframework.data.mongodb.repository.MongoRepository;  
  
import java.util.List;  
  
public interface BookRepository extends MongoRepository<Book, String> {  
  
    List<Book> findByAuthor(String author);  
  
    // Add custom query methods here  
}
```

In this interface, we’ve added a custom query method `findByAuthor(String author)` to retrieve books by the author's name. Spring Data MongoDB will automatically generate the implementation for this method based on the method name.

### Adding Methods With Custom Implementations

To create a custom Spring Mongo Repository you can follow the following process:

1.  Define a custom repository interface containing the methods that you wish to implement yourself
2.  Implement the custom repository interface
3.  Make your standard entity repository extend the custom repository interface

### Creating Custom Repository Interface
```java
import java.time.LocalDate;  
import java.util.List;  
  
public interface CustomBookRepository {  
    List<Book> findBooksByPublicationDateRange(LocalDate startDate, LocalDate endDate);  
}
```

The interface includes a method named **findBooksByPublicationDateRange,** which does not meet the criteria for being considered a query method. As a result, Spring cannot generate a proxy implementation automatically, requiring us to provide our own implementation. We will provide custom implementation below.

### **Custom Repository Interface Implementation**
```java
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.data.mongodb.core.MongoTemplate;  
import org.springframework.data.mongodb.core.query.Criteria;  
import org.springframework.data.mongodb.core.query.Query;  
  
import java.time.LocalDate;  
import java.util.List;  
  
public class CustomBookRepositoryImpl implements CustomBookRepository {  
  
    @Resource  
    @Qualifier("productsMongoTemplate")  
    MongoTemplate mongoTemplate;  
  
    @Override  
    public List<Book> findBooksByPublicationDateRange(LocalDate startDate, LocalDate endDate) {  
        // Implement custom query logic here  
        // You can use the mongoTemplate to create custom queries  
        Criteria dateCriteria = Criteria.where("publicationDate")  
                .gte(startDate.atStartOfDay())  
                .lt(endDate.plusDays(1).atStartOfDay());  
  
        Query query = new Query(dateCriteria);  
          
        return mongoTemplate.find(query, Book.class);  
    }  
}
```

We have to create a fresh class named **CustomBookRepositoryImpl**, responsible for implementing our custom interface. Within this class, we utilise a MongoTemplate instance to query and find the books by publication date range.

### Entity Repository Extends Custom Repository Interface

To complete the integration of all these components, one final step remains: extending the conventional entity interface (BookRepository) to include our custom interface. This can be done by making BookRepository extends CustomBookRepository interface.
```java
import org.springframework.data.mongodb.repository.MongoRepository;  
  
public interface BookRepository extends MongoRepository<Book, String>, CustomBookRepository {  
    // Add any additional custom query methods specific to the Book entity  
    List<Book> findByAuthor(String author);  
}
```

Now, **Spring will use your custom implementation for the methods declared in the custom interfaces** when generating the proxy methods.

### Using the entity repository for custom methods
```java
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.stereotype.Service;  
  
import java.util.List;  
  
@Service  
public class BookService {  
  
    @Resource  
    BookRepository bookRepository;  
  
  
    public List<Book> getBooksByAuthor(String author) {  
        return bookRepository.findByAuthor(author);  
    }  
  
    public List<Book> getBooksByPublicationDaterange(LocalDate startDate, LocalDate endDate) {  
        return bookRepository.findBooksByPublicationDateRange(startDate, endDate);  
    }  
}
```

Here, by using entity repository, bookRepository, we are able to call custom method defined in custom repository class.

### Configuring the Application

To make Spring Boot aware of your custom repository and configuration, you need to create a configuration class:
```java
import org.springframework.context.annotation.Configuration;  
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;  
  
@Configuration  
@EnableMongoRepositories(repositoryBaseClass = CustomBookRepositoryImpl.class)  
public class MongoConfig {  
// Mongo configurations  
}
```

### Conclusion

Creating a custom MongoDB data repository in a Spring Boot application provides flexibility and control over your data access methods. You can define custom query methods and even implement complex queries using the `MongoTemplate`. This flexibility allows you to tailor your data access layer to the specific needs of your application while benefiting from the convenience and power of Spring Data MongoDB.

# Spring Boot with MongoDB integration guide with multiple data sources.

MongoDB is a schema-less NoSQL database. it is specially designed to store a large scale of data and also allows you to work with that data very efficiently.

**Some special features of MongoDB are:**

**1) Schema-less Database:** A single collection can hold multiple documents and these documents may consist of different numbers of fields, content, and size. It is not required that a document is similar to another document as it is in the case of relational databases.

**2) Document Oriented:** the data is stored in key-value pairs instead of rows and columns which makes the data much more flexible.

**3) Indexing:** It indexes every field in the documents with primary and secondary indices which makes it easier and takes less time to get or search data from the pool of the data.

**4) Scalability:** It provides horizontal scalability. We can add new machines to a running database. It uses sharding to store data on multiple machines. Sharding refers to the process of distributing data on multiple servers, here a large amount of data is partitioned into data chunks using the shard key, and these data chunks are evenly distributed across shards that reside across many physical servers

**5) High Performance:** Due to its features like scalability, indexing, replication, etc., the performance of MongoDB becomes very high and also data persistence as compared to any other database.

**Here we will go for the integration of multiple data sources of MongoDB with spring boot.**

There are two approaches through which we can connect to the MongoDB database —

MongoRepository

MongoTemplate.

Here we will go for MongoTemplate as it provides advanced uses and complex query execution.MongoTemplate offers us closer control over what we request from MongoDB. It offers an easier step to write a complex query than MongoRepository. Even some people in the industry also find that MongoTemplate is a good choice to write a complex query easily.

Let’s start integration with the spring boot project.

**Step 1: Add maven dependency in pom.xml**
```xml
<dependency>  
    <groupId>org.springframework.data</groupId>  
    <artifactId>spring-data-mongodb</artifactId>  
</dependency>
```
**Step 2: Add connection properties in application.properties.**
```shell
spring.data.mongo.firstdb.uri=mongodb://<username>:<password>@<Host>/<DB Name>
```
**Step 3: Create DataSource class to manage the DB connections.**
```java
@Configuration  
public class MongoConfig {
    @Autowired  
    private Environment env;
    
    @Bean  
    public MongoDbFactory mongoFirstDbFactory() {  
        return new SimpleMongoDbFactory(new MongoClientURI(env.getProperty("spring.data.mongo.firstdb.uri")));  
    }
    @Bean  
    public MongoTemplate mongoFirstDbTemplate() {  
        MongoTemplate mongoFirstDbTemplate = new MongoTemplate(mongoFirstDbFactory());  
        return mongoFirstDbTemplate;  
    }
}
```
**Step4: Create Entity Class**
```java
@Document(collection="usermongo")  
public class UserMongo {
    @Id  
    private String userId;  
    private String name;  
    private Date creationDate = new Date();
    public String getUserId() {  
        return userId;  
    }
    public void setUserId(String userId) {  
this.userId = userId;  
}public String getName() {  
return name;  
}public void setName(String name) {  
this.name = name;  
}public Date getCreationDate() {  
return creationDate;  
}public void setCreationDate(Date creationDate) {  
this.creationDate = creationDate;  
}}
```

**Step5: Create Repository Class**
```java
@Repository  
public class UserMongoRepository {  
    @Autowired  
    @Qualifier("mongoFirstDbTemplate")  
    private MongoTemplate mongoTemplate;public void saveUsers() {  
        UserMongo user = new UserMongo();  
        user.setName("medium");  
        mongoTemplate.save(user);  
    }
}
```
# Spring Boot with MongoDB replica set local set up. | by Ivan Polovyi | Level Up Coding

### Spring Boot with MongoDB replica set local set up.

### Nowadays applications work with large amounts of data and at the same time have to be fast and responsive, resilient, and highly available. A MongoDB replica set was made to solve these problems. This tutorial will demonstrate how to connect the MongoDB database with the Spring Boot application. This [friendly link](/spring-boot-with-mongodb-replica-set-local-set-up-30f87e3c71dd?sk=67e19e54d4112340c7b7475921f88991) is for those without a subscription.

### MongoDB replica set configuration

To create a MongoDB replica set locally I will use a Dokcer and Docker compose, because it is a very convenient way that does not require actual installation of the MongoDB on the PC. The complete guide on how to create a MongoDB replica set locally can be found below:

[

### MongoDB replica set configuration

### MongoDB is a NoSQL database that is a leader in its class. It is popular because it is fast and at the same time stable…

faun.pub

](https://faun.pub/mongodb-replica-set-configuration-976c9e55c6f3?source=postpage-----30f87e3c71dd---------------------------------------)

If you wanna know more details about the setup, I recommend you to read it. Here I just will show you a docker-compose file and some additional steps that have to be performed to make it work with the Spring Boot application.

So, all that we need for the setup is a docker-compose file:
```yaml
version: "3.8"  
  
services:  
  
  temp-instance:  
    containername: temp-instance  
    image: mongo:5.0.5  
    volumes:  
      - ./init-mongo-db:/docker-entrypoint-initdb.d  
    networks:  
      - mongo-cluster-network  
  
  primary:  
    containername: primary  
    image: mongo:5.0.5  
    volumes:  
      - ./keys/mongo-replica-set.key:/data/db/mongo-replica-set.key  
    ports:  
      - "27017:27017"  
    environment:  
          - MONGOINITDBROOTUSERNAME=root  
          - MONGOINITDBROOTPASSWORD=root  
    networks:  
      mongo-cluster-network:  
          ipv4address: 172.16.238.10  
    command:  
      - "--replSet"  
      - "tutorial-cluster"  
      - "--keyFile"  
      - "/data/db/mongo-replica-set.key"  
      - "--profile=1"  
      - "--slowms=1"  
  
  replica01:  
    containername: replica01  
    image: mongo:5.0.5  
    volumes:  
      - ./keys/mongo-replica-set.key:/data/db/mongo-replica-set.key  
    ports:  
      - "27027:27017"  
    networks:  
      mongo-cluster-network:  
        ipv4address: 172.16.238.11  
    command:  
      - "--replSet"  
      - "tutorial-cluster"  
      - "--keyFile"  
      - "/data/db/mongo-replica-set.key"  
      - "--profile=1"  
      - "--slowms=1"  
  
  replica02:  
    containername: replica02  
    image: mongo:5.0.5  
    volumes:  
      - ./keys/mongo-replica-set.key:/data/db/mongo-replica-set.key  
    ports:  
      - "27037:27017"  
    networks:  
      mongo-cluster-network:  
        ipv4address: 172.16.238.12  
    command:  
      - "--replSet"  
      - "tutorial-cluster"  
      - "--keyFile"  
      - "/data/db/mongo-replica-set.key"  
      - "--profile=1"  
      - "--slowms=1"  
  
networks:  
  mongo-cluster-network:  
    ipam:  
      driver: default  
      config:  
        - subnet: 172.16.238.0/24
```
This file defines 4 MongoDB containers, 3 of them will be part of the replica set, and one more is a temporary container that will bootstrap a replica set for us. In its turn, a replica set will consist of one primary instance and two secondary instances (replicas).

All containers are attached to the docker network defined in this file as well. Each replica set container has static IP configured. Having static IPs of instances makes it much easier to connect to a replica set using an IP instead of a domain name because we won't need to configure any DNS mapping. In a real project, you should use a domain name because IP can change, but locally it won't happen.

To be able to see queries in the logs two parameters are passed for each instance:
```shell
--profile=1  
--slowms=1
```
Logs will help us check which instance received a query.

As I've mentioned before the temporary container will bootstrap the replica set for us using the script below:
```shell
###!/bin/bash  
  
PRIMARYINSTANCEIP=172.16.238.10  
SECONDARY01INSTANCEIP=172.16.238.11  
SECONDARY02INSTANCEIP=172.16.238.12  
  
echo "############ Waiting for primary ############"  
until mongo --host ${PRIMARYINSTANCEIP}  --eval "printjson(db.runCommand({ serverStatus: 1}).ok)"  
  do  
    echo "############ Sleeping  ############"  
    sleep 5  
  done  
  
  
echo "############ Waiting for replica 01  ############"  
until mongo --host ${SECONDARY01INSTANCEIP} --eval "printjson(db.runCommand({ serverStatus: 1}).ok)"  
  do  
    echo "############ Sleeping  ############"  
    sleep 5  
  done  
  
  
echo "############ Waiting for replica 02  ############"  
until mongo --host ${SECONDARY02INSTANCEIP} --eval "printjson(db.runCommand({ serverStatus: 1}).ok)"  
  do  
    echo "############ Sleeping  ############"  
    sleep 5  
  done  
  
echo "############ All replicas are ready!!!  ############"  
  
echo "############ Setting up cluster config  ############"  
  
echo "############ Getting replica set status  ############"  
mongosh --host ${PRIMARYINSTANCEIP} -u root -p root <<EOF  
rs.status()  
EOF  
echo "############ Initiating replica set ############"  
mongosh --host ${PRIMARYINSTANCEIP} -u root -p root  <<EOF  
rs.initiate(  
   {  
      id: "tutorial-cluster",  
      version: 1,  
      members: [  
         { id: 0, host : "${PRIMARYINSTANCEIP}:27017" },  
         { id: 1, host : "${SECONDARY01INSTANCEIP}:27017" },  
         { id: 2, host : "${SECONDARY02INSTANCEIP}:27017" }  
      ]  
   }  
)  
EOF  
  
echo "############ Getting replica set status again  ############"  
mongosh --host ${PRIMARYINSTANCEIP} -u root -p root   <<EOF  
rs.status()  
EOF  
  
echo "############ Stopping TEMP instance  ############"  
mongod --shutdown
```
### Spring Boot application

We will create an application that manages customer information such as full name, phone number, and address. It is a very simple application that has three REST API endpoints. One for customer creation, one for fetching customers by id, and one for fetching all customers.

The entity class looks like the below:
```java
package com.polovyi.ivan.tutorials.entity;  
  
import java.time.LocalDate;  
import lombok.AllArgsConstructor;  
import lombok.Builder;  
import lombok.Data;  
import lombok.NoArgsConstructor;  
import org.springframework.data.annotation.Id;  
import org.springframework.data.mongodb.core.mapping.Document;  
  
@Builder  
@Data  
@NoArgsConstructor  
@AllArgsConstructor  
@Document("customer")  
public class CustomerEntity {  
  
    @Id  
    private String id;  
  
    private String phoneNumber;  
    private String fullName;  
    private String address;  
    private LocalDate createdAt;  
}
```
And the repository interface:
```java
package com.polovyi.ivan.tutorials.repository;  
  
import com.polovyi.ivan.tutorials.entity.CustomerEntity;  
import org.springframework.data.mongodb.repository.MongoRepository;  
  
public interface CustomerRepository extends MongoRepository<CustomerEntity, String> {}
```
To connect to MongoDB we have to set in the configuration URL string by following the documentation below:

[

### Connection String URI Format

### This document describes the URI formats for defining connections between applications and MongoDB instances in the…

www.mongodb.com



](https://www.mongodb.com/docs/manual/reference/connection-string/?source=postpage-----30f87e3c71dd---------------------------------------)

The spring application yaml file is below:
```yaml
server:  
  port: 8001  
  servlet:  
    context-path: /spring-with-mongo-db-replica-set  
  
spring:  
  data:  
    mongodb:  
      uri: "mongodb://root:root@172.16.238.10:27017,172.16.238.11:27017,172.16.238.12:27017/tutorial-db?authSource=admin&replicaSet=tutorial-cluster&readPreference=secondary"  
  
logging:  
  level:  
    org:  
      springframework:  
        data:  
          mongodb:  
            core:  
              MongoTemplate: DEBUG
```

This is a minimal configs that are required to connect to a replica set and the Spring Boot will take care of the rest. I added logging configurations as well just to see query executions.

At the start-up of an application, the database will be populated with fake data using the [Java Faker](https://github.com/DiUS/java-faker) library, so we have something to test.

The rest of the code you can find here:

[

### GitHub - polovyivan/spring-with-mongo-db-replica-set

### You can't perform that action at this time. You signed in with another tab or window. You signed out in another tab or…

github.com



](https://github.com/polovyivan/spring-with-mongo-db-replica-set?source=postpage-----30f87e3c71dd---------------------------------------)

### Run a project

To create a replica set first you need to execute the following command in the folder on the PC with the key to permit containers to use this key. The key is used by containers to communicate with each other.

$sudo chmod 600 mongo-replica-set.key

After executing a single command from the directory where the docker-compose file is located:

$docker compose up

Depending on the installation of a docker-compose you may need to use a hyphen between docker and compose.

After a couple of seconds, the replica set will be ready to accept connections.

![](https://miro.medium.com/v2/resize:fit:875/1*AgfeMpARGrWhF7L5YjIuyw.png)

As I’ve told you before the temporary instance bootstraps the replica set and then stops.

![](https://miro.medium.com/v2/resize:fit:875/1*90WfvM7WkbyGLuZbS1-sg.png)

And we can run the application:

![](https://miro.medium.com/v2/resize:fit:875/1*ZNfVuyFayG4wJvI9u9--ow.png)

Now we can open logs in each instance by executing the following commands in three separate terminals from the directory with the docker-compose file:
```shell
$docker compose logs -f primary  
$docker compose logs -f replica01  
$docker compose logs -f replica02
```
When we call an API to create a customer the query is executed in the primary instance.

![](https://miro.medium.com/v2/resize:fit:875/1*DHGKX7vDsjBK4FLocVEPvw.png)

And when we hit an API to get all customers the query is executed in one of the replicas.

![](https://miro.medium.com/v2/resize:fit:875/1*qO08VPPcRAK5TWWHHR0whg.png)

This is happening because the connection string has a parameter

readPreference=secondary
---

