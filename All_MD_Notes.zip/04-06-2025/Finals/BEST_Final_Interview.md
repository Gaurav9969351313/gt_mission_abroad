# Top Java Interview Questions (with Answers) You Must Know 

Java’s not going anywhere — and neither are its interviews. Whether you’re targeting FAANG, fintechs, or high-growth startups, Java-based roles continue to demand a deep understanding of the language’s internals, concurrency, memory model, and ecosystem.

This guide covers the **most commonly asked Java interview questions**, along with **concise answers**, **code snippets**, and **bonus pro tips**.

### 💡 1. What’s the difference between `==` and `.equals()` in Java?

-   `==` checks for **reference equality**.
-   `.equals()` checks for **value/content equality** (if overridden properly).
```java
String a = new String("hello");  
String b = new String("hello");  
System.out.println(a == b);       // false  
System.out.println(a.equals(b));  // true
```
> ✅ **Pro tip:** Always override `.equals()` and `hashCode()` together.

### 🔁 2. Explain the difference between `HashMap`, `LinkedHashMap`, and `TreeMap`.

![](https://miro.medium.com/v2/resize:fit:1250/1*p0dddAY4dXXRhihxnf4d2Q.png)

### 🧵 3. What’s the difference between `synchronized`, `volatile`, and `AtomicInteger`?

-   `synchronized`: Lock-based, mutual exclusion.
-   `volatile`: Guarantees visibility, not atomicity.
-   `AtomicInteger`: Lock-free, atomic operations.
```java
AtomicInteger counter = new AtomicInteger(0);  
counter.incrementAndGet(); // atomic, no lock needed
```
> ⚠️ Use the right tool based on concurrency needs. Don’t overuse `synchronized` unless necessary.

### 💥 4. What causes a `NullPointerException` (NPE) and how can you avoid it?

Causes:

-   Dereferencing a null object.
-   Calling `.equals()` or `.length()` on null

✅ Solutions:

-   Use `Objects.requireNonNull()`
-   Defensive coding
-   Use `Optional` where it adds clarity
```java
Optional.ofNullable(user).ifPresent(u -> process(u));
```
### 🚀 5. Explain Java’s memory model: heap vs stack.

-   **Stack:** Stores method call frames, local variables, function calls.
-   **Heap:** Stores objects created with `new.`
-   **Garbage Collector** reclaims unused heap memory.

> Understanding this helps with performance optimization and avoiding memory leaks.

### 🧱 6. What’s the difference between `abstract class` and `interface`?

![](https://miro.medium.com/v2/resize:fit:875/1*2GxZKRtcgI5kMum4R8mZcw.png)

> 🧠 Use interfaces for contracts, abstract classes for shared behavior.

### 🧵 7. What’s the difference between a Thread and Runnable?

-   `Thread` is a class. `Runnable` is a functional interface.
-   Prefer `Runnable` or `Callable` with **Executors** for modern Java apps.
```java
ExecutorService pool = Executors.newFixedThreadPool(2);  
pool.submit(() -> System.out.println("Async task"));
```
### 🧪 8. What are some ways to handle exceptions in Java?

-   `try-catch`
-   `throws` declaration
-   `finally` block for cleanup
-   Custom exceptions for clarity

> ✅ Always handle exceptions as close to the source as possible, and log meaningfully.

### 🔄 9. What’s the difference between checked and unchecked exceptions?

-   **Checked:** Must be declared (`IOException`, `SQLException`)
-   **Unchecked:** Runtime exceptions (`NullPointerException`, `IllegalArgumentException`).

> 📌 Use checked exceptions when the caller can recover; otherwise use unchecked.

### 🧠 10. What is the `transient` keyword?

Used to indicate that a field **should not be serialized**.

transient String password;

> ✅ Critical in designing secure or efficient serializable classes.

### 🎯 Bonus: Java 17–21 Features That May Come Up

-   `record` types
-   `sealed` classes
-   Pattern matching for `instanceof`
-   Virtual threads (`Project Loom`) in Java 21
-   Switch expressions

Staying current with modern Java can set you apart in interviews.

### 🧠 Final Thought

Java interviews in 2025 go beyond syntax. They test:

-   Your understanding of the **language internals**
-   How well you write **safe, concurrent code**
-   Your ability to solve problems **cleanly and scalably**

---
# Is Redis Single-Threaded? How Does It Handle Millions of Requests Per Second?

**Yes, Redis is primarily single-threaded**, but it can still handle **millions of requests per second** due to its highly optimized design.

### Why is Redis Single-Threaded?

-   Redis uses an **event-driven, non-blocking I/O model** instead of traditional multi-threading.
-   This avoids the overhead of context switching and locking, making operations faster.
-   Instead of multiple threads, Redis processes commands sequentially in a single thread.

### How Does Redis Handle Millions of Requests?

**Pure In-Memory Storage**

Since Redis stores everything in RAM, it avoids slow disk I/O.

**Pipelining**

Redis can process multiple commands in a single network round-trip.

**Efficient Data Structures**

Redis uses highly optimized data structures like HashMaps, Sorted Sets, and HyperLogLogs.

**High-Performance I/O Multiplexing**

Uses `epoll`, `kqueue`, or `select()` for handling thousands of simultaneous connections efficiently.

**Single-Threaded but Multi-Processing**

In Redis 6.0+, **I/O handling is multi-threaded** for improved performance.

**Redis Clustering & Sharding**

Distributes requests across multiple Redis nodes to scale horizontally.

**When Does Redis Use Multiple Threads?**

-   **Redis 6.0+ introduced multi-threading for I/O operations** like accepting connections, reading/writing network data.
-   However, **command execution is still single-threaded** to maintain simplicity and avoid race conditions.

**Can Redis Handle More Than One CPU Core?**

-   By default, Redis mainly runs on one core.
-   For better CPU utilization, **run multiple Redis instances** on different cores.
-   Use **Redis Cluster** to distribute data across multiple nodes.

**Scaling Redis for Millions of Requests**

A high-traffic web application needs to handle 5M+ requests per second.

**Optimizations:**  
1 .Enable **Redis I/O Multi-Threading** (`io-threads 4`) in Redis 6.0+.  
2️ .Use **Replication** (read from replicas) to balance read load.  
3️ .Use **Sharding (Partitioning)** with Redis Cluster to distribute data.  
4️ .Optimize queries using **Lua Scripting & Pipelining**.  
5️ .Use **Eviction Policies** (`LRU`, `LFU`) to manage memory efficiently.

### Final Verdict

**Single-threaded by design** but extremely fast due to in-memory storage & optimized event loop.  
**Multi-threaded I/O in Redis 6+** significantly improves performance.  
**Redis Clustering & Replication** allow horizontal scaling.

Hope you all liked the content. Clap if you like this and follow me for more interesting content .It will be great if you show your love and encouragement :)

Meet you all with my next article soon.

Meanwhile, keep reading my other articles too :)  
[https://medium.com/@letslearnnow/list/reading-list](https://medium.com/@letslearnnow/list/reading-list)

Thank You.

Stay healthy and happy.

# Thank you for being a part of the community

Before you go:

-   Be sure to **clap** and **follow** the writer ️👏**️️**
-   Follow us: [**X**](https://x.com/inPlainEngHQ) | [**LinkedIn**](https://www.linkedin.com/company/inplainenglish/) | [**YouTube**](https://www.youtube.com/@InPlainEnglish) | [**Newsletter**](https://newsletter.plainenglish.io/) | [**Podcast**](https://open.spotify.com/show/7qxylRWKhvZwMz2WuEoua0) | [**Differ**](https://differ.blog/inplainenglish) | [**Twitch**](https://twitch.tv/inplainenglish)
-   [**Start your own free AI-powered blog on Differ**](https://differ.blog/) 🚀
-   [**Join our content creators community on Discord**](https://discord.gg/in-plain-english-709094664682340443) 🧑🏻‍💻
-   For more content, visit [**plainenglish.io**](https://plainenglish.io/) + [**stackademic.com**](https://stackademic.com/)

---

# Interviewer: Is a Spring Boot Singleton Bean Thread-Safe ?

Spring Boot, with its convention-over-configuration approach, makes developing robust applications a breeze. At the heart of many Spring applications lies the concept of “beans,” and by default, most Spring beans are singletons. This means only one instance of a particular bean exists within the Spring application context.

But here’s a crucial question that often trips up developers: **Is a singleton bean inherently thread-safe?** The short answer is: **Not necessarily. ⚠️**

Let’s dive into why, with practical examples in Spring Boot.

### The Nature of Singleton Beans 🌿

When you define a bean in Spring (e.g., with `@Component`, `@Service`, `@Repository`), Spring creates a single instance of that class and manages its lifecycle. Every time you inject this bean into another component, Spring provides the same instance.

This singleton scope is highly efficient for most use cases. It reduces object creation overhead and memory consumption. However, it also introduces a shared state.

### Stateful vs. Stateless Beans: The Core Distinction 🔄

Understanding the difference between stateful and stateless beans is fundamental to grasping singleton thread-safety.

-   **Stateless Beans (Thread-Safe by Nature) ✅:** A stateless bean does not hold any mutable instance variables that change based on method calls or external interactions. Its methods operate solely on the input parameters they receive or on immutable data. Since there’s no shared, changeable data, multiple threads can safely invoke its methods concurrently without interfering with each other.
-   Think of a utility class or a pure function. For example, a service that performs a calculation based on input parameters and returns a result, without storing any information about previous calculations.
-   **Stateful Beans (Potential Thread-Safety Issues) 🛑:** A stateful bean, on the other hand, does maintain mutable instance variables. These variables can be modified by the bean’s methods, and since a singleton means there’s only one instance, these mutable variables become **shared mutable state** across all threads.

This shared mutable state is the root cause of most concurrency problems in singleton beans. If multiple threads try to read and write to the same shared mutable variable simultaneously, you can encounter race conditions, inconsistent data, and unpredictable application behavior.

### The Peril of Shared Mutable State (in Stateful Singletons) 🚨

The thread-safety of a singleton bean hinges entirely on whether it maintains **shared mutable state**.

-   **Mutable state** refers to data within an object that can be changed after the object is created.
-   **Shared state** means this mutable data is accessible by multiple threads concurrently.

If your singleton bean has fields that are modified by different threads without proper synchronization, you’re heading for trouble. This can lead to race conditions, inconsistent data, and unpredictable behavior.

### Examples of Thread-Unsafe Singleton Beans (Stateful Scenarios) 👻

Let’s illustrate with a couple of Spring Boot examples that create **stateful singletons** and thus are prone to thread-safety issues.

###### Example 1: A Counter Service (Thread-Unsafe Stateful Bean) 📉

Consider a simple service that keeps track of a counter. This `counter` variable makes the bean **stateful**.
```java
package com.example.threadsafety;  
  
import org.springframework.stereotype.Service;  
@Service  
public class UnsafeCounterService {  
    private int counter = 0; // ⚠️ Mutable shared state - Makes this bean STATEFUL  
    public int incrementAndGet() {  
        // This operation is not atomic  
        counter++;  
        return counter;  
    }  
    public int getCounter() {  
        return counter;  
    }  
}
```
Now, imagine a Spring Boot controller injecting this service:

Java
```java
package com.example.threadsafety;  
  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.RestController;  
@RestController  
public class UnsafeCounterController {  
    @Autowired  
    private UnsafeCounterService unsafeCounterService; // Injects the single stateful instance  
    @GetMapping("/increment-unsafe")  
    public String incrementUnsafe() {  
        return "Counter: " + unsafeCounterService.incrementAndGet();  
    }  
}
```

If multiple users simultaneously hit the `/increment-unsafe` endpoint, each request is handled by a different thread. These threads will all operate on the same `counter` instance within `UnsafeCounterService`. The `counter++` operation is not atomic (it involves reading, incrementing, and writing). This can lead to lost updates. For example, if `counter` is 5, two threads might both read 5, increment it to 6, and then both write 6 back, resulting in a final value of 6 instead of 7.

###### Example 2: Non-Thread-Safe Data Structure Usage (Stateful Bean) 🗑️

Another common pitfall is using non-thread-safe collections as instance variables in a singleton. This `messages` list makes the bean **stateful**.

Java
```java
package com.example.threadsafety;  
  
import org.springframework.stereotype.Service;  
import java.util.ArrayList;  
import java.util.List;  
@Service  
public class UnsafeListService {  
    private List<String> messages = new ArrayList<>(); // ⚠️ Mutable shared state - Makes this bean STATEFUL  
    public void addMessage(String message) {  
        messages.add(message);  
    }  
    public List<String> getMessages() {  
        return new ArrayList<>(messages); // Return a copy to prevent external modification  
    }  
}
```
And a controller:
```java
package com.example.threadsafety;  
  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.RequestParam;  
import org.springframework.web.bind.annotation.RestController;  
import java.util.List;  
@RestController  
public class UnsafeListController {  
    @Autowired  
    private UnsafeListService unsafeListService; // Injects the single stateful instance  
    @GetMapping("/add-message-unsafe")  
    public String addMessage(@RequestParam String message) {  
        unsafeListService.addMessage(message);  
        return "Message added.";  
    }  
    @GetMapping("/get-messages")  
    public List<String> getMessages() {  
        return unsafeListService.getMessages();  
    }  
}
```
Multiple threads calling `/add-message-unsafe` concurrently on the same `ArrayList` can lead to `ConcurrentModificationException` or other unpredictable behavior, as `ArrayList` is not designed for concurrent modifications.

### Making Singleton Beans Thread-Safe (for Stateful Scenarios) 🛡️

If your singleton bean needs to be stateful and manage mutable shared state, you must ensure its thread-safety. Here are common strategies:

###### 1. Use `synchronized` Keywords 🔒

You can use the `synchronized` keyword to protect critical sections of your code.
```java
package com.example.threadsafety;  
  
import org.springframework.stereotype.Service;  
@Service  
public class SafeCounterService {  
    private int counter = 0; // Stateful, but methods are synchronized  
    public synchronized int incrementAndGet() {  
        counter++;  
        return counter;  
    }  
    public synchronized int getCounter() {  
        return counter;  
    }  
}
```
By making the `incrementAndGet()` method `synchronized`, only one thread can execute it at a time, preventing race conditions.

###### 2. Use Atomic Classes ⚛️

For simple operations on primitive types, Java’s `java.util.concurrent.atomic` package provides atomic classes that offer lock-free thread-safety.
```java
package com.example.threadsafety;  
  
import org.springframework.stereotype.Service;  
import java.util.concurrent.atomic.AtomicInteger;  
@Service  
public class AtomicCounterService {  
    private AtomicInteger counter = new AtomicInteger(0); // Stateful, using an atomic class  
    public int incrementAndGet() {  
        return counter.incrementAndGet();  
    }  
    public int getCounter() {  
        return counter.get();  
    }  
}
```
`AtomicInteger` handles the synchronization internally, making it more efficient than explicit `synchronized` blocks for single variable operations.

###### 3. Use Thread-Safe Collections 🛒

If you need to store collections in a singleton, use thread-safe alternatives from `java.util.concurrent`.

Java
```java
package com.example.threadsafety;  
  
import org.springframework.stereotype.Service;  
import java.util.List;  
import java.util.concurrent.CopyOnWriteArrayList; // Thread-safe list  
@Service  
public class SafeListService {  
    private List<String> messages = new CopyOnWriteArrayList<>(); // Stateful, using a thread-safe collection  
    public void addMessage(String message) {  
        messages.add(message);  
    }  
    public List<String> getMessages() {  
        return messages; // CopyOnWriteArrayList is safe to return directly  
    }  
}
```
`CopyOnWriteArrayList` is thread-safe for scenarios where reads vastly outnumber writes. For more general concurrent collection needs, consider `ConcurrentHashMap`, `ConcurrentLinkedQueue`, etc.

###### 4. Design for Immutability (Ideal for Statelessness) ✨

The best way to avoid concurrency issues with shared state is to eliminate mutable shared state altogether. If your singleton bean’s fields are all `final` and represent immutable objects, then it's inherently thread-safe because it essentially becomes **stateless** (or rather, its state never changes after construction).
```java
package com.example.threadsafety;  
  
import org.springframework.stereotype.Service;  
// This service is thread-safe because it has no mutable shared state - it's stateless  
@Service  
public class ImmutableService {  
    private final String applicationName = "MySpringBootApp"; // Immutable field  
    public String getApplicationName() {  
        return applicationName;  
    }  
    public String greet(String name) {  
        return "Hello, " + name + " from " + applicationName;  
    }  
}
```
Here, `applicationName` is `final` and a `String` (which is immutable in Java). There's no state that can be changed by multiple threads, so no synchronization is needed. This is the paradigm for a truly stateless singleton bean.

###### 5. Change Bean Scope (When State is Per-Request/Session) ➡️

While not directly about making a singleton thread-safe, if a bean must maintain a mutable state that is specific to a single request or session, you can change its scope. This effectively makes multiple “singletons” each tied to a specific context, isolating their state.

-   `@RequestScope`: A new instance of the bean is created for each HTTP request. This effectively isolates the state per request. Perfect for storing request-specific data like user input or transaction details. 📧
-   `@SessionScope`: A new instance of the bean is created for each user session. Useful for user-specific data that persists across multiple requests within the same session (e.g., shopping cart). 🛒

However, be mindful that these scopes can increase memory consumption compared to singletons, as more instances are created.

### When is a Singleton Bean Already Thread-Safe? (The Stateless Case) ✅

A singleton bean is naturally thread-safe if:

-   **It has no state (stateless):** All its methods operate only on their parameters or local variables. There are no instance variables that hold mutable data. This is the ideal and safest scenario. 🚀
-   **Its state is immutable:** All its instance variables are `final` and refer to immutable objects (like `String`, `Integer`, or your own carefully designed immutable classes). Once constructed, the bean's state cannot change. 🔒
-   **Its state is local to a thread:** If you’re using `ThreadLocal` for instance variables, each thread gets its own copy of the state, avoiding shared state issues (though this is a more advanced pattern and still involves state, just not shared state for the instance variable itself). 🧵

### Conclusion 🏁

In Spring Boot, singleton beans are powerful and efficient, but their thread-safety is not guaranteed by default. The key distinction lies between **stateless** and **stateful** beans. Stateless singletons are inherently thread-safe and are generally preferred. If your singleton bean must be stateful and maintain mutable shared state, it’s crucial to understand the implications.

By carefully designing your beans, using appropriate synchronization mechanisms, leveraging atomic classes, employing thread-safe collections, or ideally, striving for immutability to achieve statelessness, you can build robust and concurrent Spring Boot applications that perform reliably under heavy load. Always remember: **if your singleton bean has mutable state that can be accessed by multiple threads, it needs to be made thread-safe!** 🛑➡️🛡️
---

# Can You Inject a Prototype Bean Into a Singleton in Spring? 

If you’re working with the Spring Framework, you’ve probably come across different bean scopes like `singleton` and `prototype`. And at some point, you might have asked yourself:

> Can I inject a prototype bean into a singleton bean?

The short answer is: **yes, but not in the way you might expect.**

This is a super common question among developers learning Spring, and the way it behaves can be a little confusing if you’re not familiar with how Spring manages bean lifecycles under the hood.

In this article, we’ll break it all down step-by-step. We’ll look at what actually happens when you inject a prototype bean into a singleton, why that might not work the way you think it should, and how to fix it properly using Spring’s built-in tools.

### What Are Singleton and Prototype Beans?

Before we dig into the behavior, let’s take a quick look at what these scopes mean.

In Spring:

-   A **singleton** bean is created **once** for the entire application context. It’s shared across the app.
-   A **prototype** bean is created **every time** it’s requested from the Spring container.

So, for example, if you have this:
```java
@Component  
@Scope("prototype")  
public class MyPrototype {  
    public void doWork() {  
        System.out.println("Working with: " + this);  
    }  
}
```

Every time you request a `MyPrototype` bean, you should get a new instance.

### The Problem: Injecting a Prototype into a Singleton

Let’s say you have a singleton bean that needs to use a prototype bean. You might be tempted to write something like this:
```java
@Component  
public class MySingleton {  
  
    @Autowired  
    private MyPrototype myPrototype;  
  
    public void doSomething() {  
        myPrototype.doWork();  
    }  
}
```
Here, `MySingleton` is a singleton bean. `MyPrototype` is a prototype bean. So, naturally, you’d expect a new instance of `MyPrototype` every time `doSomething()` is called, right?

**Wrong.**

Here’s what actually happens.

### What Spring Really Does

When the application starts, Spring creates the singleton bean `MySingleton`.

At that time, it sees that `MySingleton` needs a `MyPrototype`. So it creates **one instance** of `MyPrototype` and injects it into the singleton.

From that point on, whenever `doSomething()` is called, it keeps using the **same** prototype object — the one that was injected at startup.

So in this case, the prototype bean is behaving just like a singleton. Which completely defeats the point of using `@Scope("prototype")`.

### Why This Happens

This isn’t a bug — it’s just how Spring works.

Spring only applies prototype behavior **when the bean is looked up directly from the container**. When it injects dependencies — like with `@Autowired` — it only does that once during the singleton’s creation.

So when you inject a prototype into a singleton, Spring doesn’t inject a new prototype each time you use it. It injects one — and leaves it there.

This can lead to bugs that are hard to spot, especially if you’re relying on fresh data or temporary behavior inside your prototype bean.

### The Right Way: Requesting a New Prototype Bean Manually

To fix this, you need to make sure your singleton doesn’t hold onto the prototype bean. Instead, it should **ask for a new instance every time** it needs one.

Spring gives us a couple of ways to do this.

### ✅ Option 1: Use `ObjectFactory`

You can inject a factory that gives you a new instance whenever you call it:
```java
@Component  
public class MySingleton {  
  
    @Autowired  
    private ObjectFactory<MyPrototype> myPrototypeFactory;  
  
    public void doSomething() {  
        MyPrototype fresh = myPrototypeFactory.getObject();  
        fresh.doWork();  
    }  
}
```
Now, each time `doSomething()` runs, Spring will return a fresh `MyPrototype`.

### ✅ Option 2: Use `Provider<T>` from `javax.inject`

Another clean option is using `Provider`:
```java
@Component  
public class MySingleton {  
  
    @Autowired  
    private Provider<MyPrototype> provider;  
  
    public void doSomething() {  
        MyPrototype newOne = provider.get();  
        newOne.doWork();  
    }  
}
```
Again, this makes sure that each call gets a separate object.

### ✅ Option 3: You Can Also Use Lookup Methods

There’s also a third approach: **method injection using** `**@Lookup**`.
```java
@Component  
public class MySingleton {  
  
    public void doSomething() {  
        MyPrototype prototype = getPrototypeBean();  
        prototype.doWork();  
    }  
  
    @Lookup  
    public MyPrototype getPrototypeBean() {  
        // Spring overrides this method  
        return null;  
    }  
}
```
Spring will override the `getPrototypeBean()` method at runtime and return a new bean every time. It works — but it’s a little more hidden and less readable than the factory or provider approaches.

### Why This Matters

Let’s say your prototype bean holds something like user session data, or maybe it’s generating random IDs or temporary tokens.

If you accidentally keep using the same instance inside your singleton, every user might get the same session object or the same ID.

That’s a serious problem — and one that’s hard to debug if you don’t understand what’s going on behind the scenes.

By using a factory or provider, you make sure the prototype bean works exactly the way it’s meant to — fresh instance, every time.

### 🛠️ Real-World Example

Let’s build an example where a `ReportService` (singleton) needs a new `ReportBuilder` (prototype) every time it generates a report.

### Step 1: Define the Prototype Bean
```java
@Component  
@Scope("prototype")  
public class ReportBuilder {  
  
    private final String id;  
  
    public ReportBuilder() {  
        this.id = UUID.randomUUID().toString();  
        System.out.println("New ReportBuilder created: " + id);  
    }  
  
    public void build() {  
        System.out.println("Building report with builder: " + id);  
    }  
}
```
### Step 2: Create the Singleton That Uses It
```java
@Component  
public abstract class ReportService {  
  
    public void generateReport() {  
        ReportBuilder builder = getReportBuilder(); // new instance every time  
        builder.build();  
    }  
  
    @Lookup  
    protected abstract ReportBuilder getReportBuilder();  
}
```
Here’s the magic: Spring will override `getReportBuilder()` behind the scenes and return a **new prototype bean every time**.

With `@Lookup`, Spring dynamically generates method logic to return **a new instance** of the desired prototype bean **every time the method is called**.

### Step 3: Run the Application
```java
@SpringBootApplication  
public class DemoApp {  
    public static void main(String[] args) {  
        ConfigurableApplicationContext context = SpringApplication.run(DemoApp.class, args);  
  
        ReportService service = context.getBean(ReportService.class);  
  
        service.generateReport(); // uses builder A  
        service.generateReport(); // uses builder B  
        service.generateReport(); // uses builder C  
    }  
}
```
**Output:**
```shell
New ReportBuilder created: 123  
Building report with builder: 123  
New ReportBuilder created: 456  
Building report with builder: 456  
New ReportBuilder created: 789  
Building report with builder: 789
```
As you can see, **a new instance** of `ReportBuilder` is created each time — exactly what we want from a prototype bean.

### Option 2: Use `ObjectProvider` or `Provider`
```java
@Component  
public class ReportService {  
  
    @Autowired  
    private ObjectProvider<ReportBuilder> builderProvider;  
  
    public void generateReport() {  
        ReportBuilder builder = builderProvider.getObject();  
        builder.build();  
    }  
}
```
This is clean, avoids abstract methods, and gives you full control over bean creation.

### Option 3: Manually Fetch From ApplicationContext

This is possible, but not recommended for general use:
```java
@Component  
public class ReportService {  
  
    @Autowired  
    private ApplicationContext context;  
  
    public void generateReport() {  
        ReportBuilder builder = context.getBean(ReportBuilder.class);  
        builder.build();  
    }  
}
```
Use this only if `@Lookup` or `ObjectProvider` don’t fit your case.

### Full Code Example for Reference
```java
// Prototype Bean  
@Component  
@Scope("prototype")  
public class MyPrototype {  
    public void doWork() {  
        System.out.println("Working with: " + this);  
    }  
}

// ❌ Incorrect way  
@Component  
public class MySingletonWrong {  
  
    @Autowired  
    private MyPrototype myPrototype;  
  
    public void doSomething() {  
        myPrototype.doWork(); // Same instance every time  
    }  
}

// ✅ Correct using ObjectFactory  
@Component  
public class MySingletonWithFactory {  
  
    @Autowired  
    private ObjectFactory<MyPrototype> myPrototypeFactory;  
  
    public void doSomething() {  
        MyPrototype fresh = myPrototypeFactory.getObject();  
        fresh.doWork();  
    }  
}

// ✅ Correct using Provider  
@Component  
public class MySingletonWithProvider {  
  
    @Autowired  
    private Provider<MyPrototype> provider;  
  
    public void doSomething() {  
        MyPrototype fresh = provider.get();  
        fresh.doWork();  
    }  
}
```
If you found this article helpful, feel free to share it with your fellow Spring devs — and follow for more tips like this on building better, bug-free applications with Spring Boot.

# GraalVM vs. Traditional JVM: Is It Time to Switch?

### **Introduction: A Journey from JIT to GraalVM**

Ever wondered what makes Java run so fast? Well, it’s all thanks to the **Just-In-Time (JIT) Compiler**, the unsung hero of the **Java Virtual Machine (JVM)**. It grabs your Java code, turns it into machine code on the fly, and makes your apps run like lightning.

But as apps grow, JIT starts to feel the heat. **Slow startups, too much memory usage**, and struggles with multiple languages can slow it down. Enter **GraalVM** — the superhero of modern computing.

In this article, we’ll first break down how JIT works and why it’s so crucial. Then, we’ll introduce GraalVM — a game-changing tech that supercharges Java and other languages. Finally, we’ll show you how GraalVM is killing it in the real world.

Ready to jump in? Let’s roll!

### **What Is Just-In-Time (JIT) Compilation?**

When you write Java code, it gets compiled into **bytecode**, which is platform-independent and runs on the **Java Virtual Machine (JVM)**.

To execute this bytecode, the JVM can either perform:

1. **Interpretation:** Executes instructions one at a time (this is slow).

2. **JIT Compilation:** Translates frequently used code into machine code, making it run faster.

### How does it work?

JIT works by optimizing your application dynamically:

• **Adaptive Optimization:** It detects performance bottlenecks and improves them.

• **HotSpot JVM:** The default JVM that uses profiling data to make decisions, balancing speed and memory usage efficiently.

### **Limitations with JIT:**

While JIT is great for improving Java performance, it does have its downsides:

• **Startup Delays:** JIT needs time to gather profiling data before it can optimize, so your app might take longer to reach full speed.

• **Memory Overhead:** The profiling and optimization process uses extra memory and CPU, which can impact system performance.

• **Java-Only:** JIT is mainly designed for Java and doesn’t handle other languages as efficiently.

### **Introduction to GraalVM**

**GraalVM**, developed by Oracle, is an advanced virtual machine designed to overcome these challenges. It’s not just a better JIT compiler; it’s a **universal virtual machine** that supports multiple languages like JavaScript, Python, Ruby, R, and even C/C++!

### Is it faster?

Let’s compare the GraaVM with JVM including JIT compiler. Here are some benchmarks:

![](https://miro.medium.com/v2/resize:fit:756/1*za0r5wSQ2gzXYr7JpodHw.png)

### What makes it faster?

GraalVM’s speed comes from a combination of innovations that rethink how code is executed. Let’s take a look at why GraalVM outperforms traditional JVMs.

1. ### **Advanced Compiler Technology**

At its core, GraalVM features the **Graal Compiler**, which is smarter and more efficient than the traditional **C2 compiler** in the HotSpot JVM. Key benefits include:

• **Aggressive Inlining:** GraalVM inlines methods more effectively, reducing the overhead of method calls.

• **Speculative Optimizations:** It predicts execution paths with greater accuracy, optimizing for real-world scenarios.

• **Loop Unrolling & Vectorization:** GraalVM optimizes loops and leverages modern CPUs, speeding up data-heavy tasks.

2. ### **Ahead-Of-Time (AOT) Compilation**

Unlike traditional JIT, GraalVM supports **AOT compilation**, which creates native executables for Java. This offers:

• **Instant Startup:** No warm-up time, as native images don’t require JIT optimizations at runtime.

• **Smaller Footprint:** AOT-compiled apps don’t include the JIT compiler, saving on memory.

3.### **Improved Garbage Collection**

GraalVM works with advanced garbage collectors like **G1GC** and **ZGC**, making memory management faster and less disruptive, which is great for latency-sensitive applications.

4.### **Optimized for Polyglot Execution**

GraalVM’s ability to run multiple languages isn’t just about flexibility — it’s faster too:

• **Efficient Inter-language Calls:** Calls between languages like Java and Python are optimized, reducing the overhead of data marshalling.

• **Shared Runtime:** It reduces redundancy when running multiple languages in the same application.

5.### **Better for Microservices**

Traditional JVMs struggle with microservices due to slow startups and high memory usage. GraalVM’s **native images** solve this by:

• **Quick Startup:** Starting up **10–100 times faster** than standard JVM applications.

• **Low Memory Usage:** Using **50% less memory**, making it ideal for containerized environments.

**Now we know the advantages of GraalVM. Now let’s see where we can use it.**

### **Real-Life Use Cases of GraalVM**

1. **Microservices with Quarkus and Micronaut**

Frameworks like **Quarkus** and **Micronaut** use GraalVM to compile Java microservices into native images. The result? Faster startups, lower memory usage, and better scalability — perfect for cloud-native applications.

2. **Serverless Computing**

In serverless environments like AWS Lambda, cold-start time is critical. GraalVM’s native images dramatically reduce startup latency, making it a top choice for serverless Java apps.

3. **Polyglot Applications**

Imagine a fintech app processing Python-based machine learning models, Java-based transaction logic, and JavaScript-powered user interfaces — all under GraalVM. It’s already being used by companies to unify language runtimes.

4. **Big Data and Streaming**

Tools like **Apache Kafka Streams** and **Flink** leverage GraalVM for higher throughput and lower resource consumption in big data processing pipelines.

5. **Blockchain Platforms**

GraalVM is a favorite in blockchain for its ability to optimize smart contract execution across multiple languages and reduce resource costs.

### **Conclusion: Why GraalVM Matters**

GraalVM isn’t just a faster JIT compiler — it’s a completely new approach to programming. It’s built for the future, making it easier to work with multiple languages, scale systems effectively, and improve cloud performance. Whether you’re developing serverless apps, combining different languages, or striving for peak performance, GraalVM enables you to do things that traditional JVMs just can’t.

Ready to elevate your development? It’s time to explore GraalVM and unlock your app’s true potential! And if you want to learn more about how to use GraalVM, just let me know!
---



# Navigating Multiple Personalities: Spring Boot to Inject Two Classes Implementing the Same Interface in Spring Boot 

In the world of software development, interfaces are a superpower. They allow us to define contracts, promote loose coupling, and enable flexible, pluggable architectures.1 But what happens when you have a common interface, and _multiple_ classes proudly claim to implement it? 🤔 In Spring Boot, this scenario often leads to a `NoUniqueBeanDefinitionException` because the framework, by default, doesn't know which implementation to choose.

Fear not! Spring Boot provides elegant solutions to manage this “multiple personality disorder” of your beans. This article will walk you through the common challenge and show you how to inject two (or more!) classes implementing the same interface using the power of `@Qualifier` and other techniques.

### The Interface: Defining the Contract 📜

Let’s start with a simple interface. Imagine you’re building a notification service, and you want to support different ways to send messages, like email and SMS.

```java  
// src/main/java/com/example/notifications/NotificationService.java  
package com.example.notifications;  
  
public interface NotificationService {  
    String send(String message);  
}
```
This interface defines a single method: `send`. Now, let's create two concrete implementations.

### The Implementations: Two Sides of the Same Coin 🤝

We’ll have an `EmailNotificationService` and an `SmsNotificationService`, both implementing our `NotificationService` interface.
```java
// src/main/java/com/example/notifications/EmailNotificationService.java  
package com.example.notifications;  
  
import org.springframework.stereotype.Service;  
@Service("emailService") // Assign a specific name (qualifier)  
public class EmailNotificationService implements NotificationService {  
    @Override  
    public String send(String message) {  
        return "Email notification sent: " + message + " 📧";  
    }  
}

// src/main/java/com/example/notifications/SmsNotificationService.java  
package com.example.notifications;  
  
import org.springframework.stereotype.Service;  
@Service("smsService") // Assign another specific name  
public class SmsNotificationService implements NotificationService {  
    @Override  
    public String send(String message) {  
        return "SMS notification sent: " + message + " 📱";  
    }  
}
```
Notice the `@Service("beanName")` annotation. By default, Spring assigns a bean name based on the class name (e.g., `emailNotificationService`). Here, we're explicitly providing a unique name for each bean, which will be crucial for disambiguation.

### The Challenge: Ambiguity in Autowiring 🐛

If you were to try and `@Autowired` `NotificationService` directly into another component without any further specification, Spring would throw a `NoUniqueBeanDefinitionException`:
```java
// This would cause an error!  
@Service  
public class MyService {    @Autowired  
    private NotificationService notificationService; // Ambiguity here!     
 // ...  
}
```
**Why?** Because Spring’s default autowiring mechanism tries to find _one unique bean_ of the requested type. In our case, it finds _two_ beans (`EmailNotificationService` and `SmsNotificationService`) that both implement `NotificationService`. Spring gets confused! 🤷‍♀️

### The Solution: `@Qualifier` to the Rescue! 🎯

The `@Qualifier` annotation is your go-to solution for resolving this ambiguity. It allows you to specify _which exact bean_ you want to inject when multiple implementations of an interface exist.

You use `@Qualifier` in conjunction with `@Autowired` at the injection point, referencing the bean name you assigned earlier.3

Let’s create a controller to demonstrate:
```java
// src/main/java/com/example/controllers/NotificationController.java  
package com.example.controllers;  
  
import com.example.notifications.NotificationService;  
import org.springframework.beans.factory.annotation.Qualifier;  
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.RequestParam;  
import org.springframework.web.bind.annotation.RestController;  
  
@RestController  
public class NotificationController {  
  
private final NotificationService emailNotificationService;  
    private final NotificationService smsNotificationService;  
    // Constructor Injection is generally preferred for immutability and testability  
    public NotificationController(  
            @Qualifier("emailService") NotificationService emailNotificationService,  
            @Qualifier("smsService") NotificationService smsNotificationService) {  
        this.emailNotificationService = emailNotificationService;  
        this.smsNotificationService = smsNotificationService;  
    }  
    @GetMapping("/send/email")  
    public String sendEmail(@RequestParam String message) {  
        return emailNotificationService.send(message);  
    }  
    @GetMapping("/send/sms")  
    public String sendSms(@RequestParam String message) {  
        return smsNotificationService.send(message);  
    }  
}
```
In this controller:

-   We use **constructor injection** (a good practice in Spring).
-   For each `NotificationService` dependency, we add `@Qualifier("beanName")` to tell Spring _exactly_ which bean to inject. For example, `@Qualifier("emailService")` ensures that `emailNotificationService` receives the `EmailNotificationService` instance.

### Running the Application 🏃‍♀️

Now, let’s create a simple Spring Boot application to run this:
```java
// src/main/java/com/example/demo/MultipleImplementationsApplication.java  
package com.example.demo;  
  
import org.springframework.boot.SpringApplication;  
import org.springframework.boot.autoconfigure.SpringBootApplication;  
import org.springframework.context.annotation.ComponentScan;  
@SpringBootApplication  
@ComponentScan(basePackages = {"com.example.notifications", "com.example.controllers"}) // Scan packages  
public class MultipleImplementationsApplication {  
    public static void main(String[] args) {  
        SpringApplication.run(MultipleImplementationsApplication.class, args);  
    }  
}
```
Make sure your `pom.xml` (for Maven) or `build.gradle` (for Gradle) includes the necessary Spring Boot dependencies (e.g., `spring-boot-starter-web`).

When you run this application and hit the endpoints:

-   [http://localhost:8080/send/email?message=Hello%20from%20email!](http://localhost:8080/send/email?message=Hello+from+email%21)
-   Output: Email notification sent: Hello from email! 📧
-   [http://localhost:8080/send/sms?message=Hello%20from%20SMS!](http://localhost:8080/send/sms?message=Hello+from+SMS%21)
-   Output: SMS notification sent: Hello from SMS! 📱

Success! 🎉 Spring Boot successfully injected the correct implementations based on our `@Qualifier` annotations.

### Other Strategies (Briefly) 🧩

While `@Qualifier` is the most common and explicit way, here are a couple of other scenarios and solutions:

-   @Primary for a Default:
-   If you want one of your implementations to be the default when no @Qualifier is specified, you can annotate it with @Primary.
```java
@Service  
@Primary // This will be the default if no qualifier is specified  
public class DefaultNotificationService implements NotificationService {  
    @Override  
    public String send(String message) {  
        return "Default notification sent: " + message + " 🌐";  
    }  
}
```
Then, if you simply `Autowired` `NotificationService` without `@Qualifier`, Spring would inject `DefaultNotificationService`. However, `@Qualifier` always takes precedence over `@Primary`.

###### Injecting a List of Implementations:

-   Sometimes, you might want to access all implementations of an interface and decide at runtime which one to use (e.g., implementing a Strategy pattern). Spring allows you to inject a List of all available beans for a given interface:
```java
@Service  
public class NotificationProcessor {  
  
    private final List<NotificationService> allNotificationServices;  
  
    public NotificationProcessor(List<NotificationService> allNotificationServices) {  
        this.allNotificationServices = allNotificationServices;  
    }  
  
    public void processAll(String message) {  
        for (NotificationService service : allNotificationServices) {  
            System.out.println(service.send(message));  
        }  
    }  
}
```
-   Spring will automatically populate this list with all beans that implement `NotificationService`. You can then iterate or use a factory pattern to select the appropriate service.Conclusion: Flexibility Through Controlled Injection ✅

Spring Boot’s dependency injection capabilities, especially with `@Qualifier`, provide robust mechanisms to handle scenarios where multiple classes implement the same interface.4 This allows you to build highly modular, extensible, and testable applications. By explicitly guiding Spring on which "personality" of your interface you need, you maintain clarity and avoid runtime surprises. So go forth and create highly flexible applications, knowing you can manage your beans with precision! 🛠️ Happy coding!
