### Part 1: Quarkus Persistence, CRUD with Panache. E-commerce example.

Hi. In this tutorial we’ll add a persistence layer to our quarkus application we created in a previous article and perform some basic CRUD operations.

This guide will utilize Hibernate Reactive — a streamlined Panache iteration of a reactive persistence API — to accomplish data persistence.

Additionally, we will harness a PostgreSQL database, as a reactive client extension tailored for Quarkus.

Tip: This tutorial is on Apple’s M1 silicon, and uses the quarkus basic application created in the article “[Create your First Quarkus Application and importing it into IntelliJ IDEA](/@georgesotiropoulos23050/create-your-first-quarkus-application-and-importing-it-into-intellij-idea-4efc3dda16d1)”, If you don’t want to read the whole article then start by downloading a fresh quarkus project , `git clone https://github.com/quarkusio/quarkus-quickstarts.git`, or download the [archive](https://github.com/quarkusio/quarkus-quickstarts/archive/main.zip) and then import the project into IntelliJ IDEA, or even better: execute the following command to create a quarkus project using mvn or quarkus CLI.

**MVN**
```shell
mvn io.quarkus:quarkus-maven-plugin:3.4.1.Final:create   
    -DprojectGroupId=com.platform.ecommerce.order   
    -DprojectArtifactId=order-service  
```
**Quarkus CLI**
```shell
quarkus create app com.platform.ecommerce.order:order-service                         
```
**(with the assumption that you have setup all the required depedencies such as Maven and GraalVM….etc. at your machine)**

### Step 1. Maven Depedencies

Let’s now explore the specific dependencies that need incorporation into the project.

-   Quarkus Hibernate ORM Panache for Persistence API
-   PostgreSQL for database storage
-   Jackson serialization support for our RESTEasy Reactive Services.

Open a terminal within the project folder and run the following command to install the dependencies.
```shell
mvn quarkus:add-extension -Dextensions='quarkus-hibernate-orm-panache,quarkus-jdbc-postgresql,quarkus-resteasy-reactive-jackson'
```
> Tip:Extensions are passed using a comma-separated list. The extension name is `**io.quarkus:quarkus-hibernate-orm-panache**`. However, you can pass a partial name, and Quarkus will do its best to find the right extension. If no extension is found or more than one extension matches, you will see a red check mark ❌ in the command result.(Source:[https://quarkus.io/guides/maven-tooling](https://quarkus.io/guides/maven-tooling))

On the other hand you can still modify pom.xml and add the dependencies manually.
```xml
<!-- Hibernate ORM specific dependencies -->  
<dependency>  
    <groupId>io.quarkus</groupId>  
    <artifactId>quarkus-hibernate-orm-panache</artifactId>  
</dependency>  
  
<!-- JDBC driver dependencies -->  
<dependency>  
    <groupId>io.quarkus</groupId>  
    <artifactId>quarkus-jdbc-postgresql</artifactId>  
</dependency>  
  
<!-- resteasy-reactive-jackson  -->  
    <dependency>  
      <groupId>io.quarkus</groupId>  
      <artifactId>quarkus-resteasy-reactive-jackson</artifactId>  
    </dependency>
```
### Step 2. Entity classes

Since we are buiding an eshop we will create the following classes Product, Order, OrderItem and Customer.

In this tutorial we are focusing entirely on Product first. First create the bellow class in a new package named

**com.platform.ecommerce.order.model**

### Product.java
```java
package com.platform.ecommerce.order.model;  
  
public class Product {  
    public Long id;  
      
    public String name;  
      
    pubic String description;  
      
    public double price;  
  
    public  Integer stock;  
      
    public ZonedDateTime created;       
}
```

Our application is named platform. In case you didn’t follow the first article then feel free to create the class at any package……..but for the shake of this article and the articles to follow try to follow this package naming com.myownpackagename.domain.microservice-domain.model.

> All ORM entities belong to a model package. This tutorial is about order handling functionality of an eshop therefore the microservice-domain is ‘order-service’ within the ‘ecommerce’ domain)

### Step 3. Select the right Pattern. Active Record vs Repository.

Before we proceed lets examine two patterns that we can use to implement persistence in Quarkus. The first is the **Active Record Pattern**, and the second is the **Repository Pattern** that you are familiar from Spring Boot. (Source:[https://quarkus.io/guides/hibernate-orm-panache](https://quarkus.io/guides/hibernate-orm-panache###solution-1-using-the-active-record-pattern))

### **3.1) Active Record Pattern**

-   All class fields are public.
-   Class is annotated with @Entity
-   Entity extends either **PanacheEntity or PanacheEntityBase**. (That depends if you want to setup a custom ID Generator ………etc.)
-   All the logic and custom queries are added as static methods in the entity class.

**Product.java**
```java
package com.platform.ecommerce.order.model;  
  
  
import io.quarkus.hibernate.orm.panache.PanacheEntity;  
import jakarta.persistence.*;  
import jakarta.transaction.Transactional;  
import org.hibernate.annotations.CreationTimestamp;  
  
import java.time.ZonedDateTime;  
import java.util.List;  
  
  
@Entity  
public class Product extends PanacheEntity  {  
  
    @Column(unique = true, nullable = false)  
    public  String name;  
  
    @Column(nullable = true)  
    public  String description;  
    @Column(nullable = false)  
    public  double price;  
  
    @Column(nullable = false)  
    public  Integer stock;  
  
    //default stock value  
    {stock = 100;}  
  
    @CreationTimestamp  
    public ZonedDateTime created;  
  
    public Product() {}  
  
    public static Product findProductById(Long id) {  
        return findById(id);  
    }  
    public static Product findByName(String name){      return find("name", name).firstResult();  }  
    public static List<Product> findProductByMaximumPrice(double price) {  
        return find("price < ?1", price).list();  
    }  
  
    public static List<Product> findProductByMinimumPrice(double price) {  
        return find("price > ?1", price).list();  
    }  
  
    public static void deleteProduct(Long id) {  
        findById(id).delete();  
    }  
  
    @Transactional  
    public static void deleteAllProducts() {  
        deleteAll();  
    }  
  
    @Transactional  
    public static void updateProduct(Long id, Product newProduct) {  
        Product productToBeUpdated = findProductById(id);  
        productToBeUpdated.name = newProduct.name;  
        productToBeUpdated.description = newProduct.description;  
        productToBeUpdated.price = newProduct.price;  
    }  
  
    @Transactional  
    public static void createProduct(Product product) {  
        product.persist();  
    }  
  
}  
```

Easy? Right?

> In Active Record Pattern all class fields of the entity are declared public. Quarkus adds the getter/setter methods at runtime and replaces all entity field calls with getter/setter method calls.
> 
> (Source:[https://quarkus.io/guides/hibernate-orm-panache](https://quarkus.io/guides/hibernate-orm-panache))

### **3.2) Repository Pattern**

Now lets examine the same functionality using the **Repository Pattern**. As the name implies you create a new repository class **ProductRepository**

-   Entities such as Product are defined as regular Jakarta Persistence entities, using @Entity, however they do not extend PanacheEntity.
-   Repository Class implements **PanacheRepository**<T> interface
-   All the logic and custom queries are added as methods in the repository class.

This means that the **Product** entity is clean like the one below: (notice that The annotation @Id is needed now cause there is no extension of PanacheEntity who manages that.

**Product.java**
```java
package com.platform.ecommerce.order.model;  
  
  
import jakarta.persistence.Column;  
import jakarta.persistence.Entity;  
import jakarta.persistence.Id;  
import org.hibernate.annotations.CreationTimestamp;  
import java.time.ZonedDateTime;  
  
@Entity  
public class Product   {  
  
    @Id  
    public  Long  id;  
  
    @Column(unique = true, nullable = false)  
    public  String name;  
  
    @Column(nullable = true)  
    public  String description;  
  
    @Column(nullable = false)  
    public  double price;  
  
    @Column(nullable = false)  
    public  Integer stock;  
  
    //default stock value  
    {stock = 100;}  
  
    @CreationTimestamp  
    public ZonedDateTime created;  
  
}
```

And we have also the ProductRepository class created in a new package named **repository**

**ProductRepository.java**
```java
package com.platform.ecommerce.order.repository;  
  
import com.platform.ecommerce.order.model.Product;  
import io.quarkus.hibernate.orm.panache.PanacheRepository;  
import io.quarkus.panache.common.Sort;  
import jakarta.transaction.Transactional;  
import java.util.List;  
  
  
public class ProductRepository  implements PanacheRepository<Product> {  
  
    public List<Product> findAllProducts() {  
        return listAll(Sort.by("id"));  
    }  
  
    public Product findProductById(Long id) {  
        Product product = findById(id);  
        return product;  
    }  
  
    @Transactional  
    public void createProduct(Product product) {  
       persist(product);  
    }  
  
    @Transactional  
    public void updateProduct(Product product) {  
        Product productToBeUpdated = findProductById(product.id);  
        product.name!=null ? productToBeUpdated.name = product.name : productToBeUpdated.name;  
        product.description!=null ? productToBeUpdated.description = product.description : productToBeUpdated.description;  
        product.price!=0.0 ? productToBeUpdated.price = product.price : productToBeUpdated.price;  
    }  
  
    @Transactional  
    public void deleteProduct(Long productId) {  
        Product productToBeDeleted = findProductById(productId);  
        delete(productToBeDeleted);  
    }  
}
```
In this tutorial we are going to use the Active Record Pattern to implement persistency. Our logic in not that complex and only simple CRUD operations needed and not complex SQL stuff.

### Step 4. Create PostgresSQL database, add sample data and modify application.properties.

First you have to create a new database for our order service, and add a new user with the necessary privileges. Open the postgres terminal and type:

create database ecommerceorderdb;  
create user ecommerceorderusr with  password 'password';  
grant all privileges on database ecommerceorderdb to ecommerceorderusr;  
grant all on schema public to ecommerceorderusr;

Tip:PostgreSQL version 15+ doesn’t allow to create objects in public schema, you need to explicitly specify that hence ‘**grant all on schema public to ecommerceorderusr**’ . If for some reason you still cannot create tables use the route user to connect to ecommerceorderdb for the shake of this tutorial.

Add the relevant configuration properties for postgresSQL in `application.properties`.

### configure your datasource  
```shell
quarkus.datasource.db-kind = postgresql  
quarkus.datasource.username = ecommerceorderusr  
quarkus.datasource.password = password  
quarkus.datasource.jdbc.url = jdbc:postgresql://localhost:5432/ecommerceorderdb  
  
### drop and create the database at startup (use `update` to only update the schema)  
quarkus.hibernate-orm.database.generation = drop-and-create
```
Also we are populating our database with some sample data. To load SQL statements when Hibernate ORM starts, add an **import**.**sql** file to the root of your resources directory.

**import.sql**
```sql
-- INSERT INTO customer (id, name, surname,email,address,phone) VALUES ( nextval('customerseq'), 'Marco','Verratti','marco.verratti@gmail.com','Princes Park (Le Parc des Princes)','000000000');  
-- INSERT INTO customer (id, name, surname,email,address,phone) VALUES ( nextval('customerseq'), 'Kylian','Mbappé','kylian.mbappé@gmail.com','Princes Park (Le Parc des Princes)','000000000');  
  
INSERT INTO product (id, name, price,stock) VALUES ( nextval('productseq'), 'MacMini M1',699.00,0);  
INSERT INTO product (id, name, price,stock) VALUES ( nextval('productseq'), 'MacMini M2',899.00,5);  
INSERT INTO product (id, name, price,stock) VALUES ( nextval('productseq'), 'MacBook Air M1',999.00,100);  
INSERT INTO product (id, name, price,stock) VALUES ( nextval('productseq'), 'MacBook Air M2',1399.00,100);  
INSERT INTO product (id, name, price,stock) VALUES ( nextval('productseq'), 'MacStudio M2 Max',2390.00,100);  
INSERT INTO product (id, name, price,stock) VALUES ( nextval('productseq'), 'MacStudio M2 Ultra',4399.00,100);  
```  

### Step 5.Create a Resource Endpoint for Products.

Lets create our Jakarta REST resource endpoint **ProductResource** in a new package named **resource**.

**ProductResource.java**
```java
package com.platform.ecommerce.order.resource;  
  
import com.platform.ecommerce.order.model.Product;  
import io.quarkus.logging.Log;  
import jakarta.enterprise.context.ApplicationScoped;  
import jakarta.ws.rs.*;  
import jakarta.ws.rs.core.MediaType;  
import jakarta.ws.rs.core.Response;  
  
import java.util.List;  
  
@Path("product-service/v1/product")  
@ApplicationScoped  
@Produces(MediaType.APPLICATIONJSON)  
@Consumes(MediaType.APPLICATIONJSON)  
  
public class ProductResource {  
  
    @GET  
    @Path("all")  
    public List<Product> getAllProducts() {  
        return Product.listAll();  
    }  
  
    @GET  
    @Path("{id}")  
    public Product findProductById(@PathParam("id") Long id) {  
        return Product.findProductById(id);  
    }  
  
  
    @GET  
    @Path("name/{name}")  
    public Product findByName(@PathParam("name") String name) {  
        return Product.findByName(name);  
  
    }  
  
    @GET  
    @Path("price/maximum/{price}")  
    public List<Product> findProductByMaximumPrice(@PathParam("price") double price) {  
        return Product.findProductByMaximumPrice(price);  
    }  
  
    @GET  
    @Path("price/minimum/{price}")  
    public List<Product> findProductByMinimumPrice(@PathParam("price") double price) {  
        return Product.findProductByMinimumPrice(price);  
    }  
  
    @POST  
    @Path("create")  
    public Response createProduct(Product product) {  
        Product.createProduct(product);  
        Log.info("Product created:"+product.id);  
        return Response.status(Response.Status.CREATED).build();  
  
    }  
  
    @PUT  
    @Path("update/{id}")  
    public Response updateProduct(@PathParam("id") Long id, Product product) {  
        Product.updateProduct(id,product);  
        return Response.status(Response.Status.OK).build();  
    }  
  
  
    @DELETE  
    @Path("delete/{id}")  
    public Response deleteProduct(@PathParam("id") Long id) {  
        Product.deleteProduct(id);  
        return Response.status(Response.Status.OK).build();  
    }  
  
    @DELETE  
    @Path("truncate")  
    public Response deleteAllProducts() {  
        try {  
            Product.deleteAllProducts();  
        }catch (Exception e) {  
            System.out.println("Something went wrong ."+e.toString());  
        }  
        return Response.status(Response.Status.OK).build();  
    }  
  
}  
```
Tip:You may annotate your endpoint class with the `[@Produces](https://javadoc.io/doc/jakarta.ws.rs/jakarta.ws.rs-api/3.1.0/jakarta/ws/rs/Produces.html)` or `[@Consumes](https://javadoc.io/doc/jakarta.ws.rs/jakarta.ws.rs-api/3.1.0/jakarta/ws/rs/Consumes.html)` annotations, which allow you to specify one or more media types that your endpoint may accept as HTTP request body or produce as HTTP response body. Those class annotations apply to each method.

Any method may also be annotated with the `[@Produces](https://javadoc.io/doc/jakarta.ws.rs/jakarta.ws.rs-api/3.1.0/jakarta/ws/rs/Produces.html)` or `[@Consumes](https://javadoc.io/doc/jakarta.ws.rs/jakarta.ws.rs-api/3.1.0/jakarta/ws/rs/Consumes.html)` annotations, in which case they override any eventual class annotation.

### Step 6. Testing.

Its time to write our Test for our **ProductResource**. I’m using the @Order annotation to specify the order of execution. For this test we create 2 products, then we update the price of one of them and test if we are fetching one product only using the price maximum.

**ProductResourceTest.java**
```java
package com.platform.ecommerce.order.resource;  
  
  
import com.platform.ecommerce.order.model.Product;  
import io.quarkus.test.common.http.TestHTTPEndpoint;  
import io.quarkus.test.junit.QuarkusTest;  
import jakarta.json.Json;  
import jakarta.json.JsonObject;  
import jakarta.ws.rs.core.MediaType;  
import org.junit.jupiter.api.*;  
  
import static io.restassured.RestAssured.given;  
import static org.hamcrest.CoreMatchers.is;  
  
@QuarkusTest  
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)  
@TestHTTPEndpoint(ProductResource.class)  
public class ProductResourceTest {  
  
    @Test  
    @Order(1)  
    public void createProductcreateTwoProducts() {  
  
        JsonObject product1 = Json.createObjectBuilder()  
                .add("name", "Macbook")  
                .add("price", "1400.00").build();  
  
        JsonObject product2 = Json.createObjectBuilder()  
                .add("name", "MacStudio")  
                .add("price", "1400.00").build();  
  
  
        // Test POST  
        given()  
                .contentType(MediaType.APPLICATIONJSON)  
                .body(product1.toString())  
                .when()  
                .post("create")  
                .then()  
                .statusCode(201);  
  
        // Test POST  
        given()  
                .contentType(MediaType.APPLICATIONJSON)  
                .body(product2.toString())  
                .when()  
                .post("create")  
                .then()  
                .statusCode(201);  
  
    }  
  
  
  
    @Test  
    @Order(2)  
    public void whenFetchProductByNameThenAtLeastOneProductShouldBeFound() {  
        //TEST GET  
        Product product = given()  
                .accept(MediaType.APPLICATIONJSON)  
                .when().get("name/{name}","Macbook")  
                .then()  
                .statusCode(200)  
                .extract()  
                .body().as(Product.class);  
  
    }  
  
  
    @Test  
    @Order(3)  
    public void updateProductDropThePriceOfOneProductUnder1000() {  
  
        Product product = given()  
                .accept(MediaType.APPLICATIONJSON)  
                .when().get("name/{name}","Macbook")  
                .then()  
                .statusCode(200)  
                .extract()  
                .body().as(Product.class);  
  
        JsonObject productToBeUpdated = Json.createObjectBuilder()  
                .add("name", "Macbook Price Dropped")  
                .add("price", "900.00").build();  
  
        // Test POST  
        given()  
                .contentType(MediaType.APPLICATIONJSON)  
                .body(productToBeUpdated.toString())  
                .when().put("update/{id}",product.id)  
                .then()  
                .statusCode(200);  
  
    }  
  
  
    @Test  
    @Order(4)  
    public void whenFetchProductByPriceMaximumThenOnlyOneProductShouldBeFound() {  
        given()  
                .when().get("price/maximum/{price}",1000)  
                .then()  
                .statusCode(200)  
                .assertThat().body("size()", is(4));  
    }  
  
}
```

Open up a terminal and run the test by typing
```shell
mvn clean test
```
Run the program by typing **mvn quarkus:dev** if you are using maven or if you are using quarkus cli type **quarkus dev**
```shell
mvn quarkus:dev
### OR 
quarkus dev
```
---
### Part 2: Quarkus Persistence, CRUD with Panache. E-commerce example.

In the [first part](/@georgesotiropoulos23050/part-1-crud-with-panache-orm-in-quarkus-an-eshop-example-cd37ccf051e2) of this tutorial we developed the entity for the products using the Active Record Patttern. In this tutorial we are creating the rest of the entities needed below

**Customer**

**Order**

**OrderItem**

The relations are:

OneToMany: one **customer** has many **orders**
OneToMany: one **order** has many order **items**
OneToOne: one **order item** has one **product**

### Step 1. Entity classes

**Customer.Java**
```java
package com.platform.ecommerce.order.model;  
  
import io.quarkus.hibernate.orm.panache.PanacheEntity;  
import jakarta.persistence.*;  
  
import java.util.ArrayList;  
import java.util.List;  
  
  
@Entity  
public class Customer extends PanacheEntity{  
  
  
    @Column(nullable = false)  
    public  String name;  
  
    @Column(nullable = false)  
    public  String surname;  
  
    @Column(nullable = false)  
    public  String email;  
  
    @Column(nullable = false)  
    public  String address;  
    @Column(nullable = false)  
    public  String phone;  
  
    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)  
    @JsonIgnore  
    public List<Order> orderList = new ArrayList<>();  
  
}  
```

**Order.Java**

```java
package com.platform.ecommerce.order.model;  
  
  
import io.quarkus.hibernate.orm.panache.PanacheEntity;  
import io.quarkus.logging.Log;  
import io.quarkus.panache.common.Sort;  
import jakarta.persistence.*;  
import jakarta.transaction.Transactional;  
import org.hibernate.annotations.CreationTimestamp;  
import jakarta.persistence.Column;  
  
import java.time.ZonedDateTime;  
import java.util.ArrayList;  
import java.util.List;  
  
@Entity  
@Table(name = "orders")  
public class Order extends PanacheEntity {  
  
  
    @Column(nullable = false)  
    public double totalAmount;  
  
    @Column(nullable = false)  
    public String status;  
  
  
    @CreationTimestamp  
    @Column(updatable = false, nullable = false)  
    public ZonedDateTime created;  
  
    @ManyToOne()  
    @JoinColumn(name = "customerid", nullable = false)  
    public Customer customer;  
  
    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true)  
    public List<OrderItem> orderItems = new ArrayList<>();  
  
  
    @Transient  
    public void setTotalPrice() {  
        double total = 0D;  
        for (OrderItem item : orderItems) {  
            total += item.totalAmount;  
        }  
        totalAmount = total;  
    }  
  
  
    public static Order findOrderById(Long id) {  
        return findById(id);  
    }  
  
    public static List<Order> findOrdersByStatus(String status) {  
        List<Order> orderList = Order.list("status", Sort.by("customer.id").and("created"), status);  
        return orderList;  
    }  
  
    public static List<Order> findOrdersByCustomerId(Long customerId) {  
        List<Order> orderList = Order.list("customer.id", Sort.by("created"), customerId);  
        return orderList;  
    }  
  
    @Transactional  
    public static void createOrder(Long customerId, Order order) {  
        Customer customer = Customer.findById(customerId);  
        order.customer = customer;  
        order.persist();  
    }  
  
    @Transactional  
    public static void addOrderItem(Long orderId, Product product, Integer quantity) {  
        Order order =  findOrderById(orderId);  
        OrderItem orderItem = new OrderItem(order,product,quantity);  
        order.orderItems.add(orderItem);  
        order.setTotalPrice();  
        order.persist();  
    }  
  
  
  
    @Transactional  
    public static void updateOrderItemQuantity(Long orderId, Long productId, Integer quantity) {  
        Order order =  findOrderById(orderId);  
        Log.info("Order found:"+order.id);  
  
        OrderItem orderItem = order.orderItems.stream().filter(o -> productId.equals(o.product.id)).findFirst().orElse(null);  
        Log.info("Order item found:"+orderItem.id);  
  
        orderItem.quantity = quantity;  
        Log.info("Update quantity to:"+quantity);  
  
        orderItem.setTotalPrice();  
        order.setTotalPrice();  
        order.persist();  
    }  
  
    @Transactional  
    public static void updateOrderStatus(Long id, String status) {  
        Order order = findOrderById(id);  
        order.status = status;  
        order.persist();  
    }  
  
    @Transactional  
    public static void deleteOrderItem(Long orderId, Long productId) {  
        Order order = findOrderById(orderId);  
        Log.info("Order found:"+order.id);  
  
        OrderItem orderItem = order.orderItems.stream().filter(o -> productId.equals(o.product.id)).findFirst().orElse(null);  
        Log.info("Order item found:"+orderItem.id);  
  
        order.orderItems.remove(orderItem);  
        Log.info("Remove item:"+orderItem.id);  
  
        order.setTotalPrice();  
        order.persist();  
    }  
  
  
    @Transactional  
    public static void deleteOrder(Long id) {  
        findById(id).delete();  
    }    
}
```

Tip:Notice how the functionality of adding order items and removing order items is done within the addOrderItem and removeOrderItem functions of the orders class. Since we are using **CascadeType.ALL** at the **@OneToMany** relationship any change to the list of orderItems, which is a change in the parent entity will be propagated to the child class which in this case is the OrderItem.

**In addition we are using the productId and not the OrderItem id to search through the list of OrderItems.**

**OrderItem.Java**
```java
package com.platform.ecommerce.order.model;  
  
import io.quarkus.hibernate.orm.panache.PanacheEntity;  
import jakarta.persistence.*;  
  
@Entity  
public class OrderItem extends PanacheEntity {  
  
  
    //default constructor  
    public OrderItem() {  
    }  
  
  
    public OrderItem(Order order, Product product, Integer quantity) {  
        this.order = order;  
        this.product = product;  
        this.quantity = quantity;  
        totalAmount = product.price*quantity;  
    }  
  
    public Long getId() {  
        return id;  
    }  
  
  
    @Column(nullable = false)  
    public double totalAmount;  
      
    @Column(nullable = false)  
    public Integer quantity;  
  
    @Transient  
    public Long productId;  
  
    @OneToOne  
    @JoinColumn(name = "productid",referencedColumnName = "id",insertable = true,updatable = false)  
    public Product product = new Product();  
  
  
    @ManyToOne(optional = false, fetch = FetchType.EAGER)  
    @JoinColumn(name="orderid", nullable=false)  
    @JsonIgnore  
    public Order order;  
  
  
    @Transient  
    public void  setTotalPrice() {  
        totalAmount = product.price*quantity;  
    }  
}  
```

### Step 2. Create Resource Endpoint for Orders.

**OrderResource.java**
```java
package com.platform.ecommerce.order.resource;  
   
import com.platform.ecommerce.order.model.OrderItem;  
import com.platform.ecommerce.order.model.Order;  
import io.quarkus.logging.Log;  
import jakarta.enterprise.context.ApplicationScoped;  
import jakarta.inject.Inject;  
import jakarta.ws.rs.*;  
import jakarta.ws.rs.core.MediaType;  
import jakarta.ws.rs.core.Response;  
  
  
import java.util.List;  
  
@Path("order-service/v1/order")  
@ApplicationScoped  
@Produces(MediaType.APPLICATIONJSON)  
@Consumes(MediaType.APPLICATIONJSON)  
  
public class OrderResource {  
  
    @GET  
    @Path("all")  
    public List<Order> getAllOrders() {return Order.listAll(); }  
  
    @GET  
    @Path("{id}")  
    public Order findById(@PathParam("id") Long id) {  
         Order order = Order.findById(id);  
         return order;  
    }  
  
    @POST  
    @Path("create/{customerId}")  
    public Response createOrder(@PathParam("customerId") Long customerId, Order order) {  
        Order.createOrder(customerId,order);  
        Log.info("Order created:"+order.id);  
        return Response.status(Response.Status.CREATED).build();  
    }  
    @PUT  
    @Path("update/status/{id}")  
    public Response updateOrderStatus(@PathParam("id") Long id, String status) {  
        Order.updateOrderStatus(id,status);  
        return Response.status(Response.Status.NOCONTENT).build();  
    }  
    @Path("add/item/{orderId}")  
    @POST  
    public Response addOrderItem(@PathParam("orderId") Long orderId, OrderItem orderItemForm) {  
       Product product = Product.findProductById(orderItemForm.productId);  
       Order.addOrderItem(orderId, product, orderItemForm.quantity);  
       return Response.status(Response.Status.OK).build();  
             
    }  
  
    @Path("update/item/{orderId}")  
    @PUT  
    public Response updateOrderItemQuantity(@PathParam("orderId") Long orderId, OrderItem orderItemForm) {  
            Order.updateOrderItemQuantity(orderId,orderItemForm.productId,orderItemForm.quantity);  
            return Response.status(Response.Status.OK).build();  
    }  
  
    @Path("delete/item/{orderId}")  
    @PUT  
    public Response deleteOrderItem(@PathParam("orderId") Long orderId, OrderItem orderItemForm) {  
        Order.deleteOrderItem(orderId,orderItemForm.productId);  
        return Response.status(Response.Status.OK).build();  
    }  
  
    @GET  
    @Path("customer/{id}")  
    public  List<Order> findOrdersByCustomerId(@PathParam("id") Long id) {  
        return Order.findOrdersByCustomerId(id);  
    }  
  
    @DELETE  
    @Path("delete/{id}")  
    public Response deleteOrder(@PathParam("id") Long id) {  
        Order.deleteOrder(id);  
        return Response.status(Response.Status.OK).build();  
    }  
}
```

### Step 3. Add Sample Data for Customers.

To load SQL statements when Hibernate ORM starts, add an `import.sql` file to the root of your `resources` directory. This script can contain any SQL DML statements. Make sure to terminate each statement with a semicolon.(Source:[https://quarkus.io/guides/hibernate-orm](https://quarkus.io/guides/hibernate-orm)).

We have already added some custom data for products in the first part. Now its time to add a couple of customer records.

**import.sql**
```sql
INSERT INTO customer (id, name, surname,email,address,phone) VALUES ( nextval('customerseq'), 'Marco','Verratti','marco.verratti@gmail.com','Princes Park (Le Parc des Princes)','000000000');  
INSERT INTO customer (id, name, surname,email,address,phone) VALUES ( nextval('customerseq'), 'Kylian','Mbappé','kylian.mbappé@gmail.com','Princes Park (Le Parc des Princes)','000000000');  
  
INSERT INTO product (id, name, price,stock) VALUES ( nextval('productseq'), 'MacMini M1',699.00,0);  
INSERT INTO product (id, name, price,stock) VALUES ( nextval('productseq'), 'MacMini M2',899.00,5);  
INSERT INTO product (id, name, price,stock) VALUES ( nextval('productseq'), 'MacBook Air M1',999.00,100);  
INSERT INTO product (id, name, price,stock) VALUES ( nextval('productseq'), 'MacBook Air M2',1399.00,100);  
INSERT INTO product (id, name, price,stock) VALUES ( nextval('productseq'), 'MacStudio M2 Max',2390.00,100);  
INSERT INTO product (id, name, price,stock) VALUES ( nextval('productseq'), 'MacStudio M2 Ultra',4399.00,100);
```
### Step 4. Create Testing for our Orders Endpoint.

Its time to write our Test for our OrderResource. I’m using the @Order annotation to specify the order of execution. For this test we create 1 order, then we add 1 order item of product with id:1 and quantuty 2. Then we update the quantity to 40 and test again. Finally we delete the order item and test if we are fetching an order with an empty list of order items.
```java
package com.platform.ecommerce.order.resource;  
  
import com.platform.ecommerce.order.model.OrderStatus;  
import com.platform.ecommerce.order.model.OrderItem;  
import io.quarkus.test.common.http.TestHTTPEndpoint;  
import io.quarkus.test.junit.QuarkusTest;  
import jakarta.json.Json;  
import jakarta.json.JsonObject;  
import jakarta.ws.rs.core.MediaType;  
import org.junit.jupiter.api.*;  
import static io.restassured.RestAssured.given;  
  
@QuarkusTest  
@TestHTTPEndpoint(OrderResource.class)  
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)  
public class OrderResourceTest {  

    @Test  
    @Order(1)  
    public void createOrder() {  
  
        JsonObject order = Json.createObjectBuilder()  
                .add("status", OrderStatus.Pending).build();  

        // Test POST  
        given()  
                .contentType(MediaType.APPLICATIONJSON)  
                .body(order.toString())  
                .when()  
                .when().post("create/{customerId}",1)  
                .then()  
                .statusCode(201);  
    }  
  
    @Test  
    @Order(2)  
    public void addOrderItem() {  
  
        JsonObject orderItem = Json.createObjectBuilder()  
                .add("productId", 1)  
                .add("quantity", 2)  
                .build();  
  
  
        // Test POST  
        given()  
                .contentType(MediaType.APPLICATIONJSON)  
                .body(orderItem.toString())  
                .when()  
                .when().post("add/item/{orderId}",1)  
                .then()  
                .statusCode(200);  
    }  
  
  
    @Test  
    @Order(3)  
    public void whenFetchOrderThenAtLeastOneOrderShouldBeFound() {  
        //TEST GET  
        com.platform.ecommerce.order.model.Order order = given()  
                .accept(MediaType.APPLICATIONJSON)  
                .when().get("{id}",1)  
                .then()  
                .statusCode(200)  
                .extract()  
                .body().as(com.platform.ecommerce.order.model.Order.class);  
  
    }  
  
  
    @Test  
    @Order(4)  
    public void whenUpdateOrderItemQuantityThenQuantityShouldBeEqual() {  
        JsonObject orderItemJSON = Json.createObjectBuilder()  
                .add("productId", 1)  
                .add("quantity", 40)  
                .build();  
  
        // Test UPDATE  
        given()  
                .contentType(MediaType.APPLICATIONJSON)  
                .body(orderItemJSON.toString())  
                .when().put("update/item/{orderId}",1)  
                .then()  
                .statusCode(200);  
  
        //FETCH ORDER  
        com.platform.ecommerce.order.model.Order order = given()  
                .accept(MediaType.APPLICATIONJSON)  
                .when().get("{id}",1)  
                .then()  
                .statusCode(200)  
                .extract()  
                .body().as(com.platform.ecommerce.order.model.Order.class);  
  
  
        //EXTRACT THE ORDER ITEM FOR PRODUCT WITH ID=1  
        OrderItem orderItem = order.orderItems.stream().filter(o -> o.product.id.intValue()==1).findFirst().orElse(null);  
        Assertions.assertEquals(orderItem.quantity,40);  
  
    }  
  
  
    @Test  
    @Order(4)  
    public void whenDeleteOrderItemThenSizeOfItemsShouldBeZero() {  
        JsonObject orderItemJSON = Json.createObjectBuilder()  
                .add("productId", 1)  
                .build();  
  
        // Test UPDATE  
        given()  
                .contentType(MediaType.APPLICATIONJSON)  
                .body(orderItemJSON.toString())  
                .when().put("delete/item/{orderId}",1)  
                .then()  
                .statusCode(200);  
  
        //FETCH ORDER  
        com.platform.ecommerce.order.model.Order order = given()  
                .accept(MediaType.APPLICATIONJSON)  
                .when().get("{id}",1)  
                .then()  
                .statusCode(200)  
                .extract()  
                .body().as(com.platform.ecommerce.order.model.Order.class);  
  
  
        //EXTRACT THE ORDER ITEM FOR PRODUCT WITH ID=1  
        Assertions.assertEquals(order.orderItems.size(),0);  
  
    }  
  
}  
```

Last step is to open up a terminal and run the test by typing

mvn clean test

Run the program by typing **mvn quarkus:dev** if you are using maven or if you are using quarkus cli type **quarkus dev**
```shell
mvn quarkus:dev  
```
OR   
```shell
quarkus dev
```
That’s all!

Our system is a basic one and there is lots of functionality to be added.

> **its a monolithic application. Also all the ‘product’ functionality is handled by this application, although it should be handled in a separate micro-service one.**
> 
> **For the purpose of the tutorial I did that on-purpose, and in the articles to come will we break our application into 2 different ones, into 2 different micro services.**

In addition in the next articles we will explore how we can add security, how to check items from the inventory, configuration profiles, kubernetes deployments and much more.

Thank you for reading this article!

TUTORIAL PARTS

[Part 1: Quarkus Persistence, CRUD with Panache. E-commerce example.](/javarevisited/part-1-crud-with-panache-orm-in-quarkus-an-eshop-example-cd37ccf051e2)

[Part 2: Quarkus Persistence, CRUD with Panache. E-commerce example.](/javarevisited/part-2-quarkus-persistence-crud-with-panache-e-commerce-example-a19aa5af13d9)

[Part 3.1: Quarkus. From Monolithic to a MicroService Architecture. Branch By Abstraction. REST Client Reactive. E-commerce example.](/@georgesotiropoulos23050/part-3-1-quarkus-e1b8f9732a5f)

---
### Microservices & 'Branch by Abstraction'

Branch By Abstraction’ & ‘Database-Per-Service’ patterns implementation using Quarkus REST Client Reactive and Feature Toggles.E-commerce Case Study.

In the [previous article](/javarevisited/part-3-1-quarkus-e1b8f9732a5f) of migrating our monolithic application to a micro-service architecture we discussed about the patterns, the challenges faced and we refactored our **order-service** adding a new abstraction service layer, thus enabling fetching product related data such as a single product and stock availablity info from a hypothetical **inventory-service** using [Quarkus REST Client [1]](https://quarkus.io/guides/rest-client-reactive).

In this tutorial we are finally building this **inventory-service.**

### STEP 1. Create the new Inventory Micro Service.

We start by creating a new Quarkus application named **inventory-service**. Open up a terminal and execute the following command to create a quarkus project using mvn or quarkus CLI.

**MVN**
```shell
mvn io.quarkus:quarkus-maven-plugin:3.4.1.Final:create   
    -DprojectGroupId=com.platform.ecommerce.inventory   
    -DprojectArtifactId=inventory-service
```
**OR using Quarkus CLI**
```shell
quarkus create app com.platform.ecommerce.inventory:inventory-service
```
We also need to add the following extensions for a) Postgres JDBC Driver support, b) Hibernate Panache ORM, c) Rest ‘Server’ Reactive functionality in order to provide JSON REST Services

**a) jdbc-postgresql  
b) hibernate-orm-panache  
c) resteasy-reactive-jackson**

In order to add the above extensions open up a terminal with inventory-service folder and type:
```shell
quarkus extension add 'resteasy-reactive-jackson' 'quarkus-hibernate-orm-panache' 'quarkus-jdbc-postgresql'
```
### STEP 2. Create the Database for our inventory Service

First you have to create a new separate database for our inventory service, and add a new user with the necessary privileges. Open the postgres terminal and type:
```sql
create database ecommerceinventorydb;  
create user ecommerceinventoryusr with  password 'password';  
grant all privileges on database ecommerceinventorydb to ecommerceinventoryusr;  
grant all on schema public to ecommerceinventoryusr;
```

Tip:PostgreSQL version 15+ doesn’t allow to create objects in public schema, you need to explicitly specify that hence ‘**grant all on schema public to ecommerceinventoryusr**’ . If for some reason you still cannot create tables use the **route user** to connect to ecommerceinventorydb for the shake of this tutorial.

Add the relevant configuration properties for postgresSQL as well as a new **port 8091** in `application.properties` in our **inventory-service** project.

> Remember that our order micro-service declared port 8091 in **applcation.properties** as the config-key for the i**nventory-service REST** client.

**inventory-service/application.properties**
```shell
### configure your datasource  
quarkus.datasource.db-kind = postgresql  
quarkus.datasource.username = ecommerceinventoryusr  
quarkus.datasource.password = password  
quarkus.datasource.jdbc.url = jdbc:postgresql://localhost:5432/ecommerceinventorydb  
quarkus.hibernate-orm.database.generation = drop-and-create  
  
### Server Port of Quarkus Inventory Micro Service  
quarkus.http.port=8091
```
### STEP 3. Design the Inventory Domain Model.

The Design of an inventory management system is not the easiest task on planet. For the purpose of the tutorial series, we are going to be as much specific as possible since inventory is a crucial micro-service and interacts with numerous other micro-services such as catalog, order, shipping etc.

**We are not going to model the internal ordering and restocking, but only things that matter such as products, product categories, warehouses, suppliers, inventory stock levels and locations.**

Therefore we need a robust logical model. Not over-engineered and at the same time with enough information to support this series of tutorials.

> Inventory Management systems handle things such as Inter Product Transfer between one warehouse and another as well as Ordering from Suppliers etc. We are not going to model this functionality at this point.

**3.1 The Model**

The logical model we are going to build is shown in the below figure.

![](https://miro.medium.com/v2/resize:fit:875/1*P2afvII42wFGT5GUZLKWlA.png)
Figure 1. Model of the inventory-service.

**3.2 The Product**

> Let’s explain few things first. The foundation of our system design begins with products. Various industries and business sectors feature distinct product attributes; for instance, clothing includes material, size, and color, while cars encompass attributes such as color, trim level, and engine type.

**This article will concentrate on the attributes essential for constructing our model, rather than those specific to sales or other operational aspects.**

**Product.java**
```java
package com.platform.ecommerce.inventory.model;  
  
import io.quarkus.hibernate.orm.panache.PanacheEntity;  
import jakarta.persistence.*;  
import jakarta.transaction.Transactional;  
import org.hibernate.annotations.CreationTimestamp;  
  
import java.time.ZonedDateTime;  
import java.util.*;  
import java.util.function.Predicate;  
  
@Entity  
public class Product extends PanacheEntity  {  
  
    @Column(unique = true, nullable = false)  
    public  String SKU;  
  
    @Column(nullable = false,unique = true)  
    private String barCode;  
  
    @Column(nullable = false,unique = true)  
    public String UUID;  
  
    @Column(nullable = false)  
    public  String name;  
  
    @Column  
    private String description;  
  
    @Column  
    private Double price;  
  
    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)  
    @JoinColumn(name = "categoryid", nullable = false)  
    private Category category;  
  
    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)  
    @JoinColumn(name = "supplierid", nullable = false)  
    private Supplier supplier;  
  
    @OneToMany(fetch = FetchType.EAGER, mappedBy = "product", cascade = CascadeType.ALL)  
    public List<Inventory> inventories = new ArrayList<>();  
  
    private Inventory getOptimalinventory() {  
        Optional<Inventory> inventory = inventories.stream().max(Comparator.comparing(Inventory::getQuantityInStock));  
        return inventory.orElse(inventories.get(0));  
    };  
  
    public Integer getStock() {  
        return getOptimalinventory().getQuantityInStock();  
    }  
  
  
    @CreationTimestamp  
    public ZonedDateTime created;  
  
    public Product() {}  
  
    public static Product findProductByUUID(String UUID) {  
        return find("UUID", UUID).firstResult();  
    }  
    public static Product findProductById(Long id) {  
        return findById(id);  
    }  
    public static Product findByName(String name){      return find("name", name).firstResult();  }  
  
    public static List<Product>  findByCategory(String category){      return find("categoryid", category).list();  }  
  
    public static List<Product> findByMaximumPrice(double price) {  
        return find("price < ?1", price).list();  
    }  
  
    public static List<Product> findByMinimumPrice(double price) {  
        return find("price > ?1", price).list();  
    }  
  
    public static void deleteProduct(Long id) {  
        findById(id).delete();  
    }  
  
    @Transactional  
    public static void deleteAllProducts() {  
        deleteAll();  
    }  
  
    @Transactional  
    public static void updateProduct(String UUID, Product newProduct) {  
        Product productToBeUpdated = findProductByUUID(UUID);  
        productToBeUpdated.name = newProduct.name;  
        productToBeUpdated.description = newProduct.description;  
        productToBeUpdated.price = newProduct.price;  
    }  
  
  
    @Transactional  
    public static void createProduct(Product product) {  
        product.persist();  
    }  
  
}
```

**3.3 Categories**

> A Product belongs to a Product Category. Multiple categories exist and modeled in a hierarchy structure.

**Category.java**
```java
package com.platform.ecommerce.inventory.model;  
  
import io.quarkus.hibernate.orm.panache.PanacheEntity;  
import io.quarkus.hibernate.orm.panache.PanacheEntityBase;  
import jakarta.persistence.*;  
import org.hibernate.annotations.CreationTimestamp;  
  
import java.time.ZonedDateTime;  
import java.util.*;  
  
  
@Entity  
public class Category extends PanacheEntity {  
  
  
    @Column(unique = true, nullable = false)  
    public  String name;  
  
    @Column  
    public UUID uuid = UUID.randomUUID();  
  
  
    @ManyToOne  
    @JoinColumn(name = "parentid")  
    private Category parent;  
  
    @OneToMany(mappedBy = "parent", cascade = CascadeType.REMOVE, orphanRemoval = true)  
    private List<Category> children = new ArrayList<Category>();  
  
  
    @CreationTimestamp  
    public ZonedDateTime created;  
  
  
    //Here mappedBy indicates that the owner is in the other side  
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "category", cascade = CascadeType.ALL)  
    private Set<Product> products = new HashSet<Product>();  
  
}
```

**3.4 Suppliers**

> Every Product is supplied by one specific Supplier. The Supplier of course has a contact person who picks up the phone and takes the order to restock.

**Supplier.java**
```java
package com.platform.ecommerce.inventory.model;  
  
  
import io.quarkus.hibernate.orm.panache.PanacheEntity;  
import jakarta.persistence.*;  
  
import java.util.HashSet;  
import java.util.Set;  
  
@Entity  
public class Supplier extends PanacheEntity {  
  
    private String companyName;  
  
    private String contactName;  
  
    private String contactTitle;  
  
    @OneToOne  
    @JoinColumn(name = "locationid",referencedColumnName = "id",insertable = true,updatable = true)  
    public Location location = new Location();  
  
    private String phone;  
  
    private String fax;  
  
  
    //Here mappedBy indicates that the owner is in the other side  
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "supplier", cascade = CascadeType.ALL)  
    private Set<Product> products = new HashSet<Product>();  
  
}
```

**3.4 Product — Inventory — Warehouse Relationship Modeling.**

> A Single Product can exist in multiple Warehouses across the continent or across different continents. In addition each Warehouse may have different stock levels of the product.

H**ow do we actually model that Many to Many Relationship between Product and Warehouse? By Introducing The ‘Inventory’ Entity.**

> The inventory entity plays a pivotal role as it symbolizes the connection between products and warehouses. Each product can be present in multiple warehouses, while each warehouse can house a diverse range of products.

> Beyond merely establishing this relationship, it is essential to store supplementary data, such as product quantities available. Therefore, we will introduce an entity to encapsulate this association, **featuring fundamental stock level attributes such as**
> 
> **a) minimum stock level before auto-order kicks-in  
> b) maximum stock that the warehouse can manage and  
> c) current stock level ‘quantityInStock’.**

**Inventory.java**
```java
package com.platform.ecommerce.inventory.model;  
  
import com.fasterxml.jackson.annotation.JsonIgnore;  
import io.quarkus.hibernate.orm.panache.PanacheEntity;  
import jakarta.persistence.*;  
import java.util.function.Predicate;  
  
@Entity  
public class Inventory extends PanacheEntity {  
  
    @Column(nullable = false)  
    private Integer minimumStockLevel;  
  
    @Column(nullable = false)  
    private Integer maximumStockLevel;  
  
    @Column(nullable = false)  
    private Integer quantityInStock;  
  
    @Column(nullable = false)  
    private Integer quantityOnOrder;  
  
  
    @ManyToOne(optional = false, fetch = FetchType.EAGER)  
    @JoinColumn(name="productid", nullable=false)  
    @JsonIgnore  
    public Product product;  
  
    @ManyToOne(optional = false, fetch = FetchType.EAGER)  
    @JoinColumn(name="warehouseid", nullable=false)  
    @JsonIgnore  
    public Warehouse warehouse;  
  
  
    public Integer getQuantityInStock() {  
        return quantityInStock;  
    }  
  
    public void setQuantityInStock(Integer quantityInStock) {  
        this.quantityInStock = quantityInStock;  
    }  
}
```
**3.5 Location**

> Finally the location entity holds information about the geographical sites where both warehouses and suppliers are situated. Many organizations operate across multiple locations, and each of these locations may comprise one or more warehouses.

**Location.java**
```java
package com.platform.ecommerce.inventory.model;  
  
import io.quarkus.hibernate.orm.panache.PanacheEntity;  
import jakarta.persistence.Column;  
import jakarta.persistence.Entity;  
  
@Entity  
public class Location extends PanacheEntity {  
  
    @Column(nullable = false)  
    public  String address;  
  
    @Column(nullable = false)  
    public  String city;  
  
    @Column(nullable = false)  
    public  String region;  
      
     @Column(nullable = false)  
    public  String postalCode;  
  
    @Column(nullable = false)  
    public  String country;  

}

```

### STEP 4. Transfering ‘Product’ domain code from order-service to the new inventory-service.

Since both of our micro-services sharing the ‘Product’ entity we are going to transfer the product code from **order-service** to **inventory-service** and **enrich** it.

> For start we need to open both of our projects order-service and inventory-service in **IntelliJ** IDEA. The good thing about Macs and **IntelliJ** is that you can have multiple projects opened in tabs.

**1. Create Product Resource REST API.**

C**OPY:**order-service**/**ProductResource.java -> inventory-service/ProductResource.java

We start our domain transfer process by coping **ProductResource** code from **order-service** to inventory-service within a new package named **com.platform.ecommerce.inventory.resource**.

We also change the REST path to ‘**inventory-service/v1/product’** and we implement the new **checkStockAvailability** method and **findProductByUUID** method. We also clean the code from any bounded logic to the monolithic application. The end result is:

**inventory-service/ProductResource.java**
```java
package com.platform.ecommerce.inventory.resource;  
  
  
import com.platform.ecommerce.inventory.model.InventoryProductRecord;  
import com.platform.ecommerce.inventory.model.InventoryStockResultRecord;  
import com.platform.ecommerce.inventory.model.Product;  
import com.platform.ecommerce.inventory.service.IInventoryService;  
import io.quarkus.logging.Log;  
import jakarta.enterprise.context.ApplicationScoped;  
import jakarta.inject.Inject;  
import jakarta.ws.rs.*;  
import jakarta.ws.rs.core.*;  
  
import java.net.URI;  
import java.util.List;  
  
  
@Path("inventory-service/v1/product")  
@ApplicationScoped  
@Produces(MediaType.APPLICATIONJSON)  
@Consumes(MediaType.APPLICATIONJSON)  
  
public class ProductResource {  
  
  
    @Inject  
    IInventoryService inventoryService;  
  
    @GET  
    @Path("all")  
    public List<Product> getAllProducts() {  
        return Product.listAll();  
    }  
  
    @GET  
    @Path("uuid/{UUID}")  
    public InventoryProductRecord findProductByUUID(@PathParam("UUID") String UUID) {  
        Log.infof(":request item  details with id: %s from inventory",UUID);  
        InventoryProductRecord productRecordResult = inventoryService.findProductByUUID(UUID);  
        return inventoryService.findProductByUUID(UUID);  
  
    }  
  
    @GET  
    @Path("stock/availability/{UUID}/{quantity}")  
    public InventoryStockResultRecord checkStockAvailability(@PathParam("UUID") String UUID, @PathParam("quantity") Integer quantity) {  
        InventoryStockResultRecord stockAvailabilityResult = inventoryService.checkStockAvailability(UUID,quantity);  
        Log.infof(":requested quantity %s of  inventory item: %s.  Available quantity is:  %s",quantity,stockAvailabilityResult.productUUID(),stockAvailabilityResult.availableQuantity());  
        return stockAvailabilityResult;  
    }  
    @GET  
    @Path("category/{category}")  
    public List<Product>  findByCategory(@QueryParam("category") String category) {  
        return Product.findByCategory(category);  
    }  
  
    @GET  
    @Path("price/maximum/{price}")  
    public List<Product> findByMaximumPrice(@PathParam("price") double price) {  
        return Product.findByMaximumPrice(price);  
    }  
  
    @GET  
    @Path("price/minimum/{price}")  
    public List<Product> findByMinimumPrice(@PathParam("price") double price) {  
        return Product.findByMinimumPrice(price);  
    }  
  
    @POST  
    @Path("create")  
    public Response createProduct(Product product) {  
        Product.createProduct(product);  
  
        Log.info("Product created:"+product.UUID);  
        return Response.status(Response.Status.CREATED).build();  
  
    }  
  
    @PUT  
    @Path("update/{UUID}")  
    public Response updateProduct(@PathParam("UUID") String UUID, Product product) {  
        Product.updateProduct(UUID,product);  
        Log.info("Product updated:"+product.UUID);  
        return Response.status(Response.Status.OK).build();  
    }  
  
}
```

**2. Create Persistent Service Layer Service.**

We then move forward and create our Persistent Service Layer by creating a new interface **InventoryService** and the implemenetation of it **PostGRESDatabaseService.**

**InventoryService.java**
```java
package com.platform.ecommerce.inventory.service;  
  
import com.platform.ecommerce.inventory.model.InventoryProductRecord;  
import com.platform.ecommerce.inventory.model.InventoryStockResultRecord;  
  
  
public interface IInventoryService {  
  
  
    InventoryProductRecord findProductByUUID(String UUID);  
  
    InventoryStockResultRecord checkStockAvailability(String UUID, Integer quantity);  
 
}
```

**PostGRESDatabaseService.java**
```java
package com.platform.ecommerce.inventory.service;  
  
import com.platform.ecommerce.inventory.model.InventoryProductRecord;  
import com.platform.ecommerce.inventory.model.InventoryStockResultRecord;  
import com.platform.ecommerce.inventory.model.Product;  
import io.quarkus.arc.DefaultBean;  
import jakarta.enterprise.context.ApplicationScoped;  
  
@ApplicationScoped  
@DefaultBean  
public class PostGRESDatabaseService implements IInventoryService {  
  
  
    @Override  
    public InventoryProductRecord findProductByUUID(String UUID) {  
          Product product = Product.findProductByUUID(UUID);  
        InventoryProductRecord productResult = new InventoryProductRecord(product);  
          return productResult;  
    }  
  
    @Override  
    public InventoryStockResultRecord checkStockAvailability(String UUID, Integer requestedQuantity) {  
        Product product = Product.findProductByUUID(UUID);  
        InventoryStockResultRecord availabilityResult = new InventoryStockResultRecord(product,requestedQuantity);  
        return availabilityResult;  
    }  
  
}
```

**3. Create or Copy Value Objects**

We continue our domain transfer process by coping the necessary **Data Transfer Objects — Or Else Value Objects in Domain Design Terms —** from **order-service** to inventory-service within package **com.platform.ecommerce.inventory.model.**

These objects are **InventoryProductRecord** and **InventoryStockResultRecord.**

### STEP 5. Populate inventory DB with Sample Product Data.

We also populating our newly created database with proper sample data this time.

**inventory-service/import.sql**

```sql 
------------------------------- CATEGORIES -----------------------------------------------------  
  
  
-- PARENT 1 Mac  
INSERT INTO category(id, parentid, name) VALUES ( 100, null, 'Mac');  
-- PARENT 2 iPad  
INSERT INTO category(id, parentid, name) VALUES ( 200, null, 'iPad');  
-- PARENT 3  IPhone  
INSERT INTO category(id, parentid, name) VALUES ( 300, null, 'iPhone');  
  
  
-- CHILD 1 OF  PARENT 1  
INSERT INTO category(id, parentid, name) VALUES ( 101, 100, 'Mac Studio');  
-- CHILD 2 OF  PARENT 1  
INSERT INTO category(id, parentid, name) VALUES ( 102, 100, 'Mac Mini');  
-- CHILD 3 OF  PARENT 1  
INSERT INTO category(id, parentid, name) VALUES ( 103, 100, 'Mac Book');  
-- CHILD 4 OF  PARENT 1  
INSERT INTO category(id, parentid, name) VALUES ( 104, 100, 'Mac Pro');  
  
-- CHILD 1 OF  PARENT 2  
INSERT INTO category(id, parentid, name) VALUES ( 201, 200, 'Ipad Pro');  
-- CHILD 2 OF  PARENT 2  
INSERT INTO category(id, parentid, name) VALUES ( 202, 200, 'Ipad Air');  
  
-- CHILD 1 OF  PARENT 3  
INSERT INTO category(id, parentid, name) VALUES ( 301, 300, 'IPhone 13');  
-- CHILD 2 OF  PARENT 3  
INSERT INTO category(id, parentid, name) VALUES ( 302, 300, 'IPhone 14');  
  
  
------------------------------- Locations -----------------------------------------------------  
  
-- Location 1  
INSERT INTO location(id, address, city, country, postalcode, region)  
VALUES (101, '123 Main St', 'New York', 'USA', '10001', 'East Coast');  
  
-- Location 2  
INSERT INTO location(id, address, city, country, postalcode, region)  
VALUES (102, '456 Elm St', 'Los Angeles', 'USA', '90001', 'West Coast');  
  
-- Location 3  
INSERT INTO location(id, address, city, country, postalcode, region)  
VALUES (103, '789 Oak St', 'Chicago', 'USA', '60601', 'Midwest');  
  
-- Location 4  
INSERT INTO location(id, address, city, country, postalcode, region)  
VALUES (104, '101 Pine St', 'London', 'UK', 'SW1A 1AA', 'England');  
  
-- Location 5  
INSERT INTO location(id, address, city, country, postalcode, region)  
VALUES (105, '202 Maple St', 'Paris', 'France', '75001', 'Ile-de-France');  
  
  
  
------------------------------- Suppliers -----------------------------------------------------  
  
-- Supplier 1  
INSERT INTO supplier(id, locationid, companyname, contactname, contacttitle, fax, phone)  
VALUES (1, 101, 'Supplier A', 'John Doe', 'CEO', '555-123-4567', '555-987-6543');  
  
-- Supplier 2  
INSERT INTO supplier(id, locationid, companyname, contactname, contacttitle, fax, phone)  
VALUES (2, 102, 'Supplier B', 'Jane Smith', 'Sales Manager', '555-111-2222', '555-333-4444');  
  
-- Supplier 3  
INSERT INTO supplier(id, locationid, companyname, contactname, contacttitle, fax, phone)  
VALUES (3, 103, 'Supplier C', 'Robert Johnson', 'CFO', '555-555-5555', '555-666-6666');  
  
-- Supplier 4  
INSERT INTO supplier(id, locationid, companyname, contactname, contacttitle, fax, phone)  
VALUES (4, 104, 'Supplier D', 'Mary Brown', 'Marketing Director', '555-777-8888', '555-999-0000');  
  
-- Supplier 5  
INSERT INTO supplier(id, locationid, companyname, contactname, contacttitle, fax, phone)  
VALUES (5, 105, 'Supplier E', 'Michael Wilson', 'Supply Chain Manager', '555-123-7890', '555-456-7890');  
  
  
------------------------------- Products  -----------------------------------------------------  
  
  
-- Apple Product 1  
INSERT INTO product(id, categoryid, supplierid, sku, uuid, barcode, description, name)  
VALUES (1, 104, 1, 'MAC001', '4a05b88a-6e9f-4e94-b799-9d032b33d749', '123456789012', 'Powerful desktop computer for professionals', 'Mac Pro');  
  
-- Apple Product 2  
INSERT INTO product(id, categoryid, supplierid, sku, uuid, barcode, description, name)  
VALUES (2, 103, 1, 'MAC002', 'b74fe0a0-5799-4343-9820-251d4b3c49ef', '987654321098', 'Slim and lightweight laptop with Retina display', 'Mac Book');  
  
-- Apple Product 3  
INSERT INTO product(id, categoryid, supplierid, sku, uuid, barcode, description, name)  
VALUES (3, 102, 1, 'IPD001', '7d06a914-4ec3-42d1-821a-21ff8a98e13f', '654321098765', 'High-performance tablet with Apple Pencil support', 'iPad Pro');  
  
-- Apple Product 4  
INSERT INTO product(id, categoryid, supplierid, sku, uuid, barcode, description, name)  
VALUES (4, 101, 1, 'MST001', 'b3f42c5e-8c7e-4e8f-92f6-104a7a480932', '789012345678', 'Compact desktop computer for creative professionals', 'Mac Studio');  
  
-- Apple Product 5  
INSERT INTO product(id, categoryid, supplierid, sku, uuid, barcode, description, name)  
VALUES (5, 202, 1, 'IPA001', '6a5e89d0-17a6-4b5a-85de-12fb17001f9d', '543210987654', 'Lightweight and versatile iPad', 'iPad Air');  
  
-- Apple Product 6  
INSERT INTO product(id, categoryid, supplierid, sku, uuid, barcode, description, name)  
VALUES (6, 201, 1, 'IPA002', '14cfe9e5-5d5e-45d3-8b60-8d89e5cdd96e', '234567890123', 'Professional tablet with Apple Pencil support', 'iPad Pro');  
  
-- Apple Product 7  
INSERT INTO product(id, categoryid, supplierid, sku, uuid, barcode, description, name)  
VALUES (7, 301, 1, 'IPH001', 'a70c22b7-5a0e-4587-92e5-f85572ca075f', '345678901234', 'Latest iPhone with A15 Bionic chip', 'iPhone 13');  
  
-- Apple Product 8  
INSERT INTO product(id, categoryid, supplierid, sku, uuid, barcode, description, name)  
VALUES (8, 301, 1, 'IPH002', 'bc4e30d8-5089-4e35-94cc-d305c0906b22', '456789012345', 'Advanced iPhone with Pro camera system', 'iPhone 13 Pro');  
  
-- Apple Product 9  
INSERT INTO product(id, categoryid, supplierid, sku, uuid, barcode, description, name)  
VALUES (9, 301, 1, 'IPH003', '28aa1913-67a3-4929-ba4b-93019e00e3b5', '567890123456', 'Compact iPhone with powerful features', 'iPhone SE');  
  
-- Apple Product 10  
INSERT INTO product(id, categoryid, supplierid, sku, uuid, barcode, description, name)  
VALUES (10, 300, 1, 'IPH004', 'ad0da00c-2633-4dd1-9329-aa9437e208e4', '678901234567', 'Flagship iPhone with Pro Max camera system', 'iPhone 13 Pro Max');  
  
  
  
----------------------------------    Ware House  Data ------------------------------------  
  
-- USA Warehouse  
INSERT INTO public.warehouse(id, locationid, name) VALUES (1, 101, 'USA Warehouse');  
  
-- European Warehouse  
INSERT INTO public.warehouse(id, locationid, name) VALUES (2, 105, 'European WareHouse');  
  
  
  
----------------------------------    Inventory  Data ------------------------------------  
  
-- Inventory for Warehouse 1  
-- Product 1  
INSERT INTO inventory(id, productid, warehouseid, maximumstocklevel, minimumstocklevel, quantityinstock, quantityonorder)  
VALUES (1, 1, 1, 100, 10, 75, 5);  
  
-- Product 2  
INSERT INTO inventory(id, productid, warehouseid, maximumstocklevel, minimumstocklevel, quantityinstock, quantityonorder)  
VALUES (2, 2, 1, 150, 20, 120, 10);  
  
-- Product 3  
INSERT INTO inventory(id, productid, warehouseid, maximumstocklevel, minimumstocklevel, quantityinstock, quantityonorder)  
VALUES (3, 3, 1, 80, 5, 60, 5);  
  
-- Product 4  
INSERT INTO inventory(id, productid, warehouseid, maximumstocklevel, minimumstocklevel, quantityinstock, quantityonorder)  
VALUES (4, 4, 1, 200, 25, 180, 15);  
  
-- Product 5  
INSERT INTO inventory(id, productid, warehouseid, maximumstocklevel, minimumstocklevel, quantityinstock, quantityonorder)  
VALUES (5, 5, 1, 120, 10, 100, 8);  
  
  
  
-- Inventory for Warehouse 2  
-- Product 6  
INSERT INTO inventory(id, productid, warehouseid, maximumstocklevel, minimumstocklevel, quantityinstock, quantityonorder)  
VALUES (6, 6, 2, 90, 8, 70, 7);  
  
-- Product 7  
INSERT INTO inventory(id, productid, warehouseid, maximumstocklevel, minimumstocklevel, quantityinstock, quantityonorder)  
VALUES (7, 7, 2, 160, 15, 140, 12);  
  
-- Product 8  
INSERT INTO inventory(id, productid, warehouseid, maximumstocklevel, minimumstocklevel, quantityinstock, quantityonorder)  
VALUES (8, 8, 2, 70, 6, 50, 4);  
  
-- Product 9  
INSERT INTO inventory(id, productid, warehouseid, maximumstocklevel, minimumstocklevel, quantityinstock, quantityonorder)  
VALUES (9, 9, 2, 180, 18, 160, 10);  
  
-- Product 10  
INSERT INTO inventory(id, productid, warehouseid, maximumstocklevel, minimumstocklevel, quantityinstock, quantityonorder)  
VALUES (10, 10, 2, 110, 12, 95, 8);
```
### STEP 5. Run order-service and inventory-service.

> We need to open both of our projects order-service and inventory-service in **IntelliJ** IDEA. The good thing about Macs and **IntelliJ** is that you can have multiple projects opened in tabs.

That’s all! Our inventory-service is ready to run.

Open up a terminal within **inventory-service project** in IntelliJ and run the project by typing **quarkus dev**.

Our inventory-service should start and listen at **port 8091**. Leave it running.

### STEP 5. Enable the REST Client micro-service invocation functionality.

Now it is time to test if this new functionality actually works. In our **order-service project** in IntelliJ change the remote inventory “feature-toggle” to true

**microservices.inventory.release.enabled = true**

Then open up a terminal within **order-service project** run the test by typing **mvn clean test**.

EVERYTHING SHOULD BE WORKING FINE!

![](https://miro.medium.com/v2/resize:fit:875/1*UtngQLLEOCQJd-FX7Kabw.png)

Phew! At Last! We finally decompose our Monolith to actually a **smaller monolith (hahahah!)** by extracting the inventory functionality to a separate **micro-service.** We name our monolith **‘order-service’** and the new micro-service **inventory-service.**

We are using synchronous REST communication for their communication, using Quarkus REST Client to exchange Product Info Details and Stock Availability Info.

**Our prodution monolith runs as normal and with the use of ‘feature toggles’ and ‘Branch by Abstraction’ we can work towards the decomposition, without breaking apart the whole system.**

**That’s all for now guys.**

> **By no means the end result is a production ready microservices architecture but it is one of the first steps towards the decomposition of your production monolith.**
