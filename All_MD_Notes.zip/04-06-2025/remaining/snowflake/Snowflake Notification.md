# [2024] Send Email OR Send Snowflake Notification? Let’s Decode

![](https://miro.medium.com/v2/resize:fit:1250/1*b501fbL9aDlWAAJ00qWWiA.jpeg)

If you are using Snowflake for more than 2 years, you must be aware of snowflake native capabilities to setup Alerts and Notifications using SYSTEM$SENDEMAIL(). However there’s another system stored procedure which can be used to trigger notifications too!

SYSTEM$SENDSNOWFLAKENOTIFICATION() allows you to send a notification message to an email address or a queue provided by a Cloud service.

Let’s decode the difference between these two system stored procedures in details.

# Executive Summary

-   What SENDEMAIL() does?
-   What SENDSNOWFLAKENOTIFICATION() does?
-   Syntax Differences
-   Helper Functions for SENDSNOWFLAKENOTIFICATION()
-   Deciding What to Use?

# What SENDEMAIL() Does?

![](https://miro.medium.com/v2/resize:fit:875/1*lQm-evAkH4NQaG-0fEPPw.png)

The SYSTEM$SENDEMAIL() stored procedure to send email notifications.

It uses the notification integration object, which is a Snowflake object that provides an interface between Snowflake and third-party services.

The notifications are processed through Snowflake’s Amazon Web Services (AWS) deployments, using AWS Simple Email Service (SES).

> If you are on the Amazon Web Services (AWS) cloud platform, then the email notification message is sent from [**no-reply@snowflake.net**](mailto:no-reply@snowflake.net). If you are on the Google Cloud Platform (GCP) or Microsoft Azure (Azure) cloud platform, the email notification message is sent from [**do-not-reply@snowflake.net**](mailto:do-not-reply@snowflake.net).

# What SENDSNOWFLAKENOTIFICATION() Does?

![](https://miro.medium.com/v2/resize:fit:875/1*Aryxo0nRtMMRgdDoCT9oOA.png)

The SENDSNOWFLAKENOTIFICATIONS() stored Procedure allows:

-   You can send messages to multiple destinations such as emails or queues
-   You can send messages to multiple email addresses or queues
-   You can send messages with different formats according to notification integration
-   You can use multiple notification integrations in single call to send out notifications
-   You can specify configs in JSON format

## What’s the benefit?

This means, **with a single call**, you can send messages in plain text, HTML, and JSON formats to multiple email addresses and multiple SNS, PubSub, and Event Grid topics.

You can **use multiple notification integrations** to send the notification to different queues.

You can also **create multiple email notification integrations** that have different sets of email addresses and subject lines, **making it easier to configure** email messages for different recipients.

# Syntax Differences

## SYSTEM$SENDEMAIL()

The SYSTEM$SENDEMAIL() syntax takes up the following parameters:

-   Integration Name
-   Comma Separated Email addresses
-   Email Subject
-   Email Content
-   [Optional] MIME Type

-> If the ALLOWEDRECIPIENTS property of the notification integration is set and **any of the email addresses is not in that list**, no email notifications are sent.

> For MIME, the following types are supported:

-   **text/plain** — Specify this when emailcontent is plain text. This is the default value.
-   **text/html** — Specify this when emailcontent is HTML.
```sql
CALL SYSTEM$SENDEMAIL(  
    '<integrationname>',  
    '<emailaddress1> [ , ... <emailaddressN> ]',  
    '<emailsubject>',  
    '<emailcontent>',  
    [ '<mimetype>' ]  
);
```
## SYSTEM$SENDSNOWFLAKENOTIFICATION()

The SYSTEM$SENDSNOWFLAKENOTIFICATION() syntax takes up the following parameters:

-   **Message** as JSON formatted string specifying type and content
-   **Integration** as JSON-formatted string that specifies the notification integration or the email configuration to use to send the notification.

**> Messages type can be**:  
“**text/plain**” for plain text messages.  
“**text/html**” for HTML messages.  
“**application/json**” for JSON messages.

> **Integration Options** is a comma-delimited list of properties (in JSON format) that specify values that override the defaults in the integration. These can be:
```json
'{ "myemailint": {   
                   "subject" : "Different subject"   
                    },   
                    { "toAddress": ["persona@example.com"]   
                    },  
                    { "ccAddress" : ["persontocc1@example.com", "persontocc2@example.com"]   
                    },  
                    { "bccAddress" : ["persontobcc1@example.com", "persontobcc2@example.com"]  
                    }'
```
You can also:

-   **Define Messages** as ARRAY of JSON-formatted strings, each of which specify a message type and content. Specify this argument if you want to send a **message in multiple formats.**
-   **Define Integrations** as ARRAY of JSON-formatted strings, each of which specifies a notification integration and configuration to use. Specify this argument if you **want to use multiple notification integrations** or email configurations to send a message.
```sql
SYSTEM$SENDSNOWFLAKENOTIFICATION(  
  <message>,  
  <integrationconfiguration> );  
  
SYSTEM$SENDSNOWFLAKENOTIFICATION(  
  ( <message>, [ <message>, ... ] ),  
  <integrationconfiguration> );  
  
SYSTEM$SENDSNOWFLAKENOTIFICATION(  
  <message>,  
  ( <integrationconfiguration> [ , <integrationconfiguration> , ... ] ) );  
  
SYSTEM$SENDSNOWFLAKENOTIFICATION(  
  ( <message> [ , <message> , ... ] ),  
  ( <integrationconfiguration> [ , <integrationconfiguration> , ... ] ) );
```
# Helper Functions for SENDSNOWFLAKENOTIFICATION()

SYSTEM$SENDSNOWFLAKENOTIFICATION() comes with various helper functions for building the JSON formatted string. These are:

## EMAILINTEGRATIONCONFIG

-   If you are sending an email notification and want to override the default values specified in the email notification integration, call the EMAILINTEGRATIONCONFIG function.
-   Returns a JSON object that specifies the email notification integration, recipients, and subject line to use for an email notification.
```sql
SNOWFLAKE.NOTIFICATION.EMAILINTEGRATIONCONFIG(  
 '<emailintegrationname>',  
 '<subject>',  
 <arrayofemailaddressesfortoline>,  
 <arrayofemailaddressesforccline>,  
 <arrayofemailaddressesforbccline>  
);
```
## INTEGRATION

-   If you are sending the notification to a queue, or if you are sending an email notification and want to use the default values specified in the email notification integration, call the INTEGRATION function.
-   Returns a JSON object that specifies the notification integration to use to send a message.
```sql
SNOWFLAKE.NOTIFICATION.INTEGRATION( '<integrationname>' );
```
## APPLICATIONJSON

-   To send a JSON message to a queue, call the APPLICATIONJSON function.
-   Returns a JSON object that specifies the JSON message to use for a notification.

SELECT SNOWFLAKE.NOTIFICATION.APPLICATIONJSON('{"data": "hello world"}');

## TEXTHTML

-   To send an HTML email message, call the TEXTHTML function.
-   Returns a JSON object that specifies the HTML message to use for a notification.
```sql
SNOWFLAKE.NOTIFICATION.TEXTHTML( '<message>' );
```
## TEXTPLAIN

-   To send a plain text email message, call the TEXTPLAIN function.
-   Returns a JSON object that specifies the plain text message to use for a notification.
```sql
SNOWFLAKE.NOTIFICATION.TEXTPLAIN( '<message>' );
```
**Example**:
```sql
CALL SYSTEM$SENDSNOWFLAKENOTIFICATION(  
  ARRAYCONSTRUCT(  
    SNOWFLAKE.NOTIFICATION.TEXTPLAIN('A message'),  
    SNOWFLAKE.NOTIFICATION.TEXTHTML('<p>A message</p>'),  
    SNOWFLAKE.NOTIFICATION.APPLICATIONJSON('{ "name": "value" }')  
  ),  
  ARRAYCONSTRUCT(  
    SNOWFLAKE.NOTIFICATION.INTEGRATION('mysnsint'),  
    SNOWFLAKE.NOTIFICATION.INTEGRATION('myemailint')  
  )  
);
```
# Deciding What to Use?

While SENDEMAIL() sproc is very easy to use, SENDSNOWFLAKENOTIFICATION() provides vast variety of options to send notifications as email or sns.

If you are building a basic notification alert to generate a query response’s email report, you can go with the SENDEMAIL(). On the other side if you are building a notification alert where you will be sending different notifications to various user groups or LOBs, the SENDSNOWFLAKENOTIFICATION() provides great flexibility.

# About Me:

Hi there! I am Divyansh Saxena

I am an experienced Cloud Data Engineer with a proven track record of success in Snowflake Data Cloud technology. Highly skilled in designing, implementing, and maintaining data pipelines, ETL workflows, and data warehousing solutions. Possessing advanced knowledge of Snowflake’s features and functionality, I am a Snowflake Data Superhero & Snowflake Snowpro Core SME. With a major career in Snowflake Data Cloud, I have a deep understanding of cloud-native data architecture and can leverage it to deliver high-performing, scalable, and secure data solutions.
