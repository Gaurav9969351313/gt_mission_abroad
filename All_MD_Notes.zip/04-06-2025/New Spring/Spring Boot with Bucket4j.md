# API Rate Limiting in Spring Boot with Bucket4j
API rate limiting is essential for controlling traffic, preventing abuse, and ensuring fair resource allocation in microservices. This guide explains how to implement rate limiting in Spring Boot using Bucket4j, covering per-user/IP limits, distributed rate limiting with Redis, and security best practices.

# 1. Understanding Rate Limiting with Bucket4j

[Bucket4j](https://github.com/vladimir-bukhtoyarov/bucket4j) is a Java rate-limiting library that provides in-memory and distributed rate-limiting strategies. It is based on the token-bucket algorithm, making it efficient and precise.

### Key Features of Bucket4j

-   **Precise Rate Control**: Uses token bucket algorithm for efficient request throttling.
-   **Low Overhead**: Lightweight and optimized for high-performance applications.
-   **Distributed Support**: Works with Redis, Hazelcast, and other distributed stores.
-   **Customizable Policies**: Define different limits for different users, roles, or endpoints.

# 2. Setting Up Rate Limiting Per User/IP

### Dependencies

Add the following dependency to your `pom.xml` (Maven):
```xml
<dependency>  
    <groupId>com.github.vladimir-bukhtoyarov</groupId>  
    <artifactId>bucket4j-core</artifactId>  
    <version>8.2.0</version>  
</dependency>
```
### Configuring Bucket4j for IP-Based Limiting
```java
import io.github.bucket4j.*;  
import jakarta.servlet.http.HttpServletRequest;  
import org.springframework.http.HttpStatus;  
import org.springframework.web.servlet.HandlerInterceptor;  
import java.time.Duration;  
import java.util.concurrent.ConcurrentHashMap;  
  
public class RateLimitInterceptor implements HandlerInterceptor {  
    private final ConcurrentHashMap<String, Bucket> buckets = new ConcurrentHashMap<>();  
  
    private Bucket getBucket(String ip) {  
        return buckets.computeIfAbsent(ip, k -> Bucket4j.builder()  
                .addLimit(Bandwidth.classic(10, Refill.intervally(10, Duration.ofMinutes(1))))  
                .build());  
    }  
  
    @Override  
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {  
        String ip = request.getRemoteAddr();  
        Bucket bucket = getBucket(ip);  
        if (bucket.tryConsume(1)) {  
            return true;  
        } else {  
            response.setStatus(HttpStatus.TOOMANYREQUESTS.value());  
            return false;  
        }  
    }  
}
```
# Registering the Interceptor
```java
import org.springframework.context.annotation.Configuration;  
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;  
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;  
  
@Configuration  
public class WebConfig implements WebMvcConfigurer {  
    @Override  
    public void addInterceptors(InterceptorRegistry registry) {  
        registry.addInterceptor(new RateLimitInterceptor());  
    }  
}
```
# 3. Implementing Distributed Rate Limiting with Redis

To scale rate limiting across multiple instances, use Redis as a centralized rate-limiting store.

### Add Redis Dependency
```xml
<dependency>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-starter-data-redis</artifactId>  
</dependency>
```
### Configuring Redis-Based Bucket4j Rate Limiting
```java
import io.github.bucket4j.redis.jedis.*;  
import redis.clients.jedis.JedisPool;  
import java.time.Duration;  
  
public class RedisRateLimiter {  
    private final ProxyManager<String> buckets;  
  
    public RedisRateLimiter(JedisPool jedisPool) {  
        this.buckets = Bucket4j.extension(Jedis.class).proxyManagerForJedis(jedisPool);  
    }  
  
    public Bucket getBucket(String key) {  
        return buckets.getProxy(key, () -> Bucket4j.builder()  
                .addLimit(Bandwidth.classic(20, Refill.intervally(20, Duration.ofMinutes(1))))  
                .build());  
    }  
}
```
# 4. Advanced Rate Limiting Strategies

# Rate Limiting Based on User Roles

Different users may have different rate limits depending on their subscription plans or access levels.
```java
private Bucket getUserBucket(String userId, String role) {  
    int limit = role.equals("PREMIUM") ? 100 : 20;  
    return Bucket4j.builder()  
            .addLimit(Bandwidth.classic(limit, Refill.intervally(limit, Duration.ofMinutes(1))))  
            .build();  
}
```
# Rate Limiting Specific Endpoints

Certain endpoints, such as login or payment APIs, should have stricter limits.
```java
if (request.getRequestURI().contains("/login")) {  
    return Bucket4j.builder().addLimit(Bandwidth.classic(5, Refill.intervally(5, Duration.ofMinutes(1)))).build();  
}
```
# Burst Rate Limiting for Spiky Traffic

Allow a burst of requests before enforcing the rate limit.

Bandwidth burstLimit = Bandwidth.classic(50, Refill.intervally(10, Duration.ofSeconds(10)));

# 5. Preventing Abuse and Securing APIs

-   **Use Different Rate Limits Per Endpoint**: Limit login attempts more strictly than public endpoints.
-   **Enable API Keys for Rate Limits**: Use API keys instead of IP-based rate limiting for authenticated users.
-   **Log and Monitor Rate-Limiting Events**: Integrate with monitoring tools like Spring Boot Actuator.
-   **Graceful Handling of Rate Limits**: Provide meaningful responses instead of just rejecting requests.
-   **Caching Rate Limits**: Store user rate limits in Redis to optimize performance.
-   **IP Whitelisting**: Exempt trusted IPs from rate limits (e.g., internal services).

# 6. Monitoring Rate Limiting Metrics

Spring Boot Actuator can help monitor rate-limiting performance.

**Enable Actuator Metrics:**
```shell
management.endpoints.web.exposure.include=caches,metrics  
management.metrics.cache.redis=true
```
**Check Rate Limit Metrics:**
```shell
curl http://localhost:8080/actuator/metrics/bucket4j.requests
```
# Conclusion

Rate limiting is a crucial aspect of API security and performance. By using Bucket4j with Redis, you can efficiently enforce traffic limits in Spring Boot microservices. Implementing per-user/IP limits, advanced strategies like role-based rate limits, burst handling, and monitoring ensures a robust and scalable system.
