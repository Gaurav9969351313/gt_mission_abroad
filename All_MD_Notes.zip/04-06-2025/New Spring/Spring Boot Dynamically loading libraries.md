# Dynamically loading libraries into a SpringBoot application at run time

The structure of the application in question consists of a main application **app** that has various Spring Beans that implement the **SystemAdapter** interface. Using an auto-discovery method at startup the application will discover which beans are available for the given AdapterTypes. The conops for this application is to develop the base application, present users with an API so that they can implement their own **SystemAdapter**s and deliver them a compiled **App.jar** they can run with their own implemented adapters.

### Commons

Commons is the library that defines the **SystemAdapter** interface:
```java
public interface SystemAdapter {  
  AdapterType getType();  
}
```
as well as the **AdapterType** enum:
```java
public enum AdapterType {  
  Taco, Turkey, Modem, Computer, NULL  
}
```
The **NULL** adapter type is included because I was unable to get the application to build — as implemented without having **any** classes that implement SystemAdapter — so I have a NullSystemAdapter to get things working — there is likely a better way to do this.

This library will be compiled to a vanilla Jar which is done by adding the following to build.gradle:
```java
bootJar {   
  enabled = false  
} jar {   
  enabled = true  
}
```

### App

The application itself implements 3 things

-   A component scan of **org.company.adapters**
-   An implementation of **SystemAdapater** (**NullSystemAdapter**)
-   A **SystemAdapterFactory**

Additionally the application uses the [PropertiesLauncher](https://docs.spring.io/spring-boot/docs/current/api/org/springframework/boot/loader/PropertiesLauncher.html) which allows one to add additional Jars to the classpath at startup.

### @ComponentScan

The application itself needs to know where to look for SpringBeans so its told to search in two packages:

-   **org.company.adapters** <- Any external jar that has **SystemAdapter**s must be in this package to be auto-detected
-   **org.company.app** <- this is the rest of our code
```java
@ComponentScan(  
  basePackages = {"org.company.adapters", "org.company.app"}  
)  
@SpringBootApplicationpublic class DemoApplication {    
  @Autowired  
  SystemAdapterFactory factory;    
  
  public static void main(String[] args) {      
    SpringApplication.run(DemoApplication.class, args);   
  }   
}
```
The only thing to note is you need to define a convention of where the external implementations of **SystemAdapter** will exist so the @ComponentScan can pick them up when they are loaded in externally.

For our purposes we have a **SystemAdapterFactory** which simply will print out which adapters were detected at startup.
```java
@Service  
public class SystemAdapterFactory {  
  @Autowired  
  List<SystemAdapter> adapters;  
  
  @PostConstruct  
  void listAdapters() {  
      
    System.out.println("nn-------SYSTEM ADAPTERS ------n");    for (SystemAdapter adapter: adapters) {  
       System.out.println("...Loaded Class: "   
         + adapter.getClass()   
         + " of type: "   
         + adapter.getType().toString());  
     }  
     System.out.println("n-------------------------------");  
      
    }   
}
```

Because the factory attempts to @Autowire a list of SystemAdapters in the default case (in order to get the code to compile) there is a **NullSystemAdapter:**
```java
@Component  
public class NullAdapter implements SystemAdapter {  
    @Override  
    public AdapterType getType() {  
        return AdapterType.NULL;      
}}
```
That implements the **AdapterType.NULL** — it is simply a place holder to get things to compile.

### PropertiesLauncher

For the app to use the **PropertiesLauncher** setup the build.gradle file is configured with:
```java
bootJar {  
    manifest {  
       attributes 'Main-Class': 'org.springframework.boot.loader.PropertiesLauncher'  
    }  
}
```
Once the app is built you can run it with:
```shell
java -jar -jar app/build/libs/app-0.0.1-SNAPSHOT.jar
```
It will then report something like:

-------SYSTEM ADAPTERS ------...Loaded Class: class org.company.adapters.NullAdapter of type: NULL-------------------------------

Showing that it detected the default **NullAdapter**

# External SystemAdapter Lib

So the next step is to build a new library that implements **SystemAdapter** and can be loaded at run-time

Similar to **commons**, the SpringBoot runnable Jar task is disabled instead using the normal jar build:
```java
bootJar {  
 enabled = false  
}jar {  
 enabled = true  
}
```
Next as specified earlier the we implement some adapters in the **org.company.adapter** package so that they will be picked up by the **@ComponentScan** in the main project
```java
package org.company.adapters;
import org.company.commons.adapters.AdapterType;  
import org.company.commons.adapters.SystemAdapter;  
import org.springframework.stereotype.Component;[@Component](http://twitter.com/Component)  
public class DefaultTurkeyAdapter implements SystemAdapter {[@Override](http://twitter.com/Override)  
    public AdapterType getType() {  
        return AdapterType.Turkey;  
    }  
}
```

Once compiled we end up with a Jar that can be loaded at run-time onto the class path like so:
```shell
java   
  -Dloader.path=file:./libs/defaultAdapters.jar   
  -Dloader.debug=false   
  -jar app/build/libs/app.jar
```
Which will now in turn print out:

-------SYSTEM ADAPTERS ------...Loaded Class: class org.company.adapters.DefaultTurkeyAdapter of type: Turkey  
...Loaded Class: class org.company.adapters.DefaultModemAdapter of type: Modem  
...Loaded Class: class org.company.adapters.NullAdapter of type: NULL-------------------------------

# Demo

https://github.com/jeeftor/SpringBoot-Dynamic-JarLoad