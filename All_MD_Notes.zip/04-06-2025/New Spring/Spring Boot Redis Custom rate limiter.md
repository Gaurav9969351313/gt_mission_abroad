# How I Designed a Rate Limiter to Handle Over 1 Billion API Requests Per Day
![](https://miro.medium.com/v2/resize:fit:875/1*EmrKNqf8eb-zmvSdZMeT9g.png)

> I needed a rate limiter that could play the role of a superhero — not just a hero for quiet days, but the kind who dodges disasters while juggling _hundreds of millions of requests per hour_. Think of it like this: my servers were a skyscraper in a hurricane, and the limiter had to be both the shock absorbers _and_ the reinforced steel beams. No matter how hard the storm raged, it couldn’t let a single floor buckle.

I still remember that sick feeling in my chest as I stared at the monitoring dashboard. Our APIs were getting hit with traffic spikes I’d never even seen before — hundreds of thousands of requests every second. If we didn’t stop the flood, our servers would crash in a heartbeat. That night, I swore I’d build something to handle it. Not just handle it, but crush it — 1 billion requests a day. Here’s how I pulled it off: a raw, messy, all-in account of my midnight coding sessions, wrong turns, and the crazy gamble that worked. No fluff, just what really happened.

# Why a Custom Rate Limiter?

Out-of-the-box tools? Sure, they’ll handle everyday traffic just fine. But cross that 100,000 requests per second threshold? Boom — suddenly the usual suspects break down, and everything starts imploding. It’s like trying to drink from a firehose with a soda straw. Here’s why:

-   Central bottlenecks? _Boom_ — they’re like traffic jams on the highway of your system. One clogged artery, and suddenly _everything_ slows to a crawl. It’s like trying to pour a gallon of water through a thimble: the main blockage stops the flow, and every process downstream is left gasping for speed.
-   Clock skew? Imagine a distributed system as a relay race — except every runner’s watch is stuck on a different time. One node thinks it’s time to pass the baton, but the next one’s clock hasn’t even hit “go.” Result? Limits get doled out like a kid splitting candy with their eyes closed — wildly unfair, totally random, and guaranteed to break something.
-   **Memory pressure** on a single node becomes a crash risk.

I needed something that:

1.  Scaled horizontally with minimal coordination.
2.  Gave fairly consistent limits to every client.
3.  Kept memory and CPU usage low.

# High-Level Architecture

Here’s the blueprint in plain text — no images required, just ASCII art you can follow with a coffee in hand. Think of it like a tiny traffic director (the coordination layer) handing out parking passes (tokens) to every node in the system. Every machine gets its own stash, and the flow is easy to track: just follow the lines like breadcrumbs. _PMs rejoice_ — no “where’s that image link?” drama here. Just a straightforward text map that even a five-year-old could (maybe) explain.

           +------------+            +------------+    
   ┌──────▶│ Rate Node  │◀──────────▶│ Coordinator│    
   │       │   (Cluster)│            │  (Redis)   │    
   │       +------------+            +------------+    
   │              ▲                        ▲        
   │              │                        │        
Client ──▶ Load Balancer ──▶ Rate Nodes ─────┘        
   │              │                          
   └──────────────┘

![](https://miro.medium.com/v2/resize:fit:875/1*Ic4j_2-P5xfwpoRGnIiAfA.png)
Corporate-style flowchart of load balancer, rate nodes, and Redis coordinator.

-   **Load Balancer**: Distributes incoming API calls across rate nodes.
-   **Coordinator**: A Redis cluster holding token buckets metadata.
-   **Rate Nodes**: Java/Spring-Boot services enforcing local buckets.

# Choosing the Algorithm

I compared three classic patterns:

| Algorithm      | Pros                       | Cons                      |  
| -------------- | -------------------------- | ------------------------- |  
| Fixed Window   | Easy to implement          | Bursty at window edges    |  
| Sliding Window | Smoother limits            | Higher storage per client |  
| Token Bucket   | Flexible bursts and steady | Needs refill logic        |

The Token Bucket won me over because it’s like a calm, efficient dance instructor balancing flow and pace. Picture this:

-   Every server has its own personal “traffic cop” (the local bucket) that doles out approval for requests.
-   Redis acts like a refilling water tower, trickling new tokens into each bucket at set intervals — no matter how many requests are queued up.
-   When calls come pouring in? The system’s like a nightclub bouncer: *“You’re in. Next! Next! Next! — and you? Sorry, full house tonight.”*

It’s simplicity at its finest: keep traffic smooth, reject chaos, and let the system breathe.

# Code Snippet:-

Below is a simplified version of my rate limiter interceptor. It runs in each Spring Boot node, checking and refilling tokens from Redis.
```java
@Component  
@Slf4j  
@RequiredArgsConstructor  
public class RateLimiterInterceptor implements HandlerInterceptor {  
    private final StringRedisTemplate redis;  
    private final long maxTokens = 1000;  
    private final long refillIntervalMs = 1000;  
    private final double refillRatePerMs = 0.833; // 1000 tokens per second  
  
  
    @Override  
    public boolean preHandle(HttpServletRequest req, HttpServletResponse res, Object handler) {  
        String clientId = req.getHeader("X-Client-ID");  
        String key = "rate:" + clientId;  
        // Atomically refill and fetch tokens  
        List<String> script = Arrays.asList(  
            "local tokens = tonumber(redis.call('get', KEYS[1]) or ARGV[1])",  
            "local now = tonumber(ARGV[2])",  
            "local lastTime = tonumber(redis.call('get', KEYS[2]) or ARGV[2])",  
            "local delta = math.max(0, now - lastTime)",  
            "local refill = delta * tonumber(ARGV[3])",  
            "tokens = math.min(tonumber(ARGV[1]), tokens + refill)",  
            "if tokens < 1 then return -1 end",  
            "tokens = tokens - 1",  
            "redis.call('set', KEYS[1], tokens)",  
            "redis.call('set', KEYS[2], now)",  
            "return tokens"  
        );  
        List<String> keys = Arrays.asList(key + ":tokens", key + ":time");  
        List<String> args = Arrays.asList(  
            String.valueOf(maxTokens),  
            String.valueOf(System.currentTimeMillis()),  
            String.valueOf(refillRatePerMs)  
        );  
        Long result = redis.execute(new DefaultRedisScript<>(String.join("n", script), Long.class), keys, args.toArray(new String[0]));  
        if (Objects.isNull(result) || result < 0) {  
            res.setStatus(HttpStatus.TOO_MANY_REQUESTS.value());  
            return false;  
        }  
        return true;  
    }  
}
```

This snippet is of core logic. It atomically refills tokens and enforces limits using a Redis Lua script.

# Benchmarks

I ran load tests using **Gatling**. Here’s what I saw on a **4-node cluster**:

![](https://miro.medium.com/v2/resize:fit:875/1*wP9UZhfKpfVOfsWICD8EJw.png)
Throughput, latency, and CPU usage metrics per node.

| Metric                       | Value            |  
| ---------------------------- | ---------------- |  
| Peak throughput (RPS)        | 120,000/sec/node |  
| Average latency (p95)        | 15 ms            |  
| CPU usage (per node)         | 40 %             |  
| Memory usage (per node)      | 200 MB           |  
| Total requests/day sustained | ~1.036 billion  |

With this setup, we comfortably handle over **1 billion requests in 24 hours** with headroom for spikes.

# The Lessons Which We’ve Learned From This Article:-

1.  **Local Caching of Tokens**  
    Hitting Redis on every request kills performance. A small local cache of tokens (refilled on a timer) cuts Redis trips by 80 %.
2.  **Lua Scripting for Atomicity**  
    Redis Lua scripts kept refill + consume as one atomic operation. No race conditions.
3.  **Graceful Degradation**  
    When Redis is unreachable, nodes fall back to a hardened default (e.g., a small buffer of tokens) to keep serving low-priority traffic.
4.  **Monitoring Is Key**  
    Track metrics per client, per node, and in Redis. Visual alerts on unusual refill failures saved us before downtime.

# Final Thoughts

This project taught me that simplicity is the unsung hero of resilience. Imagine baking a cake using only your most trusted ingredients — _token bucket_, _Redis coordination_, and _local caching_ — mix them, sprinkle with patience, and voilà: a system that handles a billion requests a day like it’s Tuesday and they’re sipping coffee.

If you’re staring down a tidal wave of traffic? Start small — build a prototype the size of a post-it note, then prod it, tweak it, and _only pile on complexity where the data screams “help”_. And don’t skip the boring stuff: monitor like a hawk and stress-test like you’re trying to prove your own system wrong. (Trust me — your future self will high-five you for it.)

This isn’t just a technical deep-dive. It’s a chronicle of the messy, caffeine-fueled all-nighter where I learned that “scale” isn’t magic — it’s just problem-solving with a backbone. Got a hack that’s saved your bacon? Found a flaw in my approach? Shout it in the comments — we all win when we share. Here’s to systems that don’t crack under pressure… and APIs that stay smooth enough to dance on!
