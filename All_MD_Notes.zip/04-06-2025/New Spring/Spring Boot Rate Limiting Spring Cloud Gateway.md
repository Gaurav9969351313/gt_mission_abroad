# Rate Limiting Spring Cloud Gateway 

# Introduction

Some time back I implemented production grade rate limiter using Spring Cloud Gateway, Redis and Bucket4j library. With this article I would like to share my understanding with regards to the entire implementation process. **Please read the comments in the code. I have commented it heavily for understanding**.

Let’s begin. This is going to be extremely detailed!!

Rate limiting is a crucial technique for protecting your microservices from excessive traffic and potential abuse. With this article, you will be able create a rate limiting using Spring Cloud Gateway, Redis as a distributed key resolver, and Bucket4j for advanced token bucket algorithm-based rate limiting.

# Prerequisites

Before we begin, ensure you have the following:

-   Java 17 or higher
-   Maven or Gradle
-   Redis server
-   Basic understanding of Spring Boot and Spring Cloud

# Project Setup

### 1. Create a Spring Boot Project

Start by creating a new Spring Boot project with the following dependencies. This is not exhaustive list :
```shell
plugins {  
    id 'org.springframework.boot' version '2.7.5'  
    id 'io.spring.dependency-management' version '1.0.15.RELEASE'  
    id 'java'  
}  
  
group = 'com.company'  
version = '0.0.1-SNAPSHOT'  
sourceCompatibility = '17'  
  
ext {  
    set('springCloudVersion', "2021.0.5")  
}  
dependencies {  
    implementation 'org.springframework.cloud:spring-cloud-starter-gateway'  
    implementation 'com.giffing.bucket4j.spring.boot.starter:bucket4j-spring-boot-starter:0.9.0'  
    implementation 'com.bucket4j:bucket4j-redis:8.2.0'  
    implementation 'io.lettuce:lettuce-core:6.2.3.RELEASE'  
}  
  
dependencyManagement {  
    imports {  
        mavenBom "org.springframework.cloud:spring-cloud-dependencies:${springCloudVersion}"  
    }  
}
```
### 2. Redis Configuration

Create a Redis configuration class:
```java 
@Configuration  
@RequiredArgsConstructor  
public class RedisConfig {  
  
    private final ServiceConfig serviceConfig;  
  
    @Bean  
    @Primary  
    public RedisClusterClient redisClient() {  
        String[] clusterUris = serviceConfig.getCacheConfigurations().getRedisCluster().split(",", -1);  
        Set<RedisURI> redisURIS = Arrays.stream(clusterUris).map(RedisURI::create).collect(Collectors.toSet());  
        return RedisClusterClient.create(redisURIS);  
    }  
  
  
    @Bean  
    @Primary  
    LettuceBasedProxyManager proxyManager(RedisClusterClient redisClusterClient) {  
        // The maxTimeInSecondsToExpire can be configured via environment variables  
        int maxTimeInSecondsToExpire =   
        return LettuceBasedProxyManager.builderFor(redisClusterClient)  
                .withExpirationStrategy(ExpirationAfterWriteStrategy  
                        .basedOnTimeForRefillingBucketUpToMax(Duration.ofSeconds(maxTimeInSecondsToExpire))).build();  
    }  
}
```
Few considerations for the above settings:

**Configuration Retrieval**

-   `serviceConfig.getCacheConfigurations().getRedisCluster()` retrieves a comma-separated string of Redis cluster URIs from environment properties defined in yml file.

**Proxy Manager Configuration**:

-   Uses `LettuceBasedProxyManager` from Bucket4j library for managing distributed rate limiting
-   `.builderFor(redisClusterClient)` starts configuring the proxy manager for the Redis Cluster

**Expiration Strategy**:

-   `.withExpirationStrategy()` sets how rate limit buckets expire
-   `ExpirationAfterWriteStrategy.basedOnTimeForRefillingBucketUpToMax()` defines an expiration strategy
-   Buckets will expire after a specified time
-   The expiration time is based on the time needed to refill the bucket to its maximum capacity
-   `Duration.ofSeconds(maxTimeInSecondsToExpire)` sets the maximum expiration time

### Why is a Proxy Manager Needed?

The Proxy Manager (specifically `LettuceBasedProxyManager` in this case) is crucial for implementing distributed rate limiting across multiple instances of an application. Here's a detailed breakdown:

### 1. Distributed State Management

In a distributed system, maintaining a consistent rate limit state across multiple application instances is challenging. Without a centralized mechanism:

-   Each application instance would track rate limits independently
-   This could lead to inconsistent rate limiting
-   A single user or client might consume more resources than intended

### 2. Redis as a Distributed Storage

The Proxy Manager uses Redis as a centralized storage for rate limit tokens:

-   It stores the current state of rate limit buckets in Redis
-   Ensures all application instances see the same rate limit state
-   Provides atomic operations for token consumption

### Advanced Features

The Proxy Manager provides:

-   Atomic token consumption
-   Configurable refill strategies
-   Support for complex rate limiting rules
-   Horizontal scalability

### 3. Custom Rate Limiter Implementation

Create a Redis-based rate limiter:
  
```java
@Slf4j  
public class CustomRateLimiter extends AbstractRateLimiter<CustomRateLimiter.Config> {  
  
    public static final String CONFIGURATIONPROPERTYNAME = "custom-rate-limiter";  
  
    public static final String KEY = "user";  
  
    public static final String REMAININGHEADER = "X-RateLimit-Remaining";  
    /**  
     * Replenish Rate Limit header name.  
     */  
    public static final String REPLENISHRATEHEADER = "X-RateLimit-Replenish-Rate";  
  
    /**  
     * Burst Capacity header name.  
     */  
    public static final String BURSTCAPACITYHEADER = "X-RateLimit-Burst-Capacity";  
  
    /**  
     * Requested Tokens header name.  
     */  
    public static final String RETRYAFTERSECONDS = "X-RateLimit-Retry-After-Seconds";  
  
    private boolean includeHeaders = true;  
  
    /**  
     * The name of the header that returns number of remaining requests during the current  
     * second.  
     */  
    private String remainingHeader = REMAININGHEADER;  
  
    /** The name of the header that returns the replenish rate configuration. */  
    private String replenishRateHeader = REPLENISHRATEHEADER;  
  
    /** The name of the header that returns the burst capacity configuration. */  
    private String burstCapacityHeader = BURSTCAPACITYHEADER;  
  
    /** The name of the header that returns the requested tokens configuration. */  
    private String retryAfterSeconds = RETRYAFTERSECONDS;  
    private Config defaultConfig;  
  
  
    public CustomRateLimiter(Config config) {  
        super(Config.class, CONFIGURATIONPROPERTYNAME, null);  
        this.defaultConfig = config;  
        //TODO Disable headers during prod release  
        //this.includeHeaders = false;  
    }  
  
    public Bucket resolveBucket(String key) {  
        Supplier<BucketConfiguration> configSupplier = getConfigSupplierForUser();  
        // Does not always create a new bucket, but instead returns the existing one if it exists.  
        return this.defaultConfig.getProxyManager().builder().withOptimization(Optimizations.batching())  
                .build(key.getBytes(), configSupplier);  
    }  
  
    private Supplier<BucketConfiguration> getConfigSupplierForUser() {  
        Refill refill = Refill.intervally(defaultConfig.getLimit(),  
                Duration.ofSeconds(defaultConfig.getDurationInSeconds()));  
        Bandwidth limit = Bandwidth.classic(defaultConfig.getLimit(), refill);  
        return () -> (BucketConfiguration.builder()  
                .addLimit(limit)  
                .build());  
    }  
  
    @Override  
    public Mono<Response> isAllowed(String routeId, String id) {  
        if (this.defaultConfig.isRateLimiterActive) {  
            Bucket b = resolveBucket(id);  
            long waitForRefill = 0L;  
            Config routeConfig = loadConfiguration(routeId);  
            try {  
                // Try to consume one token from the bucket  
                 // Returns a probe with consumption details  
                ConsumptionProbe probe = b.tryConsumeAndReturnRemaining(1);  
                if (probe.isConsumed()) {  
                    Response response = new Response(probe.isConsumed(), getHeaders(routeConfig, probe.getRemainingTokens(), null));  
                    if (log.isDebugEnabled()) {  
                        log.debug("response: " + response);  
                    }  
                    return Mono.just(response);  
                }  
                waitForRefill = probe.getNanosToWaitForRefill() / 1000000000;  
            } catch (Exception e) {  
                log.error("Error determining if user allowed from redis", e);  
            }  
            // Modifies bucket configuration if blocking is allowed  
            // Returns a response indicating rate limit was exceeded  
            modifyBucketByRateLimiterName(b);  
            return Mono.just(new Response(false, getHeaders(routeConfig, -1L, waitForRefill)));  
        } else {  
            return Mono.just(new Response(true, new HashMap<>()));  
        }  
    }  
  
    private void modifyBucketByRateLimiterName(Bucket b) {  
        if (defaultConfig.isBlockingAllowed) {  
            // Allows dynamic reconfiguration of the bucket  
            b.replaceConfiguration(getBucketConfigToReplace(), TokensInheritanceStrategy.ASIS);  
        }  
    }  
    private BucketConfiguration getBucketConfigToReplace() {  
        // intervally() means tokens are added at a steady, predictable rate  
        Refill refill = Refill.intervally(defaultConfig.getLimit(),  
                Duration.ofSeconds(defaultConfig.blockInSeconds));  
        // Bandwidth sets the maximum capacity of the token bucket  
        Bandwidth limit = Bandwidth.classic(defaultConfig.getLimit(), refill);  
        return  BucketConfiguration.builder()  
                .addLimit(limit)  
                .build();  
    }  
  
    @NotNull  
    public Map<String, String> getHeaders(Config config, Long tokensLeft, Long timeToWaitForRetry) {  
        log.info("Rate Limit headers: X-RateLimit-Remaining: {}, X-RateLimit-Replenish-Rate: {}, " +  
                "X-RateLimit-Retry-After-Seconds: {}", tokensLeft, config.getLimit(), timeToWaitForRetry);  
        Map<String, String> headers = new HashMap<>();  
        if (isIncludeHeaders()) {  
            headers.put(this.remainingHeader, tokensLeft.toString());  
            headers.put(this.replenishRateHeader, String.valueOf(config.getLimit()));  
            if (ObjectUtils.isNotEmpty(timeToWaitForRetry)) {  
                headers.put(this.retryAfterSeconds, String.valueOf(timeToWaitForRetry));  
            }  
        }  
        return headers;  
    }  
  
    @Validated  
    @Getter  
    @Setter  
    @Builder  
    public static class Config {  
  
        @Min(1)  
        private long limit;  
        @Min(0)  
        private long durationInSeconds = 1;  
        private boolean isRateLimiterActive;  
        private RateLimiterName rateLimiterName;  
        private long blockInSeconds;  
        private boolean isBlockingAllowed;  
        private LettuceBasedProxyManager proxyManager;  
    }  
}
```
The above custom rate limiter will be created as a bean with different types of rate limiter required. Few use cases for different type of rate limiter are as follow:

-   We want to rate limit users for apis which are accessing critical resources like OTP apis.
-   Limiting the users by grouping apis based on the factor that if they require authentication or not.
-   Limiting the users for login apis

And many more use cases. Rate limit attributes for all the above type of rate limiter can be configured in a yaml file. And then we can configure multiple different named beans of CustomRateLimiter.

```java
@Configuration  
@RequiredArgsConstructor  
public class GatewayConfig {  
  
    private final ServiceConfig serviceConfig;  
    private final LettuceBasedProxyManager proxyManager;  
  
    @Bean  
    WebClient client() {  
        return WebClient.builder()  
                .clientConnector(new ReactorClientHttpConnector(HttpClient.newConnection().wiretap(true)))  
                .build();  
    }  
  
    @Bean("guestLimiter")  
    public CustomRateLimiter guestApiRateLimiter() {  
        CustomRateLimiter.Config config = CustomRateLimiter.Config.builder()  
                .limit(serviceConfig.getGuestApiRateLimiter().getLimit())  
                .durationInSeconds(serviceConfig.getGuestApiRateLimiter().getDurationInSeconds())  
                .isRateLimiterActive(serviceConfig.getGuestApiRateLimiter().isActive())  
                .blockInSeconds(serviceConfig.getGuestApiRateLimiter().getBlockInSeconds())  
                .proxyManager(proxyManager)  
                .isBlockingAllowed(serviceConfig.getGuestApiRateLimiter().isBlockingAllowed())  
                .rateLimiterName(RateLimiterName.GUEST)  
                .build();  
        CustomRateLimiter customRateLimiter = new CustomRateLimiter(config);  
        customRateLimiter.setIncludeHeaders(serviceConfig.getBaseRateLimiterConfig().isIncludeHeaders());  
        return customRateLimiter;  
    }  
  
    @Bean("otpLimiter")  
    public CustomRateLimiter otpApiRateLimiter() {  
        CustomRateLimiter.Config config = CustomRateLimiter.Config.builder()  
                .limit(serviceConfig.getOtpApiRateLimiter().getLimit())  
                .durationInSeconds(serviceConfig.getOtpApiRateLimiter().getDurationInSeconds())  
                .isRateLimiterActive(serviceConfig.getOtpApiRateLimiter().isActive())  
                .blockInSeconds(serviceConfig.getOtpApiRateLimiter().getBlockInSeconds())  
                .proxyManager(proxyManager)  
                .isBlockingAllowed(serviceConfig.getOtpApiRateLimiter().isBlockingAllowed())  
                .rateLimiterName(RateLimiterName.OTP)  
                .build();  
        CustomRateLimiter customRateLimiter = new CustomRateLimiter(config);  
        customRateLimiter.setIncludeHeaders(serviceConfig.getBaseRateLimiterConfig().isIncludeHeaders());  
        return customRateLimiter;  
    }  
  
}
```

### 4. Gateway Rate Limiting Configuration

Create a custom rate limiting filter:  
```java
@Component  
@Slf4j  
public class CustomRequestRateLimiterGatewayFilterFactory extends AbstractGatewayFilterFactory<CustomRequestRateLimiterGatewayFilterFactory.Config> {  
    public static final String KEYRESOLVERKEY = "keyResolver";  
  
    private static final String EMPTYKEY = "EMPTYKEY";  
  
    private final RateLimiter defaultRateLimiter;  
  
    private final KeyResolver defaultKeyResolver;  
  
    private Map<String, Object> body;  
  
    /**  
     * Switch to deny requests if the Key Resolver returns an empty key, defaults to true.  
     */  
    private boolean denyEmptyKey = true;  
  
    /** HttpStatus to return when denyEmptyKey is true, defaults to FORBIDDEN. */  
    private String emptyKeyStatusCode = HttpStatus.FORBIDDEN.name();  
  
    public CustomRequestRateLimiterGatewayFilterFactory(RateLimiter defaultRateLimiter, KeyResolver defaultKeyResolver) {  
        super(CustomRequestRateLimiterGatewayFilterFactory.Config.class);  
        this.defaultRateLimiter = defaultRateLimiter;  
        this.defaultKeyResolver = defaultKeyResolver;  
    }  
  
    public KeyResolver getDefaultKeyResolver() {  
        return defaultKeyResolver;  
    }  
  
    public RateLimiter getDefaultRateLimiter() {  
        return defaultRateLimiter;  
    }  
  
    public boolean isDenyEmptyKey() {  
        return denyEmptyKey;  
    }  
  
    public void setDenyEmptyKey(boolean denyEmptyKey) {  
        this.denyEmptyKey = denyEmptyKey;  
    }  
  
    public String getEmptyKeyStatusCode() {  
        return emptyKeyStatusCode;  
    }  
  
    public void setEmptyKeyStatusCode(String emptyKeyStatusCode) {  
        this.emptyKeyStatusCode = emptyKeyStatusCode;  
    }  
  
    public Map<String, Object> getBody() {  
        return body;  
    }  
  
    public void setBody(Map<String, Object> body) {  
        this.body = body;  
    }  
  
    @SuppressWarnings("unchecked")  
    @Override  
    public GatewayFilter apply(CustomRequestRateLimiterGatewayFilterFactory.Config config) {  
        KeyResolver resolver = getOrDefault(config.keyResolver, defaultKeyResolver);  
        RateLimiter<Object> limiter = getOrDefault(config.rateLimiter, defaultRateLimiter);  
        boolean denyEmpty = getOrDefault(config.denyEmptyKey, this.denyEmptyKey);  
        HttpStatusHolder emptyKeyStatus = HttpStatusHolder  
                .parse(getOrDefault(config.emptyKeyStatus, this.emptyKeyStatusCode));  
  
        return (exchange, chain) -> resolver.resolve(exchange).defaultIfEmpty(EMPTYKEY).flatMap(key -> {  
            if (EMPTYKEY.equals(key)) {  
                if (denyEmpty) {  
                    setResponseStatus(exchange, emptyKeyStatus);  
                    return exchange.getResponse().setComplete();  
                }  
                return chain.filter(exchange);  
            }  
            String routeId = config.getRouteId();  
            if (routeId == null) {  
                Route route = exchange.getAttribute(ServerWebExchangeUtils.GATEWAYROUTEATTR);  
                routeId = route.getId();  
            }  
            return limiter.isAllowed(routeId, key).flatMap(response -> {  
  
                for (Map.Entry<String, String> header : response.getHeaders().entrySet()) {  
                    exchange.getResponse().getHeaders().add(header.getKey(), header.getValue());  
                }  
  
                if (response.isAllowed()) {  
                    return chain.filter(exchange);  
                }  
                setResponseStatus(exchange, config.getStatusCode());  
                logErrorMessage(exchange);  
                return Mono.error(new TooManyRequestException("You have reached the request limit, please try after some time."));  
            });  
        });  
    }  
  
    private void logErrorMessage(ServerWebExchange exchange) {  
        HttpHeaders headers = new HttpHeaders();  
        HttpHeaders headersFromExchange = exchange.getRequest().getHeaders();  
        for (Map.Entry<String, List<String>> header : headersFromExchange.entrySet()) {  
            if (header.getKey().equalsIgnoreCase(HttpHeaders.AUTHORIZATION)) {  
                continue;  
            }  
            headers.addAll(header.getKey(), header.getValue());  
        }  
        log.error("You have reached the request limit, please try after some time. Body: "  
                + exchange.getAttribute("cachedRequestBodyObject") + "|Headers: " + headers);  
    }  
  
    }  
}
```
In the above code we mostly copied the code from default rate limiter filter filter factory. Why we did this is because the default implementation was not giving us the correct error response. Hence we created a custom rate limiter factory which now gives us the correct error response using the below code snippet:

return Mono.error(new TooManyRequestException("You have reached the request limit, please try after some time."));

### 5. Route definition with rate limiter filter
```java
@Component  
public class BestService extends BaseRouteService{  
  
    public AvailabilityService(  
                               @Qualifier("authenticatedApiRateLimiter") CustomRateLimiter customRateLimiter,  
                               CustomRequestRateLimiterGatewayFilterFactory rateLimiterFilter) {  
        super(customRateLimiter, rateLimiterFilter);  
    }  
  
    @Bean  
    public RouteLocator bestServiceRoute(RouteLocatorBuilder builder) {  
        String rewriteReplacement = "/${segment}";  
        String originalPath = "/best/(?<segment>.*)";  
  
        return builder.routes()  
                .route(p -> p.path("/best/**")  
                        .and()  
                        .filters(f -> f.rewritePath(originalPath, rewriteReplacement)  
                                        .filter(rateLimiterFilter.apply(new CustomRequestRateLimiterGatewayFilterFactory.Config()  
                                        .setRateLimiter(customRateLimiter).setEmptyKeyStatus(HttpStatus.UNAUTHORIZED.name())))  
                        )  
                        .uri(serviceConfig.getServices().getBestServiceHost()))  
                .build();  
    }  
}
```
### 6. Application Properties

Configure your `application.yml`:

```yml 
guestLimiter:  
  limit: 2000  
  durationInSeconds: 120  
  active: true  
  blockInSeconds: 300  
  blockingAllowed: true  
otpLimiter:  
  limit: 15  
  durationInSeconds: 300  
  active: true  
  blockInSeconds: 1800  
  blockingAllowed: true
```
This completes the implementation.

# Conclusion: Beyond Rate Limiting — Building Resilient Microservices

### The Bigger Picture of Rate Limiting

Rate limiting is more than just a technical implementation — it’s a critical strategy for building robust, scalable, and secure microservices. By leveraging Spring Cloud Gateway, Redis, and Bucket4j, we’ve created a powerful solution that goes beyond simple request throttling.

### Key Takeaways

1.  **Scalability**: Distributed rate limiting ensures consistent protection across multiple service instances
2.  **Flexibility**: Configurable strategies adapt to unique application requirements
3.  **Performance**: Minimal overhead with efficient token bucket algorithms
4.  **Resilience**: Protect your services from potential abuse and unexpected traffic spikes

### Future Directions

As microservices architectures continue to evolve, consider expanding your rate limiting strategy:

-   **Machine Learning Integration**: Develop adaptive rate limiting that learns from traffic patterns
-   **Advanced Analytics**: Implement comprehensive monitoring of rate limit events
-   **Dynamic Configuration**: Create runtime-configurable rate limit rules
-   **Multi-Dimensional Limiting**: Implement more complex limiting strategies based on user roles, request types, and system load

### Final Thought

Rate limiting is not just a technical constraint — it’s a sophisticated art of balancing system performance, user experience, and resource protection. By thoughtfully implementing these strategies, you transform rate limiting from a mere defensive mechanism into a proactive tool for maintaining system health and reliability.

Stay connected for more in-depth technical content on Spring, Java, and enterprise architecture patterns.

Read my other in depth articles related to Springboot in the below library:  
[https://medium.com/@prustaniket/list/springboot-c90ae5ac6c06](https://medium.com/@prustaniket/list/springboot-c90ae5ac6c06)
