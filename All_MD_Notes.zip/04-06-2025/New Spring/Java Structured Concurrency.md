# Using Java Structured Concurrency in Java 21 

Hi All ,

This story is Free and Open to everyone; non-member readers [can click this link](https://connect2grp.medium.com/29f480594fbc?sk=9532088288a325bd0ab79d8c1c88e8f6) to read the story.

Today , We will explore the concept of Structured Concurrency in Java 21 and its importance, its Benefits .

So Let’s Begin. :

![](https://miro.medium.com/v2/resize:fit:875/0*3gvvvobAVKSasdz)

Imagine a grand orchestra, a multitude of instruments each poised to contribute to a complex symphony. Each musician (thread) has a vital role, but without a skilled conductor (a structured approach), the performance risks devolving into cacophony.

![](https://miro.medium.com/v2/resize:fit:640/0*Aoj4iFmYYAHNsaub)

Traditional concurrency in Java, while offering the raw power of individual threads, often lacks this crucial orchestration. This can lead to tangled code, unpredictable behavior, and the dreaded debugging nightmares.

![](https://miro.medium.com/v2/resize:fit:875/0*Q0EzMcFnReccR6Af)

### Introduction

Java 21 introduced a revolutionary concept known as Structured Concurrency, which simplifies the management of multithreaded applications. By automatically handling resource acquisition and release, thread joining, and exception handling, Structured Concurrency enables developers to write cleaner, more maintainable code that reduces the risk of common pitfalls. As a part of this post , we will have an in-depth exploration of this powerful tool, including its benefits, limitations, and practical applications.

### What is Structured Concurrency?

![](https://miro.medium.com/v2/resize:fit:640/0*OOZbDjCA-6cWkzet)

Structured Concurrency is a programming paradigm that simplifies the management of threads by automatically handling resource acquisition and release, thread joining, and exception handling. By adopting this approach, developers can write cleaner, more maintainable code that reduces the risk of common pitfalls, such as deadlocks and resource leaks.

It is an approach to **maintain the inherited scope** of subtasks related to a parent task by ensuring every child subtask returns to the same place when they finish. This achieves better **reliability** and **observability**.

In **OpenJDK**, it is defined under [**JEP 453**](https://openjdk.org/jeps/453).

### The Unstructured Concurrency: A Symphony of Errors

In the realm of unstructured concurrency, if one thread encounters an unexpected error, it’s akin to a rogue musician playing off-key. The other musicians, oblivious to the dissonance, might continue playing, potentially leading to a complete breakdown of the performance. There’s no clear mechanism to signal the error, halt the performance, and address the issue.

Consider a practical example: a microservice fetching data from multiple downstream services concurrently. Using traditional threads, launching separate threads for each service is relatively straightforward. However, the complexities arise when things go wrong. What if one service is temporarily unavailable, returns malformed data, or experiences a timeout?

![](https://miro.medium.com/v2/resize:fit:875/0*4OYph-5Osd5cIusI)

In unstructured concurrency, these errors can manifest in various undesirable ways:

-   **Lost Errors:** Exceptions thrown in one thread might not be properly propagated to the calling thread, leading to silent failures and difficult-to-diagnose bugs.
-   **Resource Leaks:** If a thread encounters an error and terminates prematurely, it might leave behind allocated resources, such as open network connections or file handles, leading to resource exhaustion over time.
-   **Race Conditions and Data Corruption:** Without careful synchronization, multiple threads accessing and modifying shared data can lead to race conditions, resulting in corrupted data and unpredictable application behavior.
-   **Difficult Debugging:** Tracing the flow of execution and pinpointing the source of errors in a complex multi-threaded application can be a Herculean task, often requiring complex debugging tools and significant development time.

There’s no inherent way to express dependencies between these concurrent operations. There’s no clear way to say, “If any part of this data retrieval fails, the entire operation should be considered a failure.” This lack of structure makes concurrent code difficult to reason about, maintain, and debug.

# Structured Concurrency: Bringing Harmony and Order

Structured Concurrency addresses these challenges by introducing a structured approach to managing concurrent tasks. It treats a set of related concurrent tasks as a single unit of work, establishing a clear hierarchy, much like a conductor leading an orchestra. The `StructuredTaskScope` class is the conductor's baton, providing the means to manage these concurrent tasks effectively.

The core principle is to create a well-defined scope for concurrent operations, ensuring that all forked tasks are properly managed and that errors and cancellations are handled gracefully within that scope. This eliminates the “wild west” of unstructured threads and brings a sense of order and predictability to concurrent execution.

### The Conductor’s Baton: `StructuredTaskScope` in Detail

The `StructuredTaskScope` is the cornerstone of Structured Concurrency. It provides the following key functionalities:

-   `**fork()**`**:** This method is the equivalent of instructing a section of the orchestra to play a specific part. It launches a new task within the scope, returning a `Future` representing the result of the task. Crucially, the forked task is bound to the scope, creating a clear parent-child relationship.
-   `**join()**`**:** This method represents the conductor waiting for all sections to finish their parts before proceeding to the next movement. It blocks the current thread until all forked tasks within the scope have completed, either successfully or with an exception.
-   `**close()**` **(via** `**try-with-resources**`**):** The `StructuredTaskScope` implements `AutoCloseable`, allowing it to be used with a `try-with-resources` block. This ensures that the scope is properly closed, even if exceptions occur, preventing resource leaks and ensuring proper cleanup.
-   **Shutdown Policies:** The `StructuredTaskScope` offers different shutdown policies to control how the scope behaves in the event of an error or completion:
-   `**ShutdownOnFailure**`**:** If any forked task throws an exception, all other running tasks within the scope are cancelled, and the exception is propagated to the calling thread. This policy is ideal when all tasks are interdependent, and the failure of one task renders the results of the others meaningless.
-   `**ShutdownOnSuccess**`**:** As soon as one task completes successfully, the scope shuts down, cancelling any remaining tasks. This is particularly useful for scenarios where you're searching for a specific result and only need the first successful outcome.

### Overview Structured Concurrency

![](https://miro.medium.com/v2/resize:fit:875/1*dhlAOijL8jEWcwhjdkznA.png)

Structured concurrency treats groups of related tasks running in different threads as a single unit of work, thereby streamlining error handling and cancellation, improving reliability, and enhancing observability.

The principal class of the structured concurrency API is [StructuredTaskScope](https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/concurrent/StructuredTaskScope.html) in the [java.util.concurrent](https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/concurrent/package-summary.html) package. This class enables you coordinate a group of concurrent subtasks as a unit. With a StructuredTaskScope instance, you fork each subtask, which runs them in their own individual thread. After, you join them as a unit. As a result, the StructuredTaskScope ensures that the subtasks are completed before the main task continues. Alternatively, you can specify that the application continues when one subtask succeeds.

### Basic Usage of the StructuredTaskScope Class

To use the StructuredTaskScope class, you follow these general steps:

1.  Create a StructuredTaskScope; use it with a `try`-with-resources statement.
2.  Define your subtasks as instances of Callable.
3.  Within the `try` block, fork each subtask in its own thread with StructuredTaskScope::fork.
4.  Call StructuredTaskScope::join.
5.  Handle the outcome from the subtasks.
6.  Ensure that the StructuredTaskScope is shut down.

The following figure illustrates these steps. Notice that the task scope must wait for all subtasks to finish execution because of the join() method. Afterward, it can handle the results of the subtask.

![](https://miro.medium.com/v2/resize:fit:563/1*zsYh3yb4wzA6lElSFdj3Iw.png)

In general, code that use the StructuredTaskScope class has the following structure:
```java
    Callable<String> task1 = ...  
    Callable<Integer> task2 = ...  
  
    try (var scope = new StructuredTaskScope<Object>()) {  
  
        Subtask<String> subtask1 = scope.fork(task1);  
        Subtask<Integer> subtask2 = scope.fork(task2);  
  
        scope.join();  
  
        ... process results/exceptions ...  
  
    } // close
```
Because the `StructuredTaskScope` was defined in a `try`-with-resources statement, at the end of the `try` block, the `StructuredTaskScope` is shut down, and the task scope waits for threads running any unfinished subtasks to complete.

The StructuredTaskScope class defines the shutdown method to shut down a task scope without closing it. This method cancels all unfinished subtasks by interrupting the threads. In addition, the shutdown method enables subclasses of StructuredTaskScope to implement a policy that doesn’t require all subtasks to finish. The section [Common Shutdown Policies: ShutdownOnSuccess and ShutdownOnFailure](https://docs.oracle.com/en/java/javase/21/core/structured-concurrency.html###GUID-97F95BF4-A1E2-40A3-8439-6BB4E3D5C422) describe two subclasses of StructuredTaskScope, ShutdownOnSuccess and ShutdownOnFailure. The first implements a policy that shuts down a task scope as soon as a subtask completes successfully while the second shuts down a task scope as soon as a subtask throws an exception.

![](https://miro.medium.com/v2/resize:fit:875/0*Teu9PWPNX7MhZ2tJ)

### A More Detailed Example: Orchestrating Data Retrieval

Let’s illustrate the power of `StructuredTaskScope` with a more elaborate example, simulating fetching product details, related products, and customer reviews from different data sources:
```java
import java.time.Duration;  
import java.util.concurrent.*;  
  
public class StructuredConcurrencyExample {  
  
    public static void main(String[] args) throws InterruptedException, ExecutionException {  
        try (var scope = new StructuredTaskScope.ShutdownOnFailure()) {  
            Future<String> productDetails = scope.fork(() -> fetchProductDetails(123));  
            Future<String> relatedProducts = scope.fork(() -> fetchRelatedProducts(123));  
            Future<String> customerReviews = scope.fork(() -> fetchCustomerReviews(123));  
  
            scope.join(); // Wait for all tasks to complete  
  
            String details = productDetails.resultNow();  
            String related = relatedProducts.resultNow();  
            String reviews = customerReviews.resultNow();  
  
            System.out.println("Product Details: " + details);  
            System.out.println("Related Products: " + related);  
            System.out.println("Customer Reviews: " + reviews);  
  
        } catch (ExecutionException e) {  
            System.err.println("An error occurred: " + e.getCause().getMessage()); // Centralized error handling  
        }  
    }  
  
    private static String fetchProductDetails(int productId) throws InterruptedException {  
        Thread.sleep(Duration.ofMillis(500));  
        return "Details for product " + productId;  
    }  
  
    private static String fetchRelatedProducts(int productId) throws InterruptedException {  
        Thread.sleep(Duration.ofMillis(750));  
        return "Related products for " + productId;  
    }  
  
    private static String fetchCustomerReviews(int productId) throws InterruptedException {  
        Thread.sleep(Duration.ofMillis(1000));  
        //Simulate potential error  
        //throw new RuntimeException("Error fetching reviews.");  
        return "Reviews for product " + productId;  
    }  
}
```

This example demonstrates how `StructuredTaskScope` simplifies the management of multiple concurrent operations. The `try-with-resources` block ensures proper resource management. The `fork()` method launches each data retrieval task concurrently. The `join()` method ensures the main thread waits for all tasks to complete. If any task throws an exception (as simulated in the commented-out code in `fetchCustomerReviews`), the `ShutdownOnFailure` policy cancels the other tasks and propagates the exception for centralized handling.

**Using Java 21 Preview features : Download JDK 21 and update your project to Java 21**

If you’re starting a new project, [Spring initalizr](https://start.spring.io/) already has a template for JDK 21.

**Enable preview**

How to enable preview depends on how the application is being run. The goal is to run it with the flag `--enable-preview`

### The Advantages of Structured Concurrency

1.  **Simplified Resource Management**: With Structured Concurrency, resources are automatically acquired and released, eliminating the need for manual resource handling and reducing the likelihood of resource leaks.
2.  **Automatic Thread Joining**: Structured Concurrency ensures that child threads join their parent threads, making it easier to manage the lifecycle of threads and avoid orphaned threads.
3.  **Centralized Exception Handling**: Exceptions in Structured Concurrency are centralized, allowing developers to handle errors more efficiently and avoid the complexities of nested try-catch blocks.
4.  **Simplified Error Handling:** Errors are propagated up the task hierarchy, making it easier to handle them in a centralized and predictable manner.
5.  **Controlled Cancellation:** Cancelling a parent task automatically cancels all its child tasks, preventing resource leaks and ensuring a clean shutdown.
6.  **Enhanced Readability and Maintainability:** The structured approach makes concurrent code significantly easier to understand, reason about, and maintain.
7.  **Improved Debugging:** The clear task hierarchy simplifies debugging and helps pinpoint the source of errors.
8.  **Reduced Boilerplate:** It reduces the amount of boilerplate code required for managing threads, futures, and exceptions in concurrent operations.

### The Disadvantages of Structured Concurrency

1.  **Performance Overhead**: The added abstraction of Structured Concurrency may introduce some performance overhead compared to manual thread management.
2.  **Learning Curve**: Adopting Structured Concurrency requires developers to learn a new paradigm, which may initially slow down the development process.
3.  **Preview Feature:** As a preview feature, the API is subject to change in future Java releases.
4.  **Not a Universal Solution:** Structured Concurrency is best suited for managing groups of related tasks that form part of a larger operation. For truly independent, long-running background processes (like a garbage collector or a background task scheduler), traditional thread pools or other concurrency mechanisms might be more appropriate.
5.  **ExecutorService Integration:** While `StructuredTaskScope` can use an `ExecutorService` for managing threads, careful consideration is needed to avoid resource contention and ensure proper shutdown of the executor.

Structured Concurrency in Java 21 offers a powerful, efficient, and safe approach to managing multithreaded applications. By simplifying resource management, automating thread joining, and centralizing exception handling, developers can write cleaner, more maintainable code that reduces the risk of common pitfalls. While there is a learning curve and some performance overhead associated with Structured Concurrency, the benefits far outweigh the limitations.

### Conclusion: The Next level of Concurrent Programming

Structured Concurrency in Java 21 represents a paradigm shift in how we approach concurrent programming. By providing a structured and disciplined approach to managing concurrent tasks, it addresses many of the challenges associated with traditional thread management. It allows us to orchestrate complex concurrent operations with greater ease, control, and clarity. While it’s not a silver bullet for all concurrency problems, it’s a powerful tool that significantly improves the robustness, maintainability, and debuggability of concurrent Java applications.


### Understanding Thread Priorities in Java: What They Do and What They Don’t 
![](https://miro.medium.com/v2/resize:fit:875/0*FFJXRYqh8n-sgw6o)
Photo by Tracey Parish on Unsplash

> **🎉** Article Published: 213
> 
> if you are not a medium member then Click here to read free

### What is Thread Priority in Java?

In Java, every thread has a **priority**, which helps the thread scheduler decide **which thread to run first** (when multiple threads are ready to run). Thread priority is just a hint to the **thread scheduler**, and **doesn’t guarantee** the order of execution

###### Priority Range:

-   Java provides 10 priority levels (from 1 to 10).
-   These are defined as constants in the `Thread` class

![](https://miro.medium.com/v2/resize:fit:875/1*16PB5XLgSbAyS6l9l0sCcw.png)

### let’s break it down so **even a beginner or normal developer** can clearly understand:

###### Why Thread Priority Doesn’t Guarantee Execution Order?

###### What really happens behind the scenes:

When you create threads in Java and set priorities like this
```java
t1.setPriority(Thread.MINPRIORITY); // 1  
t2.setPriority(Thread.MAXPRIORITY); // 10
```
You might think:

> “Cool, t2 will always run before t1.”

But that’s **not always true** — and here’s why:

### Think of the Thread Scheduler like a Traffic Police

Imagine you have:

Ambulance (priority = 10)

Taxi (priority = 5)

-   Auto Rickshaw (priority = 1)

In **some countries**, ambulances always get to go first.  
But in others, **traffic flow and conditions** decide who goes first

The **Java Thread Scheduler** works like that:

-   It **uses the thread priority as a hint**, saying:
-   “This thread is more important, please try to run it sooner.”
-   But the final decision depends on:
-   The **Operating System (OS)** (Windows, Linux, macOS)
-   The **JVM implementation**
-   CPU availability, number of cores, other running programs,

### So What Can Actually Happen?

Even if `t2` has a higher priority, the scheduler might:

-   Let `t1` run first
-   Alternate between them (time slicing)
-   Delay `t2` if the CPU is busy

So the output of your multithreaded program **may vary every time you run it** — this is **normal**

### So Why Does Java Even Allow Setting Priorities?

Because in **some real-time or OS-specific environments**, **thread priorities work more predictably** — especially in:

-   Embedded systems
-   Real-time operating systems (RTOS)
-   Low-level performance tuning

But for **normal application developers** (like those working in web apps, mobile apps, or backend systems):

-   You should **not rely on thread priority to control flow**
-   Instead, use proper design patterns: like `Executors`, `ThreadPools`, `Queues`, `Locks`, and `Semaphores`

### How to Set Thread Priority

You can use the `setPriority(int priority)` method

`Thread t1 = new Thread();  
t1.setPriority(Thread.MAXPRIORITY); // 10

You can retrieve priority using `getPriority()`
```java
int p = t1.getPriority(); // returns 10
```
###### Important Notes

-   The default priority of a thread is `NORMPRIORITY` (5).
-   The JVM scheduler may **prefer higher-priority threads**, but **this behavior is OS-dependent**.
-   In most systems, thread priorities **do not guarantee** the execution order

Example Program
```java
class MyThread extends Thread {  
    public MyThread(String name) {  
        super(name);  
    }  
  
    public void run() {  
        for (int i = 1; i <= 3; i++) {  
            System.out.println(getName() + " with priority " + getPriority() + " is running...");  
        }  
    }  
}  
  
public class ThreadPriorityExample {  
    public static void main(String[] args) {  
        MyThread t1 = new MyThread("Thread-1");  
        MyThread t2 = new MyThread("Thread-2");  
        MyThread t3 = new MyThread("Thread-3");  
  
        // Set priorities  
        t1.setPriority(Thread.MINPRIORITY);   // 1  
        t2.setPriority(Thread.NORMPRIORITY);  // 5 (default)  
        t3.setPriority(Thread.MAXPRIORITY);   // 10  
  
        // Start threads  
        t1.start();  
        t2.start();  
        t3.start();  
    }  
}
```
```shell

Possible Output

Thread-3 with priority 10 is running...  
Thread-3 with priority 10 is running...  
Thread-2 with priority 5 is running...  
Thread-3 with priority 10 is running...  
Thread-1 with priority 1 is running...  
Thread-2 with priority 5 is running...  
Thread-1 with priority 1 is running...  
...
```

Note: The actual output may vary depending on the OS and JVM. Priorities give a hint, not a rule

### Real-Time Use Case of Thread Priority

### 1. Media Player (Audio vs. Visual Thread)

Imagine you are building a **media player** app:

-   **Audio thread** (plays music) must run **smoothly** without lag.
-   **UI/Visual thread** (animations or effects) can run slightly slower
```java
audioThread.setPriority(Thread.MAXPRIORITY);     // Ensure smooth playback  
visualEffectThread.setPriority(Thread.NORMPRIORITY); // Less critical
```
Why? Because **audio lag is noticeable and annoying**, but a slight delay in animations isn’t a big issue

### 2. Real-Time Sensor Monitoring System

Example: In a **smart home** system or industrial IoT application:

-   `SensorReaderThread` → Reads fire or gas sensor data.
-   `LogWriterThread` → Writes logs to a file.
-   `UIUpdateThread` → Updates the user interface
```java
sensorThread.setPriority(Thread.MAXPRIORITY);  // Critical safety feature  
logThread.setPriority(Thread.NORMPRIORITY);    // Important, but not urgent  
uiThread.setPriority(Thread.MINPRIORITY);      // Least urgent
```
Higher priority helps the **sensor thread** preempt others in urgent scenarios like fire detection

### Where It’s Not Reliable or Not Recommended

-   In **most modern operating systems**, thread priority is treated as a suggestion.
-   For **server-side Java (Spring Boot apps, REST APIs)**, thread priority is rarely useful.
-   Use **Executors or thread pools** for better thread management

### Best Practice Tip

> Use thread priority **only when**:

-   You understand the underlying OS behavior.
-   You are developing a **real-time system** (media, sensors, robotics, embedded).
-   You want to **influence**, not control, thread scheduling.


# Different ways of Java Handling Exceptions in CompletableFutures


![](https://miro.medium.com/v2/resize:fit:875/0*UOllnDaSKxoupRe.jpg)

Hi Folks! As part of this blog, we will explore how we can handle exception in the different computing stages when we use CompletableFuture. We assume the read has the basic idea of the CompletableFuture. Nonethless, will start with the basic introduction of the CompletableFuture.

### What is CompletableFuture

A **CompletableFuture** is used for asynchronous programming which was introduced as an improvement of the java Future API in Java 8. If you are familiar with the Java’s Future API, you will be pretty much able to relate the this API. It offers composibility on different stages of computations. If you are new to asynch programming in Java, I would like you to go through this [blog](https://www.baeldung.com/java-completablefuture) which explains well about the CompletableFuture API.

A CompletableFuture is a class in Java. It belongs to java.util.cocurrent package. It implements CompletionStage and Future interface.

This is the most basic completable future we have by using no arg constructor

CompletableFuture<String> CompletableFuture = new CompletableFuture<String>();

Having said that, let us explore how we handle exceptions with the different stages of CompletableFuture computation.

# **Exception Handling of CompletableFuture**

Consider the following figure, which represents the five CFs (CompletableFutures):

![CompletableFuture in Java](https://miro.medium.com/v2/resize:fit:510/0*H4r16qtb1r-Xx7L7.png)

Suppose Five CFs in execution and CF21 raises an exception then all the depending CF (CF31 and CF41) are in error. It means that:

-   The call to isCompletedExceptionally() method returns true.
-   The call to get() throws an ExecutionException which causes the root Exception.

Consider the following figure, in which we have created CF30 with an exception.

![CompletableFuture in Java](https://miro.medium.com/v2/resize:fit:501/0*LWecuOK4Pdf87M6.png)

When CF21 executes normally, then CF30 just transmits the value. If it raises an exception, CF30 handles it and generate value for CF31.

### Using different exception Handling Methods

There are three main method to handle an exception offered by the API as shown below. Let us go through them one by one.
```java
public CompletableFuture <T> exceptionally(Function <Throwable, ? extends T> function);    
  
  
public <U> CompletableFuture<U> hadle(BiFunction<? super T, Throwable, ? extends U> bifunction);    
  
  
public CompletableFuture<T> whenComplete(BiConsumer<? super T, ? super Throwable> action);
```

### **Using exceptionally() method**

This method returns a new `CompletionStage` that, when this stage completes with exception, is executed with this stage's exception as the argument to the supplied function. Otherwise, if this stage completes normally, then the returned stage also completes normally with the same value.

Simply if there’s no exception then exceptionally( ) stage is skipped otherwise it is executed.

The exception passed to the exceptionally function is Completion Exception which wraps the actual exception as its root cause.
```java
future = future.thenApply(Integer::parseInt) // input String: "Example"  
        .thenApply(r -> r * 4)  
        .thenApply(s -> "apply>> " + s)  
        .exceptionally(ex -> "Error: " + ex.getMessage()); 
``` 
Run the code, the result will be:  
  
Error: java.lang.NumberFormatException: For input string: "Example"  
"Example" is the String we return to future object before call the first thenApply() method.

### **Using handle() method**
```java
future = future.thenApply(Integer::parseInt) // input String: "Example"  
        .thenApply(r -> r * 2)  
        .thenApply(s -> "apply>> " + s)  
//        .exceptionally(ex -> "Error: " + ex.getMessage())  
        .handle((result, ex) -> {  
          if (result != null) {  
            return result;  
          } else {  
            return "Error handling: " + ex.getMessage();  
          }  
        });
```  
Run the code, the result will be:  
  
accept: Error handling: java.lang.NumberFormatException: For input string: "Example"

### **Using whenComplete()**

Handle() methods are allowed to return a result (in case of exception a recovering result) thus they can **handle** the exception. On the other hand, `whenComplete()` methods cannot return a results. So they are used as merely callbacks that do not interfere in the processing pipeline of CompletionStages.

If there’s an unhandled exception coming from the stages before ‘whenComplete’ stage then that exception is passed through as it is. In other words if the upstream CompletionStage completes exceptionally, the CompletionStage returned by whenComplete() also completes exceptionally.
```java
CompletableFuture<String> test=new CompletableFuture<>();  
test.whenComplete((result, ex) -> System.out.println("stage 2: "+result+"t"+ex))  
    .exceptionally(ex -> { System.out.println("stage 3: "+ex); return ""; });  
test.completeExceptionally(new IOException());  
```
will print:  
  
stage 2: null   java.io.IOException  
stage 3: java.util.concurrent.CompletionException: java.io.IOException

### **Conclusion**

After reading this blog , you must have got the basic idea how to handle exception from completable futures with various basic exceptionally functions.
