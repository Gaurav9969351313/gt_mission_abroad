# Master Modern Java like a Pro: CompletableFuture for Async Workflows — Part 14

In real-world applications, not every task needs to block the main thread. Whether you’re calling multiple services, fetching data from APIs, or doing background computations — **asynchronous programming** helps you scale efficiently.

Enter `**CompletableFuture**` — Java's modern tool for writing clean, non-blocking, and powerful async workflows.

In this guide, we’ll break it all down:

-   What `CompletableFuture` is
-   How to run async tasks
-   How to chain, combine, and handle exceptions
-   Real-world use cases with step-by-step examples

Let’s dive in.

# ✅ Technologies Used

-   Java 21
-   Spring Boot 3 (for structure)
-   `CompletableFuture` (from `java.util.concurrent`)
-   JSONPlaceholder API (for parallel HTTP calls)

# What is `CompletableFuture`?

`CompletableFuture` is a class in Java that lets you write **non-blocking asynchronous code** using a clean and fluent API.

It solves the limitations of `Future` (Java 5), which:

-   Couldn’t be manually completed
-   Didn’t support chaining
-   Didn’t support combining multiple futures

# Simple Example: Running Code Asynchronously
```java
CompletableFuture<Void> future = CompletableFuture.runAsync(() -> {  
    System.out.println("Running in: " + Thread.currentThread().getName());  
});
```

✅ This runs the task in a **separate thread** without blocking the main one.

# Example: Return a Value Asynchronously
```java
CompletableFuture<String> future = CompletableFuture.supplyAsync(() -> {  
    return "Hello, Java!";  
});  
``` 
```java
String result = future.join(); // blocks and waits  
System.out.println(result);
```
> ✅ Use `supplyAsync()` when your task returns a result  
> ✅ Use `join()` to wait and retrieve the result (like `get()` but without checked exceptions)

# Chaining Futures: `thenApply`
```java
var future = CompletableFuture.supplyAsync(() -> 5)  
    .thenApply(n -> n * 2)  
    .thenApply(n -> "Result: " + n);  
  
System.out.println(future.join()); // Output: Result: 10
```
✅ You can transform the result in each step  
✅ The next step only runs **after** the previous one completes

# Async Composition: `thenCompose`

When the next step returns a new `CompletableFuture`, use `thenCompose`:
```java
CompletableFuture<String> future = CompletableFuture.supplyAsync(() -> "https://example.com")  
    .thenCompose(url -> CompletableFuture.supplyAsync(() -> "Fetched: " + url));  
  
System.out.println(future.join());
```
✅ Used when one async task depends on another

# Combine Two Independent Futures: `thenCombine`
```java
var userFuture = CompletableFuture.supplyAsync(() -> "Ravi");  
var emailFuture = CompletableFuture.supplyAsync(() -> "ravi@example.com");  
  
var result = userFuture.thenCombine(emailFuture, (name, email) -> name + " - " + email);  
  
System.out.println(result.join());
```
✅ Ideal when two tasks are independent but you want to combine results later

# Handle Errors: `exceptionally`
```java
var future = CompletableFuture.supplyAsync(() -> {  
    if (true) throw new RuntimeException("Oops!");  
    return "Done";  
}).exceptionally(ex -> "Failed: " + ex.getMessage());  
  
System.out.println(future.join()); // Output: Failed: Oops!
```
✅ You can return a fallback value if something goes wrong

# Real-World Example: Parallel API Calls

Imagine a service that fetches both user data and post data from external APIs.
```java
@Service  
public class AsyncApiService {  
  
    private static final String USERURL = "https://jsonplaceholder.typicode.com/users/1";  
    private static final String POSTURL = "https://jsonplaceholder.typicode.com/posts/1";  
  
    private final ObjectMapper mapper = new ObjectMapper();  
    private final HttpClient client = HttpClient.newHttpClient();  
  
    public CompletableFuture<UserDTO> fetchUserAsync() {  
        return CompletableFuture.supplyAsync(() -> {  
            try {  
                var request = HttpRequest.newBuilder().uri(URI.create(USERURL)).GET().build();  
                var response = client.send(request, HttpResponse.BodyHandlers.ofString());  
                return mapper.readValue(response.body(), UserDTO.class);  
            } catch (Exception e) {  
                throw new RuntimeException(e);  
            }  
        });  
    }  
  
    public CompletableFuture<PostDTO> fetchPostAsync() {  
        return CompletableFuture.supplyAsync(() -> {  
            try {  
                var request = HttpRequest.newBuilder().uri(URI.create(POSTURL)).GET().build();  
                var response = client.send(request, HttpResponse.BodyHandlers.ofString());  
                return mapper.readValue(response.body(), PostDTO.class);  
            } catch (Exception e) {  
                throw new RuntimeException(e);  
            }  
        });  
    }  
  
    public CompletableFuture<String> fetchUserAndPost() {  
        return fetchUserAsync().thenCombine(fetchPostAsync(), (user, post) -> {  
            return "User: " + user.name() + ", Post Title: " + post.title();  
        });  
    }  
}
```
# Record DTOs:
```java
public record UserDTO(Long id, String name, String email) {}  
public record PostDTO(Long id, String title, String body, Long userId) {}
```
# REST Controller:
```java
@RestController  
@RequestMapping("/api/async")  
public class AsyncApiController {  
  
    private final AsyncApiService service;  
  
    public AsyncApiController(AsyncApiService service) {  
        this.service = service;  
    }  
  
    @GetMapping("/combined")  
    public String getCombinedData() {  
        return service.fetchUserAndPost().join(); // Wait for both to finish  
    }  
}
```
✅ Both APIs are called **in parallel**, improving performance  
✅ The response is assembled only after both finish

# Summary of Key Methods

![](https://miro.medium.com/v2/resize:fit:875/1*n1svtq91bypexmxGA0xInQ.png)

# Where to Use `CompletableFuture`

-   Call external APIs in parallel
-   Process data without blocking the main thread
-   Improve performance in service aggregations
-   Run background computations or tasks
-   Replace `ExecutorService` boilerplate

# ❌ When Not to Use

-   For **CPU-bound** tasks that require tight resource control → prefer `ExecutorService`
-   When code becomes **too hard to read** → break it down
-   Don’t overuse chaining for deeply nested flows → refactor logic

# Wrap up

Java’s `CompletableFuture` is one of the most powerful tools in your modern Java toolbox.

It:

-   Makes asynchronous code readable
-   Scales well for multiple parallel tasks
-   Works perfectly with Java Records and functional pipelines
-   Plays well with service-based architectures and API clients
