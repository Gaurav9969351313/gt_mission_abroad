# Java deep copy and shallow copy. 

![](https://miro.medium.com/v2/resize:fit:875/1*pMAC4u1FtqNYFq0N8Qo7lg.png)

Ever wondered how objects are duplicated in Java? It’s not as simple as a quick “copy-paste”! Understanding **shallow copy** and **deep copy** is crucial for preventing unexpected behavior in your applications. Let’s dive in! 🏊‍♀️

# The Foundation: Primitive vs. Reference Types 🧱

Before we tackle copying, let’s lay the groundwork. Java categorizes data types into two main groups:

-   **Primitive Types (Value Types):** These are your basic building blocks like `char`, `boolean`, `byte`, `short`, `int`, `long`, `float`, and `double`. When you declare a primitive type, its **value is stored directly in the stack memory**. Think of it like putting a number directly into a box labeled "age." 📦
-   **Reference Types:** This group includes `classes`, `interfaces`, `arrays`, `enumerations`, and more. For reference types, the **stack stores a reference (an address)**, which then points to the actual **value stored in the heap memory**. Imagine the stack holding a sticky note with directions to a treasure chest in the heap. 🗺️💰

Consider this diagram illustrating memory allocation:

Stack Memory     | Heap Memory  
-----------------|-----------------  
a: 10           |  
b: 10           |  
c: [address_C]  | [address_C] -> "Hello"  
d: [address_C]  |

If you have `int a = 10;` and `int b = a;`, both `a` and `b` hold the value `10` directly in the stack. Simple!

However, if you have `String c = "Hello";` and then `String d = c;`, `c` and `d` don't store "Hello" directly. Instead, they both store references (memory addresses) that point to the _same_ "Hello" string in the heap. This distinction is key! 🔑 The statement `d = c` means the reference of `c` is assigned to `d`, so `c` and `d` will point to the same heap memory space.

# The `clone()` Method: Your Copying Tool 🛠️

In Java, object copying is often achieved by utilizing the `clone()` method from the `Object` class. Its signature is:

protected native Object clone() throws CloneNotSupportedException;

The `native` keyword means that the actual implementation is provided by the underlying operating system. For us, the important takeaway is that `clone()`'s purpose is to **create a new object that is a copy of the original**. ✨

# Shallow Copy: The Surface-Level Duplicate 🌊

A shallow copy is like taking a photocopy of a document. You get a new copy, but if the original document has embedded links to other files, your photocopy will still point to those _same_ linked files. 📎

In programming terms:

-   It creates a **new object**.
-   It copies the **primitive type attribute values** directly to the new object.
-   For **reference type attributes**, it copies only the **memory addresses (references)**, _not_ the actual objects they point to.

This means if you modify a reference type attribute in one object, the change will be reflected in its shallow copy because they both point to the same underlying data! 😱

Consider this diagram of a shallow copy:

Object 1 (s1)          | Object 2 (s2 - shallow copy)   | Heap Memory  
-----------------------|--------------------------------|-------------  
name: "Umesh"          | name: "Umesh"                  | [address_A] -> "Umesh"  
age: 20                | age: 20                        | 20  
address: [address_B]   | address: [address_B]           | [address_B] -> Address { province: "Kolkata", city: "Kolkata" }

To enable shallow copying via `clone()`, your class must `implement Cloneable` and `override the clone() method`.

Let’s look at an example:
```java
public class Address {  
    private String province;  
    private String city;  
  
    public void setAddress(String province, String city) {  
        this.province = province;  
        this.city = city;  
    }  
    @Override  
    public String toString() {  
        return "Address [province=" + province + ", city=" + city + "]";  
    }  
}  
  
public class Student implements Cloneable {  
    private String name;  
    private int age;  
    private Address address; // Reference type!  
    public Student() {  
    }  
    public Student(String name, int age) {  
        this.name = name;  
        this.age = age;  
        this.address = new Address();  
    }  
    public String getName() {  
        return name;  
    }  
    public void setName(String name) {  
        this.name = name;  
    }  
    public int getAge() {  
        return age;  
    }  
    public void setAge(int age) {  
        this.age = age;  
    }  
    public void setAddress(String province, String city) {  
        address.setAddress(province, city);  
    }  
    public void display(String name) {  
        System.out.println(name + ":" + "name=" + name + ", age=" + age + "," + address);  
    }  
    @Override  
    protected Object clone() throws CloneNotSupportedException {  
        return super.clone(); // Default shallow copy  
    }  
}
```
This is the original `Student` class that we want to assign values to. Next, we create a `Student` object and call its `clone` method to copy a new object.

**Note:** To call the `clone` method of an object, the class must implement the `Cloneable` interface and override the `clone` method.

**Testing Shallow Copy:**
```java
public static void main(String[] args) throws CloneNotSupportedException {  
    Student s1 = new Student("Umesh", 20);  
    s1.setAddress("Kolkata", "Kolkata");  
    Student s2 = (Student) s1.clone(); // s2 is a shallow copy of s1  
  
    System.out.println("S1:" + s1);  
    System.out.println("s1.getName:" + s1.getName().hashCode());  
    System.out.println("S2:" + s2);  
    System.out.println("s2.getName:" + s2.getName().hashCode());  
    s1.display("s1");  
    s2.display("s2");  
    s2.setAddress("Kolkata", "Patna"); // Modifying s2's address  
    s1.display("s1"); // Watch s1's address!  
    s2.display("s2");  
}
```
**Output Analysis:**

S1:org.example.jvm.Student@2a84aee7  
s1.getName:756703  
S2:org.example.jvm.Student@a09ee92  
s2.getName:756703  
s1:name=s1, age=20,Address [province=Kolkata, city=Hefei]  
s2:name=s2, age=20,Address [province=Kolkata, city=Hefei]  
s1:name=s1, age=20,Address [province=Kolkata, city=Patna]  <-- s1 changed too!  
s2:name=s2, age=20,Address [province=AnhKolkataui, city=Patna]

First, we create an object `s1` of the `Student` class, whose name is `Umesh`, age is 20, and the two attributes of the `Address` class are Kolkata and `Patna`. Then we call the `clone()` method to copy another object `s2`, and then print the contents of the two objects.

Judging from the print results, these are two different objects. From the object contents printed, we can see that the original object `s1` and the cloned object `s2` have exactly the same contents. We change the `Address` attribute of the cloned object `s2` to `Kolkata Patna` (the original object `s1` is `Kolkata Patna`), but from the print results, we can see that the `Address` attributes of both the original object `s1` and the cloned object `s2` have been modified.

The `Address` property of the `Student` object, after being cloned, actually only copies its reference. They still point to the same heap memory space. When the `Address` property of one object is modified, the other will also change.

**Shallow copy:** Create a new object, then copy the non-static fields of the current object to the new object. If the field is of value type, the field is copied; if the field is of reference type, the reference is copied but the referenced object is not copied. Therefore, the original object and its copy refer to the same object.

# Deep Copy: The Independent Duplicate 🌳

A deep copy is like making a complete replica of a document, including making copies of any linked files it refers to. Everything is duplicated independently. 👯‍♀️

With a deep copy:

-   It creates a **new object**.
-   It copies all **primitive type attribute values**.
-   For **reference type attributes**, it recursively creates **new instances of those referenced objects** and copies their content.

This ensures that the original object and its deep copy are completely independent. Modifying one will **not affect the other**. 🎉

Consider this diagram of a deep copy:

Object 1 (s1)         | Object 2 (s2 - deep copy)      | Heap Memory  
----------------------|--------------------------------|-------------  
name: "Umesh"         | name: "Umesh"                 | [address_A] -> "Umesh"  
age: 20               | age: 20                        | 20  
address: [address_B]  | address: [address_C]           | [address_B] -> Address { province: "Kolkata", city: "Kolkata" }  
                      |                                | [address_C] -> Address { province: "Kolkata", city: "Patna" }

For `Student` member variables of reference type `Address`, you need to implement `Cloneable` and override the `clone()` method.
```java
public class Address implements Cloneable {  
    private String province;  
    private String city;  
  
    public void setAddress(String province, String city) {  
        this.province = province;  
        this.city = city;  
    }  
    @Override  
    protected Object clone() throws CloneNotSupportedException {  
        return super.clone();  
    }  
    @Override  
    public String toString() {  
        return "Address [province=" + province + ", city=" + city + "]";  
    }  
}
```

In the `Student` method `clone()`, you need to get the new object generated after copying itself, and then call the copy operation on the reference type of the new object to achieve a deep copy of the reference type member variable.
```java
public class Student implements Cloneable {  
    private String name;  
    private int age;  
    private Address address;  
  
    public Student() {  
    }  
    public Student(String name, int age) {  
        this.name = name;  
        this.age = age;  
        this.address = new Address();  
    }  
    public String getName() {  
        return name;  
    }  
    public void setName(String name) {  
        this.name = name;  
    }  
    public int getAge() {  
        return age;  
    }  
    public void setAge(int age) {  
        this.age = age;  
    }  
    public void setAddress(String province, String city) {  
        address.setAddress(province, city);  
    }  
    public void display(String name) {  
        System.out.println(name + ":" + "name=" + name + ", age=" + age + "," + address);  
    }  
    @Override  
    protected Object clone() throws CloneNotSupportedException {  
        Student s = (Student) super.clone();  
        s.address = (Address) address.clone(); // Deep copy of Address  
        return s;  
    }  
}
```

**Testing Deep Copy with** `**clone()**`**:**
```java
public static void main(String[] args) throws CloneNotSupportedException {  
    Student s1 = new Student("Xiao Ming", 20);  
    s1.setAddress("Kolkata", "Kolkata");  
    Student s2 = (Student) s1.clone(); // s2 is now a deep copy  
  
    System.out.println("S1:" + s1);  
    System.out.println("s1.getName:" + s1.getName().hashCode());  
    System.out.println("S2:" + s2);  
    System.out.println("s2.getName:" + s2.getName().hashCode());  
    s1.display("s1");  
    s2.display("s2");  
    s2.setAddress("Kolkata", "Patna"); // Modifying s2's address  
    s1.display("s1"); // s1's address should remain unchanged!  
    s2.display("s2");  
}
```

**Output Analysis:**

S1:org.example.jvm.Student@2a84aee7  
s1.getName:756703  
S2:org.example.jvm.Student@a09ee92  
s2.getName:756703  
s1:name=s1, age=20,Address [province=Kolkata, city=Kolkata]  
s2:name=s2, age=20,Address [province=kolkata, city=kolkata]  
s1:name=s1, age=20,Address [province=kolkata, city=Patna]  <-- s1 remains unchanged!  
s2:name=s2, age=20,Address [province=kolkata, city=Kolkata]

From the output results, we can see that after deep copying, whether it is a member variable of a basic data type or a reference type, modifying its value will not affect each other.

**Note:** However, this approach has a disadvantage. Here our `Student` class has only one `Address` reference type, but the `Address` class has no reference type, so we only need to rewrite the `clone` method of the `Address` class. However, if the `Address` class also has a reference type, then we also have to rewrite its `clone` method. In this way, we have to rewrite it as many times as there are reference types. If there are many reference types, the amount of code will obviously be very large, so this method is not suitable.

## There is another way to achieve deep copy: using **serialization**.

Serialization is writing objects to a stream for transmission, while deserialization is reading objects from a stream. The object written to the stream here is a copy of the original object. Since the original object still exists in the JVM, we can use the serialization of the object to generate a cloned object, and then obtain this object through deserialization.

Note that every class that needs to be serialized must implement the `Serializable` interface. If a property does not need to be serialized, it can be declared as `transient`, i.e., excluded from the cloned properties.
```java
public class Address implements Serializable {  
    private String province;  
    private String city;  
  
    public void setAddress(String province, String city) {  
        this.province = province;  
        this.city = city;  
    }  
    @Override  
    public String toString() {  
        return "Address [province=" + province + ", city=" + city + "]";  
    }  
}  
  
public class Student implements Serializable {  
    private String name;  
    private int age;  
    private Address address;  
    public Student() {  
    }  
    public Student(String name, int age) {  
        this.name = name;  
        this.age = age;  
        this.address = new Address();  
    }  
    public String getName() {  
        return name;  
    }  
    public void setName(String name) {  
        this.name = name;  
    }  
    public int getAge() {  
        return age;  
    }  
    public void setAge(int age) {  
        this.age = age;  
    }  
    public void setAddress(String province, String city) {  
        address.setAddress(province, city);  
    }  
    public void display(String name) {  
        System.out.println(name + ":" + "name=" + name + ", age=" + age + "," + address);  
    }  
    // Deep copy  
    public Object deepClone() throws Exception {  
        // Serialization  
        ByteArrayOutputStream bos = new ByteArrayOutputStream();  
        ObjectOutputStream oos = new ObjectOutputStream(bos);  
        oos.writeObject(this);  
        // Deserialization  
        ByteArrayInputStream bis = new ByteArrayInputStream(bos.toByteArray());  
        ObjectInputStream ois = new ObjectInputStream(bis);  
        return ois.readObject();  
    }  
}
```

**Testing Deep Copy with Serialization:**

Java
```java
public static void main(String[] args) throws Exception {  
    Student s1 = new Student("Xiao Ming", 20);  
    s1.setAddress("Anhui", "Hefei");  
    Student s2 = (Student) s1.deepClone(); // Deep copy using serialization  
  
    System.out.println("S1:" + s1);  
    System.out.println("s1.getName:" + s1.getName().hashCode());  
    System.out.println("S2:" + s2);  
    System.out.println("s2.getName:" + s2.getName().hashCode());  
    s1.display("s1");  
    s2.display("s2");  
    s2.setAddress("Anhui", "Anqing"); // Modifying s2's address  
    s1.display("s1"); // s1's address should remain unchanged!  
    s2.display("s2");  
}
```

**Output Analysis:**

S1:org.example.jvm.Student@3f99bd52  
s1.getName:756703  
S2:org.example.jvm.Student@1f17ae12  
s2.getName:756703  
s1:name=s1, age=20,Address [province=Kolkata, city=Kolkata]  
s2:name=s2, age=20,Address [province=Kolkata, city=Kolkata]  
s1:name=s1, age=20,Address [province=Kolkata, city=Kolkata]  
s2:name=s2, age=20,Address [province=Kolkata, city=Patna]

Because serialization produces two completely independent objects, serialization can achieve deep copying no matter how many reference types are nested.

# In Summary: Choose Your Copy Wisely! 🤔

![](https://miro.medium.com/v2/resize:fit:875/1*Pw11ViCGkWg9LWX5UizNMA.png)

Understanding the difference between shallow and deep copies is fundamental for writing robust and predictable Java applications. Choose the right copying strategy based on your object’s structure and your application’s requirements! Happy coding! 💻✨

Thank you for your patience in reading this article! If you found this article helpful, please give it a clap 👏, bookmark it ⭐, and share it with friends in need and **follow** for more Spring Boot insights. Your support is my biggest motivation to continue to output technical insights!
