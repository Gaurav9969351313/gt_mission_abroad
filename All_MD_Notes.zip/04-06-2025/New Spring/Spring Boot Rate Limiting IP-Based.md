# Implementing Spring Boot Rate Limiting IP-Based  in Bucket4j

Here’s a complete example and detailed explanation for implementing IP-based request limiting in a Spring Boot application using Bucket4j. This example will ensure that requests from the same IP address are rate-limited to prevent abuse.

### 1. Add Bucket4j Dependency

In your `pom.xml` file, add the following dependency for Bucket4j:
```xml
<dependency>  
    <groupId>com.github.vladimir-bukhtoyarov</groupId>  
    <artifactId>bucket4j-core</artifactId>  
    <version>8.2.0</version>  
</dependency>
```
This library helps implement a token-bucket algorithm to rate-limit requests.

### 2. Create a Rate Limiting Filter

We’ll create a `RateLimitFilter` class that intercepts incoming requests, tracks them by IP address, and applies rate limiting.

### RateLimitFilter.java
```java
import io.github.bucket4j.Bandwidth;  
import io.github.bucket4j.Bucket;  
import io.github.bucket4j.Refill;  
import jakarta.servlet.Filter;  
import jakarta.servlet.FilterChain;  
import jakarta.servlet.FilterConfig;  
import jakarta.servlet.ServletException;  
import jakarta.servlet.ServletRequest;  
import jakarta.servlet.ServletResponse;  
import jakarta.servlet.http.HttpServletRequest;  
import org.springframework.http.HttpStatus;  
import org.springframework.stereotype.Component;  
  
import java.io.IOException;  
import java.time.Duration;  
import java.util.Map;  
import java.util.concurrent.ConcurrentHashMap;  
  
@Component  
public class RateLimitFilter implements Filter {  
  
    // A thread-safe map to store the IP address and their associated rate limit bucket  
    private final Map<String, Bucket> bucketCache = new ConcurrentHashMap<>();  
  
    @Override  
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)  
            throws IOException, ServletException {  
        HttpServletRequest httpRequest = (HttpServletRequest) request;  
        String ipAddress = httpRequest.getRemoteAddr(); // Get client's IP address  
  
        // Fetch or create a new bucket for this IP address  
        Bucket bucket = bucketCache.computeIfAbsent(ipAddress, this::createNewBucket);  
  
        // Check if there are enough tokens to allow the request  
        if (bucket.tryConsume(1)) {  
            chain.doFilter(request, response); // Proceed with the request  
        } else {  
            // Too many requests, return HTTP 429 (Too Many Requests)  
            response.getWriter().write("Too many requests. Please try again later.");  
            response.getWriter().flush();  
            ((HttpServletResponse) response).setStatus(HttpStatus.TOOMANYREQUESTS.value());  
        }  
    }  
  
    // Creates a new rate limiting bucket for the given IP address  
    private Bucket createNewBucket(String ip) {  
        Bandwidth limit = Bandwidth.classic(10, Refill.greedy(10, Duration.ofMinutes(1)));  
        return Bucket.builder().addLimit(limit).build(); // Allow 10 requests per minute  
    }  
  
    @Override  
    public void init(FilterConfig filterConfig) {}  
  
    @Override  
    public void destroy() {}  
}
```

### 3. Configure the Filter in Spring Boot

The `@Component` annotation ensures that Spring Boot automatically detects the filter and applies it to every request. You don't need any additional configuration for the filter unless you want to customize its order or mapping.

### 4. Explanation of Code

-   **Bucket4j**: This library implements the token bucket algorithm. Each IP address gets a “bucket” that holds tokens, and each request consumes a token.
-   **Map of Buckets**: A `ConcurrentHashMap` is used to store a bucket for each unique IP address. This map is thread-safe to handle multiple requests concurrently.
-   **Refill Strategy**: The `Bandwidth.classic(10, Refill.greedy(10, Duration.ofMinutes(1)))` means that each IP is allowed to make 10 requests per minute. After consuming the limit, tokens refill over time.
-   **Token Check**: The `bucket.tryConsume(1)` checks if there's a token left in the bucket. If yes, the request is processed. If not, the client receives an HTTP 429 status ("Too Many Requests").

### 5. Test the Rate Limiting

### TestController.java

You can create a simple test controller to check the functionality of the rate limiter.
```java
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.RestController;  
  
@RestController  
public class TestController {  
  
    @GetMapping("/test")  
    public String testRateLimit() {  
        return "Request successful!";  
    }  
}
```

In this example, the `/test` endpoint will only allow 10 requests per minute from the same IP address. Once the limit is exceeded, subsequent requests will return a "Too many requests" message.

### 6. Run the Application

-   Start your Spring Boot application.
-   Hit the `/test` endpoint from the same IP address using Postman or a web browser.
-   After making 10 requests within one minute, you will start getting the “Too many requests” error.

### 7. Customization Options

You can customize the request limiting logic based on your application’s requirements:

-   **Change the request rate**: Adjust `Bandwidth.classic(10, Refill.greedy(10, Duration.ofMinutes(1)))` to allow a different number of requests or modify the time duration.
-   **Limit by other factors**: Instead of limiting by IP, you can also apply rate limiting based on user tokens, API keys, or specific headers.
-   **Persist Buckets**: Store buckets in a database like Redis if you need distributed rate limiting across multiple instances of your application.

**Console Output**

2024-10-08 10:00:00.123  INFO 12345 --- [nio-8080-exec-1] com.example.ratelimit.TestController    : Request successful!  
2024-10-08 10:00:01.456  INFO 12345 --- [nio-8080-exec-2] com.example.ratelimit.TestController    : Request successful!  
2024-10-08 10:00:02.789  INFO 12345 --- [nio-8080-exec-3] com.example.ratelimit.TestController    : Request successful!  
2024-10-08 10:00:03.012  INFO 12345 --- [nio-8080-exec-4] com.example.ratelimit.TestController    : Request successful!  
2024-10-08 10:00:04.234  INFO 12345 --- [nio-8080-exec-5] com.example.ratelimit.TestController    : Request successful!  
2024-10-08 10:00:05.567  INFO 12345 --- [nio-8080-exec-6] com.example.ratelimit.TestController    : Request successful!  
2024-10-08 10:00:06.890  INFO 12345 --- [nio-8080-exec-7] com.example.ratelimit.TestController    : Request successful!  
2024-10-08 10:00:08.123  INFO 12345 --- [nio-8080-exec-8] com.example.ratelimit.TestController    : Request successful!  
2024-10-08 10:00:09.456  INFO 12345 --- [nio-8080-exec-9] com.example.ratelimit.TestController    : Request successful!  
2024-10-08 10:00:10.789  INFO 12345 --- [nio-8080-exec-10] com.example.ratelimit.TestController    : Request successful!  
  
2024-10-08 10:00:11.012  INFO 12345 --- [nio-8080-exec-11] o.a.c.c.C.[Tomcat].[localhost].[/]      : Initializing Spring DispatcherServlet 'dispatcherServlet'  
2024-10-08 10:00:11.012  INFO 12345 --- [nio-8080-exec-11] o.s.web.servlet.DispatcherServlet        : Initializing Servlet 'dispatcherServlet'  
2024-10-08 10:00:11.012  INFO 12345 --- [nio-8080-exec-11] o.s.web.servlet.DispatcherServlet        : Completed initialization in 1 ms  
  
2024-10-08 10:00:11.123  INFO 12345 --- [nio-8080-exec-12] com.example.ratelimit.TestController    : Too many requests. Please try again later.  
2024-10-08 10:00:11.456  INFO 12345 --- [nio-8080-exec-13] com.example.ratelimit.TestController    : Too many requests. Please try again later.  
2024-10-08 10:00:11.789  INFO 12345 --- [nio-8080-exec-14] com.example.ratelimit.TestController    : Too many requests. Please try again later.  
2024-10-08 10:00:12.012  INFO 12345 --- [nio-8080-exec-15] com.example.ratelimit.TestController    : Too many requests. Please try again later.

### Note on Logging

-   Make sure your logging level is set appropriately in your `application.properties` file so that you can see these logs in the console. For example, you can set the logging level to `INFO` like this:

logging.level.root=INFO

### Explanation of the Console Output

1.  **Successful Requests**:

-   The first ten lines indicate successful requests made to the `/test` endpoint. Each line represents an incoming request that was allowed by the rate limiter.

**2. Rate-Limited Requests**:

-   After the tenth request, any further requests from the same IP address receive a response indicating “Too many requests.” This is logged in the subsequent lines, showing that the requests were denied due to exceeding the rate limit.

> **If you found my articles useful, please consider giving it many claps** 👏**and sharing it with your friends and colleagues.**
