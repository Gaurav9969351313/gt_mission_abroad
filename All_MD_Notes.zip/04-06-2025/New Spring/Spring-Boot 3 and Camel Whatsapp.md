# Notification Service with Spring-Boot 3 & Camel Whatsapp

> If you’re not a Medium member, you can read this for free using [this link](/multi-channel-notifications-service-with-spring-boot-3-apache-camel-camel-whatsapp-85ab7942666f?sk=0a58fd5703dfae63ee829b8bd1aa1f09).

![](https://miro.medium.com/v2/resize:fit:875/1*C_ySeTRE8M6Jo7wObYPS4Q.png)
Apache Camel Whatsapp Integration with Spring Boot

# Overview

In our Multi-Channel Notification service with Spring Boot 3 & Apache Camel Series, we have already covered the Integration of Camel Mail with Spring Boot. You can refer to that article [here](/multi-channel-notifications-service-with-spring-boot-apache-camel-camel-mail-d1af3f5405ca). So far, we have already covered:

1.  **What are Enterprise Integration Patterns?**
2.  **Overview of Apache Camel.**
3.  **Why did Apache Camel win over Spring Integration and Mule ESB?**
4.  **Usage of Apache Camel in designing Notification Service with multi-channels.**
5.  **How to integrate Camel Mail with Spring Boot.**

With today's article, we will extend our multi-channel notification architecture by adding camel Whatsapp integration to the existing design which contains camel mail. So with this integration, our Notification service will support both the Mail channel and WhatsApp channel.

# Camel Whatsapp Integration with Spring Boot 3

The Camel WhatsApp component provides access to the [WhatsApp Cloud API](https://developers.facebook.com/docs/whatsapp/cloud-api). It permits the use of a cloud-hosted version of the `WhatsApp Business Platform` for message sending by Camel-based applications.

First, we must configure `Platform Access` and `Developer Assets` before utilizing this component. Follow the instructions at the [Setup WhatsApp Business Cloud API account](https://developers.facebook.com/docs/whatsapp/cloud-api/get-started#set-up-developer-assets) for the setups that are required.

Once we set up the account and sign in, we can navigate to the [Meta for Developers Apps](https://developers.facebook.com/apps/?show_reminder=true), dashboard. Here we can access the WhatsApp dashboard to get the `Authorization Token`, `Phone Number Id.` These are mandatory parameters to access the component.

Follow the below [guide](https://developers.facebook.com/blog/post/2022/12/05/auth-tokens/) to access the WhatsApp dashboard and generate `Authorization Tokens` and `Phone Number Id` for the WhatsApp Business Platform.

After we have successfully generated a `permanent access token` and the `phone number ID`, we can start the spring boot application setup.

# Application Setup With Spring Boot

We will set up the application with Spring Initializer with the following dependencies in the `pom.xml` file.
```xml
<dependency>  
   <groupId>org.apache.camel.springboot</groupId>  
   <artifactId>camel-spring-boot-starter</artifactId>  
   <version>4.3.0</version>  
</dependency>  
  
<dependency>  
   <groupId>org.apache.camel.springboot</groupId>  
   <artifactId>camel-mail-starter</artifactId>  
   <version>4.3.0</version>  
</dependency>  
  
<dependency>  
   <groupId>org.apache.camel.springboot</groupId>  
   <artifactId>camel-whatsapp-starter</artifactId>  
   <version>4.3.0</version>  
</dependency>

```
with `camel-whatsapp-starter` dependency, the spring application would auto-configure configurations related to camel WhatsApp.

# Configure Whatsapp Configurations

Then we will configure the common WhatsApp configurations related to our spring boot application. We will define these configuration properties inside the `application.yml` file.
```yaml
camel:  
  component:  
    mail:  
      starttls: true  
      auth: true  
      ssl: true  
      host: SMTP_HOST  
      port: 465  
      username: EMAIL_USER_NAME  
      password: EMAIL_PASSWORD  
      from: EMAIL_FROM_ADDRESS  
    whatsapp:  
      phoneId: PHONE_NUMBER_ID  
      accessToken: AUTHORIZATION_TOKEN  
      messageType: MESSAGE_TYPE
```
here the messageType parameter is `optional`.

# Defining Camel Route for Whatsapp

We will define the Camel route for sending a WhatsApp message as follows.
```java
try (final CamelContext context = new DefaultCamelContext()) {  
  
            final String uri = String.format("whatsapp://%s?authorizationToken=%s",  
                    whatsappConfiguration.getPhoneId(), whatsappConfiguration.getAccessToken());  
  
            context.addRoutes(new RouteBuilder() {  
                @Override  
                public void configure() {  
  
                    from("seda:start")  
                            .to(uri)  
                            .log("Whatsapp Message sent with content ${in.body}").end();  
  
                }  
            });  
  
            } catch (Exception e) {  
            log.error("Error: {}", e.getMessage());  
        }
```
# Configuring the Camel Context and Sending the Whatsapp Message

We will configure the [CamelContext](https://camel.apache.org/manual/camelcontext.html) for sending the Whatsapp message with the desired camel body as follows. We used the [ProducerTemplate](https://camel.apache.org/manual/producertemplate.html#_advanced_with_a_template_customizer) to send the Whatsapp message asynchronously.
```java
context.start();  
final TemplateMessageRequest templateMessageRequest = NotificationUtil.getMessageRequest();  
ProducerTemplate producer = context.createProducerTemplate();  
producer.asyncRequestBody("seda:start", templateMessageRequest);  
context.stop();
```
# Trigger the Camel Whatsapp Endpoint

We used a Rest API to trigger the WhatsApp message-sending process as below.
```java
@Component  
@RequiredArgsConstructor  
public class NotificationHandler {  
  
    private final RequestService requestService;  
    public Mono<ServerResponse> triggerNotificationRequest(ServerRequest serverRequest) {  
  
        Mono<Object> mono = serverRequest.bodyToMono(NotificationRequestVO.class).flatMap(requestService::handleRequest);  
        return Mono  
                .from(mono)  
                .flatMap(p -> ServerResponse  
                        .status(HttpStatus.OK)  
                        .contentType(MediaType.APPLICATION_JSON)  
                        .body(fromValue(p))  
                );  
    }  
}

@Service  
@RequiredArgsConstructor  
@Slf4j  
public class NotificationRequestService implements RequestService {  
  
    private final NotificationSenderService notificationSenderService;  
    private final ResponseUtility responseUtility;  
  
    private static final String EMAIL_CHANNEL = "EMAIL";  
    private static final String WHATSAPP_CHANNEL = "WHATSAPP";  
  
    @Override  
    public Mono<Object> handleRequest(final NotificationRequestVO notificationRequestVO) {  
        if (notificationRequestVO.getChannel().equalsIgnoreCase(EMAIL_CHANNEL)) {  
            CompletableFuture.runAsync(notificationSenderService::sendNotificationEmail);  
        }else if (notificationRequestVO.getChannel().equalsIgnoreCase(WHATSAPP_CHANNEL)) {  
            CompletableFuture.runAsync(notificationSenderService::sendWhatsappNotification);  
        }  
        return Mono.just(responseUtility.successResponse("SUCCESS", "200"));  
    }  
}
```
# Summary

**In this article, we have covered:**

1.  Overview of Apache Camel Whatsapp
2.  How to integrate Camel Whatsapp with Spring Boot.

https://github.com/LordMaduz/multi-channel-notification-service
