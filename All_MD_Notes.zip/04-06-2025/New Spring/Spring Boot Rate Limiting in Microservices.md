# Implementing Rate Limiting in Microservices using Spring Boot and Redis
![](https://miro.medium.com/v2/resize:fit:875/1*HB4TH1A3CIQ6SFNtwTzhUg.png)

Rate limiting is a modern concept in API based services where we define a set limit to the API call. There could be various reason for that, It works as a preemptive approach to safeguard your critical or costly resource.

**rate limiting** is a critical safeguard against abuse, system overload, or unexpected traffic spikes. It controls how many requests a client can make to an endpoint within a given timeframe. In microservices, especially those exposed to external clients or integrated into larger ecosystems, enforcing fair usage and preventing DoS (Denial of Service) attacks becomes essential.

This article explores how to implement distributed rate limiting in a **Spring Boot** microservice using **Redis** as the backend store. We will cover token bucket and sliding window strategies and demonstrate how to integrate them with Spring using filters or libraries like Resilience4j. We would also discuss other peripheral aspect related to it.

![](https://miro.medium.com/v2/resize:fit:875/1*cJdvd4ViHD-YCO-ZRkuMg.png)

# Why Redis?

Redis on the forefront is an ideal backend for rate limiting because of:

-   **Speed**: In-memory operations make Redis extremely fast for counter updates.
-   **Atomicity**: Redis commands are atomic, avoiding race conditions in distributed environments.
-   **TTL Support**: Built-in support for key expiration aligns well with time-based rate limits.

We already know redis capabilities as cache since it has low latency and has expiration capabilities. This low latency becomes critical because the rate limiting overhead is over and above the API’s own latency.

# Rate Limiting Strategies

1.  **Fixed Window Counter**: Limits based on a fixed interval (e.g., 100 requests per minute).
2.  **Sliding Window Log**: Tracks timestamps of recent requests and checks within the window.
3.  **Token Bucket**: Maintains a bucket of tokens replenished at a fixed rate; requests consume tokens.
4.  **Leaky Bucket**: Similar to token bucket but focuses on processing rate (queue-based control).

For most use cases, **token bucket** or **sliding window** are preferred for balancing burst control and fairness.

![](https://miro.medium.com/v2/resize:fit:875/1*T2f4m52xxTrkDXCMHOSGA.png)

# Spring Boot Integration (**Fixed Window Counter**)

**Maven Dependencies**:
```xml
<dependency>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-starter-data-redis</artifactId>  
</dependency>  
<dependency>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-starter-web</artifactId>  
</dependency>
```
I am skipping redis configuration with spring boot for brevity, can be googled.

## Applying a filter
```java
@Component  
public class RateLimitingFilter extends OncePerRequestFilter {  
  
    @Autowired  
    private RedisRateLimiterService limiterService;  
  
    @Override  
    protected void doFilterInternal(HttpServletRequest request,  
                                    HttpServletResponse response,  
                                    FilterChain filterChain) throws ServletException, IOException {  
  
        String clientIp = request.getRemoteAddr();  
        String key = "rl:" + clientIp;  
  
        if (!limiterService.allowRequest(key, 100, 60)) {  
            response.setStatus(HttpStatus.TOOMANYREQUESTS.value());  
            response.getWriter().write("Rate limit exceeded");  
            return;  
        }  
  
        filterChain.doFilter(request, response);  
    }  
}
```
How to read above code : Whenever the API is invoked, call `RateLimitingFilter.doFilterInternal` once beforehand where create a key with caller ip, check `limiterService.allowRequest`whether to let request should pass or not. The argument we are passing is the ip key, `100` as number of request allowed and `60` as the time duration in seconds. In case if it is not allowed then return the `429 rate limit exceeded` response.

## Service
```java
@Service  
public class RedisRateLimiterService {  
  
    private final StringRedisTemplate redisTemplate;  
  
    public RedisRateLimiterService(StringRedisTemplate redisTemplate) {  
        this.redisTemplate = redisTemplate;  
    }  
  
    /**  
     * Checks and updates a simple fixed‐window counter in Redis  
     */  
    public boolean allowRequestPlain(String key, int limit, int windowSeconds) {  
        // 1) Read the current count  
        String currentVal = redisTemplate.opsForValue().get(key);  
        int current = currentVal == null ? 0 : Integer.parseInt(currentVal);  
  
        // 2) If already at or above limit, deny immediately  
        if (current >= limit) {  
            return false;  
        }  
  
        // 3) Increment the counter  
        long newCount = redisTemplate.opsForValue().increment(key);  
  
        // 4) If this was the first increment, set the TTL  
        if (newCount == 1) {  
            redisTemplate.expire(key, Duration.ofSeconds(windowSeconds));  
        }  
  
        // 5) Allow the request  
        return true;  
    }  
}
```

call redis with key, if key doesn’t exists set the value as 0, if the counter is greater than limit then disallow, and return false. If it’s within limit then increment it. In case it’s the first time we are setting the key set the expiry, after expiry the key will be auto deleted based on TTL.

## The atomicity issue and solution with lua

As you can see there are multiple call to redis for a single API call, there is always an issue of race condition. Let’s us say two API call originates at same time, then there is a chance of indeterminate state behavior.

We should wrap these redis template call into a single lock (or with synchronized block) to provide atomicity. But then it could become a performance bottleneck. If only there could be a way to ask redis to handle these steps in a single statement.

Enter Lua
```lua
-- ratelimiter.lua  
  
local key = KEYS[1]  
local limit = tonumber(ARGV[1])  
local expire = tonumber(ARGV[2])  
  
local current = redis.call('GET', key)  
if current and tonumber(current) >= limit then  
  return 0  
end  
  
current = redis.call('INCR', key)  
if tonumber(current) == 1 then  
  redis.call('EXPIRE', key, expire)  
end  
  
return 1
```

Above is a lua script which wraps multiple redis operations, and can be executed as a single operation, providing atomicity we need.

**Why Use Lua?**

-   **Atomicity**: The entire GET → check → INCR → maybe EXPIRE sequence runs as a single Redis command, preventing race conditions under heavy concurrent traffic.
-   **Performance**: Executed server-side with minimal network round-trips.

## What’s Different Compared to the Lua Version?

1.  **Multiple Round-Trips**

-   `GET` → `INCR` → `EXPIRE` ends up as three separate network calls.

**2. Race Conditions**

-   Two threads might both do `GET` (see 99), both judge “OK,” and then both call `INCR`, allowing the counter to momentarily exceed the limit.

**3. TTL Edge Cases**

-   If a crash occurs between the first `INCR` and the `expire(...)` call, you may end up with a key that never expires.

By packaging the logic in one script, you ensure precise counting and TTL management, which is essential for correct, distributed rate limiting.

**Service with lua script**
```java
@Service  
public class RedisRateLimiterService {  
  
    private final StringRedisTemplate redisTemplate;  
    private final DefaultRedisScript<Long> rateLimiterScript;  
  
    public RedisRateLimiterService(StringRedisTemplate redisTemplate) {  
        this.redisTemplate = redisTemplate;  
        this.rateLimiterScript = new DefaultRedisScript<>();  
        this.rateLimiterScript.setScriptSource(new ResourceScriptSource(new ClassPathResource("ratelimiter.lua")));  
        this.rateLimiterScript.setResultType(Long.class);  
    }  
  
    public boolean allowRequest(String userKey, int limit, int windowSeconds) {  
        Long result = redisTemplate.execute(rateLimiterScript,  
                Collections.singletonList(userKey),  
                String.valueOf(limit), String.valueOf(windowSeconds));  
        return result != null && result == 1;  
    }  
}
```
# Dashboard and Monitoring

You can expose metrics (e.g., current count, rejections) via:

-   Spring Boot Actuator
-   Micrometer + Prometheus
-   Redis CLI for debugging (`GET rl:ip-address`)

# Alternative: Spring Cloud Gateway

If you’re using Spring Cloud Gateway, you can use the built-in Redis-based rate limiter via application.yml
```yml
spring:  
  cloud:  
    gateway:  
      routes:  
        - id: limited-api  
          uri: http://localhost:8081  
          predicates:  
            - Path=/api/**  
          filters:  
            - name: RequestRateLimiter  
              args:  
                redis-rate-limiter.replenishRate: 5  
                redis-rate-limiter.burstCapacity: 10
```
[More description about this approach](/p/cc5f249e3381)

# Rate Limiting at Web-Server Level vs. Application-Level

Rate limiting can be applied at web server level as well as application level. Letus checkout the pros and cons of both.

## 1. Web-Server (Edge) Rate Limiting

**Examples:** NGINX `limitreq`, Envoy rate-limit filter, Cloud provider API Gateway, CDN rules

**Pros**

-   **Early Rejection —** Blocks excessive traffic before it ever hits your app servers, saving CPU, memory, and database connections.
-   **Uniform Enforcement —** One central configuration for all services, regardless of language or framework.
-   **High Performance —** Implemented in native code or C++; can handle millions of requests per second with minimal latency.
-   **DDoS Mitigation —** Often integrates with WAF or bot-detection modules, providing a first line of defense.
-   **Simplicity —** Configuration-only (no code changes), easy to version and deploy with your infrastructure.

**Cons**

-   **Coarse Granularity —** Limits are usually per IP or per route; hard to apply business-specific rules (e.g., per user account, per API key).
-   **Limited Context —** Cannot easily inspect authenticated user IDs, request payload, headers beyond simple patterns.
-   **Complex Topologies —** In multi-tier or microservices architectures, you may need rate limiting at several layers (ingress + internal gateways).

## Application-Level Rate Limiting

**Examples:** Java filters (OncePerRequestFilter), Resilience4j’s `RequestRateLimiter`, Bucket4j, custom Redis scripts, Spring Cloud Gateway

**Pros**

-   **Fine-Grained Control —** Can limit per user, per API key, per organization, or even per business operation (e.g., “5 password resets per hour”).
-   **Rich Contex t—** Can tie limits to authenticated identity, request content, headers, or downstream service health.
-   **Dynamic Rules —** Rules can be data-driven (from a database or admin UI) and updated without redeploying infrastructure.
-   **Composable with Business Logic —** Integrates seamlessly with application workflows, allowing differentiated error messages or custom fallbacks.

**Cons**

-   **Resource Consumption —** Every request reaches your application, consuming thread pool, memory, and potentially hitting downstream services before being rejected.
-   **Operational Overhead —** Need to develop, test, and maintain rate-limiting code, storage (Redis, in-memory), and metrics.
-   **Performance Impact —** Depending on implementation (e.g., Redis calls with Lua), you may introduce extra latency per request.

![](https://miro.medium.com/v2/resize:fit:875/1*SzRRNRaNwEl85ucdeIUyA.png)

## Hybrid Approach

Many organizations combine both:

1.  **Edge Rate Limiting** at the web server or API gateway to stop obvious abuse and protect infrastructure.
2.  **Application-Level Rate Limiting** for business-critical rules and fine-grained controls once the request enters your service mesh or application.

This strategy gives you both high-performance protection at the perimeter and rich, context-aware control inside your microservices.

# Conclusion

Rate limiting is essential for protecting APIs from abuse and ensuring system stability. Redis provides a powerful foundation for distributed rate limiting due to its speed and atomic operations. With Spring Boot, you can integrate Redis-based rate limiting using simple Lua scripts or Spring Cloud features, offering both flexibility and performance.

This approach ensures fairness across clients, protects against overload, and allows your microservices to scale safely in production.
