# Implementing fault tolerance(@Retry and @CircuitBreaker together) in Spring Boot Application using Resilience4j 

You are working on a project. Your application is sending some data using HTTP POST method to another rest api. This another rest api is not stable and it often crashes and go out of network. So, When your application sends that data to this api, you get service unavailable exception in your production logs and the data is lost forever.

To deal with this situation, we can implement Retry/Recovery that I have discussed in one of my [articles](/@sehgal.mohit06/spring-boot-retry-recover-functionality-14c958a5efcc).

In this article, we will implement retry functionality as well as **Circuit Breaker Pattern** using Resilience4j.

> Please share, clap and follow for more information. Put some comments and share your view on this article. Do not forget to subscribe the mailing list.

Lets get started. Read point 4 , if you want to directly jump onto the functionality. Read ponit 5,6 for using actuator.

1.  This is how my **pom.xml** looks like:
```xml
<?xml version="1.0" encoding="UTF-8"?>  
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  
 xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">  
 <modelVersion>4.0.0</modelVersion>  
 <parent>  
  <groupId>org.springframework.boot</groupId>  
  <artifactId>spring-boot-starter-parent</artifactId>  
  <version>3.2.5</version>  
  <relativePath/> <!-- lookup parent from repository -->  
 </parent>  
 <groupId>com.cbr.app</groupId>  
 <artifactId>cbr-demo</artifactId>  
 <version>0.0.1-SNAPSHOT</version>  
 <name>cbr-demo</name>  
 <description>Demo project for Spring Boot CBR</description>  
 <properties>  
  <java.version>17</java.version>  
 </properties>  
 <dependencies>  
  <dependency>  
   <groupId>org.springframework.boot</groupId>  
   <artifactId>spring-boot-starter-web</artifactId>  
  </dependency>  
  <dependency>  
   <groupId>org.springframework</groupId>  
   <artifactId>spring-aspects</artifactId>  
   <version>6.1.6</version>  
  </dependency>  
  <dependency>  
   <groupId>org.springframework.cloud</groupId>  
   <artifactId>spring-cloud-starter-circuitbreaker-resilience4j</artifactId>  
   <version>3.1.1</version>  
  </dependency>  
  <dependency>  
   <groupId>org.springframework.boot</groupId>  
   <artifactId>spring-boot-starter-actuator</artifactId>  
  </dependency>  
  
  <dependency>  
   <groupId>org.projectlombok</groupId>  
   <artifactId>lombok</artifactId>  
   <optional>true</optional>  
  </dependency>  
  <dependency>  
   <groupId>org.springframework.boot</groupId>  
   <artifactId>spring-boot-starter-test</artifactId>  
   <scope>test</scope>  
  </dependency>  
 </dependencies>  
  
 <build>  
  <plugins>  
   <plugin>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-maven-plugin</artifactId>  
    <configuration>  
     <excludes>  
      <exclude>  
       <groupId>org.projectlombok</groupId>  
       <artifactId>lombok</artifactId>  
      </exclude>  
     </excludes>  
    </configuration>  
   </plugin>  
  </plugins>  
 </build>  
  
</project>
```
2. **Entrypoint to the spring boot application**:
```java
package com.cbr.app.cbrdemo;  
  
import org.springframework.boot.SpringApplication;  
import org.springframework.boot.autoconfigure.SpringBootApplication;  
  
@SpringBootApplication  
public class CbrDemoApplication {  
  
 public static void main(String[] args) {  
  SpringApplication.run(CbrDemoApplication.class, args);  
 }  
  
}
```
3. **RestController**: Very Basic and simple to understand.
```java
package com.cbr.app.cbrdemo;  
  
import lombok.RequiredArgsConstructor;  
import lombok.extern.slf4j.Slf4j;  
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.RestController;  
  
@RestController  
@RequiredArgsConstructor  
@Slf4j  
public class DemoRestController {  
  
  
    private final DemoService service;  
  
    @GetMapping("/")  
    public void send(){  
       log.info("Inside Controller");  
       service.send("This is the body.");  
    }  
}
```
4. **Service Layer**:
```java
package com.cbr.app.cbrdemo;  
  
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;  
import io.github.resilience4j.retry.annotation.Retry;  
import lombok.extern.slf4j.Slf4j;  
import org.springframework.http.MediaType;  
import org.springframework.stereotype.Service;  
import org.springframework.web.client.RestClient;  
  
@Service  
@Slf4j  
public class DemoService {  
  
  
    @CircuitBreaker(name = "cb")  
    @Retry(name = "demo-retry", fallbackMethod = "fallback")  
    public void send(String msg) {  
        log.info("Sending Data");  
        RestClient client = RestClient.builder().build();  
        client.post().uri("http://localhost:12000/abc")  
                .contentType(MediaType.TEXTPLAIN)  
                .body(msg)  
                .retrieve()  
                .onStatus(status -> status.is2xxSuccessful(), (req,res) -> System.out.println("Success")).  
                onStatus(status -> status.isError(), (req,res) -> System.out.println("Error")).toBodilessEntity();  
    }  
  
    public void fallback(String msg, Exception ex){  
        log.info("Inside Fallback for retry");  
        //send(msg);  
    }  
}
```
In this service, we are trying to send string message to another endpoint.

**4.1 @CircuitBreaker annotation:**

-   The Resilience4j default Aspect order is the following:  
    `Retry ( CircuitBreaker ( RateLimiter ( TimeLimiter ( Bulkhead ( Function ) ) ) ) )`
-   By Aspect order, we mean that if we apply both CircuitBreaker and Retry to the method then first CircuitBreaker will work and then Retry will work.
-   When our application starts, CircuitBreaker is in **“CLOSED”** state. That means CircuitBreak will be monitoring the request that we are making and it will be calculating how many got success and how many got failed.
-   We have **@Retry** also. So, if circuit breaker is in closed state and we do not get any status from the endpoint after we have send the message to the **localhost:12000/abc,** then multiple retry attempts will be made and each attempt also will be monitored by CircuitBreaker.
-   When majority of the requests failed(means not able to send any message because another endpoint is unavailable), CircuitBreaker moves to **“OPEN”** state. In open state, it will not even try to send message to another endpoint. It will straight away call the fallback method.
-   We have **@Retry** also. In “**OPEN**” state, there will not be any retries.
-   After sometime, it will allow sending few messages. If it is successfully delivered, then CircuitBreaker will move to “**HALFOPEN**” state. And messages keep getting delivered then it will again move to “CLOSED” state and also start monitoring if the request we are making are getting success or failed.
-   We have **@Retry** also. In “**HALFOPEN**”, few request will be retried and for few fallback method will be called directly.

The best thing of using both @Retry and @CircuitBreaker together is that if CircuitBreaker is just monitoring and doing nothing and any of request to localhost:12000/abc fails then it will be automatically retried. And if CircuitBreaker starts block the requests send method is making then directly the fallback method will be called and this time no retries will be there.

> With just Retry, we will eliminate any temporary failure of “localhost:12000” and with CircuitBreaker, we are answering long persisted failure of localhost:12000 by not sending every request every now and then when we know most of our messages are not getting received.

5. Application.properties file:
```shell
spring.application.name=cbr-demo  
server.port=9090  

management.endpoints.web.exposure.include=*  
management.health.circuitbreakers.enabled=true  
  
resilience4j.retry.configs.default.maxAttempts=4  
resilience4j.retry.configs.default.waitDuration=1000  
resilience4j.retry.configs.default.enableExponentialBackoff=true  
resilience4j.retry.configs.default.exponentialBackoffMultiplier=2  
  
resilience4j.circuitbreaker.instances.cb.registerHealthIndicator=true  
resilience4j.circuitbreaker.instances.cb.slidingWindowSize=10  
resilience4j.circuitbreaker.instances.cb.permittedNumberOfCallsInHalfOpenState=3  
resilience4j.circuitbreaker.instances.cb.slidingWindowType=TIMEBASED  
resilience4j.circuitbreaker.instances.cb.minimumNumberOfCalls=20  
resilience4j.circuitbreaker.instances.cb.waitDurationInOpenState=50s  
resilience4j.circuitbreaker.instances.cb.failureRateThreshold=50  
resilience4j.circuitbreaker.instances.cb.eventConsumerBufferSize=10  
```

6. Actuator provide [/actuator/circuitbreakers]
```shell
http://localhost:9090/actuator/circuitbreakers 
```
endpoint. We can see current circuit-breaker state.

![](https://miro.medium.com/v2/resize:fit:595/1*Eaa9LW32QycM9e8VxkQQEg.png)

-   In order to test whether “state” changes or not, we can make localhost:12000/abc up for some messages and then down for some messages we are sending out to this endpoint. It will work as expected.

7. **About fallback method:**

We can create multiple fallback methods but it should take same parameters as the method over which we have put Resilience4j annotations, plus one extra Exception parameter. We can create multiple fallback methods for each type of exceptions. We can use fallback methods to do something with the message whenever our message is not getting delivered. We can move this message to some MQ or topic and make some listener which would keep listening to the queue/topic and when that undelivered message is received by the listener then again it can try to send and the process continues.

https://github.com/mohit06/Resilience4jFaultTolerance