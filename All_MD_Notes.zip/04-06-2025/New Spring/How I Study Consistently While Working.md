# How I Study Consistently While Working a 9–5 Full-Time Job
**“Why are you still learning when you’re already earning?”**

Well… because jobs aren’t permanent. You’re just one layoff away from having an existential crisis on a Tuesday morning.

And if you’re not learning or growing, you’re falling behind — simple as that.

But you’re here, which means you’re different. You’re trying to study, grow, and manage your time better.  
**Good choice. 👏🏻👏🏻**

# 🎢 What My Life Looks Like

I do a lot — maybe too much at times. And if you try to do multiple things, burnout is inevitable.

For context, here is what I do:

-   🧑‍💼 9–6 full-time job (which honestly eats half my energy)
-   🧑‍💻 Freelance work (currently 2 clients)
-   ✍️ Writing technical articles for clients
-   📝 Writing posts like this one on Medium
-   🛠️ Building side projects—this I love to do
-   📚 Learning new tech (because FOMO is real and this is the important thing)
-   🧠 Solving DSA for future interviews

Yeah, it’s a lot. And I’ve been burnt out more times than I can count.

But I figured out how to make it sustainable.

You only need two things:  
→ **Discipline**  
→ **A realistic timetable**

# Build a timetable

Here is how my timetable looks:

![](https://miro.medium.com/v2/resize:fit:875/1*Fq0Gv1NJNwYpkuOpYCIGPg.png)
My Personal timetable.

I created this timetable last year in March, and honestly, it’s been one of the best decisions I’ve made in my life (you can check the date).

You would expect that I follow this timetable each and every day.

Lol, no.

We are humans and not robots. And I’m not a productivity ‘guru’ with a $200 Notion template.

Even though I don’t strictly follow this timetable every single day, just **having it** makes me accountable.

It **makes me feel guilty** (in a good way) when I scroll Instagram Reels instead of doing what’s necessary. It nudges me back on track.

There will be billions of contents on social media that will hook you, but don’t make yourself a slave of content.

Also, here’s an uncomfortable truth:

A lot of people create timetables just to feel productive — not to actually be productive.

> The main use of a timetable should be to **guide your actions**, not to **replace** them.

This gives you a **pseudo belief** that you are doing it, but actually you are NOT at all doing it.

If you spend hours making the perfect schedule and then never follow it, all you’ve done is lie to yourself in a fancy format.

Even if I don’t stick to my timetable 100%, **doing even 50% of what I planned is a win.**

> Progress > perfection. Always.

That’s 50% more intentional effort than I would’ve made without it.

# Cutting Out the Unwanted

Most people I know say they “don’t have enough time.”

Honestly, I just want to say,  
**“Sorry you only got 16 hours in a day.”**  
Because clearly everyone else got 28, right?

It’s just about how you use them.

> Time and tide wait for nobody. Especially not your excuses.

Let’s take a minimal, no-BS breakdown of a typical day:

-   9 to 6 job—9 hours
-   2 hours commute
-   2 hours for personal stuff (bath, food, brushing, scrolling while pretending to brush)
-   8 hours of sleep
-   ‍1 hour of chilling/resting or even scrolling Reels if you are addicted.

Still, you got 2 extra hours per day.

The problem isn’t time.  
The problem is what you’re doing with it.

When I started building a routine, I wasn’t adding an extra hour to my day — I was just cutting out the ones I was already wasting.

So I started cutting. Not people (lol), but things that weren’t serving me:

-   Random YouTube rabbit holes
-   Instagram Reels that took 45 minutes per day (Check your app usage and screen time)
-   Overthinking tasks instead of doing them (but this I can’t controll, I still overthink but I do control it)

This doesn’t mean I became a monk. I still chill, still scroll sometimes, still binge a show here and there.

Sometimes, I don’t even care about the timetable and act like it doesn’t exist. Once in a while, I become the laziest person alive — and honestly, that break gives me the energy to get back on track. Otherwise, I’d probably end up feeling paranoid and burnt out.

> **Cutting the noise is how you start hearing your own voice again.**

This is just my ideology — from a 23-year-old guy living alone, far away from his parents.

I know that once you are 30, have a family, maybe even a kid, a lot of the things I said above might not apply the same way.

But the point is:  
**Your situation might be different, but the principle stays the same.**

You can still find your rhythm.  
You can still take ownership of your time.  
You just have to **adapt the system to your life**, not the other way around.

The goal isn’t to follow my timetable.  
It is to build one that respects your reality — and still pushes you to grow.

Thanks for checking this out :)