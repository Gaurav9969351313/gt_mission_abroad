# How to Actually Use Modern Java Like a Pro 


🔒 This is a Medium member-only article. If you’re not a Medium member, you can read the full article for free on my blog: [How to Use Modern Java Like a Pro](https://www.javaguides.net/2025/04/how-to-use-modern-java-like-pro.html).

Java has been around since 1995, and yet, it’s still going strong. While many developers complain about Java being too verbose or outdated, the truth is — **Java has evolved**. If you’re still writing Java like it’s 2005, you’re missing out on the features that make **modern Java cleaner, smarter, and way more productive**.

![](https://miro.medium.com/v2/resize:fit:875/1*py6VY3MFkCmwUYkxt-DEXQ.png)

So, if you’re ready to stop writing boilerplate code and start coding like a **modern Java pro**, this article is your guide.

# Step 1: Use the Latest LTS Version

Before diving into features, make sure you’re using a modern Java version.

> ✅ Recommendation: Use **Java 17** or **Java 21** (both are Long-Term Support versions).

Why? Because these versions include:

-   Lambdas and Streams
-   `var` for local type inference
-   Records, Sealed Classes, Pattern Matching
-   Virtual Threads (from Java 21)
-   Better performance and garbage collection

# Step 2: Embrace the Power of `var`

Introduced in Java 10, the `var` keyword allows **local variable type inference**. It reduces boilerplate and makes code more readable when the type is obvious.

# Example:
```java
// Before  
Map<String, List<String>> map = new HashMap<>();  
  
// Modern Java  
var map = new HashMap<String, List<String>>();
```
It keeps your code **cleaner** and **less repetitive**, especially with generics.

# Step 3: Use Records for Immutable Data Classes

If you’re still writing `POJOs` with getters, setters, equals, hashCode, and toString — **stop**.

👉 It’s time to modernize — use **records** in Java 14+.

# Example:

❌ Before: Using Traditional POJO
```java
import java.util.List;  
  
public class Product {  
    private final String name;  
    private final double price;  
    private final List<String> tags;  
  
    public Product(String name, double price, List<String> tags) {  
        this.name = name;  
        this.price = price;  
        this.tags = tags;  
    }  
  
    public String getName() { return name; }  
    public double getPrice() { return price; }  
    public List<String> getTags() { return tags; }  
  
    @Override  
    public String toString() {  
        return "Product{name='%s', price=%.2f, tags=%s}".formatted(name, price, tags);  
    }  
  
    // equals() and hashCode() omitted for brevity...  
}
```
✅ After: Using `record` (Java 14+)
```java
// ✅ Cleaner immutable class using record  
public record Product(String name, double price, List<String> tags) {}
```

**This one-liner automatically generates:**

-   Constructor
-   Getters
-   equals()
-   hashCode()
-   toString()

**Using Records:**
```java
import java.util.List;  
  
public class Main {  
    public static void main(String[] args) {  
        Product product = new Product("Laptop", 75000.0, List.of("Electronics", "Computers"));  
  
        System.out.println("Product Name: " + product.name());  
        System.out.println("Price: ₹" + product.price());  
        System.out.println("Tags: " + product.tags());  
        System.out.println("toString(): " + product);  
    }  
}
```
And the best part? Records are **immutable** by default. Clean, concise, and ideal for data models, DTOs, etc.

### How to Use Java Records with Spring Boot

# Step 4: Write Declarative Code with Streams and Lambdas

If you’re still using `for` loops to filter and transform lists, you’re missing out on the expressive power of **Streams** and **Lambdas** (Java 8+).

# Before (Imperative):
```java
List<String> result = new ArrayList<>();  
for (String name : names) {  
    if (name.startsWith("A")) {  
        result.add(name.toUpperCase());  
    }  
}
```
# After (Modern Java):
```java
var result = names.stream()  
                  .filter(n -> n.startsWith("A"))  
                  .map(String::toUpperCase)  
                  .toList();
```

-   More readable
-   Easier to parallelize
-   Encourages **functional thinking**

Learn to master `map()`, `filter()`, `reduce()`, `collect()`, and you’ll write **cleaner logic with fewer bugs**.

# Step 5: Use Optional to Avoid NullPointerException

Instead of checking for `null` everywhere, use `Optional` (Java 8+) to express **optional values clearly**.

# Traditional:
```java
if (user != null && user.getEmail() != null) {  
    send(user.getEmail());  
}
```
# Modern:
```java
Optional.ofNullable(user)        
    .map(User::getEmail)        
    .ifPresent(this::send);
```
Optional makes the **presence or absence of a value explicit**, reducing null checks and improving readability.

> ⚠️ Avoid overusing Optional as method parameters or fields. Use it primarily for **return values**.

### Java Optional

# Step 6: Replace `if-else` Chains with Modern Alternatives

Nested `if-else` blocks are a sign your code needs **refactoring**.

# ✅ Alternatives:

-   Use `Map` for simple key-value logic
-   Use `switch` expressions (Java 14+)
-   Use polymorphism for behavior

# Modern `switch` example:
```java
String result = switch (status) {  
    case "NEW"    -> "Create Order";  
    case "PAID"   -> "Ship Order";  
    case "CANCEL" -> "Cancel Order";  
    default       -> "Unknown Status";  
};
```
Much cleaner than multiple `if-else` or classic `switch-case`.

# Step 7: Master Modern Spring Boot (If You’re Using Spring)

If you’re building web apps or APIs, you’re likely using **Spring Boot**. Make sure you’re using its **modern capabilities**:

-   ✅ Use **Spring Boot 3+** with Java 17+
-   ✅ Embrace **record-based DTOs**
-   ✅ Use `@RestController` + `@RequestMapping` wisely
-   ✅ Enable `lombok` where appropriate to reduce boilerplate
-   ✅ Use `@Component`, `@Service`, `@Repository` for clear layer separation
-   ✅ Use constructor injection (no field injection)
-   ✅ Profile-based configs with `application-dev.yml`, `application-prod.yml`

And don’t forget to explore:

-   **Spring Data JPA**
-   **Spring Security 6**
-   **Spring WebFlux** for reactive apps

# Step 8: Use Sealed Classes for Controlled Inheritance

Introduced in Java 17, **sealed classes** let you restrict which classes can extend a parent class. Perfect for domain models with controlled variations.

# Example:
```java
sealed interface Shape permits Circle, Rectangle {}  
  
final class Circle implements Shape {}  
  
final class Rectangle implements Shape {}
```

Great for **exhaustive switch statements** and better **type safety** in complex domain logic.


### Sealed Class vs Final Class in Java


# Step 9: Use Pattern Matching (Preview in Java 21)

Modern Java supports pattern matching for `instanceof` — and more is coming (like switch pattern matching).

# Example:
```java
if (obj instanceof String s) {  
    System.out.println("String length: " + s.length());  
}
```
Cleaner, type-safe, and avoids unnecessary casting.

# Step 10: Use the Right Tools Like a Pro

Mastering modern Java isn’t just about the language — it’s also about using **modern tools**:

-   ✅ **IntelliJ IDEA** (with live templates, refactoring tools)
-   ✅ **Lombok** (for concise POJOs)
-   ✅ **Maven / Gradle** (dependency and build management)
-   ✅ **JUnit 5 + Mockito** (modern testing frameworks)
-   ✅ **Docker + Spring Boot** (for cloud-native development)
-   ✅ **Java Records, Streams, and Optionals** — core of functional programming in Java

# Summary: How to Use Modern Java Like a Pro

### 10 Java One-Liners That Will Make You Look Like a Pro 🚀

