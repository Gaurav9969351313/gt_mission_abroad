# Spring Boot SnapAdmin — Database Admin Dashboard With Minimal Coding

# Overview

I have developed administration UI’s for my applications a few times in my career. These were specific utilities used by developers for viewing and managing test data in the database during development and performing some small administration tasks. The key point is that they were built with the applications database exposed through the entities used in the application. Another use for these tools was always production support, verifying database values, making updates as needed. These were extremely useful, saved loads of time but of course took up a fair amount of development cycles to implement.

I always wished there was an easy way to generate these types of utilities and have looked at a few tools free as well as paid, but never really found one that stuck. That is until I ran across [**SnapAdmin**](https://www.snapadmin.dev/).

SnapAdmin provides a customizable user interface to your database. The awesome part is it generates the UI and associated functionality from your JPA-annotated `@Entity` classes at runtime. So if you are building your Microservices in SpringBoot, it is definitely worth a look. It can save you a lot of development time while providing a capable UI for working with your backend database.

# Functionality

In this section we will look at the functionality exposed by SnapAdmin. Below is the front end as shown in the SnapAdmin documentation.

![](https://miro.medium.com/v2/resize:fit:875/0*NwX8p5TFGdphhxZF.png)
Screenshot Courtesy of https://www.snapadmin.dev/

In the screenshot above we see the the UI that is provided by SnapAdmin. This is fully functional interface to the backend database offering querying, insert, update and delete options in the Dashboard.. This screenshot also shows the filtering capability which is added through a provided custom annotation. These annotations can also be used for modifying the display format of the data within your dashboard.

Users can run ad-hoc queries against the database as is provided in many database tools through the SQL Console function.

Finally, one can view the audit logs for your database to view operations that were run by all users.

# Integration

Code for the sample application we use can be found [**here**](https://github.com/brianeno/springboot-snapadmin-sample).

Our sample application is a standard JPA enabled application with simple Spring Security authentication enabled. The user and password are configured in our application.yml (admin/passw@rd). Our application has 4 JPA entities. There is also one BaseEntity that provides a create and modified date and an enum class for Product Categories.

![](https://miro.medium.com/v2/resize:fit:675/1*hAbgot1dqCltkEw0Nywl2Q.png)

Now let’s look at how to integrate this into our application. It is straightforward, we are assuming that you are working with an existing JPA enabled SpringBoot application ane if you are not using the code provided from my Github repository.

First we need to include the required dependency in our maven pom.xml.
```xml
<dependency>  
    <groupId>tech.ailef</groupId>  
    <artifactId>snap-admin</artifactId>  
    <version>0.2.0</version>  
</dependency>
```

Version 0.2.0 is the latest as of time of writing. Once we have the dependencies included, we need to configure a few properties. These are added to our application.yml file.
```yml
snapadmin:  
  enabled: true  
  baseUrl: admin  
  modelsPackage: com.brianeno.sample.entity
```
Note the modelPackage is the package to be scanned for JPA entities, if you have these located in multiple packages then you can provide a comma separated list.

The last requirement is to annotate our application class with **@ImportAutoConfiguration(SnapAdminAutoConfiguration.class)**.
```java
@EnableCaching  
@SpringBootApplication  
@ImportAutoConfiguration(SnapAdminAutoConfiguration.class)  
public class DemoApplication {  
  
 public static void main(String[] args) {  
  SpringApplication.run(DemoApplication.class, args);  
 }  
  
}
```

For demonstration purposes we have modified a few columns of our entities with SnapAdmin custom annotations. The first is @Filtertable. This will add the Filter panel to our Dashboard for any entity, in our case we do this on the Project entity.
```java
  @Filterable  
  @Column(nullable = false)  
  private LocalDateTime startDate;  
    
  @Filterable  
  @Column(nullable = false)  
  private LocalDateTime endDate;
```
The second annotation is @DisplayFormat which we add to our Product class to properly format the price.
```java
    @DisplayFormat(format = "$%.2f")  
    @Min(0)  
    @Column(name = "price", columnDefinition = "decimal (10,2)")  
    private Double price;
```
Once this is done you can start the application and access the URL [http://localhost:8080/admin](http://localhost:8080/admin). After logging in, we are presented with a nice Dashboard UI of our database.

![](https://miro.medium.com/v2/resize:fit:875/1*xeLKQE9ceCuGOksA10RpiQ.png)

Notice the 4 JPA entities are presented. At the moment if we try to access SQL Console we will be presented with a blank page as the database is still empty.

Let’s add a new product.

![](https://miro.medium.com/v2/resize:fit:875/1*2By4CCq5VxxR0utP6VQr4A.png)

The category is a drop down with the values from our ProductCategory enum provided automatically. The other two fields our presented as standard text fields. The price field will only allow two decimal places to be entered as specified to prevent entering an invalid value. Pressing Create and we have a new record in our Project table.

![](https://miro.medium.com/v2/resize:fit:875/1*zJ8uAT3mEz7l2cuN0q1Yyg.png)

The new record is displayed and we can sort the fields using the ascending/descending icon in each column heading. We can also edit and delete the existing record or add a new one by pressing the + button.

Extremely useful is the Search bar which can be used to quickly find specific records by searching the available columns.

### Export

Also handy is the ability to easily export the values from a table by selecting the export icon.

![](https://miro.medium.com/v2/resize:fit:130/1*lKuxkJpYxKIagZggNXofTw.png)

You are then presented with an export screen and can choose columns as well as designate if you want formatted or raw values. The format can be set to CSV, XML or JSON.

![](https://miro.medium.com/v2/resize:fit:875/1*-X0b-VREn87gthDsJtH77w.png)

On the lefthand navigation menu we can select logs and view audit log information and view the associated record for that database interaction.

![](https://miro.medium.com/v2/resize:fit:875/1*3XOzUzCXzxavbNxqHVRkjg.png)

We can also query using standard SQL by selecting the SQL Console menu item. This provides low level access to the database, it can be disabled if you like through a application property (snapadmin.sqlConsoleEnabled=false) if you do not want to show the SQL console.

![](https://miro.medium.com/v2/resize:fit:875/1*ekyASAhthmOH93tlrjhO-Q.png)

Queries can be given names and retrieved by that name for reuse.

# Summary

We have had a detailed look at a great tool for easily integrating an administration dashboard into your SpringBoot applications. With the addition of one dependency, three properties and an annotation added to our application class we can have a fully functional dashboard for working with our applications backend.

With the latest version, protection with Spring Security is straight forward and provides the needed authentication/authorization control for your specific needs.

As always, the source for the article can be found in my Github repository [**here**](https://github.com/brianeno/springboot-snapadmin-sample).

Enjoy the journey.
