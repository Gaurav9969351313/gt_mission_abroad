# Spring Boot Retry or Recover Functionality

You are working on a project. You have a requirement to send some data in a post request to a third party api. You have written the code and everything is working fine. Someday, the third party endpoint is down and you have peak number of messages that you have send out to them but they are simply getting dropped. Business wants an immediate solution to this problem. They do not want to loose any data.

In this article, we are going to solve this problem.

> Please share, clap and follow for more information. Put some comments and share your view on this article.

Lets start. Please forgive me for bad selection of variable names.

1.  This is how my pom.xml looks like:
```xml
<?xml version="1.0" encoding="UTF-8"?>  
<project xmlns="http://maven.apache.org/POM/4.0.0"  
 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  
 xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">  
 <modelVersion>4.0.0</modelVersion>  
 <parent>  
  <groupId>org.springframework.boot</groupId>  
  <artifactId>spring-boot-starter-parent</artifactId>  
  <version>3.2.4</version>  
  <relativePath /> <!-- lookup parent from repository -->  
 </parent>  
 <groupId>com.failed-retry-demo.app</groupId>  
 <artifactId>FailedRetryDemo</artifactId>  
 <version>0.0.1-SNAPSHOT</version>  
 <name>FailedRetryDemo</name>  
 <description>Failed Retry Demo Application</description>  
 <properties>  
  <java.version>17</java.version>  
 </properties>  
 <dependencies>  
  <dependency>  
   <groupId>org.springframework.boot</groupId>  
   <artifactId>spring-boot-starter-data-jpa</artifactId>  
  </dependency>  
  <dependency>  
   <groupId>org.springframework.boot</groupId>  
   <artifactId>spring-boot-starter-web</artifactId>  
  </dependency>  
  <dependency>  
   <groupId>org.springframework.retry</groupId>  
   <artifactId>spring-retry</artifactId>  
  </dependency>  
  <dependency>  
   <groupId>org.springframework</groupId>  
   <artifactId>spring-aspects</artifactId>  
  </dependency>  
  <dependency>  
   <groupId>com.h2database</groupId>  
   <artifactId>h2</artifactId>  
   <scope>runtime</scope>  
  </dependency>  
  <dependency>  
   <groupId>org.projectlombok</groupId>  
   <artifactId>lombok</artifactId>  
   <optional>true</optional>  
  </dependency>  
  <dependency>  
   <groupId>org.springframework.boot</groupId>  
   <artifactId>spring-boot-starter-test</artifactId>  
   <scope>test</scope>  
  </dependency>  
 </dependencies>  
  
 <build>  
  <plugins>  
   <plugin>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-maven-plugin</artifactId>  
    <configuration>  
     <excludes>  
      <exclude>  
       <groupId>org.projectlombok</groupId>  
       <artifactId>lombok</artifactId>  
      </exclude>  
     </excludes>  
    </configuration>  
   </plugin>  
  </plugins>  
 </build>  
  
</project>
```
2. **Main Class** : We need to use @EnableRetry and @EnableScheduling on top of our configuration as below:
```java
package com.failedretrydemo.app;  
  
import org.springframework.boot.SpringApplication;  
import org.springframework.boot.autoconfigure.SpringBootApplication;  
import org.springframework.retry.annotation.EnableRetry;  
import org.springframework.scheduling.annotation.EnableScheduling;  
  
@SpringBootApplication  
@EnableRetry  
@EnableScheduling  
public class FailedRetryDemoApplication {  
  
 public static void main(String[] args) {  
  SpringApplication.run(FailedRetryDemoApplication.class, args);  
 }  
  
}
```
3. **Article DTO:** This is how article class looks like:
```java
package com.failedretrydemo.app.dto;  
  
import lombok.AllArgsConstructor;  
import lombok.Data;  
import lombok.NoArgsConstructor;  
import lombok.ToString;  
  
@Data  
@AllArgsConstructor  
@ToString  
@NoArgsConstructor  
public class Article {  
  
 int id;  
 String name;  
  
}
```
4. **Article Entity:** I have created article entity as below:
```java
package com.failedretrydemo.app.entity;  
  
import jakarta.persistence.Entity;  
import jakarta.persistence.Id;  
import lombok.AllArgsConstructor;  
import lombok.Data;  
import lombok.NoArgsConstructor;  
import lombok.ToString;  
  
@Entity  
@Data  
@AllArgsConstructor  
@ToString  
@NoArgsConstructor  
public class ArticleEntity {  
  
 @Id  
 int id;  
 String name;  
}
```
ArticleEntity and Article seems same. I have created two classes because Article dto will be used if I want to send/receive data to/from other API over the network. And ArticleEntity will be used to save data into database or fetch data from database.

5. **ArticleRepository** is created as below:
```java
package com.failedretrydemo.app.repos;  
  
import java.util.Optional;  
import org.springframework.data.jpa.repository.JpaRepository;  
import com.failedretrydemo.app.entity.ArticleEntity;  
  
public interface ArticleRepository extends JpaRepository<ArticleEntity,Integer>{  
  
 Optional<ArticleEntity> findByName(String name);  
  
}
```
6. **RestController** code below**:**
```java
package com.failedretrydemo.app.controller;  
  
import org.springframework.web.bind.annotation.PostMapping;  
import org.springframework.web.bind.annotation.RequestBody;  
import org.springframework.web.bind.annotation.RestController;  
  
import com.failedretrydemo.app.dto.Article;  
import com.failedretrydemo.app.service.DemoService;  
  
import lombok.AllArgsConstructor;  
  
@RestController  
@AllArgsConstructor  
public class DemoRestController {  
   
 private final DemoService dservice;  
 private final Integer PORT = 11000;   
  
 @PostMapping("/create-post")  
 public void sendToApi(@RequestBody Article articleDto) throws Exception {  
  dservice.sendToApi(articleDto,PORT);  
 }  
   
}
```
7. **Service** created as below:
```java
package com.failedretrydemo.app.service;  
  
import java.time.LocalDateTime;  
  
import org.springframework.data.domain.Page;  
import org.springframework.data.domain.PageRequest;  
import org.springframework.retry.annotation.Backoff;  
import org.springframework.retry.annotation.Recover;  
import org.springframework.retry.annotation.Retryable;  
import org.springframework.scheduling.annotation.Scheduled;  
import org.springframework.stereotype.Service;  
import org.springframework.web.client.RestClient;  
  
import com.failedretrydemo.app.dto.Article;  
import com.failedretrydemo.app.entity.ArticleEntity;  
import com.failedretrydemo.app.repos.ArticleRepository;  
  
import lombok.RequiredArgsConstructor;  
  
@Service  
@RequiredArgsConstructor  
public class DemoService {  
  
 private final RestClient.Builder restClient = RestClient.builder();  
 private final ArticleRepository repo;  
  
 @Retryable(maxAttempts = 5, backoff = @Backoff(delay = (3000),multiplier = 2, maxDelay = 10000), recover = "storeInDb")    
 public void sendToApi(Article articleDto, Integer PORT) {  
  System.out.println("Retry Attempt at "+" "+LocalDateTime.now());  
  restClient  
  .build()  
  .post()  
  .uri("http://localhost:"+PORT+"/create-article")  
  .body(articleDto)  
  .retrieve()  
  .onStatus(status -> status.isError(), (request, response)->{  
   System.out.println("Error occured!!!");  
  })  
  .onStatus(status -> !status.isError(), (req,res)->{  
   repo.deleteById(articleDto.getId());  
   System.out.println("SUCCESS");  
  })  
  .toBodilessEntity();  
  
 }  
   
 @Recover  
 public void storeInDb(Article articleDto, Integer PORT) {  
  System.out.println("Saving Failed Data into DB");  
  ArticleEntity entity = new ArticleEntity(articleDto.getId(),articleDto.getName());  
  if(repo.findByName(articleDto.getName()).isEmpty()) {  
      repo.save(entity);  
  }  
  System.out.println("RECOVERD "+articleDto.toString());  
 }  
   
 @Scheduled(cron = "0 0 * * * ?")  
 public void sendFailedDataToApi() {  
  send(0,5000);  
 }  
  
 public void send(int pageNo, int pageSize) {  
  Page<ArticleEntity> page = repo.findAll(PageRequest.of(pageNo, pageSize));  
  while(page.getSize() > 0) {  
   page.stream().map(ele -> new Article(ele.getId(),ele.getName())).forEach(ele -> {  
     this.sendToApi(ele, 11000);  
   });  
   page = repo.findAll(PageRequest.of(pageNo+1, pageSize));  
  }  
 }  
  
}
```
In the service, I have created 4 methods. Lets go through them one by one:

-   **sendToApi** : Annotated with @Retryable, the method will be called 5 times when we do not get any response from third party endpoint. BackOff is also applied so it will wait for some time in between calling the function 5 times. If it is failed to get any response from third party endpoint, it will call method with @Recover annotation.
-   **storeInDb:** The @Recover method takes same parameter as sendToApi method. In this method , we are saving the failed delivery data into db which was failed to be delivered.
-   **sendFailedDataToApi and send:** This function interally calls the function that will take the data from our table and try to send to api again and again. If we get success status then **sendToApi** will delete the record from table and if we get error response from third party then we will simply print “Error Occured”. If there is network outage then our Retry/Recover functionality will take over.

8. Output:

-   Post Request:

![](https://miro.medium.com/v2/resize:fit:765/1*53cvlmSOEa-fvsux4DoiFg.png)

-   DB Table storing failed data:

![](https://miro.medium.com/v2/resize:fit:384/1*e6UBxBj2z4siSXrcE9XA6A.png)

-   Logs:

![](https://miro.medium.com/v2/resize:fit:683/1*2PPaKG4tBvD6VFDfZQb5A.png)

After one hour data was sent out when the third party API was started and It was deleted from our table. I intentionally was not runnig third party endpoint to show Retry functionality.

![](https://miro.medium.com/v2/resize:fit:306/1*iDh8bWNpinBxKc65gg9Ng.png)

Third party API is nothing but a CRUD API that can manage Article. It is very simple and basic rest Api.

In this article, we saw @Retry/@Recover functionality. Thanks for going through the article.