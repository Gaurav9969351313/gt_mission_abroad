### Java Builder Design Pattern

![](https://miro.medium.com/v2/resize:fit:800/0*YmWW6ixy5KiVJu8K)
Source: Refactoring Guru

### What is the Builder Design Pattern?

The **Builder Design Pattern** is a **creational pattern** that **allows for the step-by-step construction of complex objects**. Unlike other creational patterns, the Builder pattern does not require that all products be built in a single,. monolithic constructor. Instead, it provides a way to construct a complex object by specifying its type and content, step by step.

### NOTE:

1.  If we don't use Builder Design pattern, we might end up working with a big constructor or multiple number of tiny constructor or multiple optional parameters.
2.  Builder design pattern helps to solve problems that are stated in point 1.

### Components of the Builder Design Pattern:

![](https://miro.medium.com/v2/resize:fit:575/0*VKhNVV1WFVLXYeq)
Source: Refactoring Guru

### Purpose of Each Component:

-   **Builder**: Provides an abstract interface for creating parts of a Product object.
-   **ConcreteBuilder**: Implements the Builder interface to construct and assemble parts of the product.
-   **Product**: Represents the complex object that is being built.
-   **Director**: Directs the construction process using the Builder interface.

### Focus on Dynamic Behavior and Reusability

The Builder Design Pattern enhances dynamic behavior and reusability by:

-   Allowing **different representations** of the object.
-   Enabling the **reuse of the same construction process** for different products.
-   Facilitating the **creation of complex objects with varying configurations**.

### When and Where to Use the Builder Design Pattern

The Builder Design Pattern is particularly useful when:

-   The **construction process of an object is complex**.
-   The **object needs to be created in multiple steps**.
-   The **object can have different representations**.
-   You **want to avoid a “telescoping constructor” anti-pattern**.

### Real-Life Use Cases

### Examples:

-   **StringBuilder in Java**: Used to construct a string incrementally.
-   **Document Generation**: Creating complex documents with various sections.
-   **UI Components**: Building complex UI components with various configurations.

### Best Practices for Implementing the Builder Design Pattern

-   **Immutability**: Ensure that the built object is immutable.
-   **Fluent Interface**: Use a fluent interface to make the builder easy to use.
-   **Validation**: Include validation logic within the builder to ensure the object is in a valid state.
-   **Separation of Concerns**: Keep the builder and the product separate to maintain a clear separation of concerns.

### Without Builder Design Pattern
```java
public class Car {  
    private String engine;  
    private String body;  
    private int seats;  
  
public Car(String engine, String body, int seats) {  
        this.engine = engine;  
        this.body = body;  
        this.seats = seats;  
    }  
    // Getters and toString() method  
}  
// Usage  
Car car = new Car("V8", "SUV", 5);
```

### Disadvantages:

-   Hard to read and maintain.
-   Difficult to add new parameters.
-   Prone to errors with many parameters.

### With Builder Design Pattern
```java
public class Car {  
    // Immutability: All fields are final to ensure the object is immutable  
    private final String engine;  
    private final String body;  
    private final int seats;  
  
    // Private constructor to enforce object creation through the builder  
    private Car(CarBuilder builder) {  
        this.engine = builder.engine;  
        this.body = builder.body;  
        this.seats = builder.seats;  
    }  
  
    // Static nested Builder class  
    public static class CarBuilder {  
        private String engine;  
        private String body;  
        private int seats;  
  
        // Fluent Interface: Each setter method returns the builder itself  
        public CarBuilder setEngine(String engine) {  
            // Validation: Ensure the engine is not null or empty  
            if (engine == null || engine.isEmpty()) {  
                throw new IllegalArgumentException("Engine cannot be null or empty");  
            }  
            this.engine = engine;  
            return this;  
        }  
  
        public CarBuilder setBody(String body) {  
            // Validation: Ensure the body is not null or empty  
            if (body == null || body.isEmpty()) {  
                throw new IllegalArgumentException("Body cannot be null or empty");  
            }  
            this.body = body;  
            return this;  
        }  
  
        public CarBuilder setSeats(int seats) {  
            // Validation: Ensure the number of seats is greater than zero  
            if (seats <= 0) {  
                throw new IllegalArgumentException("Seats must be greater than zero");  
            }  
            this.seats = seats;  
            return this;  
        }  
  
        // Build method to create the Car object  
        public Car build() {  
            return new Car(this);  
        }  
    }  
  
    // Getters only, no setters to maintain immutability  
    public String getEngine() {  
        return engine;  
    }  
  
    public String getBody() {  
        return body;  
    }  
  
    public int getSeats() {  
        return seats;  
    }  

}  
  
// Usage  
public class Main {  
    public static void main(String[] args) {  
        // Using the builder to create a Car object  
        Car car = new Car.CarBuilder()  
                .setEngine("V8")  
                .setBody("SUV")  
                .setSeats(5)  
                .build();  
  
        System.out.println(car);  
    }  
}
```

### Explanation of Best Practices:

1.  **Immutability:**

-   All fields in the `Car` class are declared as `final` to ensure that once the object is created, its state cannot be changed.

2. **Fluent Interface:**

-   Each setter method in the `CarBuilder` class returns `this`, allowing for method chaining and making the builder easy to use.

3. **Validation:**

-   Each setter method includes validation logic to ensure that the provided values are valid. For example, the `setEngine` method checks if the engine string is not null or empty.

4. **Separation of Concerns:**

-   The `Car` class and the `CarBuilder` class are kept separate. The `Car` class is responsible for representing the product, while the `CarBuilder` class handles the construction process.

### Advantages:

-   Improved readability and maintainability.
-   Easy to add new parameters.
-   Reduced risk of errors.

### Pros and Cons of Using the Builder Design Pattern

### Pros

1.  **Improved Readability and Maintainability:**

-   The Builder pattern makes the code more readable and maintainable by clearly separating the construction process from the representation of the object.

2. **Avoids Telescoping Constructor Anti-Pattern:**

-   It helps avoid the telescoping constructor anti-pattern, where constructors with many parameters become hard to read and use.

3. **Flexibility in Object Construction:**

-   It provides flexibility in constructing complex objects by allowing optional parameters and different configurations.

4. **Immutability:**

-   The pattern promotes immutability by ensuring that the constructed object is immutable once built.

5. **Fluent Interface:**

-   The fluent interface provided by the Builder pattern makes the code more intuitive and easier to use.

6. **Validation:**

-   It allows for validation of parameters before constructing the object, ensuring that the object is always in a valid state.

7. **Reusability:**

-   The same Builder can be reused to create different representations of the object, enhancing reusability.

### Cons

1.  **Increased Complexity:**

-   The Builder pattern can introduce additional complexity to the codebase, especially for simple objects where a builder might be overkill.

2. **More Boilerplate Code:**

-   It can lead to more boilerplate code, as you need to create separate Builder classes and methods for each parameter.

3. **Learning Curve:**

-   There might be a learning curve for developers who are not familiar with the pattern, making it harder to understand and implement initially.

4. **Overhead for Simple Objects:**

-   For simple objects with only a few parameters, using the Builder pattern might be unnecessary and add unnecessary overhead.

5. **Potential for Misuse:**

-   If not used correctly, the Builder pattern can be misused, leading to code that is harder to read and maintain.

Overall, the Builder Design Pattern is a powerful tool for constructing complex objects in a flexible and maintainable way. However, it’s important to weigh the pros and cons and consider whether it’s the right fit for your specific use case

### Conclusion

The Builder Design Pattern is a powerful tool for constructing complex objects in a step-by-step manner. By following best practices and understanding its components, you can create flexible and maintainable code that is easy to read and extend.

