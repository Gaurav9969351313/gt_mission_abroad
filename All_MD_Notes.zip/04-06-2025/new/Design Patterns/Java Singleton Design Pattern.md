### Singleton Design Pattern: A Comprehensive Guide 

### What is the Singleton Design Pattern?

The Singleton Design Pattern is a creational design pattern that **ensures a class has only one instance and provides a global point of access to that instance.** This pattern is particularly useful when exactly one object is needed to coordinate actions across the system.

![](https://miro.medium.com/v2/resize:fit:538/0*w7vGPrRewl1PM7Tl)
Source: Refactoring Guru

Key characteristics of the Singleton pattern include:

-   **Single Instance**: Only one instance of the class is created.
-   **Global Access**: The single instance can be accessed globally.
-   **Lazy Initialization**: The instance is created only when required (if needed).

### Where Can You Use the Singleton Design Pattern?

### Real-World Scenarios

1.  **Configuration Management**:

-   Centralising configuration properties to avoid multiple instances managing the same data.
-   Example: A properties file loader.

1.  **Logging**:

-   Ensuring a single log file is used across the application.
-   Example: Logger classes like `java.util.logging.Logger`.

**2. Database Connections**:

-   Managing a single point of access to database connections.
-   Example: Database connection pools.

**3. Caching**:

-   Implementing caching mechanisms to reduce redundant operations.
-   Example: An in-memory cache like Redis.

**4. Thread Pools**:

-   Ensuring only one thread pool is active.

**5. Resource Management**:

-   Managing shared resources like network sockets or printers.

### When to Use and Avoid Singleton Design Pattern

### When to Use

-   Centralised control is needed for resource management.
-   Frequent creation and destruction of instances is expensive.
-   A single instance ensures consistency (e.g. global configuration).

### When to Avoid

**Reflection Breaking Singleton**:

-   Reflection can bypass private constructors, creating multiple instances.
-   To prevent this, throw an exception if the constructor is invoked more than once:
```java
private Singleton() {       
  if (instance != null) {           
    throw new IllegalStateException("Instance already created");       
  }   
}
```
**Serialization Breaking Singleton**:

-   During deserialization, a new instance can be created.
-   To fix this, implement the `readResolve` method in your singleton class.
-   The `readResolve` method is a mechanism provided by Java to ensure that during deserialization, the singleton property of a class is preserved. Without this method, deserialization could lead to the creation of a new instance of the Singleton class, breaking its contract of having only one instance.

### How `readResolve` Works

The `readResolve` method is part of Java's serialization mechanism. When an object is deserialized, if the class implements the `readResolve` method, this method is invoked to determine the instance that should replace the deserialized object.

private Object readResolve() throws ObjectStreamException {       
  return instance;   
}

**Testing and Dependency Injection**:

-   Singletons can make unit testing difficult due to their global state.
-   **Use Dependency Injection to avoid tightly coupling code** to the Singleton.

**Distributed Systems**:

-   Singletons are not ideal for distributed systems as they can lead to multiple instances in a cluster.
-   Consider **distributed locking or other patterns**.

### Distributed Locking and Dependency Injection

### Distributed Locking

Distributed locking ensures that in a distributed system, only one instance of the Singleton is active at a time across all nodes. Popular tools for implementing distributed locking include:

1.  **Redis**:

-   Using `SETNX` (set if not exists) and an expiration time to create a lock.
```java
if (redis.setnx("lockkey", "value") == 1) {   
  // Acquired lock, proceed with Singleton logic   
}
```
**2. ZooKeeper**:

-   Leverages ephemeral nodes to ensure only one client holds the lock.

### Dependency Injection (DI)

**Description**:

-   Instead of hard-coding Singleton instances, provide them as dependencies to classes that need them.

**Implementation**:
```java
public class Service {       
  private final Singleton singleton;   
       
  public Service(Singleton singleton) {           
    this.singleton = singleton;       
  }   
}  

Singleton singleton = Singleton.getInstance();   
Service service = new Service(singleton);
```
**When to Use**:

-   When you need to decouple classes for better testability and maintainability.

### How to Implement Singleton in Java

### Basic Implementation
```java
public class BasicSingleton {  
    private static BasicSingleton instance;  
  
     private BasicSingleton() {  
        // private constructor to restrict instantiation  
     }  
  
     public static BasicSingleton getInstance() {  
        if (instance == null) {  
            instance = new BasicSingleton();  
        }  
        return instance;  
    }  
}
```
### Thread-Safe Implementation
```java
public class ThreadSafeSingleton {  
    private static ThreadSafeSingleton instance;  
  
    private ThreadSafeSingleton() {}  
  
    public static synchronized ThreadSafeSingleton getInstance() {  
        if (instance == null) {  
            instance = new ThreadSafeSingleton();  
        }  
        return instance;  
    }  
}
```
### Double-Checked Locking
```java
public class DoubleCheckedSingleton {  
    private static volatile DoubleCheckedSingleton instance;  
  
    private DoubleCheckedSingleton() {}  
  
    public static DoubleCheckedSingleton getInstance() {  
        if (instance == null) { // FIRST LOCK  
            synchronized (DoubleCheckedSingleton.class) {  
                if (instance == null) { // SECOND LOCK  
                    instance = new DoubleCheckedSingleton();  
                }  
            }  
        }  
        return instance;  
    }  
}
```
> **Key Points:**
> 
> **Volatile**: The `volatile` keyword ensures that the instance is always read from the main memory and **prevents thread caching issues**.
> 
> **First Check**: The first check avoids locking if the instance is already initialized, improving performance in multi-threaded scenarios.
> 
> **Second Check**: The second check ensures that only one thread initializes the resource, even if multiple threads enter the synchronized block simultaneously.
> 
> This pattern is commonly used in Singleton design to ensure thread safety while avoiding the performance cost of synchronization once the resource is initialized.

### Enum-Based Singleton
```java
public enum EnumSingleton {  
    INSTANCE;  
  
public void performAction() {  
        // action implementation  
    }  
}
```
### Which Implementation to Use and When

1.  **Basic Singleton**:

-   Use in simple applications where thread safety is not a concern.

**2. Thread-Safe Singleton**:

-   Use in multi-threaded environments to ensure only one instance is created.
-   Drawback: Synchronized methods can be slow.

**3. Double-Checked Locking**:

-   Optimal for performance in multi-threaded applications.
-   Ensures thread safety while avoiding the overhead of synchronizing every call.

**4. Enum-Based Singleton**:

-   Recommended for most use cases due to simplicity, thread safety, and protection from reflection and serialization issues.
-   Use when you need a straightforward and robust Singleton implementation.

### Class vs Enum for Singleton

### Class-Based Approach

**When to Use**:

-   Need fine-grained control over instantiation.
-   More flexibility for extensions or testing.

**When Not to Use**:

-   Increased risk of multiple instances if not implemented correctly.

### Enum-Based Approach

**When to Use**:

-   Simplifies implementation.
-   Ensures thread safety and protection from reflection/serialization.

**When Not to Use**:

-   Limited extensibility.

### Ensuring Thread Safety

-   Use **synchronized methods** for instance creation.
-   **Employ double-checked locking with** `**volatile**` **keyword.**
-   Enum-based singletons are inherently thread-safe.

### Things to Keep in Mind

-   **Ensure the constructor is private to prevent external instantiation**.
-   Consider thread safety for multi-threaded applications.
-   **Use lazy initialization only when necessary to optimise resource usage**.
-   Avoid reflection and serialization breaking the Singleton property by implementing the above safeguards.

### Pros and Cons

### Pros

-   Ensures a single instance.
-   Provides a global point of access.
-   Reduces memory usage in resource-heavy applications.

### Cons

-   Can lead to tightly coupled code.
-   Difficult to test and mock.
-   May introduce performance bottlenecks.

### Final Working Code with Class-Based Approach
```java
public class SingletonExample {  
    private static volatile SingletonExample instance;  
  
    private SingletonExample() {}  
    public static SingletonExample getInstance() {  
        if (instance == null) {  
            synchronized (SingletonExample.class) {  
                if (instance == null) {  
                    instance = new SingletonExample();  
                }  
            }  
        }  
        return instance;  
    }  
    public void showMessage() {  
        System.out.println("Singleton Instance Invoked!");  
    }  
    public static void main(String[] args) {  
        SingletonExample singleton = SingletonExample.getInstance();  
        singleton.showMessage();  
    }  
}
```
### Final Working Code with Enum-Based Approach
```java
public enum SingletonEnum {  
    INSTANCE;  
  
    // Example of a method that can be invoked on the singleton instance  
    public void showMessage() {  
        System.out.println("Singleton Instance Invoked via Enum!");  
    }  
}  
  
class EnumSingletonDemo {  
    public static void main(String[] args) {  
        // Accessing the Singleton instance  
        SingletonEnum singleton = SingletonEnum.INSTANCE;  
  
        // Calling the method on the singleton instance  
        singleton.showMessage();  
    }  
}
```