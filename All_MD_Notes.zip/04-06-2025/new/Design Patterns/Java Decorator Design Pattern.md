### Java Decorator Design Pattern

### Introduction

In software development, the **Decorator Design Pattern** is a structural pattern that allows us to dynamically add functionalities to objects without altering their code. Unlike other design patterns, the decorator pattern provides a flexible and scalable way to enhance an object’s behavior at runtime.

In this article, we will explore the **what, why, when, and how** of the decorator pattern with real-life use cases and code examples.

![](https://miro.medium.com/v2/resize:fit:800/0*fyNys6JxLP98KEeD)
Source: Refactoring Guru

### What is the Decorator Design Pattern?

The **Decorator Design Pattern** enables behavior extension by wrapping objects inside special decorator classes. These decorators modify or extend the object’s functionality without modifying the original class.

![](https://miro.medium.com/v2/resize:fit:600/0*u1DNuJAAI9AjH7T)
Source: Refactoring Guru

### How is it Different from Other Patterns?

-   Unlike **inheritance**, which extends functionality at compile-time, decorators allow modifications at runtime.
-   Unlike **the Strategy pattern**, which replaces entire behaviors, the decorator enhances existing behavior incrementally.
-   Unlike **the Proxy pattern**, which controls access to an object, decorators modify the behavior of the object itself.

### When and Where to Use the Decorator Pattern?

### When to Use?

Use the **Decorator Pattern** when:

-   You need to **extend functionalities dynamically** without modifying the base class.
-   You want to **avoid subclass explosion** caused by multiple variations of a class.
-   You need a **flexible and reusable** way to modify object behavior.

### Where to Use?

-   GUI components (e.g., adding scrollbars, borders, shadows to UI elements).
-   Logging and monitoring (e.g., adding logging functionality to a service without modifying it).
-   Security (e.g., adding encryption/decryption to data streams).
-   Data transformation (e.g., compressing or encrypting files dynamically).

### Why Use the Decorator Pattern?

-   **Adheres to Open-Closed Principle**: Enhancements are added without modifying the existing code.
-   **Avoids Complex Inheritance Trees**: Prevents the need for multiple subclasses.
-   **Runtime Flexibility**: Behaviors can be added or removed dynamically.
-   **Enhances Maintainability**: Code remains cleaner and more modular.

### Real-Life Use Cases

### 1. File I/O in Java

Java’s I/O system uses decorators to add functionalities like buffering, compression, and encryption:

InputStream fileStream = new FileInputStream("data.txt");  
InputStream bufferedStream = new BufferedInputStream(fileStream);  
InputStream compressedStream = new GZIPInputStream(bufferedStream);

### 2. Adding Extra Features to a Coffee Order System

Imagine an application where users can add extra toppings to their coffee dynamically.

### Without Using the Decorator Pattern (Problem Statement)

Let’s implement a coffee ordering system without the **Decorator Pattern**.
```java
class Coffee {  
    public int cost() {  
        return 50; // Base price  
    }  
}  
  
class CoffeeWithMilk extends Coffee {  
    @Override  
    public int cost() {  
        return super.cost() + 20;  
    }  
}  
class CoffeeWithSugar extends Coffee {  
    @Override  
    public int cost() {  
        return super.cost() + 10;  
    }  
}  
class CoffeeWithMilkAndSugar extends CoffeeWithMilk {  
    @Override  
    public int cost() {  
        return super.cost() + 10;  
    }  
}
```
### Disadvantages of this Approach

**Class Explosion**: Every combination requires a new subclass.  
**Rigid Design**: Adding new toppings requires modifying existing classes. **Code Duplication**: Repeated logic in multiple classes.

### Implementing the Decorator Pattern (Best Practice Solution)

Now, let’s solve the same problem using the **Decorator Pattern**:

![](https://miro.medium.com/v2/resize:fit:875/0*yOdqubuCVWi5YKpx.jpg)
Source: GeeksForGeeks
```java
// Step 1: Create the base interface  
interface Coffee {  
    int cost();  
}  
  
// Step 2: Implement the base class  
class BasicCoffee implements Coffee {  
    public int cost() {  
        return 50; // Base price  
    }  
}  
  
// Step 3: Create the Decorator class  
abstract class CoffeeDecorator implements Coffee {  
    protected Coffee coffee;  
      
    public CoffeeDecorator(Coffee coffee) {  
        this.coffee = coffee;  
    }  
      
    public int cost() {  
        return coffee.cost();  
    }  
}  
  
// Step 4: Implement specific decorators  
class MilkDecorator extends CoffeeDecorator {  
    public MilkDecorator(Coffee coffee) {  
        super(coffee);  
    }  
      
    public int cost() {  
        return super.cost() + 20;  
    }  
}  
  
class SugarDecorator extends CoffeeDecorator {  
    public SugarDecorator(Coffee coffee) {  
        super(coffee);  
    }  
      
    public int cost() {  
        return super.cost() + 10;  
    }  
}  
  
// Step 5: Use decorators dynamically  
public class DecoratorPatternExample {  
    public static void main(String[] args) {  
        Coffee coffee = new BasicCoffee();  
        System.out.println("Plain Coffee Cost: " + coffee.cost());  
          
        coffee = new MilkDecorator(coffee);  
        System.out.println("Coffee with Milk Cost: " + coffee.cost());  
          
        coffee = new SugarDecorator(coffee);  
        System.out.println("Coffee with Milk & Sugar Cost: " + coffee.cost());  
    }  
}
```
### Advantages of Using the Decorator Pattern

**Scalability**: No need to create multiple subclasses for each combination.  
**Flexibility**: Enhancements can be added dynamically at runtime.  
**Single Responsibility Principle (SRP)**: Each decorator has a specific role. ✔ **Improved Maintainability**: Code is modular and easy to extend.

### Comparison: Builder vs. Decorator Pattern

![](https://miro.medium.com/v2/resize:fit:875/1*sgh96VXJzeFKhbsA51fRiA.png)

### Conclusion

The **Decorator Pattern** is a powerful tool for extending object functionalities dynamically while keeping code clean and maintainable. Understanding and applying it effectively can significantly improve software design.

