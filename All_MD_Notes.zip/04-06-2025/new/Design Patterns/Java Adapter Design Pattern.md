### Java Adapter Design Pattern

### Introduction

Have you ever faced a situation where two systems or components don’t communicate with each other because they speak different ‘languages’? Just like a power plug adapter allows you to use your charger in a foreign country, the **Adapter Design Pattern** acts as a bridge between incompatible interfaces in software development.

In this article, we’ll dive deep into the **Adapter Design Pattern**, covering its features, use cases, real-world applications, best practices, step-by-step implementation, and a comparison with similar patterns.

### What is the Adapter Design Pattern?

The **Adapter Pattern** is a **structural design pattern** that allows objects with incompatible interfaces to work together. It acts as a middle layer that translates one interface into another, making it easier to integrate different parts of a system.

![](https://miro.medium.com/v2/resize:fit:725/0*kBgBtTIsCnK2DwZo.png)
Source: Refactoring Guru

### Key Features:

-   Converts one interface into another without modifying existing code.
-   Helps achieve reusability and flexibility in system design.
-   Can be implemented using **class-based** (inheritance) or **object-based** (composition) approaches.
-   Useful when integrating third-party libraries or legacy code.

### Why Do We Need the Adapter Pattern?

Modern software systems often involve integrating multiple components, APIs, or third-party services that were not designed to work together. This is where the **Adapter Pattern** comes in handy.

### When and Where to Use It?

-   **Legacy Code Integration**: When you need to use old classes in a new system but their interfaces don’t match.
-   **Third-Party Libraries**: When a library provides an interface that differs from what your system expects.
-   **Incompatible APIs**: When you need to unify the interaction between different APIs.
-   **Different Data Formats**: When data structures are inconsistent across different parts of a system.

### Real-World Applications of the Adapter Pattern

Let’s take some relatable examples to understand its significance.

### Example 1: Power Adapter (Everyday Life)

Imagine you travel to Europe with your laptop charger, but the power socket shape is different. A **power plug adapter** helps convert the socket format, making your charger compatible with the European power supply.

### Example 2: Payment Gateway Integration

Many e-commerce platforms integrate different payment gateways (PayPal, Stripe, Razorpay, etc.). Since each gateway has a different API format, an **adapter class** is used to standardize their interfaces, ensuring smooth payment processing.

### Example 3: Database Driver Adapters

JDBC (Java Database Connectivity) acts as an adapter between Java applications and multiple databases (MySQL, PostgreSQL, etc.). The application interacts with JDBC in a unified way, even though the underlying database drivers have different implementations.

### Components of Adapter Design Pattern

![](https://miro.medium.com/v2/resize:fit:725/0*4TDIErsNM6Y4I6vz.png)
Source: Refactoring Guru

1.  The **Client** is a class that contains the existing business logic of the program.
2.  The **Client Interface** describes a protocol that other classes must follow to be able to collaborate with the client code.
3.  The **Service** is some useful class (usually 3rd-party or legacy). The client can’t use this class directly because it has an incompatible interface.
4.  The **Adapter** is a class that’s able to work with both the client and the service: it implements the client interface, while wrapping the service object. The adapter receives calls from the client via the client interface and translates them into calls to the wrapped service object in a format it can understand.

The client code doesn’t get coupled to the concrete adapter class as long as it works with the adapter via the client interface. Thanks to this, you can introduce new types of adapters into the program without breaking the existing client code. This can be useful when the interface of the service class gets changed or replaced: you can just create a new adapter class without changing the client code.

### Class Adapter

This implementation uses inheritance: the adapter inherits interfaces from both objects at the same time.

![](https://miro.medium.com/v2/resize:fit:688/0*5dGaYL4ITjayTYE8.png)
Source: Refactoring Guru

The **Class Adapter** doesn’t need to wrap any objects because it inherits behaviors from both the client and the service. The adaptation happens within the overridden methods. The resulting adapter can be used in place of an existing client class.

**Note** that this approach can only be implemented in programming languages that support multiple inheritance, such as C++.

Since Java **does not support multiple inheritance**, we typically implement the **Adapter Pattern** using either **composition** or **interface implementation**.

### Adapter vs Other Structural Patterns

### Adapter vs Bridge

-   **Adapter** translates an existing interface to match what a client expects.
-   **Bridge** separates abstraction from implementation to allow independent modifications.

### Adapter vs Decorator

-   **Adapter** changes the interface of an object.
-   **Decorator** adds new functionality without altering the interface.

### Adapter vs Proxy

-   **Adapter** changes the interface.
-   **Proxy** controls access to an object (e.g., lazy initialization, access control).

### Best Practices for Implementing the Adapter Pattern

-   **Use Composition Over Inheritance**: Prefer object-based adapters to avoid tight coupling.
-   **Follow the Single Responsibility Principle**: The adapter should only handle interface conversion.
-   **Ensure Performance Efficiency**: Avoid excessive conversion logic that may slow down performance.
-   **Make It Reusable**: Design adapters that work across multiple use cases rather than being tightly bound to one implementation.

### Step-by-Step Implementation

### Example: Adapting a Legacy Logger in Java

**Scenario:** Suppose we have an old `LegacyLogger` class that only logs messages to a file, but our new system expects a logger with a `logToConsole` method.

### Step 1: Define the Incompatible Legacy Class
```java
class LegacyLogger {  
    public void logToFile(String message) {  
        System.out.println("Logging to a file: " + message);  
    }  
}
```

### Step 2: Define the Target Interface
```java
interface ModernLogger {  
    void logToConsole(String message);  
}
```
### Step 3: Create an Adapter Class
```java
class LoggerAdapter implements ModernLogger {  
    private LegacyLogger legacyLogger;  
  
    public LoggerAdapter(LegacyLogger legacyLogger) {  
        this.legacyLogger = legacyLogger;  
    }  
  
    @Override  
    public void logToConsole(String message) {  
        legacyLogger.logToFile(message); // Adapting old behavior  
    }  
}
```

### Step 4: Use the Adapter
```java
public class AdapterPatternDemo {  
    public static void main(String[] args) {  
        LegacyLogger legacyLogger = new LegacyLogger();  
        ModernLogger logger = new LoggerAdapter(legacyLogger);  
          
        logger.logToConsole("This is an adapted log message.");  
    }  
}
```
### Output:

Logging to a file: This is an adapted log message.

Here, `LoggerAdapter` bridges the gap between the legacy logger and the new system requirements.

### Pros and Cons of the Adapter Pattern

### ✅ Pros

1.  **Enables Reusability**: Allows integration of existing, incompatible classes without modification.
2.  **Enhances Flexibility**: Simplifies interactions between different systems.
3.  **Improves Maintainability**: Separates interface conversion logic into a dedicated class.

### ❌ Cons

1.  **Adds Complexity**: Introduces extra layers, which may be unnecessary for simple cases.
2.  **Performance Overhead**: If not implemented efficiently, frequent interface conversions can slow down performance.
3.  **Can Be Misused**: Overuse can lead to excessive abstraction, making the code harder to follow.

### Conclusion

The **Adapter Design Pattern** is a powerful tool when dealing with incompatible interfaces in software systems. Whether integrating legacy systems, third-party libraries, or different APIs, adapters help achieve seamless communication without modifying existing code. However, like any design pattern, it should be used judiciously to avoid unnecessary complexity.

By understanding its use cases, best practices, and implementation steps, you can leverage the **Adapter Pattern** effectively in your projects. Hope this guide helps you grasp the concept and apply it efficiently!

