### The Command Design Pattern

### Introduction

The **Command Design Pattern** helps break down actions into separate objects, making it easier to manage tasks like undo, redo, and logging. It’s great for situations where you want to **decouple** the request (what needs to be done) from how it’s actually executed.

![](https://miro.medium.com/v2/resize:fit:800/0*ZjLn3UIq-B4VFD78)
Source: Refactoring guru

In this article, we’ll cover:

-   **What is the Command Pattern?**
-   **How does it work?**
-   **When should you use it?**
-   **Real-life examples**
-   **How to implement it with and without the pattern**
-   **Best practices, pros, and cons**
-   **How to add an Undo feature**

By the end, you’ll have a solid understanding of how this pattern can improve your code.

### What is the Command Pattern?

The **Command Pattern** is a way to wrap actions (or requests) inside objects. This means that instead of calling methods directly, you create command objects that **store details of the action**, such as which method to call, which object it should act on, and any needed parameters.

### Key Parts of the Command Pattern

1.  **Command Interface**: Defines what every command should have.
2.  **Concrete Commands**: These actually do the work.
3.  **Receiver**: The object that performs the action.
4.  **Invoker**: The one that calls commands.
5.  **Client**: The main program that sets up everything.

Here’s a **simple diagram** to visualize how it works:

![](https://miro.medium.com/v2/resize:fit:750/0*Vs9pVnzqEj4cBiT.gif)
Source: oodesign.com

### When Should You Use It?

Use the **Command Pattern** when you need:

-   **Undo/Redo functionality** (e.g., text editors, design tools)
-   **Macro recording** (e.g., game automation, software shortcuts)
-   **Logging requests** (e.g., tracking user actions)
-   **GUI buttons & menu actions** (e.g., clicking buttons in an app)
-   **Job Queues & Scheduling** (e.g., background tasks)

### Real-Life Examples

-   **Remote Control**: Pressing a button triggers different commands (e.g., turn on/off TV, increase volume).
-   **ATM Transactions**: Withdrawing or depositing money acts as a command.
-   **Shopping Cart**: Adding or removing items can be executed as commands, allowing rollback.

### Implementation Without the Command Pattern

Let’s say we have a **remote control that turns a light on and off**. Without using the **Command Pattern**, it looks like this:
```java
class Light {  
    public void turnOn() {  
        System.out.println("Light is ON");  
    }  
    public void turnOff() {  
        System.out.println("Light is OFF");  
    }  
}  
  
class RemoteControl {  
    private Light light;  
    public RemoteControl(Light light) {  
        this.light = light;  
    }  
    public void pressOnButton() {  
        light.turnOn();  
    }  
    public void pressOffButton() {  
        light.turnOff();  
    }  
}  
public class Main {  
    public static void main(String[] args) {  
        Light light = new Light();  
        RemoteControl remote = new RemoteControl(light);  
        remote.pressOnButton();  // Light is ON  
        remote.pressOffButton(); // Light is OFF  
    }  
}
```
### Problems with This Approach:

1.  The remote control **directly depends** on the `Light` class.
2.  **No Undo feature** (If we want to undo an action, we have to add more logic).
3.  **Difficult to extend** (If we want to control other devices, we must modify `RemoteControl`).

### Using the Command Pattern (Better Approach)

Now, let’s **improve** our design using the **Command Pattern**.
```java
// Step 1: Command Interface  
interface Command {  
    void execute();  
    void undo();  
}  
  
class LightOnCommand implements Command {  
    private Light light;  
      
    public LightOnCommand(Light light) {  
        this.light = light;  
    }  
    public void execute() {  
        light.turnOn();  
    }  
      
    public void undo() {  
        light.turnOff();  
    }  
}  
// Step 3: Concrete Command for Turning Light OFF  
class LightOffCommand implements Command {  
    private Light light;  
      
    public LightOffCommand(Light light) {  
        this.light = light;  
    }  
      
    public void execute() {  
        light.turnOff();  
    }  
      
    public void undo() {  
        light.turnOn();  
    }  
}  
// Step 4: Remote Control (Invoker)  
class RemoteControl {  
    private Command command;  
      
    public void setCommand(Command command) {  
        this.command = command;  
    }  
      
    public void pressButton() {  
        command.execute();  
    }  
      
    public void pressUndo() {  
        command.undo();  
    }  
}  
// Step 5: Client Code  
public class Main {  
    public static void main(String[] args) {  
        Light light = new Light();  
        Command lightOn = new LightOnCommand(light);  
        Command lightOff = new LightOffCommand(light);  
          
        RemoteControl remote = new RemoteControl();  
          
        remote.setCommand(lightOn);  
        remote.pressButton();  // Light is ON  
        remote.pressUndo();    // Light is OFF  
        remote.setCommand(lightOff);  
        remote.pressButton();  // Light is OFF  
        remote.pressUndo();    // Light is ON  
    }  
}
```
### Pros & Cons of the Command Pattern

######### Pros:

1.  Decouples sender and receiver.
2.  Easier to add new commands.
3.  Supports undo/redo functionality.
4.  Can store commands for later execution

######### Cons:

1.  **More classes and objects** (Adds complexity if the problem is simple)
2.  **Might be overkill** for basic applications
