### Java Proxy Design Pattern

### Introduction

The **Proxy Design Pattern** is a **structural design pattern** that **provides an intermediary to control access to an object.** This pattern acts as a placeholder or surrogate for another object, enabling additional functionality such as **lazy initialization, access control, logging, caching, and security**.

In this article, we will cover **everything** about the Proxy Pattern, including its **components, real-world use cases, best practices, and an in-depth implementation of API rate-limiting using proxies**.

### Understanding the Proxy Pattern

A **Proxy** is an object that controls access to another object. The primary reasons for using a proxy include:

-   **Security**: Restricting access to certain functionalities.
-   **Performance Optimization**: Caching results and reducing computation.
-   **Lazy Instantiation**: Deferring the creation of resource-heavy objects.
-   **Logging and Monitoring**: Keeping track of access and modifications.
-   **Rate Limiting**: Restricting excessive API requests.

### Components of Proxy Pattern

![](https://miro.medium.com/v2/resize:fit:463/0*WJIrw-U7CTbhWs6Z)
Source: Refactoring Guru

1.  **Subject (Interface)**: Defines the common interface for RealSubject and Proxy.
2.  **RealSubject (Service)**: The actual object that performs the real functionality.
3.  **Proxy**: Controls access to the RealSubject and may add extra functionalities.

### Block Diagram

+------------+        +------------+        +--------------+  
|  Client    | -----> |   Proxy    | -----> | RealSubject  |  
+------------+        +------------+        +--------------+  
         Request       Controls Access       Actual Execution

### When and Where to Use the Proxy Pattern?

-   **Virtual Proxy**: Delays object creation (e.g., loading images in an image viewer only when required).
-   **Remote Proxy**: Represents an object in a different address space (e.g., RMI in Java).
-   **Protection Proxy**: Controls access based on user permissions (e.g., restricting access to admin functionalities).
-   **Smart Proxy**: Adds extra logic (e.g., reference counting, caching, logging).
-   **Rate-Limiting Proxy**: Restricts excessive API calls (e.g., API gateways throttling requests).

### Real-Life Examples

-   **Cloud Service Authentication**: AWS or Google Cloud APIs use API Gateway proxies for authentication and rate-limiting.
-   **Internet Proxy Servers**: Acting as intermediaries between users and websites for security and caching.
-   **Database Connection Pools**: Managing expensive database connections efficiently.
-   **Lazy-Loading in Web Applications**: Loading heavy resources only when necessary.

### Proxy Pattern in Action: API Rate Limiting

### Without Using Proxy Pattern

Let’s first implement an API rate limiter **without** a proxy.
```java
class APIService {  
    public void request(String userId) {  
        System.out.println("API request processed for user " + userId);  
    }  
}  
  
public class Main {  
    public static void main(String[] args) {  
        APIService service = new APIService();  
        service.request("user123");  
        service.request("user123");  
        service.request("user123"); // No rate limiting here  
    }  
}
```
### Issues Without Proxy

-   **No access control**: Any number of requests can be made.
-   **Performance issues**: No control over request spamming.
-   **No logging and monitoring**.

### Implementing Proxy for Rate Limiting

Now, let’s use the **Proxy Pattern** to introduce rate-limiting.
```java
import java.util.Deque;  
import java.util.HashMap;  
import java.util.LinkedList;  
  
interface Service {  
    void request(String userId);  
}  
class APIService implements Service {  
    public void request(String userId) {  
        System.out.println("API request processed for user " + userId);  
    }  
}  
class RateLimitingProxy implements Service {  
    private final APIService realService;  
    private final int maxRequests;  
    private final long timeWindow;  
    private final HashMap<String, Deque<Long>> requestLog;  
    public RateLimitingProxy(APIService realService, int maxRequests, long timeWindow) {  
        this.realService = realService;  
        this.maxRequests = maxRequests;  
        this.timeWindow = timeWindow;  
        this.requestLog = new HashMap<>();  
    }  
    public void request(String userId) {  
        long currentTime = System.currentTimeMillis();  
        requestLog.putIfAbsent(userId, new LinkedList<>());  
        Deque<Long> requestTimes = requestLog.get(userId);  
          
        while (!requestTimes.isEmpty() && currentTime - requestTimes.peekFirst() > timeWindow) {  
            requestTimes.pollFirst();  
        }  
          
        if (requestTimes.size() < maxRequests) {  
            requestTimes.addLast(currentTime);  
            realService.request(userId);  
        } else {  
            System.out.println("Rate limit exceeded for user " + userId + ". Try again later.");  
        }  
    }  
}  
public class Main {  
    public static void main(String[] args) throws InterruptedException {  
        APIService realService = new APIService();  
        Service proxy = new RateLimitingProxy(realService, 2, 10000);  
        proxy.request("user123");  
        proxy.request("user123");  
        proxy.request("user123"); // This request will be blocked  
    }  
}
```

### Advantages of Using Proxy

-   **Controlled Access**: Prevents spamming.
-   **Better Performance**: Avoids unnecessary loads on the service.
-   **Security & Monitoring**: Logs access and ensures fair use.

### Best Practices for Implementing Proxy Pattern

1.  **Use Proxies for Performance and Security**: Implement only when needed, such as caching or access control.
2.  **Keep Proxy Lightweight**: Avoid making the proxy more complex than the real object.
3.  **Decouple Proxy and RealSubject**: Use interfaces for better abstraction.
4.  **Log and Monitor Usage**: Especially for access control and performance enhancement.
5.  **Use Dependency Injection**: Inject real objects into the proxy instead of hardcoding them.

### Pros and Cons of Proxy Pattern

### Pros:

-   Improves performance with caching and lazy-loading.
-   Enhances security by controlling access.
-   Adds flexibility with logging and monitoring.
-   Supports remote objects in distributed systems.

### Cons:

-   Adds complexity to the codebase.
-   Can introduce latency if not optimized well.
-   Requires careful maintenance to avoid bottlenecks.

### Conclusion

The **Proxy Design Pattern** is a powerful tool for managing object access while adding functionalities like **security, logging, and performance optimizations**. We explored its detailed implementation for **API rate-limiting**, demonstrating how proxies efficiently regulate request handling.
