### Java Bridge Design Pattern
![](https://miro.medium.com/v2/resize:fit:800/0*5Hg1PyXEWBYEUmW)
Source: Refactoring Guru

### Introduction

The **Bridge Design Pattern** is a structural design pattern that decouples an abstraction from its implementation so that both can evolve independently. This is particularly useful when we need to extend a system with multiple dimensions of variations without causing a combinatorial explosion of subclasses.

In this article, we will explore the **Bridge Design Pattern** in depth, understand its components, when and where to use it, compare it with the **Strategy Pattern**, and implement it with a real-world example.

### What is the Bridge Design Pattern?

The **Bridge Pattern** is used to separate abstraction and implementation into different classes so that changes in one do not affect the other. This separation allows easier maintenance and scalability.

### Key Idea

Instead of tightly coupling the abstraction (interface) with a specific implementation, the **Bridge Pattern** introduces an intermediary bridge, facilitating flexibility and extensibility.

### Components of the Bridge Pattern

![](https://miro.medium.com/v2/resize:fit:700/0*tzEtDzKLdWLqILHZ)
Source: Refactoring Guru

### 1. Abstraction

-   The high-level interface that clients interact with.
-   Contains a reference to the **implementation**.

### 2. Refined Abstraction

-   Extends the **Abstraction** with additional functionalities.

### 3. Implementor (Interface or Abstract Class)

-   Declares an interface for implementation classes.

### 4. Concrete Implementor

-   Provides a concrete implementation for the **Implementor**.

### Block Diagram

            +-------------------+          +-------------------+  
            |   Abstraction     |          |  Implementor      |  
            |-------------------|          |-------------------|  
            |  Implementor impl |<>------->| operation()       |  
            +-------------------+          +-------------------+  
                     |                                 |  
            +-------------------+          +-------------------+  
            | RefinedAbstraction|          |ConcreteImplementor|  
            +-------------------+          +-------------------+

### When to Use the Bridge Design Pattern

-   When a **class has multiple dimensions of variability** that need to be managed independently.
-   When we want to **avoid subclass explosion** due to combinations of features.
-   When we need **runtime flexibility**, allowing different implementations to be switched dynamically.
-   When we want to **decouple high-level logic from platform-specific implementations**.

### Real-Life Examples of the Bridge Design Pattern

### 1. Remote Control System

-   We have a **Remote Control (Abstraction)** that works with different **devices (Implementations)** like **TV, AC, Fan**.
-   Instead of creating `TVRemoteControl`, `ACRemoteControl`, `FanRemoteControl`, we separate **Remote** from **Device**, allowing independent variations.

### 2. Cross-Platform UI Frameworks

-   Abstracting the **UI elements** from their **platform-specific rendering** (Windows, Mac, Linux).

### 3. Database Drivers

-   Different **databases (MySQL, PostgreSQL, MongoDB)** have their own implementations, but the abstraction remains the same.

### Implementation Without the Bridge Pattern (Tightly Coupled)

Let’s design a **Messaging System** where messages can be sent via **SMS, Email, and WhatsApp**.
```java
// Without Bridge Pattern  
interface Message {  
    void sendMessage(String message);  
}  
  
class SMSMessage implements Message {  
    public void sendMessage(String message) {  
        System.out.println("Sending SMS: " + message);  
    }  
}  
class EmailMessage implements Message {  
    public void sendMessage(String message) {  
        System.out.println("Sending Email: " + message);  
    }  
}  
class WhatsAppMessage implements Message {  
    public void sendMessage(String message) {  
        System.out.println("Sending WhatsApp: " + message);  
    }  
}
```

### Problems

-   If we introduce **Message Types** like `AlertMessage`, `NotificationMessage`, etc., the number of subclasses grows exponentially.
-   Changes in messaging platforms require modifying all message types.

### Implementing the Bridge Pattern

Now, let’s refactor using the **Bridge Pattern**:
```java
// Implementor Interface  
interface MessageSender {  
    void send(String message);  
}  
  
// Concrete Implementors  
class SMSSender implements MessageSender {  
    public void send(String message) {  
        System.out.println("Sending SMS: " + message);  
    }  
}  
class EmailSender implements MessageSender {  
    public void send(String message) {  
        System.out.println("Sending Email: " + message);  
    }  
}  
class WhatsAppSender implements MessageSender {  
    public void send(String message) {  
        System.out.println("Sending WhatsApp: " + message);  
    }  
}  
// Abstraction  
abstract class Message {  
    protected MessageSender sender;  
    protected Message(MessageSender sender) {  
        this.sender = sender;  
    }  
    abstract void sendMessage(String message);  
}  
// Refined Abstraction  
class NotificationMessage extends Message {  
    public NotificationMessage(MessageSender sender) {  
        super(sender);  
    }  
    public void sendMessage(String message) {  
        System.out.print("Notification - ");  
        sender.send(message);  
    }  
}  
class AlertMessage extends Message {  
    public AlertMessage(MessageSender sender) {  
        super(sender);  
    }  
    public void sendMessage(String message) {  
        System.out.print("Alert - ");  
        sender.send(message);  
    }  
}  
// Client Code  
public class BridgePatternDemo {  
    public static void main(String[] args) {  
        Message alert = new AlertMessage(new EmailSender());  
        alert.sendMessage("Server Down!");  
        Message notification = new NotificationMessage(new WhatsAppSender());  
        notification.sendMessage("Meeting at 5 PM");  
    }  
}
```

### Benefits of the Bridge Pattern

-   **Improved Scalability**: Easily add new `MessageSender` implementations or `Message` types independently.
-   **Decoupling**: Implementation changes don’t affect high-level abstractions.
-   **Runtime Flexibility**: Change implementations dynamically.

### Bridge Pattern vs Strategy Pattern

![](https://miro.medium.com/v2/resize:fit:875/1*gTQJoznHZEqKs3UHrkAQ.png)

### Pros and Cons of the Bridge Pattern

### Pros

-   Reduces subclass explosion
-   Improves maintainability
-   Enhances flexibility
-   Enables independent extension of abstraction and implementation

### Cons

-   Slightly increases code complexity
-   More indirections may introduce performance overhead

### Conclusion

The **Bridge Pattern** is a powerful structural pattern that promotes better software design by allowing abstractions and implementations to evolve independently. It’s particularly useful in scenarios where multiple dimensions of variations exist. By implementing it, we ensure **scalability, flexibility, and maintainability** while avoiding tightly coupled designs.

